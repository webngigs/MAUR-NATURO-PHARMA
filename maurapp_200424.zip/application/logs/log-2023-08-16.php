<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-16 01:54:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 01:54:04 --> Config Class Initialized
INFO - 2023-08-16 01:54:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 01:54:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 01:54:04 --> Utf8 Class Initialized
INFO - 2023-08-16 01:54:04 --> URI Class Initialized
DEBUG - 2023-08-16 01:54:04 --> No URI present. Default controller set.
INFO - 2023-08-16 01:54:04 --> Router Class Initialized
INFO - 2023-08-16 01:54:04 --> Output Class Initialized
INFO - 2023-08-16 01:54:04 --> Security Class Initialized
DEBUG - 2023-08-16 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 01:54:04 --> Input Class Initialized
INFO - 2023-08-16 01:54:04 --> Language Class Initialized
INFO - 2023-08-16 01:54:04 --> Loader Class Initialized
INFO - 2023-08-16 01:54:04 --> Helper loaded: url_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: file_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: html_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: text_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: form_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: lang_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: security_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: cookie_helper
INFO - 2023-08-16 01:54:04 --> Database Driver Class Initialized
INFO - 2023-08-16 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 01:54:04 --> Parser Class Initialized
INFO - 2023-08-16 01:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 01:54:04 --> Pagination Class Initialized
INFO - 2023-08-16 01:54:04 --> Form Validation Class Initialized
INFO - 2023-08-16 01:54:04 --> Controller Class Initialized
INFO - 2023-08-16 01:54:04 --> Model Class Initialized
DEBUG - 2023-08-16 01:54:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 01:54:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 01:54:04 --> Config Class Initialized
INFO - 2023-08-16 01:54:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 01:54:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 01:54:04 --> Utf8 Class Initialized
INFO - 2023-08-16 01:54:04 --> URI Class Initialized
INFO - 2023-08-16 01:54:04 --> Router Class Initialized
INFO - 2023-08-16 01:54:04 --> Output Class Initialized
INFO - 2023-08-16 01:54:04 --> Security Class Initialized
DEBUG - 2023-08-16 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 01:54:04 --> Input Class Initialized
INFO - 2023-08-16 01:54:04 --> Language Class Initialized
INFO - 2023-08-16 01:54:04 --> Loader Class Initialized
INFO - 2023-08-16 01:54:04 --> Helper loaded: url_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: file_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: html_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: text_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: form_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: lang_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: security_helper
INFO - 2023-08-16 01:54:04 --> Helper loaded: cookie_helper
INFO - 2023-08-16 01:54:04 --> Database Driver Class Initialized
INFO - 2023-08-16 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 01:54:04 --> Parser Class Initialized
INFO - 2023-08-16 01:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 01:54:04 --> Pagination Class Initialized
INFO - 2023-08-16 01:54:04 --> Form Validation Class Initialized
INFO - 2023-08-16 01:54:04 --> Controller Class Initialized
INFO - 2023-08-16 01:54:04 --> Model Class Initialized
DEBUG - 2023-08-16 01:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 01:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 01:54:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 01:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 01:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 01:54:04 --> Model Class Initialized
INFO - 2023-08-16 01:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 01:54:04 --> Final output sent to browser
DEBUG - 2023-08-16 01:54:04 --> Total execution time: 0.0323
ERROR - 2023-08-16 04:05:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:05:59 --> Config Class Initialized
INFO - 2023-08-16 04:05:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:05:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:05:59 --> Utf8 Class Initialized
INFO - 2023-08-16 04:05:59 --> URI Class Initialized
DEBUG - 2023-08-16 04:05:59 --> No URI present. Default controller set.
INFO - 2023-08-16 04:05:59 --> Router Class Initialized
INFO - 2023-08-16 04:05:59 --> Output Class Initialized
INFO - 2023-08-16 04:05:59 --> Security Class Initialized
DEBUG - 2023-08-16 04:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:05:59 --> Input Class Initialized
INFO - 2023-08-16 04:05:59 --> Language Class Initialized
INFO - 2023-08-16 04:05:59 --> Loader Class Initialized
INFO - 2023-08-16 04:05:59 --> Helper loaded: url_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: file_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: html_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: text_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: form_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: security_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:05:59 --> Database Driver Class Initialized
INFO - 2023-08-16 04:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:05:59 --> Parser Class Initialized
INFO - 2023-08-16 04:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:05:59 --> Pagination Class Initialized
INFO - 2023-08-16 04:05:59 --> Form Validation Class Initialized
INFO - 2023-08-16 04:05:59 --> Controller Class Initialized
INFO - 2023-08-16 04:05:59 --> Model Class Initialized
DEBUG - 2023-08-16 04:05:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 04:05:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:05:59 --> Config Class Initialized
INFO - 2023-08-16 04:05:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:05:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:05:59 --> Utf8 Class Initialized
INFO - 2023-08-16 04:05:59 --> URI Class Initialized
INFO - 2023-08-16 04:05:59 --> Router Class Initialized
INFO - 2023-08-16 04:05:59 --> Output Class Initialized
INFO - 2023-08-16 04:05:59 --> Security Class Initialized
DEBUG - 2023-08-16 04:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:05:59 --> Input Class Initialized
INFO - 2023-08-16 04:05:59 --> Language Class Initialized
INFO - 2023-08-16 04:05:59 --> Loader Class Initialized
INFO - 2023-08-16 04:05:59 --> Helper loaded: url_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: file_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: html_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: text_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: form_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: security_helper
INFO - 2023-08-16 04:05:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:05:59 --> Database Driver Class Initialized
INFO - 2023-08-16 04:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:05:59 --> Parser Class Initialized
INFO - 2023-08-16 04:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:05:59 --> Pagination Class Initialized
INFO - 2023-08-16 04:05:59 --> Form Validation Class Initialized
INFO - 2023-08-16 04:05:59 --> Controller Class Initialized
INFO - 2023-08-16 04:05:59 --> Model Class Initialized
DEBUG - 2023-08-16 04:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 04:05:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:05:59 --> Model Class Initialized
INFO - 2023-08-16 04:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:05:59 --> Final output sent to browser
DEBUG - 2023-08-16 04:05:59 --> Total execution time: 0.0310
ERROR - 2023-08-16 04:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:30:31 --> Config Class Initialized
INFO - 2023-08-16 04:30:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:30:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:30:31 --> Utf8 Class Initialized
INFO - 2023-08-16 04:30:31 --> URI Class Initialized
DEBUG - 2023-08-16 04:30:31 --> No URI present. Default controller set.
INFO - 2023-08-16 04:30:31 --> Router Class Initialized
INFO - 2023-08-16 04:30:31 --> Output Class Initialized
INFO - 2023-08-16 04:30:31 --> Security Class Initialized
DEBUG - 2023-08-16 04:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:30:31 --> Input Class Initialized
INFO - 2023-08-16 04:30:31 --> Language Class Initialized
INFO - 2023-08-16 04:30:31 --> Loader Class Initialized
INFO - 2023-08-16 04:30:31 --> Helper loaded: url_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: file_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: html_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: text_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: form_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: security_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:30:31 --> Database Driver Class Initialized
INFO - 2023-08-16 04:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:30:31 --> Parser Class Initialized
INFO - 2023-08-16 04:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:30:31 --> Pagination Class Initialized
INFO - 2023-08-16 04:30:31 --> Form Validation Class Initialized
INFO - 2023-08-16 04:30:31 --> Controller Class Initialized
INFO - 2023-08-16 04:30:31 --> Model Class Initialized
DEBUG - 2023-08-16 04:30:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 04:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:30:31 --> Config Class Initialized
INFO - 2023-08-16 04:30:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:30:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:30:31 --> Utf8 Class Initialized
INFO - 2023-08-16 04:30:31 --> URI Class Initialized
INFO - 2023-08-16 04:30:31 --> Router Class Initialized
INFO - 2023-08-16 04:30:31 --> Output Class Initialized
INFO - 2023-08-16 04:30:31 --> Security Class Initialized
DEBUG - 2023-08-16 04:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:30:31 --> Input Class Initialized
INFO - 2023-08-16 04:30:31 --> Language Class Initialized
INFO - 2023-08-16 04:30:31 --> Loader Class Initialized
INFO - 2023-08-16 04:30:31 --> Helper loaded: url_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: file_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: html_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: text_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: form_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: security_helper
INFO - 2023-08-16 04:30:31 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:30:31 --> Database Driver Class Initialized
INFO - 2023-08-16 04:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:30:31 --> Parser Class Initialized
INFO - 2023-08-16 04:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:30:31 --> Pagination Class Initialized
INFO - 2023-08-16 04:30:31 --> Form Validation Class Initialized
INFO - 2023-08-16 04:30:31 --> Controller Class Initialized
INFO - 2023-08-16 04:30:31 --> Model Class Initialized
DEBUG - 2023-08-16 04:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 04:30:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:30:31 --> Model Class Initialized
INFO - 2023-08-16 04:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:30:31 --> Final output sent to browser
DEBUG - 2023-08-16 04:30:31 --> Total execution time: 0.0326
ERROR - 2023-08-16 04:30:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:30:48 --> Config Class Initialized
INFO - 2023-08-16 04:30:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:30:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:30:48 --> Utf8 Class Initialized
INFO - 2023-08-16 04:30:48 --> URI Class Initialized
INFO - 2023-08-16 04:30:48 --> Router Class Initialized
INFO - 2023-08-16 04:30:48 --> Output Class Initialized
INFO - 2023-08-16 04:30:48 --> Security Class Initialized
DEBUG - 2023-08-16 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:30:48 --> Input Class Initialized
INFO - 2023-08-16 04:30:48 --> Language Class Initialized
INFO - 2023-08-16 04:30:48 --> Loader Class Initialized
INFO - 2023-08-16 04:30:48 --> Helper loaded: url_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: file_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: html_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: text_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: form_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: security_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:30:48 --> Database Driver Class Initialized
INFO - 2023-08-16 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:30:48 --> Parser Class Initialized
INFO - 2023-08-16 04:30:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:30:48 --> Pagination Class Initialized
INFO - 2023-08-16 04:30:48 --> Form Validation Class Initialized
INFO - 2023-08-16 04:30:48 --> Controller Class Initialized
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
DEBUG - 2023-08-16 04:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
INFO - 2023-08-16 04:30:48 --> Final output sent to browser
DEBUG - 2023-08-16 04:30:48 --> Total execution time: 0.0221
ERROR - 2023-08-16 04:30:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:30:48 --> Config Class Initialized
INFO - 2023-08-16 04:30:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:30:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:30:48 --> Utf8 Class Initialized
INFO - 2023-08-16 04:30:48 --> URI Class Initialized
DEBUG - 2023-08-16 04:30:48 --> No URI present. Default controller set.
INFO - 2023-08-16 04:30:48 --> Router Class Initialized
INFO - 2023-08-16 04:30:48 --> Output Class Initialized
INFO - 2023-08-16 04:30:48 --> Security Class Initialized
DEBUG - 2023-08-16 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:30:48 --> Input Class Initialized
INFO - 2023-08-16 04:30:48 --> Language Class Initialized
INFO - 2023-08-16 04:30:48 --> Loader Class Initialized
INFO - 2023-08-16 04:30:48 --> Helper loaded: url_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: file_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: html_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: text_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: form_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: security_helper
INFO - 2023-08-16 04:30:48 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:30:48 --> Database Driver Class Initialized
INFO - 2023-08-16 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:30:48 --> Parser Class Initialized
INFO - 2023-08-16 04:30:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:30:48 --> Pagination Class Initialized
INFO - 2023-08-16 04:30:48 --> Form Validation Class Initialized
INFO - 2023-08-16 04:30:48 --> Controller Class Initialized
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
DEBUG - 2023-08-16 04:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
DEBUG - 2023-08-16 04:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
DEBUG - 2023-08-16 04:30:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
INFO - 2023-08-16 04:30:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 04:30:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:30:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:30:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:30:48 --> Model Class Initialized
INFO - 2023-08-16 04:30:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:30:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:30:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:30:48 --> Final output sent to browser
DEBUG - 2023-08-16 04:30:48 --> Total execution time: 0.0940
ERROR - 2023-08-16 04:31:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:31:54 --> Config Class Initialized
INFO - 2023-08-16 04:31:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:31:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:31:54 --> Utf8 Class Initialized
INFO - 2023-08-16 04:31:54 --> URI Class Initialized
INFO - 2023-08-16 04:31:54 --> Router Class Initialized
INFO - 2023-08-16 04:31:54 --> Output Class Initialized
INFO - 2023-08-16 04:31:54 --> Security Class Initialized
DEBUG - 2023-08-16 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:31:54 --> Input Class Initialized
INFO - 2023-08-16 04:31:54 --> Language Class Initialized
INFO - 2023-08-16 04:31:54 --> Loader Class Initialized
INFO - 2023-08-16 04:31:54 --> Helper loaded: url_helper
INFO - 2023-08-16 04:31:54 --> Helper loaded: file_helper
INFO - 2023-08-16 04:31:54 --> Helper loaded: html_helper
INFO - 2023-08-16 04:31:54 --> Helper loaded: text_helper
INFO - 2023-08-16 04:31:54 --> Helper loaded: form_helper
INFO - 2023-08-16 04:31:54 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:31:54 --> Helper loaded: security_helper
INFO - 2023-08-16 04:31:54 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:31:54 --> Database Driver Class Initialized
INFO - 2023-08-16 04:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:31:54 --> Parser Class Initialized
INFO - 2023-08-16 04:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:31:54 --> Pagination Class Initialized
INFO - 2023-08-16 04:31:54 --> Form Validation Class Initialized
INFO - 2023-08-16 04:31:54 --> Controller Class Initialized
INFO - 2023-08-16 04:31:54 --> Model Class Initialized
DEBUG - 2023-08-16 04:31:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:31:54 --> Model Class Initialized
DEBUG - 2023-08-16 04:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:31:54 --> Model Class Initialized
INFO - 2023-08-16 04:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 04:31:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:31:54 --> Model Class Initialized
INFO - 2023-08-16 04:31:54 --> Model Class Initialized
INFO - 2023-08-16 04:31:54 --> Model Class Initialized
INFO - 2023-08-16 04:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:31:54 --> Final output sent to browser
DEBUG - 2023-08-16 04:31:54 --> Total execution time: 0.0745
ERROR - 2023-08-16 04:31:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:31:55 --> Config Class Initialized
INFO - 2023-08-16 04:31:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:31:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:31:55 --> Utf8 Class Initialized
INFO - 2023-08-16 04:31:55 --> URI Class Initialized
INFO - 2023-08-16 04:31:55 --> Router Class Initialized
INFO - 2023-08-16 04:31:55 --> Output Class Initialized
INFO - 2023-08-16 04:31:55 --> Security Class Initialized
DEBUG - 2023-08-16 04:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:31:55 --> Input Class Initialized
INFO - 2023-08-16 04:31:55 --> Language Class Initialized
INFO - 2023-08-16 04:31:55 --> Loader Class Initialized
INFO - 2023-08-16 04:31:55 --> Helper loaded: url_helper
INFO - 2023-08-16 04:31:55 --> Helper loaded: file_helper
INFO - 2023-08-16 04:31:55 --> Helper loaded: html_helper
INFO - 2023-08-16 04:31:55 --> Helper loaded: text_helper
INFO - 2023-08-16 04:31:55 --> Helper loaded: form_helper
INFO - 2023-08-16 04:31:55 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:31:55 --> Helper loaded: security_helper
INFO - 2023-08-16 04:31:55 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:31:55 --> Database Driver Class Initialized
INFO - 2023-08-16 04:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:31:55 --> Parser Class Initialized
INFO - 2023-08-16 04:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:31:55 --> Pagination Class Initialized
INFO - 2023-08-16 04:31:55 --> Form Validation Class Initialized
INFO - 2023-08-16 04:31:55 --> Controller Class Initialized
INFO - 2023-08-16 04:31:55 --> Model Class Initialized
DEBUG - 2023-08-16 04:31:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:31:55 --> Model Class Initialized
DEBUG - 2023-08-16 04:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:31:55 --> Model Class Initialized
INFO - 2023-08-16 04:31:55 --> Final output sent to browser
DEBUG - 2023-08-16 04:31:55 --> Total execution time: 0.0362
ERROR - 2023-08-16 04:32:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:32:17 --> Config Class Initialized
INFO - 2023-08-16 04:32:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:32:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:32:17 --> Utf8 Class Initialized
INFO - 2023-08-16 04:32:17 --> URI Class Initialized
INFO - 2023-08-16 04:32:17 --> Router Class Initialized
INFO - 2023-08-16 04:32:17 --> Output Class Initialized
INFO - 2023-08-16 04:32:17 --> Security Class Initialized
DEBUG - 2023-08-16 04:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:32:17 --> Input Class Initialized
INFO - 2023-08-16 04:32:17 --> Language Class Initialized
INFO - 2023-08-16 04:32:17 --> Loader Class Initialized
INFO - 2023-08-16 04:32:17 --> Helper loaded: url_helper
INFO - 2023-08-16 04:32:17 --> Helper loaded: file_helper
INFO - 2023-08-16 04:32:17 --> Helper loaded: html_helper
INFO - 2023-08-16 04:32:17 --> Helper loaded: text_helper
INFO - 2023-08-16 04:32:17 --> Helper loaded: form_helper
INFO - 2023-08-16 04:32:17 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:32:17 --> Helper loaded: security_helper
INFO - 2023-08-16 04:32:17 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:32:17 --> Database Driver Class Initialized
INFO - 2023-08-16 04:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:32:17 --> Parser Class Initialized
INFO - 2023-08-16 04:32:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:32:17 --> Pagination Class Initialized
INFO - 2023-08-16 04:32:17 --> Form Validation Class Initialized
INFO - 2023-08-16 04:32:17 --> Controller Class Initialized
INFO - 2023-08-16 04:32:17 --> Model Class Initialized
DEBUG - 2023-08-16 04:32:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:32:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:17 --> Model Class Initialized
DEBUG - 2023-08-16 04:32:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:17 --> Model Class Initialized
INFO - 2023-08-16 04:32:17 --> Final output sent to browser
DEBUG - 2023-08-16 04:32:17 --> Total execution time: 0.0446
ERROR - 2023-08-16 04:32:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:32:20 --> Config Class Initialized
INFO - 2023-08-16 04:32:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:32:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:32:20 --> Utf8 Class Initialized
INFO - 2023-08-16 04:32:20 --> URI Class Initialized
INFO - 2023-08-16 04:32:20 --> Router Class Initialized
INFO - 2023-08-16 04:32:20 --> Output Class Initialized
INFO - 2023-08-16 04:32:20 --> Security Class Initialized
DEBUG - 2023-08-16 04:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:32:20 --> Input Class Initialized
INFO - 2023-08-16 04:32:20 --> Language Class Initialized
INFO - 2023-08-16 04:32:20 --> Loader Class Initialized
INFO - 2023-08-16 04:32:20 --> Helper loaded: url_helper
INFO - 2023-08-16 04:32:20 --> Helper loaded: file_helper
INFO - 2023-08-16 04:32:20 --> Helper loaded: html_helper
INFO - 2023-08-16 04:32:20 --> Helper loaded: text_helper
INFO - 2023-08-16 04:32:20 --> Helper loaded: form_helper
INFO - 2023-08-16 04:32:20 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:32:20 --> Helper loaded: security_helper
INFO - 2023-08-16 04:32:20 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:32:20 --> Database Driver Class Initialized
INFO - 2023-08-16 04:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:32:20 --> Parser Class Initialized
INFO - 2023-08-16 04:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:32:20 --> Pagination Class Initialized
INFO - 2023-08-16 04:32:20 --> Form Validation Class Initialized
INFO - 2023-08-16 04:32:20 --> Controller Class Initialized
INFO - 2023-08-16 04:32:20 --> Model Class Initialized
DEBUG - 2023-08-16 04:32:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:20 --> Model Class Initialized
DEBUG - 2023-08-16 04:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:20 --> Model Class Initialized
INFO - 2023-08-16 04:32:20 --> Final output sent to browser
DEBUG - 2023-08-16 04:32:20 --> Total execution time: 0.0766
ERROR - 2023-08-16 04:32:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:32:42 --> Config Class Initialized
INFO - 2023-08-16 04:32:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:32:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:32:42 --> Utf8 Class Initialized
INFO - 2023-08-16 04:32:42 --> URI Class Initialized
DEBUG - 2023-08-16 04:32:42 --> No URI present. Default controller set.
INFO - 2023-08-16 04:32:42 --> Router Class Initialized
INFO - 2023-08-16 04:32:42 --> Output Class Initialized
INFO - 2023-08-16 04:32:42 --> Security Class Initialized
DEBUG - 2023-08-16 04:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:32:42 --> Input Class Initialized
INFO - 2023-08-16 04:32:42 --> Language Class Initialized
INFO - 2023-08-16 04:32:42 --> Loader Class Initialized
INFO - 2023-08-16 04:32:42 --> Helper loaded: url_helper
INFO - 2023-08-16 04:32:42 --> Helper loaded: file_helper
INFO - 2023-08-16 04:32:42 --> Helper loaded: html_helper
INFO - 2023-08-16 04:32:42 --> Helper loaded: text_helper
INFO - 2023-08-16 04:32:42 --> Helper loaded: form_helper
INFO - 2023-08-16 04:32:42 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:32:42 --> Helper loaded: security_helper
INFO - 2023-08-16 04:32:42 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:32:42 --> Database Driver Class Initialized
INFO - 2023-08-16 04:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:32:42 --> Parser Class Initialized
INFO - 2023-08-16 04:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:32:42 --> Pagination Class Initialized
INFO - 2023-08-16 04:32:42 --> Form Validation Class Initialized
INFO - 2023-08-16 04:32:42 --> Controller Class Initialized
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
DEBUG - 2023-08-16 04:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
DEBUG - 2023-08-16 04:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
DEBUG - 2023-08-16 04:32:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
INFO - 2023-08-16 04:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 04:32:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:32:42 --> Model Class Initialized
INFO - 2023-08-16 04:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:32:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:32:42 --> Final output sent to browser
DEBUG - 2023-08-16 04:32:42 --> Total execution time: 0.0920
ERROR - 2023-08-16 04:33:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:33:51 --> Config Class Initialized
INFO - 2023-08-16 04:33:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:33:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:33:51 --> Utf8 Class Initialized
INFO - 2023-08-16 04:33:51 --> URI Class Initialized
INFO - 2023-08-16 04:33:51 --> Router Class Initialized
INFO - 2023-08-16 04:33:51 --> Output Class Initialized
INFO - 2023-08-16 04:33:51 --> Security Class Initialized
DEBUG - 2023-08-16 04:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:33:51 --> Input Class Initialized
INFO - 2023-08-16 04:33:51 --> Language Class Initialized
INFO - 2023-08-16 04:33:51 --> Loader Class Initialized
INFO - 2023-08-16 04:33:51 --> Helper loaded: url_helper
INFO - 2023-08-16 04:33:51 --> Helper loaded: file_helper
INFO - 2023-08-16 04:33:51 --> Helper loaded: html_helper
INFO - 2023-08-16 04:33:51 --> Helper loaded: text_helper
INFO - 2023-08-16 04:33:51 --> Helper loaded: form_helper
INFO - 2023-08-16 04:33:51 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:33:51 --> Helper loaded: security_helper
INFO - 2023-08-16 04:33:51 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:33:51 --> Database Driver Class Initialized
INFO - 2023-08-16 04:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:33:51 --> Parser Class Initialized
INFO - 2023-08-16 04:33:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:33:51 --> Pagination Class Initialized
INFO - 2023-08-16 04:33:51 --> Form Validation Class Initialized
INFO - 2023-08-16 04:33:51 --> Controller Class Initialized
INFO - 2023-08-16 04:33:51 --> Model Class Initialized
DEBUG - 2023-08-16 04:33:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:33:51 --> Model Class Initialized
DEBUG - 2023-08-16 04:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:33:51 --> Model Class Initialized
INFO - 2023-08-16 04:33:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 04:33:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:33:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:33:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:33:51 --> Model Class Initialized
INFO - 2023-08-16 04:33:51 --> Model Class Initialized
INFO - 2023-08-16 04:33:51 --> Model Class Initialized
INFO - 2023-08-16 04:33:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:33:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:33:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:33:51 --> Final output sent to browser
DEBUG - 2023-08-16 04:33:51 --> Total execution time: 0.0769
ERROR - 2023-08-16 04:33:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:33:52 --> Config Class Initialized
INFO - 2023-08-16 04:33:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:33:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:33:52 --> Utf8 Class Initialized
INFO - 2023-08-16 04:33:52 --> URI Class Initialized
INFO - 2023-08-16 04:33:52 --> Router Class Initialized
INFO - 2023-08-16 04:33:52 --> Output Class Initialized
INFO - 2023-08-16 04:33:52 --> Security Class Initialized
DEBUG - 2023-08-16 04:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:33:52 --> Input Class Initialized
INFO - 2023-08-16 04:33:52 --> Language Class Initialized
INFO - 2023-08-16 04:33:52 --> Loader Class Initialized
INFO - 2023-08-16 04:33:52 --> Helper loaded: url_helper
INFO - 2023-08-16 04:33:52 --> Helper loaded: file_helper
INFO - 2023-08-16 04:33:52 --> Helper loaded: html_helper
INFO - 2023-08-16 04:33:52 --> Helper loaded: text_helper
INFO - 2023-08-16 04:33:52 --> Helper loaded: form_helper
INFO - 2023-08-16 04:33:52 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:33:52 --> Helper loaded: security_helper
INFO - 2023-08-16 04:33:52 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:33:52 --> Database Driver Class Initialized
INFO - 2023-08-16 04:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:33:52 --> Parser Class Initialized
INFO - 2023-08-16 04:33:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:33:52 --> Pagination Class Initialized
INFO - 2023-08-16 04:33:52 --> Form Validation Class Initialized
INFO - 2023-08-16 04:33:52 --> Controller Class Initialized
INFO - 2023-08-16 04:33:52 --> Model Class Initialized
DEBUG - 2023-08-16 04:33:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:33:52 --> Model Class Initialized
DEBUG - 2023-08-16 04:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:33:52 --> Model Class Initialized
INFO - 2023-08-16 04:33:52 --> Final output sent to browser
DEBUG - 2023-08-16 04:33:52 --> Total execution time: 0.0350
ERROR - 2023-08-16 04:48:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:48:30 --> Config Class Initialized
INFO - 2023-08-16 04:48:30 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:48:30 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:48:30 --> Utf8 Class Initialized
INFO - 2023-08-16 04:48:30 --> URI Class Initialized
INFO - 2023-08-16 04:48:30 --> Router Class Initialized
INFO - 2023-08-16 04:48:30 --> Output Class Initialized
INFO - 2023-08-16 04:48:30 --> Security Class Initialized
DEBUG - 2023-08-16 04:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:48:30 --> Input Class Initialized
INFO - 2023-08-16 04:48:30 --> Language Class Initialized
INFO - 2023-08-16 04:48:30 --> Loader Class Initialized
INFO - 2023-08-16 04:48:30 --> Helper loaded: url_helper
INFO - 2023-08-16 04:48:30 --> Helper loaded: file_helper
INFO - 2023-08-16 04:48:30 --> Helper loaded: html_helper
INFO - 2023-08-16 04:48:30 --> Helper loaded: text_helper
INFO - 2023-08-16 04:48:30 --> Helper loaded: form_helper
INFO - 2023-08-16 04:48:30 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:48:30 --> Helper loaded: security_helper
INFO - 2023-08-16 04:48:30 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:48:30 --> Database Driver Class Initialized
INFO - 2023-08-16 04:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:48:30 --> Parser Class Initialized
INFO - 2023-08-16 04:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:48:30 --> Pagination Class Initialized
INFO - 2023-08-16 04:48:30 --> Form Validation Class Initialized
INFO - 2023-08-16 04:48:30 --> Controller Class Initialized
INFO - 2023-08-16 04:48:30 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:30 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:30 --> Model Class Initialized
INFO - 2023-08-16 04:48:30 --> Final output sent to browser
DEBUG - 2023-08-16 04:48:30 --> Total execution time: 0.0408
ERROR - 2023-08-16 04:48:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:48:37 --> Config Class Initialized
INFO - 2023-08-16 04:48:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:48:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:48:37 --> Utf8 Class Initialized
INFO - 2023-08-16 04:48:37 --> URI Class Initialized
INFO - 2023-08-16 04:48:37 --> Router Class Initialized
INFO - 2023-08-16 04:48:37 --> Output Class Initialized
INFO - 2023-08-16 04:48:37 --> Security Class Initialized
DEBUG - 2023-08-16 04:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:48:37 --> Input Class Initialized
INFO - 2023-08-16 04:48:37 --> Language Class Initialized
INFO - 2023-08-16 04:48:37 --> Loader Class Initialized
INFO - 2023-08-16 04:48:37 --> Helper loaded: url_helper
INFO - 2023-08-16 04:48:37 --> Helper loaded: file_helper
INFO - 2023-08-16 04:48:37 --> Helper loaded: html_helper
INFO - 2023-08-16 04:48:37 --> Helper loaded: text_helper
INFO - 2023-08-16 04:48:37 --> Helper loaded: form_helper
INFO - 2023-08-16 04:48:37 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:48:37 --> Helper loaded: security_helper
INFO - 2023-08-16 04:48:37 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:48:37 --> Database Driver Class Initialized
INFO - 2023-08-16 04:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:48:37 --> Parser Class Initialized
INFO - 2023-08-16 04:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:48:37 --> Pagination Class Initialized
INFO - 2023-08-16 04:48:37 --> Form Validation Class Initialized
INFO - 2023-08-16 04:48:37 --> Controller Class Initialized
INFO - 2023-08-16 04:48:37 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:37 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:37 --> Model Class Initialized
INFO - 2023-08-16 04:48:37 --> Final output sent to browser
DEBUG - 2023-08-16 04:48:37 --> Total execution time: 0.0377
ERROR - 2023-08-16 04:48:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:48:46 --> Config Class Initialized
INFO - 2023-08-16 04:48:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:48:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:48:46 --> Utf8 Class Initialized
INFO - 2023-08-16 04:48:46 --> URI Class Initialized
INFO - 2023-08-16 04:48:46 --> Router Class Initialized
INFO - 2023-08-16 04:48:46 --> Output Class Initialized
INFO - 2023-08-16 04:48:46 --> Security Class Initialized
DEBUG - 2023-08-16 04:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:48:46 --> Input Class Initialized
INFO - 2023-08-16 04:48:46 --> Language Class Initialized
INFO - 2023-08-16 04:48:46 --> Loader Class Initialized
INFO - 2023-08-16 04:48:46 --> Helper loaded: url_helper
INFO - 2023-08-16 04:48:46 --> Helper loaded: file_helper
INFO - 2023-08-16 04:48:46 --> Helper loaded: html_helper
INFO - 2023-08-16 04:48:46 --> Helper loaded: text_helper
INFO - 2023-08-16 04:48:46 --> Helper loaded: form_helper
INFO - 2023-08-16 04:48:46 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:48:46 --> Helper loaded: security_helper
INFO - 2023-08-16 04:48:46 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:48:46 --> Database Driver Class Initialized
INFO - 2023-08-16 04:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:48:46 --> Parser Class Initialized
INFO - 2023-08-16 04:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:48:46 --> Pagination Class Initialized
INFO - 2023-08-16 04:48:46 --> Form Validation Class Initialized
INFO - 2023-08-16 04:48:46 --> Controller Class Initialized
INFO - 2023-08-16 04:48:46 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:46 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:46 --> Model Class Initialized
INFO - 2023-08-16 04:48:46 --> Final output sent to browser
DEBUG - 2023-08-16 04:48:46 --> Total execution time: 0.0467
ERROR - 2023-08-16 04:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:48:54 --> Config Class Initialized
INFO - 2023-08-16 04:48:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:48:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:48:54 --> Utf8 Class Initialized
INFO - 2023-08-16 04:48:54 --> URI Class Initialized
INFO - 2023-08-16 04:48:54 --> Router Class Initialized
INFO - 2023-08-16 04:48:54 --> Output Class Initialized
INFO - 2023-08-16 04:48:54 --> Security Class Initialized
DEBUG - 2023-08-16 04:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:48:54 --> Input Class Initialized
INFO - 2023-08-16 04:48:54 --> Language Class Initialized
INFO - 2023-08-16 04:48:54 --> Loader Class Initialized
INFO - 2023-08-16 04:48:54 --> Helper loaded: url_helper
INFO - 2023-08-16 04:48:54 --> Helper loaded: file_helper
INFO - 2023-08-16 04:48:54 --> Helper loaded: html_helper
INFO - 2023-08-16 04:48:54 --> Helper loaded: text_helper
INFO - 2023-08-16 04:48:54 --> Helper loaded: form_helper
INFO - 2023-08-16 04:48:54 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:48:54 --> Helper loaded: security_helper
INFO - 2023-08-16 04:48:54 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:48:54 --> Database Driver Class Initialized
INFO - 2023-08-16 04:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:48:54 --> Parser Class Initialized
INFO - 2023-08-16 04:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:48:54 --> Pagination Class Initialized
INFO - 2023-08-16 04:48:54 --> Form Validation Class Initialized
INFO - 2023-08-16 04:48:54 --> Controller Class Initialized
INFO - 2023-08-16 04:48:54 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:54 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:54 --> Model Class Initialized
INFO - 2023-08-16 04:48:54 --> Final output sent to browser
DEBUG - 2023-08-16 04:48:54 --> Total execution time: 0.0400
ERROR - 2023-08-16 04:48:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:48:55 --> Config Class Initialized
INFO - 2023-08-16 04:48:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:48:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:48:55 --> Utf8 Class Initialized
INFO - 2023-08-16 04:48:55 --> URI Class Initialized
INFO - 2023-08-16 04:48:55 --> Router Class Initialized
INFO - 2023-08-16 04:48:55 --> Output Class Initialized
INFO - 2023-08-16 04:48:55 --> Security Class Initialized
DEBUG - 2023-08-16 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:48:55 --> Input Class Initialized
INFO - 2023-08-16 04:48:55 --> Language Class Initialized
INFO - 2023-08-16 04:48:55 --> Loader Class Initialized
INFO - 2023-08-16 04:48:55 --> Helper loaded: url_helper
INFO - 2023-08-16 04:48:55 --> Helper loaded: file_helper
INFO - 2023-08-16 04:48:55 --> Helper loaded: html_helper
INFO - 2023-08-16 04:48:55 --> Helper loaded: text_helper
INFO - 2023-08-16 04:48:55 --> Helper loaded: form_helper
INFO - 2023-08-16 04:48:55 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:48:55 --> Helper loaded: security_helper
INFO - 2023-08-16 04:48:55 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:48:55 --> Database Driver Class Initialized
INFO - 2023-08-16 04:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:48:55 --> Parser Class Initialized
INFO - 2023-08-16 04:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:48:55 --> Pagination Class Initialized
INFO - 2023-08-16 04:48:55 --> Form Validation Class Initialized
INFO - 2023-08-16 04:48:55 --> Controller Class Initialized
INFO - 2023-08-16 04:48:55 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:55 --> Model Class Initialized
DEBUG - 2023-08-16 04:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:48:55 --> Model Class Initialized
INFO - 2023-08-16 04:48:55 --> Final output sent to browser
DEBUG - 2023-08-16 04:48:55 --> Total execution time: 0.0361
ERROR - 2023-08-16 04:49:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:05 --> Config Class Initialized
INFO - 2023-08-16 04:49:05 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:05 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:05 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:05 --> URI Class Initialized
INFO - 2023-08-16 04:49:05 --> Router Class Initialized
INFO - 2023-08-16 04:49:05 --> Output Class Initialized
INFO - 2023-08-16 04:49:05 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:05 --> Input Class Initialized
INFO - 2023-08-16 04:49:05 --> Language Class Initialized
INFO - 2023-08-16 04:49:05 --> Loader Class Initialized
INFO - 2023-08-16 04:49:05 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:05 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:05 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:05 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:05 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:05 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:05 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:05 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:05 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:05 --> Parser Class Initialized
INFO - 2023-08-16 04:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:05 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:05 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:05 --> Controller Class Initialized
INFO - 2023-08-16 04:49:05 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:05 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:05 --> Model Class Initialized
INFO - 2023-08-16 04:49:05 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:05 --> Total execution time: 0.0368
ERROR - 2023-08-16 04:49:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:07 --> Config Class Initialized
INFO - 2023-08-16 04:49:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:07 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:07 --> URI Class Initialized
INFO - 2023-08-16 04:49:07 --> Router Class Initialized
INFO - 2023-08-16 04:49:07 --> Output Class Initialized
INFO - 2023-08-16 04:49:07 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:07 --> Input Class Initialized
INFO - 2023-08-16 04:49:07 --> Language Class Initialized
INFO - 2023-08-16 04:49:07 --> Loader Class Initialized
INFO - 2023-08-16 04:49:07 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:07 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:07 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:07 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:07 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:07 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:07 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:07 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:07 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:07 --> Parser Class Initialized
INFO - 2023-08-16 04:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:07 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:07 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:07 --> Controller Class Initialized
INFO - 2023-08-16 04:49:07 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:07 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:07 --> Model Class Initialized
INFO - 2023-08-16 04:49:07 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:07 --> Total execution time: 0.0427
ERROR - 2023-08-16 04:49:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:08 --> Config Class Initialized
INFO - 2023-08-16 04:49:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:08 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:08 --> URI Class Initialized
INFO - 2023-08-16 04:49:08 --> Router Class Initialized
INFO - 2023-08-16 04:49:08 --> Output Class Initialized
INFO - 2023-08-16 04:49:08 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:08 --> Input Class Initialized
INFO - 2023-08-16 04:49:08 --> Language Class Initialized
INFO - 2023-08-16 04:49:08 --> Loader Class Initialized
INFO - 2023-08-16 04:49:08 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:08 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:08 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:08 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:08 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:08 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:08 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:08 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:08 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:08 --> Parser Class Initialized
INFO - 2023-08-16 04:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:08 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:08 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:08 --> Controller Class Initialized
INFO - 2023-08-16 04:49:08 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:08 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:08 --> Model Class Initialized
INFO - 2023-08-16 04:49:09 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:09 --> Total execution time: 0.0401
ERROR - 2023-08-16 04:49:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:09 --> Config Class Initialized
INFO - 2023-08-16 04:49:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:09 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:09 --> URI Class Initialized
INFO - 2023-08-16 04:49:09 --> Router Class Initialized
INFO - 2023-08-16 04:49:09 --> Output Class Initialized
INFO - 2023-08-16 04:49:09 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:09 --> Input Class Initialized
INFO - 2023-08-16 04:49:09 --> Language Class Initialized
INFO - 2023-08-16 04:49:09 --> Loader Class Initialized
INFO - 2023-08-16 04:49:09 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:09 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:09 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:09 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:09 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:09 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:09 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:09 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:09 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:09 --> Parser Class Initialized
INFO - 2023-08-16 04:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:09 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:09 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:09 --> Controller Class Initialized
INFO - 2023-08-16 04:49:09 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:09 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:09 --> Model Class Initialized
INFO - 2023-08-16 04:49:09 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:09 --> Total execution time: 0.0404
ERROR - 2023-08-16 04:49:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:13 --> Config Class Initialized
INFO - 2023-08-16 04:49:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:13 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:13 --> URI Class Initialized
INFO - 2023-08-16 04:49:13 --> Router Class Initialized
INFO - 2023-08-16 04:49:13 --> Output Class Initialized
INFO - 2023-08-16 04:49:13 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:13 --> Input Class Initialized
INFO - 2023-08-16 04:49:13 --> Language Class Initialized
INFO - 2023-08-16 04:49:13 --> Loader Class Initialized
INFO - 2023-08-16 04:49:13 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:13 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:13 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:13 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:13 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:13 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:13 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:13 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:13 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:13 --> Parser Class Initialized
INFO - 2023-08-16 04:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:13 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:13 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:13 --> Controller Class Initialized
INFO - 2023-08-16 04:49:13 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:13 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:13 --> Model Class Initialized
INFO - 2023-08-16 04:49:13 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:13 --> Total execution time: 0.0369
ERROR - 2023-08-16 04:49:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:15 --> Config Class Initialized
INFO - 2023-08-16 04:49:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:15 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:15 --> URI Class Initialized
INFO - 2023-08-16 04:49:15 --> Router Class Initialized
INFO - 2023-08-16 04:49:15 --> Output Class Initialized
INFO - 2023-08-16 04:49:15 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:15 --> Input Class Initialized
INFO - 2023-08-16 04:49:15 --> Language Class Initialized
INFO - 2023-08-16 04:49:15 --> Loader Class Initialized
INFO - 2023-08-16 04:49:15 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:15 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:15 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:15 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:15 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:15 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:15 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:15 --> Parser Class Initialized
INFO - 2023-08-16 04:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:15 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:15 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:15 --> Controller Class Initialized
INFO - 2023-08-16 04:49:15 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:15 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:15 --> Model Class Initialized
INFO - 2023-08-16 04:49:15 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:15 --> Total execution time: 0.0378
ERROR - 2023-08-16 04:49:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:29 --> Config Class Initialized
INFO - 2023-08-16 04:49:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:29 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:29 --> URI Class Initialized
INFO - 2023-08-16 04:49:29 --> Router Class Initialized
INFO - 2023-08-16 04:49:29 --> Output Class Initialized
INFO - 2023-08-16 04:49:29 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:29 --> Input Class Initialized
INFO - 2023-08-16 04:49:29 --> Language Class Initialized
INFO - 2023-08-16 04:49:29 --> Loader Class Initialized
INFO - 2023-08-16 04:49:29 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:29 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:29 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:29 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:29 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:29 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:29 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:29 --> Parser Class Initialized
INFO - 2023-08-16 04:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:29 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:29 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:29 --> Controller Class Initialized
INFO - 2023-08-16 04:49:29 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:29 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:29 --> Model Class Initialized
INFO - 2023-08-16 04:49:29 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:29 --> Total execution time: 0.0470
ERROR - 2023-08-16 04:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:49:40 --> Config Class Initialized
INFO - 2023-08-16 04:49:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:49:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:49:40 --> Utf8 Class Initialized
INFO - 2023-08-16 04:49:40 --> URI Class Initialized
INFO - 2023-08-16 04:49:40 --> Router Class Initialized
INFO - 2023-08-16 04:49:40 --> Output Class Initialized
INFO - 2023-08-16 04:49:40 --> Security Class Initialized
DEBUG - 2023-08-16 04:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:49:40 --> Input Class Initialized
INFO - 2023-08-16 04:49:40 --> Language Class Initialized
INFO - 2023-08-16 04:49:40 --> Loader Class Initialized
INFO - 2023-08-16 04:49:40 --> Helper loaded: url_helper
INFO - 2023-08-16 04:49:40 --> Helper loaded: file_helper
INFO - 2023-08-16 04:49:40 --> Helper loaded: html_helper
INFO - 2023-08-16 04:49:40 --> Helper loaded: text_helper
INFO - 2023-08-16 04:49:40 --> Helper loaded: form_helper
INFO - 2023-08-16 04:49:40 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:49:40 --> Helper loaded: security_helper
INFO - 2023-08-16 04:49:40 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:49:40 --> Database Driver Class Initialized
INFO - 2023-08-16 04:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:49:40 --> Parser Class Initialized
INFO - 2023-08-16 04:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:49:40 --> Pagination Class Initialized
INFO - 2023-08-16 04:49:40 --> Form Validation Class Initialized
INFO - 2023-08-16 04:49:40 --> Controller Class Initialized
INFO - 2023-08-16 04:49:40 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:40 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:40 --> Model Class Initialized
DEBUG - 2023-08-16 04:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 04:49:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:49:40 --> Model Class Initialized
INFO - 2023-08-16 04:49:40 --> Model Class Initialized
INFO - 2023-08-16 04:49:40 --> Model Class Initialized
INFO - 2023-08-16 04:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:49:40 --> Final output sent to browser
DEBUG - 2023-08-16 04:49:40 --> Total execution time: 0.1191
ERROR - 2023-08-16 04:50:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:01 --> Config Class Initialized
INFO - 2023-08-16 04:50:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:01 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:01 --> URI Class Initialized
INFO - 2023-08-16 04:50:01 --> Router Class Initialized
INFO - 2023-08-16 04:50:01 --> Output Class Initialized
INFO - 2023-08-16 04:50:01 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:01 --> Input Class Initialized
INFO - 2023-08-16 04:50:01 --> Language Class Initialized
INFO - 2023-08-16 04:50:01 --> Loader Class Initialized
INFO - 2023-08-16 04:50:01 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:01 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:01 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:01 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:01 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:01 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:01 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:01 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:01 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:01 --> Parser Class Initialized
INFO - 2023-08-16 04:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:01 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:01 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:01 --> Controller Class Initialized
INFO - 2023-08-16 04:50:01 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:01 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:01 --> Model Class Initialized
INFO - 2023-08-16 04:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 04:50:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:50:01 --> Model Class Initialized
INFO - 2023-08-16 04:50:01 --> Model Class Initialized
INFO - 2023-08-16 04:50:01 --> Model Class Initialized
INFO - 2023-08-16 04:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:50:01 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:01 --> Total execution time: 0.1098
ERROR - 2023-08-16 04:50:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:03 --> Config Class Initialized
INFO - 2023-08-16 04:50:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:03 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:03 --> URI Class Initialized
INFO - 2023-08-16 04:50:03 --> Router Class Initialized
INFO - 2023-08-16 04:50:03 --> Output Class Initialized
INFO - 2023-08-16 04:50:03 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:03 --> Input Class Initialized
INFO - 2023-08-16 04:50:03 --> Language Class Initialized
INFO - 2023-08-16 04:50:03 --> Loader Class Initialized
INFO - 2023-08-16 04:50:03 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:03 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:03 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:03 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:03 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:03 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:03 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:03 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:03 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:03 --> Parser Class Initialized
INFO - 2023-08-16 04:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:03 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:03 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:03 --> Controller Class Initialized
INFO - 2023-08-16 04:50:03 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:03 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:03 --> Model Class Initialized
INFO - 2023-08-16 04:50:03 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:03 --> Total execution time: 0.0439
ERROR - 2023-08-16 04:50:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:08 --> Config Class Initialized
INFO - 2023-08-16 04:50:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:08 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:08 --> URI Class Initialized
INFO - 2023-08-16 04:50:08 --> Router Class Initialized
INFO - 2023-08-16 04:50:08 --> Output Class Initialized
INFO - 2023-08-16 04:50:08 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:08 --> Input Class Initialized
INFO - 2023-08-16 04:50:08 --> Language Class Initialized
INFO - 2023-08-16 04:50:08 --> Loader Class Initialized
INFO - 2023-08-16 04:50:08 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:08 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:08 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:08 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:08 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:08 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:08 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:08 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:08 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:08 --> Parser Class Initialized
INFO - 2023-08-16 04:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:08 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:08 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:08 --> Controller Class Initialized
INFO - 2023-08-16 04:50:08 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:08 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:08 --> Model Class Initialized
INFO - 2023-08-16 04:50:08 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:08 --> Total execution time: 0.0434
ERROR - 2023-08-16 04:50:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:09 --> Config Class Initialized
INFO - 2023-08-16 04:50:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:09 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:09 --> URI Class Initialized
INFO - 2023-08-16 04:50:09 --> Router Class Initialized
INFO - 2023-08-16 04:50:09 --> Output Class Initialized
INFO - 2023-08-16 04:50:09 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:09 --> Input Class Initialized
INFO - 2023-08-16 04:50:09 --> Language Class Initialized
INFO - 2023-08-16 04:50:09 --> Loader Class Initialized
INFO - 2023-08-16 04:50:09 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:09 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:09 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:09 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:09 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:09 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:09 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:09 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:09 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:09 --> Parser Class Initialized
INFO - 2023-08-16 04:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:09 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:09 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:09 --> Controller Class Initialized
INFO - 2023-08-16 04:50:09 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:09 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:09 --> Model Class Initialized
INFO - 2023-08-16 04:50:09 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:09 --> Total execution time: 0.0424
ERROR - 2023-08-16 04:50:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:16 --> Config Class Initialized
INFO - 2023-08-16 04:50:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:16 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:16 --> URI Class Initialized
INFO - 2023-08-16 04:50:16 --> Router Class Initialized
INFO - 2023-08-16 04:50:16 --> Output Class Initialized
INFO - 2023-08-16 04:50:16 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:16 --> Input Class Initialized
INFO - 2023-08-16 04:50:16 --> Language Class Initialized
INFO - 2023-08-16 04:50:16 --> Loader Class Initialized
INFO - 2023-08-16 04:50:16 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:16 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:16 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:16 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:16 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:16 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:16 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:16 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:16 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:16 --> Parser Class Initialized
INFO - 2023-08-16 04:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:16 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:16 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:16 --> Controller Class Initialized
INFO - 2023-08-16 04:50:16 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:16 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:16 --> Model Class Initialized
INFO - 2023-08-16 04:50:16 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:16 --> Total execution time: 0.0412
ERROR - 2023-08-16 04:50:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:28 --> Config Class Initialized
INFO - 2023-08-16 04:50:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:28 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:28 --> URI Class Initialized
INFO - 2023-08-16 04:50:28 --> Router Class Initialized
INFO - 2023-08-16 04:50:28 --> Output Class Initialized
INFO - 2023-08-16 04:50:28 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:28 --> Input Class Initialized
INFO - 2023-08-16 04:50:28 --> Language Class Initialized
INFO - 2023-08-16 04:50:28 --> Loader Class Initialized
INFO - 2023-08-16 04:50:28 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:28 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:28 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:28 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:28 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:28 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:28 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:28 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:28 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:28 --> Parser Class Initialized
INFO - 2023-08-16 04:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:28 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:28 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:28 --> Controller Class Initialized
INFO - 2023-08-16 04:50:28 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:28 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:28 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 04:50:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:50:28 --> Model Class Initialized
INFO - 2023-08-16 04:50:28 --> Model Class Initialized
INFO - 2023-08-16 04:50:28 --> Model Class Initialized
INFO - 2023-08-16 04:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:50:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:50:28 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:28 --> Total execution time: 0.0778
ERROR - 2023-08-16 04:50:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:41 --> Config Class Initialized
INFO - 2023-08-16 04:50:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:41 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:41 --> URI Class Initialized
INFO - 2023-08-16 04:50:41 --> Router Class Initialized
INFO - 2023-08-16 04:50:41 --> Output Class Initialized
INFO - 2023-08-16 04:50:41 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:41 --> Input Class Initialized
INFO - 2023-08-16 04:50:41 --> Language Class Initialized
INFO - 2023-08-16 04:50:41 --> Loader Class Initialized
INFO - 2023-08-16 04:50:41 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:41 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:41 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:41 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:41 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:41 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:41 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:41 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:41 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:41 --> Parser Class Initialized
INFO - 2023-08-16 04:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:41 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:41 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:41 --> Controller Class Initialized
INFO - 2023-08-16 04:50:41 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:41 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:41 --> Model Class Initialized
INFO - 2023-08-16 04:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 04:50:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 04:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 04:50:41 --> Model Class Initialized
INFO - 2023-08-16 04:50:41 --> Model Class Initialized
INFO - 2023-08-16 04:50:41 --> Model Class Initialized
INFO - 2023-08-16 04:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 04:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 04:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 04:50:42 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:42 --> Total execution time: 0.0822
ERROR - 2023-08-16 04:50:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 04:50:43 --> Config Class Initialized
INFO - 2023-08-16 04:50:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:50:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:50:43 --> Utf8 Class Initialized
INFO - 2023-08-16 04:50:43 --> URI Class Initialized
INFO - 2023-08-16 04:50:43 --> Router Class Initialized
INFO - 2023-08-16 04:50:43 --> Output Class Initialized
INFO - 2023-08-16 04:50:43 --> Security Class Initialized
DEBUG - 2023-08-16 04:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:50:43 --> Input Class Initialized
INFO - 2023-08-16 04:50:43 --> Language Class Initialized
INFO - 2023-08-16 04:50:43 --> Loader Class Initialized
INFO - 2023-08-16 04:50:43 --> Helper loaded: url_helper
INFO - 2023-08-16 04:50:43 --> Helper loaded: file_helper
INFO - 2023-08-16 04:50:43 --> Helper loaded: html_helper
INFO - 2023-08-16 04:50:43 --> Helper loaded: text_helper
INFO - 2023-08-16 04:50:43 --> Helper loaded: form_helper
INFO - 2023-08-16 04:50:43 --> Helper loaded: lang_helper
INFO - 2023-08-16 04:50:43 --> Helper loaded: security_helper
INFO - 2023-08-16 04:50:43 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:50:43 --> Database Driver Class Initialized
INFO - 2023-08-16 04:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:50:43 --> Parser Class Initialized
INFO - 2023-08-16 04:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 04:50:43 --> Pagination Class Initialized
INFO - 2023-08-16 04:50:43 --> Form Validation Class Initialized
INFO - 2023-08-16 04:50:43 --> Controller Class Initialized
INFO - 2023-08-16 04:50:43 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 04:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:43 --> Model Class Initialized
DEBUG - 2023-08-16 04:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 04:50:43 --> Model Class Initialized
INFO - 2023-08-16 04:50:43 --> Final output sent to browser
DEBUG - 2023-08-16 04:50:43 --> Total execution time: 0.0383
ERROR - 2023-08-16 05:38:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:38:29 --> Config Class Initialized
INFO - 2023-08-16 05:38:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:38:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:38:29 --> Utf8 Class Initialized
INFO - 2023-08-16 05:38:29 --> URI Class Initialized
DEBUG - 2023-08-16 05:38:29 --> No URI present. Default controller set.
INFO - 2023-08-16 05:38:29 --> Router Class Initialized
INFO - 2023-08-16 05:38:29 --> Output Class Initialized
INFO - 2023-08-16 05:38:29 --> Security Class Initialized
DEBUG - 2023-08-16 05:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:38:29 --> Input Class Initialized
INFO - 2023-08-16 05:38:29 --> Language Class Initialized
INFO - 2023-08-16 05:38:29 --> Loader Class Initialized
INFO - 2023-08-16 05:38:29 --> Helper loaded: url_helper
INFO - 2023-08-16 05:38:29 --> Helper loaded: file_helper
INFO - 2023-08-16 05:38:29 --> Helper loaded: html_helper
INFO - 2023-08-16 05:38:29 --> Helper loaded: text_helper
INFO - 2023-08-16 05:38:29 --> Helper loaded: form_helper
INFO - 2023-08-16 05:38:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:38:29 --> Helper loaded: security_helper
INFO - 2023-08-16 05:38:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:38:29 --> Database Driver Class Initialized
INFO - 2023-08-16 05:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:38:29 --> Parser Class Initialized
INFO - 2023-08-16 05:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:38:29 --> Pagination Class Initialized
INFO - 2023-08-16 05:38:29 --> Form Validation Class Initialized
INFO - 2023-08-16 05:38:29 --> Controller Class Initialized
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
INFO - 2023-08-16 05:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 05:38:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 05:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 05:38:29 --> Model Class Initialized
INFO - 2023-08-16 05:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 05:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 05:38:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 05:38:29 --> Final output sent to browser
DEBUG - 2023-08-16 05:38:29 --> Total execution time: 0.0920
ERROR - 2023-08-16 05:38:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:38:37 --> Config Class Initialized
INFO - 2023-08-16 05:38:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:38:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:38:37 --> Utf8 Class Initialized
INFO - 2023-08-16 05:38:37 --> URI Class Initialized
INFO - 2023-08-16 05:38:37 --> Router Class Initialized
INFO - 2023-08-16 05:38:37 --> Output Class Initialized
INFO - 2023-08-16 05:38:37 --> Security Class Initialized
DEBUG - 2023-08-16 05:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:38:37 --> Input Class Initialized
INFO - 2023-08-16 05:38:37 --> Language Class Initialized
INFO - 2023-08-16 05:38:37 --> Loader Class Initialized
INFO - 2023-08-16 05:38:37 --> Helper loaded: url_helper
INFO - 2023-08-16 05:38:37 --> Helper loaded: file_helper
INFO - 2023-08-16 05:38:37 --> Helper loaded: html_helper
INFO - 2023-08-16 05:38:37 --> Helper loaded: text_helper
INFO - 2023-08-16 05:38:37 --> Helper loaded: form_helper
INFO - 2023-08-16 05:38:37 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:38:37 --> Helper loaded: security_helper
INFO - 2023-08-16 05:38:37 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:38:37 --> Database Driver Class Initialized
INFO - 2023-08-16 05:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:38:37 --> Parser Class Initialized
INFO - 2023-08-16 05:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:38:37 --> Pagination Class Initialized
INFO - 2023-08-16 05:38:37 --> Form Validation Class Initialized
INFO - 2023-08-16 05:38:37 --> Controller Class Initialized
INFO - 2023-08-16 05:38:37 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:37 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:37 --> Model Class Initialized
INFO - 2023-08-16 05:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 05:38:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 05:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 05:38:37 --> Model Class Initialized
INFO - 2023-08-16 05:38:37 --> Model Class Initialized
INFO - 2023-08-16 05:38:37 --> Model Class Initialized
INFO - 2023-08-16 05:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 05:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 05:38:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 05:38:37 --> Final output sent to browser
DEBUG - 2023-08-16 05:38:37 --> Total execution time: 0.0773
ERROR - 2023-08-16 05:38:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:38:38 --> Config Class Initialized
INFO - 2023-08-16 05:38:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:38:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:38:38 --> Utf8 Class Initialized
INFO - 2023-08-16 05:38:38 --> URI Class Initialized
INFO - 2023-08-16 05:38:38 --> Router Class Initialized
INFO - 2023-08-16 05:38:38 --> Output Class Initialized
INFO - 2023-08-16 05:38:38 --> Security Class Initialized
DEBUG - 2023-08-16 05:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:38:38 --> Input Class Initialized
INFO - 2023-08-16 05:38:38 --> Language Class Initialized
INFO - 2023-08-16 05:38:38 --> Loader Class Initialized
INFO - 2023-08-16 05:38:38 --> Helper loaded: url_helper
INFO - 2023-08-16 05:38:38 --> Helper loaded: file_helper
INFO - 2023-08-16 05:38:38 --> Helper loaded: html_helper
INFO - 2023-08-16 05:38:38 --> Helper loaded: text_helper
INFO - 2023-08-16 05:38:38 --> Helper loaded: form_helper
INFO - 2023-08-16 05:38:38 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:38:38 --> Helper loaded: security_helper
INFO - 2023-08-16 05:38:38 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:38:38 --> Database Driver Class Initialized
INFO - 2023-08-16 05:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:38:38 --> Parser Class Initialized
INFO - 2023-08-16 05:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:38:38 --> Pagination Class Initialized
INFO - 2023-08-16 05:38:38 --> Form Validation Class Initialized
INFO - 2023-08-16 05:38:38 --> Controller Class Initialized
INFO - 2023-08-16 05:38:38 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:38 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:38 --> Model Class Initialized
INFO - 2023-08-16 05:38:38 --> Final output sent to browser
DEBUG - 2023-08-16 05:38:38 --> Total execution time: 0.0368
ERROR - 2023-08-16 05:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:38:42 --> Config Class Initialized
INFO - 2023-08-16 05:38:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:38:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:38:42 --> Utf8 Class Initialized
INFO - 2023-08-16 05:38:42 --> URI Class Initialized
INFO - 2023-08-16 05:38:42 --> Router Class Initialized
INFO - 2023-08-16 05:38:42 --> Output Class Initialized
INFO - 2023-08-16 05:38:42 --> Security Class Initialized
DEBUG - 2023-08-16 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:38:42 --> Input Class Initialized
INFO - 2023-08-16 05:38:42 --> Language Class Initialized
INFO - 2023-08-16 05:38:42 --> Loader Class Initialized
INFO - 2023-08-16 05:38:42 --> Helper loaded: url_helper
INFO - 2023-08-16 05:38:42 --> Helper loaded: file_helper
INFO - 2023-08-16 05:38:42 --> Helper loaded: html_helper
INFO - 2023-08-16 05:38:42 --> Helper loaded: text_helper
INFO - 2023-08-16 05:38:42 --> Helper loaded: form_helper
INFO - 2023-08-16 05:38:42 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:38:42 --> Helper loaded: security_helper
INFO - 2023-08-16 05:38:42 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:38:42 --> Database Driver Class Initialized
INFO - 2023-08-16 05:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:38:42 --> Parser Class Initialized
INFO - 2023-08-16 05:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:38:42 --> Pagination Class Initialized
INFO - 2023-08-16 05:38:42 --> Form Validation Class Initialized
INFO - 2023-08-16 05:38:42 --> Controller Class Initialized
INFO - 2023-08-16 05:38:42 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:42 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:42 --> Model Class Initialized
INFO - 2023-08-16 05:38:42 --> Final output sent to browser
DEBUG - 2023-08-16 05:38:42 --> Total execution time: 0.0369
ERROR - 2023-08-16 05:38:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:38:47 --> Config Class Initialized
INFO - 2023-08-16 05:38:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:38:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:38:47 --> Utf8 Class Initialized
INFO - 2023-08-16 05:38:47 --> URI Class Initialized
INFO - 2023-08-16 05:38:47 --> Router Class Initialized
INFO - 2023-08-16 05:38:47 --> Output Class Initialized
INFO - 2023-08-16 05:38:47 --> Security Class Initialized
DEBUG - 2023-08-16 05:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:38:47 --> Input Class Initialized
INFO - 2023-08-16 05:38:47 --> Language Class Initialized
INFO - 2023-08-16 05:38:47 --> Loader Class Initialized
INFO - 2023-08-16 05:38:47 --> Helper loaded: url_helper
INFO - 2023-08-16 05:38:47 --> Helper loaded: file_helper
INFO - 2023-08-16 05:38:47 --> Helper loaded: html_helper
INFO - 2023-08-16 05:38:47 --> Helper loaded: text_helper
INFO - 2023-08-16 05:38:47 --> Helper loaded: form_helper
INFO - 2023-08-16 05:38:47 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:38:47 --> Helper loaded: security_helper
INFO - 2023-08-16 05:38:47 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:38:47 --> Database Driver Class Initialized
INFO - 2023-08-16 05:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:38:47 --> Parser Class Initialized
INFO - 2023-08-16 05:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:38:47 --> Pagination Class Initialized
INFO - 2023-08-16 05:38:47 --> Form Validation Class Initialized
INFO - 2023-08-16 05:38:47 --> Controller Class Initialized
INFO - 2023-08-16 05:38:47 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:47 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:47 --> Model Class Initialized
INFO - 2023-08-16 05:38:47 --> Final output sent to browser
DEBUG - 2023-08-16 05:38:47 --> Total execution time: 0.0362
ERROR - 2023-08-16 05:38:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:38:54 --> Config Class Initialized
INFO - 2023-08-16 05:38:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:38:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:38:54 --> Utf8 Class Initialized
INFO - 2023-08-16 05:38:54 --> URI Class Initialized
INFO - 2023-08-16 05:38:54 --> Router Class Initialized
INFO - 2023-08-16 05:38:54 --> Output Class Initialized
INFO - 2023-08-16 05:38:54 --> Security Class Initialized
DEBUG - 2023-08-16 05:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:38:54 --> Input Class Initialized
INFO - 2023-08-16 05:38:54 --> Language Class Initialized
INFO - 2023-08-16 05:38:54 --> Loader Class Initialized
INFO - 2023-08-16 05:38:54 --> Helper loaded: url_helper
INFO - 2023-08-16 05:38:54 --> Helper loaded: file_helper
INFO - 2023-08-16 05:38:54 --> Helper loaded: html_helper
INFO - 2023-08-16 05:38:54 --> Helper loaded: text_helper
INFO - 2023-08-16 05:38:54 --> Helper loaded: form_helper
INFO - 2023-08-16 05:38:54 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:38:54 --> Helper loaded: security_helper
INFO - 2023-08-16 05:38:54 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:38:54 --> Database Driver Class Initialized
INFO - 2023-08-16 05:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:38:54 --> Parser Class Initialized
INFO - 2023-08-16 05:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:38:54 --> Pagination Class Initialized
INFO - 2023-08-16 05:38:54 --> Form Validation Class Initialized
INFO - 2023-08-16 05:38:54 --> Controller Class Initialized
INFO - 2023-08-16 05:38:54 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:54 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:54 --> Model Class Initialized
DEBUG - 2023-08-16 05:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 05:38:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 05:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 05:38:54 --> Model Class Initialized
INFO - 2023-08-16 05:38:54 --> Model Class Initialized
INFO - 2023-08-16 05:38:54 --> Model Class Initialized
INFO - 2023-08-16 05:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 05:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 05:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 05:38:54 --> Final output sent to browser
DEBUG - 2023-08-16 05:38:54 --> Total execution time: 0.0817
ERROR - 2023-08-16 05:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:40:03 --> Config Class Initialized
INFO - 2023-08-16 05:40:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:40:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:40:03 --> Utf8 Class Initialized
INFO - 2023-08-16 05:40:03 --> URI Class Initialized
INFO - 2023-08-16 05:40:03 --> Router Class Initialized
INFO - 2023-08-16 05:40:03 --> Output Class Initialized
INFO - 2023-08-16 05:40:03 --> Security Class Initialized
DEBUG - 2023-08-16 05:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:40:03 --> Input Class Initialized
INFO - 2023-08-16 05:40:03 --> Language Class Initialized
INFO - 2023-08-16 05:40:03 --> Loader Class Initialized
INFO - 2023-08-16 05:40:03 --> Helper loaded: url_helper
INFO - 2023-08-16 05:40:03 --> Helper loaded: file_helper
INFO - 2023-08-16 05:40:03 --> Helper loaded: html_helper
INFO - 2023-08-16 05:40:03 --> Helper loaded: text_helper
INFO - 2023-08-16 05:40:03 --> Helper loaded: form_helper
INFO - 2023-08-16 05:40:03 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:40:03 --> Helper loaded: security_helper
INFO - 2023-08-16 05:40:03 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:40:03 --> Database Driver Class Initialized
INFO - 2023-08-16 05:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:40:03 --> Parser Class Initialized
INFO - 2023-08-16 05:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:40:03 --> Pagination Class Initialized
INFO - 2023-08-16 05:40:03 --> Form Validation Class Initialized
INFO - 2023-08-16 05:40:03 --> Controller Class Initialized
INFO - 2023-08-16 05:40:03 --> Model Class Initialized
DEBUG - 2023-08-16 05:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:40:03 --> Model Class Initialized
DEBUG - 2023-08-16 05:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:40:03 --> Model Class Initialized
INFO - 2023-08-16 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 05:40:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 05:40:03 --> Model Class Initialized
INFO - 2023-08-16 05:40:03 --> Model Class Initialized
INFO - 2023-08-16 05:40:03 --> Model Class Initialized
INFO - 2023-08-16 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 05:40:03 --> Final output sent to browser
DEBUG - 2023-08-16 05:40:03 --> Total execution time: 0.0758
ERROR - 2023-08-16 05:40:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 05:40:04 --> Config Class Initialized
INFO - 2023-08-16 05:40:04 --> Hooks Class Initialized
DEBUG - 2023-08-16 05:40:04 --> UTF-8 Support Enabled
INFO - 2023-08-16 05:40:04 --> Utf8 Class Initialized
INFO - 2023-08-16 05:40:04 --> URI Class Initialized
INFO - 2023-08-16 05:40:04 --> Router Class Initialized
INFO - 2023-08-16 05:40:04 --> Output Class Initialized
INFO - 2023-08-16 05:40:04 --> Security Class Initialized
DEBUG - 2023-08-16 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 05:40:04 --> Input Class Initialized
INFO - 2023-08-16 05:40:04 --> Language Class Initialized
INFO - 2023-08-16 05:40:04 --> Loader Class Initialized
INFO - 2023-08-16 05:40:04 --> Helper loaded: url_helper
INFO - 2023-08-16 05:40:04 --> Helper loaded: file_helper
INFO - 2023-08-16 05:40:05 --> Helper loaded: html_helper
INFO - 2023-08-16 05:40:05 --> Helper loaded: text_helper
INFO - 2023-08-16 05:40:05 --> Helper loaded: form_helper
INFO - 2023-08-16 05:40:05 --> Helper loaded: lang_helper
INFO - 2023-08-16 05:40:05 --> Helper loaded: security_helper
INFO - 2023-08-16 05:40:05 --> Helper loaded: cookie_helper
INFO - 2023-08-16 05:40:05 --> Database Driver Class Initialized
INFO - 2023-08-16 05:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 05:40:05 --> Parser Class Initialized
INFO - 2023-08-16 05:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 05:40:05 --> Pagination Class Initialized
INFO - 2023-08-16 05:40:05 --> Form Validation Class Initialized
INFO - 2023-08-16 05:40:05 --> Controller Class Initialized
INFO - 2023-08-16 05:40:05 --> Model Class Initialized
DEBUG - 2023-08-16 05:40:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 05:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:40:05 --> Model Class Initialized
DEBUG - 2023-08-16 05:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 05:40:05 --> Model Class Initialized
INFO - 2023-08-16 05:40:05 --> Final output sent to browser
DEBUG - 2023-08-16 05:40:05 --> Total execution time: 0.0423
ERROR - 2023-08-16 09:19:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:19:24 --> Config Class Initialized
INFO - 2023-08-16 09:19:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:19:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:19:24 --> Utf8 Class Initialized
INFO - 2023-08-16 09:19:24 --> URI Class Initialized
DEBUG - 2023-08-16 09:19:24 --> No URI present. Default controller set.
INFO - 2023-08-16 09:19:24 --> Router Class Initialized
INFO - 2023-08-16 09:19:24 --> Output Class Initialized
INFO - 2023-08-16 09:19:24 --> Security Class Initialized
DEBUG - 2023-08-16 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:19:24 --> Input Class Initialized
INFO - 2023-08-16 09:19:24 --> Language Class Initialized
INFO - 2023-08-16 09:19:24 --> Loader Class Initialized
INFO - 2023-08-16 09:19:24 --> Helper loaded: url_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: file_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: html_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: text_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: form_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: security_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:19:24 --> Database Driver Class Initialized
INFO - 2023-08-16 09:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:19:24 --> Parser Class Initialized
INFO - 2023-08-16 09:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:19:24 --> Pagination Class Initialized
INFO - 2023-08-16 09:19:24 --> Form Validation Class Initialized
INFO - 2023-08-16 09:19:24 --> Controller Class Initialized
INFO - 2023-08-16 09:19:24 --> Model Class Initialized
DEBUG - 2023-08-16 09:19:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 09:19:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:19:24 --> Config Class Initialized
INFO - 2023-08-16 09:19:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:19:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:19:24 --> Utf8 Class Initialized
INFO - 2023-08-16 09:19:24 --> URI Class Initialized
INFO - 2023-08-16 09:19:24 --> Router Class Initialized
INFO - 2023-08-16 09:19:24 --> Output Class Initialized
INFO - 2023-08-16 09:19:24 --> Security Class Initialized
DEBUG - 2023-08-16 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:19:24 --> Input Class Initialized
INFO - 2023-08-16 09:19:24 --> Language Class Initialized
INFO - 2023-08-16 09:19:24 --> Loader Class Initialized
INFO - 2023-08-16 09:19:24 --> Helper loaded: url_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: file_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: html_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: text_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: form_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: security_helper
INFO - 2023-08-16 09:19:24 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:19:24 --> Database Driver Class Initialized
INFO - 2023-08-16 09:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:19:24 --> Parser Class Initialized
INFO - 2023-08-16 09:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:19:24 --> Pagination Class Initialized
INFO - 2023-08-16 09:19:24 --> Form Validation Class Initialized
INFO - 2023-08-16 09:19:24 --> Controller Class Initialized
INFO - 2023-08-16 09:19:24 --> Model Class Initialized
DEBUG - 2023-08-16 09:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:19:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 09:19:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:19:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:19:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:19:24 --> Model Class Initialized
INFO - 2023-08-16 09:19:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:19:24 --> Final output sent to browser
DEBUG - 2023-08-16 09:19:24 --> Total execution time: 0.0342
ERROR - 2023-08-16 09:20:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:20:12 --> Config Class Initialized
INFO - 2023-08-16 09:20:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:20:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:20:12 --> Utf8 Class Initialized
INFO - 2023-08-16 09:20:12 --> URI Class Initialized
INFO - 2023-08-16 09:20:12 --> Router Class Initialized
INFO - 2023-08-16 09:20:12 --> Output Class Initialized
INFO - 2023-08-16 09:20:12 --> Security Class Initialized
DEBUG - 2023-08-16 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:20:12 --> Input Class Initialized
INFO - 2023-08-16 09:20:12 --> Language Class Initialized
INFO - 2023-08-16 09:20:12 --> Loader Class Initialized
INFO - 2023-08-16 09:20:12 --> Helper loaded: url_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: file_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: html_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: text_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: form_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: security_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:20:12 --> Database Driver Class Initialized
INFO - 2023-08-16 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:20:12 --> Parser Class Initialized
INFO - 2023-08-16 09:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:20:12 --> Pagination Class Initialized
INFO - 2023-08-16 09:20:12 --> Form Validation Class Initialized
INFO - 2023-08-16 09:20:12 --> Controller Class Initialized
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
DEBUG - 2023-08-16 09:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
INFO - 2023-08-16 09:20:12 --> Final output sent to browser
DEBUG - 2023-08-16 09:20:12 --> Total execution time: 0.0245
ERROR - 2023-08-16 09:20:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:20:12 --> Config Class Initialized
INFO - 2023-08-16 09:20:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:20:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:20:12 --> Utf8 Class Initialized
INFO - 2023-08-16 09:20:12 --> URI Class Initialized
DEBUG - 2023-08-16 09:20:12 --> No URI present. Default controller set.
INFO - 2023-08-16 09:20:12 --> Router Class Initialized
INFO - 2023-08-16 09:20:12 --> Output Class Initialized
INFO - 2023-08-16 09:20:12 --> Security Class Initialized
DEBUG - 2023-08-16 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:20:12 --> Input Class Initialized
INFO - 2023-08-16 09:20:12 --> Language Class Initialized
INFO - 2023-08-16 09:20:12 --> Loader Class Initialized
INFO - 2023-08-16 09:20:12 --> Helper loaded: url_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: file_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: html_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: text_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: form_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: security_helper
INFO - 2023-08-16 09:20:12 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:20:12 --> Database Driver Class Initialized
INFO - 2023-08-16 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:20:12 --> Parser Class Initialized
INFO - 2023-08-16 09:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:20:12 --> Pagination Class Initialized
INFO - 2023-08-16 09:20:12 --> Form Validation Class Initialized
INFO - 2023-08-16 09:20:12 --> Controller Class Initialized
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
DEBUG - 2023-08-16 09:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
DEBUG - 2023-08-16 09:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
DEBUG - 2023-08-16 09:20:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
INFO - 2023-08-16 09:20:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:20:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:20:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:20:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:20:12 --> Model Class Initialized
INFO - 2023-08-16 09:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:20:13 --> Final output sent to browser
DEBUG - 2023-08-16 09:20:13 --> Total execution time: 0.0868
ERROR - 2023-08-16 09:20:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:20:26 --> Config Class Initialized
INFO - 2023-08-16 09:20:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:20:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:20:26 --> Utf8 Class Initialized
INFO - 2023-08-16 09:20:26 --> URI Class Initialized
INFO - 2023-08-16 09:20:26 --> Router Class Initialized
INFO - 2023-08-16 09:20:26 --> Output Class Initialized
INFO - 2023-08-16 09:20:26 --> Security Class Initialized
DEBUG - 2023-08-16 09:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:20:26 --> Input Class Initialized
INFO - 2023-08-16 09:20:26 --> Language Class Initialized
INFO - 2023-08-16 09:20:26 --> Loader Class Initialized
INFO - 2023-08-16 09:20:26 --> Helper loaded: url_helper
INFO - 2023-08-16 09:20:26 --> Helper loaded: file_helper
INFO - 2023-08-16 09:20:26 --> Helper loaded: html_helper
INFO - 2023-08-16 09:20:26 --> Helper loaded: text_helper
INFO - 2023-08-16 09:20:26 --> Helper loaded: form_helper
INFO - 2023-08-16 09:20:26 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:20:26 --> Helper loaded: security_helper
INFO - 2023-08-16 09:20:26 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:20:26 --> Database Driver Class Initialized
INFO - 2023-08-16 09:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:20:26 --> Parser Class Initialized
INFO - 2023-08-16 09:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:20:26 --> Pagination Class Initialized
INFO - 2023-08-16 09:20:26 --> Form Validation Class Initialized
INFO - 2023-08-16 09:20:26 --> Controller Class Initialized
INFO - 2023-08-16 09:20:26 --> Model Class Initialized
INFO - 2023-08-16 09:20:26 --> Model Class Initialized
INFO - 2023-08-16 09:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-16 09:20:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:20:26 --> Model Class Initialized
INFO - 2023-08-16 09:20:26 --> Model Class Initialized
INFO - 2023-08-16 09:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:20:26 --> Final output sent to browser
DEBUG - 2023-08-16 09:20:26 --> Total execution time: 0.0734
ERROR - 2023-08-16 09:20:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:20:27 --> Config Class Initialized
INFO - 2023-08-16 09:20:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:20:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:20:27 --> Utf8 Class Initialized
INFO - 2023-08-16 09:20:27 --> URI Class Initialized
INFO - 2023-08-16 09:20:27 --> Router Class Initialized
INFO - 2023-08-16 09:20:27 --> Output Class Initialized
INFO - 2023-08-16 09:20:27 --> Security Class Initialized
DEBUG - 2023-08-16 09:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:20:27 --> Input Class Initialized
INFO - 2023-08-16 09:20:27 --> Language Class Initialized
INFO - 2023-08-16 09:20:27 --> Loader Class Initialized
INFO - 2023-08-16 09:20:27 --> Helper loaded: url_helper
INFO - 2023-08-16 09:20:27 --> Helper loaded: file_helper
INFO - 2023-08-16 09:20:27 --> Helper loaded: html_helper
INFO - 2023-08-16 09:20:27 --> Helper loaded: text_helper
INFO - 2023-08-16 09:20:27 --> Helper loaded: form_helper
INFO - 2023-08-16 09:20:27 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:20:27 --> Helper loaded: security_helper
INFO - 2023-08-16 09:20:27 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:20:27 --> Database Driver Class Initialized
INFO - 2023-08-16 09:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:20:27 --> Parser Class Initialized
INFO - 2023-08-16 09:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:20:27 --> Pagination Class Initialized
INFO - 2023-08-16 09:20:27 --> Form Validation Class Initialized
INFO - 2023-08-16 09:20:27 --> Controller Class Initialized
INFO - 2023-08-16 09:20:27 --> Model Class Initialized
INFO - 2023-08-16 09:20:27 --> Model Class Initialized
INFO - 2023-08-16 09:20:27 --> Final output sent to browser
DEBUG - 2023-08-16 09:20:27 --> Total execution time: 0.0310
ERROR - 2023-08-16 09:20:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:20:56 --> Config Class Initialized
INFO - 2023-08-16 09:20:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:20:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:20:56 --> Utf8 Class Initialized
INFO - 2023-08-16 09:20:56 --> URI Class Initialized
INFO - 2023-08-16 09:20:56 --> Router Class Initialized
INFO - 2023-08-16 09:20:56 --> Output Class Initialized
INFO - 2023-08-16 09:20:56 --> Security Class Initialized
DEBUG - 2023-08-16 09:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:20:56 --> Input Class Initialized
INFO - 2023-08-16 09:20:56 --> Language Class Initialized
INFO - 2023-08-16 09:20:56 --> Loader Class Initialized
INFO - 2023-08-16 09:20:56 --> Helper loaded: url_helper
INFO - 2023-08-16 09:20:56 --> Helper loaded: file_helper
INFO - 2023-08-16 09:20:56 --> Helper loaded: html_helper
INFO - 2023-08-16 09:20:56 --> Helper loaded: text_helper
INFO - 2023-08-16 09:20:56 --> Helper loaded: form_helper
INFO - 2023-08-16 09:20:56 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:20:56 --> Helper loaded: security_helper
INFO - 2023-08-16 09:20:56 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:20:56 --> Database Driver Class Initialized
INFO - 2023-08-16 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:20:56 --> Parser Class Initialized
INFO - 2023-08-16 09:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:20:56 --> Pagination Class Initialized
INFO - 2023-08-16 09:20:56 --> Form Validation Class Initialized
INFO - 2023-08-16 09:20:56 --> Controller Class Initialized
INFO - 2023-08-16 09:20:56 --> Model Class Initialized
INFO - 2023-08-16 09:20:56 --> Model Class Initialized
INFO - 2023-08-16 09:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-16 09:20:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:20:56 --> Model Class Initialized
INFO - 2023-08-16 09:20:56 --> Model Class Initialized
INFO - 2023-08-16 09:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:20:56 --> Final output sent to browser
DEBUG - 2023-08-16 09:20:56 --> Total execution time: 0.0789
ERROR - 2023-08-16 09:20:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:20:58 --> Config Class Initialized
INFO - 2023-08-16 09:20:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:20:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:20:58 --> Utf8 Class Initialized
INFO - 2023-08-16 09:20:58 --> URI Class Initialized
INFO - 2023-08-16 09:20:58 --> Router Class Initialized
INFO - 2023-08-16 09:20:58 --> Output Class Initialized
INFO - 2023-08-16 09:20:58 --> Security Class Initialized
DEBUG - 2023-08-16 09:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:20:58 --> Input Class Initialized
INFO - 2023-08-16 09:20:58 --> Language Class Initialized
INFO - 2023-08-16 09:20:58 --> Loader Class Initialized
INFO - 2023-08-16 09:20:58 --> Helper loaded: url_helper
INFO - 2023-08-16 09:20:58 --> Helper loaded: file_helper
INFO - 2023-08-16 09:20:58 --> Helper loaded: html_helper
INFO - 2023-08-16 09:20:58 --> Helper loaded: text_helper
INFO - 2023-08-16 09:20:58 --> Helper loaded: form_helper
INFO - 2023-08-16 09:20:58 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:20:58 --> Helper loaded: security_helper
INFO - 2023-08-16 09:20:58 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:20:58 --> Database Driver Class Initialized
INFO - 2023-08-16 09:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:20:58 --> Parser Class Initialized
INFO - 2023-08-16 09:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:20:58 --> Pagination Class Initialized
INFO - 2023-08-16 09:20:58 --> Form Validation Class Initialized
INFO - 2023-08-16 09:20:58 --> Controller Class Initialized
INFO - 2023-08-16 09:20:58 --> Model Class Initialized
INFO - 2023-08-16 09:20:58 --> Model Class Initialized
INFO - 2023-08-16 09:20:58 --> Final output sent to browser
DEBUG - 2023-08-16 09:20:58 --> Total execution time: 0.0486
ERROR - 2023-08-16 09:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:10 --> Config Class Initialized
INFO - 2023-08-16 09:21:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:10 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:10 --> URI Class Initialized
INFO - 2023-08-16 09:21:10 --> Router Class Initialized
INFO - 2023-08-16 09:21:10 --> Output Class Initialized
INFO - 2023-08-16 09:21:10 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:10 --> Input Class Initialized
INFO - 2023-08-16 09:21:10 --> Language Class Initialized
INFO - 2023-08-16 09:21:10 --> Loader Class Initialized
INFO - 2023-08-16 09:21:10 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:10 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:10 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:10 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:10 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:10 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:10 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:10 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:10 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:10 --> Parser Class Initialized
INFO - 2023-08-16 09:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:10 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:10 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:10 --> Controller Class Initialized
INFO - 2023-08-16 09:21:10 --> Model Class Initialized
INFO - 2023-08-16 09:21:10 --> Model Class Initialized
INFO - 2023-08-16 09:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-16 09:21:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:21:10 --> Model Class Initialized
INFO - 2023-08-16 09:21:10 --> Model Class Initialized
INFO - 2023-08-16 09:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:21:10 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:10 --> Total execution time: 0.0644
ERROR - 2023-08-16 09:21:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:13 --> Config Class Initialized
INFO - 2023-08-16 09:21:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:13 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:13 --> URI Class Initialized
INFO - 2023-08-16 09:21:13 --> Router Class Initialized
INFO - 2023-08-16 09:21:13 --> Output Class Initialized
INFO - 2023-08-16 09:21:13 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:13 --> Input Class Initialized
INFO - 2023-08-16 09:21:13 --> Language Class Initialized
INFO - 2023-08-16 09:21:13 --> Loader Class Initialized
INFO - 2023-08-16 09:21:13 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:13 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:13 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:13 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:13 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:13 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:13 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:13 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:13 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:13 --> Parser Class Initialized
INFO - 2023-08-16 09:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:13 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:13 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:13 --> Controller Class Initialized
INFO - 2023-08-16 09:21:13 --> Model Class Initialized
INFO - 2023-08-16 09:21:13 --> Model Class Initialized
INFO - 2023-08-16 09:21:13 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:13 --> Total execution time: 0.0272
ERROR - 2023-08-16 09:21:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:15 --> Config Class Initialized
INFO - 2023-08-16 09:21:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:15 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:15 --> URI Class Initialized
INFO - 2023-08-16 09:21:15 --> Router Class Initialized
INFO - 2023-08-16 09:21:15 --> Output Class Initialized
INFO - 2023-08-16 09:21:15 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:15 --> Input Class Initialized
INFO - 2023-08-16 09:21:15 --> Language Class Initialized
INFO - 2023-08-16 09:21:15 --> Loader Class Initialized
INFO - 2023-08-16 09:21:15 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:15 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:15 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:15 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:15 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:15 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:15 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:15 --> Parser Class Initialized
INFO - 2023-08-16 09:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:15 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:15 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:15 --> Controller Class Initialized
INFO - 2023-08-16 09:21:15 --> Model Class Initialized
INFO - 2023-08-16 09:21:15 --> Model Class Initialized
INFO - 2023-08-16 09:21:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-16 09:21:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:21:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:21:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:21:15 --> Model Class Initialized
INFO - 2023-08-16 09:21:15 --> Model Class Initialized
INFO - 2023-08-16 09:21:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:21:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:21:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:21:15 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:15 --> Total execution time: 0.0602
ERROR - 2023-08-16 09:21:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:16 --> Config Class Initialized
INFO - 2023-08-16 09:21:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:16 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:16 --> URI Class Initialized
INFO - 2023-08-16 09:21:16 --> Router Class Initialized
INFO - 2023-08-16 09:21:16 --> Output Class Initialized
INFO - 2023-08-16 09:21:16 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:16 --> Input Class Initialized
INFO - 2023-08-16 09:21:16 --> Language Class Initialized
INFO - 2023-08-16 09:21:16 --> Loader Class Initialized
INFO - 2023-08-16 09:21:16 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:16 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:16 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:16 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:16 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:16 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:16 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:16 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:16 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:16 --> Parser Class Initialized
INFO - 2023-08-16 09:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:16 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:16 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:16 --> Controller Class Initialized
INFO - 2023-08-16 09:21:16 --> Model Class Initialized
INFO - 2023-08-16 09:21:16 --> Model Class Initialized
INFO - 2023-08-16 09:21:16 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:16 --> Total execution time: 0.0229
ERROR - 2023-08-16 09:21:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:28 --> Config Class Initialized
INFO - 2023-08-16 09:21:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:28 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:28 --> URI Class Initialized
INFO - 2023-08-16 09:21:28 --> Router Class Initialized
INFO - 2023-08-16 09:21:28 --> Output Class Initialized
INFO - 2023-08-16 09:21:28 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:28 --> Input Class Initialized
INFO - 2023-08-16 09:21:28 --> Language Class Initialized
INFO - 2023-08-16 09:21:28 --> Loader Class Initialized
INFO - 2023-08-16 09:21:28 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:28 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:28 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:28 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:28 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:28 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:28 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:28 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:28 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:28 --> Parser Class Initialized
INFO - 2023-08-16 09:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:28 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:28 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:28 --> Controller Class Initialized
INFO - 2023-08-16 09:21:28 --> Model Class Initialized
INFO - 2023-08-16 09:21:28 --> Model Class Initialized
INFO - 2023-08-16 09:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-16 09:21:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:21:28 --> Model Class Initialized
INFO - 2023-08-16 09:21:28 --> Model Class Initialized
INFO - 2023-08-16 09:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:21:28 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:28 --> Total execution time: 0.0709
ERROR - 2023-08-16 09:21:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:29 --> Config Class Initialized
INFO - 2023-08-16 09:21:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:29 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:29 --> URI Class Initialized
INFO - 2023-08-16 09:21:29 --> Router Class Initialized
INFO - 2023-08-16 09:21:29 --> Output Class Initialized
INFO - 2023-08-16 09:21:29 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:29 --> Input Class Initialized
INFO - 2023-08-16 09:21:29 --> Language Class Initialized
INFO - 2023-08-16 09:21:29 --> Loader Class Initialized
INFO - 2023-08-16 09:21:29 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:29 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:29 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:29 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:29 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:29 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:29 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:29 --> Parser Class Initialized
INFO - 2023-08-16 09:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:29 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:29 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:29 --> Controller Class Initialized
INFO - 2023-08-16 09:21:29 --> Model Class Initialized
INFO - 2023-08-16 09:21:29 --> Model Class Initialized
INFO - 2023-08-16 09:21:29 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:29 --> Total execution time: 0.0526
ERROR - 2023-08-16 09:21:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:58 --> Config Class Initialized
INFO - 2023-08-16 09:21:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:58 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:58 --> URI Class Initialized
INFO - 2023-08-16 09:21:58 --> Router Class Initialized
INFO - 2023-08-16 09:21:58 --> Output Class Initialized
INFO - 2023-08-16 09:21:58 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:58 --> Input Class Initialized
INFO - 2023-08-16 09:21:58 --> Language Class Initialized
INFO - 2023-08-16 09:21:58 --> Loader Class Initialized
INFO - 2023-08-16 09:21:58 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:58 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:58 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:58 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:58 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:58 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:58 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:58 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:58 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:58 --> Parser Class Initialized
INFO - 2023-08-16 09:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:58 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:58 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:58 --> Controller Class Initialized
INFO - 2023-08-16 09:21:58 --> Model Class Initialized
INFO - 2023-08-16 09:21:58 --> Model Class Initialized
INFO - 2023-08-16 09:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-16 09:21:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:21:58 --> Model Class Initialized
INFO - 2023-08-16 09:21:58 --> Model Class Initialized
INFO - 2023-08-16 09:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:21:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:21:58 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:58 --> Total execution time: 0.0737
ERROR - 2023-08-16 09:21:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:21:59 --> Config Class Initialized
INFO - 2023-08-16 09:21:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:21:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:21:59 --> Utf8 Class Initialized
INFO - 2023-08-16 09:21:59 --> URI Class Initialized
INFO - 2023-08-16 09:21:59 --> Router Class Initialized
INFO - 2023-08-16 09:21:59 --> Output Class Initialized
INFO - 2023-08-16 09:21:59 --> Security Class Initialized
DEBUG - 2023-08-16 09:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:21:59 --> Input Class Initialized
INFO - 2023-08-16 09:21:59 --> Language Class Initialized
INFO - 2023-08-16 09:21:59 --> Loader Class Initialized
INFO - 2023-08-16 09:21:59 --> Helper loaded: url_helper
INFO - 2023-08-16 09:21:59 --> Helper loaded: file_helper
INFO - 2023-08-16 09:21:59 --> Helper loaded: html_helper
INFO - 2023-08-16 09:21:59 --> Helper loaded: text_helper
INFO - 2023-08-16 09:21:59 --> Helper loaded: form_helper
INFO - 2023-08-16 09:21:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:21:59 --> Helper loaded: security_helper
INFO - 2023-08-16 09:21:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:21:59 --> Database Driver Class Initialized
INFO - 2023-08-16 09:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:21:59 --> Parser Class Initialized
INFO - 2023-08-16 09:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:21:59 --> Pagination Class Initialized
INFO - 2023-08-16 09:21:59 --> Form Validation Class Initialized
INFO - 2023-08-16 09:21:59 --> Controller Class Initialized
INFO - 2023-08-16 09:21:59 --> Model Class Initialized
INFO - 2023-08-16 09:21:59 --> Model Class Initialized
INFO - 2023-08-16 09:21:59 --> Final output sent to browser
DEBUG - 2023-08-16 09:21:59 --> Total execution time: 0.0227
ERROR - 2023-08-16 09:22:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:22:01 --> Config Class Initialized
INFO - 2023-08-16 09:22:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:22:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:22:01 --> Utf8 Class Initialized
INFO - 2023-08-16 09:22:01 --> URI Class Initialized
DEBUG - 2023-08-16 09:22:01 --> No URI present. Default controller set.
INFO - 2023-08-16 09:22:01 --> Router Class Initialized
INFO - 2023-08-16 09:22:01 --> Output Class Initialized
INFO - 2023-08-16 09:22:01 --> Security Class Initialized
DEBUG - 2023-08-16 09:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:22:01 --> Input Class Initialized
INFO - 2023-08-16 09:22:01 --> Language Class Initialized
INFO - 2023-08-16 09:22:01 --> Loader Class Initialized
INFO - 2023-08-16 09:22:01 --> Helper loaded: url_helper
INFO - 2023-08-16 09:22:01 --> Helper loaded: file_helper
INFO - 2023-08-16 09:22:01 --> Helper loaded: html_helper
INFO - 2023-08-16 09:22:01 --> Helper loaded: text_helper
INFO - 2023-08-16 09:22:01 --> Helper loaded: form_helper
INFO - 2023-08-16 09:22:01 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:22:01 --> Helper loaded: security_helper
INFO - 2023-08-16 09:22:01 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:22:01 --> Database Driver Class Initialized
INFO - 2023-08-16 09:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:22:01 --> Parser Class Initialized
INFO - 2023-08-16 09:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:22:01 --> Pagination Class Initialized
INFO - 2023-08-16 09:22:01 --> Form Validation Class Initialized
INFO - 2023-08-16 09:22:01 --> Controller Class Initialized
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
INFO - 2023-08-16 09:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:22:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:22:01 --> Model Class Initialized
INFO - 2023-08-16 09:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:22:01 --> Final output sent to browser
DEBUG - 2023-08-16 09:22:01 --> Total execution time: 0.0977
ERROR - 2023-08-16 09:22:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:22:26 --> Config Class Initialized
INFO - 2023-08-16 09:22:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:22:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:22:26 --> Utf8 Class Initialized
INFO - 2023-08-16 09:22:26 --> URI Class Initialized
INFO - 2023-08-16 09:22:26 --> Router Class Initialized
INFO - 2023-08-16 09:22:26 --> Output Class Initialized
INFO - 2023-08-16 09:22:26 --> Security Class Initialized
DEBUG - 2023-08-16 09:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:22:26 --> Input Class Initialized
INFO - 2023-08-16 09:22:26 --> Language Class Initialized
INFO - 2023-08-16 09:22:26 --> Loader Class Initialized
INFO - 2023-08-16 09:22:26 --> Helper loaded: url_helper
INFO - 2023-08-16 09:22:26 --> Helper loaded: file_helper
INFO - 2023-08-16 09:22:26 --> Helper loaded: html_helper
INFO - 2023-08-16 09:22:26 --> Helper loaded: text_helper
INFO - 2023-08-16 09:22:26 --> Helper loaded: form_helper
INFO - 2023-08-16 09:22:26 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:22:26 --> Helper loaded: security_helper
INFO - 2023-08-16 09:22:26 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:22:26 --> Database Driver Class Initialized
INFO - 2023-08-16 09:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:22:26 --> Parser Class Initialized
INFO - 2023-08-16 09:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:22:26 --> Pagination Class Initialized
INFO - 2023-08-16 09:22:26 --> Form Validation Class Initialized
INFO - 2023-08-16 09:22:26 --> Controller Class Initialized
INFO - 2023-08-16 09:22:26 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:26 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:26 --> Model Class Initialized
INFO - 2023-08-16 09:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-16 09:22:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:22:26 --> Model Class Initialized
INFO - 2023-08-16 09:22:26 --> Model Class Initialized
INFO - 2023-08-16 09:22:26 --> Model Class Initialized
INFO - 2023-08-16 09:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:22:26 --> Final output sent to browser
DEBUG - 2023-08-16 09:22:26 --> Total execution time: 0.0833
ERROR - 2023-08-16 09:22:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:22:27 --> Config Class Initialized
INFO - 2023-08-16 09:22:27 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:22:27 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:22:27 --> Utf8 Class Initialized
INFO - 2023-08-16 09:22:27 --> URI Class Initialized
INFO - 2023-08-16 09:22:27 --> Router Class Initialized
INFO - 2023-08-16 09:22:27 --> Output Class Initialized
INFO - 2023-08-16 09:22:27 --> Security Class Initialized
DEBUG - 2023-08-16 09:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:22:27 --> Input Class Initialized
INFO - 2023-08-16 09:22:27 --> Language Class Initialized
INFO - 2023-08-16 09:22:27 --> Loader Class Initialized
INFO - 2023-08-16 09:22:27 --> Helper loaded: url_helper
INFO - 2023-08-16 09:22:27 --> Helper loaded: file_helper
INFO - 2023-08-16 09:22:27 --> Helper loaded: html_helper
INFO - 2023-08-16 09:22:27 --> Helper loaded: text_helper
INFO - 2023-08-16 09:22:27 --> Helper loaded: form_helper
INFO - 2023-08-16 09:22:27 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:22:27 --> Helper loaded: security_helper
INFO - 2023-08-16 09:22:27 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:22:27 --> Database Driver Class Initialized
INFO - 2023-08-16 09:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:22:27 --> Parser Class Initialized
INFO - 2023-08-16 09:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:22:27 --> Pagination Class Initialized
INFO - 2023-08-16 09:22:27 --> Form Validation Class Initialized
INFO - 2023-08-16 09:22:27 --> Controller Class Initialized
INFO - 2023-08-16 09:22:27 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:27 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:27 --> Model Class Initialized
INFO - 2023-08-16 09:22:27 --> Final output sent to browser
DEBUG - 2023-08-16 09:22:27 --> Total execution time: 0.0203
ERROR - 2023-08-16 09:22:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:22:41 --> Config Class Initialized
INFO - 2023-08-16 09:22:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:22:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:22:41 --> Utf8 Class Initialized
INFO - 2023-08-16 09:22:41 --> URI Class Initialized
INFO - 2023-08-16 09:22:41 --> Router Class Initialized
INFO - 2023-08-16 09:22:41 --> Output Class Initialized
INFO - 2023-08-16 09:22:41 --> Security Class Initialized
DEBUG - 2023-08-16 09:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:22:41 --> Input Class Initialized
INFO - 2023-08-16 09:22:41 --> Language Class Initialized
INFO - 2023-08-16 09:22:41 --> Loader Class Initialized
INFO - 2023-08-16 09:22:41 --> Helper loaded: url_helper
INFO - 2023-08-16 09:22:41 --> Helper loaded: file_helper
INFO - 2023-08-16 09:22:41 --> Helper loaded: html_helper
INFO - 2023-08-16 09:22:41 --> Helper loaded: text_helper
INFO - 2023-08-16 09:22:41 --> Helper loaded: form_helper
INFO - 2023-08-16 09:22:41 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:22:41 --> Helper loaded: security_helper
INFO - 2023-08-16 09:22:41 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:22:41 --> Database Driver Class Initialized
INFO - 2023-08-16 09:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:22:41 --> Parser Class Initialized
INFO - 2023-08-16 09:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:22:41 --> Pagination Class Initialized
INFO - 2023-08-16 09:22:41 --> Form Validation Class Initialized
INFO - 2023-08-16 09:22:41 --> Controller Class Initialized
INFO - 2023-08-16 09:22:41 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:41 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:41 --> Model Class Initialized
INFO - 2023-08-16 09:22:41 --> Final output sent to browser
DEBUG - 2023-08-16 09:22:41 --> Total execution time: 0.0219
ERROR - 2023-08-16 09:22:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:22:58 --> Config Class Initialized
INFO - 2023-08-16 09:22:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:22:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:22:58 --> Utf8 Class Initialized
INFO - 2023-08-16 09:22:58 --> URI Class Initialized
INFO - 2023-08-16 09:22:58 --> Router Class Initialized
INFO - 2023-08-16 09:22:58 --> Output Class Initialized
INFO - 2023-08-16 09:22:58 --> Security Class Initialized
DEBUG - 2023-08-16 09:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:22:58 --> Input Class Initialized
INFO - 2023-08-16 09:22:58 --> Language Class Initialized
INFO - 2023-08-16 09:22:58 --> Loader Class Initialized
INFO - 2023-08-16 09:22:58 --> Helper loaded: url_helper
INFO - 2023-08-16 09:22:58 --> Helper loaded: file_helper
INFO - 2023-08-16 09:22:58 --> Helper loaded: html_helper
INFO - 2023-08-16 09:22:58 --> Helper loaded: text_helper
INFO - 2023-08-16 09:22:58 --> Helper loaded: form_helper
INFO - 2023-08-16 09:22:58 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:22:58 --> Helper loaded: security_helper
INFO - 2023-08-16 09:22:58 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:22:58 --> Database Driver Class Initialized
INFO - 2023-08-16 09:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:22:58 --> Parser Class Initialized
INFO - 2023-08-16 09:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:22:58 --> Pagination Class Initialized
INFO - 2023-08-16 09:22:58 --> Form Validation Class Initialized
INFO - 2023-08-16 09:22:58 --> Controller Class Initialized
INFO - 2023-08-16 09:22:58 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:58 --> Model Class Initialized
DEBUG - 2023-08-16 09:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:22:58 --> Model Class Initialized
INFO - 2023-08-16 09:22:58 --> Final output sent to browser
DEBUG - 2023-08-16 09:22:58 --> Total execution time: 0.0223
ERROR - 2023-08-16 09:23:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:23:03 --> Config Class Initialized
INFO - 2023-08-16 09:23:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:23:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:23:03 --> Utf8 Class Initialized
INFO - 2023-08-16 09:23:03 --> URI Class Initialized
DEBUG - 2023-08-16 09:23:03 --> No URI present. Default controller set.
INFO - 2023-08-16 09:23:03 --> Router Class Initialized
INFO - 2023-08-16 09:23:03 --> Output Class Initialized
INFO - 2023-08-16 09:23:03 --> Security Class Initialized
DEBUG - 2023-08-16 09:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:23:03 --> Input Class Initialized
INFO - 2023-08-16 09:23:03 --> Language Class Initialized
INFO - 2023-08-16 09:23:03 --> Loader Class Initialized
INFO - 2023-08-16 09:23:03 --> Helper loaded: url_helper
INFO - 2023-08-16 09:23:03 --> Helper loaded: file_helper
INFO - 2023-08-16 09:23:03 --> Helper loaded: html_helper
INFO - 2023-08-16 09:23:03 --> Helper loaded: text_helper
INFO - 2023-08-16 09:23:03 --> Helper loaded: form_helper
INFO - 2023-08-16 09:23:03 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:23:03 --> Helper loaded: security_helper
INFO - 2023-08-16 09:23:03 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:23:03 --> Database Driver Class Initialized
INFO - 2023-08-16 09:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:23:03 --> Parser Class Initialized
INFO - 2023-08-16 09:23:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:23:03 --> Pagination Class Initialized
INFO - 2023-08-16 09:23:03 --> Form Validation Class Initialized
INFO - 2023-08-16 09:23:03 --> Controller Class Initialized
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
INFO - 2023-08-16 09:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:23:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:23:03 --> Model Class Initialized
INFO - 2023-08-16 09:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:23:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:23:03 --> Final output sent to browser
DEBUG - 2023-08-16 09:23:03 --> Total execution time: 0.0947
ERROR - 2023-08-16 09:23:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:23:10 --> Config Class Initialized
INFO - 2023-08-16 09:23:10 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:23:10 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:23:10 --> Utf8 Class Initialized
INFO - 2023-08-16 09:23:10 --> URI Class Initialized
DEBUG - 2023-08-16 09:23:10 --> No URI present. Default controller set.
INFO - 2023-08-16 09:23:10 --> Router Class Initialized
INFO - 2023-08-16 09:23:10 --> Output Class Initialized
INFO - 2023-08-16 09:23:10 --> Security Class Initialized
DEBUG - 2023-08-16 09:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:23:10 --> Input Class Initialized
INFO - 2023-08-16 09:23:10 --> Language Class Initialized
INFO - 2023-08-16 09:23:10 --> Loader Class Initialized
INFO - 2023-08-16 09:23:10 --> Helper loaded: url_helper
INFO - 2023-08-16 09:23:10 --> Helper loaded: file_helper
INFO - 2023-08-16 09:23:10 --> Helper loaded: html_helper
INFO - 2023-08-16 09:23:10 --> Helper loaded: text_helper
INFO - 2023-08-16 09:23:10 --> Helper loaded: form_helper
INFO - 2023-08-16 09:23:10 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:23:10 --> Helper loaded: security_helper
INFO - 2023-08-16 09:23:10 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:23:10 --> Database Driver Class Initialized
INFO - 2023-08-16 09:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:23:10 --> Parser Class Initialized
INFO - 2023-08-16 09:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:23:10 --> Pagination Class Initialized
INFO - 2023-08-16 09:23:10 --> Form Validation Class Initialized
INFO - 2023-08-16 09:23:10 --> Controller Class Initialized
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
INFO - 2023-08-16 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:23:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:23:10 --> Model Class Initialized
INFO - 2023-08-16 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:23:10 --> Final output sent to browser
DEBUG - 2023-08-16 09:23:10 --> Total execution time: 0.0875
ERROR - 2023-08-16 09:23:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:23:23 --> Config Class Initialized
INFO - 2023-08-16 09:23:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:23:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:23:23 --> Utf8 Class Initialized
INFO - 2023-08-16 09:23:23 --> URI Class Initialized
DEBUG - 2023-08-16 09:23:23 --> No URI present. Default controller set.
INFO - 2023-08-16 09:23:23 --> Router Class Initialized
INFO - 2023-08-16 09:23:23 --> Output Class Initialized
INFO - 2023-08-16 09:23:23 --> Security Class Initialized
DEBUG - 2023-08-16 09:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:23:23 --> Input Class Initialized
INFO - 2023-08-16 09:23:23 --> Language Class Initialized
INFO - 2023-08-16 09:23:23 --> Loader Class Initialized
INFO - 2023-08-16 09:23:23 --> Helper loaded: url_helper
INFO - 2023-08-16 09:23:23 --> Helper loaded: file_helper
INFO - 2023-08-16 09:23:23 --> Helper loaded: html_helper
INFO - 2023-08-16 09:23:23 --> Helper loaded: text_helper
INFO - 2023-08-16 09:23:23 --> Helper loaded: form_helper
INFO - 2023-08-16 09:23:23 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:23:23 --> Helper loaded: security_helper
INFO - 2023-08-16 09:23:23 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:23:23 --> Database Driver Class Initialized
INFO - 2023-08-16 09:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:23:23 --> Parser Class Initialized
INFO - 2023-08-16 09:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:23:23 --> Pagination Class Initialized
INFO - 2023-08-16 09:23:23 --> Form Validation Class Initialized
INFO - 2023-08-16 09:23:23 --> Controller Class Initialized
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
INFO - 2023-08-16 09:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:23:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:23:23 --> Model Class Initialized
INFO - 2023-08-16 09:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:23:23 --> Final output sent to browser
DEBUG - 2023-08-16 09:23:23 --> Total execution time: 0.0858
ERROR - 2023-08-16 09:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:23:43 --> Config Class Initialized
INFO - 2023-08-16 09:23:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:23:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:23:43 --> Utf8 Class Initialized
INFO - 2023-08-16 09:23:43 --> URI Class Initialized
INFO - 2023-08-16 09:23:43 --> Router Class Initialized
INFO - 2023-08-16 09:23:43 --> Output Class Initialized
INFO - 2023-08-16 09:23:43 --> Security Class Initialized
DEBUG - 2023-08-16 09:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:23:43 --> Input Class Initialized
INFO - 2023-08-16 09:23:43 --> Language Class Initialized
INFO - 2023-08-16 09:23:43 --> Loader Class Initialized
INFO - 2023-08-16 09:23:43 --> Helper loaded: url_helper
INFO - 2023-08-16 09:23:43 --> Helper loaded: file_helper
INFO - 2023-08-16 09:23:43 --> Helper loaded: html_helper
INFO - 2023-08-16 09:23:43 --> Helper loaded: text_helper
INFO - 2023-08-16 09:23:43 --> Helper loaded: form_helper
INFO - 2023-08-16 09:23:43 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:23:43 --> Helper loaded: security_helper
INFO - 2023-08-16 09:23:43 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:23:43 --> Database Driver Class Initialized
INFO - 2023-08-16 09:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:23:43 --> Parser Class Initialized
INFO - 2023-08-16 09:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:23:43 --> Pagination Class Initialized
INFO - 2023-08-16 09:23:43 --> Form Validation Class Initialized
INFO - 2023-08-16 09:23:43 --> Controller Class Initialized
INFO - 2023-08-16 09:23:43 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:43 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-08-16 09:23:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:23:43 --> Model Class Initialized
INFO - 2023-08-16 09:23:43 --> Model Class Initialized
INFO - 2023-08-16 09:23:43 --> Model Class Initialized
INFO - 2023-08-16 09:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:23:43 --> Final output sent to browser
DEBUG - 2023-08-16 09:23:43 --> Total execution time: 0.0699
ERROR - 2023-08-16 09:23:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:23:51 --> Config Class Initialized
INFO - 2023-08-16 09:23:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:23:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:23:51 --> Utf8 Class Initialized
INFO - 2023-08-16 09:23:51 --> URI Class Initialized
DEBUG - 2023-08-16 09:23:51 --> No URI present. Default controller set.
INFO - 2023-08-16 09:23:51 --> Router Class Initialized
INFO - 2023-08-16 09:23:51 --> Output Class Initialized
INFO - 2023-08-16 09:23:51 --> Security Class Initialized
DEBUG - 2023-08-16 09:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:23:51 --> Input Class Initialized
INFO - 2023-08-16 09:23:51 --> Language Class Initialized
INFO - 2023-08-16 09:23:51 --> Loader Class Initialized
INFO - 2023-08-16 09:23:51 --> Helper loaded: url_helper
INFO - 2023-08-16 09:23:51 --> Helper loaded: file_helper
INFO - 2023-08-16 09:23:51 --> Helper loaded: html_helper
INFO - 2023-08-16 09:23:51 --> Helper loaded: text_helper
INFO - 2023-08-16 09:23:51 --> Helper loaded: form_helper
INFO - 2023-08-16 09:23:51 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:23:51 --> Helper loaded: security_helper
INFO - 2023-08-16 09:23:51 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:23:51 --> Database Driver Class Initialized
INFO - 2023-08-16 09:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:23:51 --> Parser Class Initialized
INFO - 2023-08-16 09:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:23:51 --> Pagination Class Initialized
INFO - 2023-08-16 09:23:51 --> Form Validation Class Initialized
INFO - 2023-08-16 09:23:51 --> Controller Class Initialized
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
INFO - 2023-08-16 09:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:23:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:23:51 --> Model Class Initialized
INFO - 2023-08-16 09:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:23:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:23:51 --> Final output sent to browser
DEBUG - 2023-08-16 09:23:51 --> Total execution time: 0.0785
ERROR - 2023-08-16 09:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:23:59 --> Config Class Initialized
INFO - 2023-08-16 09:23:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:23:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:23:59 --> Utf8 Class Initialized
INFO - 2023-08-16 09:23:59 --> URI Class Initialized
INFO - 2023-08-16 09:23:59 --> Router Class Initialized
INFO - 2023-08-16 09:23:59 --> Output Class Initialized
INFO - 2023-08-16 09:23:59 --> Security Class Initialized
DEBUG - 2023-08-16 09:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:23:59 --> Input Class Initialized
INFO - 2023-08-16 09:23:59 --> Language Class Initialized
INFO - 2023-08-16 09:23:59 --> Loader Class Initialized
INFO - 2023-08-16 09:23:59 --> Helper loaded: url_helper
INFO - 2023-08-16 09:23:59 --> Helper loaded: file_helper
INFO - 2023-08-16 09:23:59 --> Helper loaded: html_helper
INFO - 2023-08-16 09:23:59 --> Helper loaded: text_helper
INFO - 2023-08-16 09:23:59 --> Helper loaded: form_helper
INFO - 2023-08-16 09:23:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:23:59 --> Helper loaded: security_helper
INFO - 2023-08-16 09:23:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:23:59 --> Database Driver Class Initialized
INFO - 2023-08-16 09:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:23:59 --> Parser Class Initialized
INFO - 2023-08-16 09:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:23:59 --> Pagination Class Initialized
INFO - 2023-08-16 09:23:59 --> Form Validation Class Initialized
INFO - 2023-08-16 09:23:59 --> Controller Class Initialized
INFO - 2023-08-16 09:23:59 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:59 --> Model Class Initialized
DEBUG - 2023-08-16 09:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:59 --> Model Class Initialized
INFO - 2023-08-16 09:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:23:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:23:59 --> Model Class Initialized
INFO - 2023-08-16 09:23:59 --> Model Class Initialized
INFO - 2023-08-16 09:23:59 --> Model Class Initialized
INFO - 2023-08-16 09:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:23:59 --> Final output sent to browser
DEBUG - 2023-08-16 09:23:59 --> Total execution time: 0.0818
ERROR - 2023-08-16 09:24:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:24:02 --> Config Class Initialized
INFO - 2023-08-16 09:24:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:24:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:24:02 --> Utf8 Class Initialized
INFO - 2023-08-16 09:24:02 --> URI Class Initialized
INFO - 2023-08-16 09:24:02 --> Router Class Initialized
INFO - 2023-08-16 09:24:02 --> Output Class Initialized
INFO - 2023-08-16 09:24:02 --> Security Class Initialized
DEBUG - 2023-08-16 09:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:24:02 --> Input Class Initialized
INFO - 2023-08-16 09:24:02 --> Language Class Initialized
INFO - 2023-08-16 09:24:02 --> Loader Class Initialized
INFO - 2023-08-16 09:24:02 --> Helper loaded: url_helper
INFO - 2023-08-16 09:24:02 --> Helper loaded: file_helper
INFO - 2023-08-16 09:24:02 --> Helper loaded: html_helper
INFO - 2023-08-16 09:24:02 --> Helper loaded: text_helper
INFO - 2023-08-16 09:24:02 --> Helper loaded: form_helper
INFO - 2023-08-16 09:24:02 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:24:02 --> Helper loaded: security_helper
INFO - 2023-08-16 09:24:02 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:24:02 --> Database Driver Class Initialized
INFO - 2023-08-16 09:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:24:02 --> Parser Class Initialized
INFO - 2023-08-16 09:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:24:02 --> Pagination Class Initialized
INFO - 2023-08-16 09:24:02 --> Form Validation Class Initialized
INFO - 2023-08-16 09:24:02 --> Controller Class Initialized
INFO - 2023-08-16 09:24:02 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:02 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:02 --> Model Class Initialized
INFO - 2023-08-16 09:24:02 --> Final output sent to browser
DEBUG - 2023-08-16 09:24:02 --> Total execution time: 0.0277
ERROR - 2023-08-16 09:24:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:24:18 --> Config Class Initialized
INFO - 2023-08-16 09:24:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:24:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:24:18 --> Utf8 Class Initialized
INFO - 2023-08-16 09:24:18 --> URI Class Initialized
INFO - 2023-08-16 09:24:18 --> Router Class Initialized
INFO - 2023-08-16 09:24:18 --> Output Class Initialized
INFO - 2023-08-16 09:24:18 --> Security Class Initialized
DEBUG - 2023-08-16 09:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:24:18 --> Input Class Initialized
INFO - 2023-08-16 09:24:18 --> Language Class Initialized
INFO - 2023-08-16 09:24:18 --> Loader Class Initialized
INFO - 2023-08-16 09:24:18 --> Helper loaded: url_helper
INFO - 2023-08-16 09:24:18 --> Helper loaded: file_helper
INFO - 2023-08-16 09:24:18 --> Helper loaded: html_helper
INFO - 2023-08-16 09:24:18 --> Helper loaded: text_helper
INFO - 2023-08-16 09:24:18 --> Helper loaded: form_helper
INFO - 2023-08-16 09:24:18 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:24:18 --> Helper loaded: security_helper
INFO - 2023-08-16 09:24:18 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:24:18 --> Database Driver Class Initialized
INFO - 2023-08-16 09:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:24:18 --> Parser Class Initialized
INFO - 2023-08-16 09:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:24:18 --> Pagination Class Initialized
INFO - 2023-08-16 09:24:18 --> Form Validation Class Initialized
INFO - 2023-08-16 09:24:18 --> Controller Class Initialized
INFO - 2023-08-16 09:24:18 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:18 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:18 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:24:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:24:18 --> Model Class Initialized
INFO - 2023-08-16 09:24:18 --> Model Class Initialized
INFO - 2023-08-16 09:24:18 --> Model Class Initialized
INFO - 2023-08-16 09:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:24:18 --> Final output sent to browser
DEBUG - 2023-08-16 09:24:18 --> Total execution time: 0.0829
ERROR - 2023-08-16 09:24:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:24:58 --> Config Class Initialized
INFO - 2023-08-16 09:24:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:24:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:24:58 --> Utf8 Class Initialized
INFO - 2023-08-16 09:24:58 --> URI Class Initialized
INFO - 2023-08-16 09:24:58 --> Router Class Initialized
INFO - 2023-08-16 09:24:58 --> Output Class Initialized
INFO - 2023-08-16 09:24:58 --> Security Class Initialized
DEBUG - 2023-08-16 09:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:24:58 --> Input Class Initialized
INFO - 2023-08-16 09:24:58 --> Language Class Initialized
INFO - 2023-08-16 09:24:58 --> Loader Class Initialized
INFO - 2023-08-16 09:24:58 --> Helper loaded: url_helper
INFO - 2023-08-16 09:24:58 --> Helper loaded: file_helper
INFO - 2023-08-16 09:24:58 --> Helper loaded: html_helper
INFO - 2023-08-16 09:24:58 --> Helper loaded: text_helper
INFO - 2023-08-16 09:24:58 --> Helper loaded: form_helper
INFO - 2023-08-16 09:24:58 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:24:58 --> Helper loaded: security_helper
INFO - 2023-08-16 09:24:58 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:24:58 --> Database Driver Class Initialized
INFO - 2023-08-16 09:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:24:58 --> Parser Class Initialized
INFO - 2023-08-16 09:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:24:58 --> Pagination Class Initialized
INFO - 2023-08-16 09:24:58 --> Form Validation Class Initialized
INFO - 2023-08-16 09:24:58 --> Controller Class Initialized
INFO - 2023-08-16 09:24:58 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:58 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:58 --> Model Class Initialized
INFO - 2023-08-16 09:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:24:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:24:58 --> Model Class Initialized
INFO - 2023-08-16 09:24:58 --> Model Class Initialized
INFO - 2023-08-16 09:24:58 --> Model Class Initialized
INFO - 2023-08-16 09:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:24:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:24:58 --> Final output sent to browser
DEBUG - 2023-08-16 09:24:58 --> Total execution time: 0.0740
ERROR - 2023-08-16 09:24:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:24:59 --> Config Class Initialized
INFO - 2023-08-16 09:24:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:24:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:24:59 --> Utf8 Class Initialized
INFO - 2023-08-16 09:24:59 --> URI Class Initialized
INFO - 2023-08-16 09:24:59 --> Router Class Initialized
INFO - 2023-08-16 09:24:59 --> Output Class Initialized
INFO - 2023-08-16 09:24:59 --> Security Class Initialized
DEBUG - 2023-08-16 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:24:59 --> Input Class Initialized
INFO - 2023-08-16 09:24:59 --> Language Class Initialized
INFO - 2023-08-16 09:24:59 --> Loader Class Initialized
INFO - 2023-08-16 09:24:59 --> Helper loaded: url_helper
INFO - 2023-08-16 09:24:59 --> Helper loaded: file_helper
INFO - 2023-08-16 09:24:59 --> Helper loaded: html_helper
INFO - 2023-08-16 09:24:59 --> Helper loaded: text_helper
INFO - 2023-08-16 09:24:59 --> Helper loaded: form_helper
INFO - 2023-08-16 09:24:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:24:59 --> Helper loaded: security_helper
INFO - 2023-08-16 09:24:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:24:59 --> Database Driver Class Initialized
INFO - 2023-08-16 09:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:24:59 --> Parser Class Initialized
INFO - 2023-08-16 09:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:24:59 --> Pagination Class Initialized
INFO - 2023-08-16 09:24:59 --> Form Validation Class Initialized
INFO - 2023-08-16 09:24:59 --> Controller Class Initialized
INFO - 2023-08-16 09:24:59 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:59 --> Model Class Initialized
DEBUG - 2023-08-16 09:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:24:59 --> Model Class Initialized
INFO - 2023-08-16 09:24:59 --> Final output sent to browser
DEBUG - 2023-08-16 09:24:59 --> Total execution time: 0.0270
ERROR - 2023-08-16 09:25:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:25:00 --> Config Class Initialized
INFO - 2023-08-16 09:25:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:25:00 --> Utf8 Class Initialized
INFO - 2023-08-16 09:25:00 --> URI Class Initialized
DEBUG - 2023-08-16 09:25:00 --> No URI present. Default controller set.
INFO - 2023-08-16 09:25:00 --> Router Class Initialized
INFO - 2023-08-16 09:25:00 --> Output Class Initialized
INFO - 2023-08-16 09:25:00 --> Security Class Initialized
DEBUG - 2023-08-16 09:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:25:00 --> Input Class Initialized
INFO - 2023-08-16 09:25:00 --> Language Class Initialized
INFO - 2023-08-16 09:25:00 --> Loader Class Initialized
INFO - 2023-08-16 09:25:00 --> Helper loaded: url_helper
INFO - 2023-08-16 09:25:00 --> Helper loaded: file_helper
INFO - 2023-08-16 09:25:00 --> Helper loaded: html_helper
INFO - 2023-08-16 09:25:00 --> Helper loaded: text_helper
INFO - 2023-08-16 09:25:00 --> Helper loaded: form_helper
INFO - 2023-08-16 09:25:00 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:25:00 --> Helper loaded: security_helper
INFO - 2023-08-16 09:25:00 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:25:00 --> Database Driver Class Initialized
INFO - 2023-08-16 09:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:25:00 --> Parser Class Initialized
INFO - 2023-08-16 09:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:25:00 --> Pagination Class Initialized
INFO - 2023-08-16 09:25:00 --> Form Validation Class Initialized
INFO - 2023-08-16 09:25:00 --> Controller Class Initialized
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
INFO - 2023-08-16 09:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:25:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:25:00 --> Model Class Initialized
INFO - 2023-08-16 09:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:25:00 --> Final output sent to browser
DEBUG - 2023-08-16 09:25:00 --> Total execution time: 0.0753
ERROR - 2023-08-16 09:25:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:25:03 --> Config Class Initialized
INFO - 2023-08-16 09:25:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:25:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:25:03 --> Utf8 Class Initialized
INFO - 2023-08-16 09:25:03 --> URI Class Initialized
DEBUG - 2023-08-16 09:25:03 --> No URI present. Default controller set.
INFO - 2023-08-16 09:25:03 --> Router Class Initialized
INFO - 2023-08-16 09:25:03 --> Output Class Initialized
INFO - 2023-08-16 09:25:03 --> Security Class Initialized
DEBUG - 2023-08-16 09:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:25:03 --> Input Class Initialized
INFO - 2023-08-16 09:25:03 --> Language Class Initialized
INFO - 2023-08-16 09:25:03 --> Loader Class Initialized
INFO - 2023-08-16 09:25:03 --> Helper loaded: url_helper
INFO - 2023-08-16 09:25:03 --> Helper loaded: file_helper
INFO - 2023-08-16 09:25:03 --> Helper loaded: html_helper
INFO - 2023-08-16 09:25:03 --> Helper loaded: text_helper
INFO - 2023-08-16 09:25:03 --> Helper loaded: form_helper
INFO - 2023-08-16 09:25:03 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:25:03 --> Helper loaded: security_helper
INFO - 2023-08-16 09:25:03 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:25:03 --> Database Driver Class Initialized
INFO - 2023-08-16 09:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:25:03 --> Parser Class Initialized
INFO - 2023-08-16 09:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:25:03 --> Pagination Class Initialized
INFO - 2023-08-16 09:25:03 --> Form Validation Class Initialized
INFO - 2023-08-16 09:25:03 --> Controller Class Initialized
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
INFO - 2023-08-16 09:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:25:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:25:03 --> Model Class Initialized
INFO - 2023-08-16 09:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:25:03 --> Final output sent to browser
DEBUG - 2023-08-16 09:25:03 --> Total execution time: 0.0791
ERROR - 2023-08-16 09:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:25:51 --> Config Class Initialized
INFO - 2023-08-16 09:25:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:25:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:25:51 --> Utf8 Class Initialized
INFO - 2023-08-16 09:25:51 --> URI Class Initialized
INFO - 2023-08-16 09:25:51 --> Router Class Initialized
INFO - 2023-08-16 09:25:51 --> Output Class Initialized
INFO - 2023-08-16 09:25:51 --> Security Class Initialized
DEBUG - 2023-08-16 09:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:25:51 --> Input Class Initialized
INFO - 2023-08-16 09:25:51 --> Language Class Initialized
INFO - 2023-08-16 09:25:51 --> Loader Class Initialized
INFO - 2023-08-16 09:25:51 --> Helper loaded: url_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: file_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: html_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: text_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: form_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: security_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:25:51 --> Database Driver Class Initialized
INFO - 2023-08-16 09:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:25:51 --> Parser Class Initialized
INFO - 2023-08-16 09:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:25:51 --> Pagination Class Initialized
INFO - 2023-08-16 09:25:51 --> Form Validation Class Initialized
INFO - 2023-08-16 09:25:51 --> Controller Class Initialized
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-08-16 09:25:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:25:51 --> Final output sent to browser
DEBUG - 2023-08-16 09:25:51 --> Total execution time: 0.0664
ERROR - 2023-08-16 09:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:25:51 --> Config Class Initialized
INFO - 2023-08-16 09:25:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:25:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:25:51 --> Utf8 Class Initialized
INFO - 2023-08-16 09:25:51 --> URI Class Initialized
INFO - 2023-08-16 09:25:51 --> Router Class Initialized
INFO - 2023-08-16 09:25:51 --> Output Class Initialized
INFO - 2023-08-16 09:25:51 --> Security Class Initialized
DEBUG - 2023-08-16 09:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:25:51 --> Input Class Initialized
INFO - 2023-08-16 09:25:51 --> Language Class Initialized
INFO - 2023-08-16 09:25:51 --> Loader Class Initialized
INFO - 2023-08-16 09:25:51 --> Helper loaded: url_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: file_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: html_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: text_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: form_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: security_helper
INFO - 2023-08-16 09:25:51 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:25:51 --> Database Driver Class Initialized
INFO - 2023-08-16 09:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:25:51 --> Parser Class Initialized
INFO - 2023-08-16 09:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:25:51 --> Pagination Class Initialized
INFO - 2023-08-16 09:25:51 --> Form Validation Class Initialized
INFO - 2023-08-16 09:25:51 --> Controller Class Initialized
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-08-16 09:25:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
INFO - 2023-08-16 09:25:51 --> Model Class Initialized
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:25:51 --> Final output sent to browser
DEBUG - 2023-08-16 09:25:51 --> Total execution time: 0.0696
ERROR - 2023-08-16 09:25:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:25:59 --> Config Class Initialized
INFO - 2023-08-16 09:25:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:25:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:25:59 --> Utf8 Class Initialized
INFO - 2023-08-16 09:25:59 --> URI Class Initialized
DEBUG - 2023-08-16 09:25:59 --> No URI present. Default controller set.
INFO - 2023-08-16 09:25:59 --> Router Class Initialized
INFO - 2023-08-16 09:25:59 --> Output Class Initialized
INFO - 2023-08-16 09:25:59 --> Security Class Initialized
DEBUG - 2023-08-16 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:25:59 --> Input Class Initialized
INFO - 2023-08-16 09:25:59 --> Language Class Initialized
INFO - 2023-08-16 09:25:59 --> Loader Class Initialized
INFO - 2023-08-16 09:25:59 --> Helper loaded: url_helper
INFO - 2023-08-16 09:25:59 --> Helper loaded: file_helper
INFO - 2023-08-16 09:25:59 --> Helper loaded: html_helper
INFO - 2023-08-16 09:25:59 --> Helper loaded: text_helper
INFO - 2023-08-16 09:25:59 --> Helper loaded: form_helper
INFO - 2023-08-16 09:25:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:25:59 --> Helper loaded: security_helper
INFO - 2023-08-16 09:25:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:25:59 --> Database Driver Class Initialized
INFO - 2023-08-16 09:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:25:59 --> Parser Class Initialized
INFO - 2023-08-16 09:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:25:59 --> Pagination Class Initialized
INFO - 2023-08-16 09:25:59 --> Form Validation Class Initialized
INFO - 2023-08-16 09:25:59 --> Controller Class Initialized
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
DEBUG - 2023-08-16 09:25:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
INFO - 2023-08-16 09:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:25:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:25:59 --> Model Class Initialized
INFO - 2023-08-16 09:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:25:59 --> Final output sent to browser
DEBUG - 2023-08-16 09:25:59 --> Total execution time: 0.0807
ERROR - 2023-08-16 09:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:26:01 --> Config Class Initialized
INFO - 2023-08-16 09:26:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:26:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:26:01 --> Utf8 Class Initialized
INFO - 2023-08-16 09:26:01 --> URI Class Initialized
INFO - 2023-08-16 09:26:01 --> Router Class Initialized
INFO - 2023-08-16 09:26:01 --> Output Class Initialized
INFO - 2023-08-16 09:26:01 --> Security Class Initialized
DEBUG - 2023-08-16 09:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:26:01 --> Input Class Initialized
INFO - 2023-08-16 09:26:01 --> Language Class Initialized
INFO - 2023-08-16 09:26:01 --> Loader Class Initialized
INFO - 2023-08-16 09:26:01 --> Helper loaded: url_helper
INFO - 2023-08-16 09:26:01 --> Helper loaded: file_helper
INFO - 2023-08-16 09:26:01 --> Helper loaded: html_helper
INFO - 2023-08-16 09:26:01 --> Helper loaded: text_helper
INFO - 2023-08-16 09:26:01 --> Helper loaded: form_helper
INFO - 2023-08-16 09:26:01 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:26:01 --> Helper loaded: security_helper
INFO - 2023-08-16 09:26:01 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:26:01 --> Database Driver Class Initialized
INFO - 2023-08-16 09:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:26:01 --> Parser Class Initialized
INFO - 2023-08-16 09:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:26:01 --> Pagination Class Initialized
INFO - 2023-08-16 09:26:01 --> Form Validation Class Initialized
INFO - 2023-08-16 09:26:01 --> Controller Class Initialized
INFO - 2023-08-16 09:26:01 --> Model Class Initialized
DEBUG - 2023-08-16 09:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 09:26:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:26:01 --> Model Class Initialized
INFO - 2023-08-16 09:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:26:01 --> Final output sent to browser
DEBUG - 2023-08-16 09:26:01 --> Total execution time: 0.0340
ERROR - 2023-08-16 09:26:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:26:02 --> Config Class Initialized
INFO - 2023-08-16 09:26:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:26:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:26:02 --> Utf8 Class Initialized
INFO - 2023-08-16 09:26:02 --> URI Class Initialized
INFO - 2023-08-16 09:26:02 --> Router Class Initialized
INFO - 2023-08-16 09:26:02 --> Output Class Initialized
INFO - 2023-08-16 09:26:02 --> Security Class Initialized
DEBUG - 2023-08-16 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:26:02 --> Input Class Initialized
INFO - 2023-08-16 09:26:02 --> Language Class Initialized
INFO - 2023-08-16 09:26:02 --> Loader Class Initialized
INFO - 2023-08-16 09:26:02 --> Helper loaded: url_helper
INFO - 2023-08-16 09:26:02 --> Helper loaded: file_helper
INFO - 2023-08-16 09:26:02 --> Helper loaded: html_helper
INFO - 2023-08-16 09:26:02 --> Helper loaded: text_helper
INFO - 2023-08-16 09:26:02 --> Helper loaded: form_helper
INFO - 2023-08-16 09:26:02 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:26:02 --> Helper loaded: security_helper
INFO - 2023-08-16 09:26:02 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:26:02 --> Database Driver Class Initialized
INFO - 2023-08-16 09:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:26:02 --> Parser Class Initialized
INFO - 2023-08-16 09:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:26:02 --> Pagination Class Initialized
INFO - 2023-08-16 09:26:02 --> Form Validation Class Initialized
INFO - 2023-08-16 09:26:02 --> Controller Class Initialized
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
DEBUG - 2023-08-16 09:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
DEBUG - 2023-08-16 09:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
DEBUG - 2023-08-16 09:26:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
INFO - 2023-08-16 09:26:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:26:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:26:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:26:02 --> Model Class Initialized
INFO - 2023-08-16 09:26:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:26:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:26:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:26:02 --> Final output sent to browser
DEBUG - 2023-08-16 09:26:02 --> Total execution time: 0.0964
ERROR - 2023-08-16 09:26:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:26:23 --> Config Class Initialized
INFO - 2023-08-16 09:26:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:26:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:26:23 --> Utf8 Class Initialized
INFO - 2023-08-16 09:26:23 --> URI Class Initialized
DEBUG - 2023-08-16 09:26:23 --> No URI present. Default controller set.
INFO - 2023-08-16 09:26:23 --> Router Class Initialized
INFO - 2023-08-16 09:26:23 --> Output Class Initialized
INFO - 2023-08-16 09:26:23 --> Security Class Initialized
DEBUG - 2023-08-16 09:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:26:23 --> Input Class Initialized
INFO - 2023-08-16 09:26:23 --> Language Class Initialized
INFO - 2023-08-16 09:26:23 --> Loader Class Initialized
INFO - 2023-08-16 09:26:23 --> Helper loaded: url_helper
INFO - 2023-08-16 09:26:23 --> Helper loaded: file_helper
INFO - 2023-08-16 09:26:23 --> Helper loaded: html_helper
INFO - 2023-08-16 09:26:23 --> Helper loaded: text_helper
INFO - 2023-08-16 09:26:23 --> Helper loaded: form_helper
INFO - 2023-08-16 09:26:23 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:26:23 --> Helper loaded: security_helper
INFO - 2023-08-16 09:26:23 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:26:23 --> Database Driver Class Initialized
INFO - 2023-08-16 09:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:26:23 --> Parser Class Initialized
INFO - 2023-08-16 09:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:26:23 --> Pagination Class Initialized
INFO - 2023-08-16 09:26:23 --> Form Validation Class Initialized
INFO - 2023-08-16 09:26:23 --> Controller Class Initialized
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
DEBUG - 2023-08-16 09:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
DEBUG - 2023-08-16 09:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
DEBUG - 2023-08-16 09:26:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
INFO - 2023-08-16 09:26:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:26:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:26:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:26:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:26:23 --> Model Class Initialized
INFO - 2023-08-16 09:26:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:26:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:26:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:26:23 --> Final output sent to browser
DEBUG - 2023-08-16 09:26:23 --> Total execution time: 0.0808
ERROR - 2023-08-16 09:27:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:27:21 --> Config Class Initialized
INFO - 2023-08-16 09:27:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:27:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:27:21 --> Utf8 Class Initialized
INFO - 2023-08-16 09:27:21 --> URI Class Initialized
INFO - 2023-08-16 09:27:21 --> Router Class Initialized
INFO - 2023-08-16 09:27:21 --> Output Class Initialized
INFO - 2023-08-16 09:27:21 --> Security Class Initialized
DEBUG - 2023-08-16 09:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:27:21 --> Input Class Initialized
INFO - 2023-08-16 09:27:21 --> Language Class Initialized
INFO - 2023-08-16 09:27:21 --> Loader Class Initialized
INFO - 2023-08-16 09:27:21 --> Helper loaded: url_helper
INFO - 2023-08-16 09:27:21 --> Helper loaded: file_helper
INFO - 2023-08-16 09:27:21 --> Helper loaded: html_helper
INFO - 2023-08-16 09:27:21 --> Helper loaded: text_helper
INFO - 2023-08-16 09:27:21 --> Helper loaded: form_helper
INFO - 2023-08-16 09:27:21 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:27:21 --> Helper loaded: security_helper
INFO - 2023-08-16 09:27:21 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:27:21 --> Database Driver Class Initialized
INFO - 2023-08-16 09:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:27:21 --> Parser Class Initialized
INFO - 2023-08-16 09:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:27:21 --> Pagination Class Initialized
INFO - 2023-08-16 09:27:21 --> Form Validation Class Initialized
INFO - 2023-08-16 09:27:21 --> Controller Class Initialized
INFO - 2023-08-16 09:27:21 --> Model Class Initialized
DEBUG - 2023-08-16 09:27:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:21 --> Model Class Initialized
DEBUG - 2023-08-16 09:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:21 --> Model Class Initialized
INFO - 2023-08-16 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:27:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:27:21 --> Model Class Initialized
INFO - 2023-08-16 09:27:21 --> Model Class Initialized
INFO - 2023-08-16 09:27:21 --> Model Class Initialized
INFO - 2023-08-16 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:27:21 --> Final output sent to browser
DEBUG - 2023-08-16 09:27:21 --> Total execution time: 0.0798
ERROR - 2023-08-16 09:27:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:27:24 --> Config Class Initialized
INFO - 2023-08-16 09:27:24 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:27:24 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:27:24 --> Utf8 Class Initialized
INFO - 2023-08-16 09:27:24 --> URI Class Initialized
INFO - 2023-08-16 09:27:24 --> Router Class Initialized
INFO - 2023-08-16 09:27:24 --> Output Class Initialized
INFO - 2023-08-16 09:27:24 --> Security Class Initialized
DEBUG - 2023-08-16 09:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:27:24 --> Input Class Initialized
INFO - 2023-08-16 09:27:24 --> Language Class Initialized
INFO - 2023-08-16 09:27:24 --> Loader Class Initialized
INFO - 2023-08-16 09:27:24 --> Helper loaded: url_helper
INFO - 2023-08-16 09:27:24 --> Helper loaded: file_helper
INFO - 2023-08-16 09:27:24 --> Helper loaded: html_helper
INFO - 2023-08-16 09:27:24 --> Helper loaded: text_helper
INFO - 2023-08-16 09:27:24 --> Helper loaded: form_helper
INFO - 2023-08-16 09:27:24 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:27:24 --> Helper loaded: security_helper
INFO - 2023-08-16 09:27:24 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:27:24 --> Database Driver Class Initialized
INFO - 2023-08-16 09:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:27:24 --> Parser Class Initialized
INFO - 2023-08-16 09:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:27:24 --> Pagination Class Initialized
INFO - 2023-08-16 09:27:24 --> Form Validation Class Initialized
INFO - 2023-08-16 09:27:24 --> Controller Class Initialized
INFO - 2023-08-16 09:27:24 --> Model Class Initialized
DEBUG - 2023-08-16 09:27:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:24 --> Model Class Initialized
DEBUG - 2023-08-16 09:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:24 --> Model Class Initialized
INFO - 2023-08-16 09:27:24 --> Final output sent to browser
DEBUG - 2023-08-16 09:27:24 --> Total execution time: 0.0296
ERROR - 2023-08-16 09:27:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:27:45 --> Config Class Initialized
INFO - 2023-08-16 09:27:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:27:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:27:45 --> Utf8 Class Initialized
INFO - 2023-08-16 09:27:45 --> URI Class Initialized
INFO - 2023-08-16 09:27:45 --> Router Class Initialized
INFO - 2023-08-16 09:27:45 --> Output Class Initialized
INFO - 2023-08-16 09:27:45 --> Security Class Initialized
DEBUG - 2023-08-16 09:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:27:45 --> Input Class Initialized
INFO - 2023-08-16 09:27:45 --> Language Class Initialized
INFO - 2023-08-16 09:27:45 --> Loader Class Initialized
INFO - 2023-08-16 09:27:45 --> Helper loaded: url_helper
INFO - 2023-08-16 09:27:45 --> Helper loaded: file_helper
INFO - 2023-08-16 09:27:45 --> Helper loaded: html_helper
INFO - 2023-08-16 09:27:45 --> Helper loaded: text_helper
INFO - 2023-08-16 09:27:45 --> Helper loaded: form_helper
INFO - 2023-08-16 09:27:45 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:27:45 --> Helper loaded: security_helper
INFO - 2023-08-16 09:27:45 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:27:45 --> Database Driver Class Initialized
INFO - 2023-08-16 09:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:27:45 --> Parser Class Initialized
INFO - 2023-08-16 09:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:27:45 --> Pagination Class Initialized
INFO - 2023-08-16 09:27:45 --> Form Validation Class Initialized
INFO - 2023-08-16 09:27:45 --> Controller Class Initialized
INFO - 2023-08-16 09:27:45 --> Model Class Initialized
DEBUG - 2023-08-16 09:27:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:45 --> Model Class Initialized
DEBUG - 2023-08-16 09:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:45 --> Model Class Initialized
DEBUG - 2023-08-16 09:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-16 09:27:46 --> Final output sent to browser
DEBUG - 2023-08-16 09:27:46 --> Total execution time: 0.1913
ERROR - 2023-08-16 09:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:28:01 --> Config Class Initialized
INFO - 2023-08-16 09:28:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:28:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:28:01 --> Utf8 Class Initialized
INFO - 2023-08-16 09:28:01 --> URI Class Initialized
INFO - 2023-08-16 09:28:01 --> Router Class Initialized
INFO - 2023-08-16 09:28:01 --> Output Class Initialized
INFO - 2023-08-16 09:28:01 --> Security Class Initialized
DEBUG - 2023-08-16 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:28:01 --> Input Class Initialized
INFO - 2023-08-16 09:28:01 --> Language Class Initialized
INFO - 2023-08-16 09:28:01 --> Loader Class Initialized
INFO - 2023-08-16 09:28:01 --> Helper loaded: url_helper
INFO - 2023-08-16 09:28:01 --> Helper loaded: file_helper
INFO - 2023-08-16 09:28:01 --> Helper loaded: html_helper
INFO - 2023-08-16 09:28:01 --> Helper loaded: text_helper
INFO - 2023-08-16 09:28:01 --> Helper loaded: form_helper
INFO - 2023-08-16 09:28:01 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:28:01 --> Helper loaded: security_helper
INFO - 2023-08-16 09:28:01 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:28:01 --> Database Driver Class Initialized
INFO - 2023-08-16 09:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:28:01 --> Parser Class Initialized
INFO - 2023-08-16 09:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:28:01 --> Pagination Class Initialized
INFO - 2023-08-16 09:28:01 --> Form Validation Class Initialized
INFO - 2023-08-16 09:28:01 --> Controller Class Initialized
INFO - 2023-08-16 09:28:01 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:01 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:01 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:28:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:28:01 --> Model Class Initialized
INFO - 2023-08-16 09:28:01 --> Model Class Initialized
INFO - 2023-08-16 09:28:01 --> Model Class Initialized
INFO - 2023-08-16 09:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:28:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:28:01 --> Final output sent to browser
DEBUG - 2023-08-16 09:28:01 --> Total execution time: 0.0935
ERROR - 2023-08-16 09:28:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:28:13 --> Config Class Initialized
INFO - 2023-08-16 09:28:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:28:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:28:13 --> Utf8 Class Initialized
INFO - 2023-08-16 09:28:13 --> URI Class Initialized
INFO - 2023-08-16 09:28:13 --> Router Class Initialized
INFO - 2023-08-16 09:28:13 --> Output Class Initialized
INFO - 2023-08-16 09:28:13 --> Security Class Initialized
DEBUG - 2023-08-16 09:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:28:13 --> Input Class Initialized
INFO - 2023-08-16 09:28:13 --> Language Class Initialized
INFO - 2023-08-16 09:28:13 --> Loader Class Initialized
INFO - 2023-08-16 09:28:13 --> Helper loaded: url_helper
INFO - 2023-08-16 09:28:13 --> Helper loaded: file_helper
INFO - 2023-08-16 09:28:13 --> Helper loaded: html_helper
INFO - 2023-08-16 09:28:13 --> Helper loaded: text_helper
INFO - 2023-08-16 09:28:13 --> Helper loaded: form_helper
INFO - 2023-08-16 09:28:13 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:28:13 --> Helper loaded: security_helper
INFO - 2023-08-16 09:28:13 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:28:13 --> Database Driver Class Initialized
INFO - 2023-08-16 09:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:28:13 --> Parser Class Initialized
INFO - 2023-08-16 09:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:28:13 --> Pagination Class Initialized
INFO - 2023-08-16 09:28:13 --> Form Validation Class Initialized
INFO - 2023-08-16 09:28:13 --> Controller Class Initialized
INFO - 2023-08-16 09:28:13 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:13 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:13 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:28:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:28:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:28:13 --> Model Class Initialized
INFO - 2023-08-16 09:28:13 --> Model Class Initialized
INFO - 2023-08-16 09:28:13 --> Model Class Initialized
INFO - 2023-08-16 09:28:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:28:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:28:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:28:13 --> Final output sent to browser
DEBUG - 2023-08-16 09:28:13 --> Total execution time: 0.0909
ERROR - 2023-08-16 09:28:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:28:40 --> Config Class Initialized
INFO - 2023-08-16 09:28:40 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:28:40 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:28:40 --> Utf8 Class Initialized
INFO - 2023-08-16 09:28:40 --> URI Class Initialized
INFO - 2023-08-16 09:28:40 --> Router Class Initialized
INFO - 2023-08-16 09:28:40 --> Output Class Initialized
INFO - 2023-08-16 09:28:40 --> Security Class Initialized
DEBUG - 2023-08-16 09:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:28:40 --> Input Class Initialized
INFO - 2023-08-16 09:28:40 --> Language Class Initialized
INFO - 2023-08-16 09:28:40 --> Loader Class Initialized
INFO - 2023-08-16 09:28:40 --> Helper loaded: url_helper
INFO - 2023-08-16 09:28:40 --> Helper loaded: file_helper
INFO - 2023-08-16 09:28:40 --> Helper loaded: html_helper
INFO - 2023-08-16 09:28:40 --> Helper loaded: text_helper
INFO - 2023-08-16 09:28:40 --> Helper loaded: form_helper
INFO - 2023-08-16 09:28:40 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:28:40 --> Helper loaded: security_helper
INFO - 2023-08-16 09:28:40 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:28:40 --> Database Driver Class Initialized
INFO - 2023-08-16 09:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:28:40 --> Parser Class Initialized
INFO - 2023-08-16 09:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:28:40 --> Pagination Class Initialized
INFO - 2023-08-16 09:28:40 --> Form Validation Class Initialized
INFO - 2023-08-16 09:28:40 --> Controller Class Initialized
INFO - 2023-08-16 09:28:40 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:40 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:40 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:28:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-16 09:28:40 --> Final output sent to browser
DEBUG - 2023-08-16 09:28:40 --> Total execution time: 0.1807
ERROR - 2023-08-16 09:28:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:28:45 --> Config Class Initialized
INFO - 2023-08-16 09:28:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:28:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:28:45 --> Utf8 Class Initialized
INFO - 2023-08-16 09:28:45 --> URI Class Initialized
INFO - 2023-08-16 09:28:45 --> Router Class Initialized
INFO - 2023-08-16 09:28:45 --> Output Class Initialized
INFO - 2023-08-16 09:28:45 --> Security Class Initialized
DEBUG - 2023-08-16 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:28:45 --> Input Class Initialized
INFO - 2023-08-16 09:28:45 --> Language Class Initialized
INFO - 2023-08-16 09:28:45 --> Loader Class Initialized
INFO - 2023-08-16 09:28:45 --> Helper loaded: url_helper
INFO - 2023-08-16 09:28:45 --> Helper loaded: file_helper
INFO - 2023-08-16 09:28:45 --> Helper loaded: html_helper
INFO - 2023-08-16 09:28:45 --> Helper loaded: text_helper
INFO - 2023-08-16 09:28:45 --> Helper loaded: form_helper
INFO - 2023-08-16 09:28:45 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:28:45 --> Helper loaded: security_helper
INFO - 2023-08-16 09:28:45 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:28:45 --> Database Driver Class Initialized
INFO - 2023-08-16 09:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:28:45 --> Parser Class Initialized
INFO - 2023-08-16 09:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:28:45 --> Pagination Class Initialized
INFO - 2023-08-16 09:28:45 --> Form Validation Class Initialized
INFO - 2023-08-16 09:28:45 --> Controller Class Initialized
INFO - 2023-08-16 09:28:45 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:45 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:45 --> Model Class Initialized
DEBUG - 2023-08-16 09:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:28:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:28:45 --> Model Class Initialized
INFO - 2023-08-16 09:28:45 --> Model Class Initialized
INFO - 2023-08-16 09:28:45 --> Model Class Initialized
INFO - 2023-08-16 09:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:28:45 --> Final output sent to browser
DEBUG - 2023-08-16 09:28:45 --> Total execution time: 0.0789
ERROR - 2023-08-16 09:29:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:29:14 --> Config Class Initialized
INFO - 2023-08-16 09:29:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:29:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:29:14 --> Utf8 Class Initialized
INFO - 2023-08-16 09:29:14 --> URI Class Initialized
INFO - 2023-08-16 09:29:14 --> Router Class Initialized
INFO - 2023-08-16 09:29:14 --> Output Class Initialized
INFO - 2023-08-16 09:29:14 --> Security Class Initialized
DEBUG - 2023-08-16 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:29:14 --> Input Class Initialized
INFO - 2023-08-16 09:29:14 --> Language Class Initialized
INFO - 2023-08-16 09:29:14 --> Loader Class Initialized
INFO - 2023-08-16 09:29:14 --> Helper loaded: url_helper
INFO - 2023-08-16 09:29:14 --> Helper loaded: file_helper
INFO - 2023-08-16 09:29:14 --> Helper loaded: html_helper
INFO - 2023-08-16 09:29:14 --> Helper loaded: text_helper
INFO - 2023-08-16 09:29:14 --> Helper loaded: form_helper
INFO - 2023-08-16 09:29:14 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:29:14 --> Helper loaded: security_helper
INFO - 2023-08-16 09:29:14 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:29:14 --> Database Driver Class Initialized
INFO - 2023-08-16 09:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:29:14 --> Parser Class Initialized
INFO - 2023-08-16 09:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:29:14 --> Pagination Class Initialized
INFO - 2023-08-16 09:29:14 --> Form Validation Class Initialized
INFO - 2023-08-16 09:29:14 --> Controller Class Initialized
INFO - 2023-08-16 09:29:14 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:14 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:14 --> Model Class Initialized
INFO - 2023-08-16 09:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:29:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:29:14 --> Model Class Initialized
INFO - 2023-08-16 09:29:14 --> Model Class Initialized
INFO - 2023-08-16 09:29:14 --> Model Class Initialized
INFO - 2023-08-16 09:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:29:14 --> Final output sent to browser
DEBUG - 2023-08-16 09:29:14 --> Total execution time: 0.0745
ERROR - 2023-08-16 09:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:29:15 --> Config Class Initialized
INFO - 2023-08-16 09:29:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:29:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:29:15 --> Utf8 Class Initialized
INFO - 2023-08-16 09:29:15 --> URI Class Initialized
INFO - 2023-08-16 09:29:15 --> Router Class Initialized
INFO - 2023-08-16 09:29:15 --> Output Class Initialized
INFO - 2023-08-16 09:29:15 --> Security Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:29:15 --> Input Class Initialized
INFO - 2023-08-16 09:29:15 --> Language Class Initialized
INFO - 2023-08-16 09:29:15 --> Loader Class Initialized
ERROR - 2023-08-16 09:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:29:15 --> Helper loaded: url_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: file_helper
INFO - 2023-08-16 09:29:15 --> Config Class Initialized
INFO - 2023-08-16 09:29:15 --> Hooks Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: html_helper
ERROR - 2023-08-16 09:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:29:15 --> Helper loaded: text_helper
DEBUG - 2023-08-16 09:29:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:29:15 --> Config Class Initialized
INFO - 2023-08-16 09:29:15 --> Utf8 Class Initialized
INFO - 2023-08-16 09:29:15 --> Hooks Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: form_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: security_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:29:15 --> URI Class Initialized
INFO - 2023-08-16 09:29:15 --> Router Class Initialized
DEBUG - 2023-08-16 09:29:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:29:15 --> Utf8 Class Initialized
INFO - 2023-08-16 09:29:15 --> Output Class Initialized
INFO - 2023-08-16 09:29:15 --> URI Class Initialized
INFO - 2023-08-16 09:29:15 --> Router Class Initialized
INFO - 2023-08-16 09:29:15 --> Security Class Initialized
ERROR - 2023-08-16 09:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:29:15 --> Output Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:29:15 --> Config Class Initialized
INFO - 2023-08-16 09:29:15 --> Input Class Initialized
INFO - 2023-08-16 09:29:15 --> Hooks Class Initialized
INFO - 2023-08-16 09:29:15 --> Language Class Initialized
INFO - 2023-08-16 09:29:15 --> Database Driver Class Initialized
INFO - 2023-08-16 09:29:15 --> Security Class Initialized
DEBUG - 2023-08-16 09:29:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:29:15 --> Utf8 Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:29:15 --> Input Class Initialized
INFO - 2023-08-16 09:29:15 --> Language Class Initialized
INFO - 2023-08-16 09:29:15 --> URI Class Initialized
INFO - 2023-08-16 09:29:15 --> Router Class Initialized
INFO - 2023-08-16 09:29:15 --> Loader Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: url_helper
INFO - 2023-08-16 09:29:15 --> Output Class Initialized
INFO - 2023-08-16 09:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:29:15 --> Helper loaded: file_helper
INFO - 2023-08-16 09:29:15 --> Parser Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: html_helper
INFO - 2023-08-16 09:29:15 --> Security Class Initialized
INFO - 2023-08-16 09:29:15 --> Loader Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: text_helper
INFO - 2023-08-16 09:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:29:15 --> Helper loaded: url_helper
DEBUG - 2023-08-16 09:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:29:15 --> Pagination Class Initialized
INFO - 2023-08-16 09:29:15 --> Input Class Initialized
INFO - 2023-08-16 09:29:15 --> Language Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: file_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: form_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: html_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: security_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:29:15 --> Form Validation Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: text_helper
INFO - 2023-08-16 09:29:15 --> Controller Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: form_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: security_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:29:15 --> Loader Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: url_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: file_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: html_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: text_helper
INFO - 2023-08-16 09:29:15 --> Database Driver Class Initialized
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
INFO - 2023-08-16 09:29:15 --> Helper loaded: form_helper
DEBUG - 2023-08-16 09:29:15 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: security_helper
INFO - 2023-08-16 09:29:15 --> Helper loaded: cookie_helper
DEBUG - 2023-08-16 09:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:15 --> Database Driver Class Initialized
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:15 --> Database Driver Class Initialized
INFO - 2023-08-16 09:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:29:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
INFO - 2023-08-16 09:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:29:15 --> Final output sent to browser
DEBUG - 2023-08-16 09:29:15 --> Total execution time: 0.0801
INFO - 2023-08-16 09:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:29:15 --> Parser Class Initialized
INFO - 2023-08-16 09:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:29:15 --> Pagination Class Initialized
INFO - 2023-08-16 09:29:15 --> Form Validation Class Initialized
INFO - 2023-08-16 09:29:15 --> Controller Class Initialized
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:15 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-16 09:29:16 --> Final output sent to browser
DEBUG - 2023-08-16 09:29:16 --> Total execution time: 0.2454
INFO - 2023-08-16 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:29:16 --> Parser Class Initialized
INFO - 2023-08-16 09:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:29:16 --> Pagination Class Initialized
INFO - 2023-08-16 09:29:16 --> Form Validation Class Initialized
INFO - 2023-08-16 09:29:16 --> Controller Class Initialized
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:29:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:29:16 --> Final output sent to browser
DEBUG - 2023-08-16 09:29:16 --> Total execution time: 0.3102
INFO - 2023-08-16 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:29:16 --> Parser Class Initialized
INFO - 2023-08-16 09:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:29:16 --> Pagination Class Initialized
INFO - 2023-08-16 09:29:16 --> Form Validation Class Initialized
INFO - 2023-08-16 09:29:16 --> Controller Class Initialized
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-16 09:29:16 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-16 09:29:16 --> Final output sent to browser
DEBUG - 2023-08-16 09:29:16 --> Total execution time: 0.4893
ERROR - 2023-08-16 09:29:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:29:16 --> Config Class Initialized
INFO - 2023-08-16 09:29:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:29:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:29:16 --> Utf8 Class Initialized
INFO - 2023-08-16 09:29:16 --> URI Class Initialized
INFO - 2023-08-16 09:29:16 --> Router Class Initialized
INFO - 2023-08-16 09:29:16 --> Output Class Initialized
INFO - 2023-08-16 09:29:16 --> Security Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:29:16 --> Input Class Initialized
INFO - 2023-08-16 09:29:16 --> Language Class Initialized
INFO - 2023-08-16 09:29:16 --> Loader Class Initialized
INFO - 2023-08-16 09:29:16 --> Helper loaded: url_helper
INFO - 2023-08-16 09:29:16 --> Helper loaded: file_helper
INFO - 2023-08-16 09:29:16 --> Helper loaded: html_helper
INFO - 2023-08-16 09:29:16 --> Helper loaded: text_helper
INFO - 2023-08-16 09:29:16 --> Helper loaded: form_helper
INFO - 2023-08-16 09:29:16 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:29:16 --> Helper loaded: security_helper
INFO - 2023-08-16 09:29:16 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:29:16 --> Database Driver Class Initialized
INFO - 2023-08-16 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:29:16 --> Parser Class Initialized
INFO - 2023-08-16 09:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:29:16 --> Pagination Class Initialized
INFO - 2023-08-16 09:29:16 --> Form Validation Class Initialized
INFO - 2023-08-16 09:29:16 --> Controller Class Initialized
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:16 --> Model Class Initialized
INFO - 2023-08-16 09:29:17 --> Final output sent to browser
DEBUG - 2023-08-16 09:29:17 --> Total execution time: 0.0271
ERROR - 2023-08-16 09:29:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:29:48 --> Config Class Initialized
INFO - 2023-08-16 09:29:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:29:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:29:48 --> Utf8 Class Initialized
INFO - 2023-08-16 09:29:48 --> URI Class Initialized
INFO - 2023-08-16 09:29:48 --> Router Class Initialized
INFO - 2023-08-16 09:29:48 --> Output Class Initialized
INFO - 2023-08-16 09:29:48 --> Security Class Initialized
DEBUG - 2023-08-16 09:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:29:48 --> Input Class Initialized
INFO - 2023-08-16 09:29:48 --> Language Class Initialized
INFO - 2023-08-16 09:29:48 --> Loader Class Initialized
INFO - 2023-08-16 09:29:48 --> Helper loaded: url_helper
INFO - 2023-08-16 09:29:48 --> Helper loaded: file_helper
INFO - 2023-08-16 09:29:48 --> Helper loaded: html_helper
INFO - 2023-08-16 09:29:48 --> Helper loaded: text_helper
INFO - 2023-08-16 09:29:48 --> Helper loaded: form_helper
INFO - 2023-08-16 09:29:48 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:29:48 --> Helper loaded: security_helper
INFO - 2023-08-16 09:29:48 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:29:48 --> Database Driver Class Initialized
INFO - 2023-08-16 09:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:29:48 --> Parser Class Initialized
INFO - 2023-08-16 09:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:29:48 --> Pagination Class Initialized
INFO - 2023-08-16 09:29:48 --> Form Validation Class Initialized
INFO - 2023-08-16 09:29:48 --> Controller Class Initialized
INFO - 2023-08-16 09:29:48 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:48 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:48 --> Model Class Initialized
DEBUG - 2023-08-16 09:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:29:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:29:48 --> Model Class Initialized
INFO - 2023-08-16 09:29:48 --> Model Class Initialized
INFO - 2023-08-16 09:29:48 --> Model Class Initialized
INFO - 2023-08-16 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:29:48 --> Final output sent to browser
DEBUG - 2023-08-16 09:29:48 --> Total execution time: 0.0802
ERROR - 2023-08-16 09:30:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:30:28 --> Config Class Initialized
INFO - 2023-08-16 09:30:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:30:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:30:28 --> Utf8 Class Initialized
INFO - 2023-08-16 09:30:28 --> URI Class Initialized
INFO - 2023-08-16 09:30:28 --> Router Class Initialized
INFO - 2023-08-16 09:30:28 --> Output Class Initialized
INFO - 2023-08-16 09:30:28 --> Security Class Initialized
DEBUG - 2023-08-16 09:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:30:28 --> Input Class Initialized
INFO - 2023-08-16 09:30:28 --> Language Class Initialized
INFO - 2023-08-16 09:30:28 --> Loader Class Initialized
INFO - 2023-08-16 09:30:28 --> Helper loaded: url_helper
INFO - 2023-08-16 09:30:28 --> Helper loaded: file_helper
INFO - 2023-08-16 09:30:28 --> Helper loaded: html_helper
INFO - 2023-08-16 09:30:28 --> Helper loaded: text_helper
INFO - 2023-08-16 09:30:28 --> Helper loaded: form_helper
INFO - 2023-08-16 09:30:28 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:30:28 --> Helper loaded: security_helper
INFO - 2023-08-16 09:30:28 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:30:28 --> Database Driver Class Initialized
INFO - 2023-08-16 09:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:30:28 --> Parser Class Initialized
INFO - 2023-08-16 09:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:30:28 --> Pagination Class Initialized
INFO - 2023-08-16 09:30:28 --> Form Validation Class Initialized
INFO - 2023-08-16 09:30:28 --> Controller Class Initialized
INFO - 2023-08-16 09:30:28 --> Model Class Initialized
DEBUG - 2023-08-16 09:30:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:28 --> Model Class Initialized
DEBUG - 2023-08-16 09:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:28 --> Model Class Initialized
INFO - 2023-08-16 09:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:30:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:30:28 --> Model Class Initialized
INFO - 2023-08-16 09:30:28 --> Model Class Initialized
INFO - 2023-08-16 09:30:28 --> Model Class Initialized
INFO - 2023-08-16 09:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:30:28 --> Final output sent to browser
DEBUG - 2023-08-16 09:30:28 --> Total execution time: 0.0772
ERROR - 2023-08-16 09:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:30:31 --> Config Class Initialized
INFO - 2023-08-16 09:30:31 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:30:31 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:30:31 --> Utf8 Class Initialized
INFO - 2023-08-16 09:30:31 --> URI Class Initialized
INFO - 2023-08-16 09:30:31 --> Router Class Initialized
INFO - 2023-08-16 09:30:31 --> Output Class Initialized
INFO - 2023-08-16 09:30:31 --> Security Class Initialized
DEBUG - 2023-08-16 09:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:30:31 --> Input Class Initialized
INFO - 2023-08-16 09:30:31 --> Language Class Initialized
INFO - 2023-08-16 09:30:31 --> Loader Class Initialized
INFO - 2023-08-16 09:30:31 --> Helper loaded: url_helper
INFO - 2023-08-16 09:30:31 --> Helper loaded: file_helper
INFO - 2023-08-16 09:30:31 --> Helper loaded: html_helper
INFO - 2023-08-16 09:30:31 --> Helper loaded: text_helper
INFO - 2023-08-16 09:30:31 --> Helper loaded: form_helper
INFO - 2023-08-16 09:30:31 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:30:31 --> Helper loaded: security_helper
INFO - 2023-08-16 09:30:31 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:30:31 --> Database Driver Class Initialized
INFO - 2023-08-16 09:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:30:31 --> Parser Class Initialized
INFO - 2023-08-16 09:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:30:31 --> Pagination Class Initialized
INFO - 2023-08-16 09:30:31 --> Form Validation Class Initialized
INFO - 2023-08-16 09:30:31 --> Controller Class Initialized
INFO - 2023-08-16 09:30:31 --> Model Class Initialized
DEBUG - 2023-08-16 09:30:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:31 --> Model Class Initialized
DEBUG - 2023-08-16 09:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:31 --> Model Class Initialized
INFO - 2023-08-16 09:30:31 --> Final output sent to browser
DEBUG - 2023-08-16 09:30:31 --> Total execution time: 0.0272
ERROR - 2023-08-16 09:30:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:30:46 --> Config Class Initialized
INFO - 2023-08-16 09:30:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:30:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:30:46 --> Utf8 Class Initialized
INFO - 2023-08-16 09:30:46 --> URI Class Initialized
INFO - 2023-08-16 09:30:46 --> Router Class Initialized
INFO - 2023-08-16 09:30:46 --> Output Class Initialized
INFO - 2023-08-16 09:30:46 --> Security Class Initialized
DEBUG - 2023-08-16 09:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:30:46 --> Input Class Initialized
INFO - 2023-08-16 09:30:46 --> Language Class Initialized
INFO - 2023-08-16 09:30:46 --> Loader Class Initialized
INFO - 2023-08-16 09:30:46 --> Helper loaded: url_helper
INFO - 2023-08-16 09:30:46 --> Helper loaded: file_helper
INFO - 2023-08-16 09:30:46 --> Helper loaded: html_helper
INFO - 2023-08-16 09:30:46 --> Helper loaded: text_helper
INFO - 2023-08-16 09:30:46 --> Helper loaded: form_helper
INFO - 2023-08-16 09:30:46 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:30:46 --> Helper loaded: security_helper
INFO - 2023-08-16 09:30:46 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:30:46 --> Database Driver Class Initialized
INFO - 2023-08-16 09:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:30:46 --> Parser Class Initialized
INFO - 2023-08-16 09:30:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:30:46 --> Pagination Class Initialized
INFO - 2023-08-16 09:30:46 --> Form Validation Class Initialized
INFO - 2023-08-16 09:30:46 --> Controller Class Initialized
INFO - 2023-08-16 09:30:46 --> Model Class Initialized
DEBUG - 2023-08-16 09:30:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:46 --> Model Class Initialized
DEBUG - 2023-08-16 09:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:46 --> Model Class Initialized
DEBUG - 2023-08-16 09:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:30:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:30:46 --> Model Class Initialized
INFO - 2023-08-16 09:30:46 --> Model Class Initialized
INFO - 2023-08-16 09:30:46 --> Model Class Initialized
INFO - 2023-08-16 09:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:30:46 --> Final output sent to browser
DEBUG - 2023-08-16 09:30:46 --> Total execution time: 0.0839
ERROR - 2023-08-16 09:31:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:31:48 --> Config Class Initialized
INFO - 2023-08-16 09:31:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:31:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:31:48 --> Utf8 Class Initialized
INFO - 2023-08-16 09:31:48 --> URI Class Initialized
INFO - 2023-08-16 09:31:48 --> Router Class Initialized
INFO - 2023-08-16 09:31:48 --> Output Class Initialized
INFO - 2023-08-16 09:31:48 --> Security Class Initialized
DEBUG - 2023-08-16 09:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:31:48 --> Input Class Initialized
INFO - 2023-08-16 09:31:48 --> Language Class Initialized
INFO - 2023-08-16 09:31:48 --> Loader Class Initialized
INFO - 2023-08-16 09:31:48 --> Helper loaded: url_helper
INFO - 2023-08-16 09:31:48 --> Helper loaded: file_helper
INFO - 2023-08-16 09:31:48 --> Helper loaded: html_helper
INFO - 2023-08-16 09:31:48 --> Helper loaded: text_helper
INFO - 2023-08-16 09:31:48 --> Helper loaded: form_helper
INFO - 2023-08-16 09:31:48 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:31:48 --> Helper loaded: security_helper
INFO - 2023-08-16 09:31:48 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:31:48 --> Database Driver Class Initialized
INFO - 2023-08-16 09:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:31:48 --> Parser Class Initialized
INFO - 2023-08-16 09:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:31:48 --> Pagination Class Initialized
INFO - 2023-08-16 09:31:48 --> Form Validation Class Initialized
INFO - 2023-08-16 09:31:48 --> Controller Class Initialized
INFO - 2023-08-16 09:31:48 --> Model Class Initialized
DEBUG - 2023-08-16 09:31:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:31:48 --> Model Class Initialized
DEBUG - 2023-08-16 09:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:31:48 --> Model Class Initialized
INFO - 2023-08-16 09:31:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:31:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:31:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:31:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:31:48 --> Model Class Initialized
INFO - 2023-08-16 09:31:48 --> Model Class Initialized
INFO - 2023-08-16 09:31:48 --> Model Class Initialized
INFO - 2023-08-16 09:31:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:31:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:31:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:31:48 --> Final output sent to browser
DEBUG - 2023-08-16 09:31:48 --> Total execution time: 0.0737
ERROR - 2023-08-16 09:31:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:31:49 --> Config Class Initialized
INFO - 2023-08-16 09:31:49 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:31:49 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:31:49 --> Utf8 Class Initialized
INFO - 2023-08-16 09:31:49 --> URI Class Initialized
INFO - 2023-08-16 09:31:49 --> Router Class Initialized
INFO - 2023-08-16 09:31:49 --> Output Class Initialized
INFO - 2023-08-16 09:31:49 --> Security Class Initialized
DEBUG - 2023-08-16 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:31:49 --> Input Class Initialized
INFO - 2023-08-16 09:31:49 --> Language Class Initialized
INFO - 2023-08-16 09:31:49 --> Loader Class Initialized
INFO - 2023-08-16 09:31:49 --> Helper loaded: url_helper
INFO - 2023-08-16 09:31:49 --> Helper loaded: file_helper
INFO - 2023-08-16 09:31:49 --> Helper loaded: html_helper
INFO - 2023-08-16 09:31:49 --> Helper loaded: text_helper
INFO - 2023-08-16 09:31:49 --> Helper loaded: form_helper
INFO - 2023-08-16 09:31:49 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:31:49 --> Helper loaded: security_helper
INFO - 2023-08-16 09:31:49 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:31:49 --> Database Driver Class Initialized
INFO - 2023-08-16 09:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:31:49 --> Parser Class Initialized
INFO - 2023-08-16 09:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:31:49 --> Pagination Class Initialized
INFO - 2023-08-16 09:31:49 --> Form Validation Class Initialized
INFO - 2023-08-16 09:31:49 --> Controller Class Initialized
INFO - 2023-08-16 09:31:49 --> Model Class Initialized
DEBUG - 2023-08-16 09:31:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:31:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:31:49 --> Model Class Initialized
DEBUG - 2023-08-16 09:31:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:31:49 --> Model Class Initialized
INFO - 2023-08-16 09:31:49 --> Final output sent to browser
DEBUG - 2023-08-16 09:31:49 --> Total execution time: 0.0269
ERROR - 2023-08-16 09:32:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:32:02 --> Config Class Initialized
INFO - 2023-08-16 09:32:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:32:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:32:02 --> Utf8 Class Initialized
INFO - 2023-08-16 09:32:02 --> URI Class Initialized
INFO - 2023-08-16 09:32:02 --> Router Class Initialized
INFO - 2023-08-16 09:32:02 --> Output Class Initialized
INFO - 2023-08-16 09:32:02 --> Security Class Initialized
DEBUG - 2023-08-16 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:32:02 --> Input Class Initialized
INFO - 2023-08-16 09:32:02 --> Language Class Initialized
INFO - 2023-08-16 09:32:02 --> Loader Class Initialized
INFO - 2023-08-16 09:32:02 --> Helper loaded: url_helper
INFO - 2023-08-16 09:32:02 --> Helper loaded: file_helper
INFO - 2023-08-16 09:32:02 --> Helper loaded: html_helper
INFO - 2023-08-16 09:32:02 --> Helper loaded: text_helper
INFO - 2023-08-16 09:32:02 --> Helper loaded: form_helper
INFO - 2023-08-16 09:32:02 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:32:02 --> Helper loaded: security_helper
INFO - 2023-08-16 09:32:02 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:32:03 --> Database Driver Class Initialized
INFO - 2023-08-16 09:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:32:03 --> Parser Class Initialized
INFO - 2023-08-16 09:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:32:03 --> Pagination Class Initialized
INFO - 2023-08-16 09:32:03 --> Form Validation Class Initialized
INFO - 2023-08-16 09:32:03 --> Controller Class Initialized
INFO - 2023-08-16 09:32:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:32:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:03 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:32:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:32:03 --> Model Class Initialized
INFO - 2023-08-16 09:32:03 --> Model Class Initialized
INFO - 2023-08-16 09:32:03 --> Model Class Initialized
INFO - 2023-08-16 09:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:32:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:32:03 --> Final output sent to browser
DEBUG - 2023-08-16 09:32:03 --> Total execution time: 0.0796
ERROR - 2023-08-16 09:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:32:26 --> Config Class Initialized
INFO - 2023-08-16 09:32:26 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:32:26 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:32:26 --> Utf8 Class Initialized
INFO - 2023-08-16 09:32:26 --> URI Class Initialized
INFO - 2023-08-16 09:32:26 --> Router Class Initialized
INFO - 2023-08-16 09:32:26 --> Output Class Initialized
INFO - 2023-08-16 09:32:26 --> Security Class Initialized
DEBUG - 2023-08-16 09:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:32:26 --> Input Class Initialized
INFO - 2023-08-16 09:32:26 --> Language Class Initialized
INFO - 2023-08-16 09:32:26 --> Loader Class Initialized
INFO - 2023-08-16 09:32:26 --> Helper loaded: url_helper
INFO - 2023-08-16 09:32:26 --> Helper loaded: file_helper
INFO - 2023-08-16 09:32:26 --> Helper loaded: html_helper
INFO - 2023-08-16 09:32:26 --> Helper loaded: text_helper
INFO - 2023-08-16 09:32:26 --> Helper loaded: form_helper
INFO - 2023-08-16 09:32:26 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:32:26 --> Helper loaded: security_helper
INFO - 2023-08-16 09:32:26 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:32:26 --> Database Driver Class Initialized
INFO - 2023-08-16 09:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:32:26 --> Parser Class Initialized
INFO - 2023-08-16 09:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:32:26 --> Pagination Class Initialized
INFO - 2023-08-16 09:32:26 --> Form Validation Class Initialized
INFO - 2023-08-16 09:32:26 --> Controller Class Initialized
INFO - 2023-08-16 09:32:26 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:26 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:26 --> Model Class Initialized
INFO - 2023-08-16 09:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:32:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:32:26 --> Model Class Initialized
INFO - 2023-08-16 09:32:26 --> Model Class Initialized
INFO - 2023-08-16 09:32:26 --> Model Class Initialized
INFO - 2023-08-16 09:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:32:26 --> Final output sent to browser
DEBUG - 2023-08-16 09:32:26 --> Total execution time: 0.0745
ERROR - 2023-08-16 09:32:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:32:29 --> Config Class Initialized
INFO - 2023-08-16 09:32:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:32:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:32:29 --> Utf8 Class Initialized
INFO - 2023-08-16 09:32:29 --> URI Class Initialized
INFO - 2023-08-16 09:32:29 --> Router Class Initialized
INFO - 2023-08-16 09:32:29 --> Output Class Initialized
INFO - 2023-08-16 09:32:29 --> Security Class Initialized
DEBUG - 2023-08-16 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:32:29 --> Input Class Initialized
INFO - 2023-08-16 09:32:29 --> Language Class Initialized
INFO - 2023-08-16 09:32:29 --> Loader Class Initialized
INFO - 2023-08-16 09:32:29 --> Helper loaded: url_helper
INFO - 2023-08-16 09:32:29 --> Helper loaded: file_helper
INFO - 2023-08-16 09:32:29 --> Helper loaded: html_helper
INFO - 2023-08-16 09:32:29 --> Helper loaded: text_helper
INFO - 2023-08-16 09:32:29 --> Helper loaded: form_helper
INFO - 2023-08-16 09:32:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:32:29 --> Helper loaded: security_helper
INFO - 2023-08-16 09:32:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:32:29 --> Database Driver Class Initialized
INFO - 2023-08-16 09:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:32:29 --> Parser Class Initialized
INFO - 2023-08-16 09:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:32:29 --> Pagination Class Initialized
INFO - 2023-08-16 09:32:29 --> Form Validation Class Initialized
INFO - 2023-08-16 09:32:29 --> Controller Class Initialized
INFO - 2023-08-16 09:32:29 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:29 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:29 --> Model Class Initialized
INFO - 2023-08-16 09:32:29 --> Final output sent to browser
DEBUG - 2023-08-16 09:32:29 --> Total execution time: 0.0271
ERROR - 2023-08-16 09:32:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:32:37 --> Config Class Initialized
INFO - 2023-08-16 09:32:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:32:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:32:37 --> Utf8 Class Initialized
INFO - 2023-08-16 09:32:37 --> URI Class Initialized
INFO - 2023-08-16 09:32:37 --> Router Class Initialized
INFO - 2023-08-16 09:32:37 --> Output Class Initialized
INFO - 2023-08-16 09:32:37 --> Security Class Initialized
DEBUG - 2023-08-16 09:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:32:37 --> Input Class Initialized
INFO - 2023-08-16 09:32:37 --> Language Class Initialized
INFO - 2023-08-16 09:32:37 --> Loader Class Initialized
INFO - 2023-08-16 09:32:37 --> Helper loaded: url_helper
INFO - 2023-08-16 09:32:37 --> Helper loaded: file_helper
INFO - 2023-08-16 09:32:37 --> Helper loaded: html_helper
INFO - 2023-08-16 09:32:37 --> Helper loaded: text_helper
INFO - 2023-08-16 09:32:37 --> Helper loaded: form_helper
INFO - 2023-08-16 09:32:37 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:32:37 --> Helper loaded: security_helper
INFO - 2023-08-16 09:32:37 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:32:37 --> Database Driver Class Initialized
INFO - 2023-08-16 09:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:32:37 --> Parser Class Initialized
INFO - 2023-08-16 09:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:32:37 --> Pagination Class Initialized
INFO - 2023-08-16 09:32:37 --> Form Validation Class Initialized
INFO - 2023-08-16 09:32:37 --> Controller Class Initialized
INFO - 2023-08-16 09:32:37 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:37 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:37 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 09:32:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:32:37 --> Model Class Initialized
INFO - 2023-08-16 09:32:37 --> Model Class Initialized
INFO - 2023-08-16 09:32:37 --> Model Class Initialized
INFO - 2023-08-16 09:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:32:37 --> Final output sent to browser
DEBUG - 2023-08-16 09:32:37 --> Total execution time: 0.0752
ERROR - 2023-08-16 09:32:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:32:48 --> Config Class Initialized
INFO - 2023-08-16 09:32:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:32:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:32:48 --> Utf8 Class Initialized
INFO - 2023-08-16 09:32:48 --> URI Class Initialized
INFO - 2023-08-16 09:32:48 --> Router Class Initialized
INFO - 2023-08-16 09:32:48 --> Output Class Initialized
INFO - 2023-08-16 09:32:48 --> Security Class Initialized
DEBUG - 2023-08-16 09:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:32:48 --> Input Class Initialized
INFO - 2023-08-16 09:32:48 --> Language Class Initialized
INFO - 2023-08-16 09:32:48 --> Loader Class Initialized
INFO - 2023-08-16 09:32:48 --> Helper loaded: url_helper
INFO - 2023-08-16 09:32:48 --> Helper loaded: file_helper
INFO - 2023-08-16 09:32:48 --> Helper loaded: html_helper
INFO - 2023-08-16 09:32:48 --> Helper loaded: text_helper
INFO - 2023-08-16 09:32:48 --> Helper loaded: form_helper
INFO - 2023-08-16 09:32:48 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:32:48 --> Helper loaded: security_helper
INFO - 2023-08-16 09:32:48 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:32:48 --> Database Driver Class Initialized
INFO - 2023-08-16 09:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:32:48 --> Parser Class Initialized
INFO - 2023-08-16 09:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:32:48 --> Pagination Class Initialized
INFO - 2023-08-16 09:32:48 --> Form Validation Class Initialized
INFO - 2023-08-16 09:32:48 --> Controller Class Initialized
INFO - 2023-08-16 09:32:48 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:48 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:48 --> Model Class Initialized
INFO - 2023-08-16 09:32:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 09:32:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:32:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:32:48 --> Model Class Initialized
INFO - 2023-08-16 09:32:48 --> Model Class Initialized
INFO - 2023-08-16 09:32:48 --> Model Class Initialized
INFO - 2023-08-16 09:32:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:32:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:32:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:32:48 --> Final output sent to browser
DEBUG - 2023-08-16 09:32:48 --> Total execution time: 0.0719
ERROR - 2023-08-16 09:32:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:32:53 --> Config Class Initialized
INFO - 2023-08-16 09:32:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:32:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:32:53 --> Utf8 Class Initialized
INFO - 2023-08-16 09:32:53 --> URI Class Initialized
INFO - 2023-08-16 09:32:53 --> Router Class Initialized
INFO - 2023-08-16 09:32:53 --> Output Class Initialized
INFO - 2023-08-16 09:32:53 --> Security Class Initialized
DEBUG - 2023-08-16 09:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:32:53 --> Input Class Initialized
INFO - 2023-08-16 09:32:53 --> Language Class Initialized
INFO - 2023-08-16 09:32:53 --> Loader Class Initialized
INFO - 2023-08-16 09:32:53 --> Helper loaded: url_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: file_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: html_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: text_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: form_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: security_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:32:53 --> Database Driver Class Initialized
INFO - 2023-08-16 09:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:32:53 --> Parser Class Initialized
INFO - 2023-08-16 09:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:32:53 --> Pagination Class Initialized
INFO - 2023-08-16 09:32:53 --> Form Validation Class Initialized
INFO - 2023-08-16 09:32:53 --> Controller Class Initialized
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
INFO - 2023-08-16 09:32:53 --> Final output sent to browser
DEBUG - 2023-08-16 09:32:53 --> Total execution time: 0.0263
ERROR - 2023-08-16 09:32:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 09:32:53 --> Config Class Initialized
INFO - 2023-08-16 09:32:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 09:32:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 09:32:53 --> Utf8 Class Initialized
INFO - 2023-08-16 09:32:53 --> URI Class Initialized
DEBUG - 2023-08-16 09:32:53 --> No URI present. Default controller set.
INFO - 2023-08-16 09:32:53 --> Router Class Initialized
INFO - 2023-08-16 09:32:53 --> Output Class Initialized
INFO - 2023-08-16 09:32:53 --> Security Class Initialized
DEBUG - 2023-08-16 09:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 09:32:53 --> Input Class Initialized
INFO - 2023-08-16 09:32:53 --> Language Class Initialized
INFO - 2023-08-16 09:32:53 --> Loader Class Initialized
INFO - 2023-08-16 09:32:53 --> Helper loaded: url_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: file_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: html_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: text_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: form_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: lang_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: security_helper
INFO - 2023-08-16 09:32:53 --> Helper loaded: cookie_helper
INFO - 2023-08-16 09:32:53 --> Database Driver Class Initialized
INFO - 2023-08-16 09:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 09:32:53 --> Parser Class Initialized
INFO - 2023-08-16 09:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 09:32:53 --> Pagination Class Initialized
INFO - 2023-08-16 09:32:53 --> Form Validation Class Initialized
INFO - 2023-08-16 09:32:53 --> Controller Class Initialized
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
DEBUG - 2023-08-16 09:32:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 09:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
INFO - 2023-08-16 09:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 09:32:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 09:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 09:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 09:32:53 --> Model Class Initialized
INFO - 2023-08-16 09:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 09:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 09:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 09:32:53 --> Final output sent to browser
DEBUG - 2023-08-16 09:32:53 --> Total execution time: 0.0813
ERROR - 2023-08-16 10:01:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 10:01:50 --> Config Class Initialized
INFO - 2023-08-16 10:01:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 10:01:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 10:01:50 --> Utf8 Class Initialized
INFO - 2023-08-16 10:01:50 --> URI Class Initialized
DEBUG - 2023-08-16 10:01:50 --> No URI present. Default controller set.
INFO - 2023-08-16 10:01:50 --> Router Class Initialized
INFO - 2023-08-16 10:01:50 --> Output Class Initialized
INFO - 2023-08-16 10:01:50 --> Security Class Initialized
DEBUG - 2023-08-16 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 10:01:50 --> Input Class Initialized
INFO - 2023-08-16 10:01:50 --> Language Class Initialized
INFO - 2023-08-16 10:01:50 --> Loader Class Initialized
INFO - 2023-08-16 10:01:50 --> Helper loaded: url_helper
INFO - 2023-08-16 10:01:50 --> Helper loaded: file_helper
INFO - 2023-08-16 10:01:50 --> Helper loaded: html_helper
INFO - 2023-08-16 10:01:50 --> Helper loaded: text_helper
INFO - 2023-08-16 10:01:50 --> Helper loaded: form_helper
INFO - 2023-08-16 10:01:50 --> Helper loaded: lang_helper
INFO - 2023-08-16 10:01:50 --> Helper loaded: security_helper
INFO - 2023-08-16 10:01:50 --> Helper loaded: cookie_helper
INFO - 2023-08-16 10:01:50 --> Database Driver Class Initialized
INFO - 2023-08-16 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 10:01:50 --> Parser Class Initialized
INFO - 2023-08-16 10:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 10:01:50 --> Pagination Class Initialized
INFO - 2023-08-16 10:01:50 --> Form Validation Class Initialized
INFO - 2023-08-16 10:01:50 --> Controller Class Initialized
INFO - 2023-08-16 10:01:50 --> Model Class Initialized
DEBUG - 2023-08-16 10:01:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 10:32:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 10:32:14 --> Config Class Initialized
INFO - 2023-08-16 10:32:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 10:32:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 10:32:14 --> Utf8 Class Initialized
INFO - 2023-08-16 10:32:14 --> URI Class Initialized
DEBUG - 2023-08-16 10:32:14 --> No URI present. Default controller set.
INFO - 2023-08-16 10:32:14 --> Router Class Initialized
INFO - 2023-08-16 10:32:14 --> Output Class Initialized
INFO - 2023-08-16 10:32:14 --> Security Class Initialized
DEBUG - 2023-08-16 10:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 10:32:14 --> Input Class Initialized
INFO - 2023-08-16 10:32:14 --> Language Class Initialized
INFO - 2023-08-16 10:32:14 --> Loader Class Initialized
INFO - 2023-08-16 10:32:14 --> Helper loaded: url_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: file_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: html_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: text_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: form_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: lang_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: security_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: cookie_helper
INFO - 2023-08-16 10:32:14 --> Database Driver Class Initialized
INFO - 2023-08-16 10:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 10:32:14 --> Parser Class Initialized
INFO - 2023-08-16 10:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 10:32:14 --> Pagination Class Initialized
INFO - 2023-08-16 10:32:14 --> Form Validation Class Initialized
INFO - 2023-08-16 10:32:14 --> Controller Class Initialized
INFO - 2023-08-16 10:32:14 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 10:32:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 10:32:14 --> Config Class Initialized
INFO - 2023-08-16 10:32:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 10:32:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 10:32:14 --> Utf8 Class Initialized
INFO - 2023-08-16 10:32:14 --> URI Class Initialized
INFO - 2023-08-16 10:32:14 --> Router Class Initialized
INFO - 2023-08-16 10:32:14 --> Output Class Initialized
INFO - 2023-08-16 10:32:14 --> Security Class Initialized
DEBUG - 2023-08-16 10:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 10:32:14 --> Input Class Initialized
INFO - 2023-08-16 10:32:14 --> Language Class Initialized
INFO - 2023-08-16 10:32:14 --> Loader Class Initialized
INFO - 2023-08-16 10:32:14 --> Helper loaded: url_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: file_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: html_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: text_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: form_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: lang_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: security_helper
INFO - 2023-08-16 10:32:14 --> Helper loaded: cookie_helper
INFO - 2023-08-16 10:32:14 --> Database Driver Class Initialized
INFO - 2023-08-16 10:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 10:32:14 --> Parser Class Initialized
INFO - 2023-08-16 10:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 10:32:14 --> Pagination Class Initialized
INFO - 2023-08-16 10:32:14 --> Form Validation Class Initialized
INFO - 2023-08-16 10:32:14 --> Controller Class Initialized
INFO - 2023-08-16 10:32:14 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 10:32:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 10:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 10:32:14 --> Model Class Initialized
INFO - 2023-08-16 10:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 10:32:14 --> Final output sent to browser
DEBUG - 2023-08-16 10:32:14 --> Total execution time: 0.0371
ERROR - 2023-08-16 10:32:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 10:32:23 --> Config Class Initialized
INFO - 2023-08-16 10:32:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 10:32:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 10:32:23 --> Utf8 Class Initialized
INFO - 2023-08-16 10:32:23 --> URI Class Initialized
INFO - 2023-08-16 10:32:23 --> Router Class Initialized
INFO - 2023-08-16 10:32:23 --> Output Class Initialized
INFO - 2023-08-16 10:32:23 --> Security Class Initialized
DEBUG - 2023-08-16 10:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 10:32:23 --> Input Class Initialized
INFO - 2023-08-16 10:32:23 --> Language Class Initialized
INFO - 2023-08-16 10:32:23 --> Loader Class Initialized
INFO - 2023-08-16 10:32:23 --> Helper loaded: url_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: file_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: html_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: text_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: form_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: lang_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: security_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: cookie_helper
INFO - 2023-08-16 10:32:23 --> Database Driver Class Initialized
INFO - 2023-08-16 10:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 10:32:23 --> Parser Class Initialized
INFO - 2023-08-16 10:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 10:32:23 --> Pagination Class Initialized
INFO - 2023-08-16 10:32:23 --> Form Validation Class Initialized
INFO - 2023-08-16 10:32:23 --> Controller Class Initialized
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
INFO - 2023-08-16 10:32:23 --> Final output sent to browser
DEBUG - 2023-08-16 10:32:23 --> Total execution time: 0.0188
ERROR - 2023-08-16 10:32:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 10:32:23 --> Config Class Initialized
INFO - 2023-08-16 10:32:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 10:32:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 10:32:23 --> Utf8 Class Initialized
INFO - 2023-08-16 10:32:23 --> URI Class Initialized
DEBUG - 2023-08-16 10:32:23 --> No URI present. Default controller set.
INFO - 2023-08-16 10:32:23 --> Router Class Initialized
INFO - 2023-08-16 10:32:23 --> Output Class Initialized
INFO - 2023-08-16 10:32:23 --> Security Class Initialized
DEBUG - 2023-08-16 10:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 10:32:23 --> Input Class Initialized
INFO - 2023-08-16 10:32:23 --> Language Class Initialized
INFO - 2023-08-16 10:32:23 --> Loader Class Initialized
INFO - 2023-08-16 10:32:23 --> Helper loaded: url_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: file_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: html_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: text_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: form_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: lang_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: security_helper
INFO - 2023-08-16 10:32:23 --> Helper loaded: cookie_helper
INFO - 2023-08-16 10:32:23 --> Database Driver Class Initialized
INFO - 2023-08-16 10:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 10:32:23 --> Parser Class Initialized
INFO - 2023-08-16 10:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 10:32:23 --> Pagination Class Initialized
INFO - 2023-08-16 10:32:23 --> Form Validation Class Initialized
INFO - 2023-08-16 10:32:23 --> Controller Class Initialized
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
INFO - 2023-08-16 10:32:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 10:32:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 10:32:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 10:32:23 --> Model Class Initialized
INFO - 2023-08-16 10:32:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 10:32:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 10:32:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 10:32:23 --> Final output sent to browser
DEBUG - 2023-08-16 10:32:23 --> Total execution time: 0.0799
ERROR - 2023-08-16 10:32:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 10:32:36 --> Config Class Initialized
INFO - 2023-08-16 10:32:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 10:32:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 10:32:36 --> Utf8 Class Initialized
INFO - 2023-08-16 10:32:36 --> URI Class Initialized
INFO - 2023-08-16 10:32:36 --> Router Class Initialized
INFO - 2023-08-16 10:32:36 --> Output Class Initialized
INFO - 2023-08-16 10:32:36 --> Security Class Initialized
DEBUG - 2023-08-16 10:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 10:32:36 --> Input Class Initialized
INFO - 2023-08-16 10:32:36 --> Language Class Initialized
INFO - 2023-08-16 10:32:36 --> Loader Class Initialized
INFO - 2023-08-16 10:32:36 --> Helper loaded: url_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: file_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: html_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: text_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: form_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: lang_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: security_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: cookie_helper
INFO - 2023-08-16 10:32:36 --> Database Driver Class Initialized
INFO - 2023-08-16 10:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 10:32:36 --> Parser Class Initialized
INFO - 2023-08-16 10:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 10:32:36 --> Pagination Class Initialized
INFO - 2023-08-16 10:32:36 --> Form Validation Class Initialized
INFO - 2023-08-16 10:32:36 --> Controller Class Initialized
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 10:32:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 10:32:36 --> Final output sent to browser
DEBUG - 2023-08-16 10:32:36 --> Total execution time: 0.0311
ERROR - 2023-08-16 10:32:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 10:32:36 --> Config Class Initialized
INFO - 2023-08-16 10:32:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 10:32:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 10:32:36 --> Utf8 Class Initialized
INFO - 2023-08-16 10:32:36 --> URI Class Initialized
INFO - 2023-08-16 10:32:36 --> Router Class Initialized
INFO - 2023-08-16 10:32:36 --> Output Class Initialized
INFO - 2023-08-16 10:32:36 --> Security Class Initialized
DEBUG - 2023-08-16 10:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 10:32:36 --> Input Class Initialized
INFO - 2023-08-16 10:32:36 --> Language Class Initialized
INFO - 2023-08-16 10:32:36 --> Loader Class Initialized
INFO - 2023-08-16 10:32:36 --> Helper loaded: url_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: file_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: html_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: text_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: form_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: lang_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: security_helper
INFO - 2023-08-16 10:32:36 --> Helper loaded: cookie_helper
INFO - 2023-08-16 10:32:36 --> Database Driver Class Initialized
INFO - 2023-08-16 10:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 10:32:36 --> Parser Class Initialized
INFO - 2023-08-16 10:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 10:32:36 --> Pagination Class Initialized
INFO - 2023-08-16 10:32:36 --> Form Validation Class Initialized
INFO - 2023-08-16 10:32:36 --> Controller Class Initialized
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
DEBUG - 2023-08-16 10:32:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 10:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 10:32:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 10:32:36 --> Model Class Initialized
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 10:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 10:32:36 --> Final output sent to browser
DEBUG - 2023-08-16 10:32:36 --> Total execution time: 0.0796
ERROR - 2023-08-16 11:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 11:19:59 --> Config Class Initialized
INFO - 2023-08-16 11:19:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 11:19:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 11:19:59 --> Utf8 Class Initialized
INFO - 2023-08-16 11:19:59 --> URI Class Initialized
DEBUG - 2023-08-16 11:19:59 --> No URI present. Default controller set.
INFO - 2023-08-16 11:19:59 --> Router Class Initialized
INFO - 2023-08-16 11:19:59 --> Output Class Initialized
INFO - 2023-08-16 11:19:59 --> Security Class Initialized
DEBUG - 2023-08-16 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 11:19:59 --> Input Class Initialized
INFO - 2023-08-16 11:19:59 --> Language Class Initialized
INFO - 2023-08-16 11:19:59 --> Loader Class Initialized
INFO - 2023-08-16 11:19:59 --> Helper loaded: url_helper
INFO - 2023-08-16 11:19:59 --> Helper loaded: file_helper
INFO - 2023-08-16 11:19:59 --> Helper loaded: html_helper
INFO - 2023-08-16 11:19:59 --> Helper loaded: text_helper
INFO - 2023-08-16 11:19:59 --> Helper loaded: form_helper
INFO - 2023-08-16 11:19:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 11:19:59 --> Helper loaded: security_helper
INFO - 2023-08-16 11:19:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 11:19:59 --> Database Driver Class Initialized
INFO - 2023-08-16 11:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 11:19:59 --> Parser Class Initialized
INFO - 2023-08-16 11:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 11:19:59 --> Pagination Class Initialized
INFO - 2023-08-16 11:19:59 --> Form Validation Class Initialized
INFO - 2023-08-16 11:19:59 --> Controller Class Initialized
INFO - 2023-08-16 11:19:59 --> Model Class Initialized
DEBUG - 2023-08-16 11:19:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 11:20:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 11:20:00 --> Config Class Initialized
INFO - 2023-08-16 11:20:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 11:20:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 11:20:00 --> Utf8 Class Initialized
INFO - 2023-08-16 11:20:00 --> URI Class Initialized
INFO - 2023-08-16 11:20:00 --> Router Class Initialized
INFO - 2023-08-16 11:20:00 --> Output Class Initialized
INFO - 2023-08-16 11:20:00 --> Security Class Initialized
DEBUG - 2023-08-16 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 11:20:00 --> Input Class Initialized
INFO - 2023-08-16 11:20:00 --> Language Class Initialized
INFO - 2023-08-16 11:20:00 --> Loader Class Initialized
INFO - 2023-08-16 11:20:00 --> Helper loaded: url_helper
INFO - 2023-08-16 11:20:00 --> Helper loaded: file_helper
INFO - 2023-08-16 11:20:00 --> Helper loaded: html_helper
INFO - 2023-08-16 11:20:00 --> Helper loaded: text_helper
INFO - 2023-08-16 11:20:00 --> Helper loaded: form_helper
INFO - 2023-08-16 11:20:00 --> Helper loaded: lang_helper
INFO - 2023-08-16 11:20:00 --> Helper loaded: security_helper
INFO - 2023-08-16 11:20:00 --> Helper loaded: cookie_helper
INFO - 2023-08-16 11:20:00 --> Database Driver Class Initialized
INFO - 2023-08-16 11:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 11:20:00 --> Parser Class Initialized
INFO - 2023-08-16 11:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 11:20:00 --> Pagination Class Initialized
INFO - 2023-08-16 11:20:00 --> Form Validation Class Initialized
INFO - 2023-08-16 11:20:00 --> Controller Class Initialized
INFO - 2023-08-16 11:20:00 --> Model Class Initialized
DEBUG - 2023-08-16 11:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 11:20:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 11:20:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 11:20:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 11:20:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 11:20:00 --> Model Class Initialized
INFO - 2023-08-16 11:20:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 11:20:00 --> Final output sent to browser
DEBUG - 2023-08-16 11:20:00 --> Total execution time: 0.0317
ERROR - 2023-08-16 14:03:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:03:42 --> Config Class Initialized
INFO - 2023-08-16 14:03:42 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:03:42 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:03:42 --> Utf8 Class Initialized
INFO - 2023-08-16 14:03:42 --> URI Class Initialized
DEBUG - 2023-08-16 14:03:42 --> No URI present. Default controller set.
INFO - 2023-08-16 14:03:42 --> Router Class Initialized
INFO - 2023-08-16 14:03:42 --> Output Class Initialized
INFO - 2023-08-16 14:03:42 --> Security Class Initialized
DEBUG - 2023-08-16 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:03:42 --> Input Class Initialized
INFO - 2023-08-16 14:03:42 --> Language Class Initialized
INFO - 2023-08-16 14:03:42 --> Loader Class Initialized
INFO - 2023-08-16 14:03:42 --> Helper loaded: url_helper
INFO - 2023-08-16 14:03:42 --> Helper loaded: file_helper
INFO - 2023-08-16 14:03:42 --> Helper loaded: html_helper
INFO - 2023-08-16 14:03:42 --> Helper loaded: text_helper
INFO - 2023-08-16 14:03:42 --> Helper loaded: form_helper
INFO - 2023-08-16 14:03:42 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:03:42 --> Helper loaded: security_helper
INFO - 2023-08-16 14:03:42 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:03:42 --> Database Driver Class Initialized
INFO - 2023-08-16 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:03:42 --> Parser Class Initialized
INFO - 2023-08-16 14:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:03:42 --> Pagination Class Initialized
INFO - 2023-08-16 14:03:42 --> Form Validation Class Initialized
INFO - 2023-08-16 14:03:42 --> Controller Class Initialized
INFO - 2023-08-16 14:03:42 --> Model Class Initialized
DEBUG - 2023-08-16 14:03:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 14:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:10:51 --> Config Class Initialized
INFO - 2023-08-16 14:10:51 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:10:51 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:10:51 --> Utf8 Class Initialized
INFO - 2023-08-16 14:10:51 --> URI Class Initialized
DEBUG - 2023-08-16 14:10:51 --> No URI present. Default controller set.
INFO - 2023-08-16 14:10:51 --> Router Class Initialized
INFO - 2023-08-16 14:10:51 --> Output Class Initialized
INFO - 2023-08-16 14:10:51 --> Security Class Initialized
DEBUG - 2023-08-16 14:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:10:51 --> Input Class Initialized
INFO - 2023-08-16 14:10:51 --> Language Class Initialized
INFO - 2023-08-16 14:10:51 --> Loader Class Initialized
INFO - 2023-08-16 14:10:51 --> Helper loaded: url_helper
INFO - 2023-08-16 14:10:51 --> Helper loaded: file_helper
INFO - 2023-08-16 14:10:51 --> Helper loaded: html_helper
INFO - 2023-08-16 14:10:51 --> Helper loaded: text_helper
INFO - 2023-08-16 14:10:51 --> Helper loaded: form_helper
INFO - 2023-08-16 14:10:51 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:10:51 --> Helper loaded: security_helper
INFO - 2023-08-16 14:10:51 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:10:51 --> Database Driver Class Initialized
INFO - 2023-08-16 14:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:10:51 --> Parser Class Initialized
INFO - 2023-08-16 14:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:10:51 --> Pagination Class Initialized
INFO - 2023-08-16 14:10:51 --> Form Validation Class Initialized
INFO - 2023-08-16 14:10:51 --> Controller Class Initialized
INFO - 2023-08-16 14:10:51 --> Model Class Initialized
DEBUG - 2023-08-16 14:10:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 14:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:10:52 --> Config Class Initialized
INFO - 2023-08-16 14:10:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:10:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:10:52 --> Utf8 Class Initialized
INFO - 2023-08-16 14:10:52 --> URI Class Initialized
INFO - 2023-08-16 14:10:52 --> Router Class Initialized
INFO - 2023-08-16 14:10:52 --> Output Class Initialized
INFO - 2023-08-16 14:10:52 --> Security Class Initialized
DEBUG - 2023-08-16 14:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:10:52 --> Input Class Initialized
INFO - 2023-08-16 14:10:52 --> Language Class Initialized
INFO - 2023-08-16 14:10:52 --> Loader Class Initialized
INFO - 2023-08-16 14:10:52 --> Helper loaded: url_helper
INFO - 2023-08-16 14:10:52 --> Helper loaded: file_helper
INFO - 2023-08-16 14:10:52 --> Helper loaded: html_helper
INFO - 2023-08-16 14:10:52 --> Helper loaded: text_helper
INFO - 2023-08-16 14:10:52 --> Helper loaded: form_helper
INFO - 2023-08-16 14:10:52 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:10:52 --> Helper loaded: security_helper
INFO - 2023-08-16 14:10:52 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:10:52 --> Database Driver Class Initialized
INFO - 2023-08-16 14:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:10:52 --> Parser Class Initialized
INFO - 2023-08-16 14:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:10:52 --> Pagination Class Initialized
INFO - 2023-08-16 14:10:52 --> Form Validation Class Initialized
INFO - 2023-08-16 14:10:52 --> Controller Class Initialized
INFO - 2023-08-16 14:10:52 --> Model Class Initialized
DEBUG - 2023-08-16 14:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 14:10:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 14:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 14:10:52 --> Model Class Initialized
INFO - 2023-08-16 14:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 14:10:52 --> Final output sent to browser
DEBUG - 2023-08-16 14:10:52 --> Total execution time: 0.0433
ERROR - 2023-08-16 14:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:10:52 --> Config Class Initialized
INFO - 2023-08-16 14:10:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:10:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:10:52 --> Utf8 Class Initialized
INFO - 2023-08-16 14:10:52 --> URI Class Initialized
INFO - 2023-08-16 14:10:52 --> Router Class Initialized
INFO - 2023-08-16 14:10:52 --> Output Class Initialized
INFO - 2023-08-16 14:10:52 --> Security Class Initialized
DEBUG - 2023-08-16 14:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:10:52 --> Input Class Initialized
INFO - 2023-08-16 14:10:52 --> Language Class Initialized
ERROR - 2023-08-16 14:10:52 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-08-16 14:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:10:52 --> Config Class Initialized
INFO - 2023-08-16 14:10:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:10:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:10:52 --> Utf8 Class Initialized
INFO - 2023-08-16 14:10:52 --> URI Class Initialized
INFO - 2023-08-16 14:10:52 --> Router Class Initialized
INFO - 2023-08-16 14:10:52 --> Output Class Initialized
INFO - 2023-08-16 14:10:52 --> Security Class Initialized
DEBUG - 2023-08-16 14:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:10:52 --> Input Class Initialized
INFO - 2023-08-16 14:10:52 --> Language Class Initialized
ERROR - 2023-08-16 14:10:52 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-08-16 14:10:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:10:56 --> Config Class Initialized
INFO - 2023-08-16 14:10:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:10:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:10:56 --> Utf8 Class Initialized
INFO - 2023-08-16 14:10:56 --> URI Class Initialized
INFO - 2023-08-16 14:10:56 --> Router Class Initialized
INFO - 2023-08-16 14:10:56 --> Output Class Initialized
INFO - 2023-08-16 14:10:56 --> Security Class Initialized
DEBUG - 2023-08-16 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:10:56 --> Input Class Initialized
INFO - 2023-08-16 14:10:56 --> Language Class Initialized
INFO - 2023-08-16 14:10:56 --> Loader Class Initialized
INFO - 2023-08-16 14:10:56 --> Helper loaded: url_helper
INFO - 2023-08-16 14:10:56 --> Helper loaded: file_helper
INFO - 2023-08-16 14:10:56 --> Helper loaded: html_helper
INFO - 2023-08-16 14:10:56 --> Helper loaded: text_helper
INFO - 2023-08-16 14:10:56 --> Helper loaded: form_helper
INFO - 2023-08-16 14:10:56 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:10:56 --> Helper loaded: security_helper
INFO - 2023-08-16 14:10:56 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:10:56 --> Database Driver Class Initialized
INFO - 2023-08-16 14:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:10:57 --> Parser Class Initialized
INFO - 2023-08-16 14:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:10:57 --> Pagination Class Initialized
INFO - 2023-08-16 14:10:57 --> Form Validation Class Initialized
INFO - 2023-08-16 14:10:57 --> Controller Class Initialized
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
DEBUG - 2023-08-16 14:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
INFO - 2023-08-16 14:10:57 --> Final output sent to browser
DEBUG - 2023-08-16 14:10:57 --> Total execution time: 0.0221
ERROR - 2023-08-16 14:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:10:57 --> Config Class Initialized
INFO - 2023-08-16 14:10:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:10:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:10:57 --> Utf8 Class Initialized
INFO - 2023-08-16 14:10:57 --> URI Class Initialized
DEBUG - 2023-08-16 14:10:57 --> No URI present. Default controller set.
INFO - 2023-08-16 14:10:57 --> Router Class Initialized
INFO - 2023-08-16 14:10:57 --> Output Class Initialized
INFO - 2023-08-16 14:10:57 --> Security Class Initialized
DEBUG - 2023-08-16 14:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:10:57 --> Input Class Initialized
INFO - 2023-08-16 14:10:57 --> Language Class Initialized
INFO - 2023-08-16 14:10:57 --> Loader Class Initialized
INFO - 2023-08-16 14:10:57 --> Helper loaded: url_helper
INFO - 2023-08-16 14:10:57 --> Helper loaded: file_helper
INFO - 2023-08-16 14:10:57 --> Helper loaded: html_helper
INFO - 2023-08-16 14:10:57 --> Helper loaded: text_helper
INFO - 2023-08-16 14:10:57 --> Helper loaded: form_helper
INFO - 2023-08-16 14:10:57 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:10:57 --> Helper loaded: security_helper
INFO - 2023-08-16 14:10:57 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:10:57 --> Database Driver Class Initialized
INFO - 2023-08-16 14:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:10:57 --> Parser Class Initialized
INFO - 2023-08-16 14:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:10:57 --> Pagination Class Initialized
INFO - 2023-08-16 14:10:57 --> Form Validation Class Initialized
INFO - 2023-08-16 14:10:57 --> Controller Class Initialized
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
DEBUG - 2023-08-16 14:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
DEBUG - 2023-08-16 14:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
DEBUG - 2023-08-16 14:10:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 14:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
INFO - 2023-08-16 14:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 14:10:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 14:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 14:10:57 --> Model Class Initialized
INFO - 2023-08-16 14:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 14:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 14:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 14:10:57 --> Final output sent to browser
DEBUG - 2023-08-16 14:10:57 --> Total execution time: 0.0921
ERROR - 2023-08-16 14:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:11:01 --> Config Class Initialized
INFO - 2023-08-16 14:11:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:11:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:11:01 --> Utf8 Class Initialized
INFO - 2023-08-16 14:11:01 --> URI Class Initialized
DEBUG - 2023-08-16 14:11:01 --> No URI present. Default controller set.
INFO - 2023-08-16 14:11:01 --> Router Class Initialized
INFO - 2023-08-16 14:11:01 --> Output Class Initialized
INFO - 2023-08-16 14:11:01 --> Security Class Initialized
DEBUG - 2023-08-16 14:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:11:01 --> Input Class Initialized
INFO - 2023-08-16 14:11:01 --> Language Class Initialized
INFO - 2023-08-16 14:11:01 --> Loader Class Initialized
INFO - 2023-08-16 14:11:01 --> Helper loaded: url_helper
INFO - 2023-08-16 14:11:01 --> Helper loaded: file_helper
INFO - 2023-08-16 14:11:01 --> Helper loaded: html_helper
INFO - 2023-08-16 14:11:01 --> Helper loaded: text_helper
INFO - 2023-08-16 14:11:01 --> Helper loaded: form_helper
INFO - 2023-08-16 14:11:01 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:11:01 --> Helper loaded: security_helper
INFO - 2023-08-16 14:11:01 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:11:01 --> Database Driver Class Initialized
INFO - 2023-08-16 14:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:11:01 --> Parser Class Initialized
INFO - 2023-08-16 14:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:11:01 --> Pagination Class Initialized
INFO - 2023-08-16 14:11:01 --> Form Validation Class Initialized
INFO - 2023-08-16 14:11:01 --> Controller Class Initialized
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 14:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
INFO - 2023-08-16 14:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 14:11:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 14:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 14:11:01 --> Model Class Initialized
INFO - 2023-08-16 14:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 14:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 14:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 14:11:01 --> Final output sent to browser
DEBUG - 2023-08-16 14:11:01 --> Total execution time: 0.0999
ERROR - 2023-08-16 14:11:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:11:08 --> Config Class Initialized
INFO - 2023-08-16 14:11:08 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:11:08 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:11:08 --> Utf8 Class Initialized
INFO - 2023-08-16 14:11:08 --> URI Class Initialized
INFO - 2023-08-16 14:11:08 --> Router Class Initialized
INFO - 2023-08-16 14:11:08 --> Output Class Initialized
INFO - 2023-08-16 14:11:08 --> Security Class Initialized
DEBUG - 2023-08-16 14:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:11:08 --> Input Class Initialized
INFO - 2023-08-16 14:11:08 --> Language Class Initialized
INFO - 2023-08-16 14:11:08 --> Loader Class Initialized
INFO - 2023-08-16 14:11:08 --> Helper loaded: url_helper
INFO - 2023-08-16 14:11:08 --> Helper loaded: file_helper
INFO - 2023-08-16 14:11:08 --> Helper loaded: html_helper
INFO - 2023-08-16 14:11:08 --> Helper loaded: text_helper
INFO - 2023-08-16 14:11:08 --> Helper loaded: form_helper
INFO - 2023-08-16 14:11:08 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:11:08 --> Helper loaded: security_helper
INFO - 2023-08-16 14:11:08 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:11:08 --> Database Driver Class Initialized
INFO - 2023-08-16 14:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:11:08 --> Parser Class Initialized
INFO - 2023-08-16 14:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:11:08 --> Pagination Class Initialized
INFO - 2023-08-16 14:11:08 --> Form Validation Class Initialized
INFO - 2023-08-16 14:11:08 --> Controller Class Initialized
INFO - 2023-08-16 14:11:08 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 14:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:08 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:08 --> Model Class Initialized
INFO - 2023-08-16 14:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-16 14:11:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 14:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 14:11:08 --> Model Class Initialized
INFO - 2023-08-16 14:11:08 --> Model Class Initialized
INFO - 2023-08-16 14:11:08 --> Model Class Initialized
INFO - 2023-08-16 14:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 14:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 14:11:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 14:11:08 --> Final output sent to browser
DEBUG - 2023-08-16 14:11:08 --> Total execution time: 0.0794
ERROR - 2023-08-16 14:11:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:11:09 --> Config Class Initialized
INFO - 2023-08-16 14:11:09 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:11:09 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:11:09 --> Utf8 Class Initialized
INFO - 2023-08-16 14:11:09 --> URI Class Initialized
INFO - 2023-08-16 14:11:09 --> Router Class Initialized
INFO - 2023-08-16 14:11:09 --> Output Class Initialized
INFO - 2023-08-16 14:11:09 --> Security Class Initialized
DEBUG - 2023-08-16 14:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:11:09 --> Input Class Initialized
INFO - 2023-08-16 14:11:09 --> Language Class Initialized
INFO - 2023-08-16 14:11:09 --> Loader Class Initialized
INFO - 2023-08-16 14:11:09 --> Helper loaded: url_helper
INFO - 2023-08-16 14:11:09 --> Helper loaded: file_helper
INFO - 2023-08-16 14:11:09 --> Helper loaded: html_helper
INFO - 2023-08-16 14:11:09 --> Helper loaded: text_helper
INFO - 2023-08-16 14:11:09 --> Helper loaded: form_helper
INFO - 2023-08-16 14:11:09 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:11:09 --> Helper loaded: security_helper
INFO - 2023-08-16 14:11:09 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:11:09 --> Database Driver Class Initialized
INFO - 2023-08-16 14:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:11:09 --> Parser Class Initialized
INFO - 2023-08-16 14:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:11:09 --> Pagination Class Initialized
INFO - 2023-08-16 14:11:09 --> Form Validation Class Initialized
INFO - 2023-08-16 14:11:09 --> Controller Class Initialized
INFO - 2023-08-16 14:11:09 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 14:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:09 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:09 --> Model Class Initialized
INFO - 2023-08-16 14:11:09 --> Final output sent to browser
DEBUG - 2023-08-16 14:11:09 --> Total execution time: 0.0262
ERROR - 2023-08-16 14:11:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:11:13 --> Config Class Initialized
INFO - 2023-08-16 14:11:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:11:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:11:13 --> Utf8 Class Initialized
INFO - 2023-08-16 14:11:13 --> URI Class Initialized
INFO - 2023-08-16 14:11:13 --> Router Class Initialized
INFO - 2023-08-16 14:11:13 --> Output Class Initialized
INFO - 2023-08-16 14:11:13 --> Security Class Initialized
DEBUG - 2023-08-16 14:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:11:13 --> Input Class Initialized
INFO - 2023-08-16 14:11:13 --> Language Class Initialized
INFO - 2023-08-16 14:11:13 --> Loader Class Initialized
INFO - 2023-08-16 14:11:13 --> Helper loaded: url_helper
INFO - 2023-08-16 14:11:13 --> Helper loaded: file_helper
INFO - 2023-08-16 14:11:13 --> Helper loaded: html_helper
INFO - 2023-08-16 14:11:13 --> Helper loaded: text_helper
INFO - 2023-08-16 14:11:13 --> Helper loaded: form_helper
INFO - 2023-08-16 14:11:13 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:11:13 --> Helper loaded: security_helper
INFO - 2023-08-16 14:11:13 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:11:13 --> Database Driver Class Initialized
INFO - 2023-08-16 14:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:11:13 --> Parser Class Initialized
INFO - 2023-08-16 14:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:11:13 --> Pagination Class Initialized
INFO - 2023-08-16 14:11:13 --> Form Validation Class Initialized
INFO - 2023-08-16 14:11:13 --> Controller Class Initialized
INFO - 2023-08-16 14:11:13 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 14:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:13 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:13 --> Model Class Initialized
INFO - 2023-08-16 14:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 14:11:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 14:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 14:11:13 --> Model Class Initialized
INFO - 2023-08-16 14:11:13 --> Model Class Initialized
INFO - 2023-08-16 14:11:13 --> Model Class Initialized
INFO - 2023-08-16 14:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 14:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 14:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 14:11:13 --> Final output sent to browser
DEBUG - 2023-08-16 14:11:13 --> Total execution time: 0.0786
ERROR - 2023-08-16 14:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 14:11:14 --> Config Class Initialized
INFO - 2023-08-16 14:11:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 14:11:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 14:11:14 --> Utf8 Class Initialized
INFO - 2023-08-16 14:11:14 --> URI Class Initialized
INFO - 2023-08-16 14:11:14 --> Router Class Initialized
INFO - 2023-08-16 14:11:14 --> Output Class Initialized
INFO - 2023-08-16 14:11:14 --> Security Class Initialized
DEBUG - 2023-08-16 14:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 14:11:14 --> Input Class Initialized
INFO - 2023-08-16 14:11:14 --> Language Class Initialized
INFO - 2023-08-16 14:11:14 --> Loader Class Initialized
INFO - 2023-08-16 14:11:14 --> Helper loaded: url_helper
INFO - 2023-08-16 14:11:14 --> Helper loaded: file_helper
INFO - 2023-08-16 14:11:14 --> Helper loaded: html_helper
INFO - 2023-08-16 14:11:14 --> Helper loaded: text_helper
INFO - 2023-08-16 14:11:14 --> Helper loaded: form_helper
INFO - 2023-08-16 14:11:14 --> Helper loaded: lang_helper
INFO - 2023-08-16 14:11:14 --> Helper loaded: security_helper
INFO - 2023-08-16 14:11:14 --> Helper loaded: cookie_helper
INFO - 2023-08-16 14:11:14 --> Database Driver Class Initialized
INFO - 2023-08-16 14:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 14:11:14 --> Parser Class Initialized
INFO - 2023-08-16 14:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 14:11:14 --> Pagination Class Initialized
INFO - 2023-08-16 14:11:14 --> Form Validation Class Initialized
INFO - 2023-08-16 14:11:14 --> Controller Class Initialized
INFO - 2023-08-16 14:11:14 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 14:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:14 --> Model Class Initialized
DEBUG - 2023-08-16 14:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 14:11:14 --> Model Class Initialized
INFO - 2023-08-16 14:11:14 --> Final output sent to browser
DEBUG - 2023-08-16 14:11:14 --> Total execution time: 0.0426
ERROR - 2023-08-16 15:50:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 15:50:06 --> Config Class Initialized
INFO - 2023-08-16 15:50:06 --> Hooks Class Initialized
DEBUG - 2023-08-16 15:50:06 --> UTF-8 Support Enabled
INFO - 2023-08-16 15:50:06 --> Utf8 Class Initialized
INFO - 2023-08-16 15:50:06 --> URI Class Initialized
DEBUG - 2023-08-16 15:50:06 --> No URI present. Default controller set.
INFO - 2023-08-16 15:50:06 --> Router Class Initialized
INFO - 2023-08-16 15:50:06 --> Output Class Initialized
INFO - 2023-08-16 15:50:06 --> Security Class Initialized
DEBUG - 2023-08-16 15:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 15:50:06 --> Input Class Initialized
INFO - 2023-08-16 15:50:06 --> Language Class Initialized
INFO - 2023-08-16 15:50:06 --> Loader Class Initialized
INFO - 2023-08-16 15:50:06 --> Helper loaded: url_helper
INFO - 2023-08-16 15:50:06 --> Helper loaded: file_helper
INFO - 2023-08-16 15:50:06 --> Helper loaded: html_helper
INFO - 2023-08-16 15:50:06 --> Helper loaded: text_helper
INFO - 2023-08-16 15:50:06 --> Helper loaded: form_helper
INFO - 2023-08-16 15:50:06 --> Helper loaded: lang_helper
INFO - 2023-08-16 15:50:06 --> Helper loaded: security_helper
INFO - 2023-08-16 15:50:06 --> Helper loaded: cookie_helper
INFO - 2023-08-16 15:50:06 --> Database Driver Class Initialized
INFO - 2023-08-16 15:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 15:50:06 --> Parser Class Initialized
INFO - 2023-08-16 15:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 15:50:06 --> Pagination Class Initialized
INFO - 2023-08-16 15:50:06 --> Form Validation Class Initialized
INFO - 2023-08-16 15:50:06 --> Controller Class Initialized
INFO - 2023-08-16 15:50:06 --> Model Class Initialized
DEBUG - 2023-08-16 15:50:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 15:50:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 15:50:07 --> Config Class Initialized
INFO - 2023-08-16 15:50:07 --> Hooks Class Initialized
DEBUG - 2023-08-16 15:50:07 --> UTF-8 Support Enabled
INFO - 2023-08-16 15:50:07 --> Utf8 Class Initialized
INFO - 2023-08-16 15:50:07 --> URI Class Initialized
INFO - 2023-08-16 15:50:07 --> Router Class Initialized
INFO - 2023-08-16 15:50:07 --> Output Class Initialized
INFO - 2023-08-16 15:50:07 --> Security Class Initialized
DEBUG - 2023-08-16 15:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 15:50:07 --> Input Class Initialized
INFO - 2023-08-16 15:50:07 --> Language Class Initialized
INFO - 2023-08-16 15:50:07 --> Loader Class Initialized
INFO - 2023-08-16 15:50:07 --> Helper loaded: url_helper
INFO - 2023-08-16 15:50:07 --> Helper loaded: file_helper
INFO - 2023-08-16 15:50:07 --> Helper loaded: html_helper
INFO - 2023-08-16 15:50:07 --> Helper loaded: text_helper
INFO - 2023-08-16 15:50:07 --> Helper loaded: form_helper
INFO - 2023-08-16 15:50:07 --> Helper loaded: lang_helper
INFO - 2023-08-16 15:50:07 --> Helper loaded: security_helper
INFO - 2023-08-16 15:50:07 --> Helper loaded: cookie_helper
INFO - 2023-08-16 15:50:07 --> Database Driver Class Initialized
INFO - 2023-08-16 15:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 15:50:07 --> Parser Class Initialized
INFO - 2023-08-16 15:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 15:50:07 --> Pagination Class Initialized
INFO - 2023-08-16 15:50:07 --> Form Validation Class Initialized
INFO - 2023-08-16 15:50:07 --> Controller Class Initialized
INFO - 2023-08-16 15:50:07 --> Model Class Initialized
DEBUG - 2023-08-16 15:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 15:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 15:50:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 15:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 15:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 15:50:07 --> Model Class Initialized
INFO - 2023-08-16 15:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 15:50:07 --> Final output sent to browser
DEBUG - 2023-08-16 15:50:07 --> Total execution time: 0.0349
ERROR - 2023-08-16 16:46:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:11 --> Config Class Initialized
INFO - 2023-08-16 16:46:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:11 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:11 --> URI Class Initialized
DEBUG - 2023-08-16 16:46:11 --> No URI present. Default controller set.
INFO - 2023-08-16 16:46:11 --> Router Class Initialized
INFO - 2023-08-16 16:46:11 --> Output Class Initialized
INFO - 2023-08-16 16:46:11 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:11 --> Input Class Initialized
INFO - 2023-08-16 16:46:11 --> Language Class Initialized
INFO - 2023-08-16 16:46:11 --> Loader Class Initialized
INFO - 2023-08-16 16:46:11 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:11 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:11 --> Parser Class Initialized
INFO - 2023-08-16 16:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:11 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:11 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:11 --> Controller Class Initialized
INFO - 2023-08-16 16:46:11 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 16:46:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:11 --> Config Class Initialized
INFO - 2023-08-16 16:46:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:11 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:11 --> URI Class Initialized
INFO - 2023-08-16 16:46:11 --> Router Class Initialized
INFO - 2023-08-16 16:46:11 --> Output Class Initialized
INFO - 2023-08-16 16:46:11 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:11 --> Input Class Initialized
INFO - 2023-08-16 16:46:11 --> Language Class Initialized
INFO - 2023-08-16 16:46:11 --> Loader Class Initialized
INFO - 2023-08-16 16:46:11 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:11 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:11 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:11 --> Parser Class Initialized
INFO - 2023-08-16 16:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:11 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:11 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:11 --> Controller Class Initialized
INFO - 2023-08-16 16:46:11 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 16:46:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 16:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 16:46:11 --> Model Class Initialized
INFO - 2023-08-16 16:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 16:46:11 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:11 --> Total execution time: 0.0323
ERROR - 2023-08-16 16:46:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:15 --> Config Class Initialized
INFO - 2023-08-16 16:46:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:15 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:15 --> URI Class Initialized
INFO - 2023-08-16 16:46:15 --> Router Class Initialized
INFO - 2023-08-16 16:46:15 --> Output Class Initialized
INFO - 2023-08-16 16:46:15 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:15 --> Input Class Initialized
INFO - 2023-08-16 16:46:15 --> Language Class Initialized
INFO - 2023-08-16 16:46:15 --> Loader Class Initialized
INFO - 2023-08-16 16:46:15 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:15 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:15 --> Parser Class Initialized
INFO - 2023-08-16 16:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:15 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:15 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:15 --> Controller Class Initialized
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
INFO - 2023-08-16 16:46:15 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:15 --> Total execution time: 0.0193
ERROR - 2023-08-16 16:46:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:15 --> Config Class Initialized
INFO - 2023-08-16 16:46:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:15 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:15 --> URI Class Initialized
DEBUG - 2023-08-16 16:46:15 --> No URI present. Default controller set.
INFO - 2023-08-16 16:46:15 --> Router Class Initialized
INFO - 2023-08-16 16:46:15 --> Output Class Initialized
INFO - 2023-08-16 16:46:15 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:15 --> Input Class Initialized
INFO - 2023-08-16 16:46:15 --> Language Class Initialized
INFO - 2023-08-16 16:46:15 --> Loader Class Initialized
INFO - 2023-08-16 16:46:15 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:15 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:15 --> Parser Class Initialized
INFO - 2023-08-16 16:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:15 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:15 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:15 --> Controller Class Initialized
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
INFO - 2023-08-16 16:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 16:46:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 16:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 16:46:15 --> Model Class Initialized
INFO - 2023-08-16 16:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 16:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 16:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 16:46:15 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:15 --> Total execution time: 0.2005
ERROR - 2023-08-16 16:46:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:16 --> Config Class Initialized
INFO - 2023-08-16 16:46:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:16 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:16 --> URI Class Initialized
INFO - 2023-08-16 16:46:16 --> Router Class Initialized
INFO - 2023-08-16 16:46:16 --> Output Class Initialized
INFO - 2023-08-16 16:46:16 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:16 --> Input Class Initialized
INFO - 2023-08-16 16:46:16 --> Language Class Initialized
INFO - 2023-08-16 16:46:16 --> Loader Class Initialized
INFO - 2023-08-16 16:46:16 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:16 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:16 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:16 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:16 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:16 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:16 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:16 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:16 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:16 --> Parser Class Initialized
INFO - 2023-08-16 16:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:16 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:16 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:16 --> Controller Class Initialized
DEBUG - 2023-08-16 16:46:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:16 --> Model Class Initialized
INFO - 2023-08-16 16:46:16 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:16 --> Total execution time: 0.0141
ERROR - 2023-08-16 16:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:19 --> Config Class Initialized
INFO - 2023-08-16 16:46:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:19 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:19 --> URI Class Initialized
INFO - 2023-08-16 16:46:19 --> Router Class Initialized
INFO - 2023-08-16 16:46:19 --> Output Class Initialized
INFO - 2023-08-16 16:46:19 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:19 --> Input Class Initialized
INFO - 2023-08-16 16:46:19 --> Language Class Initialized
INFO - 2023-08-16 16:46:19 --> Loader Class Initialized
INFO - 2023-08-16 16:46:19 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:19 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:19 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:19 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:19 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:19 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:19 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:19 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:19 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:19 --> Parser Class Initialized
INFO - 2023-08-16 16:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:19 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:19 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:19 --> Controller Class Initialized
INFO - 2023-08-16 16:46:19 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:19 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:19 --> Model Class Initialized
INFO - 2023-08-16 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 16:46:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 16:46:19 --> Model Class Initialized
INFO - 2023-08-16 16:46:19 --> Model Class Initialized
INFO - 2023-08-16 16:46:19 --> Model Class Initialized
INFO - 2023-08-16 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 16:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 16:46:19 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:19 --> Total execution time: 0.1337
ERROR - 2023-08-16 16:46:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:20 --> Config Class Initialized
INFO - 2023-08-16 16:46:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:20 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:20 --> URI Class Initialized
INFO - 2023-08-16 16:46:20 --> Router Class Initialized
INFO - 2023-08-16 16:46:20 --> Output Class Initialized
INFO - 2023-08-16 16:46:20 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:20 --> Input Class Initialized
INFO - 2023-08-16 16:46:20 --> Language Class Initialized
INFO - 2023-08-16 16:46:20 --> Loader Class Initialized
INFO - 2023-08-16 16:46:20 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:20 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:20 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:20 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:20 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:20 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:20 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:20 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:20 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:20 --> Parser Class Initialized
INFO - 2023-08-16 16:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:20 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:20 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:20 --> Controller Class Initialized
INFO - 2023-08-16 16:46:20 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:20 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:20 --> Model Class Initialized
INFO - 2023-08-16 16:46:20 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:20 --> Total execution time: 0.0519
ERROR - 2023-08-16 16:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:29 --> Config Class Initialized
INFO - 2023-08-16 16:46:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:29 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:29 --> URI Class Initialized
DEBUG - 2023-08-16 16:46:29 --> No URI present. Default controller set.
INFO - 2023-08-16 16:46:29 --> Router Class Initialized
INFO - 2023-08-16 16:46:29 --> Output Class Initialized
INFO - 2023-08-16 16:46:29 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:29 --> Input Class Initialized
INFO - 2023-08-16 16:46:29 --> Language Class Initialized
INFO - 2023-08-16 16:46:29 --> Loader Class Initialized
INFO - 2023-08-16 16:46:29 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:29 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:29 --> Parser Class Initialized
INFO - 2023-08-16 16:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:29 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:29 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:29 --> Controller Class Initialized
INFO - 2023-08-16 16:46:29 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-16 16:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:29 --> Config Class Initialized
INFO - 2023-08-16 16:46:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:29 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:29 --> URI Class Initialized
INFO - 2023-08-16 16:46:29 --> Router Class Initialized
INFO - 2023-08-16 16:46:29 --> Output Class Initialized
INFO - 2023-08-16 16:46:29 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:29 --> Input Class Initialized
INFO - 2023-08-16 16:46:29 --> Language Class Initialized
INFO - 2023-08-16 16:46:29 --> Loader Class Initialized
INFO - 2023-08-16 16:46:29 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:29 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:29 --> Parser Class Initialized
INFO - 2023-08-16 16:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:29 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:29 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:29 --> Controller Class Initialized
INFO - 2023-08-16 16:46:29 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-16 16:46:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 16:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 16:46:29 --> Model Class Initialized
INFO - 2023-08-16 16:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 16:46:29 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:29 --> Total execution time: 0.0273
ERROR - 2023-08-16 16:46:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:32 --> Config Class Initialized
INFO - 2023-08-16 16:46:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:32 --> URI Class Initialized
INFO - 2023-08-16 16:46:32 --> Router Class Initialized
INFO - 2023-08-16 16:46:32 --> Output Class Initialized
INFO - 2023-08-16 16:46:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:32 --> Input Class Initialized
INFO - 2023-08-16 16:46:32 --> Language Class Initialized
INFO - 2023-08-16 16:46:32 --> Loader Class Initialized
INFO - 2023-08-16 16:46:32 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:32 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:32 --> Parser Class Initialized
INFO - 2023-08-16 16:46:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:32 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:32 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:32 --> Controller Class Initialized
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
INFO - 2023-08-16 16:46:32 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:32 --> Total execution time: 0.0175
ERROR - 2023-08-16 16:46:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:32 --> Config Class Initialized
INFO - 2023-08-16 16:46:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:32 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:32 --> URI Class Initialized
DEBUG - 2023-08-16 16:46:32 --> No URI present. Default controller set.
INFO - 2023-08-16 16:46:32 --> Router Class Initialized
INFO - 2023-08-16 16:46:32 --> Output Class Initialized
INFO - 2023-08-16 16:46:32 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:32 --> Input Class Initialized
INFO - 2023-08-16 16:46:32 --> Language Class Initialized
INFO - 2023-08-16 16:46:32 --> Loader Class Initialized
INFO - 2023-08-16 16:46:32 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:32 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:32 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:32 --> Parser Class Initialized
INFO - 2023-08-16 16:46:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:32 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:32 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:32 --> Controller Class Initialized
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:46:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
INFO - 2023-08-16 16:46:32 --> Model Class Initialized
INFO - 2023-08-16 16:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 16:46:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 16:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 16:46:33 --> Model Class Initialized
INFO - 2023-08-16 16:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 16:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 16:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 16:46:33 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:33 --> Total execution time: 0.0902
ERROR - 2023-08-16 16:46:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:52 --> Config Class Initialized
INFO - 2023-08-16 16:46:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:52 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:52 --> URI Class Initialized
INFO - 2023-08-16 16:46:52 --> Router Class Initialized
INFO - 2023-08-16 16:46:52 --> Output Class Initialized
INFO - 2023-08-16 16:46:52 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:52 --> Input Class Initialized
INFO - 2023-08-16 16:46:52 --> Language Class Initialized
INFO - 2023-08-16 16:46:52 --> Loader Class Initialized
INFO - 2023-08-16 16:46:52 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:52 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:52 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:52 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:52 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:52 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:52 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:52 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:52 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:52 --> Parser Class Initialized
INFO - 2023-08-16 16:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:52 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:52 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:52 --> Controller Class Initialized
INFO - 2023-08-16 16:46:52 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:52 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:52 --> Model Class Initialized
INFO - 2023-08-16 16:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 16:46:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 16:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 16:46:52 --> Model Class Initialized
INFO - 2023-08-16 16:46:52 --> Model Class Initialized
INFO - 2023-08-16 16:46:52 --> Model Class Initialized
INFO - 2023-08-16 16:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 16:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 16:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 16:46:52 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:52 --> Total execution time: 0.0795
ERROR - 2023-08-16 16:46:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:46:53 --> Config Class Initialized
INFO - 2023-08-16 16:46:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:46:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:46:53 --> Utf8 Class Initialized
INFO - 2023-08-16 16:46:53 --> URI Class Initialized
INFO - 2023-08-16 16:46:53 --> Router Class Initialized
INFO - 2023-08-16 16:46:53 --> Output Class Initialized
INFO - 2023-08-16 16:46:53 --> Security Class Initialized
DEBUG - 2023-08-16 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:46:53 --> Input Class Initialized
INFO - 2023-08-16 16:46:53 --> Language Class Initialized
INFO - 2023-08-16 16:46:53 --> Loader Class Initialized
INFO - 2023-08-16 16:46:53 --> Helper loaded: url_helper
INFO - 2023-08-16 16:46:53 --> Helper loaded: file_helper
INFO - 2023-08-16 16:46:53 --> Helper loaded: html_helper
INFO - 2023-08-16 16:46:53 --> Helper loaded: text_helper
INFO - 2023-08-16 16:46:53 --> Helper loaded: form_helper
INFO - 2023-08-16 16:46:53 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:46:53 --> Helper loaded: security_helper
INFO - 2023-08-16 16:46:53 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:46:53 --> Database Driver Class Initialized
INFO - 2023-08-16 16:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:46:53 --> Parser Class Initialized
INFO - 2023-08-16 16:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:46:53 --> Pagination Class Initialized
INFO - 2023-08-16 16:46:53 --> Form Validation Class Initialized
INFO - 2023-08-16 16:46:53 --> Controller Class Initialized
INFO - 2023-08-16 16:46:53 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:53 --> Model Class Initialized
DEBUG - 2023-08-16 16:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:46:53 --> Model Class Initialized
INFO - 2023-08-16 16:46:53 --> Final output sent to browser
DEBUG - 2023-08-16 16:46:53 --> Total execution time: 0.0376
ERROR - 2023-08-16 16:47:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 16:47:03 --> Config Class Initialized
INFO - 2023-08-16 16:47:03 --> Hooks Class Initialized
DEBUG - 2023-08-16 16:47:03 --> UTF-8 Support Enabled
INFO - 2023-08-16 16:47:03 --> Utf8 Class Initialized
INFO - 2023-08-16 16:47:03 --> URI Class Initialized
DEBUG - 2023-08-16 16:47:03 --> No URI present. Default controller set.
INFO - 2023-08-16 16:47:03 --> Router Class Initialized
INFO - 2023-08-16 16:47:03 --> Output Class Initialized
INFO - 2023-08-16 16:47:03 --> Security Class Initialized
DEBUG - 2023-08-16 16:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 16:47:03 --> Input Class Initialized
INFO - 2023-08-16 16:47:03 --> Language Class Initialized
INFO - 2023-08-16 16:47:03 --> Loader Class Initialized
INFO - 2023-08-16 16:47:03 --> Helper loaded: url_helper
INFO - 2023-08-16 16:47:03 --> Helper loaded: file_helper
INFO - 2023-08-16 16:47:03 --> Helper loaded: html_helper
INFO - 2023-08-16 16:47:03 --> Helper loaded: text_helper
INFO - 2023-08-16 16:47:03 --> Helper loaded: form_helper
INFO - 2023-08-16 16:47:03 --> Helper loaded: lang_helper
INFO - 2023-08-16 16:47:03 --> Helper loaded: security_helper
INFO - 2023-08-16 16:47:03 --> Helper loaded: cookie_helper
INFO - 2023-08-16 16:47:03 --> Database Driver Class Initialized
INFO - 2023-08-16 16:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 16:47:03 --> Parser Class Initialized
INFO - 2023-08-16 16:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 16:47:03 --> Pagination Class Initialized
INFO - 2023-08-16 16:47:03 --> Form Validation Class Initialized
INFO - 2023-08-16 16:47:03 --> Controller Class Initialized
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
DEBUG - 2023-08-16 16:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
DEBUG - 2023-08-16 16:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
DEBUG - 2023-08-16 16:47:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 16:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
INFO - 2023-08-16 16:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 16:47:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 16:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 16:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 16:47:03 --> Model Class Initialized
INFO - 2023-08-16 16:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 16:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 16:47:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 16:47:03 --> Final output sent to browser
DEBUG - 2023-08-16 16:47:03 --> Total execution time: 0.0921
ERROR - 2023-08-16 17:03:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:03:29 --> Config Class Initialized
INFO - 2023-08-16 17:03:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:03:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:03:29 --> Utf8 Class Initialized
INFO - 2023-08-16 17:03:29 --> URI Class Initialized
DEBUG - 2023-08-16 17:03:29 --> No URI present. Default controller set.
INFO - 2023-08-16 17:03:29 --> Router Class Initialized
INFO - 2023-08-16 17:03:29 --> Output Class Initialized
INFO - 2023-08-16 17:03:29 --> Security Class Initialized
DEBUG - 2023-08-16 17:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:03:29 --> Input Class Initialized
INFO - 2023-08-16 17:03:29 --> Language Class Initialized
INFO - 2023-08-16 17:03:29 --> Loader Class Initialized
INFO - 2023-08-16 17:03:29 --> Helper loaded: url_helper
INFO - 2023-08-16 17:03:29 --> Helper loaded: file_helper
INFO - 2023-08-16 17:03:29 --> Helper loaded: html_helper
INFO - 2023-08-16 17:03:29 --> Helper loaded: text_helper
INFO - 2023-08-16 17:03:29 --> Helper loaded: form_helper
INFO - 2023-08-16 17:03:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:03:29 --> Helper loaded: security_helper
INFO - 2023-08-16 17:03:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:03:29 --> Database Driver Class Initialized
INFO - 2023-08-16 17:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:03:29 --> Parser Class Initialized
INFO - 2023-08-16 17:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:03:29 --> Pagination Class Initialized
INFO - 2023-08-16 17:03:29 --> Form Validation Class Initialized
INFO - 2023-08-16 17:03:29 --> Controller Class Initialized
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
INFO - 2023-08-16 17:03:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 17:03:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:03:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:03:29 --> Model Class Initialized
INFO - 2023-08-16 17:03:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:03:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:03:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:03:29 --> Final output sent to browser
DEBUG - 2023-08-16 17:03:29 --> Total execution time: 0.1977
ERROR - 2023-08-16 17:03:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:03:36 --> Config Class Initialized
INFO - 2023-08-16 17:03:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:03:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:03:36 --> Utf8 Class Initialized
INFO - 2023-08-16 17:03:36 --> URI Class Initialized
INFO - 2023-08-16 17:03:36 --> Router Class Initialized
INFO - 2023-08-16 17:03:36 --> Output Class Initialized
INFO - 2023-08-16 17:03:36 --> Security Class Initialized
DEBUG - 2023-08-16 17:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:03:36 --> Input Class Initialized
INFO - 2023-08-16 17:03:36 --> Language Class Initialized
INFO - 2023-08-16 17:03:36 --> Loader Class Initialized
INFO - 2023-08-16 17:03:36 --> Helper loaded: url_helper
INFO - 2023-08-16 17:03:36 --> Helper loaded: file_helper
INFO - 2023-08-16 17:03:36 --> Helper loaded: html_helper
INFO - 2023-08-16 17:03:36 --> Helper loaded: text_helper
INFO - 2023-08-16 17:03:36 --> Helper loaded: form_helper
INFO - 2023-08-16 17:03:36 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:03:36 --> Helper loaded: security_helper
INFO - 2023-08-16 17:03:36 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:03:36 --> Database Driver Class Initialized
INFO - 2023-08-16 17:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:03:36 --> Parser Class Initialized
INFO - 2023-08-16 17:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:03:36 --> Pagination Class Initialized
INFO - 2023-08-16 17:03:36 --> Form Validation Class Initialized
INFO - 2023-08-16 17:03:36 --> Controller Class Initialized
INFO - 2023-08-16 17:03:36 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:36 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:36 --> Model Class Initialized
INFO - 2023-08-16 17:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 17:03:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:03:37 --> Model Class Initialized
INFO - 2023-08-16 17:03:37 --> Model Class Initialized
INFO - 2023-08-16 17:03:37 --> Model Class Initialized
INFO - 2023-08-16 17:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:03:37 --> Final output sent to browser
DEBUG - 2023-08-16 17:03:37 --> Total execution time: 0.1406
ERROR - 2023-08-16 17:03:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:03:37 --> Config Class Initialized
INFO - 2023-08-16 17:03:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:03:37 --> Utf8 Class Initialized
INFO - 2023-08-16 17:03:37 --> URI Class Initialized
INFO - 2023-08-16 17:03:37 --> Router Class Initialized
INFO - 2023-08-16 17:03:37 --> Output Class Initialized
INFO - 2023-08-16 17:03:37 --> Security Class Initialized
DEBUG - 2023-08-16 17:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:03:37 --> Input Class Initialized
INFO - 2023-08-16 17:03:37 --> Language Class Initialized
INFO - 2023-08-16 17:03:37 --> Loader Class Initialized
INFO - 2023-08-16 17:03:37 --> Helper loaded: url_helper
INFO - 2023-08-16 17:03:37 --> Helper loaded: file_helper
INFO - 2023-08-16 17:03:37 --> Helper loaded: html_helper
INFO - 2023-08-16 17:03:37 --> Helper loaded: text_helper
INFO - 2023-08-16 17:03:37 --> Helper loaded: form_helper
INFO - 2023-08-16 17:03:37 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:03:37 --> Helper loaded: security_helper
INFO - 2023-08-16 17:03:37 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:03:37 --> Database Driver Class Initialized
INFO - 2023-08-16 17:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:03:37 --> Parser Class Initialized
INFO - 2023-08-16 17:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:03:37 --> Pagination Class Initialized
INFO - 2023-08-16 17:03:37 --> Form Validation Class Initialized
INFO - 2023-08-16 17:03:37 --> Controller Class Initialized
INFO - 2023-08-16 17:03:37 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:37 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:37 --> Model Class Initialized
INFO - 2023-08-16 17:03:38 --> Final output sent to browser
DEBUG - 2023-08-16 17:03:38 --> Total execution time: 0.0566
ERROR - 2023-08-16 17:03:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:03:43 --> Config Class Initialized
INFO - 2023-08-16 17:03:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:03:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:03:43 --> Utf8 Class Initialized
INFO - 2023-08-16 17:03:43 --> URI Class Initialized
INFO - 2023-08-16 17:03:43 --> Router Class Initialized
INFO - 2023-08-16 17:03:43 --> Output Class Initialized
INFO - 2023-08-16 17:03:43 --> Security Class Initialized
DEBUG - 2023-08-16 17:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:03:43 --> Input Class Initialized
INFO - 2023-08-16 17:03:43 --> Language Class Initialized
INFO - 2023-08-16 17:03:43 --> Loader Class Initialized
INFO - 2023-08-16 17:03:43 --> Helper loaded: url_helper
INFO - 2023-08-16 17:03:43 --> Helper loaded: file_helper
INFO - 2023-08-16 17:03:43 --> Helper loaded: html_helper
INFO - 2023-08-16 17:03:43 --> Helper loaded: text_helper
INFO - 2023-08-16 17:03:43 --> Helper loaded: form_helper
INFO - 2023-08-16 17:03:43 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:03:43 --> Helper loaded: security_helper
INFO - 2023-08-16 17:03:43 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:03:43 --> Database Driver Class Initialized
INFO - 2023-08-16 17:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:03:43 --> Parser Class Initialized
INFO - 2023-08-16 17:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:03:43 --> Pagination Class Initialized
INFO - 2023-08-16 17:03:43 --> Form Validation Class Initialized
INFO - 2023-08-16 17:03:43 --> Controller Class Initialized
INFO - 2023-08-16 17:03:43 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:43 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:43 --> Model Class Initialized
INFO - 2023-08-16 17:03:43 --> Final output sent to browser
DEBUG - 2023-08-16 17:03:43 --> Total execution time: 0.5687
ERROR - 2023-08-16 17:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:03:57 --> Config Class Initialized
INFO - 2023-08-16 17:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:03:57 --> Utf8 Class Initialized
INFO - 2023-08-16 17:03:57 --> URI Class Initialized
INFO - 2023-08-16 17:03:57 --> Router Class Initialized
INFO - 2023-08-16 17:03:57 --> Output Class Initialized
INFO - 2023-08-16 17:03:57 --> Security Class Initialized
DEBUG - 2023-08-16 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:03:57 --> Input Class Initialized
INFO - 2023-08-16 17:03:57 --> Language Class Initialized
INFO - 2023-08-16 17:03:57 --> Loader Class Initialized
INFO - 2023-08-16 17:03:57 --> Helper loaded: url_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: file_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: html_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: text_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: form_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: security_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:03:57 --> Database Driver Class Initialized
INFO - 2023-08-16 17:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:03:57 --> Parser Class Initialized
INFO - 2023-08-16 17:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:03:57 --> Pagination Class Initialized
INFO - 2023-08-16 17:03:57 --> Form Validation Class Initialized
INFO - 2023-08-16 17:03:57 --> Controller Class Initialized
INFO - 2023-08-16 17:03:57 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:57 --> Model Class Initialized
INFO - 2023-08-16 17:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-08-16 17:03:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:03:57 --> Model Class Initialized
INFO - 2023-08-16 17:03:57 --> Model Class Initialized
INFO - 2023-08-16 17:03:57 --> Model Class Initialized
INFO - 2023-08-16 17:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:03:57 --> Final output sent to browser
DEBUG - 2023-08-16 17:03:57 --> Total execution time: 0.1352
ERROR - 2023-08-16 17:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:03:57 --> Config Class Initialized
INFO - 2023-08-16 17:03:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:03:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:03:57 --> Utf8 Class Initialized
INFO - 2023-08-16 17:03:57 --> URI Class Initialized
INFO - 2023-08-16 17:03:57 --> Router Class Initialized
INFO - 2023-08-16 17:03:57 --> Output Class Initialized
INFO - 2023-08-16 17:03:57 --> Security Class Initialized
DEBUG - 2023-08-16 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:03:57 --> Input Class Initialized
INFO - 2023-08-16 17:03:57 --> Language Class Initialized
INFO - 2023-08-16 17:03:57 --> Loader Class Initialized
INFO - 2023-08-16 17:03:57 --> Helper loaded: url_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: file_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: html_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: text_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: form_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: security_helper
INFO - 2023-08-16 17:03:57 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:03:57 --> Database Driver Class Initialized
INFO - 2023-08-16 17:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:03:57 --> Parser Class Initialized
INFO - 2023-08-16 17:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:03:57 --> Pagination Class Initialized
INFO - 2023-08-16 17:03:57 --> Form Validation Class Initialized
INFO - 2023-08-16 17:03:57 --> Controller Class Initialized
INFO - 2023-08-16 17:03:57 --> Model Class Initialized
DEBUG - 2023-08-16 17:03:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:03:57 --> Model Class Initialized
INFO - 2023-08-16 17:03:57 --> Final output sent to browser
DEBUG - 2023-08-16 17:03:57 --> Total execution time: 0.0189
ERROR - 2023-08-16 17:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:02 --> Config Class Initialized
INFO - 2023-08-16 17:04:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:02 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:02 --> URI Class Initialized
INFO - 2023-08-16 17:04:02 --> Router Class Initialized
INFO - 2023-08-16 17:04:02 --> Output Class Initialized
INFO - 2023-08-16 17:04:02 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:02 --> Input Class Initialized
INFO - 2023-08-16 17:04:02 --> Language Class Initialized
INFO - 2023-08-16 17:04:02 --> Loader Class Initialized
INFO - 2023-08-16 17:04:02 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:02 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:02 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:02 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:02 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:02 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:02 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:02 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:02 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:02 --> Parser Class Initialized
INFO - 2023-08-16 17:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:02 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:02 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:02 --> Controller Class Initialized
INFO - 2023-08-16 17:04:02 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:02 --> Model Class Initialized
INFO - 2023-08-16 17:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:04:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:04:02 --> Model Class Initialized
INFO - 2023-08-16 17:04:02 --> Model Class Initialized
INFO - 2023-08-16 17:04:02 --> Model Class Initialized
INFO - 2023-08-16 17:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:04:02 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:02 --> Total execution time: 0.1392
ERROR - 2023-08-16 17:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:02 --> Config Class Initialized
INFO - 2023-08-16 17:04:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:02 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:02 --> URI Class Initialized
INFO - 2023-08-16 17:04:02 --> Router Class Initialized
INFO - 2023-08-16 17:04:02 --> Output Class Initialized
INFO - 2023-08-16 17:04:02 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:02 --> Input Class Initialized
INFO - 2023-08-16 17:04:02 --> Language Class Initialized
INFO - 2023-08-16 17:04:03 --> Loader Class Initialized
INFO - 2023-08-16 17:04:03 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:03 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:03 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:03 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:03 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:03 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:03 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:03 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:03 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:03 --> Parser Class Initialized
INFO - 2023-08-16 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:03 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:03 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:03 --> Controller Class Initialized
INFO - 2023-08-16 17:04:03 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:03 --> Model Class Initialized
INFO - 2023-08-16 17:04:03 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:03 --> Total execution time: 0.0258
ERROR - 2023-08-16 17:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:11 --> Config Class Initialized
INFO - 2023-08-16 17:04:11 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:11 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:11 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:11 --> URI Class Initialized
INFO - 2023-08-16 17:04:11 --> Router Class Initialized
INFO - 2023-08-16 17:04:11 --> Output Class Initialized
INFO - 2023-08-16 17:04:11 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:11 --> Input Class Initialized
INFO - 2023-08-16 17:04:11 --> Language Class Initialized
INFO - 2023-08-16 17:04:11 --> Loader Class Initialized
INFO - 2023-08-16 17:04:11 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:11 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:11 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:11 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:11 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:11 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:11 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:11 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:11 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:11 --> Parser Class Initialized
INFO - 2023-08-16 17:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:11 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:11 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:11 --> Controller Class Initialized
INFO - 2023-08-16 17:04:11 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:11 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-16 17:04:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:04:11 --> Model Class Initialized
INFO - 2023-08-16 17:04:11 --> Model Class Initialized
INFO - 2023-08-16 17:04:11 --> Model Class Initialized
INFO - 2023-08-16 17:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:04:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:04:11 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:11 --> Total execution time: 0.1320
ERROR - 2023-08-16 17:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:18 --> Config Class Initialized
INFO - 2023-08-16 17:04:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:18 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:18 --> URI Class Initialized
INFO - 2023-08-16 17:04:18 --> Router Class Initialized
INFO - 2023-08-16 17:04:18 --> Output Class Initialized
INFO - 2023-08-16 17:04:18 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:18 --> Input Class Initialized
INFO - 2023-08-16 17:04:18 --> Language Class Initialized
INFO - 2023-08-16 17:04:18 --> Loader Class Initialized
INFO - 2023-08-16 17:04:18 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:18 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:18 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:18 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:18 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:18 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:18 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:18 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:18 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:18 --> Parser Class Initialized
INFO - 2023-08-16 17:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:18 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:18 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:18 --> Controller Class Initialized
INFO - 2023-08-16 17:04:18 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:18 --> Model Class Initialized
INFO - 2023-08-16 17:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:04:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:04:18 --> Model Class Initialized
INFO - 2023-08-16 17:04:18 --> Model Class Initialized
INFO - 2023-08-16 17:04:18 --> Model Class Initialized
INFO - 2023-08-16 17:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:04:18 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:18 --> Total execution time: 0.1343
ERROR - 2023-08-16 17:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:19 --> Config Class Initialized
INFO - 2023-08-16 17:04:19 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:19 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:19 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:19 --> URI Class Initialized
INFO - 2023-08-16 17:04:19 --> Router Class Initialized
INFO - 2023-08-16 17:04:19 --> Output Class Initialized
INFO - 2023-08-16 17:04:19 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:19 --> Input Class Initialized
INFO - 2023-08-16 17:04:19 --> Language Class Initialized
INFO - 2023-08-16 17:04:19 --> Loader Class Initialized
INFO - 2023-08-16 17:04:19 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:19 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:19 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:19 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:19 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:19 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:19 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:19 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:19 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:19 --> Parser Class Initialized
INFO - 2023-08-16 17:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:19 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:19 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:19 --> Controller Class Initialized
INFO - 2023-08-16 17:04:19 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:19 --> Model Class Initialized
INFO - 2023-08-16 17:04:19 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:19 --> Total execution time: 0.0243
ERROR - 2023-08-16 17:04:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:41 --> Config Class Initialized
INFO - 2023-08-16 17:04:41 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:41 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:41 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:41 --> URI Class Initialized
INFO - 2023-08-16 17:04:41 --> Router Class Initialized
INFO - 2023-08-16 17:04:41 --> Output Class Initialized
INFO - 2023-08-16 17:04:41 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:41 --> Input Class Initialized
INFO - 2023-08-16 17:04:41 --> Language Class Initialized
INFO - 2023-08-16 17:04:41 --> Loader Class Initialized
INFO - 2023-08-16 17:04:41 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:41 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:41 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:41 --> Parser Class Initialized
INFO - 2023-08-16 17:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:41 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:41 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:41 --> Controller Class Initialized
INFO - 2023-08-16 17:04:41 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:41 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-16 17:04:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:04:41 --> Model Class Initialized
INFO - 2023-08-16 17:04:41 --> Model Class Initialized
INFO - 2023-08-16 17:04:41 --> Model Class Initialized
INFO - 2023-08-16 17:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:04:41 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:41 --> Total execution time: 0.1333
ERROR - 2023-08-16 17:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:44 --> Config Class Initialized
INFO - 2023-08-16 17:04:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:44 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:44 --> URI Class Initialized
INFO - 2023-08-16 17:04:44 --> Router Class Initialized
INFO - 2023-08-16 17:04:44 --> Output Class Initialized
INFO - 2023-08-16 17:04:44 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:44 --> Input Class Initialized
INFO - 2023-08-16 17:04:44 --> Language Class Initialized
INFO - 2023-08-16 17:04:44 --> Loader Class Initialized
INFO - 2023-08-16 17:04:44 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:44 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:44 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:44 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:44 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:44 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:44 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:44 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:44 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:44 --> Parser Class Initialized
INFO - 2023-08-16 17:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:44 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:44 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:44 --> Controller Class Initialized
INFO - 2023-08-16 17:04:44 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:44 --> Model Class Initialized
INFO - 2023-08-16 17:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:04:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:04:45 --> Model Class Initialized
INFO - 2023-08-16 17:04:45 --> Model Class Initialized
INFO - 2023-08-16 17:04:45 --> Model Class Initialized
INFO - 2023-08-16 17:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:04:45 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:45 --> Total execution time: 0.1570
ERROR - 2023-08-16 17:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:45 --> Config Class Initialized
INFO - 2023-08-16 17:04:45 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:45 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:45 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:45 --> URI Class Initialized
INFO - 2023-08-16 17:04:45 --> Router Class Initialized
INFO - 2023-08-16 17:04:45 --> Output Class Initialized
INFO - 2023-08-16 17:04:45 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:45 --> Input Class Initialized
INFO - 2023-08-16 17:04:45 --> Language Class Initialized
INFO - 2023-08-16 17:04:45 --> Loader Class Initialized
INFO - 2023-08-16 17:04:45 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:45 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:45 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:45 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:45 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:45 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:45 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:45 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:45 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:45 --> Parser Class Initialized
INFO - 2023-08-16 17:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:45 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:45 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:45 --> Controller Class Initialized
INFO - 2023-08-16 17:04:45 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:45 --> Model Class Initialized
INFO - 2023-08-16 17:04:45 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:45 --> Total execution time: 0.0256
ERROR - 2023-08-16 17:04:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:50 --> Config Class Initialized
INFO - 2023-08-16 17:04:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:50 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:50 --> URI Class Initialized
INFO - 2023-08-16 17:04:50 --> Router Class Initialized
INFO - 2023-08-16 17:04:50 --> Output Class Initialized
INFO - 2023-08-16 17:04:50 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:50 --> Input Class Initialized
INFO - 2023-08-16 17:04:50 --> Language Class Initialized
INFO - 2023-08-16 17:04:50 --> Loader Class Initialized
INFO - 2023-08-16 17:04:50 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:50 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:50 --> Parser Class Initialized
INFO - 2023-08-16 17:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:50 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:50 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:50 --> Controller Class Initialized
INFO - 2023-08-16 17:04:50 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:50 --> Model Class Initialized
INFO - 2023-08-16 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:04:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:04:50 --> Model Class Initialized
INFO - 2023-08-16 17:04:50 --> Model Class Initialized
INFO - 2023-08-16 17:04:50 --> Model Class Initialized
INFO - 2023-08-16 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:04:50 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:50 --> Total execution time: 0.1384
ERROR - 2023-08-16 17:04:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:50 --> Config Class Initialized
INFO - 2023-08-16 17:04:50 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:50 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:50 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:50 --> URI Class Initialized
INFO - 2023-08-16 17:04:50 --> Router Class Initialized
INFO - 2023-08-16 17:04:50 --> Output Class Initialized
INFO - 2023-08-16 17:04:50 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:50 --> Input Class Initialized
INFO - 2023-08-16 17:04:50 --> Language Class Initialized
INFO - 2023-08-16 17:04:50 --> Loader Class Initialized
INFO - 2023-08-16 17:04:50 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:50 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:50 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:50 --> Parser Class Initialized
INFO - 2023-08-16 17:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:50 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:50 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:50 --> Controller Class Initialized
INFO - 2023-08-16 17:04:50 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:50 --> Model Class Initialized
INFO - 2023-08-16 17:04:50 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:50 --> Total execution time: 0.0292
ERROR - 2023-08-16 17:04:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:04:54 --> Config Class Initialized
INFO - 2023-08-16 17:04:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:04:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:04:54 --> Utf8 Class Initialized
INFO - 2023-08-16 17:04:54 --> URI Class Initialized
INFO - 2023-08-16 17:04:54 --> Router Class Initialized
INFO - 2023-08-16 17:04:54 --> Output Class Initialized
INFO - 2023-08-16 17:04:54 --> Security Class Initialized
DEBUG - 2023-08-16 17:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:04:54 --> Input Class Initialized
INFO - 2023-08-16 17:04:54 --> Language Class Initialized
INFO - 2023-08-16 17:04:54 --> Loader Class Initialized
INFO - 2023-08-16 17:04:54 --> Helper loaded: url_helper
INFO - 2023-08-16 17:04:54 --> Helper loaded: file_helper
INFO - 2023-08-16 17:04:54 --> Helper loaded: html_helper
INFO - 2023-08-16 17:04:54 --> Helper loaded: text_helper
INFO - 2023-08-16 17:04:54 --> Helper loaded: form_helper
INFO - 2023-08-16 17:04:54 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:04:54 --> Helper loaded: security_helper
INFO - 2023-08-16 17:04:54 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:04:54 --> Database Driver Class Initialized
INFO - 2023-08-16 17:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:04:54 --> Parser Class Initialized
INFO - 2023-08-16 17:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:04:54 --> Pagination Class Initialized
INFO - 2023-08-16 17:04:54 --> Form Validation Class Initialized
INFO - 2023-08-16 17:04:54 --> Controller Class Initialized
INFO - 2023-08-16 17:04:54 --> Model Class Initialized
DEBUG - 2023-08-16 17:04:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:04:54 --> Model Class Initialized
INFO - 2023-08-16 17:04:54 --> Final output sent to browser
DEBUG - 2023-08-16 17:04:54 --> Total execution time: 0.0243
ERROR - 2023-08-16 17:05:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:16 --> Config Class Initialized
INFO - 2023-08-16 17:05:16 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:16 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:16 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:16 --> URI Class Initialized
INFO - 2023-08-16 17:05:16 --> Router Class Initialized
INFO - 2023-08-16 17:05:16 --> Output Class Initialized
INFO - 2023-08-16 17:05:16 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:16 --> Input Class Initialized
INFO - 2023-08-16 17:05:16 --> Language Class Initialized
INFO - 2023-08-16 17:05:16 --> Loader Class Initialized
INFO - 2023-08-16 17:05:16 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:16 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:16 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:16 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:16 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:16 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:16 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:16 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:16 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:16 --> Parser Class Initialized
INFO - 2023-08-16 17:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:16 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:16 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:16 --> Controller Class Initialized
INFO - 2023-08-16 17:05:16 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:16 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-16 17:05:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:05:16 --> Model Class Initialized
INFO - 2023-08-16 17:05:16 --> Model Class Initialized
INFO - 2023-08-16 17:05:16 --> Model Class Initialized
INFO - 2023-08-16 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:05:17 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:17 --> Total execution time: 0.1503
ERROR - 2023-08-16 17:05:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:25 --> Config Class Initialized
INFO - 2023-08-16 17:05:25 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:25 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:25 --> URI Class Initialized
INFO - 2023-08-16 17:05:25 --> Router Class Initialized
INFO - 2023-08-16 17:05:25 --> Output Class Initialized
INFO - 2023-08-16 17:05:25 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:25 --> Input Class Initialized
INFO - 2023-08-16 17:05:25 --> Language Class Initialized
INFO - 2023-08-16 17:05:25 --> Loader Class Initialized
INFO - 2023-08-16 17:05:25 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:25 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:25 --> Parser Class Initialized
INFO - 2023-08-16 17:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:25 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:25 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:25 --> Controller Class Initialized
INFO - 2023-08-16 17:05:25 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:25 --> Model Class Initialized
INFO - 2023-08-16 17:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:05:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:05:25 --> Model Class Initialized
INFO - 2023-08-16 17:05:25 --> Model Class Initialized
INFO - 2023-08-16 17:05:25 --> Model Class Initialized
INFO - 2023-08-16 17:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:05:25 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:25 --> Total execution time: 0.1441
ERROR - 2023-08-16 17:05:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:25 --> Config Class Initialized
INFO - 2023-08-16 17:05:25 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:25 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:25 --> URI Class Initialized
INFO - 2023-08-16 17:05:25 --> Router Class Initialized
INFO - 2023-08-16 17:05:25 --> Output Class Initialized
INFO - 2023-08-16 17:05:25 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:25 --> Input Class Initialized
INFO - 2023-08-16 17:05:25 --> Language Class Initialized
INFO - 2023-08-16 17:05:25 --> Loader Class Initialized
INFO - 2023-08-16 17:05:25 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:25 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:25 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:25 --> Parser Class Initialized
INFO - 2023-08-16 17:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:25 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:25 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:25 --> Controller Class Initialized
INFO - 2023-08-16 17:05:25 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:25 --> Model Class Initialized
INFO - 2023-08-16 17:05:25 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:25 --> Total execution time: 0.0249
ERROR - 2023-08-16 17:05:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:29 --> Config Class Initialized
INFO - 2023-08-16 17:05:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:29 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:29 --> URI Class Initialized
INFO - 2023-08-16 17:05:29 --> Router Class Initialized
INFO - 2023-08-16 17:05:29 --> Output Class Initialized
INFO - 2023-08-16 17:05:29 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:29 --> Input Class Initialized
INFO - 2023-08-16 17:05:29 --> Language Class Initialized
INFO - 2023-08-16 17:05:29 --> Loader Class Initialized
INFO - 2023-08-16 17:05:29 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:29 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:29 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:29 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:29 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:29 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:29 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:29 --> Parser Class Initialized
INFO - 2023-08-16 17:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:29 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:29 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:29 --> Controller Class Initialized
INFO - 2023-08-16 17:05:29 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:29 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-16 17:05:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:05:29 --> Model Class Initialized
INFO - 2023-08-16 17:05:29 --> Model Class Initialized
INFO - 2023-08-16 17:05:29 --> Model Class Initialized
INFO - 2023-08-16 17:05:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:05:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:05:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:05:30 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:30 --> Total execution time: 0.1442
ERROR - 2023-08-16 17:05:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:37 --> Config Class Initialized
INFO - 2023-08-16 17:05:37 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:37 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:37 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:37 --> URI Class Initialized
INFO - 2023-08-16 17:05:37 --> Router Class Initialized
INFO - 2023-08-16 17:05:37 --> Output Class Initialized
INFO - 2023-08-16 17:05:37 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:37 --> Input Class Initialized
INFO - 2023-08-16 17:05:37 --> Language Class Initialized
INFO - 2023-08-16 17:05:37 --> Loader Class Initialized
INFO - 2023-08-16 17:05:37 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:37 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:37 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:37 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:37 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:37 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:37 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:37 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:37 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:37 --> Parser Class Initialized
INFO - 2023-08-16 17:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:37 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:37 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:37 --> Controller Class Initialized
INFO - 2023-08-16 17:05:37 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:37 --> Model Class Initialized
INFO - 2023-08-16 17:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:05:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:05:37 --> Model Class Initialized
INFO - 2023-08-16 17:05:37 --> Model Class Initialized
INFO - 2023-08-16 17:05:37 --> Model Class Initialized
INFO - 2023-08-16 17:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:05:37 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:37 --> Total execution time: 0.1573
ERROR - 2023-08-16 17:05:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:38 --> Config Class Initialized
INFO - 2023-08-16 17:05:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:38 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:38 --> URI Class Initialized
INFO - 2023-08-16 17:05:38 --> Router Class Initialized
INFO - 2023-08-16 17:05:38 --> Output Class Initialized
INFO - 2023-08-16 17:05:38 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:38 --> Input Class Initialized
INFO - 2023-08-16 17:05:38 --> Language Class Initialized
INFO - 2023-08-16 17:05:38 --> Loader Class Initialized
INFO - 2023-08-16 17:05:38 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:38 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:38 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:38 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:38 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:38 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:38 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:38 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:38 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:38 --> Parser Class Initialized
INFO - 2023-08-16 17:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:38 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:38 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:38 --> Controller Class Initialized
INFO - 2023-08-16 17:05:38 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:38 --> Model Class Initialized
INFO - 2023-08-16 17:05:38 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:38 --> Total execution time: 0.0257
ERROR - 2023-08-16 17:05:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:43 --> Config Class Initialized
INFO - 2023-08-16 17:05:43 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:43 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:43 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:43 --> URI Class Initialized
INFO - 2023-08-16 17:05:43 --> Router Class Initialized
INFO - 2023-08-16 17:05:43 --> Output Class Initialized
INFO - 2023-08-16 17:05:43 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:43 --> Input Class Initialized
INFO - 2023-08-16 17:05:43 --> Language Class Initialized
INFO - 2023-08-16 17:05:43 --> Loader Class Initialized
INFO - 2023-08-16 17:05:43 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:43 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:43 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:43 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:43 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:43 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:43 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:43 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:43 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:43 --> Parser Class Initialized
INFO - 2023-08-16 17:05:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:43 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:43 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:43 --> Controller Class Initialized
INFO - 2023-08-16 17:05:43 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:43 --> Model Class Initialized
ERROR - 2023-08-16 17:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:44 --> Config Class Initialized
INFO - 2023-08-16 17:05:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:44 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:44 --> URI Class Initialized
INFO - 2023-08-16 17:05:44 --> Router Class Initialized
INFO - 2023-08-16 17:05:44 --> Output Class Initialized
INFO - 2023-08-16 17:05:44 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:44 --> Input Class Initialized
INFO - 2023-08-16 17:05:44 --> Language Class Initialized
INFO - 2023-08-16 17:05:44 --> Loader Class Initialized
INFO - 2023-08-16 17:05:44 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:44 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:44 --> Parser Class Initialized
INFO - 2023-08-16 17:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:44 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:44 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:44 --> Controller Class Initialized
INFO - 2023-08-16 17:05:44 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:44 --> Model Class Initialized
INFO - 2023-08-16 17:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:05:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:05:44 --> Model Class Initialized
INFO - 2023-08-16 17:05:44 --> Model Class Initialized
INFO - 2023-08-16 17:05:44 --> Model Class Initialized
INFO - 2023-08-16 17:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:05:44 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:44 --> Total execution time: 0.1456
ERROR - 2023-08-16 17:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:44 --> Config Class Initialized
INFO - 2023-08-16 17:05:44 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:44 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:44 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:44 --> URI Class Initialized
INFO - 2023-08-16 17:05:44 --> Router Class Initialized
INFO - 2023-08-16 17:05:44 --> Output Class Initialized
INFO - 2023-08-16 17:05:44 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:44 --> Input Class Initialized
INFO - 2023-08-16 17:05:44 --> Language Class Initialized
INFO - 2023-08-16 17:05:44 --> Loader Class Initialized
INFO - 2023-08-16 17:05:44 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:44 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:44 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:44 --> Parser Class Initialized
INFO - 2023-08-16 17:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:44 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:44 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:44 --> Controller Class Initialized
INFO - 2023-08-16 17:05:44 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:44 --> Model Class Initialized
INFO - 2023-08-16 17:05:44 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:44 --> Total execution time: 0.0264
ERROR - 2023-08-16 17:05:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:55 --> Config Class Initialized
INFO - 2023-08-16 17:05:55 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:55 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:55 --> URI Class Initialized
INFO - 2023-08-16 17:05:55 --> Router Class Initialized
INFO - 2023-08-16 17:05:55 --> Output Class Initialized
INFO - 2023-08-16 17:05:55 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:55 --> Input Class Initialized
INFO - 2023-08-16 17:05:55 --> Language Class Initialized
INFO - 2023-08-16 17:05:55 --> Loader Class Initialized
INFO - 2023-08-16 17:05:55 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:55 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:55 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:55 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:55 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:55 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:55 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:55 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:55 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:55 --> Parser Class Initialized
INFO - 2023-08-16 17:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:55 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:55 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:55 --> Controller Class Initialized
INFO - 2023-08-16 17:05:55 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:55 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:55 --> Model Class Initialized
INFO - 2023-08-16 17:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 17:05:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:05:55 --> Model Class Initialized
INFO - 2023-08-16 17:05:55 --> Model Class Initialized
INFO - 2023-08-16 17:05:55 --> Model Class Initialized
INFO - 2023-08-16 17:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:05:55 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:55 --> Total execution time: 0.1400
ERROR - 2023-08-16 17:05:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:05:56 --> Config Class Initialized
INFO - 2023-08-16 17:05:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:05:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:05:56 --> Utf8 Class Initialized
INFO - 2023-08-16 17:05:56 --> URI Class Initialized
INFO - 2023-08-16 17:05:56 --> Router Class Initialized
INFO - 2023-08-16 17:05:56 --> Output Class Initialized
INFO - 2023-08-16 17:05:56 --> Security Class Initialized
DEBUG - 2023-08-16 17:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:05:56 --> Input Class Initialized
INFO - 2023-08-16 17:05:56 --> Language Class Initialized
INFO - 2023-08-16 17:05:56 --> Loader Class Initialized
INFO - 2023-08-16 17:05:56 --> Helper loaded: url_helper
INFO - 2023-08-16 17:05:56 --> Helper loaded: file_helper
INFO - 2023-08-16 17:05:56 --> Helper loaded: html_helper
INFO - 2023-08-16 17:05:56 --> Helper loaded: text_helper
INFO - 2023-08-16 17:05:56 --> Helper loaded: form_helper
INFO - 2023-08-16 17:05:56 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:05:56 --> Helper loaded: security_helper
INFO - 2023-08-16 17:05:56 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:05:56 --> Database Driver Class Initialized
INFO - 2023-08-16 17:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:05:56 --> Parser Class Initialized
INFO - 2023-08-16 17:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:05:56 --> Pagination Class Initialized
INFO - 2023-08-16 17:05:56 --> Form Validation Class Initialized
INFO - 2023-08-16 17:05:56 --> Controller Class Initialized
INFO - 2023-08-16 17:05:56 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:56 --> Model Class Initialized
DEBUG - 2023-08-16 17:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:05:56 --> Model Class Initialized
INFO - 2023-08-16 17:05:56 --> Final output sent to browser
DEBUG - 2023-08-16 17:05:56 --> Total execution time: 0.0564
ERROR - 2023-08-16 17:06:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:00 --> Config Class Initialized
INFO - 2023-08-16 17:06:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:00 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:00 --> URI Class Initialized
INFO - 2023-08-16 17:06:00 --> Router Class Initialized
INFO - 2023-08-16 17:06:00 --> Output Class Initialized
INFO - 2023-08-16 17:06:00 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:00 --> Input Class Initialized
INFO - 2023-08-16 17:06:00 --> Language Class Initialized
INFO - 2023-08-16 17:06:00 --> Loader Class Initialized
INFO - 2023-08-16 17:06:00 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:00 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:00 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:00 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:00 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:00 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:00 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:00 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:00 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:00 --> Parser Class Initialized
INFO - 2023-08-16 17:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:00 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:00 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:00 --> Controller Class Initialized
INFO - 2023-08-16 17:06:00 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:00 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:00 --> Model Class Initialized
INFO - 2023-08-16 17:06:00 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:00 --> Total execution time: 0.0570
ERROR - 2023-08-16 17:06:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:01 --> Config Class Initialized
INFO - 2023-08-16 17:06:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:01 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:01 --> URI Class Initialized
INFO - 2023-08-16 17:06:01 --> Router Class Initialized
INFO - 2023-08-16 17:06:01 --> Output Class Initialized
INFO - 2023-08-16 17:06:01 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:01 --> Input Class Initialized
INFO - 2023-08-16 17:06:01 --> Language Class Initialized
INFO - 2023-08-16 17:06:01 --> Loader Class Initialized
INFO - 2023-08-16 17:06:01 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:01 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:01 --> Parser Class Initialized
INFO - 2023-08-16 17:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:01 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:01 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:01 --> Controller Class Initialized
INFO - 2023-08-16 17:06:01 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:01 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:01 --> Model Class Initialized
INFO - 2023-08-16 17:06:01 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:01 --> Total execution time: 0.0570
ERROR - 2023-08-16 17:06:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:01 --> Config Class Initialized
INFO - 2023-08-16 17:06:01 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:01 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:01 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:01 --> URI Class Initialized
INFO - 2023-08-16 17:06:01 --> Router Class Initialized
INFO - 2023-08-16 17:06:01 --> Output Class Initialized
INFO - 2023-08-16 17:06:01 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:01 --> Input Class Initialized
INFO - 2023-08-16 17:06:01 --> Language Class Initialized
INFO - 2023-08-16 17:06:01 --> Loader Class Initialized
INFO - 2023-08-16 17:06:01 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:01 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:01 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:01 --> Parser Class Initialized
INFO - 2023-08-16 17:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:01 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:01 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:01 --> Controller Class Initialized
INFO - 2023-08-16 17:06:01 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:01 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:01 --> Model Class Initialized
INFO - 2023-08-16 17:06:01 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:01 --> Total execution time: 0.0253
ERROR - 2023-08-16 17:06:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:02 --> Config Class Initialized
INFO - 2023-08-16 17:06:02 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:02 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:02 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:02 --> URI Class Initialized
INFO - 2023-08-16 17:06:02 --> Router Class Initialized
INFO - 2023-08-16 17:06:02 --> Output Class Initialized
INFO - 2023-08-16 17:06:02 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:02 --> Input Class Initialized
INFO - 2023-08-16 17:06:02 --> Language Class Initialized
INFO - 2023-08-16 17:06:02 --> Loader Class Initialized
INFO - 2023-08-16 17:06:02 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:02 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:02 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:02 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:02 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:02 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:02 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:02 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:02 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:02 --> Parser Class Initialized
INFO - 2023-08-16 17:06:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:02 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:02 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:02 --> Controller Class Initialized
INFO - 2023-08-16 17:06:02 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:02 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:02 --> Model Class Initialized
INFO - 2023-08-16 17:06:02 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:02 --> Total execution time: 0.0263
ERROR - 2023-08-16 17:06:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:12 --> Config Class Initialized
INFO - 2023-08-16 17:06:12 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:12 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:12 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:12 --> URI Class Initialized
INFO - 2023-08-16 17:06:12 --> Router Class Initialized
INFO - 2023-08-16 17:06:12 --> Output Class Initialized
INFO - 2023-08-16 17:06:12 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:12 --> Input Class Initialized
INFO - 2023-08-16 17:06:12 --> Language Class Initialized
INFO - 2023-08-16 17:06:12 --> Loader Class Initialized
INFO - 2023-08-16 17:06:12 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:12 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:12 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:12 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:12 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:12 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:12 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:12 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:12 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:12 --> Parser Class Initialized
INFO - 2023-08-16 17:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:12 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:12 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:12 --> Controller Class Initialized
INFO - 2023-08-16 17:06:12 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:12 --> Model Class Initialized
INFO - 2023-08-16 17:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:06:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:06:12 --> Model Class Initialized
INFO - 2023-08-16 17:06:12 --> Model Class Initialized
INFO - 2023-08-16 17:06:12 --> Model Class Initialized
INFO - 2023-08-16 17:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:06:12 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:12 --> Total execution time: 0.1300
ERROR - 2023-08-16 17:06:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:13 --> Config Class Initialized
INFO - 2023-08-16 17:06:13 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:13 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:13 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:13 --> URI Class Initialized
INFO - 2023-08-16 17:06:13 --> Router Class Initialized
INFO - 2023-08-16 17:06:13 --> Output Class Initialized
INFO - 2023-08-16 17:06:13 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:13 --> Input Class Initialized
INFO - 2023-08-16 17:06:13 --> Language Class Initialized
INFO - 2023-08-16 17:06:13 --> Loader Class Initialized
INFO - 2023-08-16 17:06:13 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:13 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:13 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:13 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:13 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:13 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:13 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:13 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:13 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:13 --> Parser Class Initialized
INFO - 2023-08-16 17:06:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:13 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:13 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:13 --> Controller Class Initialized
INFO - 2023-08-16 17:06:13 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:13 --> Model Class Initialized
INFO - 2023-08-16 17:06:13 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:13 --> Total execution time: 0.0227
ERROR - 2023-08-16 17:06:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:28 --> Config Class Initialized
INFO - 2023-08-16 17:06:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:28 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:28 --> URI Class Initialized
INFO - 2023-08-16 17:06:28 --> Router Class Initialized
INFO - 2023-08-16 17:06:28 --> Output Class Initialized
INFO - 2023-08-16 17:06:28 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:28 --> Input Class Initialized
INFO - 2023-08-16 17:06:28 --> Language Class Initialized
INFO - 2023-08-16 17:06:28 --> Loader Class Initialized
INFO - 2023-08-16 17:06:28 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:28 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:28 --> Parser Class Initialized
INFO - 2023-08-16 17:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:28 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:28 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:28 --> Controller Class Initialized
INFO - 2023-08-16 17:06:28 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:28 --> Model Class Initialized
ERROR - 2023-08-16 17:06:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:28 --> Config Class Initialized
INFO - 2023-08-16 17:06:28 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:28 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:28 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:28 --> URI Class Initialized
INFO - 2023-08-16 17:06:28 --> Router Class Initialized
INFO - 2023-08-16 17:06:28 --> Output Class Initialized
INFO - 2023-08-16 17:06:28 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:28 --> Input Class Initialized
INFO - 2023-08-16 17:06:28 --> Language Class Initialized
INFO - 2023-08-16 17:06:28 --> Loader Class Initialized
INFO - 2023-08-16 17:06:28 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:28 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:28 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:28 --> Parser Class Initialized
INFO - 2023-08-16 17:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:28 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:28 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:28 --> Controller Class Initialized
INFO - 2023-08-16 17:06:28 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:28 --> Model Class Initialized
INFO - 2023-08-16 17:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:06:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:06:28 --> Model Class Initialized
INFO - 2023-08-16 17:06:28 --> Model Class Initialized
INFO - 2023-08-16 17:06:28 --> Model Class Initialized
INFO - 2023-08-16 17:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:06:28 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:28 --> Total execution time: 0.1279
ERROR - 2023-08-16 17:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:29 --> Config Class Initialized
INFO - 2023-08-16 17:06:29 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:29 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:29 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:29 --> URI Class Initialized
INFO - 2023-08-16 17:06:29 --> Router Class Initialized
INFO - 2023-08-16 17:06:29 --> Output Class Initialized
INFO - 2023-08-16 17:06:29 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:29 --> Input Class Initialized
INFO - 2023-08-16 17:06:29 --> Language Class Initialized
INFO - 2023-08-16 17:06:29 --> Loader Class Initialized
INFO - 2023-08-16 17:06:29 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:29 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:29 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:29 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:29 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:29 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:29 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:29 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:29 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:29 --> Parser Class Initialized
INFO - 2023-08-16 17:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:29 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:29 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:29 --> Controller Class Initialized
INFO - 2023-08-16 17:06:29 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:29 --> Model Class Initialized
INFO - 2023-08-16 17:06:29 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:29 --> Total execution time: 0.0235
ERROR - 2023-08-16 17:06:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:32 --> Config Class Initialized
INFO - 2023-08-16 17:06:32 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:32 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:32 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:32 --> URI Class Initialized
INFO - 2023-08-16 17:06:32 --> Router Class Initialized
INFO - 2023-08-16 17:06:32 --> Output Class Initialized
INFO - 2023-08-16 17:06:32 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:32 --> Input Class Initialized
INFO - 2023-08-16 17:06:32 --> Language Class Initialized
INFO - 2023-08-16 17:06:32 --> Loader Class Initialized
INFO - 2023-08-16 17:06:32 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:32 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:32 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:32 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:32 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:32 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:32 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:32 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:32 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:32 --> Parser Class Initialized
INFO - 2023-08-16 17:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:32 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:32 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:32 --> Controller Class Initialized
INFO - 2023-08-16 17:06:32 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:32 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-16 17:06:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:06:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:06:32 --> Model Class Initialized
INFO - 2023-08-16 17:06:32 --> Model Class Initialized
INFO - 2023-08-16 17:06:32 --> Model Class Initialized
INFO - 2023-08-16 17:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:06:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:06:33 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:33 --> Total execution time: 0.1272
ERROR - 2023-08-16 17:06:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:36 --> Config Class Initialized
INFO - 2023-08-16 17:06:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:36 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:36 --> URI Class Initialized
INFO - 2023-08-16 17:06:36 --> Router Class Initialized
INFO - 2023-08-16 17:06:36 --> Output Class Initialized
INFO - 2023-08-16 17:06:36 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:36 --> Input Class Initialized
INFO - 2023-08-16 17:06:36 --> Language Class Initialized
INFO - 2023-08-16 17:06:36 --> Loader Class Initialized
INFO - 2023-08-16 17:06:36 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:36 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:36 --> Parser Class Initialized
INFO - 2023-08-16 17:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:36 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:36 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:36 --> Controller Class Initialized
INFO - 2023-08-16 17:06:36 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:36 --> Model Class Initialized
INFO - 2023-08-16 17:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:06:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:06:36 --> Model Class Initialized
INFO - 2023-08-16 17:06:36 --> Model Class Initialized
INFO - 2023-08-16 17:06:36 --> Model Class Initialized
INFO - 2023-08-16 17:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:06:36 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:36 --> Total execution time: 0.1210
ERROR - 2023-08-16 17:06:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:36 --> Config Class Initialized
INFO - 2023-08-16 17:06:36 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:36 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:36 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:36 --> URI Class Initialized
INFO - 2023-08-16 17:06:36 --> Router Class Initialized
INFO - 2023-08-16 17:06:36 --> Output Class Initialized
INFO - 2023-08-16 17:06:36 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:36 --> Input Class Initialized
INFO - 2023-08-16 17:06:36 --> Language Class Initialized
INFO - 2023-08-16 17:06:36 --> Loader Class Initialized
INFO - 2023-08-16 17:06:36 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:36 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:36 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:36 --> Parser Class Initialized
INFO - 2023-08-16 17:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:36 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:36 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:36 --> Controller Class Initialized
INFO - 2023-08-16 17:06:36 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:36 --> Model Class Initialized
INFO - 2023-08-16 17:06:36 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:36 --> Total execution time: 0.0210
ERROR - 2023-08-16 17:06:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:38 --> Config Class Initialized
INFO - 2023-08-16 17:06:38 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:38 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:38 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:38 --> URI Class Initialized
INFO - 2023-08-16 17:06:38 --> Router Class Initialized
INFO - 2023-08-16 17:06:38 --> Output Class Initialized
INFO - 2023-08-16 17:06:38 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:38 --> Input Class Initialized
INFO - 2023-08-16 17:06:38 --> Language Class Initialized
INFO - 2023-08-16 17:06:38 --> Loader Class Initialized
INFO - 2023-08-16 17:06:38 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:38 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:38 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:38 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:38 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:38 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:38 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:38 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:38 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:38 --> Parser Class Initialized
INFO - 2023-08-16 17:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:38 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:38 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:38 --> Controller Class Initialized
INFO - 2023-08-16 17:06:38 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:38 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-16 17:06:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:06:38 --> Model Class Initialized
INFO - 2023-08-16 17:06:38 --> Model Class Initialized
INFO - 2023-08-16 17:06:38 --> Model Class Initialized
INFO - 2023-08-16 17:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:06:38 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:38 --> Total execution time: 0.1245
ERROR - 2023-08-16 17:06:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:47 --> Config Class Initialized
INFO - 2023-08-16 17:06:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:47 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:47 --> URI Class Initialized
INFO - 2023-08-16 17:06:47 --> Router Class Initialized
INFO - 2023-08-16 17:06:47 --> Output Class Initialized
INFO - 2023-08-16 17:06:47 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:47 --> Input Class Initialized
INFO - 2023-08-16 17:06:47 --> Language Class Initialized
INFO - 2023-08-16 17:06:47 --> Loader Class Initialized
INFO - 2023-08-16 17:06:47 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:47 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:47 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:47 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:47 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:47 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:47 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:47 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:47 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:47 --> Parser Class Initialized
INFO - 2023-08-16 17:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:47 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:47 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:47 --> Controller Class Initialized
INFO - 2023-08-16 17:06:47 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:47 --> Model Class Initialized
INFO - 2023-08-16 17:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-16 17:06:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:06:47 --> Model Class Initialized
INFO - 2023-08-16 17:06:47 --> Model Class Initialized
INFO - 2023-08-16 17:06:47 --> Model Class Initialized
INFO - 2023-08-16 17:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:06:47 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:47 --> Total execution time: 0.1302
ERROR - 2023-08-16 17:06:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:48 --> Config Class Initialized
INFO - 2023-08-16 17:06:48 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:48 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:48 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:48 --> URI Class Initialized
INFO - 2023-08-16 17:06:48 --> Router Class Initialized
INFO - 2023-08-16 17:06:48 --> Output Class Initialized
INFO - 2023-08-16 17:06:48 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:48 --> Input Class Initialized
INFO - 2023-08-16 17:06:48 --> Language Class Initialized
INFO - 2023-08-16 17:06:48 --> Loader Class Initialized
INFO - 2023-08-16 17:06:48 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:48 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:48 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:48 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:48 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:48 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:48 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:48 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:48 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:48 --> Parser Class Initialized
INFO - 2023-08-16 17:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:48 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:48 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:48 --> Controller Class Initialized
INFO - 2023-08-16 17:06:48 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:48 --> Model Class Initialized
INFO - 2023-08-16 17:06:48 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:48 --> Total execution time: 0.0221
ERROR - 2023-08-16 17:06:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:52 --> Config Class Initialized
INFO - 2023-08-16 17:06:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:52 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:52 --> URI Class Initialized
INFO - 2023-08-16 17:06:52 --> Router Class Initialized
INFO - 2023-08-16 17:06:52 --> Output Class Initialized
INFO - 2023-08-16 17:06:52 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:52 --> Input Class Initialized
INFO - 2023-08-16 17:06:52 --> Language Class Initialized
INFO - 2023-08-16 17:06:52 --> Loader Class Initialized
INFO - 2023-08-16 17:06:52 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:52 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:52 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:52 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:52 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:52 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:52 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:52 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:52 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:52 --> Parser Class Initialized
INFO - 2023-08-16 17:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:52 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:52 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:52 --> Controller Class Initialized
INFO - 2023-08-16 17:06:52 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:52 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:52 --> Model Class Initialized
INFO - 2023-08-16 17:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 17:06:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:06:52 --> Model Class Initialized
INFO - 2023-08-16 17:06:52 --> Model Class Initialized
INFO - 2023-08-16 17:06:52 --> Model Class Initialized
INFO - 2023-08-16 17:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:06:52 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:52 --> Total execution time: 0.1346
ERROR - 2023-08-16 17:06:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:53 --> Config Class Initialized
INFO - 2023-08-16 17:06:53 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:53 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:53 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:53 --> URI Class Initialized
INFO - 2023-08-16 17:06:53 --> Router Class Initialized
INFO - 2023-08-16 17:06:53 --> Output Class Initialized
INFO - 2023-08-16 17:06:53 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:53 --> Input Class Initialized
INFO - 2023-08-16 17:06:53 --> Language Class Initialized
INFO - 2023-08-16 17:06:53 --> Loader Class Initialized
INFO - 2023-08-16 17:06:53 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:53 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:53 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:53 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:53 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:53 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:53 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:53 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:53 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:53 --> Parser Class Initialized
INFO - 2023-08-16 17:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:53 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:53 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:53 --> Controller Class Initialized
INFO - 2023-08-16 17:06:53 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:53 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:53 --> Model Class Initialized
INFO - 2023-08-16 17:06:53 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:53 --> Total execution time: 0.0560
ERROR - 2023-08-16 17:06:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:56 --> Config Class Initialized
INFO - 2023-08-16 17:06:56 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:56 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:56 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:56 --> URI Class Initialized
INFO - 2023-08-16 17:06:56 --> Router Class Initialized
INFO - 2023-08-16 17:06:56 --> Output Class Initialized
INFO - 2023-08-16 17:06:56 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:56 --> Input Class Initialized
INFO - 2023-08-16 17:06:56 --> Language Class Initialized
INFO - 2023-08-16 17:06:56 --> Loader Class Initialized
INFO - 2023-08-16 17:06:56 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:56 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:56 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:56 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:56 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:56 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:56 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:56 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:56 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:56 --> Parser Class Initialized
INFO - 2023-08-16 17:06:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:56 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:56 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:56 --> Controller Class Initialized
INFO - 2023-08-16 17:06:56 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:56 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:56 --> Model Class Initialized
INFO - 2023-08-16 17:06:56 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:56 --> Total execution time: 0.0571
ERROR - 2023-08-16 17:06:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:57 --> Config Class Initialized
INFO - 2023-08-16 17:06:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:57 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:57 --> URI Class Initialized
INFO - 2023-08-16 17:06:57 --> Router Class Initialized
INFO - 2023-08-16 17:06:57 --> Output Class Initialized
INFO - 2023-08-16 17:06:57 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:57 --> Input Class Initialized
INFO - 2023-08-16 17:06:57 --> Language Class Initialized
INFO - 2023-08-16 17:06:57 --> Loader Class Initialized
INFO - 2023-08-16 17:06:57 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:57 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:57 --> Parser Class Initialized
INFO - 2023-08-16 17:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:57 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:57 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:57 --> Controller Class Initialized
INFO - 2023-08-16 17:06:57 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:57 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:57 --> Model Class Initialized
INFO - 2023-08-16 17:06:57 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:57 --> Total execution time: 0.0538
ERROR - 2023-08-16 17:06:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:57 --> Config Class Initialized
INFO - 2023-08-16 17:06:57 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:57 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:57 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:57 --> URI Class Initialized
INFO - 2023-08-16 17:06:57 --> Router Class Initialized
INFO - 2023-08-16 17:06:57 --> Output Class Initialized
INFO - 2023-08-16 17:06:57 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:57 --> Input Class Initialized
INFO - 2023-08-16 17:06:57 --> Language Class Initialized
INFO - 2023-08-16 17:06:57 --> Loader Class Initialized
INFO - 2023-08-16 17:06:57 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:57 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:57 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:57 --> Parser Class Initialized
INFO - 2023-08-16 17:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:57 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:57 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:57 --> Controller Class Initialized
INFO - 2023-08-16 17:06:57 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:57 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:57 --> Model Class Initialized
INFO - 2023-08-16 17:06:57 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:57 --> Total execution time: 0.0255
ERROR - 2023-08-16 17:06:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:06:58 --> Config Class Initialized
INFO - 2023-08-16 17:06:58 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:06:58 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:06:58 --> Utf8 Class Initialized
INFO - 2023-08-16 17:06:58 --> URI Class Initialized
INFO - 2023-08-16 17:06:58 --> Router Class Initialized
INFO - 2023-08-16 17:06:58 --> Output Class Initialized
INFO - 2023-08-16 17:06:58 --> Security Class Initialized
DEBUG - 2023-08-16 17:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:06:58 --> Input Class Initialized
INFO - 2023-08-16 17:06:58 --> Language Class Initialized
INFO - 2023-08-16 17:06:58 --> Loader Class Initialized
INFO - 2023-08-16 17:06:58 --> Helper loaded: url_helper
INFO - 2023-08-16 17:06:58 --> Helper loaded: file_helper
INFO - 2023-08-16 17:06:58 --> Helper loaded: html_helper
INFO - 2023-08-16 17:06:58 --> Helper loaded: text_helper
INFO - 2023-08-16 17:06:58 --> Helper loaded: form_helper
INFO - 2023-08-16 17:06:58 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:06:58 --> Helper loaded: security_helper
INFO - 2023-08-16 17:06:58 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:06:58 --> Database Driver Class Initialized
INFO - 2023-08-16 17:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:06:58 --> Parser Class Initialized
INFO - 2023-08-16 17:06:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:06:58 --> Pagination Class Initialized
INFO - 2023-08-16 17:06:58 --> Form Validation Class Initialized
INFO - 2023-08-16 17:06:58 --> Controller Class Initialized
INFO - 2023-08-16 17:06:58 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:58 --> Model Class Initialized
DEBUG - 2023-08-16 17:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:06:58 --> Model Class Initialized
INFO - 2023-08-16 17:06:58 --> Final output sent to browser
DEBUG - 2023-08-16 17:06:58 --> Total execution time: 0.0252
ERROR - 2023-08-16 17:07:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:07:00 --> Config Class Initialized
INFO - 2023-08-16 17:07:00 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:07:00 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:07:00 --> Utf8 Class Initialized
INFO - 2023-08-16 17:07:00 --> URI Class Initialized
INFO - 2023-08-16 17:07:00 --> Router Class Initialized
INFO - 2023-08-16 17:07:00 --> Output Class Initialized
INFO - 2023-08-16 17:07:00 --> Security Class Initialized
DEBUG - 2023-08-16 17:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:07:00 --> Input Class Initialized
INFO - 2023-08-16 17:07:00 --> Language Class Initialized
INFO - 2023-08-16 17:07:00 --> Loader Class Initialized
INFO - 2023-08-16 17:07:00 --> Helper loaded: url_helper
INFO - 2023-08-16 17:07:00 --> Helper loaded: file_helper
INFO - 2023-08-16 17:07:00 --> Helper loaded: html_helper
INFO - 2023-08-16 17:07:00 --> Helper loaded: text_helper
INFO - 2023-08-16 17:07:00 --> Helper loaded: form_helper
INFO - 2023-08-16 17:07:00 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:07:00 --> Helper loaded: security_helper
INFO - 2023-08-16 17:07:00 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:07:00 --> Database Driver Class Initialized
INFO - 2023-08-16 17:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:07:00 --> Parser Class Initialized
INFO - 2023-08-16 17:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:07:00 --> Pagination Class Initialized
INFO - 2023-08-16 17:07:00 --> Form Validation Class Initialized
INFO - 2023-08-16 17:07:00 --> Controller Class Initialized
INFO - 2023-08-16 17:07:00 --> Model Class Initialized
DEBUG - 2023-08-16 17:07:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:00 --> Model Class Initialized
DEBUG - 2023-08-16 17:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:00 --> Model Class Initialized
DEBUG - 2023-08-16 17:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-16 17:07:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:07:00 --> Model Class Initialized
INFO - 2023-08-16 17:07:00 --> Model Class Initialized
INFO - 2023-08-16 17:07:00 --> Model Class Initialized
INFO - 2023-08-16 17:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:07:00 --> Final output sent to browser
DEBUG - 2023-08-16 17:07:00 --> Total execution time: 0.1482
ERROR - 2023-08-16 17:07:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:07:15 --> Config Class Initialized
INFO - 2023-08-16 17:07:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:07:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:07:15 --> Utf8 Class Initialized
INFO - 2023-08-16 17:07:15 --> URI Class Initialized
DEBUG - 2023-08-16 17:07:15 --> No URI present. Default controller set.
INFO - 2023-08-16 17:07:15 --> Router Class Initialized
INFO - 2023-08-16 17:07:15 --> Output Class Initialized
INFO - 2023-08-16 17:07:15 --> Security Class Initialized
DEBUG - 2023-08-16 17:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:07:15 --> Input Class Initialized
INFO - 2023-08-16 17:07:15 --> Language Class Initialized
INFO - 2023-08-16 17:07:15 --> Loader Class Initialized
INFO - 2023-08-16 17:07:15 --> Helper loaded: url_helper
INFO - 2023-08-16 17:07:15 --> Helper loaded: file_helper
INFO - 2023-08-16 17:07:15 --> Helper loaded: html_helper
INFO - 2023-08-16 17:07:15 --> Helper loaded: text_helper
INFO - 2023-08-16 17:07:15 --> Helper loaded: form_helper
INFO - 2023-08-16 17:07:15 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:07:15 --> Helper loaded: security_helper
INFO - 2023-08-16 17:07:15 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:07:15 --> Database Driver Class Initialized
INFO - 2023-08-16 17:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:07:15 --> Parser Class Initialized
INFO - 2023-08-16 17:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:07:15 --> Pagination Class Initialized
INFO - 2023-08-16 17:07:15 --> Form Validation Class Initialized
INFO - 2023-08-16 17:07:15 --> Controller Class Initialized
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
DEBUG - 2023-08-16 17:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
DEBUG - 2023-08-16 17:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
DEBUG - 2023-08-16 17:07:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
INFO - 2023-08-16 17:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-16 17:07:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:07:15 --> Model Class Initialized
INFO - 2023-08-16 17:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:07:15 --> Final output sent to browser
DEBUG - 2023-08-16 17:07:15 --> Total execution time: 0.1932
ERROR - 2023-08-16 17:09:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:09:46 --> Config Class Initialized
INFO - 2023-08-16 17:09:46 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:46 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:46 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:46 --> URI Class Initialized
INFO - 2023-08-16 17:09:46 --> Router Class Initialized
INFO - 2023-08-16 17:09:46 --> Output Class Initialized
INFO - 2023-08-16 17:09:46 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:46 --> Input Class Initialized
INFO - 2023-08-16 17:09:46 --> Language Class Initialized
INFO - 2023-08-16 17:09:46 --> Loader Class Initialized
INFO - 2023-08-16 17:09:46 --> Helper loaded: url_helper
INFO - 2023-08-16 17:09:46 --> Helper loaded: file_helper
INFO - 2023-08-16 17:09:46 --> Helper loaded: html_helper
INFO - 2023-08-16 17:09:46 --> Helper loaded: text_helper
INFO - 2023-08-16 17:09:46 --> Helper loaded: form_helper
INFO - 2023-08-16 17:09:46 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:09:46 --> Helper loaded: security_helper
INFO - 2023-08-16 17:09:46 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:09:46 --> Database Driver Class Initialized
INFO - 2023-08-16 17:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:09:46 --> Parser Class Initialized
INFO - 2023-08-16 17:09:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:09:46 --> Pagination Class Initialized
INFO - 2023-08-16 17:09:46 --> Form Validation Class Initialized
INFO - 2023-08-16 17:09:46 --> Controller Class Initialized
INFO - 2023-08-16 17:09:46 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:46 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:46 --> Model Class Initialized
INFO - 2023-08-16 17:09:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-16 17:09:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:09:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:09:46 --> Model Class Initialized
INFO - 2023-08-16 17:09:46 --> Model Class Initialized
INFO - 2023-08-16 17:09:46 --> Model Class Initialized
INFO - 2023-08-16 17:09:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:09:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:09:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:09:46 --> Final output sent to browser
DEBUG - 2023-08-16 17:09:46 --> Total execution time: 0.1358
ERROR - 2023-08-16 17:09:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:09:47 --> Config Class Initialized
INFO - 2023-08-16 17:09:47 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:47 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:47 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:47 --> URI Class Initialized
INFO - 2023-08-16 17:09:47 --> Router Class Initialized
INFO - 2023-08-16 17:09:47 --> Output Class Initialized
INFO - 2023-08-16 17:09:47 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:47 --> Input Class Initialized
INFO - 2023-08-16 17:09:47 --> Language Class Initialized
INFO - 2023-08-16 17:09:47 --> Loader Class Initialized
INFO - 2023-08-16 17:09:47 --> Helper loaded: url_helper
INFO - 2023-08-16 17:09:47 --> Helper loaded: file_helper
INFO - 2023-08-16 17:09:47 --> Helper loaded: html_helper
INFO - 2023-08-16 17:09:47 --> Helper loaded: text_helper
INFO - 2023-08-16 17:09:47 --> Helper loaded: form_helper
INFO - 2023-08-16 17:09:47 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:09:47 --> Helper loaded: security_helper
INFO - 2023-08-16 17:09:47 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:09:47 --> Database Driver Class Initialized
INFO - 2023-08-16 17:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:09:47 --> Parser Class Initialized
INFO - 2023-08-16 17:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:09:47 --> Pagination Class Initialized
INFO - 2023-08-16 17:09:47 --> Form Validation Class Initialized
INFO - 2023-08-16 17:09:47 --> Controller Class Initialized
INFO - 2023-08-16 17:09:47 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:47 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:47 --> Model Class Initialized
INFO - 2023-08-16 17:09:47 --> Final output sent to browser
DEBUG - 2023-08-16 17:09:47 --> Total execution time: 0.0486
ERROR - 2023-08-16 17:09:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:09:52 --> Config Class Initialized
INFO - 2023-08-16 17:09:52 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:52 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:52 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:52 --> URI Class Initialized
INFO - 2023-08-16 17:09:52 --> Router Class Initialized
INFO - 2023-08-16 17:09:52 --> Output Class Initialized
INFO - 2023-08-16 17:09:52 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:52 --> Input Class Initialized
INFO - 2023-08-16 17:09:52 --> Language Class Initialized
INFO - 2023-08-16 17:09:52 --> Loader Class Initialized
INFO - 2023-08-16 17:09:52 --> Helper loaded: url_helper
INFO - 2023-08-16 17:09:52 --> Helper loaded: file_helper
INFO - 2023-08-16 17:09:52 --> Helper loaded: html_helper
INFO - 2023-08-16 17:09:52 --> Helper loaded: text_helper
INFO - 2023-08-16 17:09:52 --> Helper loaded: form_helper
INFO - 2023-08-16 17:09:52 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:09:52 --> Helper loaded: security_helper
INFO - 2023-08-16 17:09:52 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:09:52 --> Database Driver Class Initialized
INFO - 2023-08-16 17:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:09:52 --> Parser Class Initialized
INFO - 2023-08-16 17:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:09:52 --> Pagination Class Initialized
INFO - 2023-08-16 17:09:52 --> Form Validation Class Initialized
INFO - 2023-08-16 17:09:52 --> Controller Class Initialized
INFO - 2023-08-16 17:09:52 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:52 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:52 --> Model Class Initialized
INFO - 2023-08-16 17:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-08-16 17:09:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:09:52 --> Model Class Initialized
INFO - 2023-08-16 17:09:52 --> Model Class Initialized
INFO - 2023-08-16 17:09:52 --> Model Class Initialized
INFO - 2023-08-16 17:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:09:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:09:52 --> Final output sent to browser
DEBUG - 2023-08-16 17:09:52 --> Total execution time: 0.1286
ERROR - 2023-08-16 17:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:09:59 --> Config Class Initialized
INFO - 2023-08-16 17:09:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:59 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:59 --> URI Class Initialized
INFO - 2023-08-16 17:09:59 --> Router Class Initialized
INFO - 2023-08-16 17:09:59 --> Output Class Initialized
INFO - 2023-08-16 17:09:59 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:59 --> Input Class Initialized
INFO - 2023-08-16 17:09:59 --> Language Class Initialized
INFO - 2023-08-16 17:09:59 --> Loader Class Initialized
INFO - 2023-08-16 17:09:59 --> Helper loaded: url_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: file_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: html_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: text_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: form_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: security_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:09:59 --> Database Driver Class Initialized
INFO - 2023-08-16 17:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:09:59 --> Parser Class Initialized
INFO - 2023-08-16 17:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:09:59 --> Pagination Class Initialized
INFO - 2023-08-16 17:09:59 --> Form Validation Class Initialized
INFO - 2023-08-16 17:09:59 --> Controller Class Initialized
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
INFO - 2023-08-16 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-16 17:09:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-16 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
INFO - 2023-08-16 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-16 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-16 17:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-16 17:09:59 --> Final output sent to browser
DEBUG - 2023-08-16 17:09:59 --> Total execution time: 0.1428
ERROR - 2023-08-16 17:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-16 17:09:59 --> Config Class Initialized
INFO - 2023-08-16 17:09:59 --> Hooks Class Initialized
DEBUG - 2023-08-16 17:09:59 --> UTF-8 Support Enabled
INFO - 2023-08-16 17:09:59 --> Utf8 Class Initialized
INFO - 2023-08-16 17:09:59 --> URI Class Initialized
INFO - 2023-08-16 17:09:59 --> Router Class Initialized
INFO - 2023-08-16 17:09:59 --> Output Class Initialized
INFO - 2023-08-16 17:09:59 --> Security Class Initialized
DEBUG - 2023-08-16 17:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 17:09:59 --> Input Class Initialized
INFO - 2023-08-16 17:09:59 --> Language Class Initialized
INFO - 2023-08-16 17:09:59 --> Loader Class Initialized
INFO - 2023-08-16 17:09:59 --> Helper loaded: url_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: file_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: html_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: text_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: form_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: lang_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: security_helper
INFO - 2023-08-16 17:09:59 --> Helper loaded: cookie_helper
INFO - 2023-08-16 17:09:59 --> Database Driver Class Initialized
INFO - 2023-08-16 17:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 17:09:59 --> Parser Class Initialized
INFO - 2023-08-16 17:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-16 17:09:59 --> Pagination Class Initialized
INFO - 2023-08-16 17:09:59 --> Form Validation Class Initialized
INFO - 2023-08-16 17:09:59 --> Controller Class Initialized
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-16 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
DEBUG - 2023-08-16 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-16 17:09:59 --> Model Class Initialized
INFO - 2023-08-16 17:09:59 --> Final output sent to browser
DEBUG - 2023-08-16 17:09:59 --> Total execution time: 0.0595
