<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-02 01:51:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 01:51:44 --> Config Class Initialized
INFO - 2023-09-02 01:51:44 --> Hooks Class Initialized
DEBUG - 2023-09-02 01:51:44 --> UTF-8 Support Enabled
INFO - 2023-09-02 01:51:44 --> Utf8 Class Initialized
INFO - 2023-09-02 01:51:44 --> URI Class Initialized
DEBUG - 2023-09-02 01:51:44 --> No URI present. Default controller set.
INFO - 2023-09-02 01:51:44 --> Router Class Initialized
INFO - 2023-09-02 01:51:44 --> Output Class Initialized
INFO - 2023-09-02 01:51:44 --> Security Class Initialized
DEBUG - 2023-09-02 01:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 01:51:44 --> Input Class Initialized
INFO - 2023-09-02 01:51:44 --> Language Class Initialized
INFO - 2023-09-02 01:51:44 --> Loader Class Initialized
INFO - 2023-09-02 01:51:44 --> Helper loaded: url_helper
INFO - 2023-09-02 01:51:44 --> Helper loaded: file_helper
INFO - 2023-09-02 01:51:44 --> Helper loaded: html_helper
INFO - 2023-09-02 01:51:44 --> Helper loaded: text_helper
INFO - 2023-09-02 01:51:44 --> Helper loaded: form_helper
INFO - 2023-09-02 01:51:44 --> Helper loaded: lang_helper
INFO - 2023-09-02 01:51:44 --> Helper loaded: security_helper
INFO - 2023-09-02 01:51:44 --> Helper loaded: cookie_helper
INFO - 2023-09-02 01:51:44 --> Database Driver Class Initialized
INFO - 2023-09-02 01:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 01:51:44 --> Parser Class Initialized
INFO - 2023-09-02 01:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 01:51:44 --> Pagination Class Initialized
INFO - 2023-09-02 01:51:44 --> Form Validation Class Initialized
INFO - 2023-09-02 01:51:44 --> Controller Class Initialized
INFO - 2023-09-02 01:51:44 --> Model Class Initialized
DEBUG - 2023-09-02 01:51:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 03:22:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:04 --> Config Class Initialized
INFO - 2023-09-02 03:22:04 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:04 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:04 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:04 --> URI Class Initialized
DEBUG - 2023-09-02 03:22:04 --> No URI present. Default controller set.
INFO - 2023-09-02 03:22:04 --> Router Class Initialized
INFO - 2023-09-02 03:22:04 --> Output Class Initialized
INFO - 2023-09-02 03:22:04 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:04 --> Input Class Initialized
INFO - 2023-09-02 03:22:04 --> Language Class Initialized
INFO - 2023-09-02 03:22:04 --> Loader Class Initialized
INFO - 2023-09-02 03:22:04 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:04 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:04 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:04 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:04 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:04 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:04 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:04 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:04 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:05 --> Parser Class Initialized
INFO - 2023-09-02 03:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:05 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:05 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:05 --> Controller Class Initialized
INFO - 2023-09-02 03:22:05 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 03:22:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:05 --> Config Class Initialized
INFO - 2023-09-02 03:22:05 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:05 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:05 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:05 --> URI Class Initialized
INFO - 2023-09-02 03:22:05 --> Router Class Initialized
INFO - 2023-09-02 03:22:05 --> Output Class Initialized
INFO - 2023-09-02 03:22:05 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:05 --> Input Class Initialized
INFO - 2023-09-02 03:22:05 --> Language Class Initialized
INFO - 2023-09-02 03:22:05 --> Loader Class Initialized
INFO - 2023-09-02 03:22:05 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:05 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:05 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:05 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:05 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:05 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:05 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:05 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:05 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:05 --> Parser Class Initialized
INFO - 2023-09-02 03:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:05 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:05 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:05 --> Controller Class Initialized
INFO - 2023-09-02 03:22:05 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 03:22:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 03:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 03:22:05 --> Model Class Initialized
INFO - 2023-09-02 03:22:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 03:22:05 --> Final output sent to browser
DEBUG - 2023-09-02 03:22:05 --> Total execution time: 0.0400
ERROR - 2023-09-02 03:22:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:24 --> Config Class Initialized
INFO - 2023-09-02 03:22:24 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:24 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:24 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:24 --> URI Class Initialized
INFO - 2023-09-02 03:22:24 --> Router Class Initialized
INFO - 2023-09-02 03:22:24 --> Output Class Initialized
INFO - 2023-09-02 03:22:24 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:24 --> Input Class Initialized
INFO - 2023-09-02 03:22:24 --> Language Class Initialized
INFO - 2023-09-02 03:22:24 --> Loader Class Initialized
INFO - 2023-09-02 03:22:24 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:24 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:24 --> Parser Class Initialized
INFO - 2023-09-02 03:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:24 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:24 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:24 --> Controller Class Initialized
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
INFO - 2023-09-02 03:22:24 --> Final output sent to browser
DEBUG - 2023-09-02 03:22:24 --> Total execution time: 0.0222
ERROR - 2023-09-02 03:22:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:24 --> Config Class Initialized
INFO - 2023-09-02 03:22:24 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:24 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:24 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:24 --> URI Class Initialized
DEBUG - 2023-09-02 03:22:24 --> No URI present. Default controller set.
INFO - 2023-09-02 03:22:24 --> Router Class Initialized
INFO - 2023-09-02 03:22:24 --> Output Class Initialized
INFO - 2023-09-02 03:22:24 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:24 --> Input Class Initialized
INFO - 2023-09-02 03:22:24 --> Language Class Initialized
INFO - 2023-09-02 03:22:24 --> Loader Class Initialized
INFO - 2023-09-02 03:22:24 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:24 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:24 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:24 --> Parser Class Initialized
INFO - 2023-09-02 03:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:24 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:24 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:24 --> Controller Class Initialized
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 03:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
INFO - 2023-09-02 03:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 03:22:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 03:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 03:22:24 --> Model Class Initialized
INFO - 2023-09-02 03:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 03:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 03:22:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 03:22:24 --> Final output sent to browser
DEBUG - 2023-09-02 03:22:24 --> Total execution time: 0.0910
ERROR - 2023-09-02 03:22:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:43 --> Config Class Initialized
INFO - 2023-09-02 03:22:43 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:43 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:43 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:43 --> URI Class Initialized
INFO - 2023-09-02 03:22:43 --> Router Class Initialized
INFO - 2023-09-02 03:22:43 --> Output Class Initialized
INFO - 2023-09-02 03:22:43 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:43 --> Input Class Initialized
INFO - 2023-09-02 03:22:43 --> Language Class Initialized
INFO - 2023-09-02 03:22:43 --> Loader Class Initialized
INFO - 2023-09-02 03:22:43 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:43 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:43 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:43 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:43 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:43 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:43 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:43 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:43 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:43 --> Parser Class Initialized
INFO - 2023-09-02 03:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:43 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:43 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:43 --> Controller Class Initialized
INFO - 2023-09-02 03:22:43 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 03:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:43 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:43 --> Model Class Initialized
INFO - 2023-09-02 03:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-02 03:22:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 03:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 03:22:43 --> Model Class Initialized
INFO - 2023-09-02 03:22:43 --> Model Class Initialized
INFO - 2023-09-02 03:22:43 --> Model Class Initialized
INFO - 2023-09-02 03:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 03:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 03:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 03:22:43 --> Final output sent to browser
DEBUG - 2023-09-02 03:22:43 --> Total execution time: 0.0794
ERROR - 2023-09-02 03:22:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:44 --> Config Class Initialized
INFO - 2023-09-02 03:22:44 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:44 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:44 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:44 --> URI Class Initialized
INFO - 2023-09-02 03:22:44 --> Router Class Initialized
INFO - 2023-09-02 03:22:44 --> Output Class Initialized
INFO - 2023-09-02 03:22:44 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:44 --> Input Class Initialized
INFO - 2023-09-02 03:22:44 --> Language Class Initialized
INFO - 2023-09-02 03:22:44 --> Loader Class Initialized
INFO - 2023-09-02 03:22:44 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:44 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:44 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:44 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:44 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:44 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:44 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:44 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:44 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:44 --> Parser Class Initialized
INFO - 2023-09-02 03:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:44 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:44 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:44 --> Controller Class Initialized
INFO - 2023-09-02 03:22:44 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 03:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:44 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:44 --> Model Class Initialized
INFO - 2023-09-02 03:22:44 --> Final output sent to browser
DEBUG - 2023-09-02 03:22:44 --> Total execution time: 0.0215
ERROR - 2023-09-02 03:22:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:53 --> Config Class Initialized
INFO - 2023-09-02 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:53 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:53 --> URI Class Initialized
INFO - 2023-09-02 03:22:53 --> Router Class Initialized
INFO - 2023-09-02 03:22:53 --> Output Class Initialized
INFO - 2023-09-02 03:22:53 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:53 --> Input Class Initialized
INFO - 2023-09-02 03:22:53 --> Language Class Initialized
INFO - 2023-09-02 03:22:53 --> Loader Class Initialized
INFO - 2023-09-02 03:22:53 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:53 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:53 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:53 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:53 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:53 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:53 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:53 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:53 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:53 --> Parser Class Initialized
INFO - 2023-09-02 03:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:53 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:53 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:53 --> Controller Class Initialized
INFO - 2023-09-02 03:22:53 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 03:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:53 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:53 --> Model Class Initialized
INFO - 2023-09-02 03:22:53 --> Final output sent to browser
DEBUG - 2023-09-02 03:22:53 --> Total execution time: 0.0207
ERROR - 2023-09-02 03:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:22:59 --> Config Class Initialized
INFO - 2023-09-02 03:22:59 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:22:59 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:22:59 --> Utf8 Class Initialized
INFO - 2023-09-02 03:22:59 --> URI Class Initialized
DEBUG - 2023-09-02 03:22:59 --> No URI present. Default controller set.
INFO - 2023-09-02 03:22:59 --> Router Class Initialized
INFO - 2023-09-02 03:22:59 --> Output Class Initialized
INFO - 2023-09-02 03:22:59 --> Security Class Initialized
DEBUG - 2023-09-02 03:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:22:59 --> Input Class Initialized
INFO - 2023-09-02 03:22:59 --> Language Class Initialized
INFO - 2023-09-02 03:22:59 --> Loader Class Initialized
INFO - 2023-09-02 03:22:59 --> Helper loaded: url_helper
INFO - 2023-09-02 03:22:59 --> Helper loaded: file_helper
INFO - 2023-09-02 03:22:59 --> Helper loaded: html_helper
INFO - 2023-09-02 03:22:59 --> Helper loaded: text_helper
INFO - 2023-09-02 03:22:59 --> Helper loaded: form_helper
INFO - 2023-09-02 03:22:59 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:22:59 --> Helper loaded: security_helper
INFO - 2023-09-02 03:22:59 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:22:59 --> Database Driver Class Initialized
INFO - 2023-09-02 03:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:22:59 --> Parser Class Initialized
INFO - 2023-09-02 03:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:22:59 --> Pagination Class Initialized
INFO - 2023-09-02 03:22:59 --> Form Validation Class Initialized
INFO - 2023-09-02 03:22:59 --> Controller Class Initialized
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
DEBUG - 2023-09-02 03:22:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 03:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
INFO - 2023-09-02 03:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 03:22:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 03:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 03:22:59 --> Model Class Initialized
INFO - 2023-09-02 03:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 03:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 03:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 03:22:59 --> Final output sent to browser
DEBUG - 2023-09-02 03:22:59 --> Total execution time: 0.0840
ERROR - 2023-09-02 03:23:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 03:23:25 --> Config Class Initialized
INFO - 2023-09-02 03:23:25 --> Hooks Class Initialized
DEBUG - 2023-09-02 03:23:25 --> UTF-8 Support Enabled
INFO - 2023-09-02 03:23:25 --> Utf8 Class Initialized
INFO - 2023-09-02 03:23:25 --> URI Class Initialized
INFO - 2023-09-02 03:23:25 --> Router Class Initialized
INFO - 2023-09-02 03:23:25 --> Output Class Initialized
INFO - 2023-09-02 03:23:25 --> Security Class Initialized
DEBUG - 2023-09-02 03:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 03:23:25 --> Input Class Initialized
INFO - 2023-09-02 03:23:25 --> Language Class Initialized
INFO - 2023-09-02 03:23:25 --> Loader Class Initialized
INFO - 2023-09-02 03:23:25 --> Helper loaded: url_helper
INFO - 2023-09-02 03:23:25 --> Helper loaded: file_helper
INFO - 2023-09-02 03:23:25 --> Helper loaded: html_helper
INFO - 2023-09-02 03:23:25 --> Helper loaded: text_helper
INFO - 2023-09-02 03:23:25 --> Helper loaded: form_helper
INFO - 2023-09-02 03:23:25 --> Helper loaded: lang_helper
INFO - 2023-09-02 03:23:25 --> Helper loaded: security_helper
INFO - 2023-09-02 03:23:25 --> Helper loaded: cookie_helper
INFO - 2023-09-02 03:23:25 --> Database Driver Class Initialized
INFO - 2023-09-02 03:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 03:23:25 --> Parser Class Initialized
INFO - 2023-09-02 03:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 03:23:25 --> Pagination Class Initialized
INFO - 2023-09-02 03:23:25 --> Form Validation Class Initialized
INFO - 2023-09-02 03:23:25 --> Controller Class Initialized
INFO - 2023-09-02 03:23:25 --> Model Class Initialized
DEBUG - 2023-09-02 03:23:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 03:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:23:25 --> Model Class Initialized
DEBUG - 2023-09-02 03:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-02 03:23:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 03:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 03:23:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 03:23:25 --> Model Class Initialized
INFO - 2023-09-02 03:23:25 --> Model Class Initialized
INFO - 2023-09-02 03:23:25 --> Model Class Initialized
INFO - 2023-09-02 03:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 03:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 03:23:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 03:23:26 --> Final output sent to browser
DEBUG - 2023-09-02 03:23:26 --> Total execution time: 0.0744
ERROR - 2023-09-02 06:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:47:13 --> Config Class Initialized
INFO - 2023-09-02 06:47:13 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:47:13 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:47:13 --> Utf8 Class Initialized
INFO - 2023-09-02 06:47:13 --> URI Class Initialized
DEBUG - 2023-09-02 06:47:13 --> No URI present. Default controller set.
INFO - 2023-09-02 06:47:13 --> Router Class Initialized
INFO - 2023-09-02 06:47:13 --> Output Class Initialized
INFO - 2023-09-02 06:47:13 --> Security Class Initialized
DEBUG - 2023-09-02 06:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:47:13 --> Input Class Initialized
INFO - 2023-09-02 06:47:13 --> Language Class Initialized
INFO - 2023-09-02 06:47:13 --> Loader Class Initialized
INFO - 2023-09-02 06:47:13 --> Helper loaded: url_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: file_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: html_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: text_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: form_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: security_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:47:13 --> Database Driver Class Initialized
INFO - 2023-09-02 06:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:47:13 --> Parser Class Initialized
INFO - 2023-09-02 06:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:47:13 --> Pagination Class Initialized
INFO - 2023-09-02 06:47:13 --> Form Validation Class Initialized
INFO - 2023-09-02 06:47:13 --> Controller Class Initialized
INFO - 2023-09-02 06:47:13 --> Model Class Initialized
DEBUG - 2023-09-02 06:47:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 06:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:47:13 --> Config Class Initialized
INFO - 2023-09-02 06:47:13 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:47:13 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:47:13 --> Utf8 Class Initialized
INFO - 2023-09-02 06:47:13 --> URI Class Initialized
INFO - 2023-09-02 06:47:13 --> Router Class Initialized
INFO - 2023-09-02 06:47:13 --> Output Class Initialized
INFO - 2023-09-02 06:47:13 --> Security Class Initialized
DEBUG - 2023-09-02 06:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:47:13 --> Input Class Initialized
INFO - 2023-09-02 06:47:13 --> Language Class Initialized
INFO - 2023-09-02 06:47:13 --> Loader Class Initialized
INFO - 2023-09-02 06:47:13 --> Helper loaded: url_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: file_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: html_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: text_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: form_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: security_helper
INFO - 2023-09-02 06:47:13 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:47:13 --> Database Driver Class Initialized
INFO - 2023-09-02 06:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:47:13 --> Parser Class Initialized
INFO - 2023-09-02 06:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:47:13 --> Pagination Class Initialized
INFO - 2023-09-02 06:47:13 --> Form Validation Class Initialized
INFO - 2023-09-02 06:47:13 --> Controller Class Initialized
INFO - 2023-09-02 06:47:13 --> Model Class Initialized
DEBUG - 2023-09-02 06:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 06:47:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:47:13 --> Model Class Initialized
INFO - 2023-09-02 06:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:47:13 --> Final output sent to browser
DEBUG - 2023-09-02 06:47:13 --> Total execution time: 0.0326
ERROR - 2023-09-02 06:48:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:48:05 --> Config Class Initialized
INFO - 2023-09-02 06:48:05 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:48:05 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:48:05 --> Utf8 Class Initialized
INFO - 2023-09-02 06:48:05 --> URI Class Initialized
INFO - 2023-09-02 06:48:05 --> Router Class Initialized
INFO - 2023-09-02 06:48:05 --> Output Class Initialized
INFO - 2023-09-02 06:48:05 --> Security Class Initialized
DEBUG - 2023-09-02 06:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:48:05 --> Input Class Initialized
INFO - 2023-09-02 06:48:05 --> Language Class Initialized
INFO - 2023-09-02 06:48:05 --> Loader Class Initialized
INFO - 2023-09-02 06:48:05 --> Helper loaded: url_helper
INFO - 2023-09-02 06:48:05 --> Helper loaded: file_helper
INFO - 2023-09-02 06:48:05 --> Helper loaded: html_helper
INFO - 2023-09-02 06:48:05 --> Helper loaded: text_helper
INFO - 2023-09-02 06:48:05 --> Helper loaded: form_helper
INFO - 2023-09-02 06:48:05 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:48:05 --> Helper loaded: security_helper
INFO - 2023-09-02 06:48:05 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:48:05 --> Database Driver Class Initialized
INFO - 2023-09-02 06:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:48:05 --> Parser Class Initialized
INFO - 2023-09-02 06:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:48:05 --> Pagination Class Initialized
INFO - 2023-09-02 06:48:05 --> Form Validation Class Initialized
INFO - 2023-09-02 06:48:05 --> Controller Class Initialized
INFO - 2023-09-02 06:48:05 --> Model Class Initialized
DEBUG - 2023-09-02 06:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:05 --> Model Class Initialized
INFO - 2023-09-02 06:48:05 --> Final output sent to browser
DEBUG - 2023-09-02 06:48:05 --> Total execution time: 0.0220
ERROR - 2023-09-02 06:48:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:48:07 --> Config Class Initialized
INFO - 2023-09-02 06:48:07 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:48:07 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:48:07 --> Utf8 Class Initialized
INFO - 2023-09-02 06:48:07 --> URI Class Initialized
DEBUG - 2023-09-02 06:48:07 --> No URI present. Default controller set.
INFO - 2023-09-02 06:48:07 --> Router Class Initialized
INFO - 2023-09-02 06:48:07 --> Output Class Initialized
INFO - 2023-09-02 06:48:07 --> Security Class Initialized
DEBUG - 2023-09-02 06:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:48:07 --> Input Class Initialized
INFO - 2023-09-02 06:48:07 --> Language Class Initialized
INFO - 2023-09-02 06:48:07 --> Loader Class Initialized
INFO - 2023-09-02 06:48:07 --> Helper loaded: url_helper
INFO - 2023-09-02 06:48:07 --> Helper loaded: file_helper
INFO - 2023-09-02 06:48:07 --> Helper loaded: html_helper
INFO - 2023-09-02 06:48:07 --> Helper loaded: text_helper
INFO - 2023-09-02 06:48:07 --> Helper loaded: form_helper
INFO - 2023-09-02 06:48:07 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:48:07 --> Helper loaded: security_helper
INFO - 2023-09-02 06:48:07 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:48:07 --> Database Driver Class Initialized
INFO - 2023-09-02 06:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:48:07 --> Parser Class Initialized
INFO - 2023-09-02 06:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:48:07 --> Pagination Class Initialized
INFO - 2023-09-02 06:48:07 --> Form Validation Class Initialized
INFO - 2023-09-02 06:48:07 --> Controller Class Initialized
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
DEBUG - 2023-09-02 06:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
DEBUG - 2023-09-02 06:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
DEBUG - 2023-09-02 06:48:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
INFO - 2023-09-02 06:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 06:48:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:48:07 --> Model Class Initialized
INFO - 2023-09-02 06:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:48:07 --> Final output sent to browser
DEBUG - 2023-09-02 06:48:07 --> Total execution time: 0.0880
ERROR - 2023-09-02 06:48:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:48:34 --> Config Class Initialized
INFO - 2023-09-02 06:48:34 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:48:34 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:48:34 --> Utf8 Class Initialized
INFO - 2023-09-02 06:48:34 --> URI Class Initialized
INFO - 2023-09-02 06:48:34 --> Router Class Initialized
INFO - 2023-09-02 06:48:34 --> Output Class Initialized
INFO - 2023-09-02 06:48:34 --> Security Class Initialized
DEBUG - 2023-09-02 06:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:48:34 --> Input Class Initialized
INFO - 2023-09-02 06:48:34 --> Language Class Initialized
INFO - 2023-09-02 06:48:34 --> Loader Class Initialized
INFO - 2023-09-02 06:48:34 --> Helper loaded: url_helper
INFO - 2023-09-02 06:48:34 --> Helper loaded: file_helper
INFO - 2023-09-02 06:48:34 --> Helper loaded: html_helper
INFO - 2023-09-02 06:48:34 --> Helper loaded: text_helper
INFO - 2023-09-02 06:48:34 --> Helper loaded: form_helper
INFO - 2023-09-02 06:48:34 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:48:34 --> Helper loaded: security_helper
INFO - 2023-09-02 06:48:34 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:48:34 --> Database Driver Class Initialized
INFO - 2023-09-02 06:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:48:34 --> Parser Class Initialized
INFO - 2023-09-02 06:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:48:34 --> Pagination Class Initialized
INFO - 2023-09-02 06:48:34 --> Form Validation Class Initialized
INFO - 2023-09-02 06:48:34 --> Controller Class Initialized
DEBUG - 2023-09-02 06:48:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:34 --> Model Class Initialized
DEBUG - 2023-09-02 06:48:34 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:34 --> Model Class Initialized
DEBUG - 2023-09-02 06:48:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:34 --> Model Class Initialized
DEBUG - 2023-09-02 06:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:34 --> Model Class Initialized
INFO - 2023-09-02 06:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-02 06:48:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:48:34 --> Model Class Initialized
INFO - 2023-09-02 06:48:34 --> Model Class Initialized
INFO - 2023-09-02 06:48:34 --> Model Class Initialized
INFO - 2023-09-02 06:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:48:34 --> Final output sent to browser
DEBUG - 2023-09-02 06:48:34 --> Total execution time: 0.0705
ERROR - 2023-09-02 06:48:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:48:36 --> Config Class Initialized
INFO - 2023-09-02 06:48:36 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:48:36 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:48:36 --> Utf8 Class Initialized
INFO - 2023-09-02 06:48:36 --> URI Class Initialized
INFO - 2023-09-02 06:48:36 --> Router Class Initialized
INFO - 2023-09-02 06:48:36 --> Output Class Initialized
INFO - 2023-09-02 06:48:36 --> Security Class Initialized
DEBUG - 2023-09-02 06:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:48:36 --> Input Class Initialized
INFO - 2023-09-02 06:48:36 --> Language Class Initialized
INFO - 2023-09-02 06:48:36 --> Loader Class Initialized
INFO - 2023-09-02 06:48:36 --> Helper loaded: url_helper
INFO - 2023-09-02 06:48:36 --> Helper loaded: file_helper
INFO - 2023-09-02 06:48:36 --> Helper loaded: html_helper
INFO - 2023-09-02 06:48:36 --> Helper loaded: text_helper
INFO - 2023-09-02 06:48:36 --> Helper loaded: form_helper
INFO - 2023-09-02 06:48:36 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:48:36 --> Helper loaded: security_helper
INFO - 2023-09-02 06:48:36 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:48:36 --> Database Driver Class Initialized
INFO - 2023-09-02 06:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:48:36 --> Parser Class Initialized
INFO - 2023-09-02 06:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:48:36 --> Pagination Class Initialized
INFO - 2023-09-02 06:48:36 --> Form Validation Class Initialized
INFO - 2023-09-02 06:48:36 --> Controller Class Initialized
DEBUG - 2023-09-02 06:48:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:48:36 --> Model Class Initialized
INFO - 2023-09-02 06:48:36 --> Final output sent to browser
DEBUG - 2023-09-02 06:48:36 --> Total execution time: 0.0240
ERROR - 2023-09-02 06:49:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:49:15 --> Config Class Initialized
INFO - 2023-09-02 06:49:15 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:49:15 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:49:15 --> Utf8 Class Initialized
INFO - 2023-09-02 06:49:15 --> URI Class Initialized
DEBUG - 2023-09-02 06:49:15 --> No URI present. Default controller set.
INFO - 2023-09-02 06:49:15 --> Router Class Initialized
INFO - 2023-09-02 06:49:15 --> Output Class Initialized
INFO - 2023-09-02 06:49:15 --> Security Class Initialized
DEBUG - 2023-09-02 06:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:49:15 --> Input Class Initialized
INFO - 2023-09-02 06:49:15 --> Language Class Initialized
INFO - 2023-09-02 06:49:15 --> Loader Class Initialized
INFO - 2023-09-02 06:49:15 --> Helper loaded: url_helper
INFO - 2023-09-02 06:49:15 --> Helper loaded: file_helper
INFO - 2023-09-02 06:49:15 --> Helper loaded: html_helper
INFO - 2023-09-02 06:49:15 --> Helper loaded: text_helper
INFO - 2023-09-02 06:49:15 --> Helper loaded: form_helper
INFO - 2023-09-02 06:49:15 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:49:15 --> Helper loaded: security_helper
INFO - 2023-09-02 06:49:15 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:49:15 --> Database Driver Class Initialized
INFO - 2023-09-02 06:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:49:15 --> Parser Class Initialized
INFO - 2023-09-02 06:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:49:15 --> Pagination Class Initialized
INFO - 2023-09-02 06:49:15 --> Form Validation Class Initialized
INFO - 2023-09-02 06:49:15 --> Controller Class Initialized
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
DEBUG - 2023-09-02 06:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
DEBUG - 2023-09-02 06:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
DEBUG - 2023-09-02 06:49:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
INFO - 2023-09-02 06:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 06:49:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:49:15 --> Model Class Initialized
INFO - 2023-09-02 06:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:49:15 --> Final output sent to browser
DEBUG - 2023-09-02 06:49:15 --> Total execution time: 0.0860
ERROR - 2023-09-02 06:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:49:40 --> Config Class Initialized
INFO - 2023-09-02 06:49:40 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:49:40 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:49:40 --> Utf8 Class Initialized
INFO - 2023-09-02 06:49:40 --> URI Class Initialized
INFO - 2023-09-02 06:49:40 --> Router Class Initialized
INFO - 2023-09-02 06:49:40 --> Output Class Initialized
INFO - 2023-09-02 06:49:40 --> Security Class Initialized
DEBUG - 2023-09-02 06:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:49:40 --> Input Class Initialized
INFO - 2023-09-02 06:49:40 --> Language Class Initialized
INFO - 2023-09-02 06:49:40 --> Loader Class Initialized
INFO - 2023-09-02 06:49:40 --> Helper loaded: url_helper
INFO - 2023-09-02 06:49:40 --> Helper loaded: file_helper
INFO - 2023-09-02 06:49:40 --> Helper loaded: html_helper
INFO - 2023-09-02 06:49:40 --> Helper loaded: text_helper
INFO - 2023-09-02 06:49:40 --> Helper loaded: form_helper
INFO - 2023-09-02 06:49:40 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:49:40 --> Helper loaded: security_helper
INFO - 2023-09-02 06:49:40 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:49:40 --> Database Driver Class Initialized
INFO - 2023-09-02 06:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:49:40 --> Parser Class Initialized
INFO - 2023-09-02 06:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:49:40 --> Pagination Class Initialized
INFO - 2023-09-02 06:49:40 --> Form Validation Class Initialized
INFO - 2023-09-02 06:49:40 --> Controller Class Initialized
INFO - 2023-09-02 06:49:40 --> Model Class Initialized
DEBUG - 2023-09-02 06:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 06:49:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:49:40 --> Model Class Initialized
INFO - 2023-09-02 06:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:49:40 --> Final output sent to browser
DEBUG - 2023-09-02 06:49:40 --> Total execution time: 0.0294
ERROR - 2023-09-02 06:49:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:49:41 --> Config Class Initialized
INFO - 2023-09-02 06:49:41 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:49:41 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:49:41 --> Utf8 Class Initialized
INFO - 2023-09-02 06:49:41 --> URI Class Initialized
INFO - 2023-09-02 06:49:41 --> Router Class Initialized
INFO - 2023-09-02 06:49:41 --> Output Class Initialized
INFO - 2023-09-02 06:49:41 --> Security Class Initialized
DEBUG - 2023-09-02 06:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:49:41 --> Input Class Initialized
INFO - 2023-09-02 06:49:41 --> Language Class Initialized
INFO - 2023-09-02 06:49:41 --> Loader Class Initialized
INFO - 2023-09-02 06:49:41 --> Helper loaded: url_helper
INFO - 2023-09-02 06:49:41 --> Helper loaded: file_helper
INFO - 2023-09-02 06:49:41 --> Helper loaded: html_helper
INFO - 2023-09-02 06:49:41 --> Helper loaded: text_helper
INFO - 2023-09-02 06:49:41 --> Helper loaded: form_helper
INFO - 2023-09-02 06:49:41 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:49:41 --> Helper loaded: security_helper
INFO - 2023-09-02 06:49:41 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:49:41 --> Database Driver Class Initialized
INFO - 2023-09-02 06:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:49:41 --> Parser Class Initialized
INFO - 2023-09-02 06:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:49:41 --> Pagination Class Initialized
INFO - 2023-09-02 06:49:41 --> Form Validation Class Initialized
INFO - 2023-09-02 06:49:41 --> Controller Class Initialized
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
DEBUG - 2023-09-02 06:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
DEBUG - 2023-09-02 06:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
DEBUG - 2023-09-02 06:49:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
INFO - 2023-09-02 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 06:49:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:49:41 --> Model Class Initialized
INFO - 2023-09-02 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:49:41 --> Final output sent to browser
DEBUG - 2023-09-02 06:49:41 --> Total execution time: 0.0831
ERROR - 2023-09-02 06:50:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:50:30 --> Config Class Initialized
INFO - 2023-09-02 06:50:30 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:50:30 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:50:30 --> Utf8 Class Initialized
INFO - 2023-09-02 06:50:30 --> URI Class Initialized
DEBUG - 2023-09-02 06:50:30 --> No URI present. Default controller set.
INFO - 2023-09-02 06:50:30 --> Router Class Initialized
INFO - 2023-09-02 06:50:30 --> Output Class Initialized
INFO - 2023-09-02 06:50:30 --> Security Class Initialized
DEBUG - 2023-09-02 06:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:50:30 --> Input Class Initialized
INFO - 2023-09-02 06:50:30 --> Language Class Initialized
INFO - 2023-09-02 06:50:30 --> Loader Class Initialized
INFO - 2023-09-02 06:50:30 --> Helper loaded: url_helper
INFO - 2023-09-02 06:50:30 --> Helper loaded: file_helper
INFO - 2023-09-02 06:50:30 --> Helper loaded: html_helper
INFO - 2023-09-02 06:50:30 --> Helper loaded: text_helper
INFO - 2023-09-02 06:50:30 --> Helper loaded: form_helper
INFO - 2023-09-02 06:50:30 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:50:30 --> Helper loaded: security_helper
INFO - 2023-09-02 06:50:30 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:50:30 --> Database Driver Class Initialized
INFO - 2023-09-02 06:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:50:30 --> Parser Class Initialized
INFO - 2023-09-02 06:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:50:30 --> Pagination Class Initialized
INFO - 2023-09-02 06:50:30 --> Form Validation Class Initialized
INFO - 2023-09-02 06:50:30 --> Controller Class Initialized
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
DEBUG - 2023-09-02 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
DEBUG - 2023-09-02 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
DEBUG - 2023-09-02 06:50:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
INFO - 2023-09-02 06:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 06:50:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:50:30 --> Model Class Initialized
INFO - 2023-09-02 06:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:50:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:50:30 --> Final output sent to browser
DEBUG - 2023-09-02 06:50:30 --> Total execution time: 0.0816
ERROR - 2023-09-02 06:50:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:50:42 --> Config Class Initialized
INFO - 2023-09-02 06:50:42 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:50:42 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:50:42 --> Utf8 Class Initialized
INFO - 2023-09-02 06:50:42 --> URI Class Initialized
INFO - 2023-09-02 06:50:42 --> Router Class Initialized
INFO - 2023-09-02 06:50:42 --> Output Class Initialized
INFO - 2023-09-02 06:50:42 --> Security Class Initialized
DEBUG - 2023-09-02 06:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:50:42 --> Input Class Initialized
INFO - 2023-09-02 06:50:42 --> Language Class Initialized
INFO - 2023-09-02 06:50:42 --> Loader Class Initialized
INFO - 2023-09-02 06:50:42 --> Helper loaded: url_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: file_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: html_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: text_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: form_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: security_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:50:42 --> Database Driver Class Initialized
INFO - 2023-09-02 06:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:50:42 --> Parser Class Initialized
INFO - 2023-09-02 06:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:50:42 --> Pagination Class Initialized
INFO - 2023-09-02 06:50:42 --> Form Validation Class Initialized
INFO - 2023-09-02 06:50:42 --> Controller Class Initialized
INFO - 2023-09-02 06:50:42 --> Model Class Initialized
INFO - 2023-09-02 06:50:42 --> Model Class Initialized
INFO - 2023-09-02 06:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-09-02 06:50:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:50:42 --> Model Class Initialized
INFO - 2023-09-02 06:50:42 --> Model Class Initialized
INFO - 2023-09-02 06:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:50:42 --> Final output sent to browser
DEBUG - 2023-09-02 06:50:42 --> Total execution time: 0.0663
ERROR - 2023-09-02 06:50:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:50:42 --> Config Class Initialized
INFO - 2023-09-02 06:50:42 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:50:42 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:50:42 --> Utf8 Class Initialized
INFO - 2023-09-02 06:50:42 --> URI Class Initialized
INFO - 2023-09-02 06:50:42 --> Router Class Initialized
INFO - 2023-09-02 06:50:42 --> Output Class Initialized
INFO - 2023-09-02 06:50:42 --> Security Class Initialized
DEBUG - 2023-09-02 06:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:50:42 --> Input Class Initialized
INFO - 2023-09-02 06:50:42 --> Language Class Initialized
INFO - 2023-09-02 06:50:42 --> Loader Class Initialized
INFO - 2023-09-02 06:50:42 --> Helper loaded: url_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: file_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: html_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: text_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: form_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: security_helper
INFO - 2023-09-02 06:50:42 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:50:42 --> Database Driver Class Initialized
INFO - 2023-09-02 06:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:50:42 --> Parser Class Initialized
INFO - 2023-09-02 06:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:50:42 --> Pagination Class Initialized
INFO - 2023-09-02 06:50:42 --> Form Validation Class Initialized
INFO - 2023-09-02 06:50:42 --> Controller Class Initialized
INFO - 2023-09-02 06:50:42 --> Model Class Initialized
INFO - 2023-09-02 06:50:42 --> Model Class Initialized
INFO - 2023-09-02 06:50:43 --> Final output sent to browser
DEBUG - 2023-09-02 06:50:43 --> Total execution time: 0.0242
ERROR - 2023-09-02 06:50:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:50:48 --> Config Class Initialized
INFO - 2023-09-02 06:50:48 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:50:48 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:50:48 --> Utf8 Class Initialized
INFO - 2023-09-02 06:50:48 --> URI Class Initialized
INFO - 2023-09-02 06:50:48 --> Router Class Initialized
INFO - 2023-09-02 06:50:48 --> Output Class Initialized
INFO - 2023-09-02 06:50:48 --> Security Class Initialized
DEBUG - 2023-09-02 06:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:50:48 --> Input Class Initialized
INFO - 2023-09-02 06:50:48 --> Language Class Initialized
INFO - 2023-09-02 06:50:48 --> Loader Class Initialized
INFO - 2023-09-02 06:50:48 --> Helper loaded: url_helper
INFO - 2023-09-02 06:50:48 --> Helper loaded: file_helper
INFO - 2023-09-02 06:50:48 --> Helper loaded: html_helper
INFO - 2023-09-02 06:50:48 --> Helper loaded: text_helper
INFO - 2023-09-02 06:50:48 --> Helper loaded: form_helper
INFO - 2023-09-02 06:50:48 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:50:48 --> Helper loaded: security_helper
INFO - 2023-09-02 06:50:48 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:50:48 --> Database Driver Class Initialized
INFO - 2023-09-02 06:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:50:48 --> Parser Class Initialized
INFO - 2023-09-02 06:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:50:48 --> Pagination Class Initialized
INFO - 2023-09-02 06:50:48 --> Form Validation Class Initialized
INFO - 2023-09-02 06:50:48 --> Controller Class Initialized
INFO - 2023-09-02 06:50:48 --> Model Class Initialized
INFO - 2023-09-02 06:50:48 --> Model Class Initialized
INFO - 2023-09-02 06:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-09-02 06:50:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:50:48 --> Model Class Initialized
INFO - 2023-09-02 06:50:48 --> Model Class Initialized
INFO - 2023-09-02 06:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:50:48 --> Final output sent to browser
DEBUG - 2023-09-02 06:50:48 --> Total execution time: 0.0699
ERROR - 2023-09-02 06:50:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:50:49 --> Config Class Initialized
INFO - 2023-09-02 06:50:49 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:50:49 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:50:49 --> Utf8 Class Initialized
INFO - 2023-09-02 06:50:49 --> URI Class Initialized
INFO - 2023-09-02 06:50:49 --> Router Class Initialized
INFO - 2023-09-02 06:50:49 --> Output Class Initialized
INFO - 2023-09-02 06:50:49 --> Security Class Initialized
DEBUG - 2023-09-02 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:50:49 --> Input Class Initialized
INFO - 2023-09-02 06:50:49 --> Language Class Initialized
INFO - 2023-09-02 06:50:49 --> Loader Class Initialized
INFO - 2023-09-02 06:50:49 --> Helper loaded: url_helper
INFO - 2023-09-02 06:50:49 --> Helper loaded: file_helper
INFO - 2023-09-02 06:50:49 --> Helper loaded: html_helper
INFO - 2023-09-02 06:50:49 --> Helper loaded: text_helper
INFO - 2023-09-02 06:50:49 --> Helper loaded: form_helper
INFO - 2023-09-02 06:50:49 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:50:49 --> Helper loaded: security_helper
INFO - 2023-09-02 06:50:49 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:50:49 --> Database Driver Class Initialized
INFO - 2023-09-02 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:50:49 --> Parser Class Initialized
INFO - 2023-09-02 06:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:50:49 --> Pagination Class Initialized
INFO - 2023-09-02 06:50:49 --> Form Validation Class Initialized
INFO - 2023-09-02 06:50:49 --> Controller Class Initialized
INFO - 2023-09-02 06:50:49 --> Model Class Initialized
INFO - 2023-09-02 06:50:49 --> Model Class Initialized
INFO - 2023-09-02 06:50:49 --> Final output sent to browser
DEBUG - 2023-09-02 06:50:49 --> Total execution time: 0.0483
ERROR - 2023-09-02 06:51:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:51:23 --> Config Class Initialized
INFO - 2023-09-02 06:51:23 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:51:23 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:51:23 --> Utf8 Class Initialized
INFO - 2023-09-02 06:51:23 --> URI Class Initialized
INFO - 2023-09-02 06:51:23 --> Router Class Initialized
INFO - 2023-09-02 06:51:23 --> Output Class Initialized
INFO - 2023-09-02 06:51:23 --> Security Class Initialized
DEBUG - 2023-09-02 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:51:23 --> Input Class Initialized
INFO - 2023-09-02 06:51:23 --> Language Class Initialized
INFO - 2023-09-02 06:51:23 --> Loader Class Initialized
INFO - 2023-09-02 06:51:23 --> Helper loaded: url_helper
INFO - 2023-09-02 06:51:23 --> Helper loaded: file_helper
INFO - 2023-09-02 06:51:23 --> Helper loaded: html_helper
INFO - 2023-09-02 06:51:23 --> Helper loaded: text_helper
INFO - 2023-09-02 06:51:23 --> Helper loaded: form_helper
INFO - 2023-09-02 06:51:23 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:51:23 --> Helper loaded: security_helper
INFO - 2023-09-02 06:51:23 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:51:23 --> Database Driver Class Initialized
INFO - 2023-09-02 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:51:23 --> Parser Class Initialized
INFO - 2023-09-02 06:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:51:23 --> Pagination Class Initialized
INFO - 2023-09-02 06:51:23 --> Form Validation Class Initialized
INFO - 2023-09-02 06:51:23 --> Controller Class Initialized
DEBUG - 2023-09-02 06:51:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:51:23 --> Model Class Initialized
DEBUG - 2023-09-02 06:51:23 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:51:23 --> Model Class Initialized
DEBUG - 2023-09-02 06:51:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:51:23 --> Model Class Initialized
DEBUG - 2023-09-02 06:51:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:51:23 --> Model Class Initialized
INFO - 2023-09-02 06:51:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-02 06:51:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:51:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:51:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:51:23 --> Model Class Initialized
INFO - 2023-09-02 06:51:23 --> Model Class Initialized
INFO - 2023-09-02 06:51:23 --> Model Class Initialized
INFO - 2023-09-02 06:51:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:51:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:51:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:51:23 --> Final output sent to browser
DEBUG - 2023-09-02 06:51:23 --> Total execution time: 0.0708
ERROR - 2023-09-02 06:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:51:24 --> Config Class Initialized
INFO - 2023-09-02 06:51:24 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:51:24 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:51:24 --> Utf8 Class Initialized
INFO - 2023-09-02 06:51:24 --> URI Class Initialized
INFO - 2023-09-02 06:51:24 --> Router Class Initialized
INFO - 2023-09-02 06:51:24 --> Output Class Initialized
INFO - 2023-09-02 06:51:24 --> Security Class Initialized
DEBUG - 2023-09-02 06:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:51:24 --> Input Class Initialized
INFO - 2023-09-02 06:51:24 --> Language Class Initialized
INFO - 2023-09-02 06:51:24 --> Loader Class Initialized
INFO - 2023-09-02 06:51:24 --> Helper loaded: url_helper
INFO - 2023-09-02 06:51:24 --> Helper loaded: file_helper
INFO - 2023-09-02 06:51:24 --> Helper loaded: html_helper
INFO - 2023-09-02 06:51:24 --> Helper loaded: text_helper
INFO - 2023-09-02 06:51:24 --> Helper loaded: form_helper
INFO - 2023-09-02 06:51:24 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:51:24 --> Helper loaded: security_helper
INFO - 2023-09-02 06:51:24 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:51:24 --> Database Driver Class Initialized
INFO - 2023-09-02 06:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:51:24 --> Parser Class Initialized
INFO - 2023-09-02 06:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:51:24 --> Pagination Class Initialized
INFO - 2023-09-02 06:51:24 --> Form Validation Class Initialized
INFO - 2023-09-02 06:51:24 --> Controller Class Initialized
DEBUG - 2023-09-02 06:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:51:24 --> Model Class Initialized
INFO - 2023-09-02 06:51:24 --> Final output sent to browser
DEBUG - 2023-09-02 06:51:24 --> Total execution time: 0.0195
ERROR - 2023-09-02 06:52:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:52:22 --> Config Class Initialized
INFO - 2023-09-02 06:52:22 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:52:22 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:52:22 --> Utf8 Class Initialized
INFO - 2023-09-02 06:52:22 --> URI Class Initialized
INFO - 2023-09-02 06:52:22 --> Router Class Initialized
INFO - 2023-09-02 06:52:22 --> Output Class Initialized
INFO - 2023-09-02 06:52:22 --> Security Class Initialized
DEBUG - 2023-09-02 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:52:22 --> Input Class Initialized
INFO - 2023-09-02 06:52:22 --> Language Class Initialized
INFO - 2023-09-02 06:52:22 --> Loader Class Initialized
INFO - 2023-09-02 06:52:22 --> Helper loaded: url_helper
INFO - 2023-09-02 06:52:22 --> Helper loaded: file_helper
INFO - 2023-09-02 06:52:22 --> Helper loaded: html_helper
INFO - 2023-09-02 06:52:22 --> Helper loaded: text_helper
INFO - 2023-09-02 06:52:22 --> Helper loaded: form_helper
INFO - 2023-09-02 06:52:22 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:52:22 --> Helper loaded: security_helper
INFO - 2023-09-02 06:52:22 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:52:22 --> Database Driver Class Initialized
INFO - 2023-09-02 06:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:52:22 --> Parser Class Initialized
INFO - 2023-09-02 06:52:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:52:22 --> Pagination Class Initialized
INFO - 2023-09-02 06:52:22 --> Form Validation Class Initialized
INFO - 2023-09-02 06:52:22 --> Controller Class Initialized
DEBUG - 2023-09-02 06:52:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:52:22 --> Model Class Initialized
INFO - 2023-09-02 06:52:22 --> Final output sent to browser
DEBUG - 2023-09-02 06:52:22 --> Total execution time: 0.0259
ERROR - 2023-09-02 06:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:53:10 --> Config Class Initialized
INFO - 2023-09-02 06:53:10 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:53:10 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:53:10 --> Utf8 Class Initialized
INFO - 2023-09-02 06:53:10 --> URI Class Initialized
INFO - 2023-09-02 06:53:10 --> Router Class Initialized
INFO - 2023-09-02 06:53:10 --> Output Class Initialized
INFO - 2023-09-02 06:53:10 --> Security Class Initialized
DEBUG - 2023-09-02 06:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:53:10 --> Input Class Initialized
INFO - 2023-09-02 06:53:10 --> Language Class Initialized
INFO - 2023-09-02 06:53:10 --> Loader Class Initialized
INFO - 2023-09-02 06:53:10 --> Helper loaded: url_helper
INFO - 2023-09-02 06:53:10 --> Helper loaded: file_helper
INFO - 2023-09-02 06:53:10 --> Helper loaded: html_helper
INFO - 2023-09-02 06:53:10 --> Helper loaded: text_helper
INFO - 2023-09-02 06:53:10 --> Helper loaded: form_helper
INFO - 2023-09-02 06:53:10 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:53:10 --> Helper loaded: security_helper
INFO - 2023-09-02 06:53:10 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:53:10 --> Database Driver Class Initialized
INFO - 2023-09-02 06:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:53:10 --> Parser Class Initialized
INFO - 2023-09-02 06:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:53:10 --> Pagination Class Initialized
INFO - 2023-09-02 06:53:10 --> Form Validation Class Initialized
INFO - 2023-09-02 06:53:10 --> Controller Class Initialized
INFO - 2023-09-02 06:53:10 --> Model Class Initialized
INFO - 2023-09-02 06:53:10 --> Model Class Initialized
INFO - 2023-09-02 06:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-09-02 06:53:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:53:10 --> Model Class Initialized
INFO - 2023-09-02 06:53:10 --> Model Class Initialized
INFO - 2023-09-02 06:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:53:10 --> Final output sent to browser
DEBUG - 2023-09-02 06:53:10 --> Total execution time: 0.0728
ERROR - 2023-09-02 06:53:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:53:11 --> Config Class Initialized
INFO - 2023-09-02 06:53:11 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:53:11 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:53:11 --> Utf8 Class Initialized
INFO - 2023-09-02 06:53:11 --> URI Class Initialized
INFO - 2023-09-02 06:53:11 --> Router Class Initialized
INFO - 2023-09-02 06:53:11 --> Output Class Initialized
INFO - 2023-09-02 06:53:11 --> Security Class Initialized
DEBUG - 2023-09-02 06:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:53:11 --> Input Class Initialized
INFO - 2023-09-02 06:53:11 --> Language Class Initialized
INFO - 2023-09-02 06:53:11 --> Loader Class Initialized
INFO - 2023-09-02 06:53:11 --> Helper loaded: url_helper
INFO - 2023-09-02 06:53:11 --> Helper loaded: file_helper
INFO - 2023-09-02 06:53:11 --> Helper loaded: html_helper
INFO - 2023-09-02 06:53:11 --> Helper loaded: text_helper
INFO - 2023-09-02 06:53:11 --> Helper loaded: form_helper
INFO - 2023-09-02 06:53:11 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:53:11 --> Helper loaded: security_helper
INFO - 2023-09-02 06:53:11 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:53:11 --> Database Driver Class Initialized
INFO - 2023-09-02 06:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:53:11 --> Parser Class Initialized
INFO - 2023-09-02 06:53:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:53:11 --> Pagination Class Initialized
INFO - 2023-09-02 06:53:11 --> Form Validation Class Initialized
INFO - 2023-09-02 06:53:11 --> Controller Class Initialized
INFO - 2023-09-02 06:53:11 --> Model Class Initialized
INFO - 2023-09-02 06:53:11 --> Model Class Initialized
INFO - 2023-09-02 06:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-09-02 06:53:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:53:11 --> Model Class Initialized
INFO - 2023-09-02 06:53:11 --> Model Class Initialized
INFO - 2023-09-02 06:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:53:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:53:11 --> Final output sent to browser
DEBUG - 2023-09-02 06:53:11 --> Total execution time: 0.0600
ERROR - 2023-09-02 06:53:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:53:14 --> Config Class Initialized
INFO - 2023-09-02 06:53:14 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:53:14 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:53:14 --> Utf8 Class Initialized
INFO - 2023-09-02 06:53:14 --> URI Class Initialized
INFO - 2023-09-02 06:53:14 --> Router Class Initialized
INFO - 2023-09-02 06:53:14 --> Output Class Initialized
INFO - 2023-09-02 06:53:14 --> Security Class Initialized
DEBUG - 2023-09-02 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:53:14 --> Input Class Initialized
INFO - 2023-09-02 06:53:14 --> Language Class Initialized
INFO - 2023-09-02 06:53:14 --> Loader Class Initialized
INFO - 2023-09-02 06:53:14 --> Helper loaded: url_helper
INFO - 2023-09-02 06:53:14 --> Helper loaded: file_helper
INFO - 2023-09-02 06:53:14 --> Helper loaded: html_helper
INFO - 2023-09-02 06:53:14 --> Helper loaded: text_helper
INFO - 2023-09-02 06:53:14 --> Helper loaded: form_helper
INFO - 2023-09-02 06:53:14 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:53:14 --> Helper loaded: security_helper
INFO - 2023-09-02 06:53:14 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:53:14 --> Database Driver Class Initialized
INFO - 2023-09-02 06:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:53:14 --> Parser Class Initialized
INFO - 2023-09-02 06:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:53:14 --> Pagination Class Initialized
INFO - 2023-09-02 06:53:14 --> Form Validation Class Initialized
INFO - 2023-09-02 06:53:14 --> Controller Class Initialized
INFO - 2023-09-02 06:53:14 --> Model Class Initialized
INFO - 2023-09-02 06:53:14 --> Model Class Initialized
INFO - 2023-09-02 06:53:14 --> Final output sent to browser
DEBUG - 2023-09-02 06:53:14 --> Total execution time: 0.0244
ERROR - 2023-09-02 06:53:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 06:53:25 --> Config Class Initialized
INFO - 2023-09-02 06:53:25 --> Hooks Class Initialized
DEBUG - 2023-09-02 06:53:25 --> UTF-8 Support Enabled
INFO - 2023-09-02 06:53:25 --> Utf8 Class Initialized
INFO - 2023-09-02 06:53:25 --> URI Class Initialized
DEBUG - 2023-09-02 06:53:25 --> No URI present. Default controller set.
INFO - 2023-09-02 06:53:25 --> Router Class Initialized
INFO - 2023-09-02 06:53:25 --> Output Class Initialized
INFO - 2023-09-02 06:53:25 --> Security Class Initialized
DEBUG - 2023-09-02 06:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 06:53:25 --> Input Class Initialized
INFO - 2023-09-02 06:53:25 --> Language Class Initialized
INFO - 2023-09-02 06:53:25 --> Loader Class Initialized
INFO - 2023-09-02 06:53:25 --> Helper loaded: url_helper
INFO - 2023-09-02 06:53:25 --> Helper loaded: file_helper
INFO - 2023-09-02 06:53:25 --> Helper loaded: html_helper
INFO - 2023-09-02 06:53:25 --> Helper loaded: text_helper
INFO - 2023-09-02 06:53:25 --> Helper loaded: form_helper
INFO - 2023-09-02 06:53:25 --> Helper loaded: lang_helper
INFO - 2023-09-02 06:53:25 --> Helper loaded: security_helper
INFO - 2023-09-02 06:53:25 --> Helper loaded: cookie_helper
INFO - 2023-09-02 06:53:25 --> Database Driver Class Initialized
INFO - 2023-09-02 06:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 06:53:25 --> Parser Class Initialized
INFO - 2023-09-02 06:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 06:53:25 --> Pagination Class Initialized
INFO - 2023-09-02 06:53:25 --> Form Validation Class Initialized
INFO - 2023-09-02 06:53:25 --> Controller Class Initialized
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
DEBUG - 2023-09-02 06:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
DEBUG - 2023-09-02 06:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
DEBUG - 2023-09-02 06:53:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 06:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
INFO - 2023-09-02 06:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 06:53:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 06:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 06:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 06:53:25 --> Model Class Initialized
INFO - 2023-09-02 06:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 06:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 06:53:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 06:53:25 --> Final output sent to browser
DEBUG - 2023-09-02 06:53:25 --> Total execution time: 0.0840
ERROR - 2023-09-02 07:03:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:03:48 --> Config Class Initialized
INFO - 2023-09-02 07:03:48 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:03:48 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:03:48 --> Utf8 Class Initialized
INFO - 2023-09-02 07:03:48 --> URI Class Initialized
DEBUG - 2023-09-02 07:03:48 --> No URI present. Default controller set.
INFO - 2023-09-02 07:03:48 --> Router Class Initialized
INFO - 2023-09-02 07:03:48 --> Output Class Initialized
INFO - 2023-09-02 07:03:48 --> Security Class Initialized
DEBUG - 2023-09-02 07:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:03:48 --> Input Class Initialized
INFO - 2023-09-02 07:03:48 --> Language Class Initialized
INFO - 2023-09-02 07:03:48 --> Loader Class Initialized
INFO - 2023-09-02 07:03:48 --> Helper loaded: url_helper
INFO - 2023-09-02 07:03:48 --> Helper loaded: file_helper
INFO - 2023-09-02 07:03:48 --> Helper loaded: html_helper
INFO - 2023-09-02 07:03:48 --> Helper loaded: text_helper
INFO - 2023-09-02 07:03:48 --> Helper loaded: form_helper
INFO - 2023-09-02 07:03:48 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:03:48 --> Helper loaded: security_helper
INFO - 2023-09-02 07:03:48 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:03:48 --> Database Driver Class Initialized
INFO - 2023-09-02 07:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:03:48 --> Parser Class Initialized
INFO - 2023-09-02 07:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:03:48 --> Pagination Class Initialized
INFO - 2023-09-02 07:03:48 --> Form Validation Class Initialized
INFO - 2023-09-02 07:03:48 --> Controller Class Initialized
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
DEBUG - 2023-09-02 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
DEBUG - 2023-09-02 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
DEBUG - 2023-09-02 07:03:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
INFO - 2023-09-02 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 07:03:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:03:48 --> Model Class Initialized
INFO - 2023-09-02 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:03:48 --> Final output sent to browser
DEBUG - 2023-09-02 07:03:48 --> Total execution time: 0.0900
ERROR - 2023-09-02 07:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:04:02 --> Config Class Initialized
INFO - 2023-09-02 07:04:02 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:04:02 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:04:02 --> Utf8 Class Initialized
INFO - 2023-09-02 07:04:02 --> URI Class Initialized
INFO - 2023-09-02 07:04:02 --> Router Class Initialized
INFO - 2023-09-02 07:04:02 --> Output Class Initialized
INFO - 2023-09-02 07:04:02 --> Security Class Initialized
DEBUG - 2023-09-02 07:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:04:02 --> Input Class Initialized
INFO - 2023-09-02 07:04:02 --> Language Class Initialized
INFO - 2023-09-02 07:04:02 --> Loader Class Initialized
INFO - 2023-09-02 07:04:02 --> Helper loaded: url_helper
INFO - 2023-09-02 07:04:02 --> Helper loaded: file_helper
INFO - 2023-09-02 07:04:02 --> Helper loaded: html_helper
INFO - 2023-09-02 07:04:02 --> Helper loaded: text_helper
INFO - 2023-09-02 07:04:02 --> Helper loaded: form_helper
INFO - 2023-09-02 07:04:02 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:04:02 --> Helper loaded: security_helper
INFO - 2023-09-02 07:04:02 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:04:02 --> Database Driver Class Initialized
INFO - 2023-09-02 07:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:04:02 --> Parser Class Initialized
INFO - 2023-09-02 07:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:04:02 --> Pagination Class Initialized
INFO - 2023-09-02 07:04:02 --> Form Validation Class Initialized
INFO - 2023-09-02 07:04:02 --> Controller Class Initialized
DEBUG - 2023-09-02 07:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:04:02 --> Model Class Initialized
DEBUG - 2023-09-02 07:04:02 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:04:02 --> Model Class Initialized
DEBUG - 2023-09-02 07:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:04:02 --> Model Class Initialized
DEBUG - 2023-09-02 07:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:04:02 --> Model Class Initialized
INFO - 2023-09-02 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-02 07:04:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:04:02 --> Model Class Initialized
INFO - 2023-09-02 07:04:02 --> Model Class Initialized
INFO - 2023-09-02 07:04:02 --> Model Class Initialized
INFO - 2023-09-02 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:04:02 --> Final output sent to browser
DEBUG - 2023-09-02 07:04:02 --> Total execution time: 0.0696
ERROR - 2023-09-02 07:04:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:04:10 --> Config Class Initialized
INFO - 2023-09-02 07:04:10 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:04:10 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:04:10 --> Utf8 Class Initialized
INFO - 2023-09-02 07:04:10 --> URI Class Initialized
INFO - 2023-09-02 07:04:10 --> Router Class Initialized
INFO - 2023-09-02 07:04:10 --> Output Class Initialized
INFO - 2023-09-02 07:04:10 --> Security Class Initialized
DEBUG - 2023-09-02 07:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:04:10 --> Input Class Initialized
INFO - 2023-09-02 07:04:10 --> Language Class Initialized
INFO - 2023-09-02 07:04:10 --> Loader Class Initialized
INFO - 2023-09-02 07:04:10 --> Helper loaded: url_helper
INFO - 2023-09-02 07:04:10 --> Helper loaded: file_helper
INFO - 2023-09-02 07:04:10 --> Helper loaded: html_helper
INFO - 2023-09-02 07:04:10 --> Helper loaded: text_helper
INFO - 2023-09-02 07:04:10 --> Helper loaded: form_helper
INFO - 2023-09-02 07:04:10 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:04:10 --> Helper loaded: security_helper
INFO - 2023-09-02 07:04:10 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:04:10 --> Database Driver Class Initialized
INFO - 2023-09-02 07:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:04:10 --> Parser Class Initialized
INFO - 2023-09-02 07:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:04:10 --> Pagination Class Initialized
INFO - 2023-09-02 07:04:10 --> Form Validation Class Initialized
INFO - 2023-09-02 07:04:10 --> Controller Class Initialized
DEBUG - 2023-09-02 07:04:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:04:10 --> Model Class Initialized
INFO - 2023-09-02 07:04:10 --> Final output sent to browser
DEBUG - 2023-09-02 07:04:10 --> Total execution time: 0.0209
ERROR - 2023-09-02 07:05:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:05:54 --> Config Class Initialized
INFO - 2023-09-02 07:05:54 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:05:54 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:05:54 --> Utf8 Class Initialized
INFO - 2023-09-02 07:05:54 --> URI Class Initialized
INFO - 2023-09-02 07:05:54 --> Router Class Initialized
INFO - 2023-09-02 07:05:54 --> Output Class Initialized
INFO - 2023-09-02 07:05:54 --> Security Class Initialized
DEBUG - 2023-09-02 07:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:05:54 --> Input Class Initialized
INFO - 2023-09-02 07:05:54 --> Language Class Initialized
INFO - 2023-09-02 07:05:54 --> Loader Class Initialized
INFO - 2023-09-02 07:05:54 --> Helper loaded: url_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: file_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: html_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: text_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: form_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: security_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:05:54 --> Database Driver Class Initialized
INFO - 2023-09-02 07:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:05:54 --> Parser Class Initialized
INFO - 2023-09-02 07:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:05:54 --> Pagination Class Initialized
INFO - 2023-09-02 07:05:54 --> Form Validation Class Initialized
INFO - 2023-09-02 07:05:54 --> Controller Class Initialized
DEBUG - 2023-09-02 07:05:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:54 --> Model Class Initialized
INFO - 2023-09-02 07:05:54 --> Final output sent to browser
DEBUG - 2023-09-02 07:05:54 --> Total execution time: 0.0237
ERROR - 2023-09-02 07:05:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:05:54 --> Config Class Initialized
INFO - 2023-09-02 07:05:54 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:05:54 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:05:54 --> Utf8 Class Initialized
INFO - 2023-09-02 07:05:54 --> URI Class Initialized
INFO - 2023-09-02 07:05:54 --> Router Class Initialized
INFO - 2023-09-02 07:05:54 --> Output Class Initialized
INFO - 2023-09-02 07:05:54 --> Security Class Initialized
DEBUG - 2023-09-02 07:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:05:54 --> Input Class Initialized
INFO - 2023-09-02 07:05:54 --> Language Class Initialized
INFO - 2023-09-02 07:05:54 --> Loader Class Initialized
INFO - 2023-09-02 07:05:54 --> Helper loaded: url_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: file_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: html_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: text_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: form_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: security_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:05:54 --> Database Driver Class Initialized
INFO - 2023-09-02 07:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:05:54 --> Parser Class Initialized
INFO - 2023-09-02 07:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:05:54 --> Pagination Class Initialized
INFO - 2023-09-02 07:05:54 --> Form Validation Class Initialized
INFO - 2023-09-02 07:05:54 --> Controller Class Initialized
DEBUG - 2023-09-02 07:05:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:54 --> Model Class Initialized
ERROR - 2023-09-02 07:05:54 --> Query error: Unknown column 'sl' in 'order clause' - Invalid query: SELECT *
FROM `gifts`
ORDER BY `sl` ASC
 LIMIT 10
ERROR - 2023-09-02 07:05:54 --> Severity: error --> Exception: Call to a member function result() on bool /home/powera7m/app.maurnaturo.com/application/models/Gifts.php 70
ERROR - 2023-09-02 07:05:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:05:54 --> Config Class Initialized
INFO - 2023-09-02 07:05:54 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:05:54 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:05:54 --> Utf8 Class Initialized
INFO - 2023-09-02 07:05:54 --> URI Class Initialized
INFO - 2023-09-02 07:05:54 --> Router Class Initialized
INFO - 2023-09-02 07:05:54 --> Output Class Initialized
INFO - 2023-09-02 07:05:54 --> Security Class Initialized
DEBUG - 2023-09-02 07:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:05:54 --> Input Class Initialized
INFO - 2023-09-02 07:05:54 --> Language Class Initialized
INFO - 2023-09-02 07:05:54 --> Loader Class Initialized
INFO - 2023-09-02 07:05:54 --> Helper loaded: url_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: file_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: html_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: text_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: form_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: security_helper
INFO - 2023-09-02 07:05:54 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:05:54 --> Database Driver Class Initialized
INFO - 2023-09-02 07:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:05:54 --> Parser Class Initialized
INFO - 2023-09-02 07:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:05:54 --> Pagination Class Initialized
INFO - 2023-09-02 07:05:54 --> Form Validation Class Initialized
INFO - 2023-09-02 07:05:54 --> Controller Class Initialized
DEBUG - 2023-09-02 07:05:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:54 --> Model Class Initialized
INFO - 2023-09-02 07:05:54 --> Final output sent to browser
DEBUG - 2023-09-02 07:05:54 --> Total execution time: 0.0199
ERROR - 2023-09-02 07:05:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:05:55 --> Config Class Initialized
INFO - 2023-09-02 07:05:55 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:05:55 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:05:55 --> Utf8 Class Initialized
INFO - 2023-09-02 07:05:55 --> URI Class Initialized
INFO - 2023-09-02 07:05:55 --> Router Class Initialized
INFO - 2023-09-02 07:05:55 --> Output Class Initialized
INFO - 2023-09-02 07:05:55 --> Security Class Initialized
DEBUG - 2023-09-02 07:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:05:55 --> Input Class Initialized
INFO - 2023-09-02 07:05:55 --> Language Class Initialized
INFO - 2023-09-02 07:05:55 --> Loader Class Initialized
INFO - 2023-09-02 07:05:55 --> Helper loaded: url_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: file_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: html_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: text_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: form_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: security_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:05:55 --> Database Driver Class Initialized
INFO - 2023-09-02 07:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:05:55 --> Parser Class Initialized
INFO - 2023-09-02 07:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:05:55 --> Pagination Class Initialized
INFO - 2023-09-02 07:05:55 --> Form Validation Class Initialized
INFO - 2023-09-02 07:05:55 --> Controller Class Initialized
DEBUG - 2023-09-02 07:05:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
INFO - 2023-09-02 07:05:55 --> Final output sent to browser
DEBUG - 2023-09-02 07:05:55 --> Total execution time: 0.0198
ERROR - 2023-09-02 07:05:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:05:55 --> Config Class Initialized
INFO - 2023-09-02 07:05:55 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:05:55 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:05:55 --> Utf8 Class Initialized
INFO - 2023-09-02 07:05:55 --> URI Class Initialized
DEBUG - 2023-09-02 07:05:55 --> No URI present. Default controller set.
INFO - 2023-09-02 07:05:55 --> Router Class Initialized
INFO - 2023-09-02 07:05:55 --> Output Class Initialized
INFO - 2023-09-02 07:05:55 --> Security Class Initialized
DEBUG - 2023-09-02 07:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:05:55 --> Input Class Initialized
INFO - 2023-09-02 07:05:55 --> Language Class Initialized
INFO - 2023-09-02 07:05:55 --> Loader Class Initialized
INFO - 2023-09-02 07:05:55 --> Helper loaded: url_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: file_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: html_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: text_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: form_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: security_helper
INFO - 2023-09-02 07:05:55 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:05:55 --> Database Driver Class Initialized
INFO - 2023-09-02 07:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:05:55 --> Parser Class Initialized
INFO - 2023-09-02 07:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:05:55 --> Pagination Class Initialized
INFO - 2023-09-02 07:05:55 --> Form Validation Class Initialized
INFO - 2023-09-02 07:05:55 --> Controller Class Initialized
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
DEBUG - 2023-09-02 07:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
DEBUG - 2023-09-02 07:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
DEBUG - 2023-09-02 07:05:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
INFO - 2023-09-02 07:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 07:05:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:05:55 --> Model Class Initialized
INFO - 2023-09-02 07:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:05:55 --> Final output sent to browser
DEBUG - 2023-09-02 07:05:55 --> Total execution time: 0.0867
ERROR - 2023-09-02 07:06:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:06:14 --> Config Class Initialized
INFO - 2023-09-02 07:06:14 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:06:14 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:06:14 --> Utf8 Class Initialized
INFO - 2023-09-02 07:06:14 --> URI Class Initialized
INFO - 2023-09-02 07:06:14 --> Router Class Initialized
INFO - 2023-09-02 07:06:14 --> Output Class Initialized
INFO - 2023-09-02 07:06:14 --> Security Class Initialized
DEBUG - 2023-09-02 07:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:06:14 --> Input Class Initialized
INFO - 2023-09-02 07:06:14 --> Language Class Initialized
INFO - 2023-09-02 07:06:14 --> Loader Class Initialized
INFO - 2023-09-02 07:06:14 --> Helper loaded: url_helper
INFO - 2023-09-02 07:06:14 --> Helper loaded: file_helper
INFO - 2023-09-02 07:06:14 --> Helper loaded: html_helper
INFO - 2023-09-02 07:06:14 --> Helper loaded: text_helper
INFO - 2023-09-02 07:06:14 --> Helper loaded: form_helper
INFO - 2023-09-02 07:06:14 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:06:14 --> Helper loaded: security_helper
INFO - 2023-09-02 07:06:14 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:06:14 --> Database Driver Class Initialized
INFO - 2023-09-02 07:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:06:14 --> Parser Class Initialized
INFO - 2023-09-02 07:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:06:14 --> Pagination Class Initialized
INFO - 2023-09-02 07:06:14 --> Form Validation Class Initialized
INFO - 2023-09-02 07:06:14 --> Controller Class Initialized
DEBUG - 2023-09-02 07:06:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:06:14 --> Model Class Initialized
DEBUG - 2023-09-02 07:06:14 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:06:14 --> Model Class Initialized
DEBUG - 2023-09-02 07:06:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:06:14 --> Model Class Initialized
DEBUG - 2023-09-02 07:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:06:14 --> Model Class Initialized
INFO - 2023-09-02 07:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-02 07:06:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:06:14 --> Model Class Initialized
INFO - 2023-09-02 07:06:14 --> Model Class Initialized
INFO - 2023-09-02 07:06:14 --> Model Class Initialized
INFO - 2023-09-02 07:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:06:14 --> Final output sent to browser
DEBUG - 2023-09-02 07:06:14 --> Total execution time: 0.0666
ERROR - 2023-09-02 07:06:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:06:16 --> Config Class Initialized
INFO - 2023-09-02 07:06:16 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:06:16 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:06:16 --> Utf8 Class Initialized
INFO - 2023-09-02 07:06:16 --> URI Class Initialized
INFO - 2023-09-02 07:06:16 --> Router Class Initialized
INFO - 2023-09-02 07:06:16 --> Output Class Initialized
INFO - 2023-09-02 07:06:16 --> Security Class Initialized
DEBUG - 2023-09-02 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:06:16 --> Input Class Initialized
INFO - 2023-09-02 07:06:16 --> Language Class Initialized
INFO - 2023-09-02 07:06:16 --> Loader Class Initialized
INFO - 2023-09-02 07:06:16 --> Helper loaded: url_helper
INFO - 2023-09-02 07:06:16 --> Helper loaded: file_helper
INFO - 2023-09-02 07:06:16 --> Helper loaded: html_helper
INFO - 2023-09-02 07:06:16 --> Helper loaded: text_helper
INFO - 2023-09-02 07:06:16 --> Helper loaded: form_helper
INFO - 2023-09-02 07:06:16 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:06:16 --> Helper loaded: security_helper
INFO - 2023-09-02 07:06:16 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:06:16 --> Database Driver Class Initialized
INFO - 2023-09-02 07:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:06:16 --> Parser Class Initialized
INFO - 2023-09-02 07:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:06:16 --> Pagination Class Initialized
INFO - 2023-09-02 07:06:16 --> Form Validation Class Initialized
INFO - 2023-09-02 07:06:16 --> Controller Class Initialized
DEBUG - 2023-09-02 07:06:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:06:16 --> Model Class Initialized
INFO - 2023-09-02 07:06:16 --> Final output sent to browser
DEBUG - 2023-09-02 07:06:16 --> Total execution time: 0.0198
ERROR - 2023-09-02 07:07:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:07:08 --> Config Class Initialized
INFO - 2023-09-02 07:07:08 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:07:08 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:07:08 --> Utf8 Class Initialized
INFO - 2023-09-02 07:07:08 --> URI Class Initialized
INFO - 2023-09-02 07:07:08 --> Router Class Initialized
INFO - 2023-09-02 07:07:08 --> Output Class Initialized
INFO - 2023-09-02 07:07:08 --> Security Class Initialized
DEBUG - 2023-09-02 07:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:07:08 --> Input Class Initialized
INFO - 2023-09-02 07:07:08 --> Language Class Initialized
INFO - 2023-09-02 07:07:08 --> Loader Class Initialized
INFO - 2023-09-02 07:07:08 --> Helper loaded: url_helper
INFO - 2023-09-02 07:07:08 --> Helper loaded: file_helper
INFO - 2023-09-02 07:07:08 --> Helper loaded: html_helper
INFO - 2023-09-02 07:07:08 --> Helper loaded: text_helper
INFO - 2023-09-02 07:07:08 --> Helper loaded: form_helper
INFO - 2023-09-02 07:07:08 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:07:08 --> Helper loaded: security_helper
INFO - 2023-09-02 07:07:08 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:07:08 --> Database Driver Class Initialized
INFO - 2023-09-02 07:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:07:08 --> Parser Class Initialized
INFO - 2023-09-02 07:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:07:08 --> Pagination Class Initialized
INFO - 2023-09-02 07:07:08 --> Form Validation Class Initialized
INFO - 2023-09-02 07:07:08 --> Controller Class Initialized
DEBUG - 2023-09-02 07:07:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:08 --> Model Class Initialized
INFO - 2023-09-02 07:07:08 --> Final output sent to browser
DEBUG - 2023-09-02 07:07:08 --> Total execution time: 0.0274
ERROR - 2023-09-02 07:07:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:07:18 --> Config Class Initialized
INFO - 2023-09-02 07:07:18 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:07:18 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:07:18 --> Utf8 Class Initialized
INFO - 2023-09-02 07:07:18 --> URI Class Initialized
INFO - 2023-09-02 07:07:18 --> Router Class Initialized
INFO - 2023-09-02 07:07:18 --> Output Class Initialized
INFO - 2023-09-02 07:07:18 --> Security Class Initialized
DEBUG - 2023-09-02 07:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:07:18 --> Input Class Initialized
INFO - 2023-09-02 07:07:18 --> Language Class Initialized
INFO - 2023-09-02 07:07:18 --> Loader Class Initialized
INFO - 2023-09-02 07:07:18 --> Helper loaded: url_helper
INFO - 2023-09-02 07:07:18 --> Helper loaded: file_helper
INFO - 2023-09-02 07:07:18 --> Helper loaded: html_helper
INFO - 2023-09-02 07:07:18 --> Helper loaded: text_helper
INFO - 2023-09-02 07:07:18 --> Helper loaded: form_helper
INFO - 2023-09-02 07:07:18 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:07:18 --> Helper loaded: security_helper
INFO - 2023-09-02 07:07:18 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:07:18 --> Database Driver Class Initialized
INFO - 2023-09-02 07:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:07:18 --> Parser Class Initialized
INFO - 2023-09-02 07:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:07:18 --> Pagination Class Initialized
INFO - 2023-09-02 07:07:18 --> Form Validation Class Initialized
INFO - 2023-09-02 07:07:18 --> Controller Class Initialized
DEBUG - 2023-09-02 07:07:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:18 --> Model Class Initialized
INFO - 2023-09-02 07:07:18 --> Final output sent to browser
DEBUG - 2023-09-02 07:07:18 --> Total execution time: 0.0203
ERROR - 2023-09-02 07:07:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:07:53 --> Config Class Initialized
INFO - 2023-09-02 07:07:53 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:07:53 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:07:53 --> Utf8 Class Initialized
INFO - 2023-09-02 07:07:53 --> URI Class Initialized
INFO - 2023-09-02 07:07:53 --> Router Class Initialized
INFO - 2023-09-02 07:07:53 --> Output Class Initialized
INFO - 2023-09-02 07:07:53 --> Security Class Initialized
DEBUG - 2023-09-02 07:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:07:53 --> Input Class Initialized
INFO - 2023-09-02 07:07:53 --> Language Class Initialized
INFO - 2023-09-02 07:07:53 --> Loader Class Initialized
INFO - 2023-09-02 07:07:53 --> Helper loaded: url_helper
INFO - 2023-09-02 07:07:53 --> Helper loaded: file_helper
INFO - 2023-09-02 07:07:53 --> Helper loaded: html_helper
INFO - 2023-09-02 07:07:53 --> Helper loaded: text_helper
INFO - 2023-09-02 07:07:53 --> Helper loaded: form_helper
INFO - 2023-09-02 07:07:53 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:07:53 --> Helper loaded: security_helper
INFO - 2023-09-02 07:07:53 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:07:53 --> Database Driver Class Initialized
INFO - 2023-09-02 07:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:07:53 --> Parser Class Initialized
INFO - 2023-09-02 07:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:07:53 --> Pagination Class Initialized
INFO - 2023-09-02 07:07:53 --> Form Validation Class Initialized
INFO - 2023-09-02 07:07:53 --> Controller Class Initialized
DEBUG - 2023-09-02 07:07:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:53 --> Model Class Initialized
DEBUG - 2023-09-02 07:07:53 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:53 --> Model Class Initialized
DEBUG - 2023-09-02 07:07:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:53 --> Model Class Initialized
DEBUG - 2023-09-02 07:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:53 --> Model Class Initialized
INFO - 2023-09-02 07:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-02 07:07:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:07:53 --> Model Class Initialized
INFO - 2023-09-02 07:07:53 --> Model Class Initialized
INFO - 2023-09-02 07:07:53 --> Model Class Initialized
INFO - 2023-09-02 07:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:07:53 --> Final output sent to browser
DEBUG - 2023-09-02 07:07:53 --> Total execution time: 0.0795
ERROR - 2023-09-02 07:07:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:07:55 --> Config Class Initialized
INFO - 2023-09-02 07:07:55 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:07:55 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:07:55 --> Utf8 Class Initialized
INFO - 2023-09-02 07:07:55 --> URI Class Initialized
INFO - 2023-09-02 07:07:55 --> Router Class Initialized
INFO - 2023-09-02 07:07:55 --> Output Class Initialized
INFO - 2023-09-02 07:07:55 --> Security Class Initialized
DEBUG - 2023-09-02 07:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:07:55 --> Input Class Initialized
INFO - 2023-09-02 07:07:55 --> Language Class Initialized
INFO - 2023-09-02 07:07:55 --> Loader Class Initialized
INFO - 2023-09-02 07:07:55 --> Helper loaded: url_helper
INFO - 2023-09-02 07:07:55 --> Helper loaded: file_helper
INFO - 2023-09-02 07:07:55 --> Helper loaded: html_helper
INFO - 2023-09-02 07:07:55 --> Helper loaded: text_helper
INFO - 2023-09-02 07:07:55 --> Helper loaded: form_helper
INFO - 2023-09-02 07:07:55 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:07:55 --> Helper loaded: security_helper
INFO - 2023-09-02 07:07:55 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:07:55 --> Database Driver Class Initialized
INFO - 2023-09-02 07:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:07:55 --> Parser Class Initialized
INFO - 2023-09-02 07:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:07:55 --> Pagination Class Initialized
INFO - 2023-09-02 07:07:55 --> Form Validation Class Initialized
INFO - 2023-09-02 07:07:55 --> Controller Class Initialized
DEBUG - 2023-09-02 07:07:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:07:55 --> Model Class Initialized
INFO - 2023-09-02 07:07:55 --> Final output sent to browser
DEBUG - 2023-09-02 07:07:55 --> Total execution time: 0.0228
ERROR - 2023-09-02 07:08:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:07 --> Config Class Initialized
INFO - 2023-09-02 07:08:07 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:07 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:07 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:07 --> URI Class Initialized
INFO - 2023-09-02 07:08:07 --> Router Class Initialized
INFO - 2023-09-02 07:08:07 --> Output Class Initialized
INFO - 2023-09-02 07:08:07 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:07 --> Input Class Initialized
INFO - 2023-09-02 07:08:07 --> Language Class Initialized
INFO - 2023-09-02 07:08:07 --> Loader Class Initialized
INFO - 2023-09-02 07:08:07 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:07 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:07 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:07 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:07 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:07 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:07 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:07 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:07 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:07 --> Parser Class Initialized
INFO - 2023-09-02 07:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:07 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:07 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:07 --> Controller Class Initialized
INFO - 2023-09-02 07:08:07 --> Model Class Initialized
INFO - 2023-09-02 07:08:07 --> Model Class Initialized
INFO - 2023-09-02 07:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-09-02 07:08:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:08:07 --> Model Class Initialized
INFO - 2023-09-02 07:08:07 --> Model Class Initialized
INFO - 2023-09-02 07:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:08:07 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:07 --> Total execution time: 0.0640
ERROR - 2023-09-02 07:08:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:08 --> Config Class Initialized
INFO - 2023-09-02 07:08:08 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:08 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:08 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:08 --> URI Class Initialized
INFO - 2023-09-02 07:08:08 --> Router Class Initialized
INFO - 2023-09-02 07:08:08 --> Output Class Initialized
INFO - 2023-09-02 07:08:08 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:08 --> Input Class Initialized
INFO - 2023-09-02 07:08:08 --> Language Class Initialized
INFO - 2023-09-02 07:08:08 --> Loader Class Initialized
INFO - 2023-09-02 07:08:08 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:08 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:08 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:08 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:08 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:08 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:08 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:08 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:08 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:08 --> Parser Class Initialized
INFO - 2023-09-02 07:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:08 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:08 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:08 --> Controller Class Initialized
INFO - 2023-09-02 07:08:08 --> Model Class Initialized
INFO - 2023-09-02 07:08:08 --> Model Class Initialized
INFO - 2023-09-02 07:08:08 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:08 --> Total execution time: 0.0252
ERROR - 2023-09-02 07:08:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:14 --> Config Class Initialized
INFO - 2023-09-02 07:08:14 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:14 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:14 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:14 --> URI Class Initialized
INFO - 2023-09-02 07:08:14 --> Router Class Initialized
INFO - 2023-09-02 07:08:14 --> Output Class Initialized
INFO - 2023-09-02 07:08:14 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:14 --> Input Class Initialized
INFO - 2023-09-02 07:08:14 --> Language Class Initialized
INFO - 2023-09-02 07:08:14 --> Loader Class Initialized
INFO - 2023-09-02 07:08:14 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:14 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:14 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:14 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:14 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:14 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:14 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:14 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:14 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:14 --> Parser Class Initialized
INFO - 2023-09-02 07:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:14 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:14 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:14 --> Controller Class Initialized
DEBUG - 2023-09-02 07:08:14 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:14 --> Model Class Initialized
INFO - 2023-09-02 07:08:14 --> Model Class Initialized
INFO - 2023-09-02 07:08:14 --> Model Class Initialized
INFO - 2023-09-02 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-09-02 07:08:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:08:14 --> Model Class Initialized
INFO - 2023-09-02 07:08:14 --> Model Class Initialized
INFO - 2023-09-02 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:08:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:08:14 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:14 --> Total execution time: 0.0642
ERROR - 2023-09-02 07:08:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:24 --> Config Class Initialized
INFO - 2023-09-02 07:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:24 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:24 --> URI Class Initialized
INFO - 2023-09-02 07:08:24 --> Router Class Initialized
INFO - 2023-09-02 07:08:24 --> Output Class Initialized
INFO - 2023-09-02 07:08:24 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:24 --> Input Class Initialized
INFO - 2023-09-02 07:08:24 --> Language Class Initialized
INFO - 2023-09-02 07:08:24 --> Loader Class Initialized
INFO - 2023-09-02 07:08:24 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:24 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:24 --> Parser Class Initialized
INFO - 2023-09-02 07:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:24 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:24 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:24 --> Controller Class Initialized
INFO - 2023-09-02 07:08:24 --> Model Class Initialized
INFO - 2023-09-02 07:08:24 --> Model Class Initialized
INFO - 2023-09-02 07:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-09-02 07:08:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:08:24 --> Model Class Initialized
INFO - 2023-09-02 07:08:24 --> Model Class Initialized
INFO - 2023-09-02 07:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:08:24 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:24 --> Total execution time: 0.0625
ERROR - 2023-09-02 07:08:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:24 --> Config Class Initialized
INFO - 2023-09-02 07:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:24 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:24 --> URI Class Initialized
INFO - 2023-09-02 07:08:24 --> Router Class Initialized
INFO - 2023-09-02 07:08:24 --> Output Class Initialized
INFO - 2023-09-02 07:08:24 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:24 --> Input Class Initialized
INFO - 2023-09-02 07:08:24 --> Language Class Initialized
INFO - 2023-09-02 07:08:24 --> Loader Class Initialized
INFO - 2023-09-02 07:08:24 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:24 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:24 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:24 --> Parser Class Initialized
INFO - 2023-09-02 07:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:24 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:24 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:24 --> Controller Class Initialized
INFO - 2023-09-02 07:08:24 --> Model Class Initialized
INFO - 2023-09-02 07:08:24 --> Model Class Initialized
INFO - 2023-09-02 07:08:24 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:24 --> Total execution time: 0.0232
ERROR - 2023-09-02 07:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:31 --> Config Class Initialized
INFO - 2023-09-02 07:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:31 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:31 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:31 --> URI Class Initialized
INFO - 2023-09-02 07:08:31 --> Router Class Initialized
INFO - 2023-09-02 07:08:31 --> Output Class Initialized
INFO - 2023-09-02 07:08:31 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:31 --> Input Class Initialized
INFO - 2023-09-02 07:08:31 --> Language Class Initialized
INFO - 2023-09-02 07:08:31 --> Loader Class Initialized
INFO - 2023-09-02 07:08:31 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:31 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:31 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:31 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:31 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:31 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:31 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:31 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:31 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:31 --> Parser Class Initialized
INFO - 2023-09-02 07:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:31 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:31 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:31 --> Controller Class Initialized
DEBUG - 2023-09-02 07:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:31 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:31 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:31 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:31 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:31 --> Model Class Initialized
INFO - 2023-09-02 07:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-02 07:08:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:08:31 --> Model Class Initialized
INFO - 2023-09-02 07:08:31 --> Model Class Initialized
INFO - 2023-09-02 07:08:31 --> Model Class Initialized
INFO - 2023-09-02 07:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:08:31 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:31 --> Total execution time: 0.0631
ERROR - 2023-09-02 07:08:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:32 --> Config Class Initialized
INFO - 2023-09-02 07:08:32 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:32 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:32 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:32 --> URI Class Initialized
INFO - 2023-09-02 07:08:32 --> Router Class Initialized
INFO - 2023-09-02 07:08:32 --> Output Class Initialized
INFO - 2023-09-02 07:08:32 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:32 --> Input Class Initialized
INFO - 2023-09-02 07:08:32 --> Language Class Initialized
INFO - 2023-09-02 07:08:32 --> Loader Class Initialized
INFO - 2023-09-02 07:08:32 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:32 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:32 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:32 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:32 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:32 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:32 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:32 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:32 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:32 --> Parser Class Initialized
INFO - 2023-09-02 07:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:32 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:32 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:32 --> Controller Class Initialized
DEBUG - 2023-09-02 07:08:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:32 --> Model Class Initialized
INFO - 2023-09-02 07:08:32 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:32 --> Total execution time: 0.0198
ERROR - 2023-09-02 07:08:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:34 --> Config Class Initialized
INFO - 2023-09-02 07:08:34 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:34 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:34 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:34 --> URI Class Initialized
INFO - 2023-09-02 07:08:34 --> Router Class Initialized
INFO - 2023-09-02 07:08:34 --> Output Class Initialized
INFO - 2023-09-02 07:08:34 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:34 --> Input Class Initialized
INFO - 2023-09-02 07:08:34 --> Language Class Initialized
INFO - 2023-09-02 07:08:34 --> Loader Class Initialized
INFO - 2023-09-02 07:08:34 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:34 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:34 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:34 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:34 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:34 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:34 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:34 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:34 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:34 --> Parser Class Initialized
INFO - 2023-09-02 07:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:34 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:34 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:34 --> Controller Class Initialized
DEBUG - 2023-09-02 07:08:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:34 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:34 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:34 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:34 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:34 --> Model Class Initialized
INFO - 2023-09-02 07:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-02 07:08:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:08:34 --> Model Class Initialized
INFO - 2023-09-02 07:08:34 --> Model Class Initialized
INFO - 2023-09-02 07:08:34 --> Model Class Initialized
INFO - 2023-09-02 07:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:08:34 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:34 --> Total execution time: 0.0725
ERROR - 2023-09-02 07:08:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:35 --> Config Class Initialized
INFO - 2023-09-02 07:08:35 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:35 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:35 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:35 --> URI Class Initialized
INFO - 2023-09-02 07:08:35 --> Router Class Initialized
INFO - 2023-09-02 07:08:35 --> Output Class Initialized
INFO - 2023-09-02 07:08:35 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:35 --> Input Class Initialized
INFO - 2023-09-02 07:08:35 --> Language Class Initialized
INFO - 2023-09-02 07:08:35 --> Loader Class Initialized
INFO - 2023-09-02 07:08:35 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:35 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:35 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:35 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:35 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:35 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:35 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:35 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:35 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:35 --> Parser Class Initialized
INFO - 2023-09-02 07:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:35 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:35 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:35 --> Controller Class Initialized
DEBUG - 2023-09-02 07:08:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:35 --> Model Class Initialized
INFO - 2023-09-02 07:08:35 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:35 --> Total execution time: 0.0209
ERROR - 2023-09-02 07:08:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:08:40 --> Config Class Initialized
INFO - 2023-09-02 07:08:40 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:08:40 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:08:40 --> Utf8 Class Initialized
INFO - 2023-09-02 07:08:40 --> URI Class Initialized
DEBUG - 2023-09-02 07:08:40 --> No URI present. Default controller set.
INFO - 2023-09-02 07:08:40 --> Router Class Initialized
INFO - 2023-09-02 07:08:40 --> Output Class Initialized
INFO - 2023-09-02 07:08:40 --> Security Class Initialized
DEBUG - 2023-09-02 07:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:08:40 --> Input Class Initialized
INFO - 2023-09-02 07:08:40 --> Language Class Initialized
INFO - 2023-09-02 07:08:40 --> Loader Class Initialized
INFO - 2023-09-02 07:08:40 --> Helper loaded: url_helper
INFO - 2023-09-02 07:08:40 --> Helper loaded: file_helper
INFO - 2023-09-02 07:08:40 --> Helper loaded: html_helper
INFO - 2023-09-02 07:08:40 --> Helper loaded: text_helper
INFO - 2023-09-02 07:08:40 --> Helper loaded: form_helper
INFO - 2023-09-02 07:08:40 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:08:40 --> Helper loaded: security_helper
INFO - 2023-09-02 07:08:40 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:08:40 --> Database Driver Class Initialized
INFO - 2023-09-02 07:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:08:40 --> Parser Class Initialized
INFO - 2023-09-02 07:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:08:40 --> Pagination Class Initialized
INFO - 2023-09-02 07:08:40 --> Form Validation Class Initialized
INFO - 2023-09-02 07:08:40 --> Controller Class Initialized
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
DEBUG - 2023-09-02 07:08:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 07:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
INFO - 2023-09-02 07:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 07:08:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:08:40 --> Model Class Initialized
INFO - 2023-09-02 07:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 07:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 07:08:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:08:40 --> Final output sent to browser
DEBUG - 2023-09-02 07:08:40 --> Total execution time: 0.0821
ERROR - 2023-09-02 07:45:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:45:06 --> Config Class Initialized
INFO - 2023-09-02 07:45:06 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:45:06 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:45:06 --> Utf8 Class Initialized
INFO - 2023-09-02 07:45:06 --> URI Class Initialized
DEBUG - 2023-09-02 07:45:06 --> No URI present. Default controller set.
INFO - 2023-09-02 07:45:06 --> Router Class Initialized
INFO - 2023-09-02 07:45:06 --> Output Class Initialized
INFO - 2023-09-02 07:45:06 --> Security Class Initialized
DEBUG - 2023-09-02 07:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:45:06 --> Input Class Initialized
INFO - 2023-09-02 07:45:06 --> Language Class Initialized
INFO - 2023-09-02 07:45:06 --> Loader Class Initialized
INFO - 2023-09-02 07:45:06 --> Helper loaded: url_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: file_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: html_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: text_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: form_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: security_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:45:06 --> Database Driver Class Initialized
INFO - 2023-09-02 07:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:45:06 --> Parser Class Initialized
INFO - 2023-09-02 07:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:45:06 --> Pagination Class Initialized
INFO - 2023-09-02 07:45:06 --> Form Validation Class Initialized
INFO - 2023-09-02 07:45:06 --> Controller Class Initialized
INFO - 2023-09-02 07:45:06 --> Model Class Initialized
DEBUG - 2023-09-02 07:45:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 07:45:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 07:45:06 --> Config Class Initialized
INFO - 2023-09-02 07:45:06 --> Hooks Class Initialized
DEBUG - 2023-09-02 07:45:06 --> UTF-8 Support Enabled
INFO - 2023-09-02 07:45:06 --> Utf8 Class Initialized
INFO - 2023-09-02 07:45:06 --> URI Class Initialized
INFO - 2023-09-02 07:45:06 --> Router Class Initialized
INFO - 2023-09-02 07:45:06 --> Output Class Initialized
INFO - 2023-09-02 07:45:06 --> Security Class Initialized
DEBUG - 2023-09-02 07:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 07:45:06 --> Input Class Initialized
INFO - 2023-09-02 07:45:06 --> Language Class Initialized
INFO - 2023-09-02 07:45:06 --> Loader Class Initialized
INFO - 2023-09-02 07:45:06 --> Helper loaded: url_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: file_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: html_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: text_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: form_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: lang_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: security_helper
INFO - 2023-09-02 07:45:06 --> Helper loaded: cookie_helper
INFO - 2023-09-02 07:45:06 --> Database Driver Class Initialized
INFO - 2023-09-02 07:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 07:45:06 --> Parser Class Initialized
INFO - 2023-09-02 07:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 07:45:06 --> Pagination Class Initialized
INFO - 2023-09-02 07:45:06 --> Form Validation Class Initialized
INFO - 2023-09-02 07:45:06 --> Controller Class Initialized
INFO - 2023-09-02 07:45:06 --> Model Class Initialized
DEBUG - 2023-09-02 07:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 07:45:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 07:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 07:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 07:45:06 --> Model Class Initialized
INFO - 2023-09-02 07:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 07:45:06 --> Final output sent to browser
DEBUG - 2023-09-02 07:45:06 --> Total execution time: 0.0329
ERROR - 2023-09-02 08:09:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 08:09:41 --> Config Class Initialized
INFO - 2023-09-02 08:09:41 --> Hooks Class Initialized
DEBUG - 2023-09-02 08:09:41 --> UTF-8 Support Enabled
INFO - 2023-09-02 08:09:41 --> Utf8 Class Initialized
INFO - 2023-09-02 08:09:41 --> URI Class Initialized
DEBUG - 2023-09-02 08:09:41 --> No URI present. Default controller set.
INFO - 2023-09-02 08:09:41 --> Router Class Initialized
INFO - 2023-09-02 08:09:41 --> Output Class Initialized
INFO - 2023-09-02 08:09:41 --> Security Class Initialized
DEBUG - 2023-09-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 08:09:41 --> Input Class Initialized
INFO - 2023-09-02 08:09:41 --> Language Class Initialized
INFO - 2023-09-02 08:09:41 --> Loader Class Initialized
INFO - 2023-09-02 08:09:41 --> Helper loaded: url_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: file_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: html_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: text_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: form_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: lang_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: security_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: cookie_helper
INFO - 2023-09-02 08:09:41 --> Database Driver Class Initialized
INFO - 2023-09-02 08:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 08:09:41 --> Parser Class Initialized
INFO - 2023-09-02 08:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 08:09:41 --> Pagination Class Initialized
INFO - 2023-09-02 08:09:41 --> Form Validation Class Initialized
INFO - 2023-09-02 08:09:41 --> Controller Class Initialized
INFO - 2023-09-02 08:09:41 --> Model Class Initialized
DEBUG - 2023-09-02 08:09:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 08:09:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 08:09:41 --> Config Class Initialized
INFO - 2023-09-02 08:09:41 --> Hooks Class Initialized
DEBUG - 2023-09-02 08:09:41 --> UTF-8 Support Enabled
INFO - 2023-09-02 08:09:41 --> Utf8 Class Initialized
INFO - 2023-09-02 08:09:41 --> URI Class Initialized
DEBUG - 2023-09-02 08:09:41 --> No URI present. Default controller set.
INFO - 2023-09-02 08:09:41 --> Router Class Initialized
INFO - 2023-09-02 08:09:41 --> Output Class Initialized
INFO - 2023-09-02 08:09:41 --> Security Class Initialized
DEBUG - 2023-09-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 08:09:41 --> Input Class Initialized
INFO - 2023-09-02 08:09:41 --> Language Class Initialized
INFO - 2023-09-02 08:09:41 --> Loader Class Initialized
INFO - 2023-09-02 08:09:41 --> Helper loaded: url_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: file_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: html_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: text_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: form_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: lang_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: security_helper
INFO - 2023-09-02 08:09:41 --> Helper loaded: cookie_helper
INFO - 2023-09-02 08:09:41 --> Database Driver Class Initialized
INFO - 2023-09-02 08:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 08:09:41 --> Parser Class Initialized
INFO - 2023-09-02 08:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 08:09:41 --> Pagination Class Initialized
INFO - 2023-09-02 08:09:41 --> Form Validation Class Initialized
INFO - 2023-09-02 08:09:41 --> Controller Class Initialized
INFO - 2023-09-02 08:09:41 --> Model Class Initialized
DEBUG - 2023-09-02 08:09:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 08:09:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 08:09:42 --> Config Class Initialized
INFO - 2023-09-02 08:09:42 --> Hooks Class Initialized
DEBUG - 2023-09-02 08:09:42 --> UTF-8 Support Enabled
INFO - 2023-09-02 08:09:42 --> Utf8 Class Initialized
INFO - 2023-09-02 08:09:42 --> URI Class Initialized
DEBUG - 2023-09-02 08:09:42 --> No URI present. Default controller set.
INFO - 2023-09-02 08:09:42 --> Router Class Initialized
INFO - 2023-09-02 08:09:42 --> Output Class Initialized
INFO - 2023-09-02 08:09:42 --> Security Class Initialized
DEBUG - 2023-09-02 08:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 08:09:42 --> Input Class Initialized
INFO - 2023-09-02 08:09:42 --> Language Class Initialized
INFO - 2023-09-02 08:09:42 --> Loader Class Initialized
INFO - 2023-09-02 08:09:42 --> Helper loaded: url_helper
INFO - 2023-09-02 08:09:42 --> Helper loaded: file_helper
INFO - 2023-09-02 08:09:42 --> Helper loaded: html_helper
INFO - 2023-09-02 08:09:42 --> Helper loaded: text_helper
INFO - 2023-09-02 08:09:42 --> Helper loaded: form_helper
INFO - 2023-09-02 08:09:42 --> Helper loaded: lang_helper
INFO - 2023-09-02 08:09:42 --> Helper loaded: security_helper
INFO - 2023-09-02 08:09:42 --> Helper loaded: cookie_helper
INFO - 2023-09-02 08:09:42 --> Database Driver Class Initialized
INFO - 2023-09-02 08:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 08:09:42 --> Parser Class Initialized
INFO - 2023-09-02 08:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 08:09:42 --> Pagination Class Initialized
INFO - 2023-09-02 08:09:42 --> Form Validation Class Initialized
INFO - 2023-09-02 08:09:42 --> Controller Class Initialized
INFO - 2023-09-02 08:09:42 --> Model Class Initialized
DEBUG - 2023-09-02 08:09:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 08:09:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 08:09:43 --> Config Class Initialized
INFO - 2023-09-02 08:09:43 --> Hooks Class Initialized
DEBUG - 2023-09-02 08:09:43 --> UTF-8 Support Enabled
INFO - 2023-09-02 08:09:43 --> Utf8 Class Initialized
INFO - 2023-09-02 08:09:43 --> URI Class Initialized
DEBUG - 2023-09-02 08:09:43 --> No URI present. Default controller set.
INFO - 2023-09-02 08:09:43 --> Router Class Initialized
INFO - 2023-09-02 08:09:43 --> Output Class Initialized
INFO - 2023-09-02 08:09:43 --> Security Class Initialized
DEBUG - 2023-09-02 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 08:09:43 --> Input Class Initialized
INFO - 2023-09-02 08:09:43 --> Language Class Initialized
INFO - 2023-09-02 08:09:43 --> Loader Class Initialized
INFO - 2023-09-02 08:09:43 --> Helper loaded: url_helper
INFO - 2023-09-02 08:09:43 --> Helper loaded: file_helper
INFO - 2023-09-02 08:09:43 --> Helper loaded: html_helper
INFO - 2023-09-02 08:09:43 --> Helper loaded: text_helper
INFO - 2023-09-02 08:09:43 --> Helper loaded: form_helper
INFO - 2023-09-02 08:09:43 --> Helper loaded: lang_helper
INFO - 2023-09-02 08:09:43 --> Helper loaded: security_helper
INFO - 2023-09-02 08:09:43 --> Helper loaded: cookie_helper
INFO - 2023-09-02 08:09:43 --> Database Driver Class Initialized
INFO - 2023-09-02 08:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 08:09:43 --> Parser Class Initialized
INFO - 2023-09-02 08:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 08:09:43 --> Pagination Class Initialized
INFO - 2023-09-02 08:09:43 --> Form Validation Class Initialized
INFO - 2023-09-02 08:09:43 --> Controller Class Initialized
INFO - 2023-09-02 08:09:43 --> Model Class Initialized
DEBUG - 2023-09-02 08:09:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 10:07:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:07:43 --> Config Class Initialized
INFO - 2023-09-02 10:07:43 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:07:43 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:07:43 --> Utf8 Class Initialized
INFO - 2023-09-02 10:07:43 --> URI Class Initialized
DEBUG - 2023-09-02 10:07:43 --> No URI present. Default controller set.
INFO - 2023-09-02 10:07:43 --> Router Class Initialized
INFO - 2023-09-02 10:07:43 --> Output Class Initialized
INFO - 2023-09-02 10:07:43 --> Security Class Initialized
DEBUG - 2023-09-02 10:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:07:43 --> Input Class Initialized
INFO - 2023-09-02 10:07:43 --> Language Class Initialized
INFO - 2023-09-02 10:07:43 --> Loader Class Initialized
INFO - 2023-09-02 10:07:43 --> Helper loaded: url_helper
INFO - 2023-09-02 10:07:43 --> Helper loaded: file_helper
INFO - 2023-09-02 10:07:43 --> Helper loaded: html_helper
INFO - 2023-09-02 10:07:43 --> Helper loaded: text_helper
INFO - 2023-09-02 10:07:43 --> Helper loaded: form_helper
INFO - 2023-09-02 10:07:43 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:07:43 --> Helper loaded: security_helper
INFO - 2023-09-02 10:07:43 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:07:43 --> Database Driver Class Initialized
INFO - 2023-09-02 10:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:07:43 --> Parser Class Initialized
INFO - 2023-09-02 10:07:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:07:43 --> Pagination Class Initialized
INFO - 2023-09-02 10:07:43 --> Form Validation Class Initialized
INFO - 2023-09-02 10:07:43 --> Controller Class Initialized
INFO - 2023-09-02 10:07:43 --> Model Class Initialized
DEBUG - 2023-09-02 10:07:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 10:07:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:07:47 --> Config Class Initialized
INFO - 2023-09-02 10:07:47 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:07:47 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:07:47 --> Utf8 Class Initialized
INFO - 2023-09-02 10:07:47 --> URI Class Initialized
INFO - 2023-09-02 10:07:47 --> Router Class Initialized
INFO - 2023-09-02 10:07:47 --> Output Class Initialized
INFO - 2023-09-02 10:07:47 --> Security Class Initialized
DEBUG - 2023-09-02 10:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:07:47 --> Input Class Initialized
INFO - 2023-09-02 10:07:47 --> Language Class Initialized
INFO - 2023-09-02 10:07:47 --> Loader Class Initialized
INFO - 2023-09-02 10:07:47 --> Helper loaded: url_helper
INFO - 2023-09-02 10:07:47 --> Helper loaded: file_helper
INFO - 2023-09-02 10:07:47 --> Helper loaded: html_helper
INFO - 2023-09-02 10:07:47 --> Helper loaded: text_helper
INFO - 2023-09-02 10:07:47 --> Helper loaded: form_helper
INFO - 2023-09-02 10:07:47 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:07:47 --> Helper loaded: security_helper
INFO - 2023-09-02 10:07:47 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:07:47 --> Database Driver Class Initialized
INFO - 2023-09-02 10:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:07:47 --> Parser Class Initialized
INFO - 2023-09-02 10:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:07:47 --> Pagination Class Initialized
INFO - 2023-09-02 10:07:47 --> Form Validation Class Initialized
INFO - 2023-09-02 10:07:47 --> Controller Class Initialized
INFO - 2023-09-02 10:07:47 --> Model Class Initialized
DEBUG - 2023-09-02 10:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:07:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 10:07:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:07:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:07:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:07:47 --> Model Class Initialized
INFO - 2023-09-02 10:07:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:07:47 --> Final output sent to browser
DEBUG - 2023-09-02 10:07:47 --> Total execution time: 0.0328
ERROR - 2023-09-02 10:17:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:17:40 --> Config Class Initialized
INFO - 2023-09-02 10:17:40 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:17:40 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:17:40 --> Utf8 Class Initialized
INFO - 2023-09-02 10:17:40 --> URI Class Initialized
DEBUG - 2023-09-02 10:17:40 --> No URI present. Default controller set.
INFO - 2023-09-02 10:17:40 --> Router Class Initialized
INFO - 2023-09-02 10:17:40 --> Output Class Initialized
INFO - 2023-09-02 10:17:40 --> Security Class Initialized
DEBUG - 2023-09-02 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:17:40 --> Input Class Initialized
INFO - 2023-09-02 10:17:40 --> Language Class Initialized
INFO - 2023-09-02 10:17:40 --> Loader Class Initialized
INFO - 2023-09-02 10:17:40 --> Helper loaded: url_helper
INFO - 2023-09-02 10:17:40 --> Helper loaded: file_helper
INFO - 2023-09-02 10:17:40 --> Helper loaded: html_helper
INFO - 2023-09-02 10:17:40 --> Helper loaded: text_helper
INFO - 2023-09-02 10:17:40 --> Helper loaded: form_helper
INFO - 2023-09-02 10:17:40 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:17:40 --> Helper loaded: security_helper
INFO - 2023-09-02 10:17:40 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:17:40 --> Database Driver Class Initialized
INFO - 2023-09-02 10:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:17:40 --> Parser Class Initialized
INFO - 2023-09-02 10:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:17:40 --> Pagination Class Initialized
INFO - 2023-09-02 10:17:40 --> Form Validation Class Initialized
INFO - 2023-09-02 10:17:40 --> Controller Class Initialized
INFO - 2023-09-02 10:17:40 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 10:17:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:17:41 --> Config Class Initialized
INFO - 2023-09-02 10:17:41 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:17:41 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:17:41 --> Utf8 Class Initialized
INFO - 2023-09-02 10:17:41 --> URI Class Initialized
INFO - 2023-09-02 10:17:41 --> Router Class Initialized
INFO - 2023-09-02 10:17:41 --> Output Class Initialized
INFO - 2023-09-02 10:17:41 --> Security Class Initialized
DEBUG - 2023-09-02 10:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:17:41 --> Input Class Initialized
INFO - 2023-09-02 10:17:41 --> Language Class Initialized
INFO - 2023-09-02 10:17:41 --> Loader Class Initialized
INFO - 2023-09-02 10:17:41 --> Helper loaded: url_helper
INFO - 2023-09-02 10:17:41 --> Helper loaded: file_helper
INFO - 2023-09-02 10:17:41 --> Helper loaded: html_helper
INFO - 2023-09-02 10:17:41 --> Helper loaded: text_helper
INFO - 2023-09-02 10:17:41 --> Helper loaded: form_helper
INFO - 2023-09-02 10:17:41 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:17:41 --> Helper loaded: security_helper
INFO - 2023-09-02 10:17:41 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:17:41 --> Database Driver Class Initialized
INFO - 2023-09-02 10:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:17:41 --> Parser Class Initialized
INFO - 2023-09-02 10:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:17:41 --> Pagination Class Initialized
INFO - 2023-09-02 10:17:41 --> Form Validation Class Initialized
INFO - 2023-09-02 10:17:41 --> Controller Class Initialized
INFO - 2023-09-02 10:17:41 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 10:17:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:17:41 --> Model Class Initialized
INFO - 2023-09-02 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:17:41 --> Final output sent to browser
DEBUG - 2023-09-02 10:17:41 --> Total execution time: 0.0299
ERROR - 2023-09-02 10:17:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:17:44 --> Config Class Initialized
INFO - 2023-09-02 10:17:44 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:17:44 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:17:44 --> Utf8 Class Initialized
INFO - 2023-09-02 10:17:44 --> URI Class Initialized
INFO - 2023-09-02 10:17:44 --> Router Class Initialized
INFO - 2023-09-02 10:17:44 --> Output Class Initialized
INFO - 2023-09-02 10:17:44 --> Security Class Initialized
DEBUG - 2023-09-02 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:17:44 --> Input Class Initialized
INFO - 2023-09-02 10:17:44 --> Language Class Initialized
INFO - 2023-09-02 10:17:44 --> Loader Class Initialized
INFO - 2023-09-02 10:17:44 --> Helper loaded: url_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: file_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: html_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: text_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: form_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: security_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:17:44 --> Database Driver Class Initialized
INFO - 2023-09-02 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:17:44 --> Parser Class Initialized
INFO - 2023-09-02 10:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:17:44 --> Pagination Class Initialized
INFO - 2023-09-02 10:17:44 --> Form Validation Class Initialized
INFO - 2023-09-02 10:17:44 --> Controller Class Initialized
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
INFO - 2023-09-02 10:17:44 --> Final output sent to browser
DEBUG - 2023-09-02 10:17:44 --> Total execution time: 0.0191
ERROR - 2023-09-02 10:17:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:17:44 --> Config Class Initialized
INFO - 2023-09-02 10:17:44 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:17:44 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:17:44 --> Utf8 Class Initialized
INFO - 2023-09-02 10:17:44 --> URI Class Initialized
DEBUG - 2023-09-02 10:17:44 --> No URI present. Default controller set.
INFO - 2023-09-02 10:17:44 --> Router Class Initialized
INFO - 2023-09-02 10:17:44 --> Output Class Initialized
INFO - 2023-09-02 10:17:44 --> Security Class Initialized
DEBUG - 2023-09-02 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:17:44 --> Input Class Initialized
INFO - 2023-09-02 10:17:44 --> Language Class Initialized
INFO - 2023-09-02 10:17:44 --> Loader Class Initialized
INFO - 2023-09-02 10:17:44 --> Helper loaded: url_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: file_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: html_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: text_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: form_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: security_helper
INFO - 2023-09-02 10:17:44 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:17:44 --> Database Driver Class Initialized
INFO - 2023-09-02 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:17:44 --> Parser Class Initialized
INFO - 2023-09-02 10:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:17:44 --> Pagination Class Initialized
INFO - 2023-09-02 10:17:44 --> Form Validation Class Initialized
INFO - 2023-09-02 10:17:44 --> Controller Class Initialized
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
INFO - 2023-09-02 10:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 10:17:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:17:44 --> Model Class Initialized
INFO - 2023-09-02 10:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:17:44 --> Final output sent to browser
DEBUG - 2023-09-02 10:17:44 --> Total execution time: 0.2036
ERROR - 2023-09-02 10:17:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:17:45 --> Config Class Initialized
INFO - 2023-09-02 10:17:45 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:17:45 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:17:45 --> Utf8 Class Initialized
INFO - 2023-09-02 10:17:45 --> URI Class Initialized
INFO - 2023-09-02 10:17:45 --> Router Class Initialized
INFO - 2023-09-02 10:17:45 --> Output Class Initialized
INFO - 2023-09-02 10:17:45 --> Security Class Initialized
DEBUG - 2023-09-02 10:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:17:45 --> Input Class Initialized
INFO - 2023-09-02 10:17:45 --> Language Class Initialized
INFO - 2023-09-02 10:17:45 --> Loader Class Initialized
INFO - 2023-09-02 10:17:45 --> Helper loaded: url_helper
INFO - 2023-09-02 10:17:45 --> Helper loaded: file_helper
INFO - 2023-09-02 10:17:45 --> Helper loaded: html_helper
INFO - 2023-09-02 10:17:45 --> Helper loaded: text_helper
INFO - 2023-09-02 10:17:45 --> Helper loaded: form_helper
INFO - 2023-09-02 10:17:45 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:17:45 --> Helper loaded: security_helper
INFO - 2023-09-02 10:17:45 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:17:45 --> Database Driver Class Initialized
INFO - 2023-09-02 10:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:17:45 --> Parser Class Initialized
INFO - 2023-09-02 10:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:17:45 --> Pagination Class Initialized
INFO - 2023-09-02 10:17:45 --> Form Validation Class Initialized
INFO - 2023-09-02 10:17:45 --> Controller Class Initialized
DEBUG - 2023-09-02 10:17:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:45 --> Model Class Initialized
INFO - 2023-09-02 10:17:45 --> Final output sent to browser
DEBUG - 2023-09-02 10:17:45 --> Total execution time: 0.0136
ERROR - 2023-09-02 10:17:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:17:49 --> Config Class Initialized
INFO - 2023-09-02 10:17:49 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:17:49 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:17:49 --> Utf8 Class Initialized
INFO - 2023-09-02 10:17:49 --> URI Class Initialized
INFO - 2023-09-02 10:17:49 --> Router Class Initialized
INFO - 2023-09-02 10:17:49 --> Output Class Initialized
INFO - 2023-09-02 10:17:49 --> Security Class Initialized
DEBUG - 2023-09-02 10:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:17:49 --> Input Class Initialized
INFO - 2023-09-02 10:17:49 --> Language Class Initialized
INFO - 2023-09-02 10:17:49 --> Loader Class Initialized
INFO - 2023-09-02 10:17:49 --> Helper loaded: url_helper
INFO - 2023-09-02 10:17:49 --> Helper loaded: file_helper
INFO - 2023-09-02 10:17:49 --> Helper loaded: html_helper
INFO - 2023-09-02 10:17:49 --> Helper loaded: text_helper
INFO - 2023-09-02 10:17:49 --> Helper loaded: form_helper
INFO - 2023-09-02 10:17:49 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:17:49 --> Helper loaded: security_helper
INFO - 2023-09-02 10:17:49 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:17:49 --> Database Driver Class Initialized
INFO - 2023-09-02 10:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:17:49 --> Parser Class Initialized
INFO - 2023-09-02 10:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:17:49 --> Pagination Class Initialized
INFO - 2023-09-02 10:17:49 --> Form Validation Class Initialized
INFO - 2023-09-02 10:17:49 --> Controller Class Initialized
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
INFO - 2023-09-02 10:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:17:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
INFO - 2023-09-02 10:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:17:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:17:50 --> Final output sent to browser
DEBUG - 2023-09-02 10:17:50 --> Total execution time: 0.1395
ERROR - 2023-09-02 10:17:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:17:50 --> Config Class Initialized
INFO - 2023-09-02 10:17:50 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:17:50 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:17:50 --> Utf8 Class Initialized
INFO - 2023-09-02 10:17:50 --> URI Class Initialized
INFO - 2023-09-02 10:17:50 --> Router Class Initialized
INFO - 2023-09-02 10:17:50 --> Output Class Initialized
INFO - 2023-09-02 10:17:50 --> Security Class Initialized
DEBUG - 2023-09-02 10:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:17:50 --> Input Class Initialized
INFO - 2023-09-02 10:17:50 --> Language Class Initialized
INFO - 2023-09-02 10:17:50 --> Loader Class Initialized
INFO - 2023-09-02 10:17:50 --> Helper loaded: url_helper
INFO - 2023-09-02 10:17:50 --> Helper loaded: file_helper
INFO - 2023-09-02 10:17:50 --> Helper loaded: html_helper
INFO - 2023-09-02 10:17:50 --> Helper loaded: text_helper
INFO - 2023-09-02 10:17:50 --> Helper loaded: form_helper
INFO - 2023-09-02 10:17:50 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:17:50 --> Helper loaded: security_helper
INFO - 2023-09-02 10:17:50 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:17:50 --> Database Driver Class Initialized
INFO - 2023-09-02 10:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:17:50 --> Parser Class Initialized
INFO - 2023-09-02 10:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:17:50 --> Pagination Class Initialized
INFO - 2023-09-02 10:17:50 --> Form Validation Class Initialized
INFO - 2023-09-02 10:17:50 --> Controller Class Initialized
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
DEBUG - 2023-09-02 10:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:17:50 --> Model Class Initialized
INFO - 2023-09-02 10:17:50 --> Final output sent to browser
DEBUG - 2023-09-02 10:17:50 --> Total execution time: 0.0523
ERROR - 2023-09-02 10:18:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:21 --> Config Class Initialized
INFO - 2023-09-02 10:18:21 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:21 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:21 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:21 --> URI Class Initialized
DEBUG - 2023-09-02 10:18:21 --> No URI present. Default controller set.
INFO - 2023-09-02 10:18:21 --> Router Class Initialized
INFO - 2023-09-02 10:18:21 --> Output Class Initialized
INFO - 2023-09-02 10:18:21 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:21 --> Input Class Initialized
INFO - 2023-09-02 10:18:21 --> Language Class Initialized
INFO - 2023-09-02 10:18:21 --> Loader Class Initialized
INFO - 2023-09-02 10:18:21 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:21 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:21 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:21 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:21 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:21 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:21 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:21 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:21 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:21 --> Parser Class Initialized
INFO - 2023-09-02 10:18:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:21 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:21 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:21 --> Controller Class Initialized
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
INFO - 2023-09-02 10:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 10:18:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:18:21 --> Model Class Initialized
INFO - 2023-09-02 10:18:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:18:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:18:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:18:22 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:22 --> Total execution time: 0.2013
ERROR - 2023-09-02 10:18:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:30 --> Config Class Initialized
INFO - 2023-09-02 10:18:30 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:30 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:30 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:30 --> URI Class Initialized
INFO - 2023-09-02 10:18:30 --> Router Class Initialized
INFO - 2023-09-02 10:18:30 --> Output Class Initialized
INFO - 2023-09-02 10:18:30 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:30 --> Input Class Initialized
INFO - 2023-09-02 10:18:30 --> Language Class Initialized
INFO - 2023-09-02 10:18:30 --> Loader Class Initialized
INFO - 2023-09-02 10:18:30 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:30 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:30 --> Parser Class Initialized
INFO - 2023-09-02 10:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:30 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:30 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:30 --> Controller Class Initialized
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
INFO - 2023-09-02 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:18:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
INFO - 2023-09-02 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:18:30 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:30 --> Total execution time: 0.1419
ERROR - 2023-09-02 10:18:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:30 --> Config Class Initialized
INFO - 2023-09-02 10:18:30 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:30 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:30 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:30 --> URI Class Initialized
INFO - 2023-09-02 10:18:30 --> Router Class Initialized
INFO - 2023-09-02 10:18:30 --> Output Class Initialized
INFO - 2023-09-02 10:18:30 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:30 --> Input Class Initialized
INFO - 2023-09-02 10:18:30 --> Language Class Initialized
INFO - 2023-09-02 10:18:30 --> Loader Class Initialized
INFO - 2023-09-02 10:18:30 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:30 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:30 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:30 --> Parser Class Initialized
INFO - 2023-09-02 10:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:30 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:30 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:30 --> Controller Class Initialized
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:30 --> Model Class Initialized
INFO - 2023-09-02 10:18:30 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:30 --> Total execution time: 0.0621
ERROR - 2023-09-02 10:18:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:35 --> Config Class Initialized
INFO - 2023-09-02 10:18:35 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:35 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:35 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:35 --> URI Class Initialized
INFO - 2023-09-02 10:18:35 --> Router Class Initialized
INFO - 2023-09-02 10:18:35 --> Output Class Initialized
INFO - 2023-09-02 10:18:35 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:35 --> Input Class Initialized
INFO - 2023-09-02 10:18:35 --> Language Class Initialized
INFO - 2023-09-02 10:18:35 --> Loader Class Initialized
INFO - 2023-09-02 10:18:35 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:35 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:35 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:35 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:35 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:35 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:35 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:35 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:35 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:35 --> Parser Class Initialized
INFO - 2023-09-02 10:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:35 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:35 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:35 --> Controller Class Initialized
INFO - 2023-09-02 10:18:35 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:35 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:35 --> Model Class Initialized
INFO - 2023-09-02 10:18:35 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:35 --> Total execution time: 0.6928
ERROR - 2023-09-02 10:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:51 --> Config Class Initialized
INFO - 2023-09-02 10:18:51 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:51 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:51 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:51 --> URI Class Initialized
INFO - 2023-09-02 10:18:51 --> Router Class Initialized
INFO - 2023-09-02 10:18:51 --> Output Class Initialized
INFO - 2023-09-02 10:18:51 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:51 --> Input Class Initialized
INFO - 2023-09-02 10:18:51 --> Language Class Initialized
INFO - 2023-09-02 10:18:51 --> Loader Class Initialized
INFO - 2023-09-02 10:18:51 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:51 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:51 --> Parser Class Initialized
INFO - 2023-09-02 10:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:51 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:51 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:51 --> Controller Class Initialized
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
INFO - 2023-09-02 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:18:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
INFO - 2023-09-02 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:18:51 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:51 --> Total execution time: 0.1399
ERROR - 2023-09-02 10:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:51 --> Config Class Initialized
INFO - 2023-09-02 10:18:51 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:51 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:51 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:51 --> URI Class Initialized
INFO - 2023-09-02 10:18:51 --> Router Class Initialized
INFO - 2023-09-02 10:18:51 --> Output Class Initialized
INFO - 2023-09-02 10:18:51 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:51 --> Input Class Initialized
INFO - 2023-09-02 10:18:51 --> Language Class Initialized
INFO - 2023-09-02 10:18:51 --> Loader Class Initialized
INFO - 2023-09-02 10:18:51 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:51 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:51 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:51 --> Parser Class Initialized
INFO - 2023-09-02 10:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:51 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:51 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:51 --> Controller Class Initialized
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:51 --> Model Class Initialized
INFO - 2023-09-02 10:18:51 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:51 --> Total execution time: 0.0525
ERROR - 2023-09-02 10:18:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:55 --> Config Class Initialized
INFO - 2023-09-02 10:18:55 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:55 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:55 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:55 --> URI Class Initialized
INFO - 2023-09-02 10:18:55 --> Router Class Initialized
INFO - 2023-09-02 10:18:55 --> Output Class Initialized
INFO - 2023-09-02 10:18:55 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:55 --> Input Class Initialized
INFO - 2023-09-02 10:18:55 --> Language Class Initialized
INFO - 2023-09-02 10:18:55 --> Loader Class Initialized
INFO - 2023-09-02 10:18:55 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:55 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:55 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:55 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:55 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:55 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:55 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:55 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:55 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:55 --> Parser Class Initialized
INFO - 2023-09-02 10:18:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:55 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:55 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:55 --> Controller Class Initialized
INFO - 2023-09-02 10:18:55 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:55 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:55 --> Model Class Initialized
ERROR - 2023-09-02 10:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-09-02 10:18:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-09-02 10:18:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:18:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:18:55 --> Model Class Initialized
INFO - 2023-09-02 10:18:55 --> Model Class Initialized
INFO - 2023-09-02 10:18:55 --> Model Class Initialized
INFO - 2023-09-02 10:18:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:18:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:18:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:18:55 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:55 --> Total execution time: 0.1754
ERROR - 2023-09-02 10:18:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:56 --> Config Class Initialized
INFO - 2023-09-02 10:18:56 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:56 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:56 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:56 --> URI Class Initialized
INFO - 2023-09-02 10:18:56 --> Router Class Initialized
INFO - 2023-09-02 10:18:56 --> Output Class Initialized
INFO - 2023-09-02 10:18:56 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:56 --> Input Class Initialized
INFO - 2023-09-02 10:18:56 --> Language Class Initialized
INFO - 2023-09-02 10:18:56 --> Loader Class Initialized
INFO - 2023-09-02 10:18:56 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:56 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:56 --> Parser Class Initialized
INFO - 2023-09-02 10:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:56 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:56 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:56 --> Controller Class Initialized
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:56 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:56 --> Total execution time: 0.0205
ERROR - 2023-09-02 10:18:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:18:56 --> Config Class Initialized
INFO - 2023-09-02 10:18:56 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:18:56 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:18:56 --> Utf8 Class Initialized
INFO - 2023-09-02 10:18:56 --> URI Class Initialized
INFO - 2023-09-02 10:18:56 --> Router Class Initialized
INFO - 2023-09-02 10:18:56 --> Output Class Initialized
INFO - 2023-09-02 10:18:56 --> Security Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:18:56 --> Input Class Initialized
INFO - 2023-09-02 10:18:56 --> Language Class Initialized
INFO - 2023-09-02 10:18:56 --> Loader Class Initialized
INFO - 2023-09-02 10:18:56 --> Helper loaded: url_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: file_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: html_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: text_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: form_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: security_helper
INFO - 2023-09-02 10:18:56 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:18:56 --> Database Driver Class Initialized
INFO - 2023-09-02 10:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:18:56 --> Parser Class Initialized
INFO - 2023-09-02 10:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:18:56 --> Pagination Class Initialized
INFO - 2023-09-02 10:18:56 --> Form Validation Class Initialized
INFO - 2023-09-02 10:18:56 --> Controller Class Initialized
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
INFO - 2023-09-02 10:18:56 --> Model Class Initialized
DEBUG - 2023-09-02 10:18:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:18:56 --> Final output sent to browser
DEBUG - 2023-09-02 10:18:56 --> Total execution time: 0.0202
ERROR - 2023-09-02 10:19:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:07 --> Config Class Initialized
INFO - 2023-09-02 10:19:07 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:07 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:07 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:07 --> URI Class Initialized
INFO - 2023-09-02 10:19:07 --> Router Class Initialized
INFO - 2023-09-02 10:19:07 --> Output Class Initialized
INFO - 2023-09-02 10:19:07 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:07 --> Input Class Initialized
INFO - 2023-09-02 10:19:07 --> Language Class Initialized
INFO - 2023-09-02 10:19:07 --> Loader Class Initialized
INFO - 2023-09-02 10:19:07 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:07 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:07 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:07 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:07 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:07 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:07 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:07 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:07 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:07 --> Parser Class Initialized
INFO - 2023-09-02 10:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:07 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:07 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:07 --> Controller Class Initialized
INFO - 2023-09-02 10:19:07 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:07 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:07 --> Model Class Initialized
INFO - 2023-09-02 10:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:19:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:19:07 --> Model Class Initialized
INFO - 2023-09-02 10:19:07 --> Model Class Initialized
INFO - 2023-09-02 10:19:07 --> Model Class Initialized
INFO - 2023-09-02 10:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:19:07 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:07 --> Total execution time: 0.1487
ERROR - 2023-09-02 10:19:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:08 --> Config Class Initialized
INFO - 2023-09-02 10:19:08 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:08 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:08 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:08 --> URI Class Initialized
INFO - 2023-09-02 10:19:08 --> Router Class Initialized
INFO - 2023-09-02 10:19:08 --> Output Class Initialized
INFO - 2023-09-02 10:19:08 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:08 --> Input Class Initialized
INFO - 2023-09-02 10:19:08 --> Language Class Initialized
INFO - 2023-09-02 10:19:08 --> Loader Class Initialized
INFO - 2023-09-02 10:19:08 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:08 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:08 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:08 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:08 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:08 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:08 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:08 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:08 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:08 --> Parser Class Initialized
INFO - 2023-09-02 10:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:08 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:08 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:08 --> Controller Class Initialized
INFO - 2023-09-02 10:19:08 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:08 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:08 --> Model Class Initialized
INFO - 2023-09-02 10:19:08 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:08 --> Total execution time: 0.0590
ERROR - 2023-09-02 10:19:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:17 --> Config Class Initialized
INFO - 2023-09-02 10:19:17 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:17 --> URI Class Initialized
INFO - 2023-09-02 10:19:17 --> Router Class Initialized
INFO - 2023-09-02 10:19:17 --> Output Class Initialized
INFO - 2023-09-02 10:19:17 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:17 --> Input Class Initialized
INFO - 2023-09-02 10:19:17 --> Language Class Initialized
INFO - 2023-09-02 10:19:17 --> Loader Class Initialized
INFO - 2023-09-02 10:19:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:17 --> Parser Class Initialized
INFO - 2023-09-02 10:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:17 --> Controller Class Initialized
INFO - 2023-09-02 10:19:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:17 --> Model Class Initialized
ERROR - 2023-09-02 10:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-09-02 10:19:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-09-02 10:19:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:19:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:19:17 --> Model Class Initialized
INFO - 2023-09-02 10:19:17 --> Model Class Initialized
INFO - 2023-09-02 10:19:17 --> Model Class Initialized
INFO - 2023-09-02 10:19:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:19:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:19:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:19:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:17 --> Total execution time: 0.1932
ERROR - 2023-09-02 10:19:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:18 --> Config Class Initialized
INFO - 2023-09-02 10:19:18 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:18 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:18 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:18 --> URI Class Initialized
INFO - 2023-09-02 10:19:18 --> Router Class Initialized
INFO - 2023-09-02 10:19:18 --> Output Class Initialized
INFO - 2023-09-02 10:19:18 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:18 --> Input Class Initialized
INFO - 2023-09-02 10:19:18 --> Language Class Initialized
INFO - 2023-09-02 10:19:18 --> Loader Class Initialized
INFO - 2023-09-02 10:19:18 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:18 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:18 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:18 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:18 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:18 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:18 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:18 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:18 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:18 --> Parser Class Initialized
INFO - 2023-09-02 10:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:18 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:18 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:18 --> Controller Class Initialized
INFO - 2023-09-02 10:19:18 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:18 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:18 --> Model Class Initialized
INFO - 2023-09-02 10:19:18 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:18 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:18 --> Total execution time: 0.0202
ERROR - 2023-09-02 10:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:28 --> Config Class Initialized
INFO - 2023-09-02 10:19:28 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:28 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:28 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:28 --> URI Class Initialized
DEBUG - 2023-09-02 10:19:28 --> No URI present. Default controller set.
INFO - 2023-09-02 10:19:28 --> Router Class Initialized
INFO - 2023-09-02 10:19:28 --> Output Class Initialized
INFO - 2023-09-02 10:19:28 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:28 --> Input Class Initialized
INFO - 2023-09-02 10:19:28 --> Language Class Initialized
INFO - 2023-09-02 10:19:28 --> Loader Class Initialized
INFO - 2023-09-02 10:19:28 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:28 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:28 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:28 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:28 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:28 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:28 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:28 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:28 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:28 --> Parser Class Initialized
INFO - 2023-09-02 10:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:28 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:28 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:28 --> Controller Class Initialized
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
INFO - 2023-09-02 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 10:19:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:19:28 --> Model Class Initialized
INFO - 2023-09-02 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:19:28 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:28 --> Total execution time: 0.1905
ERROR - 2023-09-02 10:19:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:38 --> Config Class Initialized
INFO - 2023-09-02 10:19:38 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:38 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:38 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:38 --> URI Class Initialized
INFO - 2023-09-02 10:19:38 --> Router Class Initialized
INFO - 2023-09-02 10:19:38 --> Output Class Initialized
INFO - 2023-09-02 10:19:38 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:38 --> Input Class Initialized
INFO - 2023-09-02 10:19:38 --> Language Class Initialized
INFO - 2023-09-02 10:19:38 --> Loader Class Initialized
INFO - 2023-09-02 10:19:38 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:38 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:38 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:38 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:38 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:38 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:38 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:38 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:38 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:38 --> Parser Class Initialized
INFO - 2023-09-02 10:19:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:38 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:38 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:38 --> Controller Class Initialized
INFO - 2023-09-02 10:19:38 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:38 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:38 --> Model Class Initialized
INFO - 2023-09-02 10:19:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:19:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:19:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:19:38 --> Model Class Initialized
INFO - 2023-09-02 10:19:38 --> Model Class Initialized
INFO - 2023-09-02 10:19:38 --> Model Class Initialized
INFO - 2023-09-02 10:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:19:39 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:39 --> Total execution time: 0.1289
ERROR - 2023-09-02 10:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:39 --> Config Class Initialized
INFO - 2023-09-02 10:19:39 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:39 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:39 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:39 --> URI Class Initialized
INFO - 2023-09-02 10:19:39 --> Router Class Initialized
INFO - 2023-09-02 10:19:39 --> Output Class Initialized
INFO - 2023-09-02 10:19:39 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:39 --> Input Class Initialized
INFO - 2023-09-02 10:19:39 --> Language Class Initialized
INFO - 2023-09-02 10:19:39 --> Loader Class Initialized
INFO - 2023-09-02 10:19:39 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:39 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:39 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:39 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:39 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:39 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:39 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:39 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:39 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:39 --> Parser Class Initialized
INFO - 2023-09-02 10:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:39 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:39 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:39 --> Controller Class Initialized
INFO - 2023-09-02 10:19:39 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:39 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:39 --> Model Class Initialized
INFO - 2023-09-02 10:19:39 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:39 --> Total execution time: 0.0516
ERROR - 2023-09-02 10:19:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:42 --> Config Class Initialized
INFO - 2023-09-02 10:19:42 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:42 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:42 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:42 --> URI Class Initialized
INFO - 2023-09-02 10:19:42 --> Router Class Initialized
INFO - 2023-09-02 10:19:42 --> Output Class Initialized
INFO - 2023-09-02 10:19:42 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:42 --> Input Class Initialized
INFO - 2023-09-02 10:19:42 --> Language Class Initialized
INFO - 2023-09-02 10:19:42 --> Loader Class Initialized
INFO - 2023-09-02 10:19:42 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:42 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:42 --> Parser Class Initialized
INFO - 2023-09-02 10:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:42 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:42 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:42 --> Controller Class Initialized
INFO - 2023-09-02 10:19:42 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:42 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:42 --> Model Class Initialized
INFO - 2023-09-02 10:19:42 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:42 --> Total execution time: 0.0544
ERROR - 2023-09-02 10:19:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:42 --> Config Class Initialized
INFO - 2023-09-02 10:19:42 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:42 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:42 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:42 --> URI Class Initialized
INFO - 2023-09-02 10:19:42 --> Router Class Initialized
INFO - 2023-09-02 10:19:42 --> Output Class Initialized
INFO - 2023-09-02 10:19:42 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:42 --> Input Class Initialized
INFO - 2023-09-02 10:19:42 --> Language Class Initialized
INFO - 2023-09-02 10:19:42 --> Loader Class Initialized
INFO - 2023-09-02 10:19:42 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:42 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:43 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:43 --> Parser Class Initialized
INFO - 2023-09-02 10:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:43 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:43 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:43 --> Controller Class Initialized
INFO - 2023-09-02 10:19:43 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:43 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:43 --> Model Class Initialized
INFO - 2023-09-02 10:19:43 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:43 --> Total execution time: 0.0535
ERROR - 2023-09-02 10:19:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:43 --> Config Class Initialized
INFO - 2023-09-02 10:19:43 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:43 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:43 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:43 --> URI Class Initialized
INFO - 2023-09-02 10:19:43 --> Router Class Initialized
INFO - 2023-09-02 10:19:43 --> Output Class Initialized
INFO - 2023-09-02 10:19:43 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:43 --> Input Class Initialized
INFO - 2023-09-02 10:19:43 --> Language Class Initialized
INFO - 2023-09-02 10:19:43 --> Loader Class Initialized
INFO - 2023-09-02 10:19:43 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:43 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:43 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:43 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:43 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:43 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:43 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:43 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:43 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:43 --> Parser Class Initialized
INFO - 2023-09-02 10:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:43 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:43 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:43 --> Controller Class Initialized
INFO - 2023-09-02 10:19:43 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:43 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:43 --> Model Class Initialized
INFO - 2023-09-02 10:19:43 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:43 --> Total execution time: 0.0365
ERROR - 2023-09-02 10:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:19:48 --> Config Class Initialized
INFO - 2023-09-02 10:19:48 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:19:48 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:19:48 --> Utf8 Class Initialized
INFO - 2023-09-02 10:19:48 --> URI Class Initialized
INFO - 2023-09-02 10:19:48 --> Router Class Initialized
INFO - 2023-09-02 10:19:48 --> Output Class Initialized
INFO - 2023-09-02 10:19:48 --> Security Class Initialized
DEBUG - 2023-09-02 10:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:19:48 --> Input Class Initialized
INFO - 2023-09-02 10:19:48 --> Language Class Initialized
INFO - 2023-09-02 10:19:48 --> Loader Class Initialized
INFO - 2023-09-02 10:19:48 --> Helper loaded: url_helper
INFO - 2023-09-02 10:19:48 --> Helper loaded: file_helper
INFO - 2023-09-02 10:19:48 --> Helper loaded: html_helper
INFO - 2023-09-02 10:19:48 --> Helper loaded: text_helper
INFO - 2023-09-02 10:19:48 --> Helper loaded: form_helper
INFO - 2023-09-02 10:19:48 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:19:48 --> Helper loaded: security_helper
INFO - 2023-09-02 10:19:48 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:19:48 --> Database Driver Class Initialized
INFO - 2023-09-02 10:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:19:48 --> Parser Class Initialized
INFO - 2023-09-02 10:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:19:48 --> Pagination Class Initialized
INFO - 2023-09-02 10:19:48 --> Form Validation Class Initialized
INFO - 2023-09-02 10:19:48 --> Controller Class Initialized
INFO - 2023-09-02 10:19:48 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:48 --> Model Class Initialized
DEBUG - 2023-09-02 10:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:19:48 --> Model Class Initialized
INFO - 2023-09-02 10:19:48 --> Final output sent to browser
DEBUG - 2023-09-02 10:19:48 --> Total execution time: 0.0365
ERROR - 2023-09-02 10:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:16 --> Config Class Initialized
INFO - 2023-09-02 10:20:16 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:16 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:16 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:16 --> URI Class Initialized
INFO - 2023-09-02 10:20:16 --> Router Class Initialized
INFO - 2023-09-02 10:20:16 --> Output Class Initialized
INFO - 2023-09-02 10:20:16 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:16 --> Input Class Initialized
INFO - 2023-09-02 10:20:16 --> Language Class Initialized
INFO - 2023-09-02 10:20:16 --> Loader Class Initialized
INFO - 2023-09-02 10:20:16 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:16 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:16 --> Parser Class Initialized
INFO - 2023-09-02 10:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:16 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:16 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:16 --> Controller Class Initialized
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
ERROR - 2023-09-02 10:20:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-09-02 10:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-09-02 10:20:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
INFO - 2023-09-02 10:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:20:16 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:16 --> Total execution time: 0.1729
ERROR - 2023-09-02 10:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:16 --> Config Class Initialized
INFO - 2023-09-02 10:20:16 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:16 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:16 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:16 --> URI Class Initialized
INFO - 2023-09-02 10:20:16 --> Router Class Initialized
INFO - 2023-09-02 10:20:16 --> Output Class Initialized
INFO - 2023-09-02 10:20:16 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:16 --> Input Class Initialized
INFO - 2023-09-02 10:20:16 --> Language Class Initialized
INFO - 2023-09-02 10:20:16 --> Loader Class Initialized
INFO - 2023-09-02 10:20:16 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:16 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:16 --> Parser Class Initialized
INFO - 2023-09-02 10:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:16 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:16 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:16 --> Controller Class Initialized
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:16 --> Total execution time: 0.0209
ERROR - 2023-09-02 10:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:16 --> Config Class Initialized
INFO - 2023-09-02 10:20:16 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:16 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:16 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:16 --> URI Class Initialized
INFO - 2023-09-02 10:20:16 --> Router Class Initialized
INFO - 2023-09-02 10:20:16 --> Output Class Initialized
INFO - 2023-09-02 10:20:16 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:16 --> Input Class Initialized
INFO - 2023-09-02 10:20:16 --> Language Class Initialized
INFO - 2023-09-02 10:20:16 --> Loader Class Initialized
INFO - 2023-09-02 10:20:16 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:16 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:16 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:16 --> Parser Class Initialized
INFO - 2023-09-02 10:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:16 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:16 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:16 --> Controller Class Initialized
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
INFO - 2023-09-02 10:20:16 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:16 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:16 --> Total execution time: 0.0223
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0207
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0296
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0367
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0478
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:17 --> Config Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:17 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> URI Class Initialized
INFO - 2023-09-02 10:20:17 --> Router Class Initialized
INFO - 2023-09-02 10:20:17 --> Output Class Initialized
INFO - 2023-09-02 10:20:17 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:17 --> Input Class Initialized
INFO - 2023-09-02 10:20:17 --> Language Class Initialized
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0448
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Loader Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0469
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0542
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0606
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0712
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0781
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.1067
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.0765
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.1008
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.1069
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.1258
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.1579
INFO - 2023-09-02 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:17 --> Parser Class Initialized
INFO - 2023-09-02 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:17 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:17 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:17 --> Controller Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
INFO - 2023-09-02 10:20:17 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:17 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:17 --> Total execution time: 0.1727
ERROR - 2023-09-02 10:20:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:34 --> Config Class Initialized
INFO - 2023-09-02 10:20:34 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:34 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:34 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:34 --> URI Class Initialized
INFO - 2023-09-02 10:20:34 --> Router Class Initialized
INFO - 2023-09-02 10:20:34 --> Output Class Initialized
INFO - 2023-09-02 10:20:34 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:34 --> Input Class Initialized
INFO - 2023-09-02 10:20:34 --> Language Class Initialized
INFO - 2023-09-02 10:20:34 --> Loader Class Initialized
INFO - 2023-09-02 10:20:34 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:34 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:34 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:34 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:34 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:34 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:34 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:34 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:34 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:34 --> Parser Class Initialized
INFO - 2023-09-02 10:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:34 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:34 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:34 --> Controller Class Initialized
INFO - 2023-09-02 10:20:34 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:34 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:34 --> Model Class Initialized
INFO - 2023-09-02 10:20:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:20:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:20:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:20:34 --> Model Class Initialized
INFO - 2023-09-02 10:20:34 --> Model Class Initialized
INFO - 2023-09-02 10:20:34 --> Model Class Initialized
INFO - 2023-09-02 10:20:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:20:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:20:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:20:34 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:34 --> Total execution time: 0.1815
ERROR - 2023-09-02 10:20:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:35 --> Config Class Initialized
INFO - 2023-09-02 10:20:35 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:35 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:35 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:35 --> URI Class Initialized
INFO - 2023-09-02 10:20:35 --> Router Class Initialized
INFO - 2023-09-02 10:20:35 --> Output Class Initialized
INFO - 2023-09-02 10:20:35 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:35 --> Input Class Initialized
INFO - 2023-09-02 10:20:35 --> Language Class Initialized
INFO - 2023-09-02 10:20:35 --> Loader Class Initialized
INFO - 2023-09-02 10:20:35 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:35 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:35 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:35 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:35 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:35 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:35 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:35 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:35 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:35 --> Parser Class Initialized
INFO - 2023-09-02 10:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:35 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:35 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:35 --> Controller Class Initialized
INFO - 2023-09-02 10:20:35 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:35 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:35 --> Model Class Initialized
INFO - 2023-09-02 10:20:35 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:35 --> Total execution time: 0.0539
ERROR - 2023-09-02 10:20:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:20:38 --> Config Class Initialized
INFO - 2023-09-02 10:20:38 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:20:38 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:20:38 --> Utf8 Class Initialized
INFO - 2023-09-02 10:20:38 --> URI Class Initialized
INFO - 2023-09-02 10:20:38 --> Router Class Initialized
INFO - 2023-09-02 10:20:38 --> Output Class Initialized
INFO - 2023-09-02 10:20:38 --> Security Class Initialized
DEBUG - 2023-09-02 10:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:20:38 --> Input Class Initialized
INFO - 2023-09-02 10:20:38 --> Language Class Initialized
INFO - 2023-09-02 10:20:38 --> Loader Class Initialized
INFO - 2023-09-02 10:20:38 --> Helper loaded: url_helper
INFO - 2023-09-02 10:20:38 --> Helper loaded: file_helper
INFO - 2023-09-02 10:20:38 --> Helper loaded: html_helper
INFO - 2023-09-02 10:20:38 --> Helper loaded: text_helper
INFO - 2023-09-02 10:20:38 --> Helper loaded: form_helper
INFO - 2023-09-02 10:20:38 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:20:38 --> Helper loaded: security_helper
INFO - 2023-09-02 10:20:38 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:20:38 --> Database Driver Class Initialized
INFO - 2023-09-02 10:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:20:38 --> Parser Class Initialized
INFO - 2023-09-02 10:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:20:38 --> Pagination Class Initialized
INFO - 2023-09-02 10:20:38 --> Form Validation Class Initialized
INFO - 2023-09-02 10:20:38 --> Controller Class Initialized
INFO - 2023-09-02 10:20:38 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:38 --> Model Class Initialized
DEBUG - 2023-09-02 10:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:20:38 --> Model Class Initialized
INFO - 2023-09-02 10:20:39 --> Final output sent to browser
DEBUG - 2023-09-02 10:20:39 --> Total execution time: 0.7042
ERROR - 2023-09-02 10:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:21:04 --> Config Class Initialized
INFO - 2023-09-02 10:21:04 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:21:04 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:21:04 --> Utf8 Class Initialized
INFO - 2023-09-02 10:21:04 --> URI Class Initialized
DEBUG - 2023-09-02 10:21:04 --> No URI present. Default controller set.
INFO - 2023-09-02 10:21:04 --> Router Class Initialized
INFO - 2023-09-02 10:21:04 --> Output Class Initialized
INFO - 2023-09-02 10:21:04 --> Security Class Initialized
DEBUG - 2023-09-02 10:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:21:04 --> Input Class Initialized
INFO - 2023-09-02 10:21:04 --> Language Class Initialized
INFO - 2023-09-02 10:21:04 --> Loader Class Initialized
INFO - 2023-09-02 10:21:04 --> Helper loaded: url_helper
INFO - 2023-09-02 10:21:04 --> Helper loaded: file_helper
INFO - 2023-09-02 10:21:04 --> Helper loaded: html_helper
INFO - 2023-09-02 10:21:04 --> Helper loaded: text_helper
INFO - 2023-09-02 10:21:04 --> Helper loaded: form_helper
INFO - 2023-09-02 10:21:04 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:21:04 --> Helper loaded: security_helper
INFO - 2023-09-02 10:21:04 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:21:04 --> Database Driver Class Initialized
INFO - 2023-09-02 10:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:21:04 --> Parser Class Initialized
INFO - 2023-09-02 10:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:21:04 --> Pagination Class Initialized
INFO - 2023-09-02 10:21:04 --> Form Validation Class Initialized
INFO - 2023-09-02 10:21:04 --> Controller Class Initialized
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
DEBUG - 2023-09-02 10:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
DEBUG - 2023-09-02 10:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
DEBUG - 2023-09-02 10:21:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
INFO - 2023-09-02 10:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 10:21:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:21:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:21:04 --> Model Class Initialized
INFO - 2023-09-02 10:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:21:05 --> Final output sent to browser
DEBUG - 2023-09-02 10:21:05 --> Total execution time: 0.2080
ERROR - 2023-09-02 10:21:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:21:19 --> Config Class Initialized
INFO - 2023-09-02 10:21:19 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:21:19 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:21:19 --> Utf8 Class Initialized
INFO - 2023-09-02 10:21:19 --> URI Class Initialized
INFO - 2023-09-02 10:21:19 --> Router Class Initialized
INFO - 2023-09-02 10:21:19 --> Output Class Initialized
INFO - 2023-09-02 10:21:19 --> Security Class Initialized
DEBUG - 2023-09-02 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:21:19 --> Input Class Initialized
INFO - 2023-09-02 10:21:19 --> Language Class Initialized
INFO - 2023-09-02 10:21:19 --> Loader Class Initialized
INFO - 2023-09-02 10:21:19 --> Helper loaded: url_helper
INFO - 2023-09-02 10:21:19 --> Helper loaded: file_helper
INFO - 2023-09-02 10:21:19 --> Helper loaded: html_helper
INFO - 2023-09-02 10:21:19 --> Helper loaded: text_helper
INFO - 2023-09-02 10:21:19 --> Helper loaded: form_helper
INFO - 2023-09-02 10:21:19 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:21:19 --> Helper loaded: security_helper
INFO - 2023-09-02 10:21:19 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:21:19 --> Database Driver Class Initialized
INFO - 2023-09-02 10:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:21:19 --> Parser Class Initialized
INFO - 2023-09-02 10:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:21:19 --> Pagination Class Initialized
INFO - 2023-09-02 10:21:19 --> Form Validation Class Initialized
INFO - 2023-09-02 10:21:19 --> Controller Class Initialized
INFO - 2023-09-02 10:21:19 --> Model Class Initialized
DEBUG - 2023-09-02 10:21:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:19 --> Model Class Initialized
DEBUG - 2023-09-02 10:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:19 --> Model Class Initialized
INFO - 2023-09-02 10:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:21:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:21:19 --> Model Class Initialized
INFO - 2023-09-02 10:21:19 --> Model Class Initialized
INFO - 2023-09-02 10:21:19 --> Model Class Initialized
INFO - 2023-09-02 10:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:21:19 --> Final output sent to browser
DEBUG - 2023-09-02 10:21:19 --> Total execution time: 0.2076
ERROR - 2023-09-02 10:21:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:21:20 --> Config Class Initialized
INFO - 2023-09-02 10:21:20 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:21:20 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:21:20 --> Utf8 Class Initialized
INFO - 2023-09-02 10:21:20 --> URI Class Initialized
INFO - 2023-09-02 10:21:20 --> Router Class Initialized
INFO - 2023-09-02 10:21:20 --> Output Class Initialized
INFO - 2023-09-02 10:21:20 --> Security Class Initialized
DEBUG - 2023-09-02 10:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:21:20 --> Input Class Initialized
INFO - 2023-09-02 10:21:20 --> Language Class Initialized
INFO - 2023-09-02 10:21:20 --> Loader Class Initialized
INFO - 2023-09-02 10:21:20 --> Helper loaded: url_helper
INFO - 2023-09-02 10:21:20 --> Helper loaded: file_helper
INFO - 2023-09-02 10:21:20 --> Helper loaded: html_helper
INFO - 2023-09-02 10:21:20 --> Helper loaded: text_helper
INFO - 2023-09-02 10:21:20 --> Helper loaded: form_helper
INFO - 2023-09-02 10:21:20 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:21:20 --> Helper loaded: security_helper
INFO - 2023-09-02 10:21:20 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:21:20 --> Database Driver Class Initialized
INFO - 2023-09-02 10:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:21:20 --> Parser Class Initialized
INFO - 2023-09-02 10:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:21:20 --> Pagination Class Initialized
INFO - 2023-09-02 10:21:20 --> Form Validation Class Initialized
INFO - 2023-09-02 10:21:20 --> Controller Class Initialized
INFO - 2023-09-02 10:21:20 --> Model Class Initialized
DEBUG - 2023-09-02 10:21:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:20 --> Model Class Initialized
DEBUG - 2023-09-02 10:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:21:20 --> Model Class Initialized
INFO - 2023-09-02 10:21:20 --> Final output sent to browser
DEBUG - 2023-09-02 10:21:20 --> Total execution time: 0.2519
ERROR - 2023-09-02 10:48:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:15 --> Config Class Initialized
INFO - 2023-09-02 10:48:15 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:15 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:15 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:15 --> URI Class Initialized
DEBUG - 2023-09-02 10:48:15 --> No URI present. Default controller set.
INFO - 2023-09-02 10:48:15 --> Router Class Initialized
INFO - 2023-09-02 10:48:15 --> Output Class Initialized
INFO - 2023-09-02 10:48:15 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:15 --> Input Class Initialized
INFO - 2023-09-02 10:48:15 --> Language Class Initialized
INFO - 2023-09-02 10:48:15 --> Loader Class Initialized
INFO - 2023-09-02 10:48:15 --> Helper loaded: url_helper
INFO - 2023-09-02 10:48:15 --> Helper loaded: file_helper
INFO - 2023-09-02 10:48:15 --> Helper loaded: html_helper
INFO - 2023-09-02 10:48:15 --> Helper loaded: text_helper
INFO - 2023-09-02 10:48:15 --> Helper loaded: form_helper
INFO - 2023-09-02 10:48:15 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:48:15 --> Helper loaded: security_helper
INFO - 2023-09-02 10:48:15 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:48:15 --> Database Driver Class Initialized
INFO - 2023-09-02 10:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:48:15 --> Parser Class Initialized
INFO - 2023-09-02 10:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:48:15 --> Pagination Class Initialized
INFO - 2023-09-02 10:48:15 --> Form Validation Class Initialized
INFO - 2023-09-02 10:48:15 --> Controller Class Initialized
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
INFO - 2023-09-02 10:48:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 10:48:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:48:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:48:15 --> Model Class Initialized
INFO - 2023-09-02 10:48:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:48:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:48:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:48:15 --> Final output sent to browser
DEBUG - 2023-09-02 10:48:15 --> Total execution time: 0.1902
ERROR - 2023-09-02 10:48:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:33 --> Config Class Initialized
INFO - 2023-09-02 10:48:33 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:33 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:33 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:33 --> URI Class Initialized
DEBUG - 2023-09-02 10:48:33 --> No URI present. Default controller set.
INFO - 2023-09-02 10:48:33 --> Router Class Initialized
INFO - 2023-09-02 10:48:33 --> Output Class Initialized
INFO - 2023-09-02 10:48:33 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:33 --> Input Class Initialized
INFO - 2023-09-02 10:48:33 --> Language Class Initialized
INFO - 2023-09-02 10:48:33 --> Loader Class Initialized
INFO - 2023-09-02 10:48:33 --> Helper loaded: url_helper
INFO - 2023-09-02 10:48:33 --> Helper loaded: file_helper
INFO - 2023-09-02 10:48:33 --> Helper loaded: html_helper
INFO - 2023-09-02 10:48:33 --> Helper loaded: text_helper
INFO - 2023-09-02 10:48:33 --> Helper loaded: form_helper
INFO - 2023-09-02 10:48:33 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:48:33 --> Helper loaded: security_helper
INFO - 2023-09-02 10:48:33 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:48:33 --> Database Driver Class Initialized
INFO - 2023-09-02 10:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:48:33 --> Parser Class Initialized
INFO - 2023-09-02 10:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:48:33 --> Pagination Class Initialized
INFO - 2023-09-02 10:48:33 --> Form Validation Class Initialized
INFO - 2023-09-02 10:48:33 --> Controller Class Initialized
INFO - 2023-09-02 10:48:33 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 10:48:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:34 --> Config Class Initialized
INFO - 2023-09-02 10:48:34 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:34 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:34 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:34 --> URI Class Initialized
INFO - 2023-09-02 10:48:34 --> Router Class Initialized
INFO - 2023-09-02 10:48:34 --> Output Class Initialized
INFO - 2023-09-02 10:48:34 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:34 --> Input Class Initialized
INFO - 2023-09-02 10:48:34 --> Language Class Initialized
INFO - 2023-09-02 10:48:34 --> Loader Class Initialized
INFO - 2023-09-02 10:48:34 --> Helper loaded: url_helper
INFO - 2023-09-02 10:48:34 --> Helper loaded: file_helper
INFO - 2023-09-02 10:48:34 --> Helper loaded: html_helper
INFO - 2023-09-02 10:48:34 --> Helper loaded: text_helper
INFO - 2023-09-02 10:48:34 --> Helper loaded: form_helper
INFO - 2023-09-02 10:48:34 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:48:34 --> Helper loaded: security_helper
INFO - 2023-09-02 10:48:34 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:48:34 --> Database Driver Class Initialized
INFO - 2023-09-02 10:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:48:34 --> Parser Class Initialized
INFO - 2023-09-02 10:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:48:34 --> Pagination Class Initialized
INFO - 2023-09-02 10:48:34 --> Form Validation Class Initialized
INFO - 2023-09-02 10:48:34 --> Controller Class Initialized
INFO - 2023-09-02 10:48:34 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 10:48:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:48:34 --> Model Class Initialized
INFO - 2023-09-02 10:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:48:34 --> Final output sent to browser
DEBUG - 2023-09-02 10:48:34 --> Total execution time: 0.0285
ERROR - 2023-09-02 10:48:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:35 --> Config Class Initialized
INFO - 2023-09-02 10:48:35 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:35 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:35 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:35 --> URI Class Initialized
INFO - 2023-09-02 10:48:35 --> Router Class Initialized
INFO - 2023-09-02 10:48:35 --> Output Class Initialized
INFO - 2023-09-02 10:48:35 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:35 --> Input Class Initialized
INFO - 2023-09-02 10:48:35 --> Language Class Initialized
ERROR - 2023-09-02 10:48:35 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-09-02 10:48:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:35 --> Config Class Initialized
INFO - 2023-09-02 10:48:35 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:35 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:35 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:35 --> URI Class Initialized
INFO - 2023-09-02 10:48:35 --> Router Class Initialized
INFO - 2023-09-02 10:48:35 --> Output Class Initialized
INFO - 2023-09-02 10:48:35 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:35 --> Input Class Initialized
INFO - 2023-09-02 10:48:35 --> Language Class Initialized
ERROR - 2023-09-02 10:48:35 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-09-02 10:48:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:38 --> Config Class Initialized
INFO - 2023-09-02 10:48:38 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:38 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:38 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:38 --> URI Class Initialized
INFO - 2023-09-02 10:48:38 --> Router Class Initialized
INFO - 2023-09-02 10:48:38 --> Output Class Initialized
INFO - 2023-09-02 10:48:38 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:38 --> Input Class Initialized
INFO - 2023-09-02 10:48:38 --> Language Class Initialized
INFO - 2023-09-02 10:48:38 --> Loader Class Initialized
INFO - 2023-09-02 10:48:38 --> Helper loaded: url_helper
INFO - 2023-09-02 10:48:38 --> Helper loaded: file_helper
INFO - 2023-09-02 10:48:38 --> Helper loaded: html_helper
INFO - 2023-09-02 10:48:38 --> Helper loaded: text_helper
INFO - 2023-09-02 10:48:38 --> Helper loaded: form_helper
INFO - 2023-09-02 10:48:38 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:48:38 --> Helper loaded: security_helper
INFO - 2023-09-02 10:48:38 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:48:38 --> Database Driver Class Initialized
INFO - 2023-09-02 10:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:48:38 --> Parser Class Initialized
INFO - 2023-09-02 10:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:48:38 --> Pagination Class Initialized
INFO - 2023-09-02 10:48:38 --> Form Validation Class Initialized
INFO - 2023-09-02 10:48:38 --> Controller Class Initialized
INFO - 2023-09-02 10:48:38 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:38 --> Model Class Initialized
INFO - 2023-09-02 10:48:38 --> Final output sent to browser
DEBUG - 2023-09-02 10:48:38 --> Total execution time: 0.0184
ERROR - 2023-09-02 10:48:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:39 --> Config Class Initialized
INFO - 2023-09-02 10:48:39 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:39 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:39 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:39 --> URI Class Initialized
DEBUG - 2023-09-02 10:48:39 --> No URI present. Default controller set.
INFO - 2023-09-02 10:48:39 --> Router Class Initialized
INFO - 2023-09-02 10:48:39 --> Output Class Initialized
INFO - 2023-09-02 10:48:39 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:39 --> Input Class Initialized
INFO - 2023-09-02 10:48:39 --> Language Class Initialized
INFO - 2023-09-02 10:48:39 --> Loader Class Initialized
INFO - 2023-09-02 10:48:39 --> Helper loaded: url_helper
INFO - 2023-09-02 10:48:39 --> Helper loaded: file_helper
INFO - 2023-09-02 10:48:39 --> Helper loaded: html_helper
INFO - 2023-09-02 10:48:39 --> Helper loaded: text_helper
INFO - 2023-09-02 10:48:39 --> Helper loaded: form_helper
INFO - 2023-09-02 10:48:39 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:48:39 --> Helper loaded: security_helper
INFO - 2023-09-02 10:48:39 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:48:39 --> Database Driver Class Initialized
INFO - 2023-09-02 10:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:48:39 --> Parser Class Initialized
INFO - 2023-09-02 10:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:48:39 --> Pagination Class Initialized
INFO - 2023-09-02 10:48:39 --> Form Validation Class Initialized
INFO - 2023-09-02 10:48:39 --> Controller Class Initialized
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
INFO - 2023-09-02 10:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 10:48:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:48:39 --> Model Class Initialized
INFO - 2023-09-02 10:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:48:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:48:39 --> Final output sent to browser
DEBUG - 2023-09-02 10:48:39 --> Total execution time: 0.0908
ERROR - 2023-09-02 10:48:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:43 --> Config Class Initialized
INFO - 2023-09-02 10:48:43 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:43 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:43 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:43 --> URI Class Initialized
INFO - 2023-09-02 10:48:43 --> Router Class Initialized
INFO - 2023-09-02 10:48:43 --> Output Class Initialized
INFO - 2023-09-02 10:48:43 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:43 --> Input Class Initialized
INFO - 2023-09-02 10:48:43 --> Language Class Initialized
INFO - 2023-09-02 10:48:43 --> Loader Class Initialized
INFO - 2023-09-02 10:48:43 --> Helper loaded: url_helper
INFO - 2023-09-02 10:48:43 --> Helper loaded: file_helper
INFO - 2023-09-02 10:48:43 --> Helper loaded: html_helper
INFO - 2023-09-02 10:48:43 --> Helper loaded: text_helper
INFO - 2023-09-02 10:48:43 --> Helper loaded: form_helper
INFO - 2023-09-02 10:48:43 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:48:43 --> Helper loaded: security_helper
INFO - 2023-09-02 10:48:43 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:48:43 --> Database Driver Class Initialized
INFO - 2023-09-02 10:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:48:43 --> Parser Class Initialized
INFO - 2023-09-02 10:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:48:43 --> Pagination Class Initialized
INFO - 2023-09-02 10:48:43 --> Form Validation Class Initialized
INFO - 2023-09-02 10:48:43 --> Controller Class Initialized
INFO - 2023-09-02 10:48:43 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:43 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:43 --> Model Class Initialized
INFO - 2023-09-02 10:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 10:48:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 10:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 10:48:43 --> Model Class Initialized
INFO - 2023-09-02 10:48:43 --> Model Class Initialized
INFO - 2023-09-02 10:48:43 --> Model Class Initialized
INFO - 2023-09-02 10:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 10:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 10:48:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 10:48:43 --> Final output sent to browser
DEBUG - 2023-09-02 10:48:43 --> Total execution time: 0.0877
ERROR - 2023-09-02 10:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 10:48:44 --> Config Class Initialized
INFO - 2023-09-02 10:48:44 --> Hooks Class Initialized
DEBUG - 2023-09-02 10:48:44 --> UTF-8 Support Enabled
INFO - 2023-09-02 10:48:44 --> Utf8 Class Initialized
INFO - 2023-09-02 10:48:44 --> URI Class Initialized
INFO - 2023-09-02 10:48:44 --> Router Class Initialized
INFO - 2023-09-02 10:48:44 --> Output Class Initialized
INFO - 2023-09-02 10:48:44 --> Security Class Initialized
DEBUG - 2023-09-02 10:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 10:48:44 --> Input Class Initialized
INFO - 2023-09-02 10:48:44 --> Language Class Initialized
INFO - 2023-09-02 10:48:44 --> Loader Class Initialized
INFO - 2023-09-02 10:48:44 --> Helper loaded: url_helper
INFO - 2023-09-02 10:48:44 --> Helper loaded: file_helper
INFO - 2023-09-02 10:48:44 --> Helper loaded: html_helper
INFO - 2023-09-02 10:48:44 --> Helper loaded: text_helper
INFO - 2023-09-02 10:48:44 --> Helper loaded: form_helper
INFO - 2023-09-02 10:48:44 --> Helper loaded: lang_helper
INFO - 2023-09-02 10:48:44 --> Helper loaded: security_helper
INFO - 2023-09-02 10:48:44 --> Helper loaded: cookie_helper
INFO - 2023-09-02 10:48:44 --> Database Driver Class Initialized
INFO - 2023-09-02 10:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 10:48:44 --> Parser Class Initialized
INFO - 2023-09-02 10:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 10:48:44 --> Pagination Class Initialized
INFO - 2023-09-02 10:48:44 --> Form Validation Class Initialized
INFO - 2023-09-02 10:48:44 --> Controller Class Initialized
INFO - 2023-09-02 10:48:44 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 10:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:44 --> Model Class Initialized
DEBUG - 2023-09-02 10:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 10:48:44 --> Model Class Initialized
INFO - 2023-09-02 10:48:44 --> Final output sent to browser
DEBUG - 2023-09-02 10:48:44 --> Total execution time: 0.0408
ERROR - 2023-09-02 11:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:11:01 --> Config Class Initialized
INFO - 2023-09-02 11:11:01 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:11:01 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:11:01 --> Utf8 Class Initialized
INFO - 2023-09-02 11:11:01 --> URI Class Initialized
DEBUG - 2023-09-02 11:11:01 --> No URI present. Default controller set.
INFO - 2023-09-02 11:11:01 --> Router Class Initialized
INFO - 2023-09-02 11:11:01 --> Output Class Initialized
INFO - 2023-09-02 11:11:01 --> Security Class Initialized
DEBUG - 2023-09-02 11:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:11:01 --> Input Class Initialized
INFO - 2023-09-02 11:11:01 --> Language Class Initialized
INFO - 2023-09-02 11:11:01 --> Loader Class Initialized
INFO - 2023-09-02 11:11:01 --> Helper loaded: url_helper
INFO - 2023-09-02 11:11:01 --> Helper loaded: file_helper
INFO - 2023-09-02 11:11:01 --> Helper loaded: html_helper
INFO - 2023-09-02 11:11:01 --> Helper loaded: text_helper
INFO - 2023-09-02 11:11:01 --> Helper loaded: form_helper
INFO - 2023-09-02 11:11:01 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:11:01 --> Helper loaded: security_helper
INFO - 2023-09-02 11:11:01 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:11:01 --> Database Driver Class Initialized
INFO - 2023-09-02 11:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:11:01 --> Parser Class Initialized
INFO - 2023-09-02 11:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:11:01 --> Pagination Class Initialized
INFO - 2023-09-02 11:11:01 --> Form Validation Class Initialized
INFO - 2023-09-02 11:11:01 --> Controller Class Initialized
INFO - 2023-09-02 11:11:01 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 11:11:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:11:02 --> Config Class Initialized
INFO - 2023-09-02 11:11:02 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:11:02 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:11:02 --> Utf8 Class Initialized
INFO - 2023-09-02 11:11:02 --> URI Class Initialized
INFO - 2023-09-02 11:11:02 --> Router Class Initialized
INFO - 2023-09-02 11:11:02 --> Output Class Initialized
INFO - 2023-09-02 11:11:02 --> Security Class Initialized
DEBUG - 2023-09-02 11:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:11:02 --> Input Class Initialized
INFO - 2023-09-02 11:11:02 --> Language Class Initialized
INFO - 2023-09-02 11:11:02 --> Loader Class Initialized
INFO - 2023-09-02 11:11:02 --> Helper loaded: url_helper
INFO - 2023-09-02 11:11:02 --> Helper loaded: file_helper
INFO - 2023-09-02 11:11:02 --> Helper loaded: html_helper
INFO - 2023-09-02 11:11:02 --> Helper loaded: text_helper
INFO - 2023-09-02 11:11:02 --> Helper loaded: form_helper
INFO - 2023-09-02 11:11:02 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:11:02 --> Helper loaded: security_helper
INFO - 2023-09-02 11:11:02 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:11:02 --> Database Driver Class Initialized
INFO - 2023-09-02 11:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:11:02 --> Parser Class Initialized
INFO - 2023-09-02 11:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:11:02 --> Pagination Class Initialized
INFO - 2023-09-02 11:11:02 --> Form Validation Class Initialized
INFO - 2023-09-02 11:11:02 --> Controller Class Initialized
INFO - 2023-09-02 11:11:02 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 11:11:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 11:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 11:11:02 --> Model Class Initialized
INFO - 2023-09-02 11:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 11:11:02 --> Final output sent to browser
DEBUG - 2023-09-02 11:11:02 --> Total execution time: 0.0311
ERROR - 2023-09-02 11:11:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:11:31 --> Config Class Initialized
INFO - 2023-09-02 11:11:31 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:11:31 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:11:31 --> Utf8 Class Initialized
INFO - 2023-09-02 11:11:31 --> URI Class Initialized
INFO - 2023-09-02 11:11:31 --> Router Class Initialized
INFO - 2023-09-02 11:11:31 --> Output Class Initialized
INFO - 2023-09-02 11:11:31 --> Security Class Initialized
DEBUG - 2023-09-02 11:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:11:31 --> Input Class Initialized
INFO - 2023-09-02 11:11:31 --> Language Class Initialized
INFO - 2023-09-02 11:11:31 --> Loader Class Initialized
INFO - 2023-09-02 11:11:31 --> Helper loaded: url_helper
INFO - 2023-09-02 11:11:31 --> Helper loaded: file_helper
INFO - 2023-09-02 11:11:31 --> Helper loaded: html_helper
INFO - 2023-09-02 11:11:31 --> Helper loaded: text_helper
INFO - 2023-09-02 11:11:31 --> Helper loaded: form_helper
INFO - 2023-09-02 11:11:31 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:11:31 --> Helper loaded: security_helper
INFO - 2023-09-02 11:11:31 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:11:31 --> Database Driver Class Initialized
INFO - 2023-09-02 11:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:11:31 --> Parser Class Initialized
INFO - 2023-09-02 11:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:11:31 --> Pagination Class Initialized
INFO - 2023-09-02 11:11:31 --> Form Validation Class Initialized
INFO - 2023-09-02 11:11:31 --> Controller Class Initialized
INFO - 2023-09-02 11:11:31 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:31 --> Model Class Initialized
INFO - 2023-09-02 11:11:31 --> Final output sent to browser
DEBUG - 2023-09-02 11:11:31 --> Total execution time: 0.0205
ERROR - 2023-09-02 11:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:11:32 --> Config Class Initialized
INFO - 2023-09-02 11:11:32 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:11:32 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:11:32 --> Utf8 Class Initialized
INFO - 2023-09-02 11:11:32 --> URI Class Initialized
DEBUG - 2023-09-02 11:11:32 --> No URI present. Default controller set.
INFO - 2023-09-02 11:11:32 --> Router Class Initialized
INFO - 2023-09-02 11:11:32 --> Output Class Initialized
INFO - 2023-09-02 11:11:32 --> Security Class Initialized
DEBUG - 2023-09-02 11:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:11:32 --> Input Class Initialized
INFO - 2023-09-02 11:11:32 --> Language Class Initialized
INFO - 2023-09-02 11:11:32 --> Loader Class Initialized
INFO - 2023-09-02 11:11:32 --> Helper loaded: url_helper
INFO - 2023-09-02 11:11:32 --> Helper loaded: file_helper
INFO - 2023-09-02 11:11:32 --> Helper loaded: html_helper
INFO - 2023-09-02 11:11:32 --> Helper loaded: text_helper
INFO - 2023-09-02 11:11:32 --> Helper loaded: form_helper
INFO - 2023-09-02 11:11:32 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:11:32 --> Helper loaded: security_helper
INFO - 2023-09-02 11:11:32 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:11:32 --> Database Driver Class Initialized
INFO - 2023-09-02 11:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:11:32 --> Parser Class Initialized
INFO - 2023-09-02 11:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:11:32 --> Pagination Class Initialized
INFO - 2023-09-02 11:11:32 --> Form Validation Class Initialized
INFO - 2023-09-02 11:11:32 --> Controller Class Initialized
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
INFO - 2023-09-02 11:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 11:11:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 11:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 11:11:32 --> Model Class Initialized
INFO - 2023-09-02 11:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 11:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 11:11:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 11:11:32 --> Final output sent to browser
DEBUG - 2023-09-02 11:11:32 --> Total execution time: 0.0962
ERROR - 2023-09-02 11:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:11:37 --> Config Class Initialized
INFO - 2023-09-02 11:11:37 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:11:37 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:11:37 --> Utf8 Class Initialized
INFO - 2023-09-02 11:11:37 --> URI Class Initialized
INFO - 2023-09-02 11:11:37 --> Router Class Initialized
INFO - 2023-09-02 11:11:37 --> Output Class Initialized
INFO - 2023-09-02 11:11:37 --> Security Class Initialized
DEBUG - 2023-09-02 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:11:37 --> Input Class Initialized
INFO - 2023-09-02 11:11:37 --> Language Class Initialized
INFO - 2023-09-02 11:11:37 --> Loader Class Initialized
INFO - 2023-09-02 11:11:37 --> Helper loaded: url_helper
INFO - 2023-09-02 11:11:37 --> Helper loaded: file_helper
INFO - 2023-09-02 11:11:37 --> Helper loaded: html_helper
INFO - 2023-09-02 11:11:37 --> Helper loaded: text_helper
INFO - 2023-09-02 11:11:37 --> Helper loaded: form_helper
INFO - 2023-09-02 11:11:37 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:11:37 --> Helper loaded: security_helper
INFO - 2023-09-02 11:11:37 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:11:37 --> Database Driver Class Initialized
INFO - 2023-09-02 11:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:11:37 --> Parser Class Initialized
INFO - 2023-09-02 11:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:11:37 --> Pagination Class Initialized
INFO - 2023-09-02 11:11:37 --> Form Validation Class Initialized
INFO - 2023-09-02 11:11:37 --> Controller Class Initialized
INFO - 2023-09-02 11:11:37 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:37 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:37 --> Model Class Initialized
INFO - 2023-09-02 11:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 11:11:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 11:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 11:11:37 --> Model Class Initialized
INFO - 2023-09-02 11:11:37 --> Model Class Initialized
INFO - 2023-09-02 11:11:37 --> Model Class Initialized
INFO - 2023-09-02 11:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 11:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 11:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 11:11:37 --> Final output sent to browser
DEBUG - 2023-09-02 11:11:37 --> Total execution time: 0.0757
ERROR - 2023-09-02 11:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:11:38 --> Config Class Initialized
INFO - 2023-09-02 11:11:38 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:11:38 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:11:38 --> Utf8 Class Initialized
INFO - 2023-09-02 11:11:38 --> URI Class Initialized
INFO - 2023-09-02 11:11:38 --> Router Class Initialized
INFO - 2023-09-02 11:11:38 --> Output Class Initialized
INFO - 2023-09-02 11:11:38 --> Security Class Initialized
DEBUG - 2023-09-02 11:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:11:38 --> Input Class Initialized
INFO - 2023-09-02 11:11:38 --> Language Class Initialized
INFO - 2023-09-02 11:11:38 --> Loader Class Initialized
INFO - 2023-09-02 11:11:38 --> Helper loaded: url_helper
INFO - 2023-09-02 11:11:38 --> Helper loaded: file_helper
INFO - 2023-09-02 11:11:38 --> Helper loaded: html_helper
INFO - 2023-09-02 11:11:38 --> Helper loaded: text_helper
INFO - 2023-09-02 11:11:38 --> Helper loaded: form_helper
INFO - 2023-09-02 11:11:38 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:11:38 --> Helper loaded: security_helper
INFO - 2023-09-02 11:11:38 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:11:38 --> Database Driver Class Initialized
INFO - 2023-09-02 11:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:11:38 --> Parser Class Initialized
INFO - 2023-09-02 11:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:11:38 --> Pagination Class Initialized
INFO - 2023-09-02 11:11:38 --> Form Validation Class Initialized
INFO - 2023-09-02 11:11:38 --> Controller Class Initialized
INFO - 2023-09-02 11:11:38 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:38 --> Model Class Initialized
DEBUG - 2023-09-02 11:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:11:38 --> Model Class Initialized
INFO - 2023-09-02 11:11:38 --> Final output sent to browser
DEBUG - 2023-09-02 11:11:38 --> Total execution time: 0.0353
ERROR - 2023-09-02 11:12:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:12:20 --> Config Class Initialized
INFO - 2023-09-02 11:12:20 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:12:20 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:12:20 --> Utf8 Class Initialized
INFO - 2023-09-02 11:12:20 --> URI Class Initialized
INFO - 2023-09-02 11:12:20 --> Router Class Initialized
INFO - 2023-09-02 11:12:20 --> Output Class Initialized
INFO - 2023-09-02 11:12:20 --> Security Class Initialized
DEBUG - 2023-09-02 11:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:12:20 --> Input Class Initialized
INFO - 2023-09-02 11:12:20 --> Language Class Initialized
INFO - 2023-09-02 11:12:20 --> Loader Class Initialized
INFO - 2023-09-02 11:12:20 --> Helper loaded: url_helper
INFO - 2023-09-02 11:12:20 --> Helper loaded: file_helper
INFO - 2023-09-02 11:12:20 --> Helper loaded: html_helper
INFO - 2023-09-02 11:12:20 --> Helper loaded: text_helper
INFO - 2023-09-02 11:12:20 --> Helper loaded: form_helper
INFO - 2023-09-02 11:12:20 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:12:20 --> Helper loaded: security_helper
INFO - 2023-09-02 11:12:20 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:12:20 --> Database Driver Class Initialized
INFO - 2023-09-02 11:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:12:20 --> Parser Class Initialized
INFO - 2023-09-02 11:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:12:20 --> Pagination Class Initialized
INFO - 2023-09-02 11:12:20 --> Form Validation Class Initialized
INFO - 2023-09-02 11:12:20 --> Controller Class Initialized
INFO - 2023-09-02 11:12:20 --> Model Class Initialized
DEBUG - 2023-09-02 11:12:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:12:20 --> Model Class Initialized
DEBUG - 2023-09-02 11:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:12:20 --> Model Class Initialized
INFO - 2023-09-02 11:12:20 --> Final output sent to browser
DEBUG - 2023-09-02 11:12:20 --> Total execution time: 0.0403
ERROR - 2023-09-02 11:12:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:12:23 --> Config Class Initialized
INFO - 2023-09-02 11:12:23 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:12:23 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:12:23 --> Utf8 Class Initialized
INFO - 2023-09-02 11:12:23 --> URI Class Initialized
INFO - 2023-09-02 11:12:23 --> Router Class Initialized
INFO - 2023-09-02 11:12:23 --> Output Class Initialized
INFO - 2023-09-02 11:12:23 --> Security Class Initialized
DEBUG - 2023-09-02 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:12:23 --> Input Class Initialized
INFO - 2023-09-02 11:12:23 --> Language Class Initialized
INFO - 2023-09-02 11:12:23 --> Loader Class Initialized
INFO - 2023-09-02 11:12:23 --> Helper loaded: url_helper
INFO - 2023-09-02 11:12:23 --> Helper loaded: file_helper
INFO - 2023-09-02 11:12:23 --> Helper loaded: html_helper
INFO - 2023-09-02 11:12:23 --> Helper loaded: text_helper
INFO - 2023-09-02 11:12:23 --> Helper loaded: form_helper
INFO - 2023-09-02 11:12:23 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:12:23 --> Helper loaded: security_helper
INFO - 2023-09-02 11:12:23 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:12:23 --> Database Driver Class Initialized
INFO - 2023-09-02 11:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:12:24 --> Parser Class Initialized
INFO - 2023-09-02 11:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:12:24 --> Pagination Class Initialized
INFO - 2023-09-02 11:12:24 --> Form Validation Class Initialized
INFO - 2023-09-02 11:12:24 --> Controller Class Initialized
INFO - 2023-09-02 11:12:24 --> Model Class Initialized
DEBUG - 2023-09-02 11:12:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:12:24 --> Model Class Initialized
DEBUG - 2023-09-02 11:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:12:24 --> Model Class Initialized
INFO - 2023-09-02 11:12:24 --> Final output sent to browser
DEBUG - 2023-09-02 11:12:24 --> Total execution time: 0.0337
ERROR - 2023-09-02 11:18:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:18:24 --> Config Class Initialized
INFO - 2023-09-02 11:18:24 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:18:24 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:18:24 --> Utf8 Class Initialized
INFO - 2023-09-02 11:18:24 --> URI Class Initialized
INFO - 2023-09-02 11:18:24 --> Router Class Initialized
INFO - 2023-09-02 11:18:24 --> Output Class Initialized
INFO - 2023-09-02 11:18:24 --> Security Class Initialized
DEBUG - 2023-09-02 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:18:24 --> Input Class Initialized
INFO - 2023-09-02 11:18:24 --> Language Class Initialized
INFO - 2023-09-02 11:18:24 --> Loader Class Initialized
INFO - 2023-09-02 11:18:24 --> Helper loaded: url_helper
INFO - 2023-09-02 11:18:24 --> Helper loaded: file_helper
INFO - 2023-09-02 11:18:24 --> Helper loaded: html_helper
INFO - 2023-09-02 11:18:24 --> Helper loaded: text_helper
INFO - 2023-09-02 11:18:24 --> Helper loaded: form_helper
INFO - 2023-09-02 11:18:24 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:18:24 --> Helper loaded: security_helper
INFO - 2023-09-02 11:18:24 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:18:24 --> Database Driver Class Initialized
INFO - 2023-09-02 11:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:18:24 --> Parser Class Initialized
INFO - 2023-09-02 11:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:18:24 --> Pagination Class Initialized
INFO - 2023-09-02 11:18:24 --> Form Validation Class Initialized
INFO - 2023-09-02 11:18:24 --> Controller Class Initialized
INFO - 2023-09-02 11:18:24 --> Model Class Initialized
DEBUG - 2023-09-02 11:18:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:18:24 --> Model Class Initialized
DEBUG - 2023-09-02 11:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:18:24 --> Model Class Initialized
INFO - 2023-09-02 11:18:24 --> Final output sent to browser
DEBUG - 2023-09-02 11:18:24 --> Total execution time: 0.0373
ERROR - 2023-09-02 11:18:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:18:47 --> Config Class Initialized
INFO - 2023-09-02 11:18:47 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:18:47 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:18:47 --> Utf8 Class Initialized
INFO - 2023-09-02 11:18:47 --> URI Class Initialized
INFO - 2023-09-02 11:18:47 --> Router Class Initialized
INFO - 2023-09-02 11:18:47 --> Output Class Initialized
INFO - 2023-09-02 11:18:47 --> Security Class Initialized
DEBUG - 2023-09-02 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:18:47 --> Input Class Initialized
INFO - 2023-09-02 11:18:47 --> Language Class Initialized
INFO - 2023-09-02 11:18:47 --> Loader Class Initialized
INFO - 2023-09-02 11:18:47 --> Helper loaded: url_helper
INFO - 2023-09-02 11:18:47 --> Helper loaded: file_helper
INFO - 2023-09-02 11:18:47 --> Helper loaded: html_helper
INFO - 2023-09-02 11:18:47 --> Helper loaded: text_helper
INFO - 2023-09-02 11:18:47 --> Helper loaded: form_helper
INFO - 2023-09-02 11:18:47 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:18:47 --> Helper loaded: security_helper
INFO - 2023-09-02 11:18:47 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:18:47 --> Database Driver Class Initialized
INFO - 2023-09-02 11:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:18:47 --> Parser Class Initialized
INFO - 2023-09-02 11:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:18:47 --> Pagination Class Initialized
INFO - 2023-09-02 11:18:47 --> Form Validation Class Initialized
INFO - 2023-09-02 11:18:47 --> Controller Class Initialized
INFO - 2023-09-02 11:18:47 --> Model Class Initialized
DEBUG - 2023-09-02 11:18:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:18:47 --> Model Class Initialized
DEBUG - 2023-09-02 11:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:18:47 --> Model Class Initialized
INFO - 2023-09-02 11:18:47 --> Final output sent to browser
DEBUG - 2023-09-02 11:18:47 --> Total execution time: 0.0413
ERROR - 2023-09-02 11:18:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:18:52 --> Config Class Initialized
INFO - 2023-09-02 11:18:52 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:18:52 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:18:52 --> Utf8 Class Initialized
INFO - 2023-09-02 11:18:52 --> URI Class Initialized
INFO - 2023-09-02 11:18:52 --> Router Class Initialized
INFO - 2023-09-02 11:18:52 --> Output Class Initialized
INFO - 2023-09-02 11:18:52 --> Security Class Initialized
DEBUG - 2023-09-02 11:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:18:52 --> Input Class Initialized
INFO - 2023-09-02 11:18:52 --> Language Class Initialized
INFO - 2023-09-02 11:18:52 --> Loader Class Initialized
INFO - 2023-09-02 11:18:52 --> Helper loaded: url_helper
INFO - 2023-09-02 11:18:52 --> Helper loaded: file_helper
INFO - 2023-09-02 11:18:52 --> Helper loaded: html_helper
INFO - 2023-09-02 11:18:52 --> Helper loaded: text_helper
INFO - 2023-09-02 11:18:52 --> Helper loaded: form_helper
INFO - 2023-09-02 11:18:52 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:18:52 --> Helper loaded: security_helper
INFO - 2023-09-02 11:18:52 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:18:52 --> Database Driver Class Initialized
INFO - 2023-09-02 11:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:18:52 --> Parser Class Initialized
INFO - 2023-09-02 11:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:18:52 --> Pagination Class Initialized
INFO - 2023-09-02 11:18:52 --> Form Validation Class Initialized
INFO - 2023-09-02 11:18:52 --> Controller Class Initialized
INFO - 2023-09-02 11:18:52 --> Model Class Initialized
DEBUG - 2023-09-02 11:18:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:18:52 --> Model Class Initialized
DEBUG - 2023-09-02 11:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:18:52 --> Model Class Initialized
INFO - 2023-09-02 11:18:52 --> Final output sent to browser
DEBUG - 2023-09-02 11:18:52 --> Total execution time: 0.1865
ERROR - 2023-09-02 11:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 11:20:06 --> Config Class Initialized
INFO - 2023-09-02 11:20:06 --> Hooks Class Initialized
DEBUG - 2023-09-02 11:20:06 --> UTF-8 Support Enabled
INFO - 2023-09-02 11:20:06 --> Utf8 Class Initialized
INFO - 2023-09-02 11:20:06 --> URI Class Initialized
INFO - 2023-09-02 11:20:06 --> Router Class Initialized
INFO - 2023-09-02 11:20:06 --> Output Class Initialized
INFO - 2023-09-02 11:20:06 --> Security Class Initialized
DEBUG - 2023-09-02 11:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 11:20:06 --> Input Class Initialized
INFO - 2023-09-02 11:20:06 --> Language Class Initialized
INFO - 2023-09-02 11:20:06 --> Loader Class Initialized
INFO - 2023-09-02 11:20:06 --> Helper loaded: url_helper
INFO - 2023-09-02 11:20:06 --> Helper loaded: file_helper
INFO - 2023-09-02 11:20:06 --> Helper loaded: html_helper
INFO - 2023-09-02 11:20:06 --> Helper loaded: text_helper
INFO - 2023-09-02 11:20:06 --> Helper loaded: form_helper
INFO - 2023-09-02 11:20:06 --> Helper loaded: lang_helper
INFO - 2023-09-02 11:20:06 --> Helper loaded: security_helper
INFO - 2023-09-02 11:20:06 --> Helper loaded: cookie_helper
INFO - 2023-09-02 11:20:06 --> Database Driver Class Initialized
INFO - 2023-09-02 11:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 11:20:06 --> Parser Class Initialized
INFO - 2023-09-02 11:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 11:20:06 --> Pagination Class Initialized
INFO - 2023-09-02 11:20:06 --> Form Validation Class Initialized
INFO - 2023-09-02 11:20:06 --> Controller Class Initialized
INFO - 2023-09-02 11:20:06 --> Model Class Initialized
DEBUG - 2023-09-02 11:20:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 11:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:20:06 --> Model Class Initialized
DEBUG - 2023-09-02 11:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 11:20:06 --> Model Class Initialized
INFO - 2023-09-02 11:20:06 --> Final output sent to browser
DEBUG - 2023-09-02 11:20:06 --> Total execution time: 0.0697
ERROR - 2023-09-02 13:46:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 13:46:26 --> Config Class Initialized
INFO - 2023-09-02 13:46:26 --> Hooks Class Initialized
DEBUG - 2023-09-02 13:46:26 --> UTF-8 Support Enabled
INFO - 2023-09-02 13:46:26 --> Utf8 Class Initialized
INFO - 2023-09-02 13:46:26 --> URI Class Initialized
DEBUG - 2023-09-02 13:46:26 --> No URI present. Default controller set.
INFO - 2023-09-02 13:46:26 --> Router Class Initialized
INFO - 2023-09-02 13:46:26 --> Output Class Initialized
INFO - 2023-09-02 13:46:26 --> Security Class Initialized
DEBUG - 2023-09-02 13:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 13:46:26 --> Input Class Initialized
INFO - 2023-09-02 13:46:26 --> Language Class Initialized
INFO - 2023-09-02 13:46:26 --> Loader Class Initialized
INFO - 2023-09-02 13:46:26 --> Helper loaded: url_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: file_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: html_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: text_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: form_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: lang_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: security_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: cookie_helper
INFO - 2023-09-02 13:46:26 --> Database Driver Class Initialized
INFO - 2023-09-02 13:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 13:46:26 --> Parser Class Initialized
INFO - 2023-09-02 13:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 13:46:26 --> Pagination Class Initialized
INFO - 2023-09-02 13:46:26 --> Form Validation Class Initialized
INFO - 2023-09-02 13:46:26 --> Controller Class Initialized
INFO - 2023-09-02 13:46:26 --> Model Class Initialized
DEBUG - 2023-09-02 13:46:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 13:46:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 13:46:26 --> Config Class Initialized
INFO - 2023-09-02 13:46:26 --> Hooks Class Initialized
DEBUG - 2023-09-02 13:46:26 --> UTF-8 Support Enabled
INFO - 2023-09-02 13:46:26 --> Utf8 Class Initialized
INFO - 2023-09-02 13:46:26 --> URI Class Initialized
INFO - 2023-09-02 13:46:26 --> Router Class Initialized
INFO - 2023-09-02 13:46:26 --> Output Class Initialized
INFO - 2023-09-02 13:46:26 --> Security Class Initialized
DEBUG - 2023-09-02 13:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 13:46:26 --> Input Class Initialized
INFO - 2023-09-02 13:46:26 --> Language Class Initialized
INFO - 2023-09-02 13:46:26 --> Loader Class Initialized
INFO - 2023-09-02 13:46:26 --> Helper loaded: url_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: file_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: html_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: text_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: form_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: lang_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: security_helper
INFO - 2023-09-02 13:46:26 --> Helper loaded: cookie_helper
INFO - 2023-09-02 13:46:26 --> Database Driver Class Initialized
INFO - 2023-09-02 13:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 13:46:26 --> Parser Class Initialized
INFO - 2023-09-02 13:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 13:46:26 --> Pagination Class Initialized
INFO - 2023-09-02 13:46:26 --> Form Validation Class Initialized
INFO - 2023-09-02 13:46:26 --> Controller Class Initialized
INFO - 2023-09-02 13:46:26 --> Model Class Initialized
DEBUG - 2023-09-02 13:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 13:46:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 13:46:26 --> Model Class Initialized
INFO - 2023-09-02 13:46:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 13:46:26 --> Final output sent to browser
DEBUG - 2023-09-02 13:46:26 --> Total execution time: 0.0348
ERROR - 2023-09-02 14:52:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:52:49 --> Config Class Initialized
INFO - 2023-09-02 14:52:49 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:52:49 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:52:49 --> Utf8 Class Initialized
INFO - 2023-09-02 14:52:49 --> URI Class Initialized
DEBUG - 2023-09-02 14:52:49 --> No URI present. Default controller set.
INFO - 2023-09-02 14:52:49 --> Router Class Initialized
INFO - 2023-09-02 14:52:49 --> Output Class Initialized
INFO - 2023-09-02 14:52:49 --> Security Class Initialized
DEBUG - 2023-09-02 14:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:52:49 --> Input Class Initialized
INFO - 2023-09-02 14:52:49 --> Language Class Initialized
INFO - 2023-09-02 14:52:49 --> Loader Class Initialized
INFO - 2023-09-02 14:52:49 --> Helper loaded: url_helper
INFO - 2023-09-02 14:52:49 --> Helper loaded: file_helper
INFO - 2023-09-02 14:52:49 --> Helper loaded: html_helper
INFO - 2023-09-02 14:52:49 --> Helper loaded: text_helper
INFO - 2023-09-02 14:52:49 --> Helper loaded: form_helper
INFO - 2023-09-02 14:52:49 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:52:49 --> Helper loaded: security_helper
INFO - 2023-09-02 14:52:49 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:52:49 --> Database Driver Class Initialized
INFO - 2023-09-02 14:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:52:49 --> Parser Class Initialized
INFO - 2023-09-02 14:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:52:49 --> Pagination Class Initialized
INFO - 2023-09-02 14:52:49 --> Form Validation Class Initialized
INFO - 2023-09-02 14:52:49 --> Controller Class Initialized
INFO - 2023-09-02 14:52:49 --> Model Class Initialized
DEBUG - 2023-09-02 14:52:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-02 14:52:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:52:50 --> Config Class Initialized
INFO - 2023-09-02 14:52:50 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:52:50 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:52:50 --> Utf8 Class Initialized
INFO - 2023-09-02 14:52:50 --> URI Class Initialized
INFO - 2023-09-02 14:52:50 --> Router Class Initialized
INFO - 2023-09-02 14:52:50 --> Output Class Initialized
INFO - 2023-09-02 14:52:50 --> Security Class Initialized
DEBUG - 2023-09-02 14:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:52:50 --> Input Class Initialized
INFO - 2023-09-02 14:52:50 --> Language Class Initialized
INFO - 2023-09-02 14:52:50 --> Loader Class Initialized
INFO - 2023-09-02 14:52:50 --> Helper loaded: url_helper
INFO - 2023-09-02 14:52:50 --> Helper loaded: file_helper
INFO - 2023-09-02 14:52:50 --> Helper loaded: html_helper
INFO - 2023-09-02 14:52:50 --> Helper loaded: text_helper
INFO - 2023-09-02 14:52:50 --> Helper loaded: form_helper
INFO - 2023-09-02 14:52:50 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:52:50 --> Helper loaded: security_helper
INFO - 2023-09-02 14:52:50 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:52:50 --> Database Driver Class Initialized
INFO - 2023-09-02 14:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:52:50 --> Parser Class Initialized
INFO - 2023-09-02 14:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:52:50 --> Pagination Class Initialized
INFO - 2023-09-02 14:52:50 --> Form Validation Class Initialized
INFO - 2023-09-02 14:52:50 --> Controller Class Initialized
INFO - 2023-09-02 14:52:50 --> Model Class Initialized
DEBUG - 2023-09-02 14:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 14:52:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 14:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 14:52:50 --> Model Class Initialized
INFO - 2023-09-02 14:52:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 14:52:50 --> Final output sent to browser
DEBUG - 2023-09-02 14:52:50 --> Total execution time: 0.0321
ERROR - 2023-09-02 14:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:53:05 --> Config Class Initialized
INFO - 2023-09-02 14:53:05 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:53:05 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:53:05 --> Utf8 Class Initialized
INFO - 2023-09-02 14:53:05 --> URI Class Initialized
INFO - 2023-09-02 14:53:05 --> Router Class Initialized
INFO - 2023-09-02 14:53:05 --> Output Class Initialized
INFO - 2023-09-02 14:53:05 --> Security Class Initialized
DEBUG - 2023-09-02 14:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:53:05 --> Input Class Initialized
INFO - 2023-09-02 14:53:05 --> Language Class Initialized
INFO - 2023-09-02 14:53:05 --> Loader Class Initialized
INFO - 2023-09-02 14:53:05 --> Helper loaded: url_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: file_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: html_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: text_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: form_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: security_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:53:05 --> Database Driver Class Initialized
INFO - 2023-09-02 14:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:53:05 --> Parser Class Initialized
INFO - 2023-09-02 14:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:53:05 --> Pagination Class Initialized
INFO - 2023-09-02 14:53:05 --> Form Validation Class Initialized
INFO - 2023-09-02 14:53:05 --> Controller Class Initialized
INFO - 2023-09-02 14:53:05 --> Model Class Initialized
DEBUG - 2023-09-02 14:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:05 --> Model Class Initialized
INFO - 2023-09-02 14:53:05 --> Final output sent to browser
DEBUG - 2023-09-02 14:53:05 --> Total execution time: 0.0214
ERROR - 2023-09-02 14:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:53:05 --> Config Class Initialized
INFO - 2023-09-02 14:53:05 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:53:05 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:53:05 --> Utf8 Class Initialized
INFO - 2023-09-02 14:53:05 --> URI Class Initialized
INFO - 2023-09-02 14:53:05 --> Router Class Initialized
INFO - 2023-09-02 14:53:05 --> Output Class Initialized
INFO - 2023-09-02 14:53:05 --> Security Class Initialized
DEBUG - 2023-09-02 14:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:53:05 --> Input Class Initialized
INFO - 2023-09-02 14:53:05 --> Language Class Initialized
INFO - 2023-09-02 14:53:05 --> Loader Class Initialized
INFO - 2023-09-02 14:53:05 --> Helper loaded: url_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: file_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: html_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: text_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: form_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: security_helper
INFO - 2023-09-02 14:53:05 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:53:05 --> Database Driver Class Initialized
INFO - 2023-09-02 14:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:53:05 --> Parser Class Initialized
INFO - 2023-09-02 14:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:53:05 --> Pagination Class Initialized
INFO - 2023-09-02 14:53:05 --> Form Validation Class Initialized
INFO - 2023-09-02 14:53:05 --> Controller Class Initialized
INFO - 2023-09-02 14:53:05 --> Model Class Initialized
DEBUG - 2023-09-02 14:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-02 14:53:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 14:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 14:53:05 --> Model Class Initialized
INFO - 2023-09-02 14:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 14:53:05 --> Final output sent to browser
DEBUG - 2023-09-02 14:53:05 --> Total execution time: 0.0373
ERROR - 2023-09-02 14:53:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:53:15 --> Config Class Initialized
INFO - 2023-09-02 14:53:15 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:53:15 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:53:15 --> Utf8 Class Initialized
INFO - 2023-09-02 14:53:15 --> URI Class Initialized
INFO - 2023-09-02 14:53:15 --> Router Class Initialized
INFO - 2023-09-02 14:53:15 --> Output Class Initialized
INFO - 2023-09-02 14:53:15 --> Security Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:53:15 --> Input Class Initialized
INFO - 2023-09-02 14:53:15 --> Language Class Initialized
INFO - 2023-09-02 14:53:15 --> Loader Class Initialized
INFO - 2023-09-02 14:53:15 --> Helper loaded: url_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: file_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: html_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: text_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: form_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: security_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:53:15 --> Database Driver Class Initialized
INFO - 2023-09-02 14:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:53:15 --> Parser Class Initialized
INFO - 2023-09-02 14:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:53:15 --> Pagination Class Initialized
INFO - 2023-09-02 14:53:15 --> Form Validation Class Initialized
INFO - 2023-09-02 14:53:15 --> Controller Class Initialized
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> Final output sent to browser
DEBUG - 2023-09-02 14:53:15 --> Total execution time: 0.0177
ERROR - 2023-09-02 14:53:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:53:15 --> Config Class Initialized
INFO - 2023-09-02 14:53:15 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:53:15 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:53:15 --> Utf8 Class Initialized
INFO - 2023-09-02 14:53:15 --> URI Class Initialized
INFO - 2023-09-02 14:53:15 --> Router Class Initialized
INFO - 2023-09-02 14:53:15 --> Output Class Initialized
INFO - 2023-09-02 14:53:15 --> Security Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:53:15 --> Input Class Initialized
INFO - 2023-09-02 14:53:15 --> Language Class Initialized
INFO - 2023-09-02 14:53:15 --> Loader Class Initialized
INFO - 2023-09-02 14:53:15 --> Helper loaded: url_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: file_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: html_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: text_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: form_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: security_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:53:15 --> Database Driver Class Initialized
INFO - 2023-09-02 14:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:53:15 --> Parser Class Initialized
INFO - 2023-09-02 14:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:53:15 --> Pagination Class Initialized
INFO - 2023-09-02 14:53:15 --> Form Validation Class Initialized
INFO - 2023-09-02 14:53:15 --> Controller Class Initialized
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> Final output sent to browser
DEBUG - 2023-09-02 14:53:15 --> Total execution time: 0.0159
ERROR - 2023-09-02 14:53:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:53:15 --> Config Class Initialized
INFO - 2023-09-02 14:53:15 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:53:15 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:53:15 --> Utf8 Class Initialized
INFO - 2023-09-02 14:53:15 --> URI Class Initialized
DEBUG - 2023-09-02 14:53:15 --> No URI present. Default controller set.
INFO - 2023-09-02 14:53:15 --> Router Class Initialized
INFO - 2023-09-02 14:53:15 --> Output Class Initialized
INFO - 2023-09-02 14:53:15 --> Security Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:53:15 --> Input Class Initialized
INFO - 2023-09-02 14:53:15 --> Language Class Initialized
INFO - 2023-09-02 14:53:15 --> Loader Class Initialized
INFO - 2023-09-02 14:53:15 --> Helper loaded: url_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: file_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: html_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: text_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: form_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: security_helper
INFO - 2023-09-02 14:53:15 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:53:15 --> Database Driver Class Initialized
INFO - 2023-09-02 14:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:53:15 --> Parser Class Initialized
INFO - 2023-09-02 14:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:53:15 --> Pagination Class Initialized
INFO - 2023-09-02 14:53:15 --> Form Validation Class Initialized
INFO - 2023-09-02 14:53:15 --> Controller Class Initialized
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
DEBUG - 2023-09-02 14:53:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 14:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 14:53:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 14:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 14:53:15 --> Model Class Initialized
INFO - 2023-09-02 14:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 14:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 14:53:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 14:53:15 --> Final output sent to browser
DEBUG - 2023-09-02 14:53:15 --> Total execution time: 0.1067
ERROR - 2023-09-02 14:59:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:59:40 --> Config Class Initialized
INFO - 2023-09-02 14:59:40 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:59:40 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:59:40 --> Utf8 Class Initialized
INFO - 2023-09-02 14:59:40 --> URI Class Initialized
INFO - 2023-09-02 14:59:40 --> Router Class Initialized
INFO - 2023-09-02 14:59:40 --> Output Class Initialized
INFO - 2023-09-02 14:59:40 --> Security Class Initialized
DEBUG - 2023-09-02 14:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:59:40 --> Input Class Initialized
INFO - 2023-09-02 14:59:40 --> Language Class Initialized
INFO - 2023-09-02 14:59:40 --> Loader Class Initialized
INFO - 2023-09-02 14:59:40 --> Helper loaded: url_helper
INFO - 2023-09-02 14:59:40 --> Helper loaded: file_helper
INFO - 2023-09-02 14:59:40 --> Helper loaded: html_helper
INFO - 2023-09-02 14:59:40 --> Helper loaded: text_helper
INFO - 2023-09-02 14:59:40 --> Helper loaded: form_helper
INFO - 2023-09-02 14:59:40 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:59:40 --> Helper loaded: security_helper
INFO - 2023-09-02 14:59:40 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:59:40 --> Database Driver Class Initialized
INFO - 2023-09-02 14:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:59:40 --> Parser Class Initialized
INFO - 2023-09-02 14:59:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:59:40 --> Pagination Class Initialized
INFO - 2023-09-02 14:59:40 --> Form Validation Class Initialized
INFO - 2023-09-02 14:59:40 --> Controller Class Initialized
INFO - 2023-09-02 14:59:40 --> Model Class Initialized
DEBUG - 2023-09-02 14:59:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 14:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:59:40 --> Model Class Initialized
DEBUG - 2023-09-02 14:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:59:40 --> Model Class Initialized
INFO - 2023-09-02 14:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 14:59:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 14:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 14:59:40 --> Model Class Initialized
INFO - 2023-09-02 14:59:40 --> Model Class Initialized
INFO - 2023-09-02 14:59:40 --> Model Class Initialized
INFO - 2023-09-02 14:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 14:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 14:59:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 14:59:40 --> Final output sent to browser
DEBUG - 2023-09-02 14:59:40 --> Total execution time: 0.0893
ERROR - 2023-09-02 14:59:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 14:59:41 --> Config Class Initialized
INFO - 2023-09-02 14:59:41 --> Hooks Class Initialized
DEBUG - 2023-09-02 14:59:41 --> UTF-8 Support Enabled
INFO - 2023-09-02 14:59:41 --> Utf8 Class Initialized
INFO - 2023-09-02 14:59:41 --> URI Class Initialized
INFO - 2023-09-02 14:59:41 --> Router Class Initialized
INFO - 2023-09-02 14:59:41 --> Output Class Initialized
INFO - 2023-09-02 14:59:41 --> Security Class Initialized
DEBUG - 2023-09-02 14:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 14:59:41 --> Input Class Initialized
INFO - 2023-09-02 14:59:41 --> Language Class Initialized
INFO - 2023-09-02 14:59:41 --> Loader Class Initialized
INFO - 2023-09-02 14:59:41 --> Helper loaded: url_helper
INFO - 2023-09-02 14:59:41 --> Helper loaded: file_helper
INFO - 2023-09-02 14:59:41 --> Helper loaded: html_helper
INFO - 2023-09-02 14:59:41 --> Helper loaded: text_helper
INFO - 2023-09-02 14:59:41 --> Helper loaded: form_helper
INFO - 2023-09-02 14:59:41 --> Helper loaded: lang_helper
INFO - 2023-09-02 14:59:41 --> Helper loaded: security_helper
INFO - 2023-09-02 14:59:41 --> Helper loaded: cookie_helper
INFO - 2023-09-02 14:59:41 --> Database Driver Class Initialized
INFO - 2023-09-02 14:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 14:59:41 --> Parser Class Initialized
INFO - 2023-09-02 14:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 14:59:41 --> Pagination Class Initialized
INFO - 2023-09-02 14:59:41 --> Form Validation Class Initialized
INFO - 2023-09-02 14:59:41 --> Controller Class Initialized
INFO - 2023-09-02 14:59:41 --> Model Class Initialized
DEBUG - 2023-09-02 14:59:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 14:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:59:41 --> Model Class Initialized
DEBUG - 2023-09-02 14:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 14:59:41 --> Model Class Initialized
INFO - 2023-09-02 14:59:41 --> Final output sent to browser
DEBUG - 2023-09-02 14:59:41 --> Total execution time: 0.0438
ERROR - 2023-09-02 15:05:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:05:58 --> Config Class Initialized
INFO - 2023-09-02 15:05:58 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:05:58 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:05:58 --> Utf8 Class Initialized
INFO - 2023-09-02 15:05:58 --> URI Class Initialized
DEBUG - 2023-09-02 15:05:58 --> No URI present. Default controller set.
INFO - 2023-09-02 15:05:58 --> Router Class Initialized
INFO - 2023-09-02 15:05:58 --> Output Class Initialized
INFO - 2023-09-02 15:05:58 --> Security Class Initialized
DEBUG - 2023-09-02 15:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:05:58 --> Input Class Initialized
INFO - 2023-09-02 15:05:58 --> Language Class Initialized
INFO - 2023-09-02 15:05:58 --> Loader Class Initialized
INFO - 2023-09-02 15:05:58 --> Helper loaded: url_helper
INFO - 2023-09-02 15:05:58 --> Helper loaded: file_helper
INFO - 2023-09-02 15:05:58 --> Helper loaded: html_helper
INFO - 2023-09-02 15:05:58 --> Helper loaded: text_helper
INFO - 2023-09-02 15:05:58 --> Helper loaded: form_helper
INFO - 2023-09-02 15:05:58 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:05:58 --> Helper loaded: security_helper
INFO - 2023-09-02 15:05:58 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:05:58 --> Database Driver Class Initialized
INFO - 2023-09-02 15:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:05:58 --> Parser Class Initialized
INFO - 2023-09-02 15:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:05:58 --> Pagination Class Initialized
INFO - 2023-09-02 15:05:58 --> Form Validation Class Initialized
INFO - 2023-09-02 15:05:58 --> Controller Class Initialized
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
DEBUG - 2023-09-02 15:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
DEBUG - 2023-09-02 15:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
DEBUG - 2023-09-02 15:05:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
INFO - 2023-09-02 15:05:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 15:05:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:05:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 15:05:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 15:05:58 --> Model Class Initialized
INFO - 2023-09-02 15:05:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 15:05:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 15:05:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 15:05:58 --> Final output sent to browser
DEBUG - 2023-09-02 15:05:58 --> Total execution time: 0.1262
ERROR - 2023-09-02 15:08:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:08:39 --> Config Class Initialized
INFO - 2023-09-02 15:08:39 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:08:39 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:08:39 --> Utf8 Class Initialized
INFO - 2023-09-02 15:08:39 --> URI Class Initialized
DEBUG - 2023-09-02 15:08:39 --> No URI present. Default controller set.
INFO - 2023-09-02 15:08:39 --> Router Class Initialized
INFO - 2023-09-02 15:08:39 --> Output Class Initialized
INFO - 2023-09-02 15:08:39 --> Security Class Initialized
DEBUG - 2023-09-02 15:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:08:39 --> Input Class Initialized
INFO - 2023-09-02 15:08:39 --> Language Class Initialized
INFO - 2023-09-02 15:08:39 --> Loader Class Initialized
INFO - 2023-09-02 15:08:39 --> Helper loaded: url_helper
INFO - 2023-09-02 15:08:39 --> Helper loaded: file_helper
INFO - 2023-09-02 15:08:39 --> Helper loaded: html_helper
INFO - 2023-09-02 15:08:39 --> Helper loaded: text_helper
INFO - 2023-09-02 15:08:39 --> Helper loaded: form_helper
INFO - 2023-09-02 15:08:39 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:08:39 --> Helper loaded: security_helper
INFO - 2023-09-02 15:08:39 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:08:39 --> Database Driver Class Initialized
INFO - 2023-09-02 15:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:08:39 --> Parser Class Initialized
INFO - 2023-09-02 15:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:08:39 --> Pagination Class Initialized
INFO - 2023-09-02 15:08:39 --> Form Validation Class Initialized
INFO - 2023-09-02 15:08:39 --> Controller Class Initialized
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
DEBUG - 2023-09-02 15:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
DEBUG - 2023-09-02 15:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
DEBUG - 2023-09-02 15:08:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
INFO - 2023-09-02 15:08:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 15:08:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 15:08:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 15:08:39 --> Model Class Initialized
INFO - 2023-09-02 15:08:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 15:08:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 15:08:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 15:08:39 --> Final output sent to browser
DEBUG - 2023-09-02 15:08:39 --> Total execution time: 0.0959
ERROR - 2023-09-02 15:08:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:08:54 --> Config Class Initialized
INFO - 2023-09-02 15:08:54 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:08:54 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:08:54 --> Utf8 Class Initialized
INFO - 2023-09-02 15:08:54 --> URI Class Initialized
INFO - 2023-09-02 15:08:54 --> Router Class Initialized
INFO - 2023-09-02 15:08:54 --> Output Class Initialized
INFO - 2023-09-02 15:08:54 --> Security Class Initialized
DEBUG - 2023-09-02 15:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:08:54 --> Input Class Initialized
INFO - 2023-09-02 15:08:54 --> Language Class Initialized
INFO - 2023-09-02 15:08:54 --> Loader Class Initialized
INFO - 2023-09-02 15:08:54 --> Helper loaded: url_helper
INFO - 2023-09-02 15:08:54 --> Helper loaded: file_helper
INFO - 2023-09-02 15:08:54 --> Helper loaded: html_helper
INFO - 2023-09-02 15:08:54 --> Helper loaded: text_helper
INFO - 2023-09-02 15:08:54 --> Helper loaded: form_helper
INFO - 2023-09-02 15:08:54 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:08:54 --> Helper loaded: security_helper
INFO - 2023-09-02 15:08:54 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:08:54 --> Database Driver Class Initialized
INFO - 2023-09-02 15:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:08:54 --> Parser Class Initialized
INFO - 2023-09-02 15:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:08:54 --> Pagination Class Initialized
INFO - 2023-09-02 15:08:54 --> Form Validation Class Initialized
INFO - 2023-09-02 15:08:54 --> Controller Class Initialized
INFO - 2023-09-02 15:08:54 --> Model Class Initialized
DEBUG - 2023-09-02 15:08:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:54 --> Model Class Initialized
DEBUG - 2023-09-02 15:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:54 --> Model Class Initialized
INFO - 2023-09-02 15:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-02 15:08:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 15:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 15:08:54 --> Model Class Initialized
INFO - 2023-09-02 15:08:54 --> Model Class Initialized
INFO - 2023-09-02 15:08:54 --> Model Class Initialized
INFO - 2023-09-02 15:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 15:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 15:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 15:08:54 --> Final output sent to browser
DEBUG - 2023-09-02 15:08:54 --> Total execution time: 0.0859
ERROR - 2023-09-02 15:08:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:08:55 --> Config Class Initialized
INFO - 2023-09-02 15:08:55 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:08:55 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:08:55 --> Utf8 Class Initialized
INFO - 2023-09-02 15:08:55 --> URI Class Initialized
INFO - 2023-09-02 15:08:55 --> Router Class Initialized
INFO - 2023-09-02 15:08:55 --> Output Class Initialized
INFO - 2023-09-02 15:08:55 --> Security Class Initialized
DEBUG - 2023-09-02 15:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:08:55 --> Input Class Initialized
INFO - 2023-09-02 15:08:55 --> Language Class Initialized
INFO - 2023-09-02 15:08:55 --> Loader Class Initialized
INFO - 2023-09-02 15:08:55 --> Helper loaded: url_helper
INFO - 2023-09-02 15:08:55 --> Helper loaded: file_helper
INFO - 2023-09-02 15:08:55 --> Helper loaded: html_helper
INFO - 2023-09-02 15:08:55 --> Helper loaded: text_helper
INFO - 2023-09-02 15:08:55 --> Helper loaded: form_helper
INFO - 2023-09-02 15:08:55 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:08:55 --> Helper loaded: security_helper
INFO - 2023-09-02 15:08:55 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:08:55 --> Database Driver Class Initialized
INFO - 2023-09-02 15:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:08:55 --> Parser Class Initialized
INFO - 2023-09-02 15:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:08:55 --> Pagination Class Initialized
INFO - 2023-09-02 15:08:55 --> Form Validation Class Initialized
INFO - 2023-09-02 15:08:55 --> Controller Class Initialized
INFO - 2023-09-02 15:08:55 --> Model Class Initialized
DEBUG - 2023-09-02 15:08:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:55 --> Model Class Initialized
DEBUG - 2023-09-02 15:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:08:55 --> Model Class Initialized
INFO - 2023-09-02 15:08:55 --> Final output sent to browser
DEBUG - 2023-09-02 15:08:55 --> Total execution time: 0.0384
ERROR - 2023-09-02 15:09:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:07 --> Config Class Initialized
INFO - 2023-09-02 15:09:07 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:07 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:07 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:07 --> URI Class Initialized
INFO - 2023-09-02 15:09:07 --> Router Class Initialized
INFO - 2023-09-02 15:09:07 --> Output Class Initialized
INFO - 2023-09-02 15:09:07 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:07 --> Input Class Initialized
INFO - 2023-09-02 15:09:07 --> Language Class Initialized
INFO - 2023-09-02 15:09:07 --> Loader Class Initialized
INFO - 2023-09-02 15:09:07 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:07 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:07 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:07 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:07 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:07 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:07 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:07 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:07 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:07 --> Parser Class Initialized
INFO - 2023-09-02 15:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:07 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:07 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:07 --> Controller Class Initialized
INFO - 2023-09-02 15:09:07 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:07 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:07 --> Model Class Initialized
INFO - 2023-09-02 15:09:07 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:07 --> Total execution time: 0.0427
ERROR - 2023-09-02 15:09:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:09 --> Config Class Initialized
INFO - 2023-09-02 15:09:09 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:09 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:09 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:09 --> URI Class Initialized
INFO - 2023-09-02 15:09:09 --> Router Class Initialized
INFO - 2023-09-02 15:09:09 --> Output Class Initialized
INFO - 2023-09-02 15:09:09 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:09 --> Input Class Initialized
INFO - 2023-09-02 15:09:09 --> Language Class Initialized
INFO - 2023-09-02 15:09:09 --> Loader Class Initialized
INFO - 2023-09-02 15:09:09 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:09 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:09 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:09 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:09 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:09 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:09 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:09 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:09 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:09 --> Parser Class Initialized
INFO - 2023-09-02 15:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:09 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:09 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:09 --> Controller Class Initialized
INFO - 2023-09-02 15:09:09 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:09 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:09 --> Model Class Initialized
INFO - 2023-09-02 15:09:09 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:09 --> Total execution time: 0.0426
ERROR - 2023-09-02 15:09:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:10 --> Config Class Initialized
INFO - 2023-09-02 15:09:10 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:10 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:10 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:10 --> URI Class Initialized
INFO - 2023-09-02 15:09:10 --> Router Class Initialized
INFO - 2023-09-02 15:09:10 --> Output Class Initialized
INFO - 2023-09-02 15:09:10 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:10 --> Input Class Initialized
INFO - 2023-09-02 15:09:10 --> Language Class Initialized
INFO - 2023-09-02 15:09:10 --> Loader Class Initialized
INFO - 2023-09-02 15:09:10 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:10 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:10 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:10 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:10 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:10 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:10 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:10 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:10 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:10 --> Parser Class Initialized
INFO - 2023-09-02 15:09:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:10 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:10 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:10 --> Controller Class Initialized
INFO - 2023-09-02 15:09:10 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:10 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:10 --> Model Class Initialized
INFO - 2023-09-02 15:09:10 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:10 --> Total execution time: 0.0424
ERROR - 2023-09-02 15:09:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:12 --> Config Class Initialized
INFO - 2023-09-02 15:09:12 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:12 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:12 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:12 --> URI Class Initialized
INFO - 2023-09-02 15:09:12 --> Router Class Initialized
INFO - 2023-09-02 15:09:12 --> Output Class Initialized
INFO - 2023-09-02 15:09:12 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:12 --> Input Class Initialized
INFO - 2023-09-02 15:09:12 --> Language Class Initialized
INFO - 2023-09-02 15:09:12 --> Loader Class Initialized
INFO - 2023-09-02 15:09:12 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:12 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:12 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:12 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:12 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:12 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:12 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:12 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:12 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:12 --> Parser Class Initialized
INFO - 2023-09-02 15:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:12 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:12 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:12 --> Controller Class Initialized
INFO - 2023-09-02 15:09:12 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:12 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:12 --> Model Class Initialized
INFO - 2023-09-02 15:09:12 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:12 --> Total execution time: 0.0420
ERROR - 2023-09-02 15:09:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:13 --> Config Class Initialized
INFO - 2023-09-02 15:09:13 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:13 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:13 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:13 --> URI Class Initialized
INFO - 2023-09-02 15:09:13 --> Router Class Initialized
INFO - 2023-09-02 15:09:13 --> Output Class Initialized
INFO - 2023-09-02 15:09:13 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:13 --> Input Class Initialized
INFO - 2023-09-02 15:09:13 --> Language Class Initialized
INFO - 2023-09-02 15:09:13 --> Loader Class Initialized
INFO - 2023-09-02 15:09:13 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:13 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:13 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:13 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:13 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:13 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:13 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:13 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:13 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:13 --> Parser Class Initialized
INFO - 2023-09-02 15:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:13 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:13 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:13 --> Controller Class Initialized
INFO - 2023-09-02 15:09:13 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:13 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:13 --> Model Class Initialized
INFO - 2023-09-02 15:09:13 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:13 --> Total execution time: 0.0414
ERROR - 2023-09-02 15:09:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:15 --> Config Class Initialized
INFO - 2023-09-02 15:09:15 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:15 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:15 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:15 --> URI Class Initialized
INFO - 2023-09-02 15:09:15 --> Router Class Initialized
INFO - 2023-09-02 15:09:15 --> Output Class Initialized
INFO - 2023-09-02 15:09:15 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:15 --> Input Class Initialized
INFO - 2023-09-02 15:09:15 --> Language Class Initialized
INFO - 2023-09-02 15:09:15 --> Loader Class Initialized
INFO - 2023-09-02 15:09:15 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:15 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:15 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:15 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:15 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:15 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:15 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:15 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:15 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:15 --> Parser Class Initialized
INFO - 2023-09-02 15:09:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:15 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:15 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:15 --> Controller Class Initialized
INFO - 2023-09-02 15:09:15 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:15 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:15 --> Model Class Initialized
INFO - 2023-09-02 15:09:15 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:15 --> Total execution time: 0.0461
ERROR - 2023-09-02 15:09:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:16 --> Config Class Initialized
INFO - 2023-09-02 15:09:16 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:16 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:16 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:16 --> URI Class Initialized
INFO - 2023-09-02 15:09:16 --> Router Class Initialized
INFO - 2023-09-02 15:09:16 --> Output Class Initialized
INFO - 2023-09-02 15:09:16 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:16 --> Input Class Initialized
INFO - 2023-09-02 15:09:16 --> Language Class Initialized
INFO - 2023-09-02 15:09:16 --> Loader Class Initialized
INFO - 2023-09-02 15:09:16 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:16 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:16 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:16 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:16 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:16 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:16 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:16 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:16 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:16 --> Parser Class Initialized
INFO - 2023-09-02 15:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:16 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:16 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:16 --> Controller Class Initialized
INFO - 2023-09-02 15:09:16 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:16 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:16 --> Model Class Initialized
INFO - 2023-09-02 15:09:16 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:16 --> Total execution time: 0.0471
ERROR - 2023-09-02 15:09:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:09:18 --> Config Class Initialized
INFO - 2023-09-02 15:09:18 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:09:18 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:09:18 --> Utf8 Class Initialized
INFO - 2023-09-02 15:09:18 --> URI Class Initialized
INFO - 2023-09-02 15:09:18 --> Router Class Initialized
INFO - 2023-09-02 15:09:18 --> Output Class Initialized
INFO - 2023-09-02 15:09:18 --> Security Class Initialized
DEBUG - 2023-09-02 15:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:09:18 --> Input Class Initialized
INFO - 2023-09-02 15:09:18 --> Language Class Initialized
INFO - 2023-09-02 15:09:18 --> Loader Class Initialized
INFO - 2023-09-02 15:09:18 --> Helper loaded: url_helper
INFO - 2023-09-02 15:09:18 --> Helper loaded: file_helper
INFO - 2023-09-02 15:09:18 --> Helper loaded: html_helper
INFO - 2023-09-02 15:09:18 --> Helper loaded: text_helper
INFO - 2023-09-02 15:09:18 --> Helper loaded: form_helper
INFO - 2023-09-02 15:09:18 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:09:18 --> Helper loaded: security_helper
INFO - 2023-09-02 15:09:18 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:09:18 --> Database Driver Class Initialized
INFO - 2023-09-02 15:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:09:18 --> Parser Class Initialized
INFO - 2023-09-02 15:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:09:18 --> Pagination Class Initialized
INFO - 2023-09-02 15:09:18 --> Form Validation Class Initialized
INFO - 2023-09-02 15:09:18 --> Controller Class Initialized
INFO - 2023-09-02 15:09:18 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:18 --> Model Class Initialized
DEBUG - 2023-09-02 15:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:09:18 --> Model Class Initialized
INFO - 2023-09-02 15:09:18 --> Final output sent to browser
DEBUG - 2023-09-02 15:09:18 --> Total execution time: 0.0311
ERROR - 2023-09-02 15:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 15:16:33 --> Config Class Initialized
INFO - 2023-09-02 15:16:33 --> Hooks Class Initialized
DEBUG - 2023-09-02 15:16:33 --> UTF-8 Support Enabled
INFO - 2023-09-02 15:16:33 --> Utf8 Class Initialized
INFO - 2023-09-02 15:16:33 --> URI Class Initialized
DEBUG - 2023-09-02 15:16:33 --> No URI present. Default controller set.
INFO - 2023-09-02 15:16:33 --> Router Class Initialized
INFO - 2023-09-02 15:16:33 --> Output Class Initialized
INFO - 2023-09-02 15:16:33 --> Security Class Initialized
DEBUG - 2023-09-02 15:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 15:16:33 --> Input Class Initialized
INFO - 2023-09-02 15:16:33 --> Language Class Initialized
INFO - 2023-09-02 15:16:33 --> Loader Class Initialized
INFO - 2023-09-02 15:16:33 --> Helper loaded: url_helper
INFO - 2023-09-02 15:16:33 --> Helper loaded: file_helper
INFO - 2023-09-02 15:16:33 --> Helper loaded: html_helper
INFO - 2023-09-02 15:16:33 --> Helper loaded: text_helper
INFO - 2023-09-02 15:16:33 --> Helper loaded: form_helper
INFO - 2023-09-02 15:16:33 --> Helper loaded: lang_helper
INFO - 2023-09-02 15:16:33 --> Helper loaded: security_helper
INFO - 2023-09-02 15:16:33 --> Helper loaded: cookie_helper
INFO - 2023-09-02 15:16:33 --> Database Driver Class Initialized
INFO - 2023-09-02 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 15:16:33 --> Parser Class Initialized
INFO - 2023-09-02 15:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 15:16:33 --> Pagination Class Initialized
INFO - 2023-09-02 15:16:33 --> Form Validation Class Initialized
INFO - 2023-09-02 15:16:33 --> Controller Class Initialized
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
DEBUG - 2023-09-02 15:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
DEBUG - 2023-09-02 15:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
DEBUG - 2023-09-02 15:16:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-02 15:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
INFO - 2023-09-02 15:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-02 15:16:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-02 15:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-02 15:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-02 15:16:33 --> Model Class Initialized
INFO - 2023-09-02 15:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-02 15:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-02 15:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-02 15:16:33 --> Final output sent to browser
DEBUG - 2023-09-02 15:16:33 --> Total execution time: 0.1012
ERROR - 2023-09-02 19:51:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-02 19:51:55 --> Config Class Initialized
INFO - 2023-09-02 19:51:55 --> Hooks Class Initialized
DEBUG - 2023-09-02 19:51:55 --> UTF-8 Support Enabled
INFO - 2023-09-02 19:51:55 --> Utf8 Class Initialized
INFO - 2023-09-02 19:51:55 --> URI Class Initialized
DEBUG - 2023-09-02 19:51:55 --> No URI present. Default controller set.
INFO - 2023-09-02 19:51:55 --> Router Class Initialized
INFO - 2023-09-02 19:51:55 --> Output Class Initialized
INFO - 2023-09-02 19:51:55 --> Security Class Initialized
DEBUG - 2023-09-02 19:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-02 19:51:55 --> Input Class Initialized
INFO - 2023-09-02 19:51:55 --> Language Class Initialized
INFO - 2023-09-02 19:51:55 --> Loader Class Initialized
INFO - 2023-09-02 19:51:55 --> Helper loaded: url_helper
INFO - 2023-09-02 19:51:55 --> Helper loaded: file_helper
INFO - 2023-09-02 19:51:55 --> Helper loaded: html_helper
INFO - 2023-09-02 19:51:55 --> Helper loaded: text_helper
INFO - 2023-09-02 19:51:55 --> Helper loaded: form_helper
INFO - 2023-09-02 19:51:55 --> Helper loaded: lang_helper
INFO - 2023-09-02 19:51:55 --> Helper loaded: security_helper
INFO - 2023-09-02 19:51:55 --> Helper loaded: cookie_helper
INFO - 2023-09-02 19:51:55 --> Database Driver Class Initialized
INFO - 2023-09-02 19:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-02 19:51:55 --> Parser Class Initialized
INFO - 2023-09-02 19:51:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-02 19:51:55 --> Pagination Class Initialized
INFO - 2023-09-02 19:51:55 --> Form Validation Class Initialized
INFO - 2023-09-02 19:51:55 --> Controller Class Initialized
INFO - 2023-09-02 19:51:55 --> Model Class Initialized
DEBUG - 2023-09-02 19:51:55 --> Session class already loaded. Second attempt ignored.
