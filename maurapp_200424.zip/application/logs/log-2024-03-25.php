<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-25 09:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 09:23:45 --> Config Class Initialized
INFO - 2024-03-25 09:23:45 --> Hooks Class Initialized
DEBUG - 2024-03-25 09:23:45 --> UTF-8 Support Enabled
INFO - 2024-03-25 09:23:45 --> Utf8 Class Initialized
INFO - 2024-03-25 09:23:45 --> URI Class Initialized
DEBUG - 2024-03-25 09:23:45 --> No URI present. Default controller set.
INFO - 2024-03-25 09:23:45 --> Router Class Initialized
INFO - 2024-03-25 09:23:45 --> Output Class Initialized
INFO - 2024-03-25 09:23:45 --> Security Class Initialized
DEBUG - 2024-03-25 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 09:23:45 --> Input Class Initialized
INFO - 2024-03-25 09:23:45 --> Language Class Initialized
INFO - 2024-03-25 09:23:45 --> Loader Class Initialized
INFO - 2024-03-25 09:23:45 --> Helper loaded: url_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: file_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: html_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: text_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: form_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: lang_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: security_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: cookie_helper
INFO - 2024-03-25 09:23:45 --> Database Driver Class Initialized
INFO - 2024-03-25 09:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 09:23:45 --> Parser Class Initialized
INFO - 2024-03-25 09:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 09:23:45 --> Pagination Class Initialized
INFO - 2024-03-25 09:23:45 --> Form Validation Class Initialized
INFO - 2024-03-25 09:23:45 --> Controller Class Initialized
INFO - 2024-03-25 09:23:45 --> Model Class Initialized
DEBUG - 2024-03-25 09:23:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 09:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 09:23:45 --> Config Class Initialized
INFO - 2024-03-25 09:23:45 --> Hooks Class Initialized
DEBUG - 2024-03-25 09:23:45 --> UTF-8 Support Enabled
INFO - 2024-03-25 09:23:45 --> Utf8 Class Initialized
INFO - 2024-03-25 09:23:45 --> URI Class Initialized
INFO - 2024-03-25 09:23:45 --> Router Class Initialized
INFO - 2024-03-25 09:23:45 --> Output Class Initialized
INFO - 2024-03-25 09:23:45 --> Security Class Initialized
DEBUG - 2024-03-25 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 09:23:45 --> Input Class Initialized
INFO - 2024-03-25 09:23:45 --> Language Class Initialized
INFO - 2024-03-25 09:23:45 --> Loader Class Initialized
INFO - 2024-03-25 09:23:45 --> Helper loaded: url_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: file_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: html_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: text_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: form_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: lang_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: security_helper
INFO - 2024-03-25 09:23:45 --> Helper loaded: cookie_helper
INFO - 2024-03-25 09:23:45 --> Database Driver Class Initialized
INFO - 2024-03-25 09:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 09:23:45 --> Parser Class Initialized
INFO - 2024-03-25 09:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 09:23:45 --> Pagination Class Initialized
INFO - 2024-03-25 09:23:45 --> Form Validation Class Initialized
INFO - 2024-03-25 09:23:45 --> Controller Class Initialized
INFO - 2024-03-25 09:23:45 --> Model Class Initialized
DEBUG - 2024-03-25 09:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-25 09:23:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 09:23:45 --> Model Class Initialized
INFO - 2024-03-25 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 09:23:45 --> Final output sent to browser
DEBUG - 2024-03-25 09:23:45 --> Total execution time: 0.0353
ERROR - 2024-03-25 10:23:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 10:23:13 --> Config Class Initialized
INFO - 2024-03-25 10:23:13 --> Hooks Class Initialized
DEBUG - 2024-03-25 10:23:13 --> UTF-8 Support Enabled
INFO - 2024-03-25 10:23:13 --> Utf8 Class Initialized
INFO - 2024-03-25 10:23:13 --> URI Class Initialized
DEBUG - 2024-03-25 10:23:13 --> No URI present. Default controller set.
INFO - 2024-03-25 10:23:13 --> Router Class Initialized
INFO - 2024-03-25 10:23:13 --> Output Class Initialized
INFO - 2024-03-25 10:23:13 --> Security Class Initialized
DEBUG - 2024-03-25 10:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 10:23:13 --> Input Class Initialized
INFO - 2024-03-25 10:23:13 --> Language Class Initialized
INFO - 2024-03-25 10:23:13 --> Loader Class Initialized
INFO - 2024-03-25 10:23:13 --> Helper loaded: url_helper
INFO - 2024-03-25 10:23:13 --> Helper loaded: file_helper
INFO - 2024-03-25 10:23:13 --> Helper loaded: html_helper
INFO - 2024-03-25 10:23:13 --> Helper loaded: text_helper
INFO - 2024-03-25 10:23:13 --> Helper loaded: form_helper
INFO - 2024-03-25 10:23:13 --> Helper loaded: lang_helper
INFO - 2024-03-25 10:23:13 --> Helper loaded: security_helper
INFO - 2024-03-25 10:23:13 --> Helper loaded: cookie_helper
INFO - 2024-03-25 10:23:13 --> Database Driver Class Initialized
INFO - 2024-03-25 10:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 10:23:13 --> Parser Class Initialized
INFO - 2024-03-25 10:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 10:23:13 --> Pagination Class Initialized
INFO - 2024-03-25 10:23:13 --> Form Validation Class Initialized
INFO - 2024-03-25 10:23:13 --> Controller Class Initialized
INFO - 2024-03-25 10:23:13 --> Model Class Initialized
DEBUG - 2024-03-25 10:23:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 10:23:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 10:23:14 --> Config Class Initialized
INFO - 2024-03-25 10:23:14 --> Hooks Class Initialized
DEBUG - 2024-03-25 10:23:14 --> UTF-8 Support Enabled
INFO - 2024-03-25 10:23:14 --> Utf8 Class Initialized
INFO - 2024-03-25 10:23:14 --> URI Class Initialized
INFO - 2024-03-25 10:23:14 --> Router Class Initialized
INFO - 2024-03-25 10:23:14 --> Output Class Initialized
INFO - 2024-03-25 10:23:14 --> Security Class Initialized
DEBUG - 2024-03-25 10:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 10:23:14 --> Input Class Initialized
INFO - 2024-03-25 10:23:14 --> Language Class Initialized
INFO - 2024-03-25 10:23:14 --> Loader Class Initialized
INFO - 2024-03-25 10:23:14 --> Helper loaded: url_helper
INFO - 2024-03-25 10:23:14 --> Helper loaded: file_helper
INFO - 2024-03-25 10:23:14 --> Helper loaded: html_helper
INFO - 2024-03-25 10:23:14 --> Helper loaded: text_helper
INFO - 2024-03-25 10:23:14 --> Helper loaded: form_helper
INFO - 2024-03-25 10:23:14 --> Helper loaded: lang_helper
INFO - 2024-03-25 10:23:14 --> Helper loaded: security_helper
INFO - 2024-03-25 10:23:14 --> Helper loaded: cookie_helper
INFO - 2024-03-25 10:23:14 --> Database Driver Class Initialized
INFO - 2024-03-25 10:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 10:23:14 --> Parser Class Initialized
INFO - 2024-03-25 10:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 10:23:14 --> Pagination Class Initialized
INFO - 2024-03-25 10:23:14 --> Form Validation Class Initialized
INFO - 2024-03-25 10:23:14 --> Controller Class Initialized
INFO - 2024-03-25 10:23:14 --> Model Class Initialized
DEBUG - 2024-03-25 10:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-25 10:23:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 10:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 10:23:14 --> Model Class Initialized
INFO - 2024-03-25 10:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 10:23:14 --> Final output sent to browser
DEBUG - 2024-03-25 10:23:14 --> Total execution time: 0.0347
ERROR - 2024-03-25 10:59:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 10:59:28 --> Config Class Initialized
INFO - 2024-03-25 10:59:28 --> Hooks Class Initialized
DEBUG - 2024-03-25 10:59:28 --> UTF-8 Support Enabled
INFO - 2024-03-25 10:59:28 --> Utf8 Class Initialized
INFO - 2024-03-25 10:59:28 --> URI Class Initialized
DEBUG - 2024-03-25 10:59:28 --> No URI present. Default controller set.
INFO - 2024-03-25 10:59:28 --> Router Class Initialized
INFO - 2024-03-25 10:59:28 --> Output Class Initialized
INFO - 2024-03-25 10:59:28 --> Security Class Initialized
DEBUG - 2024-03-25 10:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 10:59:28 --> Input Class Initialized
INFO - 2024-03-25 10:59:28 --> Language Class Initialized
INFO - 2024-03-25 10:59:28 --> Loader Class Initialized
INFO - 2024-03-25 10:59:28 --> Helper loaded: url_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: file_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: html_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: text_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: form_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: lang_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: security_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: cookie_helper
INFO - 2024-03-25 10:59:28 --> Database Driver Class Initialized
INFO - 2024-03-25 10:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 10:59:28 --> Parser Class Initialized
INFO - 2024-03-25 10:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 10:59:28 --> Pagination Class Initialized
INFO - 2024-03-25 10:59:28 --> Form Validation Class Initialized
INFO - 2024-03-25 10:59:28 --> Controller Class Initialized
INFO - 2024-03-25 10:59:28 --> Model Class Initialized
DEBUG - 2024-03-25 10:59:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 10:59:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 10:59:28 --> Config Class Initialized
INFO - 2024-03-25 10:59:28 --> Hooks Class Initialized
DEBUG - 2024-03-25 10:59:28 --> UTF-8 Support Enabled
INFO - 2024-03-25 10:59:28 --> Utf8 Class Initialized
INFO - 2024-03-25 10:59:28 --> URI Class Initialized
INFO - 2024-03-25 10:59:28 --> Router Class Initialized
INFO - 2024-03-25 10:59:28 --> Output Class Initialized
INFO - 2024-03-25 10:59:28 --> Security Class Initialized
DEBUG - 2024-03-25 10:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 10:59:28 --> Input Class Initialized
INFO - 2024-03-25 10:59:28 --> Language Class Initialized
INFO - 2024-03-25 10:59:28 --> Loader Class Initialized
INFO - 2024-03-25 10:59:28 --> Helper loaded: url_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: file_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: html_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: text_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: form_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: lang_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: security_helper
INFO - 2024-03-25 10:59:28 --> Helper loaded: cookie_helper
INFO - 2024-03-25 10:59:28 --> Database Driver Class Initialized
INFO - 2024-03-25 10:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 10:59:28 --> Parser Class Initialized
INFO - 2024-03-25 10:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 10:59:28 --> Pagination Class Initialized
INFO - 2024-03-25 10:59:28 --> Form Validation Class Initialized
INFO - 2024-03-25 10:59:28 --> Controller Class Initialized
INFO - 2024-03-25 10:59:28 --> Model Class Initialized
DEBUG - 2024-03-25 10:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-25 10:59:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 10:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 10:59:28 --> Model Class Initialized
INFO - 2024-03-25 10:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 10:59:28 --> Final output sent to browser
DEBUG - 2024-03-25 10:59:28 --> Total execution time: 0.0339
ERROR - 2024-03-25 10:59:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 10:59:45 --> Config Class Initialized
INFO - 2024-03-25 10:59:45 --> Hooks Class Initialized
DEBUG - 2024-03-25 10:59:45 --> UTF-8 Support Enabled
INFO - 2024-03-25 10:59:45 --> Utf8 Class Initialized
INFO - 2024-03-25 10:59:45 --> URI Class Initialized
INFO - 2024-03-25 10:59:45 --> Router Class Initialized
INFO - 2024-03-25 10:59:45 --> Output Class Initialized
INFO - 2024-03-25 10:59:45 --> Security Class Initialized
DEBUG - 2024-03-25 10:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 10:59:45 --> Input Class Initialized
INFO - 2024-03-25 10:59:45 --> Language Class Initialized
INFO - 2024-03-25 10:59:45 --> Loader Class Initialized
INFO - 2024-03-25 10:59:45 --> Helper loaded: url_helper
INFO - 2024-03-25 10:59:45 --> Helper loaded: file_helper
INFO - 2024-03-25 10:59:45 --> Helper loaded: html_helper
INFO - 2024-03-25 10:59:45 --> Helper loaded: text_helper
INFO - 2024-03-25 10:59:45 --> Helper loaded: form_helper
INFO - 2024-03-25 10:59:45 --> Helper loaded: lang_helper
INFO - 2024-03-25 10:59:45 --> Helper loaded: security_helper
INFO - 2024-03-25 10:59:45 --> Helper loaded: cookie_helper
INFO - 2024-03-25 10:59:45 --> Database Driver Class Initialized
INFO - 2024-03-25 10:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 10:59:45 --> Parser Class Initialized
INFO - 2024-03-25 10:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 10:59:45 --> Pagination Class Initialized
INFO - 2024-03-25 10:59:45 --> Form Validation Class Initialized
INFO - 2024-03-25 10:59:45 --> Controller Class Initialized
INFO - 2024-03-25 10:59:45 --> Model Class Initialized
DEBUG - 2024-03-25 10:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:45 --> Model Class Initialized
INFO - 2024-03-25 10:59:45 --> Final output sent to browser
DEBUG - 2024-03-25 10:59:45 --> Total execution time: 0.0202
ERROR - 2024-03-25 10:59:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 10:59:46 --> Config Class Initialized
INFO - 2024-03-25 10:59:46 --> Hooks Class Initialized
DEBUG - 2024-03-25 10:59:46 --> UTF-8 Support Enabled
INFO - 2024-03-25 10:59:46 --> Utf8 Class Initialized
INFO - 2024-03-25 10:59:46 --> URI Class Initialized
DEBUG - 2024-03-25 10:59:46 --> No URI present. Default controller set.
INFO - 2024-03-25 10:59:46 --> Router Class Initialized
INFO - 2024-03-25 10:59:46 --> Output Class Initialized
INFO - 2024-03-25 10:59:46 --> Security Class Initialized
DEBUG - 2024-03-25 10:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 10:59:46 --> Input Class Initialized
INFO - 2024-03-25 10:59:46 --> Language Class Initialized
INFO - 2024-03-25 10:59:46 --> Loader Class Initialized
INFO - 2024-03-25 10:59:46 --> Helper loaded: url_helper
INFO - 2024-03-25 10:59:46 --> Helper loaded: file_helper
INFO - 2024-03-25 10:59:46 --> Helper loaded: html_helper
INFO - 2024-03-25 10:59:46 --> Helper loaded: text_helper
INFO - 2024-03-25 10:59:46 --> Helper loaded: form_helper
INFO - 2024-03-25 10:59:46 --> Helper loaded: lang_helper
INFO - 2024-03-25 10:59:46 --> Helper loaded: security_helper
INFO - 2024-03-25 10:59:46 --> Helper loaded: cookie_helper
INFO - 2024-03-25 10:59:46 --> Database Driver Class Initialized
INFO - 2024-03-25 10:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 10:59:46 --> Parser Class Initialized
INFO - 2024-03-25 10:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 10:59:46 --> Pagination Class Initialized
INFO - 2024-03-25 10:59:46 --> Form Validation Class Initialized
INFO - 2024-03-25 10:59:46 --> Controller Class Initialized
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
DEBUG - 2024-03-25 10:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
DEBUG - 2024-03-25 10:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
DEBUG - 2024-03-25 10:59:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 10:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
INFO - 2024-03-25 10:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 10:59:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 10:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 10:59:46 --> Model Class Initialized
INFO - 2024-03-25 10:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 10:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 10:59:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 10:59:46 --> Final output sent to browser
DEBUG - 2024-03-25 10:59:46 --> Total execution time: 0.4360
ERROR - 2024-03-25 10:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 10:59:48 --> Config Class Initialized
INFO - 2024-03-25 10:59:48 --> Hooks Class Initialized
DEBUG - 2024-03-25 10:59:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 10:59:48 --> Utf8 Class Initialized
INFO - 2024-03-25 10:59:48 --> URI Class Initialized
INFO - 2024-03-25 10:59:48 --> Router Class Initialized
INFO - 2024-03-25 10:59:48 --> Output Class Initialized
INFO - 2024-03-25 10:59:48 --> Security Class Initialized
DEBUG - 2024-03-25 10:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 10:59:48 --> Input Class Initialized
INFO - 2024-03-25 10:59:48 --> Language Class Initialized
INFO - 2024-03-25 10:59:48 --> Loader Class Initialized
INFO - 2024-03-25 10:59:48 --> Helper loaded: url_helper
INFO - 2024-03-25 10:59:48 --> Helper loaded: file_helper
INFO - 2024-03-25 10:59:48 --> Helper loaded: html_helper
INFO - 2024-03-25 10:59:48 --> Helper loaded: text_helper
INFO - 2024-03-25 10:59:48 --> Helper loaded: form_helper
INFO - 2024-03-25 10:59:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 10:59:48 --> Helper loaded: security_helper
INFO - 2024-03-25 10:59:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 10:59:48 --> Database Driver Class Initialized
INFO - 2024-03-25 10:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 10:59:48 --> Parser Class Initialized
INFO - 2024-03-25 10:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 10:59:48 --> Pagination Class Initialized
INFO - 2024-03-25 10:59:48 --> Form Validation Class Initialized
INFO - 2024-03-25 10:59:48 --> Controller Class Initialized
DEBUG - 2024-03-25 10:59:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 10:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 10:59:48 --> Model Class Initialized
INFO - 2024-03-25 10:59:48 --> Final output sent to browser
DEBUG - 2024-03-25 10:59:48 --> Total execution time: 0.0130
ERROR - 2024-03-25 13:34:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:34:49 --> Config Class Initialized
INFO - 2024-03-25 13:34:49 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:34:49 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:34:49 --> Utf8 Class Initialized
INFO - 2024-03-25 13:34:49 --> URI Class Initialized
DEBUG - 2024-03-25 13:34:49 --> No URI present. Default controller set.
INFO - 2024-03-25 13:34:49 --> Router Class Initialized
INFO - 2024-03-25 13:34:49 --> Output Class Initialized
INFO - 2024-03-25 13:34:49 --> Security Class Initialized
DEBUG - 2024-03-25 13:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:34:49 --> Input Class Initialized
INFO - 2024-03-25 13:34:49 --> Language Class Initialized
INFO - 2024-03-25 13:34:49 --> Loader Class Initialized
INFO - 2024-03-25 13:34:49 --> Helper loaded: url_helper
INFO - 2024-03-25 13:34:49 --> Helper loaded: file_helper
INFO - 2024-03-25 13:34:49 --> Helper loaded: html_helper
INFO - 2024-03-25 13:34:49 --> Helper loaded: text_helper
INFO - 2024-03-25 13:34:49 --> Helper loaded: form_helper
INFO - 2024-03-25 13:34:49 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:34:49 --> Helper loaded: security_helper
INFO - 2024-03-25 13:34:49 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:34:49 --> Database Driver Class Initialized
INFO - 2024-03-25 13:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:34:49 --> Parser Class Initialized
INFO - 2024-03-25 13:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:34:49 --> Pagination Class Initialized
INFO - 2024-03-25 13:34:49 --> Form Validation Class Initialized
INFO - 2024-03-25 13:34:49 --> Controller Class Initialized
INFO - 2024-03-25 13:34:49 --> Model Class Initialized
DEBUG - 2024-03-25 13:34:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 13:34:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:34:50 --> Config Class Initialized
INFO - 2024-03-25 13:34:50 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:34:50 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:34:50 --> Utf8 Class Initialized
INFO - 2024-03-25 13:34:50 --> URI Class Initialized
INFO - 2024-03-25 13:34:50 --> Router Class Initialized
INFO - 2024-03-25 13:34:50 --> Output Class Initialized
INFO - 2024-03-25 13:34:50 --> Security Class Initialized
DEBUG - 2024-03-25 13:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:34:50 --> Input Class Initialized
INFO - 2024-03-25 13:34:50 --> Language Class Initialized
INFO - 2024-03-25 13:34:50 --> Loader Class Initialized
INFO - 2024-03-25 13:34:50 --> Helper loaded: url_helper
INFO - 2024-03-25 13:34:50 --> Helper loaded: file_helper
INFO - 2024-03-25 13:34:50 --> Helper loaded: html_helper
INFO - 2024-03-25 13:34:50 --> Helper loaded: text_helper
INFO - 2024-03-25 13:34:50 --> Helper loaded: form_helper
INFO - 2024-03-25 13:34:50 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:34:50 --> Helper loaded: security_helper
INFO - 2024-03-25 13:34:50 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:34:50 --> Database Driver Class Initialized
INFO - 2024-03-25 13:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:34:50 --> Parser Class Initialized
INFO - 2024-03-25 13:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:34:50 --> Pagination Class Initialized
INFO - 2024-03-25 13:34:50 --> Form Validation Class Initialized
INFO - 2024-03-25 13:34:50 --> Controller Class Initialized
INFO - 2024-03-25 13:34:50 --> Model Class Initialized
DEBUG - 2024-03-25 13:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-25 13:34:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 13:34:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 13:34:50 --> Model Class Initialized
INFO - 2024-03-25 13:34:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 13:34:50 --> Final output sent to browser
DEBUG - 2024-03-25 13:34:50 --> Total execution time: 0.0394
ERROR - 2024-03-25 13:34:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:34:54 --> Config Class Initialized
INFO - 2024-03-25 13:34:54 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:34:54 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:34:54 --> Utf8 Class Initialized
INFO - 2024-03-25 13:34:54 --> URI Class Initialized
INFO - 2024-03-25 13:34:54 --> Router Class Initialized
INFO - 2024-03-25 13:34:54 --> Output Class Initialized
INFO - 2024-03-25 13:34:54 --> Security Class Initialized
DEBUG - 2024-03-25 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:34:54 --> Input Class Initialized
INFO - 2024-03-25 13:34:54 --> Language Class Initialized
INFO - 2024-03-25 13:34:54 --> Loader Class Initialized
INFO - 2024-03-25 13:34:54 --> Helper loaded: url_helper
INFO - 2024-03-25 13:34:54 --> Helper loaded: file_helper
INFO - 2024-03-25 13:34:54 --> Helper loaded: html_helper
INFO - 2024-03-25 13:34:54 --> Helper loaded: text_helper
INFO - 2024-03-25 13:34:54 --> Helper loaded: form_helper
INFO - 2024-03-25 13:34:54 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:34:54 --> Helper loaded: security_helper
INFO - 2024-03-25 13:34:54 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:34:54 --> Database Driver Class Initialized
INFO - 2024-03-25 13:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:34:54 --> Parser Class Initialized
INFO - 2024-03-25 13:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:34:54 --> Pagination Class Initialized
INFO - 2024-03-25 13:34:54 --> Form Validation Class Initialized
INFO - 2024-03-25 13:34:54 --> Controller Class Initialized
INFO - 2024-03-25 13:34:54 --> Model Class Initialized
DEBUG - 2024-03-25 13:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:54 --> Model Class Initialized
INFO - 2024-03-25 13:34:54 --> Final output sent to browser
DEBUG - 2024-03-25 13:34:54 --> Total execution time: 0.0190
ERROR - 2024-03-25 13:34:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:34:55 --> Config Class Initialized
INFO - 2024-03-25 13:34:55 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:34:55 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:34:55 --> Utf8 Class Initialized
INFO - 2024-03-25 13:34:55 --> URI Class Initialized
DEBUG - 2024-03-25 13:34:55 --> No URI present. Default controller set.
INFO - 2024-03-25 13:34:55 --> Router Class Initialized
INFO - 2024-03-25 13:34:55 --> Output Class Initialized
INFO - 2024-03-25 13:34:55 --> Security Class Initialized
DEBUG - 2024-03-25 13:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:34:55 --> Input Class Initialized
INFO - 2024-03-25 13:34:55 --> Language Class Initialized
INFO - 2024-03-25 13:34:55 --> Loader Class Initialized
INFO - 2024-03-25 13:34:55 --> Helper loaded: url_helper
INFO - 2024-03-25 13:34:55 --> Helper loaded: file_helper
INFO - 2024-03-25 13:34:55 --> Helper loaded: html_helper
INFO - 2024-03-25 13:34:55 --> Helper loaded: text_helper
INFO - 2024-03-25 13:34:55 --> Helper loaded: form_helper
INFO - 2024-03-25 13:34:55 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:34:55 --> Helper loaded: security_helper
INFO - 2024-03-25 13:34:55 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:34:55 --> Database Driver Class Initialized
INFO - 2024-03-25 13:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:34:55 --> Parser Class Initialized
INFO - 2024-03-25 13:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:34:55 --> Pagination Class Initialized
INFO - 2024-03-25 13:34:55 --> Form Validation Class Initialized
INFO - 2024-03-25 13:34:55 --> Controller Class Initialized
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
DEBUG - 2024-03-25 13:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
DEBUG - 2024-03-25 13:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
DEBUG - 2024-03-25 13:34:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
INFO - 2024-03-25 13:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 13:34:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 13:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 13:34:55 --> Model Class Initialized
INFO - 2024-03-25 13:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 13:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 13:34:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 13:34:55 --> Final output sent to browser
DEBUG - 2024-03-25 13:34:55 --> Total execution time: 0.4678
ERROR - 2024-03-25 13:34:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:34:57 --> Config Class Initialized
INFO - 2024-03-25 13:34:57 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:34:57 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:34:57 --> Utf8 Class Initialized
INFO - 2024-03-25 13:34:57 --> URI Class Initialized
INFO - 2024-03-25 13:34:57 --> Router Class Initialized
INFO - 2024-03-25 13:34:57 --> Output Class Initialized
INFO - 2024-03-25 13:34:57 --> Security Class Initialized
DEBUG - 2024-03-25 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:34:57 --> Input Class Initialized
INFO - 2024-03-25 13:34:57 --> Language Class Initialized
INFO - 2024-03-25 13:34:57 --> Loader Class Initialized
INFO - 2024-03-25 13:34:57 --> Helper loaded: url_helper
INFO - 2024-03-25 13:34:57 --> Helper loaded: file_helper
INFO - 2024-03-25 13:34:57 --> Helper loaded: html_helper
INFO - 2024-03-25 13:34:57 --> Helper loaded: text_helper
INFO - 2024-03-25 13:34:57 --> Helper loaded: form_helper
INFO - 2024-03-25 13:34:57 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:34:57 --> Helper loaded: security_helper
INFO - 2024-03-25 13:34:57 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:34:57 --> Database Driver Class Initialized
INFO - 2024-03-25 13:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:34:57 --> Parser Class Initialized
INFO - 2024-03-25 13:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:34:57 --> Pagination Class Initialized
INFO - 2024-03-25 13:34:57 --> Form Validation Class Initialized
INFO - 2024-03-25 13:34:57 --> Controller Class Initialized
DEBUG - 2024-03-25 13:34:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:34:57 --> Model Class Initialized
INFO - 2024-03-25 13:34:57 --> Final output sent to browser
DEBUG - 2024-03-25 13:34:57 --> Total execution time: 0.0135
ERROR - 2024-03-25 13:35:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:28 --> Config Class Initialized
INFO - 2024-03-25 13:35:28 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:28 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:28 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:28 --> URI Class Initialized
INFO - 2024-03-25 13:35:28 --> Router Class Initialized
INFO - 2024-03-25 13:35:28 --> Output Class Initialized
INFO - 2024-03-25 13:35:28 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:28 --> Input Class Initialized
INFO - 2024-03-25 13:35:28 --> Language Class Initialized
INFO - 2024-03-25 13:35:28 --> Loader Class Initialized
INFO - 2024-03-25 13:35:28 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:28 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:28 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:28 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:28 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:28 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:28 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:28 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:28 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:28 --> Parser Class Initialized
INFO - 2024-03-25 13:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:28 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:28 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:28 --> Controller Class Initialized
INFO - 2024-03-25 13:35:28 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:28 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:28 --> Model Class Initialized
INFO - 2024-03-25 13:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-25 13:35:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 13:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 13:35:28 --> Model Class Initialized
INFO - 2024-03-25 13:35:28 --> Model Class Initialized
INFO - 2024-03-25 13:35:28 --> Model Class Initialized
INFO - 2024-03-25 13:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 13:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 13:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 13:35:28 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:28 --> Total execution time: 0.2351
ERROR - 2024-03-25 13:35:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:29 --> Config Class Initialized
INFO - 2024-03-25 13:35:29 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:29 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:29 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:29 --> URI Class Initialized
INFO - 2024-03-25 13:35:29 --> Router Class Initialized
INFO - 2024-03-25 13:35:29 --> Output Class Initialized
INFO - 2024-03-25 13:35:29 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:29 --> Input Class Initialized
INFO - 2024-03-25 13:35:29 --> Language Class Initialized
INFO - 2024-03-25 13:35:29 --> Loader Class Initialized
INFO - 2024-03-25 13:35:29 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:29 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:29 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:29 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:29 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:29 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:29 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:29 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:29 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:29 --> Parser Class Initialized
INFO - 2024-03-25 13:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:29 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:29 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:29 --> Controller Class Initialized
INFO - 2024-03-25 13:35:29 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:29 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:29 --> Model Class Initialized
INFO - 2024-03-25 13:35:29 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:29 --> Total execution time: 0.0659
ERROR - 2024-03-25 13:35:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:46 --> Config Class Initialized
INFO - 2024-03-25 13:35:46 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:46 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:46 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:46 --> URI Class Initialized
INFO - 2024-03-25 13:35:46 --> Router Class Initialized
INFO - 2024-03-25 13:35:46 --> Output Class Initialized
INFO - 2024-03-25 13:35:46 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:46 --> Input Class Initialized
INFO - 2024-03-25 13:35:46 --> Language Class Initialized
INFO - 2024-03-25 13:35:46 --> Loader Class Initialized
INFO - 2024-03-25 13:35:46 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:46 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:46 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:46 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:46 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:46 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:46 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:46 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:46 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:46 --> Parser Class Initialized
INFO - 2024-03-25 13:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:46 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:46 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:46 --> Controller Class Initialized
INFO - 2024-03-25 13:35:46 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:46 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:46 --> Model Class Initialized
ERROR - 2024-03-25 13:35:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2024-03-25 13:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2024-03-25 13:35:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 13:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 13:35:46 --> Model Class Initialized
INFO - 2024-03-25 13:35:46 --> Model Class Initialized
INFO - 2024-03-25 13:35:46 --> Model Class Initialized
INFO - 2024-03-25 13:35:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 13:35:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 13:35:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 13:35:47 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:47 --> Total execution time: 0.2794
ERROR - 2024-03-25 13:35:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:47 --> Config Class Initialized
INFO - 2024-03-25 13:35:47 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:47 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:47 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:47 --> URI Class Initialized
INFO - 2024-03-25 13:35:47 --> Router Class Initialized
INFO - 2024-03-25 13:35:47 --> Output Class Initialized
INFO - 2024-03-25 13:35:47 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:47 --> Input Class Initialized
INFO - 2024-03-25 13:35:47 --> Language Class Initialized
INFO - 2024-03-25 13:35:47 --> Loader Class Initialized
INFO - 2024-03-25 13:35:47 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:47 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:47 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:47 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:47 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:47 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:47 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:47 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:47 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:47 --> Parser Class Initialized
INFO - 2024-03-25 13:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:47 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:47 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0250
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0198
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0269
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0377
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0373
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0435
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0462
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 13:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:48 --> Config Class Initialized
INFO - 2024-03-25 13:35:48 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:48 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:48 --> URI Class Initialized
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0199
INFO - 2024-03-25 13:35:48 --> Router Class Initialized
INFO - 2024-03-25 13:35:48 --> Output Class Initialized
INFO - 2024-03-25 13:35:48 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:48 --> Input Class Initialized
INFO - 2024-03-25 13:35:48 --> Language Class Initialized
INFO - 2024-03-25 13:35:48 --> Loader Class Initialized
INFO - 2024-03-25 13:35:48 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:48 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:48 --> Parser Class Initialized
INFO - 2024-03-25 13:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:48 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:48 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:48 --> Controller Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
INFO - 2024-03-25 13:35:48 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:48 --> Final output sent to browser
DEBUG - 2024-03-25 13:35:48 --> Total execution time: 0.0250
ERROR - 2024-03-25 13:35:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 13:35:59 --> Config Class Initialized
INFO - 2024-03-25 13:35:59 --> Hooks Class Initialized
DEBUG - 2024-03-25 13:35:59 --> UTF-8 Support Enabled
INFO - 2024-03-25 13:35:59 --> Utf8 Class Initialized
INFO - 2024-03-25 13:35:59 --> URI Class Initialized
DEBUG - 2024-03-25 13:35:59 --> No URI present. Default controller set.
INFO - 2024-03-25 13:35:59 --> Router Class Initialized
INFO - 2024-03-25 13:35:59 --> Output Class Initialized
INFO - 2024-03-25 13:35:59 --> Security Class Initialized
DEBUG - 2024-03-25 13:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 13:35:59 --> Input Class Initialized
INFO - 2024-03-25 13:35:59 --> Language Class Initialized
INFO - 2024-03-25 13:35:59 --> Loader Class Initialized
INFO - 2024-03-25 13:35:59 --> Helper loaded: url_helper
INFO - 2024-03-25 13:35:59 --> Helper loaded: file_helper
INFO - 2024-03-25 13:35:59 --> Helper loaded: html_helper
INFO - 2024-03-25 13:35:59 --> Helper loaded: text_helper
INFO - 2024-03-25 13:35:59 --> Helper loaded: form_helper
INFO - 2024-03-25 13:35:59 --> Helper loaded: lang_helper
INFO - 2024-03-25 13:35:59 --> Helper loaded: security_helper
INFO - 2024-03-25 13:35:59 --> Helper loaded: cookie_helper
INFO - 2024-03-25 13:35:59 --> Database Driver Class Initialized
INFO - 2024-03-25 13:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 13:35:59 --> Parser Class Initialized
INFO - 2024-03-25 13:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 13:35:59 --> Pagination Class Initialized
INFO - 2024-03-25 13:35:59 --> Form Validation Class Initialized
INFO - 2024-03-25 13:35:59 --> Controller Class Initialized
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
DEBUG - 2024-03-25 13:35:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 13:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
INFO - 2024-03-25 13:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 13:35:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 13:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 13:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 13:35:59 --> Model Class Initialized
INFO - 2024-03-25 13:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 13:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 13:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 13:36:00 --> Final output sent to browser
DEBUG - 2024-03-25 13:36:00 --> Total execution time: 0.4457
ERROR - 2024-03-25 14:26:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 14:26:18 --> Config Class Initialized
INFO - 2024-03-25 14:26:18 --> Hooks Class Initialized
DEBUG - 2024-03-25 14:26:18 --> UTF-8 Support Enabled
INFO - 2024-03-25 14:26:18 --> Utf8 Class Initialized
INFO - 2024-03-25 14:26:18 --> URI Class Initialized
INFO - 2024-03-25 14:26:18 --> Router Class Initialized
INFO - 2024-03-25 14:26:18 --> Output Class Initialized
INFO - 2024-03-25 14:26:18 --> Security Class Initialized
DEBUG - 2024-03-25 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 14:26:18 --> Input Class Initialized
INFO - 2024-03-25 14:26:18 --> Language Class Initialized
ERROR - 2024-03-25 14:26:18 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-03-25 15:59:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 15:59:26 --> Config Class Initialized
INFO - 2024-03-25 15:59:26 --> Hooks Class Initialized
DEBUG - 2024-03-25 15:59:26 --> UTF-8 Support Enabled
INFO - 2024-03-25 15:59:26 --> Utf8 Class Initialized
INFO - 2024-03-25 15:59:26 --> URI Class Initialized
DEBUG - 2024-03-25 15:59:26 --> No URI present. Default controller set.
INFO - 2024-03-25 15:59:26 --> Router Class Initialized
INFO - 2024-03-25 15:59:26 --> Output Class Initialized
INFO - 2024-03-25 15:59:26 --> Security Class Initialized
DEBUG - 2024-03-25 15:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 15:59:26 --> Input Class Initialized
INFO - 2024-03-25 15:59:26 --> Language Class Initialized
INFO - 2024-03-25 15:59:26 --> Loader Class Initialized
INFO - 2024-03-25 15:59:26 --> Helper loaded: url_helper
INFO - 2024-03-25 15:59:26 --> Helper loaded: file_helper
INFO - 2024-03-25 15:59:26 --> Helper loaded: html_helper
INFO - 2024-03-25 15:59:26 --> Helper loaded: text_helper
INFO - 2024-03-25 15:59:26 --> Helper loaded: form_helper
INFO - 2024-03-25 15:59:26 --> Helper loaded: lang_helper
INFO - 2024-03-25 15:59:26 --> Helper loaded: security_helper
INFO - 2024-03-25 15:59:26 --> Helper loaded: cookie_helper
INFO - 2024-03-25 15:59:26 --> Database Driver Class Initialized
INFO - 2024-03-25 15:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 15:59:26 --> Parser Class Initialized
INFO - 2024-03-25 15:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 15:59:26 --> Pagination Class Initialized
INFO - 2024-03-25 15:59:26 --> Form Validation Class Initialized
INFO - 2024-03-25 15:59:26 --> Controller Class Initialized
INFO - 2024-03-25 15:59:26 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 15:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 15:59:27 --> Config Class Initialized
INFO - 2024-03-25 15:59:27 --> Hooks Class Initialized
DEBUG - 2024-03-25 15:59:27 --> UTF-8 Support Enabled
INFO - 2024-03-25 15:59:27 --> Utf8 Class Initialized
INFO - 2024-03-25 15:59:27 --> URI Class Initialized
INFO - 2024-03-25 15:59:27 --> Router Class Initialized
INFO - 2024-03-25 15:59:27 --> Output Class Initialized
INFO - 2024-03-25 15:59:27 --> Security Class Initialized
DEBUG - 2024-03-25 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 15:59:27 --> Input Class Initialized
INFO - 2024-03-25 15:59:27 --> Language Class Initialized
INFO - 2024-03-25 15:59:27 --> Loader Class Initialized
INFO - 2024-03-25 15:59:27 --> Helper loaded: url_helper
INFO - 2024-03-25 15:59:27 --> Helper loaded: file_helper
INFO - 2024-03-25 15:59:27 --> Helper loaded: html_helper
INFO - 2024-03-25 15:59:27 --> Helper loaded: text_helper
INFO - 2024-03-25 15:59:27 --> Helper loaded: form_helper
INFO - 2024-03-25 15:59:27 --> Helper loaded: lang_helper
INFO - 2024-03-25 15:59:27 --> Helper loaded: security_helper
INFO - 2024-03-25 15:59:27 --> Helper loaded: cookie_helper
INFO - 2024-03-25 15:59:27 --> Database Driver Class Initialized
INFO - 2024-03-25 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 15:59:27 --> Parser Class Initialized
INFO - 2024-03-25 15:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 15:59:27 --> Pagination Class Initialized
INFO - 2024-03-25 15:59:27 --> Form Validation Class Initialized
INFO - 2024-03-25 15:59:27 --> Controller Class Initialized
INFO - 2024-03-25 15:59:27 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-25 15:59:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 15:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 15:59:27 --> Model Class Initialized
INFO - 2024-03-25 15:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 15:59:27 --> Final output sent to browser
DEBUG - 2024-03-25 15:59:27 --> Total execution time: 0.0335
ERROR - 2024-03-25 15:59:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 15:59:41 --> Config Class Initialized
INFO - 2024-03-25 15:59:41 --> Hooks Class Initialized
DEBUG - 2024-03-25 15:59:41 --> UTF-8 Support Enabled
INFO - 2024-03-25 15:59:41 --> Utf8 Class Initialized
INFO - 2024-03-25 15:59:41 --> URI Class Initialized
INFO - 2024-03-25 15:59:41 --> Router Class Initialized
INFO - 2024-03-25 15:59:41 --> Output Class Initialized
INFO - 2024-03-25 15:59:41 --> Security Class Initialized
DEBUG - 2024-03-25 15:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 15:59:41 --> Input Class Initialized
INFO - 2024-03-25 15:59:41 --> Language Class Initialized
INFO - 2024-03-25 15:59:41 --> Loader Class Initialized
INFO - 2024-03-25 15:59:41 --> Helper loaded: url_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: file_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: html_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: text_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: form_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: lang_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: security_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: cookie_helper
INFO - 2024-03-25 15:59:41 --> Database Driver Class Initialized
INFO - 2024-03-25 15:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 15:59:41 --> Parser Class Initialized
INFO - 2024-03-25 15:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 15:59:41 --> Pagination Class Initialized
INFO - 2024-03-25 15:59:41 --> Form Validation Class Initialized
INFO - 2024-03-25 15:59:41 --> Controller Class Initialized
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
INFO - 2024-03-25 15:59:41 --> Final output sent to browser
DEBUG - 2024-03-25 15:59:41 --> Total execution time: 0.0209
ERROR - 2024-03-25 15:59:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 15:59:41 --> Config Class Initialized
INFO - 2024-03-25 15:59:41 --> Hooks Class Initialized
DEBUG - 2024-03-25 15:59:41 --> UTF-8 Support Enabled
INFO - 2024-03-25 15:59:41 --> Utf8 Class Initialized
INFO - 2024-03-25 15:59:41 --> URI Class Initialized
DEBUG - 2024-03-25 15:59:41 --> No URI present. Default controller set.
INFO - 2024-03-25 15:59:41 --> Router Class Initialized
INFO - 2024-03-25 15:59:41 --> Output Class Initialized
INFO - 2024-03-25 15:59:41 --> Security Class Initialized
DEBUG - 2024-03-25 15:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 15:59:41 --> Input Class Initialized
INFO - 2024-03-25 15:59:41 --> Language Class Initialized
INFO - 2024-03-25 15:59:41 --> Loader Class Initialized
INFO - 2024-03-25 15:59:41 --> Helper loaded: url_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: file_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: html_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: text_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: form_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: lang_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: security_helper
INFO - 2024-03-25 15:59:41 --> Helper loaded: cookie_helper
INFO - 2024-03-25 15:59:41 --> Database Driver Class Initialized
INFO - 2024-03-25 15:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 15:59:41 --> Parser Class Initialized
INFO - 2024-03-25 15:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 15:59:41 --> Pagination Class Initialized
INFO - 2024-03-25 15:59:41 --> Form Validation Class Initialized
INFO - 2024-03-25 15:59:41 --> Controller Class Initialized
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 15:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
INFO - 2024-03-25 15:59:41 --> Model Class Initialized
INFO - 2024-03-25 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 15:59:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 15:59:42 --> Model Class Initialized
INFO - 2024-03-25 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 15:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 15:59:42 --> Final output sent to browser
DEBUG - 2024-03-25 15:59:42 --> Total execution time: 0.2472
ERROR - 2024-03-25 15:59:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 15:59:50 --> Config Class Initialized
INFO - 2024-03-25 15:59:50 --> Hooks Class Initialized
DEBUG - 2024-03-25 15:59:50 --> UTF-8 Support Enabled
INFO - 2024-03-25 15:59:50 --> Utf8 Class Initialized
INFO - 2024-03-25 15:59:50 --> URI Class Initialized
INFO - 2024-03-25 15:59:50 --> Router Class Initialized
INFO - 2024-03-25 15:59:50 --> Output Class Initialized
INFO - 2024-03-25 15:59:50 --> Security Class Initialized
DEBUG - 2024-03-25 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 15:59:50 --> Input Class Initialized
INFO - 2024-03-25 15:59:50 --> Language Class Initialized
INFO - 2024-03-25 15:59:50 --> Loader Class Initialized
INFO - 2024-03-25 15:59:50 --> Helper loaded: url_helper
INFO - 2024-03-25 15:59:50 --> Helper loaded: file_helper
INFO - 2024-03-25 15:59:50 --> Helper loaded: html_helper
INFO - 2024-03-25 15:59:50 --> Helper loaded: text_helper
INFO - 2024-03-25 15:59:50 --> Helper loaded: form_helper
INFO - 2024-03-25 15:59:50 --> Helper loaded: lang_helper
INFO - 2024-03-25 15:59:50 --> Helper loaded: security_helper
INFO - 2024-03-25 15:59:50 --> Helper loaded: cookie_helper
INFO - 2024-03-25 15:59:50 --> Database Driver Class Initialized
INFO - 2024-03-25 15:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 15:59:50 --> Parser Class Initialized
INFO - 2024-03-25 15:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 15:59:50 --> Pagination Class Initialized
INFO - 2024-03-25 15:59:50 --> Form Validation Class Initialized
INFO - 2024-03-25 15:59:50 --> Controller Class Initialized
INFO - 2024-03-25 15:59:50 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 15:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:50 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:50 --> Model Class Initialized
INFO - 2024-03-25 15:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-25 15:59:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 15:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 15:59:50 --> Model Class Initialized
INFO - 2024-03-25 15:59:50 --> Model Class Initialized
INFO - 2024-03-25 15:59:50 --> Model Class Initialized
INFO - 2024-03-25 15:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 15:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 15:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 15:59:50 --> Final output sent to browser
DEBUG - 2024-03-25 15:59:50 --> Total execution time: 0.1609
ERROR - 2024-03-25 15:59:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 15:59:51 --> Config Class Initialized
INFO - 2024-03-25 15:59:51 --> Hooks Class Initialized
DEBUG - 2024-03-25 15:59:51 --> UTF-8 Support Enabled
INFO - 2024-03-25 15:59:51 --> Utf8 Class Initialized
INFO - 2024-03-25 15:59:51 --> URI Class Initialized
INFO - 2024-03-25 15:59:51 --> Router Class Initialized
INFO - 2024-03-25 15:59:51 --> Output Class Initialized
INFO - 2024-03-25 15:59:51 --> Security Class Initialized
DEBUG - 2024-03-25 15:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 15:59:51 --> Input Class Initialized
INFO - 2024-03-25 15:59:51 --> Language Class Initialized
INFO - 2024-03-25 15:59:51 --> Loader Class Initialized
INFO - 2024-03-25 15:59:51 --> Helper loaded: url_helper
INFO - 2024-03-25 15:59:51 --> Helper loaded: file_helper
INFO - 2024-03-25 15:59:51 --> Helper loaded: html_helper
INFO - 2024-03-25 15:59:51 --> Helper loaded: text_helper
INFO - 2024-03-25 15:59:51 --> Helper loaded: form_helper
INFO - 2024-03-25 15:59:51 --> Helper loaded: lang_helper
INFO - 2024-03-25 15:59:51 --> Helper loaded: security_helper
INFO - 2024-03-25 15:59:51 --> Helper loaded: cookie_helper
INFO - 2024-03-25 15:59:51 --> Database Driver Class Initialized
INFO - 2024-03-25 15:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 15:59:51 --> Parser Class Initialized
INFO - 2024-03-25 15:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 15:59:51 --> Pagination Class Initialized
INFO - 2024-03-25 15:59:51 --> Form Validation Class Initialized
INFO - 2024-03-25 15:59:51 --> Controller Class Initialized
INFO - 2024-03-25 15:59:51 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 15:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:51 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:51 --> Model Class Initialized
INFO - 2024-03-25 15:59:51 --> Final output sent to browser
DEBUG - 2024-03-25 15:59:51 --> Total execution time: 0.0385
ERROR - 2024-03-25 15:59:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 15:59:55 --> Config Class Initialized
INFO - 2024-03-25 15:59:55 --> Hooks Class Initialized
DEBUG - 2024-03-25 15:59:55 --> UTF-8 Support Enabled
INFO - 2024-03-25 15:59:55 --> Utf8 Class Initialized
INFO - 2024-03-25 15:59:55 --> URI Class Initialized
DEBUG - 2024-03-25 15:59:55 --> No URI present. Default controller set.
INFO - 2024-03-25 15:59:55 --> Router Class Initialized
INFO - 2024-03-25 15:59:55 --> Output Class Initialized
INFO - 2024-03-25 15:59:55 --> Security Class Initialized
DEBUG - 2024-03-25 15:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 15:59:55 --> Input Class Initialized
INFO - 2024-03-25 15:59:55 --> Language Class Initialized
INFO - 2024-03-25 15:59:55 --> Loader Class Initialized
INFO - 2024-03-25 15:59:55 --> Helper loaded: url_helper
INFO - 2024-03-25 15:59:55 --> Helper loaded: file_helper
INFO - 2024-03-25 15:59:55 --> Helper loaded: html_helper
INFO - 2024-03-25 15:59:55 --> Helper loaded: text_helper
INFO - 2024-03-25 15:59:55 --> Helper loaded: form_helper
INFO - 2024-03-25 15:59:55 --> Helper loaded: lang_helper
INFO - 2024-03-25 15:59:55 --> Helper loaded: security_helper
INFO - 2024-03-25 15:59:55 --> Helper loaded: cookie_helper
INFO - 2024-03-25 15:59:55 --> Database Driver Class Initialized
INFO - 2024-03-25 15:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 15:59:55 --> Parser Class Initialized
INFO - 2024-03-25 15:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 15:59:55 --> Pagination Class Initialized
INFO - 2024-03-25 15:59:55 --> Form Validation Class Initialized
INFO - 2024-03-25 15:59:55 --> Controller Class Initialized
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
DEBUG - 2024-03-25 15:59:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 15:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
INFO - 2024-03-25 15:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 15:59:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 15:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 15:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 15:59:55 --> Model Class Initialized
INFO - 2024-03-25 15:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 15:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 15:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 15:59:55 --> Final output sent to browser
DEBUG - 2024-03-25 15:59:55 --> Total execution time: 0.2551
ERROR - 2024-03-25 16:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:02 --> Config Class Initialized
INFO - 2024-03-25 16:00:02 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:02 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:02 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:02 --> URI Class Initialized
INFO - 2024-03-25 16:00:02 --> Router Class Initialized
INFO - 2024-03-25 16:00:02 --> Output Class Initialized
INFO - 2024-03-25 16:00:02 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:02 --> Input Class Initialized
INFO - 2024-03-25 16:00:02 --> Language Class Initialized
INFO - 2024-03-25 16:00:02 --> Loader Class Initialized
INFO - 2024-03-25 16:00:02 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:02 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:02 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:02 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:02 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:02 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:02 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:02 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:02 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:02 --> Parser Class Initialized
INFO - 2024-03-25 16:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:02 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:02 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:02 --> Controller Class Initialized
INFO - 2024-03-25 16:00:02 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 16:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:02 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:02 --> Model Class Initialized
INFO - 2024-03-25 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-25 16:00:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 16:00:02 --> Model Class Initialized
INFO - 2024-03-25 16:00:02 --> Model Class Initialized
INFO - 2024-03-25 16:00:02 --> Model Class Initialized
INFO - 2024-03-25 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 16:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 16:00:02 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:02 --> Total execution time: 0.1981
ERROR - 2024-03-25 16:00:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:15 --> Config Class Initialized
INFO - 2024-03-25 16:00:15 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:15 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:15 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:15 --> URI Class Initialized
INFO - 2024-03-25 16:00:15 --> Router Class Initialized
INFO - 2024-03-25 16:00:15 --> Output Class Initialized
INFO - 2024-03-25 16:00:15 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:15 --> Input Class Initialized
INFO - 2024-03-25 16:00:15 --> Language Class Initialized
INFO - 2024-03-25 16:00:15 --> Loader Class Initialized
INFO - 2024-03-25 16:00:15 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:15 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:15 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:15 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:15 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:15 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:15 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:15 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:15 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:15 --> Parser Class Initialized
INFO - 2024-03-25 16:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:15 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:15 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:15 --> Controller Class Initialized
INFO - 2024-03-25 16:00:15 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:15 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:15 --> Total execution time: 0.0182
ERROR - 2024-03-25 16:00:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:16 --> Config Class Initialized
INFO - 2024-03-25 16:00:16 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:16 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:16 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:16 --> URI Class Initialized
INFO - 2024-03-25 16:00:16 --> Router Class Initialized
INFO - 2024-03-25 16:00:16 --> Output Class Initialized
INFO - 2024-03-25 16:00:16 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:16 --> Input Class Initialized
INFO - 2024-03-25 16:00:16 --> Language Class Initialized
INFO - 2024-03-25 16:00:16 --> Loader Class Initialized
INFO - 2024-03-25 16:00:16 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:16 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:16 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:16 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:16 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:16 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:16 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:16 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:16 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:16 --> Parser Class Initialized
INFO - 2024-03-25 16:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:16 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:16 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:16 --> Controller Class Initialized
INFO - 2024-03-25 16:00:16 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:16 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:16 --> Total execution time: 0.0148
ERROR - 2024-03-25 16:00:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:21 --> Config Class Initialized
INFO - 2024-03-25 16:00:21 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:21 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:21 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:21 --> URI Class Initialized
INFO - 2024-03-25 16:00:21 --> Router Class Initialized
INFO - 2024-03-25 16:00:21 --> Output Class Initialized
INFO - 2024-03-25 16:00:21 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:21 --> Input Class Initialized
INFO - 2024-03-25 16:00:21 --> Language Class Initialized
INFO - 2024-03-25 16:00:21 --> Loader Class Initialized
INFO - 2024-03-25 16:00:21 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:21 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:21 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:21 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:21 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:21 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:21 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:21 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:21 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:21 --> Parser Class Initialized
INFO - 2024-03-25 16:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:21 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:21 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:21 --> Controller Class Initialized
INFO - 2024-03-25 16:00:21 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:21 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:21 --> Total execution time: 0.0178
ERROR - 2024-03-25 16:00:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:27 --> Config Class Initialized
INFO - 2024-03-25 16:00:27 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:27 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:27 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:27 --> URI Class Initialized
INFO - 2024-03-25 16:00:27 --> Router Class Initialized
INFO - 2024-03-25 16:00:27 --> Output Class Initialized
INFO - 2024-03-25 16:00:27 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:27 --> Input Class Initialized
INFO - 2024-03-25 16:00:27 --> Language Class Initialized
INFO - 2024-03-25 16:00:27 --> Loader Class Initialized
INFO - 2024-03-25 16:00:27 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:27 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:27 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:27 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:27 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:27 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:27 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:27 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:27 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:27 --> Parser Class Initialized
INFO - 2024-03-25 16:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:27 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:27 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:27 --> Controller Class Initialized
INFO - 2024-03-25 16:00:27 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:27 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:27 --> Total execution time: 0.0182
ERROR - 2024-03-25 16:00:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:28 --> Config Class Initialized
INFO - 2024-03-25 16:00:28 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:28 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:28 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:28 --> URI Class Initialized
INFO - 2024-03-25 16:00:28 --> Router Class Initialized
INFO - 2024-03-25 16:00:28 --> Output Class Initialized
INFO - 2024-03-25 16:00:28 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:28 --> Input Class Initialized
INFO - 2024-03-25 16:00:28 --> Language Class Initialized
INFO - 2024-03-25 16:00:28 --> Loader Class Initialized
INFO - 2024-03-25 16:00:28 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:28 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:28 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:28 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:28 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:28 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:28 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:28 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:28 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:28 --> Parser Class Initialized
INFO - 2024-03-25 16:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:28 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:28 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:28 --> Controller Class Initialized
INFO - 2024-03-25 16:00:28 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-25 16:00:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-03-25 16:00:28 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:28 --> Total execution time: 0.0203
ERROR - 2024-03-25 16:00:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:31 --> Config Class Initialized
INFO - 2024-03-25 16:00:31 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:31 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:31 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:31 --> URI Class Initialized
INFO - 2024-03-25 16:00:31 --> Router Class Initialized
INFO - 2024-03-25 16:00:31 --> Output Class Initialized
INFO - 2024-03-25 16:00:31 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:31 --> Input Class Initialized
INFO - 2024-03-25 16:00:31 --> Language Class Initialized
INFO - 2024-03-25 16:00:31 --> Loader Class Initialized
INFO - 2024-03-25 16:00:31 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:31 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:31 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:31 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:31 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:31 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:31 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:31 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:31 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:31 --> Parser Class Initialized
INFO - 2024-03-25 16:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:31 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:31 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:31 --> Controller Class Initialized
INFO - 2024-03-25 16:00:31 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:31 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:31 --> Total execution time: 0.0160
ERROR - 2024-03-25 16:00:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:32 --> Config Class Initialized
INFO - 2024-03-25 16:00:32 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:32 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:32 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:32 --> URI Class Initialized
INFO - 2024-03-25 16:00:32 --> Router Class Initialized
INFO - 2024-03-25 16:00:32 --> Output Class Initialized
INFO - 2024-03-25 16:00:32 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:32 --> Input Class Initialized
INFO - 2024-03-25 16:00:32 --> Language Class Initialized
INFO - 2024-03-25 16:00:32 --> Loader Class Initialized
INFO - 2024-03-25 16:00:32 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:32 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:32 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:32 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:32 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:32 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:32 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:32 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:32 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:32 --> Parser Class Initialized
INFO - 2024-03-25 16:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:32 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:32 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:32 --> Controller Class Initialized
INFO - 2024-03-25 16:00:32 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:32 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:32 --> Total execution time: 0.0160
ERROR - 2024-03-25 16:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:33 --> Config Class Initialized
INFO - 2024-03-25 16:00:33 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:33 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:33 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:33 --> URI Class Initialized
INFO - 2024-03-25 16:00:33 --> Router Class Initialized
INFO - 2024-03-25 16:00:33 --> Output Class Initialized
INFO - 2024-03-25 16:00:33 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:33 --> Input Class Initialized
INFO - 2024-03-25 16:00:33 --> Language Class Initialized
INFO - 2024-03-25 16:00:33 --> Loader Class Initialized
INFO - 2024-03-25 16:00:33 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:33 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:33 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:33 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:33 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:33 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:33 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:33 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:33 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:33 --> Parser Class Initialized
INFO - 2024-03-25 16:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:33 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:33 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:33 --> Controller Class Initialized
INFO - 2024-03-25 16:00:33 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:33 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:33 --> Total execution time: 0.0182
ERROR - 2024-03-25 16:00:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:48 --> Config Class Initialized
INFO - 2024-03-25 16:00:48 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:48 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:48 --> URI Class Initialized
DEBUG - 2024-03-25 16:00:48 --> No URI present. Default controller set.
INFO - 2024-03-25 16:00:48 --> Router Class Initialized
INFO - 2024-03-25 16:00:48 --> Output Class Initialized
INFO - 2024-03-25 16:00:48 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:48 --> Input Class Initialized
INFO - 2024-03-25 16:00:48 --> Language Class Initialized
INFO - 2024-03-25 16:00:48 --> Loader Class Initialized
INFO - 2024-03-25 16:00:48 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:48 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:48 --> Parser Class Initialized
INFO - 2024-03-25 16:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:48 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:48 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:48 --> Controller Class Initialized
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 16:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 16:00:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 16:00:48 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:48 --> Total execution time: 0.2573
ERROR - 2024-03-25 16:00:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:48 --> Config Class Initialized
INFO - 2024-03-25 16:00:48 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:48 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:48 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:48 --> URI Class Initialized
INFO - 2024-03-25 16:00:48 --> Router Class Initialized
INFO - 2024-03-25 16:00:48 --> Output Class Initialized
INFO - 2024-03-25 16:00:48 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:48 --> Input Class Initialized
INFO - 2024-03-25 16:00:48 --> Language Class Initialized
INFO - 2024-03-25 16:00:48 --> Loader Class Initialized
INFO - 2024-03-25 16:00:48 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:48 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:48 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:48 --> Parser Class Initialized
INFO - 2024-03-25 16:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:48 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:48 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:48 --> Controller Class Initialized
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-25 16:00:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 16:00:48 --> Model Class Initialized
INFO - 2024-03-25 16:00:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 16:00:48 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:48 --> Total execution time: 0.0350
ERROR - 2024-03-25 16:00:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:49 --> Config Class Initialized
INFO - 2024-03-25 16:00:49 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:49 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:49 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:49 --> URI Class Initialized
INFO - 2024-03-25 16:00:49 --> Router Class Initialized
INFO - 2024-03-25 16:00:49 --> Output Class Initialized
INFO - 2024-03-25 16:00:49 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:49 --> Input Class Initialized
INFO - 2024-03-25 16:00:49 --> Language Class Initialized
INFO - 2024-03-25 16:00:49 --> Loader Class Initialized
INFO - 2024-03-25 16:00:49 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:49 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:49 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:49 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:49 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:49 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:49 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:49 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:49 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:49 --> Parser Class Initialized
INFO - 2024-03-25 16:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:49 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:49 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:49 --> Controller Class Initialized
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 16:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
INFO - 2024-03-25 16:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 16:00:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 16:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 16:00:49 --> Model Class Initialized
INFO - 2024-03-25 16:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 16:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 16:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 16:00:49 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:49 --> Total execution time: 0.2551
ERROR - 2024-03-25 16:00:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:55 --> Config Class Initialized
INFO - 2024-03-25 16:00:55 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:55 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:55 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:55 --> URI Class Initialized
INFO - 2024-03-25 16:00:55 --> Router Class Initialized
INFO - 2024-03-25 16:00:55 --> Output Class Initialized
INFO - 2024-03-25 16:00:55 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:55 --> Input Class Initialized
INFO - 2024-03-25 16:00:55 --> Language Class Initialized
INFO - 2024-03-25 16:00:55 --> Loader Class Initialized
INFO - 2024-03-25 16:00:55 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:55 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:55 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:55 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:55 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:55 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:55 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:55 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:55 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:55 --> Parser Class Initialized
INFO - 2024-03-25 16:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:55 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:55 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:55 --> Controller Class Initialized
DEBUG - 2024-03-25 16:00:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 16:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:55 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:55 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:55 --> Model Class Initialized
INFO - 2024-03-25 16:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-25 16:00:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 16:00:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 16:00:55 --> Model Class Initialized
INFO - 2024-03-25 16:00:55 --> Model Class Initialized
INFO - 2024-03-25 16:00:55 --> Model Class Initialized
INFO - 2024-03-25 16:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 16:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 16:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 16:00:56 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:56 --> Total execution time: 0.1619
ERROR - 2024-03-25 16:00:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:00:56 --> Config Class Initialized
INFO - 2024-03-25 16:00:56 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:00:56 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:00:56 --> Utf8 Class Initialized
INFO - 2024-03-25 16:00:56 --> URI Class Initialized
INFO - 2024-03-25 16:00:56 --> Router Class Initialized
INFO - 2024-03-25 16:00:56 --> Output Class Initialized
INFO - 2024-03-25 16:00:56 --> Security Class Initialized
DEBUG - 2024-03-25 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:00:56 --> Input Class Initialized
INFO - 2024-03-25 16:00:56 --> Language Class Initialized
INFO - 2024-03-25 16:00:56 --> Loader Class Initialized
INFO - 2024-03-25 16:00:56 --> Helper loaded: url_helper
INFO - 2024-03-25 16:00:56 --> Helper loaded: file_helper
INFO - 2024-03-25 16:00:56 --> Helper loaded: html_helper
INFO - 2024-03-25 16:00:56 --> Helper loaded: text_helper
INFO - 2024-03-25 16:00:56 --> Helper loaded: form_helper
INFO - 2024-03-25 16:00:56 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:00:56 --> Helper loaded: security_helper
INFO - 2024-03-25 16:00:56 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:00:56 --> Database Driver Class Initialized
INFO - 2024-03-25 16:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:00:56 --> Parser Class Initialized
INFO - 2024-03-25 16:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:00:56 --> Pagination Class Initialized
INFO - 2024-03-25 16:00:56 --> Form Validation Class Initialized
INFO - 2024-03-25 16:00:56 --> Controller Class Initialized
DEBUG - 2024-03-25 16:00:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 16:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:56 --> Model Class Initialized
DEBUG - 2024-03-25 16:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:00:56 --> Model Class Initialized
INFO - 2024-03-25 16:00:56 --> Final output sent to browser
DEBUG - 2024-03-25 16:00:56 --> Total execution time: 0.0267
ERROR - 2024-03-25 16:01:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:01:00 --> Config Class Initialized
INFO - 2024-03-25 16:01:00 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:01:00 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:01:00 --> Utf8 Class Initialized
INFO - 2024-03-25 16:01:00 --> URI Class Initialized
INFO - 2024-03-25 16:01:00 --> Router Class Initialized
INFO - 2024-03-25 16:01:00 --> Output Class Initialized
INFO - 2024-03-25 16:01:00 --> Security Class Initialized
DEBUG - 2024-03-25 16:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:01:00 --> Input Class Initialized
INFO - 2024-03-25 16:01:00 --> Language Class Initialized
INFO - 2024-03-25 16:01:00 --> Loader Class Initialized
INFO - 2024-03-25 16:01:00 --> Helper loaded: url_helper
INFO - 2024-03-25 16:01:00 --> Helper loaded: file_helper
INFO - 2024-03-25 16:01:00 --> Helper loaded: html_helper
INFO - 2024-03-25 16:01:00 --> Helper loaded: text_helper
INFO - 2024-03-25 16:01:00 --> Helper loaded: form_helper
INFO - 2024-03-25 16:01:00 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:01:00 --> Helper loaded: security_helper
INFO - 2024-03-25 16:01:00 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:01:00 --> Database Driver Class Initialized
INFO - 2024-03-25 16:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:01:00 --> Parser Class Initialized
INFO - 2024-03-25 16:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:01:00 --> Pagination Class Initialized
INFO - 2024-03-25 16:01:00 --> Form Validation Class Initialized
INFO - 2024-03-25 16:01:00 --> Controller Class Initialized
DEBUG - 2024-03-25 16:01:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 16:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:01:00 --> Model Class Initialized
DEBUG - 2024-03-25 16:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:01:00 --> Model Class Initialized
INFO - 2024-03-25 16:01:00 --> Final output sent to browser
DEBUG - 2024-03-25 16:01:00 --> Total execution time: 0.0416
ERROR - 2024-03-25 16:02:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:02:07 --> Config Class Initialized
INFO - 2024-03-25 16:02:07 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:02:07 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:02:07 --> Utf8 Class Initialized
INFO - 2024-03-25 16:02:07 --> URI Class Initialized
INFO - 2024-03-25 16:02:07 --> Router Class Initialized
INFO - 2024-03-25 16:02:07 --> Output Class Initialized
INFO - 2024-03-25 16:02:07 --> Security Class Initialized
DEBUG - 2024-03-25 16:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:02:07 --> Input Class Initialized
INFO - 2024-03-25 16:02:07 --> Language Class Initialized
INFO - 2024-03-25 16:02:07 --> Loader Class Initialized
INFO - 2024-03-25 16:02:07 --> Helper loaded: url_helper
INFO - 2024-03-25 16:02:07 --> Helper loaded: file_helper
INFO - 2024-03-25 16:02:07 --> Helper loaded: html_helper
INFO - 2024-03-25 16:02:07 --> Helper loaded: text_helper
INFO - 2024-03-25 16:02:07 --> Helper loaded: form_helper
INFO - 2024-03-25 16:02:07 --> Helper loaded: lang_helper
INFO - 2024-03-25 16:02:07 --> Helper loaded: security_helper
INFO - 2024-03-25 16:02:07 --> Helper loaded: cookie_helper
INFO - 2024-03-25 16:02:07 --> Database Driver Class Initialized
INFO - 2024-03-25 16:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-25 16:02:07 --> Parser Class Initialized
INFO - 2024-03-25 16:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-25 16:02:07 --> Pagination Class Initialized
INFO - 2024-03-25 16:02:07 --> Form Validation Class Initialized
INFO - 2024-03-25 16:02:07 --> Controller Class Initialized
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
DEBUG - 2024-03-25 16:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
DEBUG - 2024-03-25 16:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
DEBUG - 2024-03-25 16:02:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-25 16:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
INFO - 2024-03-25 16:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-25 16:02:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-25 16:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-25 16:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-25 16:02:07 --> Model Class Initialized
INFO - 2024-03-25 16:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-25 16:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-25 16:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-25 16:02:07 --> Final output sent to browser
DEBUG - 2024-03-25 16:02:07 --> Total execution time: 0.2584
ERROR - 2024-03-25 16:55:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 16:55:10 --> Config Class Initialized
INFO - 2024-03-25 16:55:10 --> Hooks Class Initialized
DEBUG - 2024-03-25 16:55:10 --> UTF-8 Support Enabled
INFO - 2024-03-25 16:55:10 --> Utf8 Class Initialized
INFO - 2024-03-25 16:55:10 --> URI Class Initialized
INFO - 2024-03-25 16:55:10 --> Router Class Initialized
INFO - 2024-03-25 16:55:10 --> Output Class Initialized
INFO - 2024-03-25 16:55:10 --> Security Class Initialized
DEBUG - 2024-03-25 16:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 16:55:10 --> Input Class Initialized
INFO - 2024-03-25 16:55:10 --> Language Class Initialized
ERROR - 2024-03-25 16:55:10 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-25 22:04:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-25 22:04:41 --> Config Class Initialized
INFO - 2024-03-25 22:04:41 --> Hooks Class Initialized
DEBUG - 2024-03-25 22:04:41 --> UTF-8 Support Enabled
INFO - 2024-03-25 22:04:41 --> Utf8 Class Initialized
INFO - 2024-03-25 22:04:41 --> URI Class Initialized
INFO - 2024-03-25 22:04:41 --> Router Class Initialized
INFO - 2024-03-25 22:04:41 --> Output Class Initialized
INFO - 2024-03-25 22:04:41 --> Security Class Initialized
DEBUG - 2024-03-25 22:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-25 22:04:41 --> Input Class Initialized
INFO - 2024-03-25 22:04:41 --> Language Class Initialized
ERROR - 2024-03-25 22:04:41 --> 404 Page Not Found: Well-known/assetlinks.json
