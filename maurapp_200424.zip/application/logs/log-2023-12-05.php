<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-05 02:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:18 --> Config Class Initialized
INFO - 2023-12-05 02:45:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:18 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:18 --> URI Class Initialized
DEBUG - 2023-12-05 02:45:18 --> No URI present. Default controller set.
INFO - 2023-12-05 02:45:18 --> Router Class Initialized
INFO - 2023-12-05 02:45:18 --> Output Class Initialized
INFO - 2023-12-05 02:45:18 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:18 --> Input Class Initialized
INFO - 2023-12-05 02:45:18 --> Language Class Initialized
INFO - 2023-12-05 02:45:18 --> Loader Class Initialized
INFO - 2023-12-05 02:45:18 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:18 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:18 --> Parser Class Initialized
INFO - 2023-12-05 02:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:18 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:18 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:18 --> Controller Class Initialized
INFO - 2023-12-05 02:45:18 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 02:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:18 --> Config Class Initialized
INFO - 2023-12-05 02:45:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:18 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:18 --> URI Class Initialized
DEBUG - 2023-12-05 02:45:18 --> No URI present. Default controller set.
INFO - 2023-12-05 02:45:18 --> Router Class Initialized
INFO - 2023-12-05 02:45:18 --> Output Class Initialized
INFO - 2023-12-05 02:45:18 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:18 --> Input Class Initialized
INFO - 2023-12-05 02:45:18 --> Language Class Initialized
INFO - 2023-12-05 02:45:18 --> Loader Class Initialized
INFO - 2023-12-05 02:45:18 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:18 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:18 --> Parser Class Initialized
INFO - 2023-12-05 02:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:18 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:18 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:18 --> Controller Class Initialized
INFO - 2023-12-05 02:45:18 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 02:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:18 --> Config Class Initialized
INFO - 2023-12-05 02:45:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:18 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:18 --> URI Class Initialized
INFO - 2023-12-05 02:45:18 --> Router Class Initialized
INFO - 2023-12-05 02:45:18 --> Output Class Initialized
INFO - 2023-12-05 02:45:18 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:18 --> Input Class Initialized
INFO - 2023-12-05 02:45:18 --> Language Class Initialized
INFO - 2023-12-05 02:45:18 --> Loader Class Initialized
INFO - 2023-12-05 02:45:18 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:18 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:18 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:18 --> Parser Class Initialized
INFO - 2023-12-05 02:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:18 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:18 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:18 --> Controller Class Initialized
INFO - 2023-12-05 02:45:18 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 02:45:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:45:18 --> Model Class Initialized
INFO - 2023-12-05 02:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:45:18 --> Final output sent to browser
DEBUG - 2023-12-05 02:45:18 --> Total execution time: 0.0333
ERROR - 2023-12-05 02:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:22 --> Config Class Initialized
INFO - 2023-12-05 02:45:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:22 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:22 --> URI Class Initialized
INFO - 2023-12-05 02:45:22 --> Router Class Initialized
INFO - 2023-12-05 02:45:22 --> Output Class Initialized
INFO - 2023-12-05 02:45:22 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:22 --> Input Class Initialized
INFO - 2023-12-05 02:45:22 --> Language Class Initialized
INFO - 2023-12-05 02:45:22 --> Loader Class Initialized
INFO - 2023-12-05 02:45:22 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:22 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:22 --> Parser Class Initialized
INFO - 2023-12-05 02:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:22 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:22 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:22 --> Controller Class Initialized
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
INFO - 2023-12-05 02:45:22 --> Final output sent to browser
DEBUG - 2023-12-05 02:45:22 --> Total execution time: 0.0186
ERROR - 2023-12-05 02:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:22 --> Config Class Initialized
INFO - 2023-12-05 02:45:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:22 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:22 --> URI Class Initialized
DEBUG - 2023-12-05 02:45:22 --> No URI present. Default controller set.
INFO - 2023-12-05 02:45:22 --> Router Class Initialized
INFO - 2023-12-05 02:45:22 --> Output Class Initialized
INFO - 2023-12-05 02:45:22 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:22 --> Input Class Initialized
INFO - 2023-12-05 02:45:22 --> Language Class Initialized
INFO - 2023-12-05 02:45:22 --> Loader Class Initialized
INFO - 2023-12-05 02:45:22 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:22 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:22 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:22 --> Parser Class Initialized
INFO - 2023-12-05 02:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:22 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:22 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:22 --> Controller Class Initialized
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
INFO - 2023-12-05 02:45:22 --> Model Class Initialized
INFO - 2023-12-05 02:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 02:45:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:45:23 --> Model Class Initialized
INFO - 2023-12-05 02:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:45:23 --> Final output sent to browser
DEBUG - 2023-12-05 02:45:23 --> Total execution time: 0.4061
ERROR - 2023-12-05 02:45:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:23 --> Config Class Initialized
INFO - 2023-12-05 02:45:23 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:23 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:23 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:23 --> URI Class Initialized
INFO - 2023-12-05 02:45:23 --> Router Class Initialized
INFO - 2023-12-05 02:45:23 --> Output Class Initialized
INFO - 2023-12-05 02:45:23 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:23 --> Input Class Initialized
INFO - 2023-12-05 02:45:23 --> Language Class Initialized
INFO - 2023-12-05 02:45:23 --> Loader Class Initialized
INFO - 2023-12-05 02:45:23 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:23 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:23 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:23 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:23 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:23 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:23 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:23 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:23 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:23 --> Parser Class Initialized
INFO - 2023-12-05 02:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:23 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:23 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:23 --> Controller Class Initialized
DEBUG - 2023-12-05 02:45:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:23 --> Model Class Initialized
INFO - 2023-12-05 02:45:23 --> Final output sent to browser
DEBUG - 2023-12-05 02:45:23 --> Total execution time: 0.0131
ERROR - 2023-12-05 02:45:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:43 --> Config Class Initialized
INFO - 2023-12-05 02:45:43 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:43 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:43 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:43 --> URI Class Initialized
INFO - 2023-12-05 02:45:43 --> Router Class Initialized
INFO - 2023-12-05 02:45:43 --> Output Class Initialized
INFO - 2023-12-05 02:45:43 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:43 --> Input Class Initialized
INFO - 2023-12-05 02:45:43 --> Language Class Initialized
INFO - 2023-12-05 02:45:43 --> Loader Class Initialized
INFO - 2023-12-05 02:45:43 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:43 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:43 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:43 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:43 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:43 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:43 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:43 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:43 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:43 --> Parser Class Initialized
INFO - 2023-12-05 02:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:43 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:43 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:43 --> Controller Class Initialized
INFO - 2023-12-05 02:45:43 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:43 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:43 --> Model Class Initialized
INFO - 2023-12-05 02:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-05 02:45:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:45:43 --> Model Class Initialized
INFO - 2023-12-05 02:45:43 --> Model Class Initialized
INFO - 2023-12-05 02:45:43 --> Model Class Initialized
INFO - 2023-12-05 02:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:45:44 --> Final output sent to browser
DEBUG - 2023-12-05 02:45:44 --> Total execution time: 0.2206
ERROR - 2023-12-05 02:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:45:44 --> Config Class Initialized
INFO - 2023-12-05 02:45:44 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:45:44 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:45:44 --> Utf8 Class Initialized
INFO - 2023-12-05 02:45:44 --> URI Class Initialized
INFO - 2023-12-05 02:45:44 --> Router Class Initialized
INFO - 2023-12-05 02:45:44 --> Output Class Initialized
INFO - 2023-12-05 02:45:44 --> Security Class Initialized
DEBUG - 2023-12-05 02:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:45:44 --> Input Class Initialized
INFO - 2023-12-05 02:45:44 --> Language Class Initialized
INFO - 2023-12-05 02:45:44 --> Loader Class Initialized
INFO - 2023-12-05 02:45:44 --> Helper loaded: url_helper
INFO - 2023-12-05 02:45:44 --> Helper loaded: file_helper
INFO - 2023-12-05 02:45:44 --> Helper loaded: html_helper
INFO - 2023-12-05 02:45:44 --> Helper loaded: text_helper
INFO - 2023-12-05 02:45:44 --> Helper loaded: form_helper
INFO - 2023-12-05 02:45:44 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:45:44 --> Helper loaded: security_helper
INFO - 2023-12-05 02:45:44 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:45:44 --> Database Driver Class Initialized
INFO - 2023-12-05 02:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:45:44 --> Parser Class Initialized
INFO - 2023-12-05 02:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:45:44 --> Pagination Class Initialized
INFO - 2023-12-05 02:45:44 --> Form Validation Class Initialized
INFO - 2023-12-05 02:45:44 --> Controller Class Initialized
INFO - 2023-12-05 02:45:44 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:44 --> Model Class Initialized
DEBUG - 2023-12-05 02:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:45:44 --> Model Class Initialized
INFO - 2023-12-05 02:45:44 --> Final output sent to browser
DEBUG - 2023-12-05 02:45:44 --> Total execution time: 0.0672
ERROR - 2023-12-05 02:46:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:46:10 --> Config Class Initialized
INFO - 2023-12-05 02:46:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:46:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:46:10 --> Utf8 Class Initialized
INFO - 2023-12-05 02:46:10 --> URI Class Initialized
DEBUG - 2023-12-05 02:46:10 --> No URI present. Default controller set.
INFO - 2023-12-05 02:46:10 --> Router Class Initialized
INFO - 2023-12-05 02:46:10 --> Output Class Initialized
INFO - 2023-12-05 02:46:10 --> Security Class Initialized
DEBUG - 2023-12-05 02:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:46:10 --> Input Class Initialized
INFO - 2023-12-05 02:46:10 --> Language Class Initialized
INFO - 2023-12-05 02:46:10 --> Loader Class Initialized
INFO - 2023-12-05 02:46:10 --> Helper loaded: url_helper
INFO - 2023-12-05 02:46:10 --> Helper loaded: file_helper
INFO - 2023-12-05 02:46:10 --> Helper loaded: html_helper
INFO - 2023-12-05 02:46:10 --> Helper loaded: text_helper
INFO - 2023-12-05 02:46:10 --> Helper loaded: form_helper
INFO - 2023-12-05 02:46:10 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:46:10 --> Helper loaded: security_helper
INFO - 2023-12-05 02:46:10 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:46:10 --> Database Driver Class Initialized
INFO - 2023-12-05 02:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:46:10 --> Parser Class Initialized
INFO - 2023-12-05 02:46:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:46:10 --> Pagination Class Initialized
INFO - 2023-12-05 02:46:10 --> Form Validation Class Initialized
INFO - 2023-12-05 02:46:10 --> Controller Class Initialized
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
DEBUG - 2023-12-05 02:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
DEBUG - 2023-12-05 02:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
DEBUG - 2023-12-05 02:46:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
INFO - 2023-12-05 02:46:10 --> Model Class Initialized
INFO - 2023-12-05 02:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 02:46:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:46:11 --> Model Class Initialized
INFO - 2023-12-05 02:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:46:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:46:11 --> Final output sent to browser
DEBUG - 2023-12-05 02:46:11 --> Total execution time: 0.4058
ERROR - 2023-12-05 02:47:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:47:16 --> Config Class Initialized
INFO - 2023-12-05 02:47:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:47:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:47:16 --> Utf8 Class Initialized
INFO - 2023-12-05 02:47:16 --> URI Class Initialized
DEBUG - 2023-12-05 02:47:16 --> No URI present. Default controller set.
INFO - 2023-12-05 02:47:16 --> Router Class Initialized
INFO - 2023-12-05 02:47:16 --> Output Class Initialized
INFO - 2023-12-05 02:47:16 --> Security Class Initialized
DEBUG - 2023-12-05 02:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:47:16 --> Input Class Initialized
INFO - 2023-12-05 02:47:16 --> Language Class Initialized
INFO - 2023-12-05 02:47:16 --> Loader Class Initialized
INFO - 2023-12-05 02:47:16 --> Helper loaded: url_helper
INFO - 2023-12-05 02:47:16 --> Helper loaded: file_helper
INFO - 2023-12-05 02:47:16 --> Helper loaded: html_helper
INFO - 2023-12-05 02:47:16 --> Helper loaded: text_helper
INFO - 2023-12-05 02:47:16 --> Helper loaded: form_helper
INFO - 2023-12-05 02:47:16 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:47:16 --> Helper loaded: security_helper
INFO - 2023-12-05 02:47:16 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:47:16 --> Database Driver Class Initialized
INFO - 2023-12-05 02:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:47:16 --> Parser Class Initialized
INFO - 2023-12-05 02:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:47:16 --> Pagination Class Initialized
INFO - 2023-12-05 02:47:16 --> Form Validation Class Initialized
INFO - 2023-12-05 02:47:16 --> Controller Class Initialized
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
DEBUG - 2023-12-05 02:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
DEBUG - 2023-12-05 02:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
DEBUG - 2023-12-05 02:47:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
INFO - 2023-12-05 02:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 02:47:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:47:16 --> Model Class Initialized
INFO - 2023-12-05 02:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:47:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:47:16 --> Final output sent to browser
DEBUG - 2023-12-05 02:47:16 --> Total execution time: 0.3922
ERROR - 2023-12-05 02:52:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:52:55 --> Config Class Initialized
INFO - 2023-12-05 02:52:55 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:52:55 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:52:55 --> Utf8 Class Initialized
INFO - 2023-12-05 02:52:55 --> URI Class Initialized
DEBUG - 2023-12-05 02:52:55 --> No URI present. Default controller set.
INFO - 2023-12-05 02:52:55 --> Router Class Initialized
INFO - 2023-12-05 02:52:55 --> Output Class Initialized
INFO - 2023-12-05 02:52:55 --> Security Class Initialized
DEBUG - 2023-12-05 02:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:52:55 --> Input Class Initialized
INFO - 2023-12-05 02:52:55 --> Language Class Initialized
INFO - 2023-12-05 02:52:55 --> Loader Class Initialized
INFO - 2023-12-05 02:52:55 --> Helper loaded: url_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: file_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: html_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: text_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: form_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: security_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:52:55 --> Database Driver Class Initialized
INFO - 2023-12-05 02:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:52:55 --> Parser Class Initialized
INFO - 2023-12-05 02:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:52:55 --> Pagination Class Initialized
INFO - 2023-12-05 02:52:55 --> Form Validation Class Initialized
INFO - 2023-12-05 02:52:55 --> Controller Class Initialized
INFO - 2023-12-05 02:52:55 --> Model Class Initialized
DEBUG - 2023-12-05 02:52:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 02:52:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:52:55 --> Config Class Initialized
INFO - 2023-12-05 02:52:55 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:52:55 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:52:55 --> Utf8 Class Initialized
INFO - 2023-12-05 02:52:55 --> URI Class Initialized
INFO - 2023-12-05 02:52:55 --> Router Class Initialized
INFO - 2023-12-05 02:52:55 --> Output Class Initialized
INFO - 2023-12-05 02:52:55 --> Security Class Initialized
DEBUG - 2023-12-05 02:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:52:55 --> Input Class Initialized
INFO - 2023-12-05 02:52:55 --> Language Class Initialized
INFO - 2023-12-05 02:52:55 --> Loader Class Initialized
INFO - 2023-12-05 02:52:55 --> Helper loaded: url_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: file_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: html_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: text_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: form_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: security_helper
INFO - 2023-12-05 02:52:55 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:52:55 --> Database Driver Class Initialized
INFO - 2023-12-05 02:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:52:55 --> Parser Class Initialized
INFO - 2023-12-05 02:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:52:55 --> Pagination Class Initialized
INFO - 2023-12-05 02:52:55 --> Form Validation Class Initialized
INFO - 2023-12-05 02:52:55 --> Controller Class Initialized
INFO - 2023-12-05 02:52:55 --> Model Class Initialized
DEBUG - 2023-12-05 02:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 02:52:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:52:55 --> Model Class Initialized
INFO - 2023-12-05 02:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:52:55 --> Final output sent to browser
DEBUG - 2023-12-05 02:52:55 --> Total execution time: 0.0362
ERROR - 2023-12-05 02:52:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:52:55 --> Config Class Initialized
INFO - 2023-12-05 02:52:55 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:52:55 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:52:55 --> Utf8 Class Initialized
INFO - 2023-12-05 02:52:55 --> URI Class Initialized
INFO - 2023-12-05 02:52:55 --> Router Class Initialized
INFO - 2023-12-05 02:52:55 --> Output Class Initialized
INFO - 2023-12-05 02:52:55 --> Security Class Initialized
DEBUG - 2023-12-05 02:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:52:55 --> Input Class Initialized
INFO - 2023-12-05 02:52:55 --> Language Class Initialized
ERROR - 2023-12-05 02:52:55 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-12-05 02:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:52:56 --> Config Class Initialized
INFO - 2023-12-05 02:52:56 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:52:56 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:52:56 --> Utf8 Class Initialized
INFO - 2023-12-05 02:52:56 --> URI Class Initialized
INFO - 2023-12-05 02:52:56 --> Router Class Initialized
INFO - 2023-12-05 02:52:56 --> Output Class Initialized
INFO - 2023-12-05 02:52:56 --> Security Class Initialized
DEBUG - 2023-12-05 02:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:52:56 --> Input Class Initialized
INFO - 2023-12-05 02:52:56 --> Language Class Initialized
ERROR - 2023-12-05 02:52:56 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-12-05 02:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:00 --> Config Class Initialized
INFO - 2023-12-05 02:53:00 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:00 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:00 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:00 --> URI Class Initialized
INFO - 2023-12-05 02:53:00 --> Router Class Initialized
INFO - 2023-12-05 02:53:00 --> Output Class Initialized
INFO - 2023-12-05 02:53:00 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:00 --> Input Class Initialized
INFO - 2023-12-05 02:53:00 --> Language Class Initialized
INFO - 2023-12-05 02:53:00 --> Loader Class Initialized
INFO - 2023-12-05 02:53:00 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:00 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:00 --> Parser Class Initialized
INFO - 2023-12-05 02:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:00 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:00 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:00 --> Controller Class Initialized
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
INFO - 2023-12-05 02:53:00 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:00 --> Total execution time: 0.0184
ERROR - 2023-12-05 02:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:00 --> Config Class Initialized
INFO - 2023-12-05 02:53:00 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:00 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:00 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:00 --> URI Class Initialized
DEBUG - 2023-12-05 02:53:00 --> No URI present. Default controller set.
INFO - 2023-12-05 02:53:00 --> Router Class Initialized
INFO - 2023-12-05 02:53:00 --> Output Class Initialized
INFO - 2023-12-05 02:53:00 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:00 --> Input Class Initialized
INFO - 2023-12-05 02:53:00 --> Language Class Initialized
INFO - 2023-12-05 02:53:00 --> Loader Class Initialized
INFO - 2023-12-05 02:53:00 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:00 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:00 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:00 --> Parser Class Initialized
INFO - 2023-12-05 02:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:00 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:00 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:00 --> Controller Class Initialized
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
INFO - 2023-12-05 02:53:00 --> Model Class Initialized
INFO - 2023-12-05 02:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 02:53:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:53:01 --> Model Class Initialized
INFO - 2023-12-05 02:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:53:01 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:01 --> Total execution time: 0.2141
ERROR - 2023-12-05 02:53:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:06 --> Config Class Initialized
INFO - 2023-12-05 02:53:06 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:06 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:06 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:06 --> URI Class Initialized
INFO - 2023-12-05 02:53:06 --> Router Class Initialized
INFO - 2023-12-05 02:53:06 --> Output Class Initialized
INFO - 2023-12-05 02:53:06 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:06 --> Input Class Initialized
INFO - 2023-12-05 02:53:06 --> Language Class Initialized
INFO - 2023-12-05 02:53:06 --> Loader Class Initialized
INFO - 2023-12-05 02:53:06 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:06 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:06 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:06 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:06 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:06 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:06 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:06 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:06 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:06 --> Parser Class Initialized
INFO - 2023-12-05 02:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:06 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:06 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:06 --> Controller Class Initialized
INFO - 2023-12-05 02:53:06 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:06 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:06 --> Model Class Initialized
INFO - 2023-12-05 02:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-05 02:53:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:53:06 --> Model Class Initialized
INFO - 2023-12-05 02:53:06 --> Model Class Initialized
INFO - 2023-12-05 02:53:06 --> Model Class Initialized
INFO - 2023-12-05 02:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:53:06 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:06 --> Total execution time: 0.1447
ERROR - 2023-12-05 02:53:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:07 --> Config Class Initialized
INFO - 2023-12-05 02:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:07 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:07 --> URI Class Initialized
INFO - 2023-12-05 02:53:07 --> Router Class Initialized
INFO - 2023-12-05 02:53:07 --> Output Class Initialized
INFO - 2023-12-05 02:53:07 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:07 --> Input Class Initialized
INFO - 2023-12-05 02:53:07 --> Language Class Initialized
INFO - 2023-12-05 02:53:07 --> Loader Class Initialized
INFO - 2023-12-05 02:53:07 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:07 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:07 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:07 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:07 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:07 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:07 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:07 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:07 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:07 --> Parser Class Initialized
INFO - 2023-12-05 02:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:07 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:07 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:07 --> Controller Class Initialized
INFO - 2023-12-05 02:53:07 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:07 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:07 --> Model Class Initialized
INFO - 2023-12-05 02:53:07 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:07 --> Total execution time: 0.0408
ERROR - 2023-12-05 02:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:10 --> Config Class Initialized
INFO - 2023-12-05 02:53:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:10 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:10 --> URI Class Initialized
DEBUG - 2023-12-05 02:53:10 --> No URI present. Default controller set.
INFO - 2023-12-05 02:53:10 --> Router Class Initialized
INFO - 2023-12-05 02:53:10 --> Output Class Initialized
INFO - 2023-12-05 02:53:10 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:10 --> Input Class Initialized
INFO - 2023-12-05 02:53:10 --> Language Class Initialized
INFO - 2023-12-05 02:53:10 --> Loader Class Initialized
INFO - 2023-12-05 02:53:10 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:10 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:10 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:10 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:10 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:10 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:10 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:10 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:10 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:10 --> Parser Class Initialized
INFO - 2023-12-05 02:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:10 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:10 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:10 --> Controller Class Initialized
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
INFO - 2023-12-05 02:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 02:53:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:53:10 --> Model Class Initialized
INFO - 2023-12-05 02:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:53:10 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:10 --> Total execution time: 0.2171
ERROR - 2023-12-05 02:53:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:23 --> Config Class Initialized
INFO - 2023-12-05 02:53:23 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:23 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:23 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:23 --> URI Class Initialized
INFO - 2023-12-05 02:53:23 --> Router Class Initialized
INFO - 2023-12-05 02:53:23 --> Output Class Initialized
INFO - 2023-12-05 02:53:23 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:23 --> Input Class Initialized
INFO - 2023-12-05 02:53:23 --> Language Class Initialized
INFO - 2023-12-05 02:53:23 --> Loader Class Initialized
INFO - 2023-12-05 02:53:23 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:23 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:23 --> Parser Class Initialized
INFO - 2023-12-05 02:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:23 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:23 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:23 --> Controller Class Initialized
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
INFO - 2023-12-05 02:53:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-05 02:53:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:53:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
INFO - 2023-12-05 02:53:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:53:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:53:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:53:23 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:23 --> Total execution time: 0.1447
ERROR - 2023-12-05 02:53:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:23 --> Config Class Initialized
INFO - 2023-12-05 02:53:23 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:23 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:23 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:23 --> URI Class Initialized
INFO - 2023-12-05 02:53:23 --> Router Class Initialized
INFO - 2023-12-05 02:53:23 --> Output Class Initialized
INFO - 2023-12-05 02:53:23 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:23 --> Input Class Initialized
INFO - 2023-12-05 02:53:23 --> Language Class Initialized
INFO - 2023-12-05 02:53:23 --> Loader Class Initialized
INFO - 2023-12-05 02:53:23 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:23 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:23 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:23 --> Parser Class Initialized
INFO - 2023-12-05 02:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:23 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:23 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:23 --> Controller Class Initialized
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:23 --> Model Class Initialized
INFO - 2023-12-05 02:53:23 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:23 --> Total execution time: 0.0408
ERROR - 2023-12-05 02:53:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:53:42 --> Config Class Initialized
INFO - 2023-12-05 02:53:42 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:53:42 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:53:42 --> Utf8 Class Initialized
INFO - 2023-12-05 02:53:42 --> URI Class Initialized
INFO - 2023-12-05 02:53:42 --> Router Class Initialized
INFO - 2023-12-05 02:53:42 --> Output Class Initialized
INFO - 2023-12-05 02:53:42 --> Security Class Initialized
DEBUG - 2023-12-05 02:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:53:42 --> Input Class Initialized
INFO - 2023-12-05 02:53:42 --> Language Class Initialized
INFO - 2023-12-05 02:53:42 --> Loader Class Initialized
INFO - 2023-12-05 02:53:42 --> Helper loaded: url_helper
INFO - 2023-12-05 02:53:42 --> Helper loaded: file_helper
INFO - 2023-12-05 02:53:42 --> Helper loaded: html_helper
INFO - 2023-12-05 02:53:42 --> Helper loaded: text_helper
INFO - 2023-12-05 02:53:42 --> Helper loaded: form_helper
INFO - 2023-12-05 02:53:42 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:53:42 --> Helper loaded: security_helper
INFO - 2023-12-05 02:53:42 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:53:42 --> Database Driver Class Initialized
INFO - 2023-12-05 02:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:53:42 --> Parser Class Initialized
INFO - 2023-12-05 02:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:53:42 --> Pagination Class Initialized
INFO - 2023-12-05 02:53:42 --> Form Validation Class Initialized
INFO - 2023-12-05 02:53:42 --> Controller Class Initialized
INFO - 2023-12-05 02:53:42 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:42 --> Model Class Initialized
DEBUG - 2023-12-05 02:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:53:42 --> Model Class Initialized
INFO - 2023-12-05 02:53:43 --> Final output sent to browser
DEBUG - 2023-12-05 02:53:43 --> Total execution time: 0.4141
ERROR - 2023-12-05 02:54:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:54:17 --> Config Class Initialized
INFO - 2023-12-05 02:54:17 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:54:17 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:54:17 --> Utf8 Class Initialized
INFO - 2023-12-05 02:54:17 --> URI Class Initialized
DEBUG - 2023-12-05 02:54:17 --> No URI present. Default controller set.
INFO - 2023-12-05 02:54:17 --> Router Class Initialized
INFO - 2023-12-05 02:54:17 --> Output Class Initialized
INFO - 2023-12-05 02:54:17 --> Security Class Initialized
DEBUG - 2023-12-05 02:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:54:17 --> Input Class Initialized
INFO - 2023-12-05 02:54:17 --> Language Class Initialized
INFO - 2023-12-05 02:54:17 --> Loader Class Initialized
INFO - 2023-12-05 02:54:17 --> Helper loaded: url_helper
INFO - 2023-12-05 02:54:17 --> Helper loaded: file_helper
INFO - 2023-12-05 02:54:17 --> Helper loaded: html_helper
INFO - 2023-12-05 02:54:17 --> Helper loaded: text_helper
INFO - 2023-12-05 02:54:17 --> Helper loaded: form_helper
INFO - 2023-12-05 02:54:17 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:54:17 --> Helper loaded: security_helper
INFO - 2023-12-05 02:54:17 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:54:17 --> Database Driver Class Initialized
INFO - 2023-12-05 02:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:54:18 --> Parser Class Initialized
INFO - 2023-12-05 02:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:54:18 --> Pagination Class Initialized
INFO - 2023-12-05 02:54:18 --> Form Validation Class Initialized
INFO - 2023-12-05 02:54:18 --> Controller Class Initialized
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
DEBUG - 2023-12-05 02:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
DEBUG - 2023-12-05 02:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
DEBUG - 2023-12-05 02:54:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
INFO - 2023-12-05 02:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 02:54:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:54:18 --> Model Class Initialized
INFO - 2023-12-05 02:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:54:18 --> Final output sent to browser
DEBUG - 2023-12-05 02:54:18 --> Total execution time: 0.2330
ERROR - 2023-12-05 02:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:58:04 --> Config Class Initialized
INFO - 2023-12-05 02:58:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:58:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:58:04 --> Utf8 Class Initialized
INFO - 2023-12-05 02:58:04 --> URI Class Initialized
INFO - 2023-12-05 02:58:04 --> Router Class Initialized
INFO - 2023-12-05 02:58:04 --> Output Class Initialized
INFO - 2023-12-05 02:58:04 --> Security Class Initialized
DEBUG - 2023-12-05 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:58:04 --> Input Class Initialized
INFO - 2023-12-05 02:58:04 --> Language Class Initialized
INFO - 2023-12-05 02:58:04 --> Loader Class Initialized
INFO - 2023-12-05 02:58:04 --> Helper loaded: url_helper
INFO - 2023-12-05 02:58:04 --> Helper loaded: file_helper
INFO - 2023-12-05 02:58:04 --> Helper loaded: html_helper
INFO - 2023-12-05 02:58:04 --> Helper loaded: text_helper
INFO - 2023-12-05 02:58:04 --> Helper loaded: form_helper
INFO - 2023-12-05 02:58:04 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:58:04 --> Helper loaded: security_helper
INFO - 2023-12-05 02:58:04 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:58:04 --> Database Driver Class Initialized
INFO - 2023-12-05 02:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:58:04 --> Parser Class Initialized
INFO - 2023-12-05 02:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:58:04 --> Pagination Class Initialized
INFO - 2023-12-05 02:58:04 --> Form Validation Class Initialized
INFO - 2023-12-05 02:58:04 --> Controller Class Initialized
INFO - 2023-12-05 02:58:04 --> Model Class Initialized
DEBUG - 2023-12-05 02:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:58:04 --> Model Class Initialized
INFO - 2023-12-05 02:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-12-05 02:58:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 02:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 02:58:04 --> Model Class Initialized
INFO - 2023-12-05 02:58:04 --> Model Class Initialized
INFO - 2023-12-05 02:58:04 --> Model Class Initialized
INFO - 2023-12-05 02:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 02:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 02:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 02:58:04 --> Final output sent to browser
DEBUG - 2023-12-05 02:58:04 --> Total execution time: 0.1901
ERROR - 2023-12-05 02:58:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:58:05 --> Config Class Initialized
INFO - 2023-12-05 02:58:05 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:58:05 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:58:05 --> Utf8 Class Initialized
INFO - 2023-12-05 02:58:05 --> URI Class Initialized
INFO - 2023-12-05 02:58:05 --> Router Class Initialized
INFO - 2023-12-05 02:58:05 --> Output Class Initialized
INFO - 2023-12-05 02:58:05 --> Security Class Initialized
DEBUG - 2023-12-05 02:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:58:05 --> Input Class Initialized
INFO - 2023-12-05 02:58:05 --> Language Class Initialized
INFO - 2023-12-05 02:58:05 --> Loader Class Initialized
INFO - 2023-12-05 02:58:05 --> Helper loaded: url_helper
INFO - 2023-12-05 02:58:05 --> Helper loaded: file_helper
INFO - 2023-12-05 02:58:05 --> Helper loaded: html_helper
INFO - 2023-12-05 02:58:05 --> Helper loaded: text_helper
INFO - 2023-12-05 02:58:05 --> Helper loaded: form_helper
INFO - 2023-12-05 02:58:05 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:58:05 --> Helper loaded: security_helper
INFO - 2023-12-05 02:58:05 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:58:05 --> Database Driver Class Initialized
INFO - 2023-12-05 02:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:58:05 --> Parser Class Initialized
INFO - 2023-12-05 02:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:58:05 --> Pagination Class Initialized
INFO - 2023-12-05 02:58:05 --> Form Validation Class Initialized
INFO - 2023-12-05 02:58:05 --> Controller Class Initialized
INFO - 2023-12-05 02:58:05 --> Model Class Initialized
DEBUG - 2023-12-05 02:58:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:58:05 --> Model Class Initialized
INFO - 2023-12-05 02:58:05 --> Final output sent to browser
DEBUG - 2023-12-05 02:58:05 --> Total execution time: 0.0750
ERROR - 2023-12-05 02:58:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 02:58:08 --> Config Class Initialized
INFO - 2023-12-05 02:58:08 --> Hooks Class Initialized
DEBUG - 2023-12-05 02:58:08 --> UTF-8 Support Enabled
INFO - 2023-12-05 02:58:08 --> Utf8 Class Initialized
INFO - 2023-12-05 02:58:08 --> URI Class Initialized
INFO - 2023-12-05 02:58:08 --> Router Class Initialized
INFO - 2023-12-05 02:58:08 --> Output Class Initialized
INFO - 2023-12-05 02:58:08 --> Security Class Initialized
DEBUG - 2023-12-05 02:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 02:58:08 --> Input Class Initialized
INFO - 2023-12-05 02:58:08 --> Language Class Initialized
INFO - 2023-12-05 02:58:08 --> Loader Class Initialized
INFO - 2023-12-05 02:58:08 --> Helper loaded: url_helper
INFO - 2023-12-05 02:58:08 --> Helper loaded: file_helper
INFO - 2023-12-05 02:58:08 --> Helper loaded: html_helper
INFO - 2023-12-05 02:58:08 --> Helper loaded: text_helper
INFO - 2023-12-05 02:58:08 --> Helper loaded: form_helper
INFO - 2023-12-05 02:58:08 --> Helper loaded: lang_helper
INFO - 2023-12-05 02:58:08 --> Helper loaded: security_helper
INFO - 2023-12-05 02:58:08 --> Helper loaded: cookie_helper
INFO - 2023-12-05 02:58:08 --> Database Driver Class Initialized
INFO - 2023-12-05 02:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 02:58:08 --> Parser Class Initialized
INFO - 2023-12-05 02:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 02:58:08 --> Pagination Class Initialized
INFO - 2023-12-05 02:58:08 --> Form Validation Class Initialized
INFO - 2023-12-05 02:58:08 --> Controller Class Initialized
INFO - 2023-12-05 02:58:08 --> Model Class Initialized
DEBUG - 2023-12-05 02:58:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 02:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 02:58:08 --> Model Class Initialized
INFO - 2023-12-05 02:58:08 --> Final output sent to browser
DEBUG - 2023-12-05 02:58:08 --> Total execution time: 0.1906
ERROR - 2023-12-05 03:24:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 03:24:47 --> Config Class Initialized
INFO - 2023-12-05 03:24:47 --> Hooks Class Initialized
DEBUG - 2023-12-05 03:24:47 --> UTF-8 Support Enabled
INFO - 2023-12-05 03:24:47 --> Utf8 Class Initialized
INFO - 2023-12-05 03:24:47 --> URI Class Initialized
DEBUG - 2023-12-05 03:24:47 --> No URI present. Default controller set.
INFO - 2023-12-05 03:24:47 --> Router Class Initialized
INFO - 2023-12-05 03:24:47 --> Output Class Initialized
INFO - 2023-12-05 03:24:47 --> Security Class Initialized
DEBUG - 2023-12-05 03:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 03:24:47 --> Input Class Initialized
INFO - 2023-12-05 03:24:47 --> Language Class Initialized
INFO - 2023-12-05 03:24:47 --> Loader Class Initialized
INFO - 2023-12-05 03:24:47 --> Helper loaded: url_helper
INFO - 2023-12-05 03:24:47 --> Helper loaded: file_helper
INFO - 2023-12-05 03:24:47 --> Helper loaded: html_helper
INFO - 2023-12-05 03:24:47 --> Helper loaded: text_helper
INFO - 2023-12-05 03:24:47 --> Helper loaded: form_helper
INFO - 2023-12-05 03:24:47 --> Helper loaded: lang_helper
INFO - 2023-12-05 03:24:47 --> Helper loaded: security_helper
INFO - 2023-12-05 03:24:47 --> Helper loaded: cookie_helper
INFO - 2023-12-05 03:24:47 --> Database Driver Class Initialized
INFO - 2023-12-05 03:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 03:24:47 --> Parser Class Initialized
INFO - 2023-12-05 03:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 03:24:47 --> Pagination Class Initialized
INFO - 2023-12-05 03:24:47 --> Form Validation Class Initialized
INFO - 2023-12-05 03:24:47 --> Controller Class Initialized
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
DEBUG - 2023-12-05 03:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
DEBUG - 2023-12-05 03:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
DEBUG - 2023-12-05 03:24:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 03:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
INFO - 2023-12-05 03:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 03:24:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 03:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 03:24:47 --> Model Class Initialized
INFO - 2023-12-05 03:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 03:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 03:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 03:24:47 --> Final output sent to browser
DEBUG - 2023-12-05 03:24:47 --> Total execution time: 0.4137
ERROR - 2023-12-05 03:27:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 03:27:19 --> Config Class Initialized
INFO - 2023-12-05 03:27:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 03:27:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 03:27:19 --> Utf8 Class Initialized
INFO - 2023-12-05 03:27:19 --> URI Class Initialized
INFO - 2023-12-05 03:27:19 --> Router Class Initialized
INFO - 2023-12-05 03:27:19 --> Output Class Initialized
INFO - 2023-12-05 03:27:19 --> Security Class Initialized
DEBUG - 2023-12-05 03:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 03:27:19 --> Input Class Initialized
INFO - 2023-12-05 03:27:19 --> Language Class Initialized
INFO - 2023-12-05 03:27:19 --> Loader Class Initialized
INFO - 2023-12-05 03:27:19 --> Helper loaded: url_helper
INFO - 2023-12-05 03:27:19 --> Helper loaded: file_helper
INFO - 2023-12-05 03:27:19 --> Helper loaded: html_helper
INFO - 2023-12-05 03:27:19 --> Helper loaded: text_helper
INFO - 2023-12-05 03:27:19 --> Helper loaded: form_helper
INFO - 2023-12-05 03:27:19 --> Helper loaded: lang_helper
INFO - 2023-12-05 03:27:19 --> Helper loaded: security_helper
INFO - 2023-12-05 03:27:19 --> Helper loaded: cookie_helper
INFO - 2023-12-05 03:27:19 --> Database Driver Class Initialized
INFO - 2023-12-05 03:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 03:27:19 --> Parser Class Initialized
INFO - 2023-12-05 03:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 03:27:19 --> Pagination Class Initialized
INFO - 2023-12-05 03:27:19 --> Form Validation Class Initialized
INFO - 2023-12-05 03:27:19 --> Controller Class Initialized
INFO - 2023-12-05 03:27:19 --> Model Class Initialized
DEBUG - 2023-12-05 03:27:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 03:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:27:19 --> Model Class Initialized
DEBUG - 2023-12-05 03:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:27:19 --> Model Class Initialized
INFO - 2023-12-05 03:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-05 03:27:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 03:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 03:27:19 --> Model Class Initialized
INFO - 2023-12-05 03:27:19 --> Model Class Initialized
INFO - 2023-12-05 03:27:19 --> Model Class Initialized
INFO - 2023-12-05 03:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 03:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 03:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 03:27:19 --> Final output sent to browser
DEBUG - 2023-12-05 03:27:19 --> Total execution time: 0.2254
ERROR - 2023-12-05 03:27:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 03:27:20 --> Config Class Initialized
INFO - 2023-12-05 03:27:20 --> Hooks Class Initialized
DEBUG - 2023-12-05 03:27:20 --> UTF-8 Support Enabled
INFO - 2023-12-05 03:27:20 --> Utf8 Class Initialized
INFO - 2023-12-05 03:27:20 --> URI Class Initialized
INFO - 2023-12-05 03:27:20 --> Router Class Initialized
INFO - 2023-12-05 03:27:20 --> Output Class Initialized
INFO - 2023-12-05 03:27:20 --> Security Class Initialized
DEBUG - 2023-12-05 03:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 03:27:20 --> Input Class Initialized
INFO - 2023-12-05 03:27:20 --> Language Class Initialized
INFO - 2023-12-05 03:27:20 --> Loader Class Initialized
INFO - 2023-12-05 03:27:20 --> Helper loaded: url_helper
INFO - 2023-12-05 03:27:20 --> Helper loaded: file_helper
INFO - 2023-12-05 03:27:20 --> Helper loaded: html_helper
INFO - 2023-12-05 03:27:20 --> Helper loaded: text_helper
INFO - 2023-12-05 03:27:20 --> Helper loaded: form_helper
INFO - 2023-12-05 03:27:20 --> Helper loaded: lang_helper
INFO - 2023-12-05 03:27:20 --> Helper loaded: security_helper
INFO - 2023-12-05 03:27:20 --> Helper loaded: cookie_helper
INFO - 2023-12-05 03:27:20 --> Database Driver Class Initialized
INFO - 2023-12-05 03:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 03:27:20 --> Parser Class Initialized
INFO - 2023-12-05 03:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 03:27:20 --> Pagination Class Initialized
INFO - 2023-12-05 03:27:20 --> Form Validation Class Initialized
INFO - 2023-12-05 03:27:20 --> Controller Class Initialized
INFO - 2023-12-05 03:27:20 --> Model Class Initialized
DEBUG - 2023-12-05 03:27:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 03:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:27:20 --> Model Class Initialized
DEBUG - 2023-12-05 03:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:27:20 --> Model Class Initialized
INFO - 2023-12-05 03:27:20 --> Final output sent to browser
DEBUG - 2023-12-05 03:27:20 --> Total execution time: 0.0674
ERROR - 2023-12-05 03:33:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 03:33:19 --> Config Class Initialized
INFO - 2023-12-05 03:33:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 03:33:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 03:33:19 --> Utf8 Class Initialized
INFO - 2023-12-05 03:33:19 --> URI Class Initialized
DEBUG - 2023-12-05 03:33:19 --> No URI present. Default controller set.
INFO - 2023-12-05 03:33:19 --> Router Class Initialized
INFO - 2023-12-05 03:33:19 --> Output Class Initialized
INFO - 2023-12-05 03:33:19 --> Security Class Initialized
DEBUG - 2023-12-05 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 03:33:19 --> Input Class Initialized
INFO - 2023-12-05 03:33:19 --> Language Class Initialized
INFO - 2023-12-05 03:33:19 --> Loader Class Initialized
INFO - 2023-12-05 03:33:19 --> Helper loaded: url_helper
INFO - 2023-12-05 03:33:19 --> Helper loaded: file_helper
INFO - 2023-12-05 03:33:19 --> Helper loaded: html_helper
INFO - 2023-12-05 03:33:19 --> Helper loaded: text_helper
INFO - 2023-12-05 03:33:19 --> Helper loaded: form_helper
INFO - 2023-12-05 03:33:19 --> Helper loaded: lang_helper
INFO - 2023-12-05 03:33:19 --> Helper loaded: security_helper
INFO - 2023-12-05 03:33:19 --> Helper loaded: cookie_helper
INFO - 2023-12-05 03:33:19 --> Database Driver Class Initialized
INFO - 2023-12-05 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 03:33:19 --> Parser Class Initialized
INFO - 2023-12-05 03:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 03:33:19 --> Pagination Class Initialized
INFO - 2023-12-05 03:33:19 --> Form Validation Class Initialized
INFO - 2023-12-05 03:33:19 --> Controller Class Initialized
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
DEBUG - 2023-12-05 03:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
DEBUG - 2023-12-05 03:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
DEBUG - 2023-12-05 03:33:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 03:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
INFO - 2023-12-05 03:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 03:33:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 03:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 03:33:19 --> Model Class Initialized
INFO - 2023-12-05 03:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 03:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 03:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 03:33:19 --> Final output sent to browser
DEBUG - 2023-12-05 03:33:19 --> Total execution time: 0.4204
ERROR - 2023-12-05 03:51:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 03:51:04 --> Config Class Initialized
INFO - 2023-12-05 03:51:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 03:51:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 03:51:04 --> Utf8 Class Initialized
INFO - 2023-12-05 03:51:04 --> URI Class Initialized
DEBUG - 2023-12-05 03:51:04 --> No URI present. Default controller set.
INFO - 2023-12-05 03:51:04 --> Router Class Initialized
INFO - 2023-12-05 03:51:04 --> Output Class Initialized
INFO - 2023-12-05 03:51:04 --> Security Class Initialized
DEBUG - 2023-12-05 03:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 03:51:04 --> Input Class Initialized
INFO - 2023-12-05 03:51:04 --> Language Class Initialized
INFO - 2023-12-05 03:51:04 --> Loader Class Initialized
INFO - 2023-12-05 03:51:04 --> Helper loaded: url_helper
INFO - 2023-12-05 03:51:04 --> Helper loaded: file_helper
INFO - 2023-12-05 03:51:04 --> Helper loaded: html_helper
INFO - 2023-12-05 03:51:04 --> Helper loaded: text_helper
INFO - 2023-12-05 03:51:04 --> Helper loaded: form_helper
INFO - 2023-12-05 03:51:04 --> Helper loaded: lang_helper
INFO - 2023-12-05 03:51:04 --> Helper loaded: security_helper
INFO - 2023-12-05 03:51:04 --> Helper loaded: cookie_helper
INFO - 2023-12-05 03:51:04 --> Database Driver Class Initialized
INFO - 2023-12-05 03:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 03:51:04 --> Parser Class Initialized
INFO - 2023-12-05 03:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 03:51:04 --> Pagination Class Initialized
INFO - 2023-12-05 03:51:04 --> Form Validation Class Initialized
INFO - 2023-12-05 03:51:04 --> Controller Class Initialized
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
DEBUG - 2023-12-05 03:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
DEBUG - 2023-12-05 03:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
DEBUG - 2023-12-05 03:51:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 03:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
INFO - 2023-12-05 03:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 03:51:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 03:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 03:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 03:51:04 --> Model Class Initialized
INFO - 2023-12-05 03:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 03:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 03:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 03:51:05 --> Final output sent to browser
DEBUG - 2023-12-05 03:51:05 --> Total execution time: 0.2251
ERROR - 2023-12-05 04:10:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 04:10:53 --> Config Class Initialized
INFO - 2023-12-05 04:10:53 --> Hooks Class Initialized
DEBUG - 2023-12-05 04:10:53 --> UTF-8 Support Enabled
INFO - 2023-12-05 04:10:53 --> Utf8 Class Initialized
INFO - 2023-12-05 04:10:53 --> URI Class Initialized
INFO - 2023-12-05 04:10:53 --> Router Class Initialized
INFO - 2023-12-05 04:10:53 --> Output Class Initialized
INFO - 2023-12-05 04:10:53 --> Security Class Initialized
DEBUG - 2023-12-05 04:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 04:10:53 --> Input Class Initialized
INFO - 2023-12-05 04:10:53 --> Language Class Initialized
ERROR - 2023-12-05 04:10:53 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-05 04:17:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 04:17:41 --> Config Class Initialized
INFO - 2023-12-05 04:17:41 --> Hooks Class Initialized
DEBUG - 2023-12-05 04:17:41 --> UTF-8 Support Enabled
INFO - 2023-12-05 04:17:41 --> Utf8 Class Initialized
INFO - 2023-12-05 04:17:41 --> URI Class Initialized
DEBUG - 2023-12-05 04:17:41 --> No URI present. Default controller set.
INFO - 2023-12-05 04:17:41 --> Router Class Initialized
INFO - 2023-12-05 04:17:41 --> Output Class Initialized
INFO - 2023-12-05 04:17:41 --> Security Class Initialized
DEBUG - 2023-12-05 04:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 04:17:41 --> Input Class Initialized
INFO - 2023-12-05 04:17:41 --> Language Class Initialized
INFO - 2023-12-05 04:17:41 --> Loader Class Initialized
INFO - 2023-12-05 04:17:41 --> Helper loaded: url_helper
INFO - 2023-12-05 04:17:41 --> Helper loaded: file_helper
INFO - 2023-12-05 04:17:41 --> Helper loaded: html_helper
INFO - 2023-12-05 04:17:41 --> Helper loaded: text_helper
INFO - 2023-12-05 04:17:41 --> Helper loaded: form_helper
INFO - 2023-12-05 04:17:41 --> Helper loaded: lang_helper
INFO - 2023-12-05 04:17:41 --> Helper loaded: security_helper
INFO - 2023-12-05 04:17:41 --> Helper loaded: cookie_helper
INFO - 2023-12-05 04:17:41 --> Database Driver Class Initialized
INFO - 2023-12-05 04:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 04:17:41 --> Parser Class Initialized
INFO - 2023-12-05 04:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 04:17:41 --> Pagination Class Initialized
INFO - 2023-12-05 04:17:41 --> Form Validation Class Initialized
INFO - 2023-12-05 04:17:41 --> Controller Class Initialized
INFO - 2023-12-05 04:17:41 --> Model Class Initialized
DEBUG - 2023-12-05 04:17:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 06:23:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 06:23:22 --> Config Class Initialized
INFO - 2023-12-05 06:23:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 06:23:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 06:23:22 --> Utf8 Class Initialized
INFO - 2023-12-05 06:23:22 --> URI Class Initialized
DEBUG - 2023-12-05 06:23:22 --> No URI present. Default controller set.
INFO - 2023-12-05 06:23:22 --> Router Class Initialized
INFO - 2023-12-05 06:23:22 --> Output Class Initialized
INFO - 2023-12-05 06:23:22 --> Security Class Initialized
DEBUG - 2023-12-05 06:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 06:23:22 --> Input Class Initialized
INFO - 2023-12-05 06:23:22 --> Language Class Initialized
INFO - 2023-12-05 06:23:22 --> Loader Class Initialized
INFO - 2023-12-05 06:23:22 --> Helper loaded: url_helper
INFO - 2023-12-05 06:23:22 --> Helper loaded: file_helper
INFO - 2023-12-05 06:23:22 --> Helper loaded: html_helper
INFO - 2023-12-05 06:23:22 --> Helper loaded: text_helper
INFO - 2023-12-05 06:23:22 --> Helper loaded: form_helper
INFO - 2023-12-05 06:23:22 --> Helper loaded: lang_helper
INFO - 2023-12-05 06:23:22 --> Helper loaded: security_helper
INFO - 2023-12-05 06:23:22 --> Helper loaded: cookie_helper
INFO - 2023-12-05 06:23:22 --> Database Driver Class Initialized
INFO - 2023-12-05 06:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 06:23:22 --> Parser Class Initialized
INFO - 2023-12-05 06:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 06:23:22 --> Pagination Class Initialized
INFO - 2023-12-05 06:23:22 --> Form Validation Class Initialized
INFO - 2023-12-05 06:23:22 --> Controller Class Initialized
INFO - 2023-12-05 06:23:22 --> Model Class Initialized
DEBUG - 2023-12-05 06:23:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 06:23:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 06:23:25 --> Config Class Initialized
INFO - 2023-12-05 06:23:25 --> Hooks Class Initialized
DEBUG - 2023-12-05 06:23:25 --> UTF-8 Support Enabled
INFO - 2023-12-05 06:23:25 --> Utf8 Class Initialized
INFO - 2023-12-05 06:23:25 --> URI Class Initialized
DEBUG - 2023-12-05 06:23:25 --> No URI present. Default controller set.
INFO - 2023-12-05 06:23:25 --> Router Class Initialized
INFO - 2023-12-05 06:23:25 --> Output Class Initialized
INFO - 2023-12-05 06:23:25 --> Security Class Initialized
DEBUG - 2023-12-05 06:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 06:23:25 --> Input Class Initialized
INFO - 2023-12-05 06:23:25 --> Language Class Initialized
INFO - 2023-12-05 06:23:25 --> Loader Class Initialized
INFO - 2023-12-05 06:23:25 --> Helper loaded: url_helper
INFO - 2023-12-05 06:23:25 --> Helper loaded: file_helper
INFO - 2023-12-05 06:23:25 --> Helper loaded: html_helper
INFO - 2023-12-05 06:23:25 --> Helper loaded: text_helper
INFO - 2023-12-05 06:23:25 --> Helper loaded: form_helper
INFO - 2023-12-05 06:23:25 --> Helper loaded: lang_helper
INFO - 2023-12-05 06:23:25 --> Helper loaded: security_helper
INFO - 2023-12-05 06:23:25 --> Helper loaded: cookie_helper
INFO - 2023-12-05 06:23:25 --> Database Driver Class Initialized
INFO - 2023-12-05 06:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 06:23:25 --> Parser Class Initialized
INFO - 2023-12-05 06:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 06:23:25 --> Pagination Class Initialized
INFO - 2023-12-05 06:23:25 --> Form Validation Class Initialized
INFO - 2023-12-05 06:23:25 --> Controller Class Initialized
INFO - 2023-12-05 06:23:25 --> Model Class Initialized
DEBUG - 2023-12-05 06:23:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 06:23:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 06:23:27 --> Config Class Initialized
INFO - 2023-12-05 06:23:27 --> Hooks Class Initialized
DEBUG - 2023-12-05 06:23:27 --> UTF-8 Support Enabled
INFO - 2023-12-05 06:23:27 --> Utf8 Class Initialized
INFO - 2023-12-05 06:23:27 --> URI Class Initialized
DEBUG - 2023-12-05 06:23:27 --> No URI present. Default controller set.
INFO - 2023-12-05 06:23:27 --> Router Class Initialized
INFO - 2023-12-05 06:23:27 --> Output Class Initialized
INFO - 2023-12-05 06:23:27 --> Security Class Initialized
DEBUG - 2023-12-05 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 06:23:27 --> Input Class Initialized
INFO - 2023-12-05 06:23:27 --> Language Class Initialized
INFO - 2023-12-05 06:23:27 --> Loader Class Initialized
INFO - 2023-12-05 06:23:27 --> Helper loaded: url_helper
INFO - 2023-12-05 06:23:27 --> Helper loaded: file_helper
INFO - 2023-12-05 06:23:27 --> Helper loaded: html_helper
INFO - 2023-12-05 06:23:27 --> Helper loaded: text_helper
INFO - 2023-12-05 06:23:27 --> Helper loaded: form_helper
INFO - 2023-12-05 06:23:27 --> Helper loaded: lang_helper
INFO - 2023-12-05 06:23:27 --> Helper loaded: security_helper
INFO - 2023-12-05 06:23:27 --> Helper loaded: cookie_helper
INFO - 2023-12-05 06:23:27 --> Database Driver Class Initialized
INFO - 2023-12-05 06:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 06:23:27 --> Parser Class Initialized
INFO - 2023-12-05 06:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 06:23:27 --> Pagination Class Initialized
INFO - 2023-12-05 06:23:27 --> Form Validation Class Initialized
INFO - 2023-12-05 06:23:27 --> Controller Class Initialized
INFO - 2023-12-05 06:23:27 --> Model Class Initialized
DEBUG - 2023-12-05 06:23:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 06:23:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 06:23:28 --> Config Class Initialized
INFO - 2023-12-05 06:23:28 --> Hooks Class Initialized
DEBUG - 2023-12-05 06:23:28 --> UTF-8 Support Enabled
INFO - 2023-12-05 06:23:28 --> Utf8 Class Initialized
INFO - 2023-12-05 06:23:28 --> URI Class Initialized
DEBUG - 2023-12-05 06:23:28 --> No URI present. Default controller set.
INFO - 2023-12-05 06:23:28 --> Router Class Initialized
INFO - 2023-12-05 06:23:28 --> Output Class Initialized
INFO - 2023-12-05 06:23:28 --> Security Class Initialized
DEBUG - 2023-12-05 06:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 06:23:28 --> Input Class Initialized
INFO - 2023-12-05 06:23:28 --> Language Class Initialized
INFO - 2023-12-05 06:23:28 --> Loader Class Initialized
INFO - 2023-12-05 06:23:28 --> Helper loaded: url_helper
INFO - 2023-12-05 06:23:28 --> Helper loaded: file_helper
INFO - 2023-12-05 06:23:28 --> Helper loaded: html_helper
INFO - 2023-12-05 06:23:28 --> Helper loaded: text_helper
INFO - 2023-12-05 06:23:28 --> Helper loaded: form_helper
INFO - 2023-12-05 06:23:28 --> Helper loaded: lang_helper
INFO - 2023-12-05 06:23:28 --> Helper loaded: security_helper
INFO - 2023-12-05 06:23:28 --> Helper loaded: cookie_helper
INFO - 2023-12-05 06:23:28 --> Database Driver Class Initialized
INFO - 2023-12-05 06:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 06:23:28 --> Parser Class Initialized
INFO - 2023-12-05 06:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 06:23:28 --> Pagination Class Initialized
INFO - 2023-12-05 06:23:28 --> Form Validation Class Initialized
INFO - 2023-12-05 06:23:28 --> Controller Class Initialized
INFO - 2023-12-05 06:23:28 --> Model Class Initialized
DEBUG - 2023-12-05 06:23:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 10:53:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:53:19 --> Config Class Initialized
INFO - 2023-12-05 10:53:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:53:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:53:19 --> Utf8 Class Initialized
INFO - 2023-12-05 10:53:19 --> URI Class Initialized
DEBUG - 2023-12-05 10:53:19 --> No URI present. Default controller set.
INFO - 2023-12-05 10:53:19 --> Router Class Initialized
INFO - 2023-12-05 10:53:19 --> Output Class Initialized
INFO - 2023-12-05 10:53:19 --> Security Class Initialized
DEBUG - 2023-12-05 10:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:53:19 --> Input Class Initialized
INFO - 2023-12-05 10:53:19 --> Language Class Initialized
INFO - 2023-12-05 10:53:19 --> Loader Class Initialized
INFO - 2023-12-05 10:53:19 --> Helper loaded: url_helper
INFO - 2023-12-05 10:53:19 --> Helper loaded: file_helper
INFO - 2023-12-05 10:53:19 --> Helper loaded: html_helper
INFO - 2023-12-05 10:53:19 --> Helper loaded: text_helper
INFO - 2023-12-05 10:53:19 --> Helper loaded: form_helper
INFO - 2023-12-05 10:53:19 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:53:19 --> Helper loaded: security_helper
INFO - 2023-12-05 10:53:19 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:53:19 --> Database Driver Class Initialized
INFO - 2023-12-05 10:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:53:19 --> Parser Class Initialized
INFO - 2023-12-05 10:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:53:19 --> Pagination Class Initialized
INFO - 2023-12-05 10:53:19 --> Form Validation Class Initialized
INFO - 2023-12-05 10:53:19 --> Controller Class Initialized
INFO - 2023-12-05 10:53:19 --> Model Class Initialized
DEBUG - 2023-12-05 10:53:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 10:53:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:53:20 --> Config Class Initialized
INFO - 2023-12-05 10:53:20 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:53:20 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:53:20 --> Utf8 Class Initialized
INFO - 2023-12-05 10:53:20 --> URI Class Initialized
INFO - 2023-12-05 10:53:20 --> Router Class Initialized
INFO - 2023-12-05 10:53:20 --> Output Class Initialized
INFO - 2023-12-05 10:53:20 --> Security Class Initialized
DEBUG - 2023-12-05 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:53:20 --> Input Class Initialized
INFO - 2023-12-05 10:53:20 --> Language Class Initialized
INFO - 2023-12-05 10:53:20 --> Loader Class Initialized
INFO - 2023-12-05 10:53:20 --> Helper loaded: url_helper
INFO - 2023-12-05 10:53:20 --> Helper loaded: file_helper
INFO - 2023-12-05 10:53:20 --> Helper loaded: html_helper
INFO - 2023-12-05 10:53:20 --> Helper loaded: text_helper
INFO - 2023-12-05 10:53:20 --> Helper loaded: form_helper
INFO - 2023-12-05 10:53:20 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:53:20 --> Helper loaded: security_helper
INFO - 2023-12-05 10:53:20 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:53:20 --> Database Driver Class Initialized
INFO - 2023-12-05 10:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:53:20 --> Parser Class Initialized
INFO - 2023-12-05 10:53:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:53:20 --> Pagination Class Initialized
INFO - 2023-12-05 10:53:20 --> Form Validation Class Initialized
INFO - 2023-12-05 10:53:20 --> Controller Class Initialized
INFO - 2023-12-05 10:53:20 --> Model Class Initialized
DEBUG - 2023-12-05 10:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 10:53:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 10:53:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 10:53:20 --> Model Class Initialized
INFO - 2023-12-05 10:53:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 10:53:20 --> Final output sent to browser
DEBUG - 2023-12-05 10:53:20 --> Total execution time: 0.0317
ERROR - 2023-12-05 10:53:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:53:51 --> Config Class Initialized
INFO - 2023-12-05 10:53:51 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:53:51 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:53:51 --> Utf8 Class Initialized
INFO - 2023-12-05 10:53:51 --> URI Class Initialized
INFO - 2023-12-05 10:53:51 --> Router Class Initialized
INFO - 2023-12-05 10:53:51 --> Output Class Initialized
INFO - 2023-12-05 10:53:51 --> Security Class Initialized
DEBUG - 2023-12-05 10:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:53:51 --> Input Class Initialized
INFO - 2023-12-05 10:53:51 --> Language Class Initialized
INFO - 2023-12-05 10:53:51 --> Loader Class Initialized
INFO - 2023-12-05 10:53:51 --> Helper loaded: url_helper
INFO - 2023-12-05 10:53:51 --> Helper loaded: file_helper
INFO - 2023-12-05 10:53:51 --> Helper loaded: html_helper
INFO - 2023-12-05 10:53:51 --> Helper loaded: text_helper
INFO - 2023-12-05 10:53:51 --> Helper loaded: form_helper
INFO - 2023-12-05 10:53:51 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:53:51 --> Helper loaded: security_helper
INFO - 2023-12-05 10:53:51 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:53:51 --> Database Driver Class Initialized
INFO - 2023-12-05 10:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:53:51 --> Parser Class Initialized
INFO - 2023-12-05 10:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:53:51 --> Pagination Class Initialized
INFO - 2023-12-05 10:53:51 --> Form Validation Class Initialized
INFO - 2023-12-05 10:53:51 --> Controller Class Initialized
INFO - 2023-12-05 10:53:51 --> Model Class Initialized
DEBUG - 2023-12-05 10:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:51 --> Model Class Initialized
INFO - 2023-12-05 10:53:51 --> Final output sent to browser
DEBUG - 2023-12-05 10:53:51 --> Total execution time: 0.0199
ERROR - 2023-12-05 10:53:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:53:52 --> Config Class Initialized
INFO - 2023-12-05 10:53:52 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:53:52 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:53:52 --> Utf8 Class Initialized
INFO - 2023-12-05 10:53:52 --> URI Class Initialized
DEBUG - 2023-12-05 10:53:52 --> No URI present. Default controller set.
INFO - 2023-12-05 10:53:52 --> Router Class Initialized
INFO - 2023-12-05 10:53:52 --> Output Class Initialized
INFO - 2023-12-05 10:53:52 --> Security Class Initialized
DEBUG - 2023-12-05 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:53:52 --> Input Class Initialized
INFO - 2023-12-05 10:53:52 --> Language Class Initialized
INFO - 2023-12-05 10:53:52 --> Loader Class Initialized
INFO - 2023-12-05 10:53:52 --> Helper loaded: url_helper
INFO - 2023-12-05 10:53:52 --> Helper loaded: file_helper
INFO - 2023-12-05 10:53:52 --> Helper loaded: html_helper
INFO - 2023-12-05 10:53:52 --> Helper loaded: text_helper
INFO - 2023-12-05 10:53:52 --> Helper loaded: form_helper
INFO - 2023-12-05 10:53:52 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:53:52 --> Helper loaded: security_helper
INFO - 2023-12-05 10:53:52 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:53:52 --> Database Driver Class Initialized
INFO - 2023-12-05 10:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:53:52 --> Parser Class Initialized
INFO - 2023-12-05 10:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:53:52 --> Pagination Class Initialized
INFO - 2023-12-05 10:53:52 --> Form Validation Class Initialized
INFO - 2023-12-05 10:53:52 --> Controller Class Initialized
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
DEBUG - 2023-12-05 10:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
DEBUG - 2023-12-05 10:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
DEBUG - 2023-12-05 10:53:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
INFO - 2023-12-05 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 10:53:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 10:53:52 --> Model Class Initialized
INFO - 2023-12-05 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 10:53:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 10:53:52 --> Final output sent to browser
DEBUG - 2023-12-05 10:53:52 --> Total execution time: 0.3781
ERROR - 2023-12-05 10:53:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:53:54 --> Config Class Initialized
INFO - 2023-12-05 10:53:54 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:53:54 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:53:54 --> Utf8 Class Initialized
INFO - 2023-12-05 10:53:54 --> URI Class Initialized
INFO - 2023-12-05 10:53:54 --> Router Class Initialized
INFO - 2023-12-05 10:53:54 --> Output Class Initialized
INFO - 2023-12-05 10:53:54 --> Security Class Initialized
DEBUG - 2023-12-05 10:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:53:54 --> Input Class Initialized
INFO - 2023-12-05 10:53:54 --> Language Class Initialized
INFO - 2023-12-05 10:53:54 --> Loader Class Initialized
INFO - 2023-12-05 10:53:54 --> Helper loaded: url_helper
INFO - 2023-12-05 10:53:54 --> Helper loaded: file_helper
INFO - 2023-12-05 10:53:54 --> Helper loaded: html_helper
INFO - 2023-12-05 10:53:54 --> Helper loaded: text_helper
INFO - 2023-12-05 10:53:54 --> Helper loaded: form_helper
INFO - 2023-12-05 10:53:54 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:53:54 --> Helper loaded: security_helper
INFO - 2023-12-05 10:53:54 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:53:54 --> Database Driver Class Initialized
INFO - 2023-12-05 10:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:53:54 --> Parser Class Initialized
INFO - 2023-12-05 10:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:53:54 --> Pagination Class Initialized
INFO - 2023-12-05 10:53:54 --> Form Validation Class Initialized
INFO - 2023-12-05 10:53:54 --> Controller Class Initialized
DEBUG - 2023-12-05 10:53:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:53:54 --> Model Class Initialized
INFO - 2023-12-05 10:53:54 --> Final output sent to browser
DEBUG - 2023-12-05 10:53:54 --> Total execution time: 0.0137
ERROR - 2023-12-05 10:54:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:54:07 --> Config Class Initialized
INFO - 2023-12-05 10:54:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:54:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:54:07 --> Utf8 Class Initialized
INFO - 2023-12-05 10:54:07 --> URI Class Initialized
INFO - 2023-12-05 10:54:07 --> Router Class Initialized
INFO - 2023-12-05 10:54:07 --> Output Class Initialized
INFO - 2023-12-05 10:54:07 --> Security Class Initialized
DEBUG - 2023-12-05 10:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:54:07 --> Input Class Initialized
INFO - 2023-12-05 10:54:07 --> Language Class Initialized
INFO - 2023-12-05 10:54:07 --> Loader Class Initialized
INFO - 2023-12-05 10:54:07 --> Helper loaded: url_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: file_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: html_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: text_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: form_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: security_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:54:07 --> Database Driver Class Initialized
INFO - 2023-12-05 10:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:54:07 --> Parser Class Initialized
INFO - 2023-12-05 10:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:54:07 --> Pagination Class Initialized
INFO - 2023-12-05 10:54:07 --> Form Validation Class Initialized
INFO - 2023-12-05 10:54:07 --> Controller Class Initialized
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
INFO - 2023-12-05 10:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-05 10:54:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 10:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
INFO - 2023-12-05 10:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 10:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 10:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 10:54:07 --> Final output sent to browser
DEBUG - 2023-12-05 10:54:07 --> Total execution time: 0.2245
ERROR - 2023-12-05 10:54:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:54:07 --> Config Class Initialized
INFO - 2023-12-05 10:54:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:54:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:54:07 --> Utf8 Class Initialized
INFO - 2023-12-05 10:54:07 --> URI Class Initialized
INFO - 2023-12-05 10:54:07 --> Router Class Initialized
INFO - 2023-12-05 10:54:07 --> Output Class Initialized
INFO - 2023-12-05 10:54:07 --> Security Class Initialized
DEBUG - 2023-12-05 10:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:54:07 --> Input Class Initialized
INFO - 2023-12-05 10:54:07 --> Language Class Initialized
INFO - 2023-12-05 10:54:07 --> Loader Class Initialized
INFO - 2023-12-05 10:54:07 --> Helper loaded: url_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: file_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: html_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: text_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: form_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: security_helper
INFO - 2023-12-05 10:54:07 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:54:07 --> Database Driver Class Initialized
INFO - 2023-12-05 10:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:54:07 --> Parser Class Initialized
INFO - 2023-12-05 10:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:54:07 --> Pagination Class Initialized
INFO - 2023-12-05 10:54:07 --> Form Validation Class Initialized
INFO - 2023-12-05 10:54:07 --> Controller Class Initialized
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:07 --> Model Class Initialized
INFO - 2023-12-05 10:54:07 --> Final output sent to browser
DEBUG - 2023-12-05 10:54:07 --> Total execution time: 0.0587
ERROR - 2023-12-05 10:54:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:54:13 --> Config Class Initialized
INFO - 2023-12-05 10:54:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:54:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:54:13 --> Utf8 Class Initialized
INFO - 2023-12-05 10:54:13 --> URI Class Initialized
INFO - 2023-12-05 10:54:13 --> Router Class Initialized
INFO - 2023-12-05 10:54:13 --> Output Class Initialized
INFO - 2023-12-05 10:54:13 --> Security Class Initialized
DEBUG - 2023-12-05 10:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:54:13 --> Input Class Initialized
INFO - 2023-12-05 10:54:13 --> Language Class Initialized
INFO - 2023-12-05 10:54:13 --> Loader Class Initialized
INFO - 2023-12-05 10:54:13 --> Helper loaded: url_helper
INFO - 2023-12-05 10:54:13 --> Helper loaded: file_helper
INFO - 2023-12-05 10:54:13 --> Helper loaded: html_helper
INFO - 2023-12-05 10:54:13 --> Helper loaded: text_helper
INFO - 2023-12-05 10:54:13 --> Helper loaded: form_helper
INFO - 2023-12-05 10:54:13 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:54:13 --> Helper loaded: security_helper
INFO - 2023-12-05 10:54:13 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:54:13 --> Database Driver Class Initialized
INFO - 2023-12-05 10:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:54:13 --> Parser Class Initialized
INFO - 2023-12-05 10:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:54:13 --> Pagination Class Initialized
INFO - 2023-12-05 10:54:13 --> Form Validation Class Initialized
INFO - 2023-12-05 10:54:13 --> Controller Class Initialized
INFO - 2023-12-05 10:54:13 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:13 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:13 --> Model Class Initialized
INFO - 2023-12-05 10:54:14 --> Final output sent to browser
DEBUG - 2023-12-05 10:54:14 --> Total execution time: 0.9021
ERROR - 2023-12-05 10:54:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:54:34 --> Config Class Initialized
INFO - 2023-12-05 10:54:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:54:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:54:34 --> Utf8 Class Initialized
INFO - 2023-12-05 10:54:34 --> URI Class Initialized
INFO - 2023-12-05 10:54:34 --> Router Class Initialized
INFO - 2023-12-05 10:54:34 --> Output Class Initialized
INFO - 2023-12-05 10:54:34 --> Security Class Initialized
DEBUG - 2023-12-05 10:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:54:34 --> Input Class Initialized
INFO - 2023-12-05 10:54:34 --> Language Class Initialized
INFO - 2023-12-05 10:54:34 --> Loader Class Initialized
INFO - 2023-12-05 10:54:34 --> Helper loaded: url_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: file_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: html_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: text_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: form_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: security_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:54:34 --> Database Driver Class Initialized
INFO - 2023-12-05 10:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:54:34 --> Parser Class Initialized
INFO - 2023-12-05 10:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:54:34 --> Pagination Class Initialized
INFO - 2023-12-05 10:54:34 --> Form Validation Class Initialized
INFO - 2023-12-05 10:54:34 --> Controller Class Initialized
DEBUG - 2023-12-05 10:54:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:34 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
DEBUG - 2023-12-05 10:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
INFO - 2023-12-05 10:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-12-05 10:54:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 10:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
INFO - 2023-12-05 10:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 10:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 10:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 10:54:34 --> Final output sent to browser
DEBUG - 2023-12-05 10:54:34 --> Total execution time: 0.2012
ERROR - 2023-12-05 10:54:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:54:34 --> Config Class Initialized
INFO - 2023-12-05 10:54:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:54:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:54:34 --> Utf8 Class Initialized
INFO - 2023-12-05 10:54:34 --> URI Class Initialized
INFO - 2023-12-05 10:54:34 --> Router Class Initialized
INFO - 2023-12-05 10:54:34 --> Output Class Initialized
INFO - 2023-12-05 10:54:34 --> Security Class Initialized
DEBUG - 2023-12-05 10:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:54:34 --> Input Class Initialized
INFO - 2023-12-05 10:54:34 --> Language Class Initialized
INFO - 2023-12-05 10:54:34 --> Loader Class Initialized
INFO - 2023-12-05 10:54:34 --> Helper loaded: url_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: file_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: html_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: text_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: form_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: security_helper
INFO - 2023-12-05 10:54:34 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:54:34 --> Database Driver Class Initialized
INFO - 2023-12-05 10:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:54:34 --> Parser Class Initialized
INFO - 2023-12-05 10:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:54:34 --> Pagination Class Initialized
INFO - 2023-12-05 10:54:34 --> Form Validation Class Initialized
INFO - 2023-12-05 10:54:34 --> Controller Class Initialized
DEBUG - 2023-12-05 10:54:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:54:34 --> Model Class Initialized
INFO - 2023-12-05 10:54:34 --> Final output sent to browser
DEBUG - 2023-12-05 10:54:34 --> Total execution time: 0.0157
ERROR - 2023-12-05 10:55:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:55:10 --> Config Class Initialized
INFO - 2023-12-05 10:55:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:55:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:55:10 --> Utf8 Class Initialized
INFO - 2023-12-05 10:55:10 --> URI Class Initialized
DEBUG - 2023-12-05 10:55:10 --> No URI present. Default controller set.
INFO - 2023-12-05 10:55:10 --> Router Class Initialized
INFO - 2023-12-05 10:55:10 --> Output Class Initialized
INFO - 2023-12-05 10:55:10 --> Security Class Initialized
DEBUG - 2023-12-05 10:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:55:10 --> Input Class Initialized
INFO - 2023-12-05 10:55:10 --> Language Class Initialized
INFO - 2023-12-05 10:55:10 --> Loader Class Initialized
INFO - 2023-12-05 10:55:10 --> Helper loaded: url_helper
INFO - 2023-12-05 10:55:10 --> Helper loaded: file_helper
INFO - 2023-12-05 10:55:10 --> Helper loaded: html_helper
INFO - 2023-12-05 10:55:10 --> Helper loaded: text_helper
INFO - 2023-12-05 10:55:10 --> Helper loaded: form_helper
INFO - 2023-12-05 10:55:10 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:55:10 --> Helper loaded: security_helper
INFO - 2023-12-05 10:55:10 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:55:10 --> Database Driver Class Initialized
INFO - 2023-12-05 10:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:55:10 --> Parser Class Initialized
INFO - 2023-12-05 10:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:55:10 --> Pagination Class Initialized
INFO - 2023-12-05 10:55:10 --> Form Validation Class Initialized
INFO - 2023-12-05 10:55:10 --> Controller Class Initialized
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
DEBUG - 2023-12-05 10:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
DEBUG - 2023-12-05 10:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
DEBUG - 2023-12-05 10:55:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
INFO - 2023-12-05 10:55:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-05 10:55:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 10:55:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 10:55:10 --> Model Class Initialized
INFO - 2023-12-05 10:55:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 10:55:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 10:55:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 10:55:10 --> Final output sent to browser
DEBUG - 2023-12-05 10:55:10 --> Total execution time: 0.3775
ERROR - 2023-12-05 10:55:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 10:55:31 --> Config Class Initialized
INFO - 2023-12-05 10:55:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:55:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:55:31 --> Utf8 Class Initialized
INFO - 2023-12-05 10:55:31 --> URI Class Initialized
INFO - 2023-12-05 10:55:31 --> Router Class Initialized
INFO - 2023-12-05 10:55:31 --> Output Class Initialized
INFO - 2023-12-05 10:55:31 --> Security Class Initialized
DEBUG - 2023-12-05 10:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:55:31 --> Input Class Initialized
INFO - 2023-12-05 10:55:31 --> Language Class Initialized
INFO - 2023-12-05 10:55:31 --> Loader Class Initialized
INFO - 2023-12-05 10:55:31 --> Helper loaded: url_helper
INFO - 2023-12-05 10:55:31 --> Helper loaded: file_helper
INFO - 2023-12-05 10:55:31 --> Helper loaded: html_helper
INFO - 2023-12-05 10:55:31 --> Helper loaded: text_helper
INFO - 2023-12-05 10:55:31 --> Helper loaded: form_helper
INFO - 2023-12-05 10:55:31 --> Helper loaded: lang_helper
INFO - 2023-12-05 10:55:31 --> Helper loaded: security_helper
INFO - 2023-12-05 10:55:31 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:55:31 --> Database Driver Class Initialized
INFO - 2023-12-05 10:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:55:31 --> Parser Class Initialized
INFO - 2023-12-05 10:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 10:55:31 --> Pagination Class Initialized
INFO - 2023-12-05 10:55:31 --> Form Validation Class Initialized
INFO - 2023-12-05 10:55:31 --> Controller Class Initialized
DEBUG - 2023-12-05 10:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:31 --> Model Class Initialized
INFO - 2023-12-05 10:55:31 --> Model Class Initialized
DEBUG - 2023-12-05 10:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 10:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:31 --> Model Class Initialized
DEBUG - 2023-12-05 10:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-12-05 10:55:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 10:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 10:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 10:55:31 --> Model Class Initialized
INFO - 2023-12-05 10:55:31 --> Model Class Initialized
INFO - 2023-12-05 10:55:31 --> Model Class Initialized
INFO - 2023-12-05 10:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-05 10:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-05 10:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 10:55:31 --> Final output sent to browser
DEBUG - 2023-12-05 10:55:31 --> Total execution time: 0.1871
ERROR - 2023-12-05 12:58:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:58:48 --> Config Class Initialized
INFO - 2023-12-05 12:58:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:58:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:58:48 --> Utf8 Class Initialized
INFO - 2023-12-05 12:58:48 --> URI Class Initialized
DEBUG - 2023-12-05 12:58:48 --> No URI present. Default controller set.
INFO - 2023-12-05 12:58:48 --> Router Class Initialized
INFO - 2023-12-05 12:58:48 --> Output Class Initialized
INFO - 2023-12-05 12:58:48 --> Security Class Initialized
DEBUG - 2023-12-05 12:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:58:48 --> Input Class Initialized
INFO - 2023-12-05 12:58:48 --> Language Class Initialized
INFO - 2023-12-05 12:58:48 --> Loader Class Initialized
INFO - 2023-12-05 12:58:48 --> Helper loaded: url_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: file_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: html_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: text_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: form_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: security_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:58:48 --> Database Driver Class Initialized
INFO - 2023-12-05 12:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:58:48 --> Parser Class Initialized
INFO - 2023-12-05 12:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:58:48 --> Pagination Class Initialized
INFO - 2023-12-05 12:58:48 --> Form Validation Class Initialized
INFO - 2023-12-05 12:58:48 --> Controller Class Initialized
INFO - 2023-12-05 12:58:48 --> Model Class Initialized
DEBUG - 2023-12-05 12:58:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 12:58:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:58:48 --> Config Class Initialized
INFO - 2023-12-05 12:58:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:58:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:58:48 --> Utf8 Class Initialized
INFO - 2023-12-05 12:58:48 --> URI Class Initialized
INFO - 2023-12-05 12:58:48 --> Router Class Initialized
INFO - 2023-12-05 12:58:48 --> Output Class Initialized
INFO - 2023-12-05 12:58:48 --> Security Class Initialized
DEBUG - 2023-12-05 12:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:58:48 --> Input Class Initialized
INFO - 2023-12-05 12:58:48 --> Language Class Initialized
INFO - 2023-12-05 12:58:48 --> Loader Class Initialized
INFO - 2023-12-05 12:58:48 --> Helper loaded: url_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: file_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: html_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: text_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: form_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: security_helper
INFO - 2023-12-05 12:58:48 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:58:48 --> Database Driver Class Initialized
INFO - 2023-12-05 12:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:58:48 --> Parser Class Initialized
INFO - 2023-12-05 12:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:58:48 --> Pagination Class Initialized
INFO - 2023-12-05 12:58:48 --> Form Validation Class Initialized
INFO - 2023-12-05 12:58:48 --> Controller Class Initialized
INFO - 2023-12-05 12:58:48 --> Model Class Initialized
DEBUG - 2023-12-05 12:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 12:58:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 12:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 12:58:48 --> Model Class Initialized
INFO - 2023-12-05 12:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 12:58:48 --> Final output sent to browser
DEBUG - 2023-12-05 12:58:48 --> Total execution time: 0.0344
ERROR - 2023-12-05 12:59:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:40 --> Config Class Initialized
INFO - 2023-12-05 12:59:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:40 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:40 --> URI Class Initialized
INFO - 2023-12-05 12:59:40 --> Router Class Initialized
INFO - 2023-12-05 12:59:40 --> Output Class Initialized
INFO - 2023-12-05 12:59:40 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:40 --> Input Class Initialized
INFO - 2023-12-05 12:59:40 --> Language Class Initialized
INFO - 2023-12-05 12:59:40 --> Loader Class Initialized
INFO - 2023-12-05 12:59:40 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:40 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:40 --> Parser Class Initialized
INFO - 2023-12-05 12:59:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:40 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:40 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:40 --> Controller Class Initialized
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
INFO - 2023-12-05 12:59:40 --> Final output sent to browser
DEBUG - 2023-12-05 12:59:40 --> Total execution time: 0.0243
ERROR - 2023-12-05 12:59:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:40 --> Config Class Initialized
INFO - 2023-12-05 12:59:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:40 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:40 --> URI Class Initialized
DEBUG - 2023-12-05 12:59:40 --> No URI present. Default controller set.
INFO - 2023-12-05 12:59:40 --> Router Class Initialized
INFO - 2023-12-05 12:59:40 --> Output Class Initialized
INFO - 2023-12-05 12:59:40 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:40 --> Input Class Initialized
INFO - 2023-12-05 12:59:40 --> Language Class Initialized
INFO - 2023-12-05 12:59:40 --> Loader Class Initialized
INFO - 2023-12-05 12:59:40 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:40 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:40 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:40 --> Parser Class Initialized
INFO - 2023-12-05 12:59:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:40 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:40 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:40 --> Controller Class Initialized
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 12:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
INFO - 2023-12-05 12:59:40 --> Model Class Initialized
ERROR - 2023-12-05 12:59:40 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'powera7m_maurnaturo.b.manufacturer_name' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `b`.`manufacturer_name`, `a`.`product_name`, `a`.`generic_name`, `a`.`strength`, ((select ifnull(sum(quantity), 0) from product_purchase_details where product_id= `a`.`product_id`)-(select ifnull(sum(quantity), 0) from invoice_details where product_id= `a`.`product_id`)) as 'stock'
FROM `product_information` `a`
LEFT JOIN `manufacturer_information` `b` ON `b`.`manufacturer_id`=`a`.`manufacturer_id`
GROUP BY `a`.`product_id`
HAVING `stock` < 10
ERROR - 2023-12-05 12:59:40 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/powera7m/app.maurnaturo.com/application/models/Reports.php 276
ERROR - 2023-12-05 12:59:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:47 --> Config Class Initialized
INFO - 2023-12-05 12:59:47 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:47 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:47 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:47 --> URI Class Initialized
INFO - 2023-12-05 12:59:47 --> Router Class Initialized
INFO - 2023-12-05 12:59:47 --> Output Class Initialized
INFO - 2023-12-05 12:59:47 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:47 --> Input Class Initialized
INFO - 2023-12-05 12:59:47 --> Language Class Initialized
INFO - 2023-12-05 12:59:47 --> Loader Class Initialized
INFO - 2023-12-05 12:59:47 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:47 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:47 --> Parser Class Initialized
INFO - 2023-12-05 12:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:47 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:47 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:47 --> Controller Class Initialized
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 12:59:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 12:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
INFO - 2023-12-05 12:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 12:59:47 --> Final output sent to browser
DEBUG - 2023-12-05 12:59:47 --> Total execution time: 0.0312
ERROR - 2023-12-05 12:59:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:47 --> Config Class Initialized
INFO - 2023-12-05 12:59:47 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:47 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:47 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:47 --> URI Class Initialized
INFO - 2023-12-05 12:59:47 --> Router Class Initialized
INFO - 2023-12-05 12:59:47 --> Output Class Initialized
INFO - 2023-12-05 12:59:47 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:47 --> Input Class Initialized
INFO - 2023-12-05 12:59:47 --> Language Class Initialized
INFO - 2023-12-05 12:59:47 --> Loader Class Initialized
INFO - 2023-12-05 12:59:47 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:47 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:47 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:47 --> Parser Class Initialized
INFO - 2023-12-05 12:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:47 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:47 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:47 --> Controller Class Initialized
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 12:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
INFO - 2023-12-05 12:59:47 --> Model Class Initialized
ERROR - 2023-12-05 12:59:47 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'powera7m_maurnaturo.b.manufacturer_name' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `b`.`manufacturer_name`, `a`.`product_name`, `a`.`generic_name`, `a`.`strength`, ((select ifnull(sum(quantity), 0) from product_purchase_details where product_id= `a`.`product_id`)-(select ifnull(sum(quantity), 0) from invoice_details where product_id= `a`.`product_id`)) as 'stock'
FROM `product_information` `a`
LEFT JOIN `manufacturer_information` `b` ON `b`.`manufacturer_id`=`a`.`manufacturer_id`
GROUP BY `a`.`product_id`
HAVING `stock` < 10
ERROR - 2023-12-05 12:59:47 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/powera7m/app.maurnaturo.com/application/models/Reports.php 276
ERROR - 2023-12-05 12:59:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:49 --> Config Class Initialized
INFO - 2023-12-05 12:59:49 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:49 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:49 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:49 --> URI Class Initialized
INFO - 2023-12-05 12:59:49 --> Router Class Initialized
INFO - 2023-12-05 12:59:49 --> Output Class Initialized
INFO - 2023-12-05 12:59:49 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:49 --> Input Class Initialized
INFO - 2023-12-05 12:59:49 --> Language Class Initialized
INFO - 2023-12-05 12:59:49 --> Loader Class Initialized
INFO - 2023-12-05 12:59:49 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:49 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:49 --> Parser Class Initialized
INFO - 2023-12-05 12:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:49 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:49 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:49 --> Controller Class Initialized
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 12:59:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 12:59:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
INFO - 2023-12-05 12:59:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 12:59:49 --> Final output sent to browser
DEBUG - 2023-12-05 12:59:49 --> Total execution time: 0.0303
ERROR - 2023-12-05 12:59:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:49 --> Config Class Initialized
INFO - 2023-12-05 12:59:49 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:49 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:49 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:49 --> URI Class Initialized
INFO - 2023-12-05 12:59:49 --> Router Class Initialized
INFO - 2023-12-05 12:59:49 --> Output Class Initialized
INFO - 2023-12-05 12:59:49 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:49 --> Input Class Initialized
INFO - 2023-12-05 12:59:49 --> Language Class Initialized
INFO - 2023-12-05 12:59:49 --> Loader Class Initialized
INFO - 2023-12-05 12:59:49 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:49 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:49 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:49 --> Parser Class Initialized
INFO - 2023-12-05 12:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:49 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:49 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:49 --> Controller Class Initialized
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 12:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
INFO - 2023-12-05 12:59:49 --> Model Class Initialized
ERROR - 2023-12-05 12:59:49 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'powera7m_maurnaturo.b.manufacturer_name' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `b`.`manufacturer_name`, `a`.`product_name`, `a`.`generic_name`, `a`.`strength`, ((select ifnull(sum(quantity), 0) from product_purchase_details where product_id= `a`.`product_id`)-(select ifnull(sum(quantity), 0) from invoice_details where product_id= `a`.`product_id`)) as 'stock'
FROM `product_information` `a`
LEFT JOIN `manufacturer_information` `b` ON `b`.`manufacturer_id`=`a`.`manufacturer_id`
GROUP BY `a`.`product_id`
HAVING `stock` < 10
ERROR - 2023-12-05 12:59:49 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/powera7m/app.maurnaturo.com/application/models/Reports.php 276
ERROR - 2023-12-05 12:59:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:50 --> Config Class Initialized
INFO - 2023-12-05 12:59:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:50 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:50 --> URI Class Initialized
INFO - 2023-12-05 12:59:50 --> Router Class Initialized
INFO - 2023-12-05 12:59:50 --> Output Class Initialized
INFO - 2023-12-05 12:59:50 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:50 --> Input Class Initialized
INFO - 2023-12-05 12:59:50 --> Language Class Initialized
INFO - 2023-12-05 12:59:50 --> Loader Class Initialized
INFO - 2023-12-05 12:59:50 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:50 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:50 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:50 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:50 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:50 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:50 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:50 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:50 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:50 --> Parser Class Initialized
INFO - 2023-12-05 12:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:50 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:50 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:50 --> Controller Class Initialized
INFO - 2023-12-05 12:59:50 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 12:59:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 12:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 12:59:50 --> Model Class Initialized
INFO - 2023-12-05 12:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 12:59:50 --> Final output sent to browser
DEBUG - 2023-12-05 12:59:50 --> Total execution time: 0.0299
ERROR - 2023-12-05 12:59:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 12:59:51 --> Config Class Initialized
INFO - 2023-12-05 12:59:51 --> Hooks Class Initialized
DEBUG - 2023-12-05 12:59:51 --> UTF-8 Support Enabled
INFO - 2023-12-05 12:59:51 --> Utf8 Class Initialized
INFO - 2023-12-05 12:59:51 --> URI Class Initialized
INFO - 2023-12-05 12:59:51 --> Router Class Initialized
INFO - 2023-12-05 12:59:51 --> Output Class Initialized
INFO - 2023-12-05 12:59:51 --> Security Class Initialized
DEBUG - 2023-12-05 12:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 12:59:51 --> Input Class Initialized
INFO - 2023-12-05 12:59:51 --> Language Class Initialized
INFO - 2023-12-05 12:59:51 --> Loader Class Initialized
INFO - 2023-12-05 12:59:51 --> Helper loaded: url_helper
INFO - 2023-12-05 12:59:51 --> Helper loaded: file_helper
INFO - 2023-12-05 12:59:51 --> Helper loaded: html_helper
INFO - 2023-12-05 12:59:51 --> Helper loaded: text_helper
INFO - 2023-12-05 12:59:51 --> Helper loaded: form_helper
INFO - 2023-12-05 12:59:51 --> Helper loaded: lang_helper
INFO - 2023-12-05 12:59:51 --> Helper loaded: security_helper
INFO - 2023-12-05 12:59:51 --> Helper loaded: cookie_helper
INFO - 2023-12-05 12:59:51 --> Database Driver Class Initialized
INFO - 2023-12-05 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 12:59:51 --> Parser Class Initialized
INFO - 2023-12-05 12:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 12:59:51 --> Pagination Class Initialized
INFO - 2023-12-05 12:59:51 --> Form Validation Class Initialized
INFO - 2023-12-05 12:59:51 --> Controller Class Initialized
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
DEBUG - 2023-12-05 12:59:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-05 12:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
INFO - 2023-12-05 12:59:51 --> Model Class Initialized
ERROR - 2023-12-05 12:59:51 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'powera7m_maurnaturo.b.manufacturer_name' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `b`.`manufacturer_name`, `a`.`product_name`, `a`.`generic_name`, `a`.`strength`, ((select ifnull(sum(quantity), 0) from product_purchase_details where product_id= `a`.`product_id`)-(select ifnull(sum(quantity), 0) from invoice_details where product_id= `a`.`product_id`)) as 'stock'
FROM `product_information` `a`
LEFT JOIN `manufacturer_information` `b` ON `b`.`manufacturer_id`=`a`.`manufacturer_id`
GROUP BY `a`.`product_id`
HAVING `stock` < 10
ERROR - 2023-12-05 12:59:51 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/powera7m/app.maurnaturo.com/application/models/Reports.php 276
ERROR - 2023-12-05 17:54:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 17:54:22 --> Config Class Initialized
INFO - 2023-12-05 17:54:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 17:54:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 17:54:22 --> Utf8 Class Initialized
INFO - 2023-12-05 17:54:22 --> URI Class Initialized
DEBUG - 2023-12-05 17:54:22 --> No URI present. Default controller set.
INFO - 2023-12-05 17:54:22 --> Router Class Initialized
INFO - 2023-12-05 17:54:22 --> Output Class Initialized
INFO - 2023-12-05 17:54:22 --> Security Class Initialized
DEBUG - 2023-12-05 17:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 17:54:22 --> Input Class Initialized
INFO - 2023-12-05 17:54:22 --> Language Class Initialized
INFO - 2023-12-05 17:54:22 --> Loader Class Initialized
INFO - 2023-12-05 17:54:22 --> Helper loaded: url_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: file_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: html_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: text_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: form_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: lang_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: security_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: cookie_helper
INFO - 2023-12-05 17:54:22 --> Database Driver Class Initialized
INFO - 2023-12-05 17:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 17:54:22 --> Parser Class Initialized
INFO - 2023-12-05 17:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 17:54:22 --> Pagination Class Initialized
INFO - 2023-12-05 17:54:22 --> Form Validation Class Initialized
INFO - 2023-12-05 17:54:22 --> Controller Class Initialized
INFO - 2023-12-05 17:54:22 --> Model Class Initialized
DEBUG - 2023-12-05 17:54:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-05 17:54:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 17:54:22 --> Config Class Initialized
INFO - 2023-12-05 17:54:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 17:54:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 17:54:22 --> Utf8 Class Initialized
INFO - 2023-12-05 17:54:22 --> URI Class Initialized
INFO - 2023-12-05 17:54:22 --> Router Class Initialized
INFO - 2023-12-05 17:54:22 --> Output Class Initialized
INFO - 2023-12-05 17:54:22 --> Security Class Initialized
DEBUG - 2023-12-05 17:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 17:54:22 --> Input Class Initialized
INFO - 2023-12-05 17:54:22 --> Language Class Initialized
INFO - 2023-12-05 17:54:22 --> Loader Class Initialized
INFO - 2023-12-05 17:54:22 --> Helper loaded: url_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: file_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: html_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: text_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: form_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: lang_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: security_helper
INFO - 2023-12-05 17:54:22 --> Helper loaded: cookie_helper
INFO - 2023-12-05 17:54:22 --> Database Driver Class Initialized
INFO - 2023-12-05 17:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 17:54:22 --> Parser Class Initialized
INFO - 2023-12-05 17:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 17:54:22 --> Pagination Class Initialized
INFO - 2023-12-05 17:54:22 --> Form Validation Class Initialized
INFO - 2023-12-05 17:54:22 --> Controller Class Initialized
INFO - 2023-12-05 17:54:22 --> Model Class Initialized
DEBUG - 2023-12-05 17:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-05 17:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-05 17:54:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-05 17:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-05 17:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-05 17:54:22 --> Model Class Initialized
INFO - 2023-12-05 17:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-05 17:54:22 --> Final output sent to browser
DEBUG - 2023-12-05 17:54:22 --> Total execution time: 0.0385
ERROR - 2023-12-05 18:12:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 18:12:02 --> Config Class Initialized
INFO - 2023-12-05 18:12:02 --> Hooks Class Initialized
DEBUG - 2023-12-05 18:12:02 --> UTF-8 Support Enabled
INFO - 2023-12-05 18:12:02 --> Utf8 Class Initialized
INFO - 2023-12-05 18:12:02 --> URI Class Initialized
INFO - 2023-12-05 18:12:02 --> Router Class Initialized
INFO - 2023-12-05 18:12:02 --> Output Class Initialized
INFO - 2023-12-05 18:12:02 --> Security Class Initialized
DEBUG - 2023-12-05 18:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 18:12:02 --> Input Class Initialized
INFO - 2023-12-05 18:12:02 --> Language Class Initialized
ERROR - 2023-12-05 18:12:02 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-05 18:24:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-05 18:24:01 --> Config Class Initialized
INFO - 2023-12-05 18:24:01 --> Hooks Class Initialized
DEBUG - 2023-12-05 18:24:01 --> UTF-8 Support Enabled
INFO - 2023-12-05 18:24:01 --> Utf8 Class Initialized
INFO - 2023-12-05 18:24:01 --> URI Class Initialized
DEBUG - 2023-12-05 18:24:01 --> No URI present. Default controller set.
INFO - 2023-12-05 18:24:01 --> Router Class Initialized
INFO - 2023-12-05 18:24:01 --> Output Class Initialized
INFO - 2023-12-05 18:24:01 --> Security Class Initialized
DEBUG - 2023-12-05 18:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 18:24:01 --> Input Class Initialized
INFO - 2023-12-05 18:24:01 --> Language Class Initialized
INFO - 2023-12-05 18:24:01 --> Loader Class Initialized
INFO - 2023-12-05 18:24:01 --> Helper loaded: url_helper
INFO - 2023-12-05 18:24:01 --> Helper loaded: file_helper
INFO - 2023-12-05 18:24:01 --> Helper loaded: html_helper
INFO - 2023-12-05 18:24:01 --> Helper loaded: text_helper
INFO - 2023-12-05 18:24:01 --> Helper loaded: form_helper
INFO - 2023-12-05 18:24:01 --> Helper loaded: lang_helper
INFO - 2023-12-05 18:24:01 --> Helper loaded: security_helper
INFO - 2023-12-05 18:24:01 --> Helper loaded: cookie_helper
INFO - 2023-12-05 18:24:01 --> Database Driver Class Initialized
INFO - 2023-12-05 18:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 18:24:01 --> Parser Class Initialized
INFO - 2023-12-05 18:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-05 18:24:01 --> Pagination Class Initialized
INFO - 2023-12-05 18:24:01 --> Form Validation Class Initialized
INFO - 2023-12-05 18:24:01 --> Controller Class Initialized
INFO - 2023-12-05 18:24:01 --> Model Class Initialized
DEBUG - 2023-12-05 18:24:01 --> Session class already loaded. Second attempt ignored.
