<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-18 00:58:28 --> Model Class Initialized
INFO - 2023-06-18 00:58:29 --> Model Class Initialized
INFO - 2023-06-18 00:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/accounts/tax_settings_update.php
DEBUG - 2023-06-18 00:58:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 00:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 00:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 00:58:29 --> Model Class Initialized
INFO - 2023-06-18 00:58:29 --> Model Class Initialized
INFO - 2023-06-18 00:58:29 --> Model Class Initialized
INFO - 2023-06-18 00:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 00:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 00:58:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 00:58:29 --> Final output sent to browser
DEBUG - 2023-06-18 00:58:29 --> Total execution time: 0.1285
INFO - 2023-06-18 01:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/sales_report.php
DEBUG - 2023-06-18 01:13:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 01:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 01:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 01:13:59 --> Model Class Initialized
INFO - 2023-06-18 01:13:59 --> Model Class Initialized
INFO - 2023-06-18 01:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 01:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 01:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 01:13:59 --> Final output sent to browser
DEBUG - 2023-06-18 01:13:59 --> Total execution time: 0.1174
INFO - 2023-06-18 01:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/sales_report.php
DEBUG - 2023-06-18 01:14:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 01:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 01:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 01:14:21 --> Model Class Initialized
INFO - 2023-06-18 01:14:21 --> Model Class Initialized
INFO - 2023-06-18 01:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 01:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 01:14:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 01:14:21 --> Final output sent to browser
DEBUG - 2023-06-18 01:14:21 --> Total execution time: 0.1299
INFO - 2023-06-18 01:54:54 --> Model Class Initialized
INFO - 2023-06-18 01:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/accounts/manage_income_tax.php
DEBUG - 2023-06-18 01:54:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 01:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 01:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 01:54:54 --> Model Class Initialized
INFO - 2023-06-18 01:54:54 --> Model Class Initialized
INFO - 2023-06-18 01:54:54 --> Model Class Initialized
INFO - 2023-06-18 01:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 01:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 01:54:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 01:54:54 --> Final output sent to browser
DEBUG - 2023-06-18 01:54:54 --> Total execution time: 0.1421
INFO - 2023-06-18 01:57:02 --> Model Class Initialized
INFO - 2023-06-18 01:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/accounts/tax_report.php
DEBUG - 2023-06-18 01:57:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 01:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 01:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 01:57:03 --> Model Class Initialized
INFO - 2023-06-18 01:57:03 --> Model Class Initialized
INFO - 2023-06-18 01:57:03 --> Model Class Initialized
INFO - 2023-06-18 01:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 01:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 01:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 01:57:03 --> Final output sent to browser
DEBUG - 2023-06-18 01:57:03 --> Total execution time: 0.1562
INFO - 2023-06-18 01:57:18 --> Model Class Initialized
INFO - 2023-06-18 01:57:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/accounts/tax_report.php
DEBUG - 2023-06-18 01:57:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 01:57:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 01:57:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 01:57:18 --> Model Class Initialized
INFO - 2023-06-18 01:57:18 --> Model Class Initialized
INFO - 2023-06-18 01:57:18 --> Model Class Initialized
INFO - 2023-06-18 01:57:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 01:57:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 01:57:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 01:57:18 --> Final output sent to browser
DEBUG - 2023-06-18 01:57:18 --> Total execution time: 0.1284
INFO - 2023-06-18 01:57:44 --> Model Class Initialized
INFO - 2023-06-18 01:57:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/accounts/invoice_wise_tax_report.php
DEBUG - 2023-06-18 01:57:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 01:57:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 01:57:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 01:57:44 --> Model Class Initialized
INFO - 2023-06-18 01:57:44 --> Model Class Initialized
INFO - 2023-06-18 01:57:44 --> Model Class Initialized
INFO - 2023-06-18 01:57:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 01:57:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 01:57:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 01:57:44 --> Final output sent to browser
DEBUG - 2023-06-18 01:57:44 --> Total execution time: 0.1238
INFO - 2023-06-18 01:59:41 --> Model Class Initialized
INFO - 2023-06-18 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/accounts/invoice_wise_tax_report.php
DEBUG - 2023-06-18 01:59:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 01:59:41 --> Model Class Initialized
INFO - 2023-06-18 01:59:41 --> Model Class Initialized
INFO - 2023-06-18 01:59:41 --> Model Class Initialized
INFO - 2023-06-18 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 01:59:41 --> Final output sent to browser
DEBUG - 2023-06-18 01:59:41 --> Total execution time: 0.1365
INFO - 2023-06-18 02:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/medicine_search.php
DEBUG - 2023-06-18 02:00:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 02:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 02:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 02:00:47 --> Model Class Initialized
INFO - 2023-06-18 02:00:47 --> Model Class Initialized
INFO - 2023-06-18 02:00:47 --> Model Class Initialized
INFO - 2023-06-18 02:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 02:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 02:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 02:00:47 --> Final output sent to browser
DEBUG - 2023-06-18 02:00:47 --> Total execution time: 0.1243
INFO - 2023-06-18 02:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/invoice_search.php
DEBUG - 2023-06-18 02:00:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 02:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 02:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 02:00:53 --> Model Class Initialized
INFO - 2023-06-18 02:00:53 --> Model Class Initialized
INFO - 2023-06-18 02:00:53 --> Model Class Initialized
INFO - 2023-06-18 02:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 02:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 02:00:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 02:00:53 --> Final output sent to browser
DEBUG - 2023-06-18 02:00:53 --> Total execution time: 0.1215
INFO - 2023-06-18 02:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/invoice_search.php
DEBUG - 2023-06-18 02:01:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 02:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 02:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 02:01:14 --> Model Class Initialized
INFO - 2023-06-18 02:01:14 --> Model Class Initialized
INFO - 2023-06-18 02:01:14 --> Model Class Initialized
INFO - 2023-06-18 02:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 02:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 02:01:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 02:01:14 --> Final output sent to browser
DEBUG - 2023-06-18 02:01:14 --> Total execution time: 0.1558
INFO - 2023-06-18 02:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/customer_search.php
DEBUG - 2023-06-18 02:01:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 02:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 02:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 02:01:43 --> Model Class Initialized
INFO - 2023-06-18 02:01:43 --> Model Class Initialized
INFO - 2023-06-18 02:01:43 --> Model Class Initialized
INFO - 2023-06-18 02:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 02:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 02:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 02:01:43 --> Final output sent to browser
DEBUG - 2023-06-18 02:01:43 --> Total execution time: 0.1269
INFO - 2023-06-18 02:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/customer_search.php
DEBUG - 2023-06-18 02:01:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 02:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 02:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 02:01:48 --> Model Class Initialized
INFO - 2023-06-18 02:01:48 --> Model Class Initialized
INFO - 2023-06-18 02:01:48 --> Model Class Initialized
INFO - 2023-06-18 02:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 02:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 02:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 02:01:48 --> Final output sent to browser
DEBUG - 2023-06-18 02:01:48 --> Total execution time: 0.1300
ERROR - 2023-06-18 06:46:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 06:46:07 --> Config Class Initialized
INFO - 2023-06-18 06:46:07 --> Hooks Class Initialized
DEBUG - 2023-06-18 06:46:07 --> UTF-8 Support Enabled
INFO - 2023-06-18 06:46:07 --> Utf8 Class Initialized
INFO - 2023-06-18 06:46:07 --> URI Class Initialized
DEBUG - 2023-06-18 06:46:07 --> No URI present. Default controller set.
INFO - 2023-06-18 06:46:07 --> Router Class Initialized
INFO - 2023-06-18 06:46:07 --> Output Class Initialized
INFO - 2023-06-18 06:46:07 --> Security Class Initialized
DEBUG - 2023-06-18 06:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 06:46:07 --> Input Class Initialized
INFO - 2023-06-18 06:46:07 --> Language Class Initialized
INFO - 2023-06-18 06:46:07 --> Loader Class Initialized
INFO - 2023-06-18 06:46:07 --> Helper loaded: url_helper
INFO - 2023-06-18 06:46:07 --> Helper loaded: file_helper
INFO - 2023-06-18 06:46:07 --> Helper loaded: html_helper
INFO - 2023-06-18 06:46:07 --> Helper loaded: text_helper
INFO - 2023-06-18 06:46:07 --> Helper loaded: form_helper
INFO - 2023-06-18 06:46:07 --> Helper loaded: lang_helper
INFO - 2023-06-18 06:46:07 --> Helper loaded: security_helper
INFO - 2023-06-18 06:46:07 --> Helper loaded: cookie_helper
INFO - 2023-06-18 06:46:07 --> Database Driver Class Initialized
INFO - 2023-06-18 06:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 06:46:07 --> Parser Class Initialized
INFO - 2023-06-18 06:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 06:46:07 --> Pagination Class Initialized
INFO - 2023-06-18 06:46:07 --> Form Validation Class Initialized
INFO - 2023-06-18 06:46:07 --> Controller Class Initialized
INFO - 2023-06-18 06:46:07 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-18 06:46:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 06:46:08 --> Config Class Initialized
INFO - 2023-06-18 06:46:08 --> Hooks Class Initialized
DEBUG - 2023-06-18 06:46:08 --> UTF-8 Support Enabled
INFO - 2023-06-18 06:46:08 --> Utf8 Class Initialized
INFO - 2023-06-18 06:46:08 --> URI Class Initialized
INFO - 2023-06-18 06:46:08 --> Router Class Initialized
INFO - 2023-06-18 06:46:08 --> Output Class Initialized
INFO - 2023-06-18 06:46:08 --> Security Class Initialized
DEBUG - 2023-06-18 06:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 06:46:08 --> Input Class Initialized
INFO - 2023-06-18 06:46:08 --> Language Class Initialized
INFO - 2023-06-18 06:46:08 --> Loader Class Initialized
INFO - 2023-06-18 06:46:08 --> Helper loaded: url_helper
INFO - 2023-06-18 06:46:08 --> Helper loaded: file_helper
INFO - 2023-06-18 06:46:08 --> Helper loaded: html_helper
INFO - 2023-06-18 06:46:08 --> Helper loaded: text_helper
INFO - 2023-06-18 06:46:08 --> Helper loaded: form_helper
INFO - 2023-06-18 06:46:08 --> Helper loaded: lang_helper
INFO - 2023-06-18 06:46:08 --> Helper loaded: security_helper
INFO - 2023-06-18 06:46:08 --> Helper loaded: cookie_helper
INFO - 2023-06-18 06:46:08 --> Database Driver Class Initialized
INFO - 2023-06-18 06:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 06:46:08 --> Parser Class Initialized
INFO - 2023-06-18 06:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 06:46:08 --> Pagination Class Initialized
INFO - 2023-06-18 06:46:08 --> Form Validation Class Initialized
INFO - 2023-06-18 06:46:08 --> Controller Class Initialized
INFO - 2023-06-18 06:46:08 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-18 06:46:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 06:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 06:46:08 --> Model Class Initialized
INFO - 2023-06-18 06:46:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 06:46:08 --> Final output sent to browser
DEBUG - 2023-06-18 06:46:08 --> Total execution time: 0.0315
ERROR - 2023-06-18 06:46:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 06:46:12 --> Config Class Initialized
INFO - 2023-06-18 06:46:12 --> Hooks Class Initialized
DEBUG - 2023-06-18 06:46:12 --> UTF-8 Support Enabled
INFO - 2023-06-18 06:46:12 --> Utf8 Class Initialized
INFO - 2023-06-18 06:46:12 --> URI Class Initialized
INFO - 2023-06-18 06:46:12 --> Router Class Initialized
INFO - 2023-06-18 06:46:12 --> Output Class Initialized
INFO - 2023-06-18 06:46:12 --> Security Class Initialized
DEBUG - 2023-06-18 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 06:46:12 --> Input Class Initialized
INFO - 2023-06-18 06:46:12 --> Language Class Initialized
INFO - 2023-06-18 06:46:12 --> Loader Class Initialized
INFO - 2023-06-18 06:46:12 --> Helper loaded: url_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: file_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: html_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: text_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: form_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: lang_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: security_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: cookie_helper
INFO - 2023-06-18 06:46:12 --> Database Driver Class Initialized
INFO - 2023-06-18 06:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 06:46:12 --> Parser Class Initialized
INFO - 2023-06-18 06:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 06:46:12 --> Pagination Class Initialized
INFO - 2023-06-18 06:46:12 --> Form Validation Class Initialized
INFO - 2023-06-18 06:46:12 --> Controller Class Initialized
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
INFO - 2023-06-18 06:46:12 --> Final output sent to browser
DEBUG - 2023-06-18 06:46:12 --> Total execution time: 0.0186
ERROR - 2023-06-18 06:46:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 06:46:12 --> Config Class Initialized
INFO - 2023-06-18 06:46:12 --> Hooks Class Initialized
DEBUG - 2023-06-18 06:46:12 --> UTF-8 Support Enabled
INFO - 2023-06-18 06:46:12 --> Utf8 Class Initialized
INFO - 2023-06-18 06:46:12 --> URI Class Initialized
DEBUG - 2023-06-18 06:46:12 --> No URI present. Default controller set.
INFO - 2023-06-18 06:46:12 --> Router Class Initialized
INFO - 2023-06-18 06:46:12 --> Output Class Initialized
INFO - 2023-06-18 06:46:12 --> Security Class Initialized
DEBUG - 2023-06-18 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 06:46:12 --> Input Class Initialized
INFO - 2023-06-18 06:46:12 --> Language Class Initialized
INFO - 2023-06-18 06:46:12 --> Loader Class Initialized
INFO - 2023-06-18 06:46:12 --> Helper loaded: url_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: file_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: html_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: text_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: form_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: lang_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: security_helper
INFO - 2023-06-18 06:46:12 --> Helper loaded: cookie_helper
INFO - 2023-06-18 06:46:12 --> Database Driver Class Initialized
INFO - 2023-06-18 06:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 06:46:12 --> Parser Class Initialized
INFO - 2023-06-18 06:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 06:46:12 --> Pagination Class Initialized
INFO - 2023-06-18 06:46:12 --> Form Validation Class Initialized
INFO - 2023-06-18 06:46:12 --> Controller Class Initialized
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 06:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
INFO - 2023-06-18 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-18 06:46:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 06:46:12 --> Model Class Initialized
INFO - 2023-06-18 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 06:46:12 --> Final output sent to browser
DEBUG - 2023-06-18 06:46:12 --> Total execution time: 0.2068
ERROR - 2023-06-18 06:46:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 06:46:13 --> Config Class Initialized
INFO - 2023-06-18 06:46:13 --> Hooks Class Initialized
DEBUG - 2023-06-18 06:46:13 --> UTF-8 Support Enabled
INFO - 2023-06-18 06:46:13 --> Utf8 Class Initialized
INFO - 2023-06-18 06:46:13 --> URI Class Initialized
INFO - 2023-06-18 06:46:13 --> Router Class Initialized
INFO - 2023-06-18 06:46:13 --> Output Class Initialized
INFO - 2023-06-18 06:46:13 --> Security Class Initialized
DEBUG - 2023-06-18 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 06:46:13 --> Input Class Initialized
INFO - 2023-06-18 06:46:13 --> Language Class Initialized
INFO - 2023-06-18 06:46:13 --> Loader Class Initialized
INFO - 2023-06-18 06:46:13 --> Helper loaded: url_helper
INFO - 2023-06-18 06:46:13 --> Helper loaded: file_helper
INFO - 2023-06-18 06:46:13 --> Helper loaded: html_helper
INFO - 2023-06-18 06:46:13 --> Helper loaded: text_helper
INFO - 2023-06-18 06:46:13 --> Helper loaded: form_helper
INFO - 2023-06-18 06:46:13 --> Helper loaded: lang_helper
INFO - 2023-06-18 06:46:13 --> Helper loaded: security_helper
INFO - 2023-06-18 06:46:13 --> Helper loaded: cookie_helper
INFO - 2023-06-18 06:46:13 --> Database Driver Class Initialized
INFO - 2023-06-18 06:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 06:46:13 --> Parser Class Initialized
INFO - 2023-06-18 06:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 06:46:13 --> Pagination Class Initialized
INFO - 2023-06-18 06:46:13 --> Form Validation Class Initialized
INFO - 2023-06-18 06:46:13 --> Controller Class Initialized
DEBUG - 2023-06-18 06:46:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 06:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:13 --> Model Class Initialized
INFO - 2023-06-18 06:46:13 --> Final output sent to browser
DEBUG - 2023-06-18 06:46:13 --> Total execution time: 0.0140
ERROR - 2023-06-18 06:46:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 06:46:35 --> Config Class Initialized
INFO - 2023-06-18 06:46:35 --> Hooks Class Initialized
DEBUG - 2023-06-18 06:46:35 --> UTF-8 Support Enabled
INFO - 2023-06-18 06:46:35 --> Utf8 Class Initialized
INFO - 2023-06-18 06:46:35 --> URI Class Initialized
DEBUG - 2023-06-18 06:46:35 --> No URI present. Default controller set.
INFO - 2023-06-18 06:46:35 --> Router Class Initialized
INFO - 2023-06-18 06:46:35 --> Output Class Initialized
INFO - 2023-06-18 06:46:35 --> Security Class Initialized
DEBUG - 2023-06-18 06:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 06:46:35 --> Input Class Initialized
INFO - 2023-06-18 06:46:35 --> Language Class Initialized
INFO - 2023-06-18 06:46:35 --> Loader Class Initialized
INFO - 2023-06-18 06:46:35 --> Helper loaded: url_helper
INFO - 2023-06-18 06:46:35 --> Helper loaded: file_helper
INFO - 2023-06-18 06:46:35 --> Helper loaded: html_helper
INFO - 2023-06-18 06:46:35 --> Helper loaded: text_helper
INFO - 2023-06-18 06:46:35 --> Helper loaded: form_helper
INFO - 2023-06-18 06:46:35 --> Helper loaded: lang_helper
INFO - 2023-06-18 06:46:35 --> Helper loaded: security_helper
INFO - 2023-06-18 06:46:35 --> Helper loaded: cookie_helper
INFO - 2023-06-18 06:46:35 --> Database Driver Class Initialized
INFO - 2023-06-18 06:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 06:46:35 --> Parser Class Initialized
INFO - 2023-06-18 06:46:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 06:46:35 --> Pagination Class Initialized
INFO - 2023-06-18 06:46:35 --> Form Validation Class Initialized
INFO - 2023-06-18 06:46:35 --> Controller Class Initialized
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
DEBUG - 2023-06-18 06:46:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 06:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
INFO - 2023-06-18 06:46:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-18 06:46:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 06:46:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 06:46:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 06:46:35 --> Model Class Initialized
INFO - 2023-06-18 06:46:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 06:46:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 06:46:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 06:46:35 --> Final output sent to browser
DEBUG - 2023-06-18 06:46:35 --> Total execution time: 0.1877
ERROR - 2023-06-18 12:24:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 12:24:29 --> Config Class Initialized
INFO - 2023-06-18 12:24:29 --> Hooks Class Initialized
DEBUG - 2023-06-18 12:24:29 --> UTF-8 Support Enabled
INFO - 2023-06-18 12:24:29 --> Utf8 Class Initialized
INFO - 2023-06-18 12:24:29 --> URI Class Initialized
DEBUG - 2023-06-18 12:24:29 --> No URI present. Default controller set.
INFO - 2023-06-18 12:24:29 --> Router Class Initialized
INFO - 2023-06-18 12:24:29 --> Output Class Initialized
INFO - 2023-06-18 12:24:29 --> Security Class Initialized
DEBUG - 2023-06-18 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 12:24:29 --> Input Class Initialized
INFO - 2023-06-18 12:24:29 --> Language Class Initialized
INFO - 2023-06-18 12:24:29 --> Loader Class Initialized
INFO - 2023-06-18 12:24:29 --> Helper loaded: url_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: file_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: html_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: text_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: form_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: lang_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: security_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: cookie_helper
INFO - 2023-06-18 12:24:29 --> Database Driver Class Initialized
INFO - 2023-06-18 12:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 12:24:29 --> Parser Class Initialized
INFO - 2023-06-18 12:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 12:24:29 --> Pagination Class Initialized
INFO - 2023-06-18 12:24:29 --> Form Validation Class Initialized
INFO - 2023-06-18 12:24:29 --> Controller Class Initialized
INFO - 2023-06-18 12:24:29 --> Model Class Initialized
DEBUG - 2023-06-18 12:24:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-18 12:24:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 12:24:29 --> Config Class Initialized
INFO - 2023-06-18 12:24:29 --> Hooks Class Initialized
DEBUG - 2023-06-18 12:24:29 --> UTF-8 Support Enabled
INFO - 2023-06-18 12:24:29 --> Utf8 Class Initialized
INFO - 2023-06-18 12:24:29 --> URI Class Initialized
INFO - 2023-06-18 12:24:29 --> Router Class Initialized
INFO - 2023-06-18 12:24:29 --> Output Class Initialized
INFO - 2023-06-18 12:24:29 --> Security Class Initialized
DEBUG - 2023-06-18 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 12:24:29 --> Input Class Initialized
INFO - 2023-06-18 12:24:29 --> Language Class Initialized
INFO - 2023-06-18 12:24:29 --> Loader Class Initialized
INFO - 2023-06-18 12:24:29 --> Helper loaded: url_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: file_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: html_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: text_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: form_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: lang_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: security_helper
INFO - 2023-06-18 12:24:29 --> Helper loaded: cookie_helper
INFO - 2023-06-18 12:24:30 --> Database Driver Class Initialized
INFO - 2023-06-18 12:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 12:24:30 --> Parser Class Initialized
INFO - 2023-06-18 12:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 12:24:30 --> Pagination Class Initialized
INFO - 2023-06-18 12:24:30 --> Form Validation Class Initialized
INFO - 2023-06-18 12:24:30 --> Controller Class Initialized
INFO - 2023-06-18 12:24:30 --> Model Class Initialized
DEBUG - 2023-06-18 12:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 12:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-18 12:24:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 12:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 12:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 12:24:30 --> Model Class Initialized
INFO - 2023-06-18 12:24:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 12:24:30 --> Final output sent to browser
DEBUG - 2023-06-18 12:24:30 --> Total execution time: 0.0329
ERROR - 2023-06-18 14:40:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:40:30 --> Config Class Initialized
INFO - 2023-06-18 14:40:30 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:40:30 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:40:30 --> Utf8 Class Initialized
INFO - 2023-06-18 14:40:30 --> URI Class Initialized
DEBUG - 2023-06-18 14:40:30 --> No URI present. Default controller set.
INFO - 2023-06-18 14:40:30 --> Router Class Initialized
INFO - 2023-06-18 14:40:30 --> Output Class Initialized
INFO - 2023-06-18 14:40:30 --> Security Class Initialized
DEBUG - 2023-06-18 14:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:40:30 --> Input Class Initialized
INFO - 2023-06-18 14:40:30 --> Language Class Initialized
INFO - 2023-06-18 14:40:30 --> Loader Class Initialized
INFO - 2023-06-18 14:40:30 --> Helper loaded: url_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: file_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: html_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: text_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: form_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: security_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:40:30 --> Database Driver Class Initialized
INFO - 2023-06-18 14:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:40:30 --> Parser Class Initialized
INFO - 2023-06-18 14:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:40:30 --> Pagination Class Initialized
INFO - 2023-06-18 14:40:30 --> Form Validation Class Initialized
INFO - 2023-06-18 14:40:30 --> Controller Class Initialized
INFO - 2023-06-18 14:40:30 --> Model Class Initialized
DEBUG - 2023-06-18 14:40:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-18 14:40:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:40:30 --> Config Class Initialized
INFO - 2023-06-18 14:40:30 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:40:30 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:40:30 --> Utf8 Class Initialized
INFO - 2023-06-18 14:40:30 --> URI Class Initialized
INFO - 2023-06-18 14:40:30 --> Router Class Initialized
INFO - 2023-06-18 14:40:30 --> Output Class Initialized
INFO - 2023-06-18 14:40:30 --> Security Class Initialized
DEBUG - 2023-06-18 14:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:40:30 --> Input Class Initialized
INFO - 2023-06-18 14:40:30 --> Language Class Initialized
INFO - 2023-06-18 14:40:30 --> Loader Class Initialized
INFO - 2023-06-18 14:40:30 --> Helper loaded: url_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: file_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: html_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: text_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: form_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: security_helper
INFO - 2023-06-18 14:40:30 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:40:30 --> Database Driver Class Initialized
INFO - 2023-06-18 14:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:40:30 --> Parser Class Initialized
INFO - 2023-06-18 14:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:40:30 --> Pagination Class Initialized
INFO - 2023-06-18 14:40:30 --> Form Validation Class Initialized
INFO - 2023-06-18 14:40:30 --> Controller Class Initialized
INFO - 2023-06-18 14:40:30 --> Model Class Initialized
DEBUG - 2023-06-18 14:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-18 14:40:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 14:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 14:40:30 --> Model Class Initialized
INFO - 2023-06-18 14:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 14:40:30 --> Final output sent to browser
DEBUG - 2023-06-18 14:40:30 --> Total execution time: 0.0322
ERROR - 2023-06-18 14:46:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:46:42 --> Config Class Initialized
INFO - 2023-06-18 14:46:42 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:46:42 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:46:42 --> Utf8 Class Initialized
INFO - 2023-06-18 14:46:42 --> URI Class Initialized
DEBUG - 2023-06-18 14:46:42 --> No URI present. Default controller set.
INFO - 2023-06-18 14:46:42 --> Router Class Initialized
INFO - 2023-06-18 14:46:42 --> Output Class Initialized
INFO - 2023-06-18 14:46:42 --> Security Class Initialized
DEBUG - 2023-06-18 14:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:46:42 --> Input Class Initialized
INFO - 2023-06-18 14:46:42 --> Language Class Initialized
INFO - 2023-06-18 14:46:42 --> Loader Class Initialized
INFO - 2023-06-18 14:46:42 --> Helper loaded: url_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: file_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: html_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: text_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: form_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: security_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:46:42 --> Database Driver Class Initialized
INFO - 2023-06-18 14:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:46:42 --> Parser Class Initialized
INFO - 2023-06-18 14:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:46:42 --> Pagination Class Initialized
INFO - 2023-06-18 14:46:42 --> Form Validation Class Initialized
INFO - 2023-06-18 14:46:42 --> Controller Class Initialized
INFO - 2023-06-18 14:46:42 --> Model Class Initialized
DEBUG - 2023-06-18 14:46:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-18 14:46:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:46:42 --> Config Class Initialized
INFO - 2023-06-18 14:46:42 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:46:42 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:46:42 --> Utf8 Class Initialized
INFO - 2023-06-18 14:46:42 --> URI Class Initialized
INFO - 2023-06-18 14:46:42 --> Router Class Initialized
INFO - 2023-06-18 14:46:42 --> Output Class Initialized
INFO - 2023-06-18 14:46:42 --> Security Class Initialized
DEBUG - 2023-06-18 14:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:46:42 --> Input Class Initialized
INFO - 2023-06-18 14:46:42 --> Language Class Initialized
INFO - 2023-06-18 14:46:42 --> Loader Class Initialized
INFO - 2023-06-18 14:46:42 --> Helper loaded: url_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: file_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: html_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: text_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: form_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: security_helper
INFO - 2023-06-18 14:46:42 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:46:42 --> Database Driver Class Initialized
INFO - 2023-06-18 14:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:46:42 --> Parser Class Initialized
INFO - 2023-06-18 14:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:46:42 --> Pagination Class Initialized
INFO - 2023-06-18 14:46:42 --> Form Validation Class Initialized
INFO - 2023-06-18 14:46:42 --> Controller Class Initialized
INFO - 2023-06-18 14:46:42 --> Model Class Initialized
DEBUG - 2023-06-18 14:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:46:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-18 14:46:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:46:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 14:46:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 14:46:42 --> Model Class Initialized
INFO - 2023-06-18 14:46:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 14:46:42 --> Final output sent to browser
DEBUG - 2023-06-18 14:46:42 --> Total execution time: 0.0312
ERROR - 2023-06-18 14:49:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:49:25 --> Config Class Initialized
INFO - 2023-06-18 14:49:25 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:49:25 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:49:25 --> Utf8 Class Initialized
INFO - 2023-06-18 14:49:25 --> URI Class Initialized
INFO - 2023-06-18 14:49:25 --> Router Class Initialized
INFO - 2023-06-18 14:49:25 --> Output Class Initialized
INFO - 2023-06-18 14:49:25 --> Security Class Initialized
DEBUG - 2023-06-18 14:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:49:25 --> Input Class Initialized
INFO - 2023-06-18 14:49:25 --> Language Class Initialized
INFO - 2023-06-18 14:49:25 --> Loader Class Initialized
INFO - 2023-06-18 14:49:25 --> Helper loaded: url_helper
INFO - 2023-06-18 14:49:25 --> Helper loaded: file_helper
INFO - 2023-06-18 14:49:25 --> Helper loaded: html_helper
INFO - 2023-06-18 14:49:25 --> Helper loaded: text_helper
INFO - 2023-06-18 14:49:25 --> Helper loaded: form_helper
INFO - 2023-06-18 14:49:25 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:49:25 --> Helper loaded: security_helper
INFO - 2023-06-18 14:49:25 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:49:25 --> Database Driver Class Initialized
INFO - 2023-06-18 14:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:49:25 --> Parser Class Initialized
INFO - 2023-06-18 14:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:49:25 --> Pagination Class Initialized
INFO - 2023-06-18 14:49:25 --> Form Validation Class Initialized
INFO - 2023-06-18 14:49:25 --> Controller Class Initialized
INFO - 2023-06-18 14:49:25 --> Model Class Initialized
DEBUG - 2023-06-18 14:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:49:25 --> Model Class Initialized
INFO - 2023-06-18 14:49:25 --> Final output sent to browser
DEBUG - 2023-06-18 14:49:25 --> Total execution time: 0.0206
ERROR - 2023-06-18 14:49:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:49:26 --> Config Class Initialized
INFO - 2023-06-18 14:49:26 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:49:26 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:49:26 --> Utf8 Class Initialized
INFO - 2023-06-18 14:49:26 --> URI Class Initialized
DEBUG - 2023-06-18 14:49:26 --> No URI present. Default controller set.
INFO - 2023-06-18 14:49:26 --> Router Class Initialized
INFO - 2023-06-18 14:49:26 --> Output Class Initialized
INFO - 2023-06-18 14:49:26 --> Security Class Initialized
DEBUG - 2023-06-18 14:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:49:26 --> Input Class Initialized
INFO - 2023-06-18 14:49:26 --> Language Class Initialized
INFO - 2023-06-18 14:49:26 --> Loader Class Initialized
INFO - 2023-06-18 14:49:26 --> Helper loaded: url_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: file_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: html_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: text_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: form_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: security_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:49:26 --> Database Driver Class Initialized
INFO - 2023-06-18 14:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:49:26 --> Parser Class Initialized
INFO - 2023-06-18 14:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:49:26 --> Pagination Class Initialized
INFO - 2023-06-18 14:49:26 --> Form Validation Class Initialized
INFO - 2023-06-18 14:49:26 --> Controller Class Initialized
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
DEBUG - 2023-06-18 14:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
DEBUG - 2023-06-18 14:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
DEBUG - 2023-06-18 14:49:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
INFO - 2023-06-18 14:49:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-18 14:49:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:49:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 14:49:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
INFO - 2023-06-18 14:49:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 14:49:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 14:49:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 14:49:26 --> Final output sent to browser
DEBUG - 2023-06-18 14:49:26 --> Total execution time: 0.1836
ERROR - 2023-06-18 14:49:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:49:26 --> Config Class Initialized
INFO - 2023-06-18 14:49:26 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:49:26 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:49:26 --> Utf8 Class Initialized
INFO - 2023-06-18 14:49:26 --> URI Class Initialized
INFO - 2023-06-18 14:49:26 --> Router Class Initialized
INFO - 2023-06-18 14:49:26 --> Output Class Initialized
INFO - 2023-06-18 14:49:26 --> Security Class Initialized
DEBUG - 2023-06-18 14:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:49:26 --> Input Class Initialized
INFO - 2023-06-18 14:49:26 --> Language Class Initialized
INFO - 2023-06-18 14:49:26 --> Loader Class Initialized
INFO - 2023-06-18 14:49:26 --> Helper loaded: url_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: file_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: html_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: text_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: form_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: security_helper
INFO - 2023-06-18 14:49:26 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:49:26 --> Database Driver Class Initialized
INFO - 2023-06-18 14:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:49:26 --> Parser Class Initialized
INFO - 2023-06-18 14:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:49:26 --> Pagination Class Initialized
INFO - 2023-06-18 14:49:26 --> Form Validation Class Initialized
INFO - 2023-06-18 14:49:26 --> Controller Class Initialized
DEBUG - 2023-06-18 14:49:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:49:26 --> Model Class Initialized
INFO - 2023-06-18 14:49:26 --> Final output sent to browser
DEBUG - 2023-06-18 14:49:26 --> Total execution time: 0.0142
ERROR - 2023-06-18 14:54:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:54:04 --> Config Class Initialized
INFO - 2023-06-18 14:54:04 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:54:04 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:54:04 --> Utf8 Class Initialized
INFO - 2023-06-18 14:54:04 --> URI Class Initialized
INFO - 2023-06-18 14:54:04 --> Router Class Initialized
INFO - 2023-06-18 14:54:04 --> Output Class Initialized
INFO - 2023-06-18 14:54:04 --> Security Class Initialized
DEBUG - 2023-06-18 14:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:54:04 --> Input Class Initialized
INFO - 2023-06-18 14:54:04 --> Language Class Initialized
INFO - 2023-06-18 14:54:04 --> Loader Class Initialized
INFO - 2023-06-18 14:54:04 --> Helper loaded: url_helper
INFO - 2023-06-18 14:54:04 --> Helper loaded: file_helper
INFO - 2023-06-18 14:54:04 --> Helper loaded: html_helper
INFO - 2023-06-18 14:54:04 --> Helper loaded: text_helper
INFO - 2023-06-18 14:54:04 --> Helper loaded: form_helper
INFO - 2023-06-18 14:54:04 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:54:04 --> Helper loaded: security_helper
INFO - 2023-06-18 14:54:04 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:54:04 --> Database Driver Class Initialized
INFO - 2023-06-18 14:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:54:04 --> Parser Class Initialized
INFO - 2023-06-18 14:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:54:04 --> Pagination Class Initialized
INFO - 2023-06-18 14:54:04 --> Form Validation Class Initialized
INFO - 2023-06-18 14:54:04 --> Controller Class Initialized
INFO - 2023-06-18 14:54:04 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:04 --> Model Class Initialized
INFO - 2023-06-18 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-18 14:54:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 14:54:04 --> Model Class Initialized
INFO - 2023-06-18 14:54:04 --> Model Class Initialized
INFO - 2023-06-18 14:54:04 --> Model Class Initialized
INFO - 2023-06-18 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 14:54:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 14:54:04 --> Final output sent to browser
DEBUG - 2023-06-18 14:54:04 --> Total execution time: 0.1497
ERROR - 2023-06-18 14:54:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:54:05 --> Config Class Initialized
INFO - 2023-06-18 14:54:05 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:54:05 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:54:05 --> Utf8 Class Initialized
INFO - 2023-06-18 14:54:05 --> URI Class Initialized
INFO - 2023-06-18 14:54:05 --> Router Class Initialized
INFO - 2023-06-18 14:54:05 --> Output Class Initialized
INFO - 2023-06-18 14:54:05 --> Security Class Initialized
DEBUG - 2023-06-18 14:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:54:05 --> Input Class Initialized
INFO - 2023-06-18 14:54:05 --> Language Class Initialized
INFO - 2023-06-18 14:54:05 --> Loader Class Initialized
INFO - 2023-06-18 14:54:05 --> Helper loaded: url_helper
INFO - 2023-06-18 14:54:05 --> Helper loaded: file_helper
INFO - 2023-06-18 14:54:05 --> Helper loaded: html_helper
INFO - 2023-06-18 14:54:05 --> Helper loaded: text_helper
INFO - 2023-06-18 14:54:05 --> Helper loaded: form_helper
INFO - 2023-06-18 14:54:05 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:54:05 --> Helper loaded: security_helper
INFO - 2023-06-18 14:54:05 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:54:05 --> Database Driver Class Initialized
INFO - 2023-06-18 14:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:54:05 --> Parser Class Initialized
INFO - 2023-06-18 14:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:54:05 --> Pagination Class Initialized
INFO - 2023-06-18 14:54:05 --> Form Validation Class Initialized
INFO - 2023-06-18 14:54:05 --> Controller Class Initialized
INFO - 2023-06-18 14:54:05 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:05 --> Model Class Initialized
INFO - 2023-06-18 14:54:05 --> Final output sent to browser
DEBUG - 2023-06-18 14:54:05 --> Total execution time: 0.0294
ERROR - 2023-06-18 14:54:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:54:12 --> Config Class Initialized
INFO - 2023-06-18 14:54:12 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:54:12 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:54:12 --> Utf8 Class Initialized
INFO - 2023-06-18 14:54:12 --> URI Class Initialized
INFO - 2023-06-18 14:54:12 --> Router Class Initialized
INFO - 2023-06-18 14:54:12 --> Output Class Initialized
INFO - 2023-06-18 14:54:12 --> Security Class Initialized
DEBUG - 2023-06-18 14:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:54:12 --> Input Class Initialized
INFO - 2023-06-18 14:54:12 --> Language Class Initialized
INFO - 2023-06-18 14:54:12 --> Loader Class Initialized
INFO - 2023-06-18 14:54:12 --> Helper loaded: url_helper
INFO - 2023-06-18 14:54:12 --> Helper loaded: file_helper
INFO - 2023-06-18 14:54:12 --> Helper loaded: html_helper
INFO - 2023-06-18 14:54:12 --> Helper loaded: text_helper
INFO - 2023-06-18 14:54:12 --> Helper loaded: form_helper
INFO - 2023-06-18 14:54:12 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:54:12 --> Helper loaded: security_helper
INFO - 2023-06-18 14:54:12 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:54:12 --> Database Driver Class Initialized
INFO - 2023-06-18 14:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:54:12 --> Parser Class Initialized
INFO - 2023-06-18 14:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:54:12 --> Pagination Class Initialized
INFO - 2023-06-18 14:54:12 --> Form Validation Class Initialized
INFO - 2023-06-18 14:54:12 --> Controller Class Initialized
INFO - 2023-06-18 14:54:12 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:12 --> Model Class Initialized
INFO - 2023-06-18 14:54:12 --> Final output sent to browser
DEBUG - 2023-06-18 14:54:12 --> Total execution time: 0.0721
ERROR - 2023-06-18 14:54:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:54:24 --> Config Class Initialized
INFO - 2023-06-18 14:54:24 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:54:24 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:54:24 --> Utf8 Class Initialized
INFO - 2023-06-18 14:54:24 --> URI Class Initialized
INFO - 2023-06-18 14:54:24 --> Router Class Initialized
INFO - 2023-06-18 14:54:24 --> Output Class Initialized
INFO - 2023-06-18 14:54:24 --> Security Class Initialized
DEBUG - 2023-06-18 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:54:24 --> Input Class Initialized
INFO - 2023-06-18 14:54:24 --> Language Class Initialized
INFO - 2023-06-18 14:54:24 --> Loader Class Initialized
INFO - 2023-06-18 14:54:24 --> Helper loaded: url_helper
INFO - 2023-06-18 14:54:24 --> Helper loaded: file_helper
INFO - 2023-06-18 14:54:24 --> Helper loaded: html_helper
INFO - 2023-06-18 14:54:24 --> Helper loaded: text_helper
INFO - 2023-06-18 14:54:24 --> Helper loaded: form_helper
INFO - 2023-06-18 14:54:24 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:54:24 --> Helper loaded: security_helper
INFO - 2023-06-18 14:54:24 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:54:24 --> Database Driver Class Initialized
INFO - 2023-06-18 14:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:54:24 --> Parser Class Initialized
INFO - 2023-06-18 14:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:54:24 --> Pagination Class Initialized
INFO - 2023-06-18 14:54:24 --> Form Validation Class Initialized
INFO - 2023-06-18 14:54:24 --> Controller Class Initialized
INFO - 2023-06-18 14:54:24 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:24 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-06-18 14:54:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 14:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 14:54:24 --> Model Class Initialized
INFO - 2023-06-18 14:54:24 --> Model Class Initialized
INFO - 2023-06-18 14:54:24 --> Model Class Initialized
INFO - 2023-06-18 14:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 14:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 14:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 14:54:24 --> Final output sent to browser
DEBUG - 2023-06-18 14:54:24 --> Total execution time: 0.1513
ERROR - 2023-06-18 14:54:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:54:31 --> Config Class Initialized
INFO - 2023-06-18 14:54:31 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:54:31 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:54:31 --> Utf8 Class Initialized
INFO - 2023-06-18 14:54:31 --> URI Class Initialized
INFO - 2023-06-18 14:54:31 --> Router Class Initialized
INFO - 2023-06-18 14:54:31 --> Output Class Initialized
INFO - 2023-06-18 14:54:31 --> Security Class Initialized
DEBUG - 2023-06-18 14:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:54:31 --> Input Class Initialized
INFO - 2023-06-18 14:54:31 --> Language Class Initialized
INFO - 2023-06-18 14:54:31 --> Loader Class Initialized
INFO - 2023-06-18 14:54:31 --> Helper loaded: url_helper
INFO - 2023-06-18 14:54:31 --> Helper loaded: file_helper
INFO - 2023-06-18 14:54:31 --> Helper loaded: html_helper
INFO - 2023-06-18 14:54:31 --> Helper loaded: text_helper
INFO - 2023-06-18 14:54:31 --> Helper loaded: form_helper
INFO - 2023-06-18 14:54:31 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:54:31 --> Helper loaded: security_helper
INFO - 2023-06-18 14:54:31 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:54:31 --> Database Driver Class Initialized
INFO - 2023-06-18 14:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:54:31 --> Parser Class Initialized
INFO - 2023-06-18 14:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:54:31 --> Pagination Class Initialized
INFO - 2023-06-18 14:54:31 --> Form Validation Class Initialized
INFO - 2023-06-18 14:54:31 --> Controller Class Initialized
INFO - 2023-06-18 14:54:31 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:31 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:31 --> Model Class Initialized
INFO - 2023-06-18 14:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-18 14:54:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 14:54:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 14:54:31 --> Model Class Initialized
INFO - 2023-06-18 14:54:31 --> Model Class Initialized
INFO - 2023-06-18 14:54:31 --> Model Class Initialized
INFO - 2023-06-18 14:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 14:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 14:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 14:54:32 --> Final output sent to browser
DEBUG - 2023-06-18 14:54:32 --> Total execution time: 0.1542
ERROR - 2023-06-18 14:54:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:54:32 --> Config Class Initialized
INFO - 2023-06-18 14:54:32 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:54:32 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:54:32 --> Utf8 Class Initialized
INFO - 2023-06-18 14:54:32 --> URI Class Initialized
INFO - 2023-06-18 14:54:32 --> Router Class Initialized
INFO - 2023-06-18 14:54:32 --> Output Class Initialized
INFO - 2023-06-18 14:54:32 --> Security Class Initialized
DEBUG - 2023-06-18 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:54:32 --> Input Class Initialized
INFO - 2023-06-18 14:54:32 --> Language Class Initialized
INFO - 2023-06-18 14:54:32 --> Loader Class Initialized
INFO - 2023-06-18 14:54:32 --> Helper loaded: url_helper
INFO - 2023-06-18 14:54:32 --> Helper loaded: file_helper
INFO - 2023-06-18 14:54:32 --> Helper loaded: html_helper
INFO - 2023-06-18 14:54:32 --> Helper loaded: text_helper
INFO - 2023-06-18 14:54:32 --> Helper loaded: form_helper
INFO - 2023-06-18 14:54:32 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:54:32 --> Helper loaded: security_helper
INFO - 2023-06-18 14:54:32 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:54:32 --> Database Driver Class Initialized
INFO - 2023-06-18 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:54:32 --> Parser Class Initialized
INFO - 2023-06-18 14:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:54:32 --> Pagination Class Initialized
INFO - 2023-06-18 14:54:32 --> Form Validation Class Initialized
INFO - 2023-06-18 14:54:32 --> Controller Class Initialized
INFO - 2023-06-18 14:54:32 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:32 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:32 --> Model Class Initialized
INFO - 2023-06-18 14:54:32 --> Final output sent to browser
DEBUG - 2023-06-18 14:54:32 --> Total execution time: 0.0625
ERROR - 2023-06-18 14:54:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 14:54:36 --> Config Class Initialized
INFO - 2023-06-18 14:54:36 --> Hooks Class Initialized
DEBUG - 2023-06-18 14:54:36 --> UTF-8 Support Enabled
INFO - 2023-06-18 14:54:36 --> Utf8 Class Initialized
INFO - 2023-06-18 14:54:36 --> URI Class Initialized
INFO - 2023-06-18 14:54:36 --> Router Class Initialized
INFO - 2023-06-18 14:54:36 --> Output Class Initialized
INFO - 2023-06-18 14:54:36 --> Security Class Initialized
DEBUG - 2023-06-18 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 14:54:36 --> Input Class Initialized
INFO - 2023-06-18 14:54:36 --> Language Class Initialized
INFO - 2023-06-18 14:54:36 --> Loader Class Initialized
INFO - 2023-06-18 14:54:36 --> Helper loaded: url_helper
INFO - 2023-06-18 14:54:36 --> Helper loaded: file_helper
INFO - 2023-06-18 14:54:36 --> Helper loaded: html_helper
INFO - 2023-06-18 14:54:36 --> Helper loaded: text_helper
INFO - 2023-06-18 14:54:36 --> Helper loaded: form_helper
INFO - 2023-06-18 14:54:36 --> Helper loaded: lang_helper
INFO - 2023-06-18 14:54:36 --> Helper loaded: security_helper
INFO - 2023-06-18 14:54:36 --> Helper loaded: cookie_helper
INFO - 2023-06-18 14:54:36 --> Database Driver Class Initialized
INFO - 2023-06-18 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 14:54:36 --> Parser Class Initialized
INFO - 2023-06-18 14:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 14:54:36 --> Pagination Class Initialized
INFO - 2023-06-18 14:54:36 --> Form Validation Class Initialized
INFO - 2023-06-18 14:54:36 --> Controller Class Initialized
INFO - 2023-06-18 14:54:36 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 14:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:36 --> Model Class Initialized
DEBUG - 2023-06-18 14:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 14:54:36 --> Model Class Initialized
INFO - 2023-06-18 14:54:37 --> Final output sent to browser
DEBUG - 2023-06-18 14:54:37 --> Total execution time: 0.2672
ERROR - 2023-06-18 17:37:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:07 --> Config Class Initialized
INFO - 2023-06-18 17:37:07 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:07 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:07 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:07 --> URI Class Initialized
DEBUG - 2023-06-18 17:37:07 --> No URI present. Default controller set.
INFO - 2023-06-18 17:37:07 --> Router Class Initialized
INFO - 2023-06-18 17:37:07 --> Output Class Initialized
INFO - 2023-06-18 17:37:07 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:07 --> Input Class Initialized
INFO - 2023-06-18 17:37:07 --> Language Class Initialized
INFO - 2023-06-18 17:37:07 --> Loader Class Initialized
INFO - 2023-06-18 17:37:07 --> Helper loaded: url_helper
INFO - 2023-06-18 17:37:07 --> Helper loaded: file_helper
INFO - 2023-06-18 17:37:07 --> Helper loaded: html_helper
INFO - 2023-06-18 17:37:07 --> Helper loaded: text_helper
INFO - 2023-06-18 17:37:07 --> Helper loaded: form_helper
INFO - 2023-06-18 17:37:07 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:37:07 --> Helper loaded: security_helper
INFO - 2023-06-18 17:37:07 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:37:07 --> Database Driver Class Initialized
INFO - 2023-06-18 17:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:37:07 --> Parser Class Initialized
INFO - 2023-06-18 17:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:37:07 --> Pagination Class Initialized
INFO - 2023-06-18 17:37:07 --> Form Validation Class Initialized
INFO - 2023-06-18 17:37:07 --> Controller Class Initialized
INFO - 2023-06-18 17:37:07 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-18 17:37:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:08 --> Config Class Initialized
INFO - 2023-06-18 17:37:08 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:08 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:08 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:08 --> URI Class Initialized
INFO - 2023-06-18 17:37:08 --> Router Class Initialized
INFO - 2023-06-18 17:37:08 --> Output Class Initialized
INFO - 2023-06-18 17:37:08 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:08 --> Input Class Initialized
INFO - 2023-06-18 17:37:08 --> Language Class Initialized
INFO - 2023-06-18 17:37:08 --> Loader Class Initialized
INFO - 2023-06-18 17:37:08 --> Helper loaded: url_helper
INFO - 2023-06-18 17:37:08 --> Helper loaded: file_helper
INFO - 2023-06-18 17:37:08 --> Helper loaded: html_helper
INFO - 2023-06-18 17:37:08 --> Helper loaded: text_helper
INFO - 2023-06-18 17:37:08 --> Helper loaded: form_helper
INFO - 2023-06-18 17:37:08 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:37:08 --> Helper loaded: security_helper
INFO - 2023-06-18 17:37:08 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:37:08 --> Database Driver Class Initialized
INFO - 2023-06-18 17:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:37:08 --> Parser Class Initialized
INFO - 2023-06-18 17:37:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:37:08 --> Pagination Class Initialized
INFO - 2023-06-18 17:37:08 --> Form Validation Class Initialized
INFO - 2023-06-18 17:37:08 --> Controller Class Initialized
INFO - 2023-06-18 17:37:08 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-18 17:37:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 17:37:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 17:37:08 --> Model Class Initialized
INFO - 2023-06-18 17:37:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 17:37:08 --> Final output sent to browser
DEBUG - 2023-06-18 17:37:08 --> Total execution time: 0.0347
ERROR - 2023-06-18 17:37:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:08 --> Config Class Initialized
INFO - 2023-06-18 17:37:08 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:08 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:08 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:08 --> URI Class Initialized
INFO - 2023-06-18 17:37:08 --> Router Class Initialized
INFO - 2023-06-18 17:37:08 --> Output Class Initialized
INFO - 2023-06-18 17:37:08 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:08 --> Input Class Initialized
INFO - 2023-06-18 17:37:08 --> Language Class Initialized
ERROR - 2023-06-18 17:37:08 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-06-18 17:37:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:08 --> Config Class Initialized
INFO - 2023-06-18 17:37:08 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:08 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:08 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:08 --> URI Class Initialized
INFO - 2023-06-18 17:37:08 --> Router Class Initialized
INFO - 2023-06-18 17:37:08 --> Output Class Initialized
INFO - 2023-06-18 17:37:08 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:08 --> Input Class Initialized
INFO - 2023-06-18 17:37:08 --> Language Class Initialized
ERROR - 2023-06-18 17:37:08 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-06-18 17:37:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:13 --> Config Class Initialized
INFO - 2023-06-18 17:37:13 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:13 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:13 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:13 --> URI Class Initialized
INFO - 2023-06-18 17:37:13 --> Router Class Initialized
INFO - 2023-06-18 17:37:13 --> Output Class Initialized
INFO - 2023-06-18 17:37:13 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:13 --> Input Class Initialized
INFO - 2023-06-18 17:37:13 --> Language Class Initialized
INFO - 2023-06-18 17:37:13 --> Loader Class Initialized
INFO - 2023-06-18 17:37:13 --> Helper loaded: url_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: file_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: html_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: text_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: form_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: security_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:37:13 --> Database Driver Class Initialized
INFO - 2023-06-18 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:37:13 --> Parser Class Initialized
INFO - 2023-06-18 17:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:37:13 --> Pagination Class Initialized
INFO - 2023-06-18 17:37:13 --> Form Validation Class Initialized
INFO - 2023-06-18 17:37:13 --> Controller Class Initialized
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
INFO - 2023-06-18 17:37:13 --> Final output sent to browser
DEBUG - 2023-06-18 17:37:13 --> Total execution time: 0.0202
ERROR - 2023-06-18 17:37:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:13 --> Config Class Initialized
INFO - 2023-06-18 17:37:13 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:13 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:13 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:13 --> URI Class Initialized
DEBUG - 2023-06-18 17:37:13 --> No URI present. Default controller set.
INFO - 2023-06-18 17:37:13 --> Router Class Initialized
INFO - 2023-06-18 17:37:13 --> Output Class Initialized
INFO - 2023-06-18 17:37:13 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:13 --> Input Class Initialized
INFO - 2023-06-18 17:37:13 --> Language Class Initialized
INFO - 2023-06-18 17:37:13 --> Loader Class Initialized
INFO - 2023-06-18 17:37:13 --> Helper loaded: url_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: file_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: html_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: text_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: form_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: security_helper
INFO - 2023-06-18 17:37:13 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:37:13 --> Database Driver Class Initialized
INFO - 2023-06-18 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:37:13 --> Parser Class Initialized
INFO - 2023-06-18 17:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:37:13 --> Pagination Class Initialized
INFO - 2023-06-18 17:37:13 --> Form Validation Class Initialized
INFO - 2023-06-18 17:37:13 --> Controller Class Initialized
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-18 17:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
INFO - 2023-06-18 17:37:13 --> Model Class Initialized
INFO - 2023-06-18 17:37:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-18 17:37:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 17:37:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 17:37:14 --> Model Class Initialized
INFO - 2023-06-18 17:37:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-18 17:37:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-18 17:37:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 17:37:14 --> Final output sent to browser
DEBUG - 2023-06-18 17:37:14 --> Total execution time: 0.0850
ERROR - 2023-06-18 17:37:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:34 --> Config Class Initialized
INFO - 2023-06-18 17:37:34 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:34 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:34 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:34 --> URI Class Initialized
INFO - 2023-06-18 17:37:34 --> Router Class Initialized
INFO - 2023-06-18 17:37:34 --> Output Class Initialized
INFO - 2023-06-18 17:37:34 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:34 --> Input Class Initialized
INFO - 2023-06-18 17:37:34 --> Language Class Initialized
INFO - 2023-06-18 17:37:34 --> Loader Class Initialized
INFO - 2023-06-18 17:37:34 --> Helper loaded: url_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: file_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: html_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: text_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: form_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: security_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:37:34 --> Database Driver Class Initialized
INFO - 2023-06-18 17:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:37:34 --> Parser Class Initialized
INFO - 2023-06-18 17:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:37:34 --> Pagination Class Initialized
INFO - 2023-06-18 17:37:34 --> Form Validation Class Initialized
INFO - 2023-06-18 17:37:34 --> Controller Class Initialized
INFO - 2023-06-18 17:37:34 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:34 --> Final output sent to browser
DEBUG - 2023-06-18 17:37:34 --> Total execution time: 0.0154
ERROR - 2023-06-18 17:37:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:37:34 --> Config Class Initialized
INFO - 2023-06-18 17:37:34 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:37:34 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:37:34 --> Utf8 Class Initialized
INFO - 2023-06-18 17:37:34 --> URI Class Initialized
INFO - 2023-06-18 17:37:34 --> Router Class Initialized
INFO - 2023-06-18 17:37:34 --> Output Class Initialized
INFO - 2023-06-18 17:37:34 --> Security Class Initialized
DEBUG - 2023-06-18 17:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:37:34 --> Input Class Initialized
INFO - 2023-06-18 17:37:34 --> Language Class Initialized
INFO - 2023-06-18 17:37:34 --> Loader Class Initialized
INFO - 2023-06-18 17:37:34 --> Helper loaded: url_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: file_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: html_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: text_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: form_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: security_helper
INFO - 2023-06-18 17:37:34 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:37:34 --> Database Driver Class Initialized
INFO - 2023-06-18 17:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:37:34 --> Parser Class Initialized
INFO - 2023-06-18 17:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:37:34 --> Pagination Class Initialized
INFO - 2023-06-18 17:37:34 --> Form Validation Class Initialized
INFO - 2023-06-18 17:37:34 --> Controller Class Initialized
INFO - 2023-06-18 17:37:34 --> Model Class Initialized
DEBUG - 2023-06-18 17:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-18 17:37:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 17:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 17:37:34 --> Model Class Initialized
INFO - 2023-06-18 17:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 17:37:34 --> Final output sent to browser
DEBUG - 2023-06-18 17:37:34 --> Total execution time: 0.0294
ERROR - 2023-06-18 17:47:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:47:50 --> Config Class Initialized
INFO - 2023-06-18 17:47:50 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:47:50 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:47:50 --> Utf8 Class Initialized
INFO - 2023-06-18 17:47:50 --> URI Class Initialized
DEBUG - 2023-06-18 17:47:50 --> No URI present. Default controller set.
INFO - 2023-06-18 17:47:50 --> Router Class Initialized
INFO - 2023-06-18 17:47:50 --> Output Class Initialized
INFO - 2023-06-18 17:47:50 --> Security Class Initialized
DEBUG - 2023-06-18 17:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:47:50 --> Input Class Initialized
INFO - 2023-06-18 17:47:50 --> Language Class Initialized
INFO - 2023-06-18 17:47:50 --> Loader Class Initialized
INFO - 2023-06-18 17:47:50 --> Helper loaded: url_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: file_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: html_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: text_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: form_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: security_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:47:50 --> Database Driver Class Initialized
INFO - 2023-06-18 17:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:47:50 --> Parser Class Initialized
INFO - 2023-06-18 17:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:47:50 --> Pagination Class Initialized
INFO - 2023-06-18 17:47:50 --> Form Validation Class Initialized
INFO - 2023-06-18 17:47:50 --> Controller Class Initialized
INFO - 2023-06-18 17:47:50 --> Model Class Initialized
DEBUG - 2023-06-18 17:47:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-18 17:47:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-18 17:47:50 --> Config Class Initialized
INFO - 2023-06-18 17:47:50 --> Hooks Class Initialized
DEBUG - 2023-06-18 17:47:50 --> UTF-8 Support Enabled
INFO - 2023-06-18 17:47:50 --> Utf8 Class Initialized
INFO - 2023-06-18 17:47:50 --> URI Class Initialized
INFO - 2023-06-18 17:47:50 --> Router Class Initialized
INFO - 2023-06-18 17:47:50 --> Output Class Initialized
INFO - 2023-06-18 17:47:50 --> Security Class Initialized
DEBUG - 2023-06-18 17:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-18 17:47:50 --> Input Class Initialized
INFO - 2023-06-18 17:47:50 --> Language Class Initialized
INFO - 2023-06-18 17:47:50 --> Loader Class Initialized
INFO - 2023-06-18 17:47:50 --> Helper loaded: url_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: file_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: html_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: text_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: form_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: lang_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: security_helper
INFO - 2023-06-18 17:47:50 --> Helper loaded: cookie_helper
INFO - 2023-06-18 17:47:50 --> Database Driver Class Initialized
INFO - 2023-06-18 17:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-18 17:47:50 --> Parser Class Initialized
INFO - 2023-06-18 17:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-18 17:47:50 --> Pagination Class Initialized
INFO - 2023-06-18 17:47:50 --> Form Validation Class Initialized
INFO - 2023-06-18 17:47:50 --> Controller Class Initialized
INFO - 2023-06-18 17:47:50 --> Model Class Initialized
DEBUG - 2023-06-18 17:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-18 17:47:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-18 17:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-18 17:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-18 17:47:50 --> Model Class Initialized
INFO - 2023-06-18 17:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-18 17:47:50 --> Final output sent to browser
DEBUG - 2023-06-18 17:47:50 --> Total execution time: 0.0318
