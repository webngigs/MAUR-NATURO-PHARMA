<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-05 13:31:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 13:31:15 --> Config Class Initialized
INFO - 2024-04-05 13:31:15 --> Hooks Class Initialized
DEBUG - 2024-04-05 13:31:15 --> UTF-8 Support Enabled
INFO - 2024-04-05 13:31:15 --> Utf8 Class Initialized
INFO - 2024-04-05 13:31:15 --> URI Class Initialized
INFO - 2024-04-05 13:31:15 --> Router Class Initialized
INFO - 2024-04-05 13:31:15 --> Output Class Initialized
INFO - 2024-04-05 13:31:15 --> Security Class Initialized
DEBUG - 2024-04-05 13:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 13:31:15 --> Input Class Initialized
INFO - 2024-04-05 13:31:15 --> Language Class Initialized
ERROR - 2024-04-05 13:31:15 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-05 18:41:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:06 --> Config Class Initialized
INFO - 2024-04-05 18:41:06 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:06 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:06 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:06 --> URI Class Initialized
DEBUG - 2024-04-05 18:41:06 --> No URI present. Default controller set.
INFO - 2024-04-05 18:41:06 --> Router Class Initialized
INFO - 2024-04-05 18:41:06 --> Output Class Initialized
INFO - 2024-04-05 18:41:06 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:06 --> Input Class Initialized
INFO - 2024-04-05 18:41:06 --> Language Class Initialized
INFO - 2024-04-05 18:41:06 --> Loader Class Initialized
INFO - 2024-04-05 18:41:06 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:06 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:06 --> Parser Class Initialized
INFO - 2024-04-05 18:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:06 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:06 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:06 --> Controller Class Initialized
INFO - 2024-04-05 18:41:06 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-05 18:41:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:06 --> Config Class Initialized
INFO - 2024-04-05 18:41:06 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:06 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:06 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:06 --> URI Class Initialized
INFO - 2024-04-05 18:41:06 --> Router Class Initialized
INFO - 2024-04-05 18:41:06 --> Output Class Initialized
INFO - 2024-04-05 18:41:06 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:06 --> Input Class Initialized
INFO - 2024-04-05 18:41:06 --> Language Class Initialized
INFO - 2024-04-05 18:41:06 --> Loader Class Initialized
INFO - 2024-04-05 18:41:06 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:06 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:06 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:06 --> Parser Class Initialized
INFO - 2024-04-05 18:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:06 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:06 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:06 --> Controller Class Initialized
INFO - 2024-04-05 18:41:06 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-05 18:41:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-05 18:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-05 18:41:06 --> Model Class Initialized
INFO - 2024-04-05 18:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-05 18:41:06 --> Final output sent to browser
DEBUG - 2024-04-05 18:41:06 --> Total execution time: 0.0373
ERROR - 2024-04-05 18:41:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:10 --> Config Class Initialized
INFO - 2024-04-05 18:41:10 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:10 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:10 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:10 --> URI Class Initialized
INFO - 2024-04-05 18:41:10 --> Router Class Initialized
INFO - 2024-04-05 18:41:10 --> Output Class Initialized
INFO - 2024-04-05 18:41:10 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:10 --> Input Class Initialized
INFO - 2024-04-05 18:41:10 --> Language Class Initialized
INFO - 2024-04-05 18:41:10 --> Loader Class Initialized
INFO - 2024-04-05 18:41:10 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:10 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:10 --> Parser Class Initialized
INFO - 2024-04-05 18:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:10 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:10 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:10 --> Controller Class Initialized
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
INFO - 2024-04-05 18:41:10 --> Final output sent to browser
DEBUG - 2024-04-05 18:41:10 --> Total execution time: 0.0231
ERROR - 2024-04-05 18:41:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:10 --> Config Class Initialized
INFO - 2024-04-05 18:41:10 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:10 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:10 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:10 --> URI Class Initialized
DEBUG - 2024-04-05 18:41:10 --> No URI present. Default controller set.
INFO - 2024-04-05 18:41:10 --> Router Class Initialized
INFO - 2024-04-05 18:41:10 --> Output Class Initialized
INFO - 2024-04-05 18:41:10 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:10 --> Input Class Initialized
INFO - 2024-04-05 18:41:10 --> Language Class Initialized
INFO - 2024-04-05 18:41:10 --> Loader Class Initialized
INFO - 2024-04-05 18:41:10 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:10 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:10 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:10 --> Parser Class Initialized
INFO - 2024-04-05 18:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:10 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:10 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:10 --> Controller Class Initialized
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 18:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
INFO - 2024-04-05 18:41:10 --> Model Class Initialized
INFO - 2024-04-05 18:41:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-05 18:41:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-05 18:41:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-05 18:41:11 --> Model Class Initialized
INFO - 2024-04-05 18:41:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-05 18:41:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-05 18:41:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-05 18:41:11 --> Final output sent to browser
DEBUG - 2024-04-05 18:41:11 --> Total execution time: 0.4446
ERROR - 2024-04-05 18:41:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:12 --> Config Class Initialized
INFO - 2024-04-05 18:41:12 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:12 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:12 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:12 --> URI Class Initialized
INFO - 2024-04-05 18:41:12 --> Router Class Initialized
INFO - 2024-04-05 18:41:12 --> Output Class Initialized
INFO - 2024-04-05 18:41:12 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:12 --> Input Class Initialized
INFO - 2024-04-05 18:41:12 --> Language Class Initialized
INFO - 2024-04-05 18:41:12 --> Loader Class Initialized
INFO - 2024-04-05 18:41:12 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:12 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:12 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:12 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:12 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:12 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:12 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:12 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:12 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:12 --> Parser Class Initialized
INFO - 2024-04-05 18:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:12 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:12 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:12 --> Controller Class Initialized
DEBUG - 2024-04-05 18:41:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 18:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:12 --> Model Class Initialized
INFO - 2024-04-05 18:41:12 --> Final output sent to browser
DEBUG - 2024-04-05 18:41:12 --> Total execution time: 0.0136
ERROR - 2024-04-05 18:41:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:20 --> Config Class Initialized
INFO - 2024-04-05 18:41:20 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:20 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:20 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:20 --> URI Class Initialized
INFO - 2024-04-05 18:41:20 --> Router Class Initialized
INFO - 2024-04-05 18:41:20 --> Output Class Initialized
INFO - 2024-04-05 18:41:20 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:20 --> Input Class Initialized
INFO - 2024-04-05 18:41:20 --> Language Class Initialized
INFO - 2024-04-05 18:41:20 --> Loader Class Initialized
INFO - 2024-04-05 18:41:20 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:20 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:20 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:20 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:20 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:20 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:20 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:20 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:20 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:20 --> Parser Class Initialized
INFO - 2024-04-05 18:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:20 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:20 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:20 --> Controller Class Initialized
INFO - 2024-04-05 18:41:20 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 18:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:20 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:20 --> Model Class Initialized
INFO - 2024-04-05 18:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-05 18:41:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-05 18:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-05 18:41:20 --> Model Class Initialized
INFO - 2024-04-05 18:41:20 --> Model Class Initialized
INFO - 2024-04-05 18:41:20 --> Model Class Initialized
INFO - 2024-04-05 18:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-05 18:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-05 18:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-05 18:41:20 --> Final output sent to browser
DEBUG - 2024-04-05 18:41:20 --> Total execution time: 0.2221
ERROR - 2024-04-05 18:41:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:21 --> Config Class Initialized
INFO - 2024-04-05 18:41:21 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:21 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:21 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:21 --> URI Class Initialized
INFO - 2024-04-05 18:41:21 --> Router Class Initialized
INFO - 2024-04-05 18:41:21 --> Output Class Initialized
INFO - 2024-04-05 18:41:21 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:21 --> Input Class Initialized
INFO - 2024-04-05 18:41:21 --> Language Class Initialized
INFO - 2024-04-05 18:41:21 --> Loader Class Initialized
INFO - 2024-04-05 18:41:21 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:21 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:21 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:21 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:21 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:21 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:21 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:21 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:21 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:21 --> Parser Class Initialized
INFO - 2024-04-05 18:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:21 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:21 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:21 --> Controller Class Initialized
INFO - 2024-04-05 18:41:21 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 18:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:21 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:21 --> Model Class Initialized
INFO - 2024-04-05 18:41:21 --> Final output sent to browser
DEBUG - 2024-04-05 18:41:21 --> Total execution time: 0.1566
ERROR - 2024-04-05 18:41:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:41:42 --> Config Class Initialized
INFO - 2024-04-05 18:41:42 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:41:42 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:41:42 --> Utf8 Class Initialized
INFO - 2024-04-05 18:41:42 --> URI Class Initialized
DEBUG - 2024-04-05 18:41:42 --> No URI present. Default controller set.
INFO - 2024-04-05 18:41:42 --> Router Class Initialized
INFO - 2024-04-05 18:41:42 --> Output Class Initialized
INFO - 2024-04-05 18:41:42 --> Security Class Initialized
DEBUG - 2024-04-05 18:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:41:42 --> Input Class Initialized
INFO - 2024-04-05 18:41:42 --> Language Class Initialized
INFO - 2024-04-05 18:41:42 --> Loader Class Initialized
INFO - 2024-04-05 18:41:42 --> Helper loaded: url_helper
INFO - 2024-04-05 18:41:42 --> Helper loaded: file_helper
INFO - 2024-04-05 18:41:42 --> Helper loaded: html_helper
INFO - 2024-04-05 18:41:42 --> Helper loaded: text_helper
INFO - 2024-04-05 18:41:42 --> Helper loaded: form_helper
INFO - 2024-04-05 18:41:42 --> Helper loaded: lang_helper
INFO - 2024-04-05 18:41:42 --> Helper loaded: security_helper
INFO - 2024-04-05 18:41:42 --> Helper loaded: cookie_helper
INFO - 2024-04-05 18:41:42 --> Database Driver Class Initialized
INFO - 2024-04-05 18:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-05 18:41:42 --> Parser Class Initialized
INFO - 2024-04-05 18:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-05 18:41:42 --> Pagination Class Initialized
INFO - 2024-04-05 18:41:42 --> Form Validation Class Initialized
INFO - 2024-04-05 18:41:42 --> Controller Class Initialized
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
DEBUG - 2024-04-05 18:41:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-05 18:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
INFO - 2024-04-05 18:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-05 18:41:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-05 18:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-05 18:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-05 18:41:42 --> Model Class Initialized
INFO - 2024-04-05 18:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-05 18:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-05 18:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-05 18:41:42 --> Final output sent to browser
DEBUG - 2024-04-05 18:41:42 --> Total execution time: 0.4316
ERROR - 2024-04-05 18:48:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-05 18:48:19 --> Config Class Initialized
INFO - 2024-04-05 18:48:19 --> Hooks Class Initialized
DEBUG - 2024-04-05 18:48:19 --> UTF-8 Support Enabled
INFO - 2024-04-05 18:48:19 --> Utf8 Class Initialized
INFO - 2024-04-05 18:48:19 --> URI Class Initialized
INFO - 2024-04-05 18:48:19 --> Router Class Initialized
INFO - 2024-04-05 18:48:19 --> Output Class Initialized
INFO - 2024-04-05 18:48:19 --> Security Class Initialized
DEBUG - 2024-04-05 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-05 18:48:19 --> Input Class Initialized
INFO - 2024-04-05 18:48:19 --> Language Class Initialized
ERROR - 2024-04-05 18:48:19 --> 404 Page Not Found: Well-known/assetlinks.json
