<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-21 01:01:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 01:01:35 --> Config Class Initialized
INFO - 2023-10-21 01:01:35 --> Hooks Class Initialized
DEBUG - 2023-10-21 01:01:35 --> UTF-8 Support Enabled
INFO - 2023-10-21 01:01:35 --> Utf8 Class Initialized
INFO - 2023-10-21 01:01:35 --> URI Class Initialized
INFO - 2023-10-21 01:01:35 --> Router Class Initialized
INFO - 2023-10-21 01:01:35 --> Output Class Initialized
INFO - 2023-10-21 01:01:35 --> Security Class Initialized
DEBUG - 2023-10-21 01:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 01:01:35 --> Input Class Initialized
INFO - 2023-10-21 01:01:35 --> Language Class Initialized
ERROR - 2023-10-21 01:01:35 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-21 01:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 01:29:15 --> Config Class Initialized
INFO - 2023-10-21 01:29:15 --> Hooks Class Initialized
DEBUG - 2023-10-21 01:29:15 --> UTF-8 Support Enabled
INFO - 2023-10-21 01:29:15 --> Utf8 Class Initialized
INFO - 2023-10-21 01:29:15 --> URI Class Initialized
DEBUG - 2023-10-21 01:29:15 --> No URI present. Default controller set.
INFO - 2023-10-21 01:29:15 --> Router Class Initialized
INFO - 2023-10-21 01:29:15 --> Output Class Initialized
INFO - 2023-10-21 01:29:15 --> Security Class Initialized
DEBUG - 2023-10-21 01:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 01:29:15 --> Input Class Initialized
INFO - 2023-10-21 01:29:15 --> Language Class Initialized
INFO - 2023-10-21 01:29:15 --> Loader Class Initialized
INFO - 2023-10-21 01:29:15 --> Helper loaded: url_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: file_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: html_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: text_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: form_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: lang_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: security_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: cookie_helper
INFO - 2023-10-21 01:29:15 --> Database Driver Class Initialized
ERROR - 2023-10-21 01:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 01:29:15 --> Config Class Initialized
INFO - 2023-10-21 01:29:15 --> Hooks Class Initialized
DEBUG - 2023-10-21 01:29:15 --> UTF-8 Support Enabled
INFO - 2023-10-21 01:29:15 --> Utf8 Class Initialized
INFO - 2023-10-21 01:29:15 --> URI Class Initialized
DEBUG - 2023-10-21 01:29:15 --> No URI present. Default controller set.
INFO - 2023-10-21 01:29:15 --> Router Class Initialized
INFO - 2023-10-21 01:29:15 --> Output Class Initialized
INFO - 2023-10-21 01:29:15 --> Security Class Initialized
DEBUG - 2023-10-21 01:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 01:29:15 --> Input Class Initialized
INFO - 2023-10-21 01:29:15 --> Language Class Initialized
INFO - 2023-10-21 01:29:15 --> Loader Class Initialized
INFO - 2023-10-21 01:29:15 --> Helper loaded: url_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: file_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: html_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: text_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: form_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: lang_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: security_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: cookie_helper
INFO - 2023-10-21 01:29:15 --> Database Driver Class Initialized
INFO - 2023-10-21 01:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 01:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 01:29:15 --> Parser Class Initialized
INFO - 2023-10-21 01:29:15 --> Parser Class Initialized
INFO - 2023-10-21 01:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 01:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 01:29:15 --> Pagination Class Initialized
INFO - 2023-10-21 01:29:15 --> Pagination Class Initialized
INFO - 2023-10-21 01:29:15 --> Form Validation Class Initialized
INFO - 2023-10-21 01:29:15 --> Form Validation Class Initialized
INFO - 2023-10-21 01:29:15 --> Controller Class Initialized
INFO - 2023-10-21 01:29:15 --> Controller Class Initialized
INFO - 2023-10-21 01:29:15 --> Model Class Initialized
INFO - 2023-10-21 01:29:15 --> Model Class Initialized
DEBUG - 2023-10-21 01:29:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 01:29:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-21 01:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 01:29:15 --> Config Class Initialized
INFO - 2023-10-21 01:29:15 --> Hooks Class Initialized
DEBUG - 2023-10-21 01:29:15 --> UTF-8 Support Enabled
INFO - 2023-10-21 01:29:15 --> Utf8 Class Initialized
INFO - 2023-10-21 01:29:15 --> URI Class Initialized
INFO - 2023-10-21 01:29:15 --> Router Class Initialized
INFO - 2023-10-21 01:29:15 --> Output Class Initialized
INFO - 2023-10-21 01:29:15 --> Security Class Initialized
DEBUG - 2023-10-21 01:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 01:29:15 --> Input Class Initialized
INFO - 2023-10-21 01:29:15 --> Language Class Initialized
INFO - 2023-10-21 01:29:15 --> Loader Class Initialized
INFO - 2023-10-21 01:29:15 --> Helper loaded: url_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: file_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: html_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: text_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: form_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: lang_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: security_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: cookie_helper
INFO - 2023-10-21 01:29:15 --> Database Driver Class Initialized
ERROR - 2023-10-21 01:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 01:29:15 --> Config Class Initialized
INFO - 2023-10-21 01:29:15 --> Hooks Class Initialized
DEBUG - 2023-10-21 01:29:15 --> UTF-8 Support Enabled
INFO - 2023-10-21 01:29:15 --> Utf8 Class Initialized
INFO - 2023-10-21 01:29:15 --> URI Class Initialized
INFO - 2023-10-21 01:29:15 --> Router Class Initialized
INFO - 2023-10-21 01:29:15 --> Output Class Initialized
INFO - 2023-10-21 01:29:15 --> Security Class Initialized
DEBUG - 2023-10-21 01:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 01:29:15 --> Input Class Initialized
INFO - 2023-10-21 01:29:15 --> Language Class Initialized
INFO - 2023-10-21 01:29:15 --> Loader Class Initialized
INFO - 2023-10-21 01:29:15 --> Helper loaded: url_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: file_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: html_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: text_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: form_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: lang_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: security_helper
INFO - 2023-10-21 01:29:15 --> Helper loaded: cookie_helper
INFO - 2023-10-21 01:29:15 --> Database Driver Class Initialized
INFO - 2023-10-21 01:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 01:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 01:29:15 --> Parser Class Initialized
INFO - 2023-10-21 01:29:15 --> Parser Class Initialized
INFO - 2023-10-21 01:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 01:29:15 --> Pagination Class Initialized
INFO - 2023-10-21 01:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 01:29:15 --> Pagination Class Initialized
INFO - 2023-10-21 01:29:15 --> Form Validation Class Initialized
INFO - 2023-10-21 01:29:15 --> Controller Class Initialized
INFO - 2023-10-21 01:29:15 --> Form Validation Class Initialized
INFO - 2023-10-21 01:29:15 --> Model Class Initialized
DEBUG - 2023-10-21 01:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 01:29:15 --> Controller Class Initialized
INFO - 2023-10-21 01:29:15 --> Model Class Initialized
DEBUG - 2023-10-21 01:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 01:29:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 01:29:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 01:29:15 --> Model Class Initialized
INFO - 2023-10-21 01:29:15 --> Model Class Initialized
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 01:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 01:29:15 --> Final output sent to browser
INFO - 2023-10-21 01:29:15 --> Final output sent to browser
DEBUG - 2023-10-21 01:29:15 --> Total execution time: 0.1291
DEBUG - 2023-10-21 01:29:15 --> Total execution time: 0.2382
ERROR - 2023-10-21 04:31:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 04:31:35 --> Config Class Initialized
INFO - 2023-10-21 04:31:35 --> Hooks Class Initialized
DEBUG - 2023-10-21 04:31:35 --> UTF-8 Support Enabled
INFO - 2023-10-21 04:31:35 --> Utf8 Class Initialized
INFO - 2023-10-21 04:31:35 --> URI Class Initialized
INFO - 2023-10-21 04:31:35 --> Router Class Initialized
INFO - 2023-10-21 04:31:35 --> Output Class Initialized
INFO - 2023-10-21 04:31:35 --> Security Class Initialized
DEBUG - 2023-10-21 04:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 04:31:35 --> Input Class Initialized
INFO - 2023-10-21 04:31:35 --> Language Class Initialized
ERROR - 2023-10-21 04:31:35 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-21 05:36:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 05:36:23 --> Config Class Initialized
INFO - 2023-10-21 05:36:23 --> Hooks Class Initialized
DEBUG - 2023-10-21 05:36:23 --> UTF-8 Support Enabled
INFO - 2023-10-21 05:36:23 --> Utf8 Class Initialized
INFO - 2023-10-21 05:36:23 --> URI Class Initialized
DEBUG - 2023-10-21 05:36:23 --> No URI present. Default controller set.
INFO - 2023-10-21 05:36:23 --> Router Class Initialized
INFO - 2023-10-21 05:36:23 --> Output Class Initialized
INFO - 2023-10-21 05:36:23 --> Security Class Initialized
DEBUG - 2023-10-21 05:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 05:36:23 --> Input Class Initialized
INFO - 2023-10-21 05:36:23 --> Language Class Initialized
INFO - 2023-10-21 05:36:23 --> Loader Class Initialized
INFO - 2023-10-21 05:36:23 --> Helper loaded: url_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: file_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: html_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: text_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: form_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: lang_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: security_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: cookie_helper
INFO - 2023-10-21 05:36:23 --> Database Driver Class Initialized
INFO - 2023-10-21 05:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 05:36:23 --> Parser Class Initialized
INFO - 2023-10-21 05:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 05:36:23 --> Pagination Class Initialized
INFO - 2023-10-21 05:36:23 --> Form Validation Class Initialized
INFO - 2023-10-21 05:36:23 --> Controller Class Initialized
INFO - 2023-10-21 05:36:23 --> Model Class Initialized
DEBUG - 2023-10-21 05:36:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-21 05:36:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 05:36:23 --> Config Class Initialized
INFO - 2023-10-21 05:36:23 --> Hooks Class Initialized
DEBUG - 2023-10-21 05:36:23 --> UTF-8 Support Enabled
INFO - 2023-10-21 05:36:23 --> Utf8 Class Initialized
INFO - 2023-10-21 05:36:23 --> URI Class Initialized
INFO - 2023-10-21 05:36:23 --> Router Class Initialized
INFO - 2023-10-21 05:36:23 --> Output Class Initialized
INFO - 2023-10-21 05:36:23 --> Security Class Initialized
DEBUG - 2023-10-21 05:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 05:36:23 --> Input Class Initialized
INFO - 2023-10-21 05:36:23 --> Language Class Initialized
INFO - 2023-10-21 05:36:23 --> Loader Class Initialized
INFO - 2023-10-21 05:36:23 --> Helper loaded: url_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: file_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: html_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: text_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: form_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: lang_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: security_helper
INFO - 2023-10-21 05:36:23 --> Helper loaded: cookie_helper
INFO - 2023-10-21 05:36:23 --> Database Driver Class Initialized
INFO - 2023-10-21 05:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 05:36:23 --> Parser Class Initialized
INFO - 2023-10-21 05:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 05:36:23 --> Pagination Class Initialized
INFO - 2023-10-21 05:36:23 --> Form Validation Class Initialized
INFO - 2023-10-21 05:36:23 --> Controller Class Initialized
INFO - 2023-10-21 05:36:23 --> Model Class Initialized
DEBUG - 2023-10-21 05:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 05:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 05:36:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 05:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 05:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 05:36:23 --> Model Class Initialized
INFO - 2023-10-21 05:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 05:36:23 --> Final output sent to browser
DEBUG - 2023-10-21 05:36:23 --> Total execution time: 0.0338
ERROR - 2023-10-21 08:12:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:29 --> Config Class Initialized
INFO - 2023-10-21 08:12:29 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:29 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:29 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:29 --> URI Class Initialized
DEBUG - 2023-10-21 08:12:29 --> No URI present. Default controller set.
INFO - 2023-10-21 08:12:29 --> Router Class Initialized
INFO - 2023-10-21 08:12:29 --> Output Class Initialized
INFO - 2023-10-21 08:12:29 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:29 --> Input Class Initialized
INFO - 2023-10-21 08:12:29 --> Language Class Initialized
INFO - 2023-10-21 08:12:29 --> Loader Class Initialized
INFO - 2023-10-21 08:12:29 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:29 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:29 --> Parser Class Initialized
INFO - 2023-10-21 08:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:29 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:29 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:29 --> Controller Class Initialized
INFO - 2023-10-21 08:12:29 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-21 08:12:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:29 --> Config Class Initialized
INFO - 2023-10-21 08:12:29 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:29 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:29 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:29 --> URI Class Initialized
INFO - 2023-10-21 08:12:29 --> Router Class Initialized
INFO - 2023-10-21 08:12:29 --> Output Class Initialized
INFO - 2023-10-21 08:12:29 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:29 --> Input Class Initialized
INFO - 2023-10-21 08:12:29 --> Language Class Initialized
INFO - 2023-10-21 08:12:29 --> Loader Class Initialized
INFO - 2023-10-21 08:12:29 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:29 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:29 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:29 --> Parser Class Initialized
INFO - 2023-10-21 08:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:29 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:29 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:29 --> Controller Class Initialized
INFO - 2023-10-21 08:12:29 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 08:12:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:12:29 --> Model Class Initialized
INFO - 2023-10-21 08:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:12:29 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:29 --> Total execution time: 0.0348
ERROR - 2023-10-21 08:12:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:44 --> Config Class Initialized
INFO - 2023-10-21 08:12:44 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:44 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:44 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:44 --> URI Class Initialized
INFO - 2023-10-21 08:12:44 --> Router Class Initialized
INFO - 2023-10-21 08:12:44 --> Output Class Initialized
INFO - 2023-10-21 08:12:44 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:44 --> Input Class Initialized
INFO - 2023-10-21 08:12:44 --> Language Class Initialized
INFO - 2023-10-21 08:12:44 --> Loader Class Initialized
INFO - 2023-10-21 08:12:44 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:44 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:44 --> Parser Class Initialized
INFO - 2023-10-21 08:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:44 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:44 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:44 --> Controller Class Initialized
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
INFO - 2023-10-21 08:12:44 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:44 --> Total execution time: 0.0200
ERROR - 2023-10-21 08:12:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:44 --> Config Class Initialized
INFO - 2023-10-21 08:12:44 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:44 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:44 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:44 --> URI Class Initialized
DEBUG - 2023-10-21 08:12:44 --> No URI present. Default controller set.
INFO - 2023-10-21 08:12:44 --> Router Class Initialized
INFO - 2023-10-21 08:12:44 --> Output Class Initialized
INFO - 2023-10-21 08:12:44 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:44 --> Input Class Initialized
INFO - 2023-10-21 08:12:44 --> Language Class Initialized
INFO - 2023-10-21 08:12:44 --> Loader Class Initialized
INFO - 2023-10-21 08:12:44 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:44 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:44 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:44 --> Parser Class Initialized
INFO - 2023-10-21 08:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:44 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:44 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:44 --> Controller Class Initialized
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
INFO - 2023-10-21 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 08:12:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:12:44 --> Model Class Initialized
INFO - 2023-10-21 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:12:44 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:44 --> Total execution time: 0.2082
ERROR - 2023-10-21 08:12:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:52 --> Config Class Initialized
INFO - 2023-10-21 08:12:52 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:52 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:52 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:52 --> URI Class Initialized
INFO - 2023-10-21 08:12:52 --> Router Class Initialized
INFO - 2023-10-21 08:12:52 --> Output Class Initialized
INFO - 2023-10-21 08:12:52 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:52 --> Input Class Initialized
INFO - 2023-10-21 08:12:52 --> Language Class Initialized
INFO - 2023-10-21 08:12:52 --> Loader Class Initialized
INFO - 2023-10-21 08:12:52 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:52 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:52 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:52 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:52 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:52 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:52 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:52 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:52 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:52 --> Parser Class Initialized
INFO - 2023-10-21 08:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:52 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:52 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:52 --> Controller Class Initialized
INFO - 2023-10-21 08:12:52 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:52 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:52 --> Model Class Initialized
INFO - 2023-10-21 08:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-21 08:12:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:12:52 --> Model Class Initialized
INFO - 2023-10-21 08:12:52 --> Model Class Initialized
INFO - 2023-10-21 08:12:52 --> Model Class Initialized
INFO - 2023-10-21 08:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:12:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:12:53 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:53 --> Total execution time: 0.1324
ERROR - 2023-10-21 08:12:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:53 --> Config Class Initialized
INFO - 2023-10-21 08:12:53 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:53 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:53 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:53 --> URI Class Initialized
INFO - 2023-10-21 08:12:53 --> Router Class Initialized
INFO - 2023-10-21 08:12:53 --> Output Class Initialized
INFO - 2023-10-21 08:12:53 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:53 --> Input Class Initialized
INFO - 2023-10-21 08:12:53 --> Language Class Initialized
INFO - 2023-10-21 08:12:53 --> Loader Class Initialized
INFO - 2023-10-21 08:12:53 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:53 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:53 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:53 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:53 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:53 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:53 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:53 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:53 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:53 --> Parser Class Initialized
INFO - 2023-10-21 08:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:53 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:53 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:53 --> Controller Class Initialized
INFO - 2023-10-21 08:12:53 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:53 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:53 --> Model Class Initialized
INFO - 2023-10-21 08:12:53 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:53 --> Total execution time: 0.0400
ERROR - 2023-10-21 08:12:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:57 --> Config Class Initialized
INFO - 2023-10-21 08:12:57 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:57 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:57 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:57 --> URI Class Initialized
INFO - 2023-10-21 08:12:57 --> Router Class Initialized
INFO - 2023-10-21 08:12:57 --> Output Class Initialized
INFO - 2023-10-21 08:12:57 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:57 --> Input Class Initialized
INFO - 2023-10-21 08:12:57 --> Language Class Initialized
INFO - 2023-10-21 08:12:57 --> Loader Class Initialized
INFO - 2023-10-21 08:12:57 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:57 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:57 --> Parser Class Initialized
INFO - 2023-10-21 08:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:57 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:57 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:57 --> Controller Class Initialized
INFO - 2023-10-21 08:12:57 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:57 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:57 --> Model Class Initialized
INFO - 2023-10-21 08:12:57 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:57 --> Total execution time: 0.0443
ERROR - 2023-10-21 08:12:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:57 --> Config Class Initialized
INFO - 2023-10-21 08:12:57 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:57 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:57 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:57 --> URI Class Initialized
INFO - 2023-10-21 08:12:57 --> Router Class Initialized
INFO - 2023-10-21 08:12:57 --> Output Class Initialized
INFO - 2023-10-21 08:12:57 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:57 --> Input Class Initialized
INFO - 2023-10-21 08:12:57 --> Language Class Initialized
INFO - 2023-10-21 08:12:57 --> Loader Class Initialized
INFO - 2023-10-21 08:12:57 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:57 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:57 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:57 --> Parser Class Initialized
INFO - 2023-10-21 08:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:57 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:57 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:57 --> Controller Class Initialized
INFO - 2023-10-21 08:12:57 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:57 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:57 --> Model Class Initialized
INFO - 2023-10-21 08:12:57 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:57 --> Total execution time: 0.0403
ERROR - 2023-10-21 08:12:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:58 --> Config Class Initialized
INFO - 2023-10-21 08:12:58 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:58 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:58 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:58 --> URI Class Initialized
INFO - 2023-10-21 08:12:58 --> Router Class Initialized
INFO - 2023-10-21 08:12:58 --> Output Class Initialized
INFO - 2023-10-21 08:12:58 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:58 --> Input Class Initialized
INFO - 2023-10-21 08:12:58 --> Language Class Initialized
INFO - 2023-10-21 08:12:58 --> Loader Class Initialized
INFO - 2023-10-21 08:12:58 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:58 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:58 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:58 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:58 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:58 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:58 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:58 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:58 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:58 --> Parser Class Initialized
INFO - 2023-10-21 08:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:58 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:58 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:58 --> Controller Class Initialized
INFO - 2023-10-21 08:12:58 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:58 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:58 --> Model Class Initialized
INFO - 2023-10-21 08:12:58 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:58 --> Total execution time: 0.0310
ERROR - 2023-10-21 08:12:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:59 --> Config Class Initialized
INFO - 2023-10-21 08:12:59 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:59 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:59 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:59 --> URI Class Initialized
INFO - 2023-10-21 08:12:59 --> Router Class Initialized
INFO - 2023-10-21 08:12:59 --> Output Class Initialized
INFO - 2023-10-21 08:12:59 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:59 --> Input Class Initialized
INFO - 2023-10-21 08:12:59 --> Language Class Initialized
INFO - 2023-10-21 08:12:59 --> Loader Class Initialized
INFO - 2023-10-21 08:12:59 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:59 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:59 --> Parser Class Initialized
INFO - 2023-10-21 08:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:59 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:59 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:59 --> Controller Class Initialized
INFO - 2023-10-21 08:12:59 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:59 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:59 --> Model Class Initialized
INFO - 2023-10-21 08:12:59 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:59 --> Total execution time: 0.0328
ERROR - 2023-10-21 08:12:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:12:59 --> Config Class Initialized
INFO - 2023-10-21 08:12:59 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:12:59 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:12:59 --> Utf8 Class Initialized
INFO - 2023-10-21 08:12:59 --> URI Class Initialized
INFO - 2023-10-21 08:12:59 --> Router Class Initialized
INFO - 2023-10-21 08:12:59 --> Output Class Initialized
INFO - 2023-10-21 08:12:59 --> Security Class Initialized
DEBUG - 2023-10-21 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:12:59 --> Input Class Initialized
INFO - 2023-10-21 08:12:59 --> Language Class Initialized
INFO - 2023-10-21 08:12:59 --> Loader Class Initialized
INFO - 2023-10-21 08:12:59 --> Helper loaded: url_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: file_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: html_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: text_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: form_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: security_helper
INFO - 2023-10-21 08:12:59 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:12:59 --> Database Driver Class Initialized
INFO - 2023-10-21 08:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:12:59 --> Parser Class Initialized
INFO - 2023-10-21 08:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:12:59 --> Pagination Class Initialized
INFO - 2023-10-21 08:12:59 --> Form Validation Class Initialized
INFO - 2023-10-21 08:12:59 --> Controller Class Initialized
INFO - 2023-10-21 08:12:59 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:59 --> Model Class Initialized
DEBUG - 2023-10-21 08:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:12:59 --> Model Class Initialized
INFO - 2023-10-21 08:12:59 --> Final output sent to browser
DEBUG - 2023-10-21 08:12:59 --> Total execution time: 0.0288
ERROR - 2023-10-21 08:13:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:13:00 --> Config Class Initialized
INFO - 2023-10-21 08:13:00 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:13:00 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:13:00 --> Utf8 Class Initialized
INFO - 2023-10-21 08:13:00 --> URI Class Initialized
INFO - 2023-10-21 08:13:00 --> Router Class Initialized
INFO - 2023-10-21 08:13:00 --> Output Class Initialized
INFO - 2023-10-21 08:13:00 --> Security Class Initialized
DEBUG - 2023-10-21 08:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:13:00 --> Input Class Initialized
INFO - 2023-10-21 08:13:00 --> Language Class Initialized
INFO - 2023-10-21 08:13:00 --> Loader Class Initialized
INFO - 2023-10-21 08:13:00 --> Helper loaded: url_helper
INFO - 2023-10-21 08:13:00 --> Helper loaded: file_helper
INFO - 2023-10-21 08:13:00 --> Helper loaded: html_helper
INFO - 2023-10-21 08:13:00 --> Helper loaded: text_helper
INFO - 2023-10-21 08:13:00 --> Helper loaded: form_helper
INFO - 2023-10-21 08:13:00 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:13:00 --> Helper loaded: security_helper
INFO - 2023-10-21 08:13:00 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:13:00 --> Database Driver Class Initialized
INFO - 2023-10-21 08:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:13:00 --> Parser Class Initialized
INFO - 2023-10-21 08:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:13:00 --> Pagination Class Initialized
INFO - 2023-10-21 08:13:00 --> Form Validation Class Initialized
INFO - 2023-10-21 08:13:00 --> Controller Class Initialized
INFO - 2023-10-21 08:13:00 --> Model Class Initialized
DEBUG - 2023-10-21 08:13:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:13:00 --> Model Class Initialized
DEBUG - 2023-10-21 08:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:13:00 --> Model Class Initialized
INFO - 2023-10-21 08:13:00 --> Final output sent to browser
DEBUG - 2023-10-21 08:13:00 --> Total execution time: 0.0271
ERROR - 2023-10-21 08:13:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:13:14 --> Config Class Initialized
INFO - 2023-10-21 08:13:14 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:13:14 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:13:14 --> Utf8 Class Initialized
INFO - 2023-10-21 08:13:14 --> URI Class Initialized
INFO - 2023-10-21 08:13:14 --> Router Class Initialized
INFO - 2023-10-21 08:13:14 --> Output Class Initialized
INFO - 2023-10-21 08:13:14 --> Security Class Initialized
DEBUG - 2023-10-21 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:13:14 --> Input Class Initialized
INFO - 2023-10-21 08:13:14 --> Language Class Initialized
INFO - 2023-10-21 08:13:14 --> Loader Class Initialized
INFO - 2023-10-21 08:13:14 --> Helper loaded: url_helper
INFO - 2023-10-21 08:13:14 --> Helper loaded: file_helper
INFO - 2023-10-21 08:13:14 --> Helper loaded: html_helper
INFO - 2023-10-21 08:13:14 --> Helper loaded: text_helper
INFO - 2023-10-21 08:13:14 --> Helper loaded: form_helper
INFO - 2023-10-21 08:13:14 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:13:14 --> Helper loaded: security_helper
INFO - 2023-10-21 08:13:14 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:13:14 --> Database Driver Class Initialized
INFO - 2023-10-21 08:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:13:14 --> Parser Class Initialized
INFO - 2023-10-21 08:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:13:14 --> Pagination Class Initialized
INFO - 2023-10-21 08:13:14 --> Form Validation Class Initialized
INFO - 2023-10-21 08:13:14 --> Controller Class Initialized
INFO - 2023-10-21 08:13:14 --> Model Class Initialized
DEBUG - 2023-10-21 08:13:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:13:14 --> Model Class Initialized
DEBUG - 2023-10-21 08:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:13:14 --> Model Class Initialized
DEBUG - 2023-10-21 08:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:13:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-21 08:13:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:13:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:13:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:13:14 --> Model Class Initialized
INFO - 2023-10-21 08:13:14 --> Model Class Initialized
INFO - 2023-10-21 08:13:14 --> Model Class Initialized
INFO - 2023-10-21 08:13:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:13:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:13:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:13:15 --> Final output sent to browser
DEBUG - 2023-10-21 08:13:15 --> Total execution time: 0.1398
ERROR - 2023-10-21 08:44:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:44:39 --> Config Class Initialized
INFO - 2023-10-21 08:44:39 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:44:39 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:44:39 --> Utf8 Class Initialized
INFO - 2023-10-21 08:44:39 --> URI Class Initialized
DEBUG - 2023-10-21 08:44:39 --> No URI present. Default controller set.
INFO - 2023-10-21 08:44:39 --> Router Class Initialized
INFO - 2023-10-21 08:44:39 --> Output Class Initialized
INFO - 2023-10-21 08:44:39 --> Security Class Initialized
DEBUG - 2023-10-21 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:44:39 --> Input Class Initialized
INFO - 2023-10-21 08:44:39 --> Language Class Initialized
INFO - 2023-10-21 08:44:39 --> Loader Class Initialized
INFO - 2023-10-21 08:44:39 --> Helper loaded: url_helper
INFO - 2023-10-21 08:44:39 --> Helper loaded: file_helper
INFO - 2023-10-21 08:44:39 --> Helper loaded: html_helper
INFO - 2023-10-21 08:44:39 --> Helper loaded: text_helper
INFO - 2023-10-21 08:44:39 --> Helper loaded: form_helper
INFO - 2023-10-21 08:44:39 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:44:39 --> Helper loaded: security_helper
INFO - 2023-10-21 08:44:39 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:44:39 --> Database Driver Class Initialized
INFO - 2023-10-21 08:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:44:39 --> Parser Class Initialized
INFO - 2023-10-21 08:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:44:39 --> Pagination Class Initialized
INFO - 2023-10-21 08:44:39 --> Form Validation Class Initialized
INFO - 2023-10-21 08:44:39 --> Controller Class Initialized
INFO - 2023-10-21 08:44:39 --> Model Class Initialized
DEBUG - 2023-10-21 08:44:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-21 08:44:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:44:40 --> Config Class Initialized
INFO - 2023-10-21 08:44:40 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:44:40 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:44:40 --> Utf8 Class Initialized
INFO - 2023-10-21 08:44:40 --> URI Class Initialized
INFO - 2023-10-21 08:44:40 --> Router Class Initialized
INFO - 2023-10-21 08:44:40 --> Output Class Initialized
INFO - 2023-10-21 08:44:40 --> Security Class Initialized
DEBUG - 2023-10-21 08:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:44:40 --> Input Class Initialized
INFO - 2023-10-21 08:44:40 --> Language Class Initialized
INFO - 2023-10-21 08:44:40 --> Loader Class Initialized
INFO - 2023-10-21 08:44:40 --> Helper loaded: url_helper
INFO - 2023-10-21 08:44:40 --> Helper loaded: file_helper
INFO - 2023-10-21 08:44:40 --> Helper loaded: html_helper
INFO - 2023-10-21 08:44:40 --> Helper loaded: text_helper
INFO - 2023-10-21 08:44:40 --> Helper loaded: form_helper
INFO - 2023-10-21 08:44:40 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:44:40 --> Helper loaded: security_helper
INFO - 2023-10-21 08:44:40 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:44:40 --> Database Driver Class Initialized
INFO - 2023-10-21 08:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:44:40 --> Parser Class Initialized
INFO - 2023-10-21 08:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:44:40 --> Pagination Class Initialized
INFO - 2023-10-21 08:44:40 --> Form Validation Class Initialized
INFO - 2023-10-21 08:44:40 --> Controller Class Initialized
INFO - 2023-10-21 08:44:40 --> Model Class Initialized
DEBUG - 2023-10-21 08:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 08:44:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:44:40 --> Model Class Initialized
INFO - 2023-10-21 08:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:44:40 --> Final output sent to browser
DEBUG - 2023-10-21 08:44:40 --> Total execution time: 0.0284
ERROR - 2023-10-21 08:45:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:45:05 --> Config Class Initialized
INFO - 2023-10-21 08:45:05 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:45:05 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:45:05 --> Utf8 Class Initialized
INFO - 2023-10-21 08:45:05 --> URI Class Initialized
INFO - 2023-10-21 08:45:05 --> Router Class Initialized
INFO - 2023-10-21 08:45:05 --> Output Class Initialized
INFO - 2023-10-21 08:45:05 --> Security Class Initialized
DEBUG - 2023-10-21 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:45:05 --> Input Class Initialized
INFO - 2023-10-21 08:45:05 --> Language Class Initialized
INFO - 2023-10-21 08:45:05 --> Loader Class Initialized
INFO - 2023-10-21 08:45:05 --> Helper loaded: url_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: file_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: html_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: text_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: form_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: security_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:45:05 --> Database Driver Class Initialized
INFO - 2023-10-21 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:45:05 --> Parser Class Initialized
INFO - 2023-10-21 08:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:45:05 --> Pagination Class Initialized
INFO - 2023-10-21 08:45:05 --> Form Validation Class Initialized
INFO - 2023-10-21 08:45:05 --> Controller Class Initialized
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
DEBUG - 2023-10-21 08:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
INFO - 2023-10-21 08:45:05 --> Final output sent to browser
DEBUG - 2023-10-21 08:45:05 --> Total execution time: 0.0193
ERROR - 2023-10-21 08:45:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:45:05 --> Config Class Initialized
INFO - 2023-10-21 08:45:05 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:45:05 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:45:05 --> Utf8 Class Initialized
INFO - 2023-10-21 08:45:05 --> URI Class Initialized
DEBUG - 2023-10-21 08:45:05 --> No URI present. Default controller set.
INFO - 2023-10-21 08:45:05 --> Router Class Initialized
INFO - 2023-10-21 08:45:05 --> Output Class Initialized
INFO - 2023-10-21 08:45:05 --> Security Class Initialized
DEBUG - 2023-10-21 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:45:05 --> Input Class Initialized
INFO - 2023-10-21 08:45:05 --> Language Class Initialized
INFO - 2023-10-21 08:45:05 --> Loader Class Initialized
INFO - 2023-10-21 08:45:05 --> Helper loaded: url_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: file_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: html_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: text_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: form_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: security_helper
INFO - 2023-10-21 08:45:05 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:45:05 --> Database Driver Class Initialized
INFO - 2023-10-21 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:45:05 --> Parser Class Initialized
INFO - 2023-10-21 08:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:45:05 --> Pagination Class Initialized
INFO - 2023-10-21 08:45:05 --> Form Validation Class Initialized
INFO - 2023-10-21 08:45:05 --> Controller Class Initialized
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
DEBUG - 2023-10-21 08:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
DEBUG - 2023-10-21 08:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
DEBUG - 2023-10-21 08:45:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
INFO - 2023-10-21 08:45:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 08:45:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:45:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:45:05 --> Model Class Initialized
INFO - 2023-10-21 08:45:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:45:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:45:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:45:05 --> Final output sent to browser
DEBUG - 2023-10-21 08:45:05 --> Total execution time: 0.1966
ERROR - 2023-10-21 08:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:45:26 --> Config Class Initialized
INFO - 2023-10-21 08:45:26 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:45:26 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:45:26 --> Utf8 Class Initialized
INFO - 2023-10-21 08:45:26 --> URI Class Initialized
INFO - 2023-10-21 08:45:26 --> Router Class Initialized
INFO - 2023-10-21 08:45:26 --> Output Class Initialized
INFO - 2023-10-21 08:45:26 --> Security Class Initialized
DEBUG - 2023-10-21 08:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:45:26 --> Input Class Initialized
INFO - 2023-10-21 08:45:26 --> Language Class Initialized
INFO - 2023-10-21 08:45:26 --> Loader Class Initialized
INFO - 2023-10-21 08:45:26 --> Helper loaded: url_helper
INFO - 2023-10-21 08:45:26 --> Helper loaded: file_helper
INFO - 2023-10-21 08:45:26 --> Helper loaded: html_helper
INFO - 2023-10-21 08:45:26 --> Helper loaded: text_helper
INFO - 2023-10-21 08:45:26 --> Helper loaded: form_helper
INFO - 2023-10-21 08:45:26 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:45:26 --> Helper loaded: security_helper
INFO - 2023-10-21 08:45:26 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:45:26 --> Database Driver Class Initialized
INFO - 2023-10-21 08:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:45:26 --> Parser Class Initialized
INFO - 2023-10-21 08:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:45:26 --> Pagination Class Initialized
INFO - 2023-10-21 08:45:26 --> Form Validation Class Initialized
INFO - 2023-10-21 08:45:26 --> Controller Class Initialized
DEBUG - 2023-10-21 08:45:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:26 --> Model Class Initialized
DEBUG - 2023-10-21 08:45:26 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:26 --> Model Class Initialized
DEBUG - 2023-10-21 08:45:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:26 --> Model Class Initialized
DEBUG - 2023-10-21 08:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:26 --> Model Class Initialized
INFO - 2023-10-21 08:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-10-21 08:45:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:45:26 --> Model Class Initialized
INFO - 2023-10-21 08:45:26 --> Model Class Initialized
INFO - 2023-10-21 08:45:26 --> Model Class Initialized
INFO - 2023-10-21 08:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:45:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:45:26 --> Final output sent to browser
DEBUG - 2023-10-21 08:45:26 --> Total execution time: 0.1202
ERROR - 2023-10-21 08:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:45:27 --> Config Class Initialized
INFO - 2023-10-21 08:45:27 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:45:27 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:45:27 --> Utf8 Class Initialized
INFO - 2023-10-21 08:45:27 --> URI Class Initialized
INFO - 2023-10-21 08:45:27 --> Router Class Initialized
INFO - 2023-10-21 08:45:27 --> Output Class Initialized
INFO - 2023-10-21 08:45:27 --> Security Class Initialized
DEBUG - 2023-10-21 08:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:45:27 --> Input Class Initialized
INFO - 2023-10-21 08:45:27 --> Language Class Initialized
INFO - 2023-10-21 08:45:27 --> Loader Class Initialized
INFO - 2023-10-21 08:45:27 --> Helper loaded: url_helper
INFO - 2023-10-21 08:45:27 --> Helper loaded: file_helper
INFO - 2023-10-21 08:45:27 --> Helper loaded: html_helper
INFO - 2023-10-21 08:45:27 --> Helper loaded: text_helper
INFO - 2023-10-21 08:45:27 --> Helper loaded: form_helper
INFO - 2023-10-21 08:45:27 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:45:27 --> Helper loaded: security_helper
INFO - 2023-10-21 08:45:27 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:45:27 --> Database Driver Class Initialized
INFO - 2023-10-21 08:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:45:27 --> Parser Class Initialized
INFO - 2023-10-21 08:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:45:27 --> Pagination Class Initialized
INFO - 2023-10-21 08:45:27 --> Form Validation Class Initialized
INFO - 2023-10-21 08:45:27 --> Controller Class Initialized
DEBUG - 2023-10-21 08:45:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:45:27 --> Model Class Initialized
INFO - 2023-10-21 08:45:27 --> Final output sent to browser
DEBUG - 2023-10-21 08:45:27 --> Total execution time: 0.0164
ERROR - 2023-10-21 08:46:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:46:57 --> Config Class Initialized
INFO - 2023-10-21 08:46:57 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:46:57 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:46:57 --> Utf8 Class Initialized
INFO - 2023-10-21 08:46:57 --> URI Class Initialized
DEBUG - 2023-10-21 08:46:57 --> No URI present. Default controller set.
INFO - 2023-10-21 08:46:57 --> Router Class Initialized
INFO - 2023-10-21 08:46:57 --> Output Class Initialized
INFO - 2023-10-21 08:46:57 --> Security Class Initialized
DEBUG - 2023-10-21 08:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:46:57 --> Input Class Initialized
INFO - 2023-10-21 08:46:57 --> Language Class Initialized
INFO - 2023-10-21 08:46:57 --> Loader Class Initialized
INFO - 2023-10-21 08:46:57 --> Helper loaded: url_helper
INFO - 2023-10-21 08:46:57 --> Helper loaded: file_helper
INFO - 2023-10-21 08:46:57 --> Helper loaded: html_helper
INFO - 2023-10-21 08:46:57 --> Helper loaded: text_helper
INFO - 2023-10-21 08:46:57 --> Helper loaded: form_helper
INFO - 2023-10-21 08:46:57 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:46:57 --> Helper loaded: security_helper
INFO - 2023-10-21 08:46:57 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:46:57 --> Database Driver Class Initialized
INFO - 2023-10-21 08:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:46:57 --> Parser Class Initialized
INFO - 2023-10-21 08:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:46:57 --> Pagination Class Initialized
INFO - 2023-10-21 08:46:57 --> Form Validation Class Initialized
INFO - 2023-10-21 08:46:57 --> Controller Class Initialized
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
DEBUG - 2023-10-21 08:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
DEBUG - 2023-10-21 08:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
DEBUG - 2023-10-21 08:46:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
INFO - 2023-10-21 08:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 08:46:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:46:57 --> Model Class Initialized
INFO - 2023-10-21 08:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:46:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:46:57 --> Final output sent to browser
DEBUG - 2023-10-21 08:46:57 --> Total execution time: 0.1956
ERROR - 2023-10-21 08:46:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:46:58 --> Config Class Initialized
INFO - 2023-10-21 08:46:58 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:46:58 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:46:58 --> Utf8 Class Initialized
INFO - 2023-10-21 08:46:58 --> URI Class Initialized
INFO - 2023-10-21 08:46:58 --> Router Class Initialized
INFO - 2023-10-21 08:46:58 --> Output Class Initialized
INFO - 2023-10-21 08:46:58 --> Security Class Initialized
DEBUG - 2023-10-21 08:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:46:58 --> Input Class Initialized
INFO - 2023-10-21 08:46:58 --> Language Class Initialized
INFO - 2023-10-21 08:46:58 --> Loader Class Initialized
INFO - 2023-10-21 08:46:58 --> Helper loaded: url_helper
INFO - 2023-10-21 08:46:58 --> Helper loaded: file_helper
INFO - 2023-10-21 08:46:58 --> Helper loaded: html_helper
INFO - 2023-10-21 08:46:58 --> Helper loaded: text_helper
INFO - 2023-10-21 08:46:58 --> Helper loaded: form_helper
INFO - 2023-10-21 08:46:58 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:46:58 --> Helper loaded: security_helper
INFO - 2023-10-21 08:46:58 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:46:58 --> Database Driver Class Initialized
INFO - 2023-10-21 08:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:46:58 --> Parser Class Initialized
INFO - 2023-10-21 08:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:46:58 --> Pagination Class Initialized
INFO - 2023-10-21 08:46:58 --> Form Validation Class Initialized
INFO - 2023-10-21 08:46:58 --> Controller Class Initialized
INFO - 2023-10-21 08:46:58 --> Model Class Initialized
DEBUG - 2023-10-21 08:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 08:46:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:46:58 --> Model Class Initialized
INFO - 2023-10-21 08:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:46:58 --> Final output sent to browser
DEBUG - 2023-10-21 08:46:58 --> Total execution time: 0.0271
ERROR - 2023-10-21 08:46:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:46:59 --> Config Class Initialized
INFO - 2023-10-21 08:46:59 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:46:59 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:46:59 --> Utf8 Class Initialized
INFO - 2023-10-21 08:46:59 --> URI Class Initialized
INFO - 2023-10-21 08:46:59 --> Router Class Initialized
INFO - 2023-10-21 08:46:59 --> Output Class Initialized
INFO - 2023-10-21 08:46:59 --> Security Class Initialized
DEBUG - 2023-10-21 08:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:46:59 --> Input Class Initialized
INFO - 2023-10-21 08:46:59 --> Language Class Initialized
INFO - 2023-10-21 08:46:59 --> Loader Class Initialized
INFO - 2023-10-21 08:46:59 --> Helper loaded: url_helper
INFO - 2023-10-21 08:46:59 --> Helper loaded: file_helper
INFO - 2023-10-21 08:46:59 --> Helper loaded: html_helper
INFO - 2023-10-21 08:46:59 --> Helper loaded: text_helper
INFO - 2023-10-21 08:46:59 --> Helper loaded: form_helper
INFO - 2023-10-21 08:46:59 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:46:59 --> Helper loaded: security_helper
INFO - 2023-10-21 08:46:59 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:46:59 --> Database Driver Class Initialized
INFO - 2023-10-21 08:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:46:59 --> Parser Class Initialized
INFO - 2023-10-21 08:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:46:59 --> Pagination Class Initialized
INFO - 2023-10-21 08:46:59 --> Form Validation Class Initialized
INFO - 2023-10-21 08:46:59 --> Controller Class Initialized
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
DEBUG - 2023-10-21 08:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
DEBUG - 2023-10-21 08:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
DEBUG - 2023-10-21 08:46:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
INFO - 2023-10-21 08:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 08:46:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:46:59 --> Model Class Initialized
INFO - 2023-10-21 08:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:46:59 --> Final output sent to browser
DEBUG - 2023-10-21 08:46:59 --> Total execution time: 0.1831
ERROR - 2023-10-21 08:47:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:47:08 --> Config Class Initialized
INFO - 2023-10-21 08:47:08 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:47:08 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:47:08 --> Utf8 Class Initialized
INFO - 2023-10-21 08:47:08 --> URI Class Initialized
INFO - 2023-10-21 08:47:08 --> Router Class Initialized
INFO - 2023-10-21 08:47:08 --> Output Class Initialized
INFO - 2023-10-21 08:47:08 --> Security Class Initialized
DEBUG - 2023-10-21 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:47:08 --> Input Class Initialized
INFO - 2023-10-21 08:47:08 --> Language Class Initialized
INFO - 2023-10-21 08:47:08 --> Loader Class Initialized
INFO - 2023-10-21 08:47:08 --> Helper loaded: url_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: file_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: html_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: text_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: form_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: security_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:47:08 --> Database Driver Class Initialized
INFO - 2023-10-21 08:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:47:08 --> Parser Class Initialized
INFO - 2023-10-21 08:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:47:08 --> Pagination Class Initialized
INFO - 2023-10-21 08:47:08 --> Form Validation Class Initialized
INFO - 2023-10-21 08:47:08 --> Controller Class Initialized
DEBUG - 2023-10-21 08:47:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:08 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
INFO - 2023-10-21 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-10-21 08:47:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
INFO - 2023-10-21 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:47:08 --> Final output sent to browser
DEBUG - 2023-10-21 08:47:08 --> Total execution time: 0.1232
ERROR - 2023-10-21 08:47:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:47:08 --> Config Class Initialized
INFO - 2023-10-21 08:47:08 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:47:08 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:47:08 --> Utf8 Class Initialized
INFO - 2023-10-21 08:47:08 --> URI Class Initialized
INFO - 2023-10-21 08:47:08 --> Router Class Initialized
INFO - 2023-10-21 08:47:08 --> Output Class Initialized
INFO - 2023-10-21 08:47:08 --> Security Class Initialized
DEBUG - 2023-10-21 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:47:08 --> Input Class Initialized
INFO - 2023-10-21 08:47:08 --> Language Class Initialized
INFO - 2023-10-21 08:47:08 --> Loader Class Initialized
INFO - 2023-10-21 08:47:08 --> Helper loaded: url_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: file_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: html_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: text_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: form_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: security_helper
INFO - 2023-10-21 08:47:08 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:47:08 --> Database Driver Class Initialized
INFO - 2023-10-21 08:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:47:08 --> Parser Class Initialized
INFO - 2023-10-21 08:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:47:08 --> Pagination Class Initialized
INFO - 2023-10-21 08:47:08 --> Form Validation Class Initialized
INFO - 2023-10-21 08:47:08 --> Controller Class Initialized
DEBUG - 2023-10-21 08:47:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:08 --> Model Class Initialized
INFO - 2023-10-21 08:47:08 --> Final output sent to browser
DEBUG - 2023-10-21 08:47:08 --> Total execution time: 0.0156
ERROR - 2023-10-21 08:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:47:30 --> Config Class Initialized
INFO - 2023-10-21 08:47:30 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:47:30 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:47:30 --> Utf8 Class Initialized
INFO - 2023-10-21 08:47:30 --> URI Class Initialized
INFO - 2023-10-21 08:47:30 --> Router Class Initialized
INFO - 2023-10-21 08:47:30 --> Output Class Initialized
INFO - 2023-10-21 08:47:30 --> Security Class Initialized
DEBUG - 2023-10-21 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:47:30 --> Input Class Initialized
INFO - 2023-10-21 08:47:30 --> Language Class Initialized
INFO - 2023-10-21 08:47:30 --> Loader Class Initialized
INFO - 2023-10-21 08:47:30 --> Helper loaded: url_helper
INFO - 2023-10-21 08:47:30 --> Helper loaded: file_helper
INFO - 2023-10-21 08:47:30 --> Helper loaded: html_helper
INFO - 2023-10-21 08:47:30 --> Helper loaded: text_helper
INFO - 2023-10-21 08:47:30 --> Helper loaded: form_helper
INFO - 2023-10-21 08:47:30 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:47:30 --> Helper loaded: security_helper
INFO - 2023-10-21 08:47:30 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:47:30 --> Database Driver Class Initialized
INFO - 2023-10-21 08:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:47:30 --> Parser Class Initialized
INFO - 2023-10-21 08:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:47:30 --> Pagination Class Initialized
INFO - 2023-10-21 08:47:30 --> Form Validation Class Initialized
INFO - 2023-10-21 08:47:30 --> Controller Class Initialized
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
INFO - 2023-10-21 08:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 08:47:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:47:30 --> Model Class Initialized
INFO - 2023-10-21 08:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:47:30 --> Final output sent to browser
DEBUG - 2023-10-21 08:47:30 --> Total execution time: 0.1963
ERROR - 2023-10-21 08:47:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:47:37 --> Config Class Initialized
INFO - 2023-10-21 08:47:37 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:47:37 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:47:37 --> Utf8 Class Initialized
INFO - 2023-10-21 08:47:37 --> URI Class Initialized
INFO - 2023-10-21 08:47:37 --> Router Class Initialized
INFO - 2023-10-21 08:47:37 --> Output Class Initialized
INFO - 2023-10-21 08:47:37 --> Security Class Initialized
DEBUG - 2023-10-21 08:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:47:37 --> Input Class Initialized
INFO - 2023-10-21 08:47:37 --> Language Class Initialized
INFO - 2023-10-21 08:47:37 --> Loader Class Initialized
INFO - 2023-10-21 08:47:37 --> Helper loaded: url_helper
INFO - 2023-10-21 08:47:37 --> Helper loaded: file_helper
INFO - 2023-10-21 08:47:37 --> Helper loaded: html_helper
INFO - 2023-10-21 08:47:37 --> Helper loaded: text_helper
INFO - 2023-10-21 08:47:37 --> Helper loaded: form_helper
INFO - 2023-10-21 08:47:37 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:47:37 --> Helper loaded: security_helper
INFO - 2023-10-21 08:47:37 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:47:37 --> Database Driver Class Initialized
INFO - 2023-10-21 08:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:47:37 --> Parser Class Initialized
INFO - 2023-10-21 08:47:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:47:37 --> Pagination Class Initialized
INFO - 2023-10-21 08:47:37 --> Form Validation Class Initialized
INFO - 2023-10-21 08:47:37 --> Controller Class Initialized
DEBUG - 2023-10-21 08:47:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:37 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:37 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:37 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:37 --> Model Class Initialized
DEBUG - 2023-10-21 08:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:37 --> Model Class Initialized
INFO - 2023-10-21 08:47:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-10-21 08:47:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:47:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:47:37 --> Model Class Initialized
INFO - 2023-10-21 08:47:37 --> Model Class Initialized
INFO - 2023-10-21 08:47:37 --> Model Class Initialized
INFO - 2023-10-21 08:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:47:38 --> Final output sent to browser
DEBUG - 2023-10-21 08:47:38 --> Total execution time: 0.1194
ERROR - 2023-10-21 08:47:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:47:39 --> Config Class Initialized
INFO - 2023-10-21 08:47:39 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:47:39 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:47:39 --> Utf8 Class Initialized
INFO - 2023-10-21 08:47:39 --> URI Class Initialized
INFO - 2023-10-21 08:47:39 --> Router Class Initialized
INFO - 2023-10-21 08:47:39 --> Output Class Initialized
INFO - 2023-10-21 08:47:39 --> Security Class Initialized
DEBUG - 2023-10-21 08:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:47:39 --> Input Class Initialized
INFO - 2023-10-21 08:47:39 --> Language Class Initialized
INFO - 2023-10-21 08:47:39 --> Loader Class Initialized
INFO - 2023-10-21 08:47:39 --> Helper loaded: url_helper
INFO - 2023-10-21 08:47:39 --> Helper loaded: file_helper
INFO - 2023-10-21 08:47:39 --> Helper loaded: html_helper
INFO - 2023-10-21 08:47:39 --> Helper loaded: text_helper
INFO - 2023-10-21 08:47:39 --> Helper loaded: form_helper
INFO - 2023-10-21 08:47:39 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:47:39 --> Helper loaded: security_helper
INFO - 2023-10-21 08:47:39 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:47:39 --> Database Driver Class Initialized
INFO - 2023-10-21 08:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:47:39 --> Parser Class Initialized
INFO - 2023-10-21 08:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:47:39 --> Pagination Class Initialized
INFO - 2023-10-21 08:47:39 --> Form Validation Class Initialized
INFO - 2023-10-21 08:47:39 --> Controller Class Initialized
DEBUG - 2023-10-21 08:47:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:47:39 --> Model Class Initialized
INFO - 2023-10-21 08:47:39 --> Final output sent to browser
DEBUG - 2023-10-21 08:47:39 --> Total execution time: 0.0148
ERROR - 2023-10-21 08:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 08:48:27 --> Config Class Initialized
INFO - 2023-10-21 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-10-21 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-10-21 08:48:27 --> Utf8 Class Initialized
INFO - 2023-10-21 08:48:27 --> URI Class Initialized
INFO - 2023-10-21 08:48:27 --> Router Class Initialized
INFO - 2023-10-21 08:48:27 --> Output Class Initialized
INFO - 2023-10-21 08:48:27 --> Security Class Initialized
DEBUG - 2023-10-21 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 08:48:27 --> Input Class Initialized
INFO - 2023-10-21 08:48:27 --> Language Class Initialized
INFO - 2023-10-21 08:48:27 --> Loader Class Initialized
INFO - 2023-10-21 08:48:27 --> Helper loaded: url_helper
INFO - 2023-10-21 08:48:27 --> Helper loaded: file_helper
INFO - 2023-10-21 08:48:27 --> Helper loaded: html_helper
INFO - 2023-10-21 08:48:27 --> Helper loaded: text_helper
INFO - 2023-10-21 08:48:27 --> Helper loaded: form_helper
INFO - 2023-10-21 08:48:27 --> Helper loaded: lang_helper
INFO - 2023-10-21 08:48:27 --> Helper loaded: security_helper
INFO - 2023-10-21 08:48:27 --> Helper loaded: cookie_helper
INFO - 2023-10-21 08:48:27 --> Database Driver Class Initialized
INFO - 2023-10-21 08:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 08:48:27 --> Parser Class Initialized
INFO - 2023-10-21 08:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 08:48:27 --> Pagination Class Initialized
INFO - 2023-10-21 08:48:27 --> Form Validation Class Initialized
INFO - 2023-10-21 08:48:27 --> Controller Class Initialized
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
DEBUG - 2023-10-21 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
DEBUG - 2023-10-21 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
DEBUG - 2023-10-21 08:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
INFO - 2023-10-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 08:48:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 08:48:27 --> Model Class Initialized
INFO - 2023-10-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 08:48:27 --> Final output sent to browser
DEBUG - 2023-10-21 08:48:27 --> Total execution time: 0.1854
ERROR - 2023-10-21 13:58:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:58:36 --> Config Class Initialized
INFO - 2023-10-21 13:58:36 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:58:36 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:58:36 --> Utf8 Class Initialized
INFO - 2023-10-21 13:58:36 --> URI Class Initialized
DEBUG - 2023-10-21 13:58:36 --> No URI present. Default controller set.
INFO - 2023-10-21 13:58:36 --> Router Class Initialized
INFO - 2023-10-21 13:58:36 --> Output Class Initialized
INFO - 2023-10-21 13:58:36 --> Security Class Initialized
DEBUG - 2023-10-21 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:58:36 --> Input Class Initialized
INFO - 2023-10-21 13:58:36 --> Language Class Initialized
INFO - 2023-10-21 13:58:36 --> Loader Class Initialized
INFO - 2023-10-21 13:58:36 --> Helper loaded: url_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: file_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: html_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: text_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: form_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: security_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:58:36 --> Database Driver Class Initialized
INFO - 2023-10-21 13:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:58:36 --> Parser Class Initialized
INFO - 2023-10-21 13:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:58:36 --> Pagination Class Initialized
INFO - 2023-10-21 13:58:36 --> Form Validation Class Initialized
INFO - 2023-10-21 13:58:36 --> Controller Class Initialized
INFO - 2023-10-21 13:58:36 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-21 13:58:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:58:36 --> Config Class Initialized
INFO - 2023-10-21 13:58:36 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:58:36 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:58:36 --> Utf8 Class Initialized
INFO - 2023-10-21 13:58:36 --> URI Class Initialized
INFO - 2023-10-21 13:58:36 --> Router Class Initialized
INFO - 2023-10-21 13:58:36 --> Output Class Initialized
INFO - 2023-10-21 13:58:36 --> Security Class Initialized
DEBUG - 2023-10-21 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:58:36 --> Input Class Initialized
INFO - 2023-10-21 13:58:36 --> Language Class Initialized
INFO - 2023-10-21 13:58:36 --> Loader Class Initialized
INFO - 2023-10-21 13:58:36 --> Helper loaded: url_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: file_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: html_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: text_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: form_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: security_helper
INFO - 2023-10-21 13:58:36 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:58:36 --> Database Driver Class Initialized
INFO - 2023-10-21 13:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:58:36 --> Parser Class Initialized
INFO - 2023-10-21 13:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:58:36 --> Pagination Class Initialized
INFO - 2023-10-21 13:58:36 --> Form Validation Class Initialized
INFO - 2023-10-21 13:58:36 --> Controller Class Initialized
INFO - 2023-10-21 13:58:36 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 13:58:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 13:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 13:58:36 --> Model Class Initialized
INFO - 2023-10-21 13:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 13:58:36 --> Final output sent to browser
DEBUG - 2023-10-21 13:58:36 --> Total execution time: 0.0330
ERROR - 2023-10-21 13:58:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:58:48 --> Config Class Initialized
INFO - 2023-10-21 13:58:48 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:58:48 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:58:48 --> Utf8 Class Initialized
INFO - 2023-10-21 13:58:48 --> URI Class Initialized
INFO - 2023-10-21 13:58:48 --> Router Class Initialized
INFO - 2023-10-21 13:58:48 --> Output Class Initialized
INFO - 2023-10-21 13:58:48 --> Security Class Initialized
DEBUG - 2023-10-21 13:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:58:48 --> Input Class Initialized
INFO - 2023-10-21 13:58:48 --> Language Class Initialized
INFO - 2023-10-21 13:58:48 --> Loader Class Initialized
INFO - 2023-10-21 13:58:48 --> Helper loaded: url_helper
INFO - 2023-10-21 13:58:48 --> Helper loaded: file_helper
INFO - 2023-10-21 13:58:48 --> Helper loaded: html_helper
INFO - 2023-10-21 13:58:48 --> Helper loaded: text_helper
INFO - 2023-10-21 13:58:48 --> Helper loaded: form_helper
INFO - 2023-10-21 13:58:48 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:58:48 --> Helper loaded: security_helper
INFO - 2023-10-21 13:58:48 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:58:48 --> Database Driver Class Initialized
INFO - 2023-10-21 13:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:58:48 --> Parser Class Initialized
INFO - 2023-10-21 13:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:58:48 --> Pagination Class Initialized
INFO - 2023-10-21 13:58:48 --> Form Validation Class Initialized
INFO - 2023-10-21 13:58:48 --> Controller Class Initialized
INFO - 2023-10-21 13:58:48 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:48 --> Model Class Initialized
INFO - 2023-10-21 13:58:48 --> Final output sent to browser
DEBUG - 2023-10-21 13:58:48 --> Total execution time: 0.0222
ERROR - 2023-10-21 13:58:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:58:50 --> Config Class Initialized
INFO - 2023-10-21 13:58:50 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:58:50 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:58:50 --> Utf8 Class Initialized
INFO - 2023-10-21 13:58:50 --> URI Class Initialized
DEBUG - 2023-10-21 13:58:50 --> No URI present. Default controller set.
INFO - 2023-10-21 13:58:50 --> Router Class Initialized
INFO - 2023-10-21 13:58:50 --> Output Class Initialized
INFO - 2023-10-21 13:58:50 --> Security Class Initialized
DEBUG - 2023-10-21 13:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:58:50 --> Input Class Initialized
INFO - 2023-10-21 13:58:50 --> Language Class Initialized
INFO - 2023-10-21 13:58:50 --> Loader Class Initialized
INFO - 2023-10-21 13:58:50 --> Helper loaded: url_helper
INFO - 2023-10-21 13:58:50 --> Helper loaded: file_helper
INFO - 2023-10-21 13:58:50 --> Helper loaded: html_helper
INFO - 2023-10-21 13:58:50 --> Helper loaded: text_helper
INFO - 2023-10-21 13:58:50 --> Helper loaded: form_helper
INFO - 2023-10-21 13:58:50 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:58:50 --> Helper loaded: security_helper
INFO - 2023-10-21 13:58:50 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:58:50 --> Database Driver Class Initialized
INFO - 2023-10-21 13:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:58:50 --> Parser Class Initialized
INFO - 2023-10-21 13:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:58:50 --> Pagination Class Initialized
INFO - 2023-10-21 13:58:50 --> Form Validation Class Initialized
INFO - 2023-10-21 13:58:50 --> Controller Class Initialized
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 13:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
INFO - 2023-10-21 13:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 13:58:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 13:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 13:58:50 --> Model Class Initialized
INFO - 2023-10-21 13:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 13:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 13:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 13:58:50 --> Final output sent to browser
DEBUG - 2023-10-21 13:58:50 --> Total execution time: 0.2132
ERROR - 2023-10-21 13:58:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:58:53 --> Config Class Initialized
INFO - 2023-10-21 13:58:53 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:58:53 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:58:53 --> Utf8 Class Initialized
INFO - 2023-10-21 13:58:53 --> URI Class Initialized
INFO - 2023-10-21 13:58:53 --> Router Class Initialized
INFO - 2023-10-21 13:58:53 --> Output Class Initialized
INFO - 2023-10-21 13:58:53 --> Security Class Initialized
DEBUG - 2023-10-21 13:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:58:53 --> Input Class Initialized
INFO - 2023-10-21 13:58:53 --> Language Class Initialized
INFO - 2023-10-21 13:58:53 --> Loader Class Initialized
INFO - 2023-10-21 13:58:53 --> Helper loaded: url_helper
INFO - 2023-10-21 13:58:53 --> Helper loaded: file_helper
INFO - 2023-10-21 13:58:53 --> Helper loaded: html_helper
INFO - 2023-10-21 13:58:53 --> Helper loaded: text_helper
INFO - 2023-10-21 13:58:53 --> Helper loaded: form_helper
INFO - 2023-10-21 13:58:53 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:58:53 --> Helper loaded: security_helper
INFO - 2023-10-21 13:58:53 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:58:53 --> Database Driver Class Initialized
INFO - 2023-10-21 13:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:58:53 --> Parser Class Initialized
INFO - 2023-10-21 13:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:58:53 --> Pagination Class Initialized
INFO - 2023-10-21 13:58:53 --> Form Validation Class Initialized
INFO - 2023-10-21 13:58:53 --> Controller Class Initialized
INFO - 2023-10-21 13:58:53 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 13:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:53 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:53 --> Model Class Initialized
INFO - 2023-10-21 13:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-21 13:58:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 13:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 13:58:53 --> Model Class Initialized
INFO - 2023-10-21 13:58:53 --> Model Class Initialized
INFO - 2023-10-21 13:58:53 --> Model Class Initialized
INFO - 2023-10-21 13:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 13:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 13:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 13:58:53 --> Final output sent to browser
DEBUG - 2023-10-21 13:58:53 --> Total execution time: 0.1314
ERROR - 2023-10-21 13:58:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:58:54 --> Config Class Initialized
INFO - 2023-10-21 13:58:54 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:58:54 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:58:54 --> Utf8 Class Initialized
INFO - 2023-10-21 13:58:54 --> URI Class Initialized
INFO - 2023-10-21 13:58:54 --> Router Class Initialized
INFO - 2023-10-21 13:58:54 --> Output Class Initialized
INFO - 2023-10-21 13:58:54 --> Security Class Initialized
DEBUG - 2023-10-21 13:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:58:54 --> Input Class Initialized
INFO - 2023-10-21 13:58:54 --> Language Class Initialized
INFO - 2023-10-21 13:58:54 --> Loader Class Initialized
INFO - 2023-10-21 13:58:54 --> Helper loaded: url_helper
INFO - 2023-10-21 13:58:54 --> Helper loaded: file_helper
INFO - 2023-10-21 13:58:54 --> Helper loaded: html_helper
INFO - 2023-10-21 13:58:54 --> Helper loaded: text_helper
INFO - 2023-10-21 13:58:54 --> Helper loaded: form_helper
INFO - 2023-10-21 13:58:54 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:58:54 --> Helper loaded: security_helper
INFO - 2023-10-21 13:58:54 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:58:54 --> Database Driver Class Initialized
INFO - 2023-10-21 13:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:58:54 --> Parser Class Initialized
INFO - 2023-10-21 13:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:58:54 --> Pagination Class Initialized
INFO - 2023-10-21 13:58:54 --> Form Validation Class Initialized
INFO - 2023-10-21 13:58:54 --> Controller Class Initialized
INFO - 2023-10-21 13:58:54 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 13:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:54 --> Model Class Initialized
DEBUG - 2023-10-21 13:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:58:54 --> Model Class Initialized
INFO - 2023-10-21 13:58:54 --> Final output sent to browser
DEBUG - 2023-10-21 13:58:54 --> Total execution time: 0.0382
ERROR - 2023-10-21 13:59:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:59:15 --> Config Class Initialized
INFO - 2023-10-21 13:59:15 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:59:15 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:59:15 --> Utf8 Class Initialized
INFO - 2023-10-21 13:59:15 --> URI Class Initialized
INFO - 2023-10-21 13:59:15 --> Router Class Initialized
INFO - 2023-10-21 13:59:15 --> Output Class Initialized
INFO - 2023-10-21 13:59:15 --> Security Class Initialized
DEBUG - 2023-10-21 13:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:59:15 --> Input Class Initialized
INFO - 2023-10-21 13:59:15 --> Language Class Initialized
INFO - 2023-10-21 13:59:15 --> Loader Class Initialized
INFO - 2023-10-21 13:59:15 --> Helper loaded: url_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: file_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: html_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: text_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: form_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: security_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:59:15 --> Database Driver Class Initialized
INFO - 2023-10-21 13:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:59:15 --> Parser Class Initialized
INFO - 2023-10-21 13:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:59:15 --> Pagination Class Initialized
INFO - 2023-10-21 13:59:15 --> Form Validation Class Initialized
INFO - 2023-10-21 13:59:15 --> Controller Class Initialized
INFO - 2023-10-21 13:59:15 --> Model Class Initialized
DEBUG - 2023-10-21 13:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:15 --> Final output sent to browser
DEBUG - 2023-10-21 13:59:15 --> Total execution time: 0.0148
ERROR - 2023-10-21 13:59:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:59:15 --> Config Class Initialized
INFO - 2023-10-21 13:59:15 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:59:15 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:59:15 --> Utf8 Class Initialized
INFO - 2023-10-21 13:59:15 --> URI Class Initialized
INFO - 2023-10-21 13:59:15 --> Router Class Initialized
INFO - 2023-10-21 13:59:15 --> Output Class Initialized
INFO - 2023-10-21 13:59:15 --> Security Class Initialized
DEBUG - 2023-10-21 13:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:59:15 --> Input Class Initialized
INFO - 2023-10-21 13:59:15 --> Language Class Initialized
INFO - 2023-10-21 13:59:15 --> Loader Class Initialized
INFO - 2023-10-21 13:59:15 --> Helper loaded: url_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: file_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: html_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: text_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: form_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: security_helper
INFO - 2023-10-21 13:59:15 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:59:15 --> Database Driver Class Initialized
INFO - 2023-10-21 13:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:59:15 --> Parser Class Initialized
INFO - 2023-10-21 13:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:59:15 --> Pagination Class Initialized
INFO - 2023-10-21 13:59:15 --> Form Validation Class Initialized
INFO - 2023-10-21 13:59:15 --> Controller Class Initialized
INFO - 2023-10-21 13:59:15 --> Model Class Initialized
DEBUG - 2023-10-21 13:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 13:59:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 13:59:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 13:59:15 --> Model Class Initialized
INFO - 2023-10-21 13:59:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 13:59:15 --> Final output sent to browser
DEBUG - 2023-10-21 13:59:15 --> Total execution time: 0.0294
ERROR - 2023-10-21 13:59:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:59:24 --> Config Class Initialized
INFO - 2023-10-21 13:59:24 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:59:24 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:59:24 --> Utf8 Class Initialized
INFO - 2023-10-21 13:59:24 --> URI Class Initialized
INFO - 2023-10-21 13:59:24 --> Router Class Initialized
INFO - 2023-10-21 13:59:24 --> Output Class Initialized
INFO - 2023-10-21 13:59:24 --> Security Class Initialized
DEBUG - 2023-10-21 13:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:59:24 --> Input Class Initialized
INFO - 2023-10-21 13:59:24 --> Language Class Initialized
INFO - 2023-10-21 13:59:24 --> Loader Class Initialized
INFO - 2023-10-21 13:59:24 --> Helper loaded: url_helper
INFO - 2023-10-21 13:59:24 --> Helper loaded: file_helper
INFO - 2023-10-21 13:59:24 --> Helper loaded: html_helper
INFO - 2023-10-21 13:59:24 --> Helper loaded: text_helper
INFO - 2023-10-21 13:59:24 --> Helper loaded: form_helper
INFO - 2023-10-21 13:59:24 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:59:24 --> Helper loaded: security_helper
INFO - 2023-10-21 13:59:24 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:59:24 --> Database Driver Class Initialized
INFO - 2023-10-21 13:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:59:24 --> Parser Class Initialized
INFO - 2023-10-21 13:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:59:24 --> Pagination Class Initialized
INFO - 2023-10-21 13:59:24 --> Form Validation Class Initialized
INFO - 2023-10-21 13:59:24 --> Controller Class Initialized
ERROR - 2023-10-21 13:59:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:59:25 --> Config Class Initialized
INFO - 2023-10-21 13:59:25 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:59:25 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:59:25 --> Utf8 Class Initialized
INFO - 2023-10-21 13:59:25 --> URI Class Initialized
INFO - 2023-10-21 13:59:25 --> Router Class Initialized
INFO - 2023-10-21 13:59:25 --> Output Class Initialized
INFO - 2023-10-21 13:59:25 --> Security Class Initialized
DEBUG - 2023-10-21 13:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:59:25 --> Input Class Initialized
INFO - 2023-10-21 13:59:25 --> Language Class Initialized
INFO - 2023-10-21 13:59:25 --> Loader Class Initialized
INFO - 2023-10-21 13:59:25 --> Helper loaded: url_helper
INFO - 2023-10-21 13:59:25 --> Helper loaded: file_helper
INFO - 2023-10-21 13:59:25 --> Helper loaded: html_helper
INFO - 2023-10-21 13:59:25 --> Helper loaded: text_helper
INFO - 2023-10-21 13:59:25 --> Helper loaded: form_helper
INFO - 2023-10-21 13:59:25 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:59:25 --> Helper loaded: security_helper
INFO - 2023-10-21 13:59:25 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:59:25 --> Database Driver Class Initialized
INFO - 2023-10-21 13:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:59:25 --> Parser Class Initialized
INFO - 2023-10-21 13:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:59:25 --> Pagination Class Initialized
INFO - 2023-10-21 13:59:25 --> Form Validation Class Initialized
INFO - 2023-10-21 13:59:25 --> Controller Class Initialized
INFO - 2023-10-21 13:59:25 --> Model Class Initialized
DEBUG - 2023-10-21 13:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 13:59:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 13:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 13:59:25 --> Model Class Initialized
INFO - 2023-10-21 13:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 13:59:25 --> Final output sent to browser
DEBUG - 2023-10-21 13:59:25 --> Total execution time: 0.0299
ERROR - 2023-10-21 13:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:59:27 --> Config Class Initialized
INFO - 2023-10-21 13:59:27 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:59:27 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:59:27 --> Utf8 Class Initialized
INFO - 2023-10-21 13:59:27 --> URI Class Initialized
INFO - 2023-10-21 13:59:27 --> Router Class Initialized
INFO - 2023-10-21 13:59:27 --> Output Class Initialized
INFO - 2023-10-21 13:59:27 --> Security Class Initialized
DEBUG - 2023-10-21 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:59:27 --> Input Class Initialized
INFO - 2023-10-21 13:59:27 --> Language Class Initialized
INFO - 2023-10-21 13:59:27 --> Loader Class Initialized
INFO - 2023-10-21 13:59:27 --> Helper loaded: url_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: file_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: html_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: text_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: form_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: security_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:59:27 --> Database Driver Class Initialized
INFO - 2023-10-21 13:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:59:27 --> Parser Class Initialized
INFO - 2023-10-21 13:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:59:27 --> Pagination Class Initialized
INFO - 2023-10-21 13:59:27 --> Form Validation Class Initialized
INFO - 2023-10-21 13:59:27 --> Controller Class Initialized
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
DEBUG - 2023-10-21 13:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
INFO - 2023-10-21 13:59:27 --> Final output sent to browser
DEBUG - 2023-10-21 13:59:27 --> Total execution time: 0.0165
ERROR - 2023-10-21 13:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:59:27 --> Config Class Initialized
INFO - 2023-10-21 13:59:27 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:59:27 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:59:27 --> Utf8 Class Initialized
INFO - 2023-10-21 13:59:27 --> URI Class Initialized
DEBUG - 2023-10-21 13:59:27 --> No URI present. Default controller set.
INFO - 2023-10-21 13:59:27 --> Router Class Initialized
INFO - 2023-10-21 13:59:27 --> Output Class Initialized
INFO - 2023-10-21 13:59:27 --> Security Class Initialized
DEBUG - 2023-10-21 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:59:27 --> Input Class Initialized
INFO - 2023-10-21 13:59:27 --> Language Class Initialized
INFO - 2023-10-21 13:59:27 --> Loader Class Initialized
INFO - 2023-10-21 13:59:27 --> Helper loaded: url_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: file_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: html_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: text_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: form_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: security_helper
INFO - 2023-10-21 13:59:27 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:59:27 --> Database Driver Class Initialized
INFO - 2023-10-21 13:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:59:27 --> Parser Class Initialized
INFO - 2023-10-21 13:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:59:27 --> Pagination Class Initialized
INFO - 2023-10-21 13:59:27 --> Form Validation Class Initialized
INFO - 2023-10-21 13:59:27 --> Controller Class Initialized
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
DEBUG - 2023-10-21 13:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
DEBUG - 2023-10-21 13:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
DEBUG - 2023-10-21 13:59:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 13:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
INFO - 2023-10-21 13:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 13:59:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 13:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 13:59:27 --> Model Class Initialized
INFO - 2023-10-21 13:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 13:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 13:59:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 13:59:28 --> Final output sent to browser
DEBUG - 2023-10-21 13:59:28 --> Total execution time: 0.3689
ERROR - 2023-10-21 13:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 13:59:30 --> Config Class Initialized
INFO - 2023-10-21 13:59:30 --> Hooks Class Initialized
DEBUG - 2023-10-21 13:59:30 --> UTF-8 Support Enabled
INFO - 2023-10-21 13:59:30 --> Utf8 Class Initialized
INFO - 2023-10-21 13:59:30 --> URI Class Initialized
INFO - 2023-10-21 13:59:30 --> Router Class Initialized
INFO - 2023-10-21 13:59:30 --> Output Class Initialized
INFO - 2023-10-21 13:59:30 --> Security Class Initialized
DEBUG - 2023-10-21 13:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 13:59:30 --> Input Class Initialized
INFO - 2023-10-21 13:59:30 --> Language Class Initialized
INFO - 2023-10-21 13:59:30 --> Loader Class Initialized
INFO - 2023-10-21 13:59:30 --> Helper loaded: url_helper
INFO - 2023-10-21 13:59:30 --> Helper loaded: file_helper
INFO - 2023-10-21 13:59:30 --> Helper loaded: html_helper
INFO - 2023-10-21 13:59:30 --> Helper loaded: text_helper
INFO - 2023-10-21 13:59:30 --> Helper loaded: form_helper
INFO - 2023-10-21 13:59:30 --> Helper loaded: lang_helper
INFO - 2023-10-21 13:59:30 --> Helper loaded: security_helper
INFO - 2023-10-21 13:59:30 --> Helper loaded: cookie_helper
INFO - 2023-10-21 13:59:30 --> Database Driver Class Initialized
INFO - 2023-10-21 13:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 13:59:30 --> Parser Class Initialized
INFO - 2023-10-21 13:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 13:59:30 --> Pagination Class Initialized
INFO - 2023-10-21 13:59:30 --> Form Validation Class Initialized
INFO - 2023-10-21 13:59:30 --> Controller Class Initialized
DEBUG - 2023-10-21 13:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 13:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 13:59:30 --> Model Class Initialized
INFO - 2023-10-21 13:59:30 --> Final output sent to browser
DEBUG - 2023-10-21 13:59:30 --> Total execution time: 0.0132
ERROR - 2023-10-21 14:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:11:37 --> Config Class Initialized
INFO - 2023-10-21 14:11:37 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:11:37 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:11:37 --> Utf8 Class Initialized
INFO - 2023-10-21 14:11:37 --> URI Class Initialized
DEBUG - 2023-10-21 14:11:37 --> No URI present. Default controller set.
INFO - 2023-10-21 14:11:37 --> Router Class Initialized
INFO - 2023-10-21 14:11:37 --> Output Class Initialized
INFO - 2023-10-21 14:11:37 --> Security Class Initialized
DEBUG - 2023-10-21 14:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:11:37 --> Input Class Initialized
INFO - 2023-10-21 14:11:37 --> Language Class Initialized
INFO - 2023-10-21 14:11:37 --> Loader Class Initialized
INFO - 2023-10-21 14:11:37 --> Helper loaded: url_helper
INFO - 2023-10-21 14:11:37 --> Helper loaded: file_helper
INFO - 2023-10-21 14:11:37 --> Helper loaded: html_helper
INFO - 2023-10-21 14:11:37 --> Helper loaded: text_helper
INFO - 2023-10-21 14:11:37 --> Helper loaded: form_helper
INFO - 2023-10-21 14:11:37 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:11:37 --> Helper loaded: security_helper
INFO - 2023-10-21 14:11:37 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:11:37 --> Database Driver Class Initialized
INFO - 2023-10-21 14:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:11:37 --> Parser Class Initialized
INFO - 2023-10-21 14:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:11:37 --> Pagination Class Initialized
INFO - 2023-10-21 14:11:37 --> Form Validation Class Initialized
INFO - 2023-10-21 14:11:37 --> Controller Class Initialized
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
DEBUG - 2023-10-21 14:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
DEBUG - 2023-10-21 14:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
DEBUG - 2023-10-21 14:11:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
INFO - 2023-10-21 14:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 14:11:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:11:37 --> Model Class Initialized
INFO - 2023-10-21 14:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:11:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:11:37 --> Final output sent to browser
DEBUG - 2023-10-21 14:11:37 --> Total execution time: 0.3685
ERROR - 2023-10-21 14:11:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:11:53 --> Config Class Initialized
INFO - 2023-10-21 14:11:53 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:11:53 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:11:53 --> Utf8 Class Initialized
INFO - 2023-10-21 14:11:53 --> URI Class Initialized
DEBUG - 2023-10-21 14:11:53 --> No URI present. Default controller set.
INFO - 2023-10-21 14:11:53 --> Router Class Initialized
INFO - 2023-10-21 14:11:53 --> Output Class Initialized
INFO - 2023-10-21 14:11:53 --> Security Class Initialized
DEBUG - 2023-10-21 14:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:11:53 --> Input Class Initialized
INFO - 2023-10-21 14:11:53 --> Language Class Initialized
INFO - 2023-10-21 14:11:53 --> Loader Class Initialized
INFO - 2023-10-21 14:11:53 --> Helper loaded: url_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: file_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: html_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: text_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: form_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: security_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:11:53 --> Database Driver Class Initialized
INFO - 2023-10-21 14:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:11:53 --> Parser Class Initialized
INFO - 2023-10-21 14:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:11:53 --> Pagination Class Initialized
INFO - 2023-10-21 14:11:53 --> Form Validation Class Initialized
INFO - 2023-10-21 14:11:53 --> Controller Class Initialized
INFO - 2023-10-21 14:11:53 --> Model Class Initialized
DEBUG - 2023-10-21 14:11:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-21 14:11:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:11:53 --> Config Class Initialized
INFO - 2023-10-21 14:11:53 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:11:53 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:11:53 --> Utf8 Class Initialized
INFO - 2023-10-21 14:11:53 --> URI Class Initialized
INFO - 2023-10-21 14:11:53 --> Router Class Initialized
INFO - 2023-10-21 14:11:53 --> Output Class Initialized
INFO - 2023-10-21 14:11:53 --> Security Class Initialized
DEBUG - 2023-10-21 14:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:11:53 --> Input Class Initialized
INFO - 2023-10-21 14:11:53 --> Language Class Initialized
INFO - 2023-10-21 14:11:53 --> Loader Class Initialized
INFO - 2023-10-21 14:11:53 --> Helper loaded: url_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: file_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: html_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: text_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: form_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: security_helper
INFO - 2023-10-21 14:11:53 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:11:53 --> Database Driver Class Initialized
INFO - 2023-10-21 14:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:11:53 --> Parser Class Initialized
INFO - 2023-10-21 14:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:11:53 --> Pagination Class Initialized
INFO - 2023-10-21 14:11:53 --> Form Validation Class Initialized
INFO - 2023-10-21 14:11:53 --> Controller Class Initialized
INFO - 2023-10-21 14:11:53 --> Model Class Initialized
DEBUG - 2023-10-21 14:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 14:11:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:11:53 --> Model Class Initialized
INFO - 2023-10-21 14:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:11:53 --> Final output sent to browser
DEBUG - 2023-10-21 14:11:53 --> Total execution time: 0.0287
ERROR - 2023-10-21 14:11:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:11:59 --> Config Class Initialized
INFO - 2023-10-21 14:11:59 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:11:59 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:11:59 --> Utf8 Class Initialized
INFO - 2023-10-21 14:11:59 --> URI Class Initialized
INFO - 2023-10-21 14:11:59 --> Router Class Initialized
INFO - 2023-10-21 14:11:59 --> Output Class Initialized
INFO - 2023-10-21 14:11:59 --> Security Class Initialized
DEBUG - 2023-10-21 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:11:59 --> Input Class Initialized
INFO - 2023-10-21 14:11:59 --> Language Class Initialized
INFO - 2023-10-21 14:11:59 --> Loader Class Initialized
INFO - 2023-10-21 14:11:59 --> Helper loaded: url_helper
INFO - 2023-10-21 14:11:59 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:00 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:00 --> Parser Class Initialized
INFO - 2023-10-21 14:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:00 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:00 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:00 --> Controller Class Initialized
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
INFO - 2023-10-21 14:12:00 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:00 --> Total execution time: 0.0174
ERROR - 2023-10-21 14:12:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:00 --> Config Class Initialized
INFO - 2023-10-21 14:12:00 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:00 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:00 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:00 --> URI Class Initialized
DEBUG - 2023-10-21 14:12:00 --> No URI present. Default controller set.
INFO - 2023-10-21 14:12:00 --> Router Class Initialized
INFO - 2023-10-21 14:12:00 --> Output Class Initialized
INFO - 2023-10-21 14:12:00 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:00 --> Input Class Initialized
INFO - 2023-10-21 14:12:00 --> Language Class Initialized
INFO - 2023-10-21 14:12:00 --> Loader Class Initialized
INFO - 2023-10-21 14:12:00 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:00 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:00 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:00 --> Parser Class Initialized
INFO - 2023-10-21 14:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:00 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:00 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:00 --> Controller Class Initialized
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
INFO - 2023-10-21 14:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 14:12:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:12:00 --> Model Class Initialized
INFO - 2023-10-21 14:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:12:00 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:00 --> Total execution time: 0.1961
ERROR - 2023-10-21 14:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:11 --> Config Class Initialized
INFO - 2023-10-21 14:12:11 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:11 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:11 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:11 --> URI Class Initialized
INFO - 2023-10-21 14:12:11 --> Router Class Initialized
INFO - 2023-10-21 14:12:11 --> Output Class Initialized
INFO - 2023-10-21 14:12:11 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:11 --> Input Class Initialized
INFO - 2023-10-21 14:12:11 --> Language Class Initialized
INFO - 2023-10-21 14:12:11 --> Loader Class Initialized
INFO - 2023-10-21 14:12:11 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:11 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:11 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:11 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:11 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:11 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:11 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:11 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:11 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:11 --> Parser Class Initialized
INFO - 2023-10-21 14:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:11 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:11 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:11 --> Controller Class Initialized
INFO - 2023-10-21 14:12:11 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:11 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:11 --> Model Class Initialized
INFO - 2023-10-21 14:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-21 14:12:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:12:11 --> Model Class Initialized
INFO - 2023-10-21 14:12:11 --> Model Class Initialized
INFO - 2023-10-21 14:12:11 --> Model Class Initialized
INFO - 2023-10-21 14:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:12:12 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:12 --> Total execution time: 0.1309
ERROR - 2023-10-21 14:12:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:12 --> Config Class Initialized
INFO - 2023-10-21 14:12:12 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:12 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:12 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:12 --> URI Class Initialized
INFO - 2023-10-21 14:12:12 --> Router Class Initialized
INFO - 2023-10-21 14:12:12 --> Output Class Initialized
INFO - 2023-10-21 14:12:12 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:12 --> Input Class Initialized
INFO - 2023-10-21 14:12:12 --> Language Class Initialized
INFO - 2023-10-21 14:12:12 --> Loader Class Initialized
INFO - 2023-10-21 14:12:12 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:12 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:12 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:12 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:12 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:12 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:12 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:12 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:12 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:12 --> Parser Class Initialized
INFO - 2023-10-21 14:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:12 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:12 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:12 --> Controller Class Initialized
INFO - 2023-10-21 14:12:12 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:12 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:12 --> Model Class Initialized
INFO - 2023-10-21 14:12:12 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:12 --> Total execution time: 0.0377
ERROR - 2023-10-21 14:12:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:18 --> Config Class Initialized
INFO - 2023-10-21 14:12:18 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:18 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:18 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:18 --> URI Class Initialized
INFO - 2023-10-21 14:12:18 --> Router Class Initialized
INFO - 2023-10-21 14:12:18 --> Output Class Initialized
INFO - 2023-10-21 14:12:18 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:18 --> Input Class Initialized
INFO - 2023-10-21 14:12:18 --> Language Class Initialized
INFO - 2023-10-21 14:12:18 --> Loader Class Initialized
INFO - 2023-10-21 14:12:18 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:18 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:18 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:18 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:18 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:18 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:18 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:18 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:18 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:18 --> Parser Class Initialized
INFO - 2023-10-21 14:12:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:18 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:18 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:18 --> Controller Class Initialized
INFO - 2023-10-21 14:12:18 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:18 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:18 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-21 14:12:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:12:18 --> Model Class Initialized
INFO - 2023-10-21 14:12:18 --> Model Class Initialized
INFO - 2023-10-21 14:12:18 --> Model Class Initialized
INFO - 2023-10-21 14:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:12:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:12:18 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:18 --> Total execution time: 0.1327
ERROR - 2023-10-21 14:12:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:37 --> Config Class Initialized
INFO - 2023-10-21 14:12:37 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:37 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:37 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:37 --> URI Class Initialized
DEBUG - 2023-10-21 14:12:37 --> No URI present. Default controller set.
INFO - 2023-10-21 14:12:37 --> Router Class Initialized
INFO - 2023-10-21 14:12:37 --> Output Class Initialized
INFO - 2023-10-21 14:12:37 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:37 --> Input Class Initialized
INFO - 2023-10-21 14:12:37 --> Language Class Initialized
INFO - 2023-10-21 14:12:37 --> Loader Class Initialized
INFO - 2023-10-21 14:12:37 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:37 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:37 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:37 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:37 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:37 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:37 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:37 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:37 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:37 --> Parser Class Initialized
INFO - 2023-10-21 14:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:37 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:37 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:37 --> Controller Class Initialized
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
INFO - 2023-10-21 14:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 14:12:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:12:37 --> Model Class Initialized
INFO - 2023-10-21 14:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:12:37 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:37 --> Total execution time: 0.1993
ERROR - 2023-10-21 14:12:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:51 --> Config Class Initialized
INFO - 2023-10-21 14:12:51 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:51 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:51 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:51 --> URI Class Initialized
INFO - 2023-10-21 14:12:51 --> Router Class Initialized
INFO - 2023-10-21 14:12:51 --> Output Class Initialized
INFO - 2023-10-21 14:12:51 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:51 --> Input Class Initialized
INFO - 2023-10-21 14:12:51 --> Language Class Initialized
INFO - 2023-10-21 14:12:51 --> Loader Class Initialized
INFO - 2023-10-21 14:12:51 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:51 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:51 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:51 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:51 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:51 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:51 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:51 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:51 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:51 --> Parser Class Initialized
INFO - 2023-10-21 14:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:51 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:51 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:51 --> Controller Class Initialized
INFO - 2023-10-21 14:12:51 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:51 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:51 --> Model Class Initialized
INFO - 2023-10-21 14:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-21 14:12:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:12:51 --> Model Class Initialized
INFO - 2023-10-21 14:12:51 --> Model Class Initialized
INFO - 2023-10-21 14:12:51 --> Model Class Initialized
INFO - 2023-10-21 14:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:12:51 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:51 --> Total execution time: 0.1419
ERROR - 2023-10-21 14:12:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:52 --> Config Class Initialized
INFO - 2023-10-21 14:12:52 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:52 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:52 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:52 --> URI Class Initialized
INFO - 2023-10-21 14:12:52 --> Router Class Initialized
INFO - 2023-10-21 14:12:52 --> Output Class Initialized
INFO - 2023-10-21 14:12:52 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:52 --> Input Class Initialized
INFO - 2023-10-21 14:12:52 --> Language Class Initialized
INFO - 2023-10-21 14:12:52 --> Loader Class Initialized
INFO - 2023-10-21 14:12:52 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:52 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:52 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:52 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:52 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:52 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:52 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:52 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:52 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:52 --> Parser Class Initialized
INFO - 2023-10-21 14:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:52 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:52 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:52 --> Controller Class Initialized
INFO - 2023-10-21 14:12:52 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:52 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:52 --> Model Class Initialized
INFO - 2023-10-21 14:12:52 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:52 --> Total execution time: 0.0485
ERROR - 2023-10-21 14:12:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:12:55 --> Config Class Initialized
INFO - 2023-10-21 14:12:55 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:12:55 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:12:55 --> Utf8 Class Initialized
INFO - 2023-10-21 14:12:55 --> URI Class Initialized
INFO - 2023-10-21 14:12:55 --> Router Class Initialized
INFO - 2023-10-21 14:12:55 --> Output Class Initialized
INFO - 2023-10-21 14:12:55 --> Security Class Initialized
DEBUG - 2023-10-21 14:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:12:55 --> Input Class Initialized
INFO - 2023-10-21 14:12:55 --> Language Class Initialized
INFO - 2023-10-21 14:12:55 --> Loader Class Initialized
INFO - 2023-10-21 14:12:55 --> Helper loaded: url_helper
INFO - 2023-10-21 14:12:55 --> Helper loaded: file_helper
INFO - 2023-10-21 14:12:55 --> Helper loaded: html_helper
INFO - 2023-10-21 14:12:55 --> Helper loaded: text_helper
INFO - 2023-10-21 14:12:55 --> Helper loaded: form_helper
INFO - 2023-10-21 14:12:55 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:12:55 --> Helper loaded: security_helper
INFO - 2023-10-21 14:12:55 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:12:55 --> Database Driver Class Initialized
INFO - 2023-10-21 14:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:12:55 --> Parser Class Initialized
INFO - 2023-10-21 14:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:12:55 --> Pagination Class Initialized
INFO - 2023-10-21 14:12:55 --> Form Validation Class Initialized
INFO - 2023-10-21 14:12:55 --> Controller Class Initialized
INFO - 2023-10-21 14:12:55 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:55 --> Model Class Initialized
DEBUG - 2023-10-21 14:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:12:55 --> Model Class Initialized
INFO - 2023-10-21 14:12:55 --> Final output sent to browser
DEBUG - 2023-10-21 14:12:55 --> Total execution time: 0.4096
ERROR - 2023-10-21 14:13:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:13:32 --> Config Class Initialized
INFO - 2023-10-21 14:13:32 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:13:32 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:13:32 --> Utf8 Class Initialized
INFO - 2023-10-21 14:13:32 --> URI Class Initialized
DEBUG - 2023-10-21 14:13:32 --> No URI present. Default controller set.
INFO - 2023-10-21 14:13:32 --> Router Class Initialized
INFO - 2023-10-21 14:13:32 --> Output Class Initialized
INFO - 2023-10-21 14:13:32 --> Security Class Initialized
DEBUG - 2023-10-21 14:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:13:32 --> Input Class Initialized
INFO - 2023-10-21 14:13:32 --> Language Class Initialized
INFO - 2023-10-21 14:13:32 --> Loader Class Initialized
INFO - 2023-10-21 14:13:32 --> Helper loaded: url_helper
INFO - 2023-10-21 14:13:32 --> Helper loaded: file_helper
INFO - 2023-10-21 14:13:32 --> Helper loaded: html_helper
INFO - 2023-10-21 14:13:32 --> Helper loaded: text_helper
INFO - 2023-10-21 14:13:32 --> Helper loaded: form_helper
INFO - 2023-10-21 14:13:32 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:13:32 --> Helper loaded: security_helper
INFO - 2023-10-21 14:13:32 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:13:32 --> Database Driver Class Initialized
INFO - 2023-10-21 14:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:13:32 --> Parser Class Initialized
INFO - 2023-10-21 14:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:13:32 --> Pagination Class Initialized
INFO - 2023-10-21 14:13:32 --> Form Validation Class Initialized
INFO - 2023-10-21 14:13:32 --> Controller Class Initialized
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
INFO - 2023-10-21 14:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 14:13:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:13:32 --> Model Class Initialized
INFO - 2023-10-21 14:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:13:32 --> Final output sent to browser
DEBUG - 2023-10-21 14:13:32 --> Total execution time: 0.2066
ERROR - 2023-10-21 14:13:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:13:44 --> Config Class Initialized
INFO - 2023-10-21 14:13:44 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:13:44 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:13:44 --> Utf8 Class Initialized
INFO - 2023-10-21 14:13:44 --> URI Class Initialized
INFO - 2023-10-21 14:13:44 --> Router Class Initialized
INFO - 2023-10-21 14:13:44 --> Output Class Initialized
INFO - 2023-10-21 14:13:44 --> Security Class Initialized
DEBUG - 2023-10-21 14:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:13:44 --> Input Class Initialized
INFO - 2023-10-21 14:13:44 --> Language Class Initialized
INFO - 2023-10-21 14:13:44 --> Loader Class Initialized
INFO - 2023-10-21 14:13:44 --> Helper loaded: url_helper
INFO - 2023-10-21 14:13:44 --> Helper loaded: file_helper
INFO - 2023-10-21 14:13:44 --> Helper loaded: html_helper
INFO - 2023-10-21 14:13:44 --> Helper loaded: text_helper
INFO - 2023-10-21 14:13:44 --> Helper loaded: form_helper
INFO - 2023-10-21 14:13:44 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:13:44 --> Helper loaded: security_helper
INFO - 2023-10-21 14:13:44 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:13:44 --> Database Driver Class Initialized
INFO - 2023-10-21 14:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:13:44 --> Parser Class Initialized
INFO - 2023-10-21 14:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:13:44 --> Pagination Class Initialized
INFO - 2023-10-21 14:13:44 --> Form Validation Class Initialized
INFO - 2023-10-21 14:13:44 --> Controller Class Initialized
INFO - 2023-10-21 14:13:44 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:44 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:44 --> Model Class Initialized
INFO - 2023-10-21 14:13:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-21 14:13:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:13:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:13:44 --> Model Class Initialized
INFO - 2023-10-21 14:13:44 --> Model Class Initialized
INFO - 2023-10-21 14:13:44 --> Model Class Initialized
INFO - 2023-10-21 14:13:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:13:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:13:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:13:44 --> Final output sent to browser
DEBUG - 2023-10-21 14:13:44 --> Total execution time: 0.1456
ERROR - 2023-10-21 14:13:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:13:45 --> Config Class Initialized
INFO - 2023-10-21 14:13:45 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:13:45 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:13:45 --> Utf8 Class Initialized
INFO - 2023-10-21 14:13:45 --> URI Class Initialized
INFO - 2023-10-21 14:13:45 --> Router Class Initialized
INFO - 2023-10-21 14:13:45 --> Output Class Initialized
INFO - 2023-10-21 14:13:45 --> Security Class Initialized
DEBUG - 2023-10-21 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:13:45 --> Input Class Initialized
INFO - 2023-10-21 14:13:45 --> Language Class Initialized
INFO - 2023-10-21 14:13:45 --> Loader Class Initialized
INFO - 2023-10-21 14:13:45 --> Helper loaded: url_helper
INFO - 2023-10-21 14:13:45 --> Helper loaded: file_helper
INFO - 2023-10-21 14:13:45 --> Helper loaded: html_helper
INFO - 2023-10-21 14:13:45 --> Helper loaded: text_helper
INFO - 2023-10-21 14:13:45 --> Helper loaded: form_helper
INFO - 2023-10-21 14:13:45 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:13:45 --> Helper loaded: security_helper
INFO - 2023-10-21 14:13:45 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:13:45 --> Database Driver Class Initialized
INFO - 2023-10-21 14:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:13:45 --> Parser Class Initialized
INFO - 2023-10-21 14:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:13:45 --> Pagination Class Initialized
INFO - 2023-10-21 14:13:45 --> Form Validation Class Initialized
INFO - 2023-10-21 14:13:45 --> Controller Class Initialized
INFO - 2023-10-21 14:13:45 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:45 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:45 --> Model Class Initialized
INFO - 2023-10-21 14:13:45 --> Final output sent to browser
DEBUG - 2023-10-21 14:13:45 --> Total execution time: 0.0396
ERROR - 2023-10-21 14:13:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:13:48 --> Config Class Initialized
INFO - 2023-10-21 14:13:48 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:13:48 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:13:48 --> Utf8 Class Initialized
INFO - 2023-10-21 14:13:48 --> URI Class Initialized
INFO - 2023-10-21 14:13:48 --> Router Class Initialized
INFO - 2023-10-21 14:13:48 --> Output Class Initialized
INFO - 2023-10-21 14:13:48 --> Security Class Initialized
DEBUG - 2023-10-21 14:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:13:48 --> Input Class Initialized
INFO - 2023-10-21 14:13:48 --> Language Class Initialized
INFO - 2023-10-21 14:13:48 --> Loader Class Initialized
INFO - 2023-10-21 14:13:48 --> Helper loaded: url_helper
INFO - 2023-10-21 14:13:48 --> Helper loaded: file_helper
INFO - 2023-10-21 14:13:48 --> Helper loaded: html_helper
INFO - 2023-10-21 14:13:48 --> Helper loaded: text_helper
INFO - 2023-10-21 14:13:48 --> Helper loaded: form_helper
INFO - 2023-10-21 14:13:48 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:13:48 --> Helper loaded: security_helper
INFO - 2023-10-21 14:13:48 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:13:48 --> Database Driver Class Initialized
INFO - 2023-10-21 14:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:13:48 --> Parser Class Initialized
INFO - 2023-10-21 14:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:13:48 --> Pagination Class Initialized
INFO - 2023-10-21 14:13:48 --> Form Validation Class Initialized
INFO - 2023-10-21 14:13:48 --> Controller Class Initialized
INFO - 2023-10-21 14:13:48 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:48 --> Model Class Initialized
DEBUG - 2023-10-21 14:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:13:48 --> Model Class Initialized
INFO - 2023-10-21 14:13:48 --> Final output sent to browser
DEBUG - 2023-10-21 14:13:48 --> Total execution time: 0.4069
ERROR - 2023-10-21 14:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:14:08 --> Config Class Initialized
INFO - 2023-10-21 14:14:08 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:14:08 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:14:08 --> Utf8 Class Initialized
INFO - 2023-10-21 14:14:08 --> URI Class Initialized
INFO - 2023-10-21 14:14:08 --> Router Class Initialized
INFO - 2023-10-21 14:14:08 --> Output Class Initialized
INFO - 2023-10-21 14:14:08 --> Security Class Initialized
DEBUG - 2023-10-21 14:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:14:08 --> Input Class Initialized
INFO - 2023-10-21 14:14:08 --> Language Class Initialized
INFO - 2023-10-21 14:14:08 --> Loader Class Initialized
INFO - 2023-10-21 14:14:08 --> Helper loaded: url_helper
INFO - 2023-10-21 14:14:08 --> Helper loaded: file_helper
INFO - 2023-10-21 14:14:08 --> Helper loaded: html_helper
INFO - 2023-10-21 14:14:08 --> Helper loaded: text_helper
INFO - 2023-10-21 14:14:08 --> Helper loaded: form_helper
INFO - 2023-10-21 14:14:08 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:14:08 --> Helper loaded: security_helper
INFO - 2023-10-21 14:14:08 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:14:08 --> Database Driver Class Initialized
INFO - 2023-10-21 14:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:14:08 --> Parser Class Initialized
INFO - 2023-10-21 14:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:14:08 --> Pagination Class Initialized
INFO - 2023-10-21 14:14:08 --> Form Validation Class Initialized
INFO - 2023-10-21 14:14:08 --> Controller Class Initialized
INFO - 2023-10-21 14:14:08 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:08 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:08 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-21 14:14:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:14:08 --> Model Class Initialized
INFO - 2023-10-21 14:14:08 --> Model Class Initialized
INFO - 2023-10-21 14:14:08 --> Model Class Initialized
INFO - 2023-10-21 14:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:14:08 --> Final output sent to browser
DEBUG - 2023-10-21 14:14:08 --> Total execution time: 0.1384
ERROR - 2023-10-21 14:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:14:13 --> Config Class Initialized
INFO - 2023-10-21 14:14:13 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:14:13 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:14:13 --> Utf8 Class Initialized
INFO - 2023-10-21 14:14:13 --> URI Class Initialized
INFO - 2023-10-21 14:14:13 --> Router Class Initialized
INFO - 2023-10-21 14:14:13 --> Output Class Initialized
INFO - 2023-10-21 14:14:13 --> Security Class Initialized
DEBUG - 2023-10-21 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:14:13 --> Input Class Initialized
INFO - 2023-10-21 14:14:13 --> Language Class Initialized
INFO - 2023-10-21 14:14:13 --> Loader Class Initialized
INFO - 2023-10-21 14:14:13 --> Helper loaded: url_helper
INFO - 2023-10-21 14:14:13 --> Helper loaded: file_helper
INFO - 2023-10-21 14:14:13 --> Helper loaded: html_helper
INFO - 2023-10-21 14:14:13 --> Helper loaded: text_helper
INFO - 2023-10-21 14:14:13 --> Helper loaded: form_helper
INFO - 2023-10-21 14:14:13 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:14:13 --> Helper loaded: security_helper
INFO - 2023-10-21 14:14:13 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:14:13 --> Database Driver Class Initialized
INFO - 2023-10-21 14:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:14:13 --> Parser Class Initialized
INFO - 2023-10-21 14:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:14:13 --> Pagination Class Initialized
INFO - 2023-10-21 14:14:13 --> Form Validation Class Initialized
INFO - 2023-10-21 14:14:13 --> Controller Class Initialized
INFO - 2023-10-21 14:14:13 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:13 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:13 --> Model Class Initialized
INFO - 2023-10-21 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-21 14:14:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:14:13 --> Model Class Initialized
INFO - 2023-10-21 14:14:13 --> Model Class Initialized
INFO - 2023-10-21 14:14:13 --> Model Class Initialized
INFO - 2023-10-21 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:14:13 --> Final output sent to browser
DEBUG - 2023-10-21 14:14:13 --> Total execution time: 0.1351
ERROR - 2023-10-21 14:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:14:14 --> Config Class Initialized
INFO - 2023-10-21 14:14:14 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:14:14 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:14:14 --> Utf8 Class Initialized
INFO - 2023-10-21 14:14:14 --> URI Class Initialized
INFO - 2023-10-21 14:14:14 --> Router Class Initialized
INFO - 2023-10-21 14:14:14 --> Output Class Initialized
INFO - 2023-10-21 14:14:14 --> Security Class Initialized
DEBUG - 2023-10-21 14:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:14:14 --> Input Class Initialized
INFO - 2023-10-21 14:14:14 --> Language Class Initialized
INFO - 2023-10-21 14:14:14 --> Loader Class Initialized
INFO - 2023-10-21 14:14:14 --> Helper loaded: url_helper
INFO - 2023-10-21 14:14:14 --> Helper loaded: file_helper
INFO - 2023-10-21 14:14:14 --> Helper loaded: html_helper
INFO - 2023-10-21 14:14:14 --> Helper loaded: text_helper
INFO - 2023-10-21 14:14:14 --> Helper loaded: form_helper
INFO - 2023-10-21 14:14:14 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:14:14 --> Helper loaded: security_helper
INFO - 2023-10-21 14:14:14 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:14:14 --> Database Driver Class Initialized
INFO - 2023-10-21 14:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:14:14 --> Parser Class Initialized
INFO - 2023-10-21 14:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:14:14 --> Pagination Class Initialized
INFO - 2023-10-21 14:14:14 --> Form Validation Class Initialized
INFO - 2023-10-21 14:14:14 --> Controller Class Initialized
INFO - 2023-10-21 14:14:14 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:14 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:14 --> Model Class Initialized
INFO - 2023-10-21 14:14:14 --> Final output sent to browser
DEBUG - 2023-10-21 14:14:14 --> Total execution time: 0.0437
ERROR - 2023-10-21 14:14:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:14:17 --> Config Class Initialized
INFO - 2023-10-21 14:14:17 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:14:17 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:14:17 --> Utf8 Class Initialized
INFO - 2023-10-21 14:14:17 --> URI Class Initialized
INFO - 2023-10-21 14:14:17 --> Router Class Initialized
INFO - 2023-10-21 14:14:17 --> Output Class Initialized
INFO - 2023-10-21 14:14:17 --> Security Class Initialized
DEBUG - 2023-10-21 14:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:14:17 --> Input Class Initialized
INFO - 2023-10-21 14:14:17 --> Language Class Initialized
INFO - 2023-10-21 14:14:17 --> Loader Class Initialized
INFO - 2023-10-21 14:14:17 --> Helper loaded: url_helper
INFO - 2023-10-21 14:14:17 --> Helper loaded: file_helper
INFO - 2023-10-21 14:14:17 --> Helper loaded: html_helper
INFO - 2023-10-21 14:14:17 --> Helper loaded: text_helper
INFO - 2023-10-21 14:14:17 --> Helper loaded: form_helper
INFO - 2023-10-21 14:14:17 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:14:17 --> Helper loaded: security_helper
INFO - 2023-10-21 14:14:17 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:14:17 --> Database Driver Class Initialized
INFO - 2023-10-21 14:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:14:17 --> Parser Class Initialized
INFO - 2023-10-21 14:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:14:17 --> Pagination Class Initialized
INFO - 2023-10-21 14:14:17 --> Form Validation Class Initialized
INFO - 2023-10-21 14:14:17 --> Controller Class Initialized
INFO - 2023-10-21 14:14:17 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:17 --> Model Class Initialized
DEBUG - 2023-10-21 14:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:14:17 --> Model Class Initialized
INFO - 2023-10-21 14:14:17 --> Final output sent to browser
DEBUG - 2023-10-21 14:14:17 --> Total execution time: 0.3916
ERROR - 2023-10-21 14:15:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:15:31 --> Config Class Initialized
INFO - 2023-10-21 14:15:31 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:15:31 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:15:31 --> Utf8 Class Initialized
INFO - 2023-10-21 14:15:31 --> URI Class Initialized
DEBUG - 2023-10-21 14:15:31 --> No URI present. Default controller set.
INFO - 2023-10-21 14:15:31 --> Router Class Initialized
INFO - 2023-10-21 14:15:31 --> Output Class Initialized
INFO - 2023-10-21 14:15:31 --> Security Class Initialized
DEBUG - 2023-10-21 14:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:15:31 --> Input Class Initialized
INFO - 2023-10-21 14:15:31 --> Language Class Initialized
INFO - 2023-10-21 14:15:31 --> Loader Class Initialized
INFO - 2023-10-21 14:15:31 --> Helper loaded: url_helper
INFO - 2023-10-21 14:15:31 --> Helper loaded: file_helper
INFO - 2023-10-21 14:15:31 --> Helper loaded: html_helper
INFO - 2023-10-21 14:15:31 --> Helper loaded: text_helper
INFO - 2023-10-21 14:15:31 --> Helper loaded: form_helper
INFO - 2023-10-21 14:15:31 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:15:31 --> Helper loaded: security_helper
INFO - 2023-10-21 14:15:31 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:15:31 --> Database Driver Class Initialized
INFO - 2023-10-21 14:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:15:31 --> Parser Class Initialized
INFO - 2023-10-21 14:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:15:32 --> Pagination Class Initialized
INFO - 2023-10-21 14:15:32 --> Form Validation Class Initialized
INFO - 2023-10-21 14:15:32 --> Controller Class Initialized
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
INFO - 2023-10-21 14:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-21 14:15:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:15:32 --> Model Class Initialized
INFO - 2023-10-21 14:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:15:32 --> Final output sent to browser
DEBUG - 2023-10-21 14:15:32 --> Total execution time: 0.2169
ERROR - 2023-10-21 14:15:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:15:41 --> Config Class Initialized
INFO - 2023-10-21 14:15:41 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:15:41 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:15:41 --> Utf8 Class Initialized
INFO - 2023-10-21 14:15:41 --> URI Class Initialized
INFO - 2023-10-21 14:15:41 --> Router Class Initialized
INFO - 2023-10-21 14:15:41 --> Output Class Initialized
INFO - 2023-10-21 14:15:41 --> Security Class Initialized
DEBUG - 2023-10-21 14:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:15:41 --> Input Class Initialized
INFO - 2023-10-21 14:15:41 --> Language Class Initialized
INFO - 2023-10-21 14:15:41 --> Loader Class Initialized
INFO - 2023-10-21 14:15:41 --> Helper loaded: url_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: file_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: html_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: text_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: form_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: security_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:15:41 --> Database Driver Class Initialized
INFO - 2023-10-21 14:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:15:41 --> Parser Class Initialized
INFO - 2023-10-21 14:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:15:41 --> Pagination Class Initialized
INFO - 2023-10-21 14:15:41 --> Form Validation Class Initialized
INFO - 2023-10-21 14:15:41 --> Controller Class Initialized
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
INFO - 2023-10-21 14:15:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-21 14:15:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 14:15:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
INFO - 2023-10-21 14:15:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-21 14:15:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-21 14:15:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 14:15:41 --> Final output sent to browser
DEBUG - 2023-10-21 14:15:41 --> Total execution time: 0.2113
ERROR - 2023-10-21 14:15:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:15:41 --> Config Class Initialized
INFO - 2023-10-21 14:15:41 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:15:41 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:15:41 --> Utf8 Class Initialized
INFO - 2023-10-21 14:15:41 --> URI Class Initialized
INFO - 2023-10-21 14:15:41 --> Router Class Initialized
INFO - 2023-10-21 14:15:41 --> Output Class Initialized
INFO - 2023-10-21 14:15:41 --> Security Class Initialized
DEBUG - 2023-10-21 14:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:15:41 --> Input Class Initialized
INFO - 2023-10-21 14:15:41 --> Language Class Initialized
INFO - 2023-10-21 14:15:41 --> Loader Class Initialized
INFO - 2023-10-21 14:15:41 --> Helper loaded: url_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: file_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: html_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: text_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: form_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: security_helper
INFO - 2023-10-21 14:15:41 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:15:41 --> Database Driver Class Initialized
INFO - 2023-10-21 14:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:15:41 --> Parser Class Initialized
INFO - 2023-10-21 14:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:15:41 --> Pagination Class Initialized
INFO - 2023-10-21 14:15:41 --> Form Validation Class Initialized
INFO - 2023-10-21 14:15:41 --> Controller Class Initialized
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:41 --> Model Class Initialized
INFO - 2023-10-21 14:15:41 --> Final output sent to browser
DEBUG - 2023-10-21 14:15:41 --> Total execution time: 0.0588
ERROR - 2023-10-21 14:15:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:15:48 --> Config Class Initialized
INFO - 2023-10-21 14:15:48 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:15:48 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:15:48 --> Utf8 Class Initialized
INFO - 2023-10-21 14:15:48 --> URI Class Initialized
INFO - 2023-10-21 14:15:48 --> Router Class Initialized
INFO - 2023-10-21 14:15:48 --> Output Class Initialized
INFO - 2023-10-21 14:15:48 --> Security Class Initialized
DEBUG - 2023-10-21 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:15:48 --> Input Class Initialized
INFO - 2023-10-21 14:15:48 --> Language Class Initialized
INFO - 2023-10-21 14:15:48 --> Loader Class Initialized
INFO - 2023-10-21 14:15:48 --> Helper loaded: url_helper
INFO - 2023-10-21 14:15:48 --> Helper loaded: file_helper
INFO - 2023-10-21 14:15:48 --> Helper loaded: html_helper
INFO - 2023-10-21 14:15:48 --> Helper loaded: text_helper
INFO - 2023-10-21 14:15:48 --> Helper loaded: form_helper
INFO - 2023-10-21 14:15:48 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:15:48 --> Helper loaded: security_helper
INFO - 2023-10-21 14:15:48 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:15:48 --> Database Driver Class Initialized
INFO - 2023-10-21 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:15:48 --> Parser Class Initialized
INFO - 2023-10-21 14:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:15:48 --> Pagination Class Initialized
INFO - 2023-10-21 14:15:48 --> Form Validation Class Initialized
INFO - 2023-10-21 14:15:48 --> Controller Class Initialized
INFO - 2023-10-21 14:15:48 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:48 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:48 --> Model Class Initialized
ERROR - 2023-10-21 14:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:15:49 --> Config Class Initialized
INFO - 2023-10-21 14:15:49 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:15:49 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:15:49 --> Utf8 Class Initialized
INFO - 2023-10-21 14:15:49 --> URI Class Initialized
DEBUG - 2023-10-21 14:15:49 --> No URI present. Default controller set.
INFO - 2023-10-21 14:15:49 --> Router Class Initialized
INFO - 2023-10-21 14:15:49 --> Output Class Initialized
INFO - 2023-10-21 14:15:49 --> Security Class Initialized
DEBUG - 2023-10-21 14:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:15:49 --> Input Class Initialized
INFO - 2023-10-21 14:15:49 --> Language Class Initialized
INFO - 2023-10-21 14:15:49 --> Loader Class Initialized
INFO - 2023-10-21 14:15:49 --> Helper loaded: url_helper
INFO - 2023-10-21 14:15:49 --> Helper loaded: file_helper
INFO - 2023-10-21 14:15:49 --> Helper loaded: html_helper
INFO - 2023-10-21 14:15:49 --> Helper loaded: text_helper
INFO - 2023-10-21 14:15:49 --> Helper loaded: form_helper
INFO - 2023-10-21 14:15:49 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:15:49 --> Helper loaded: security_helper
INFO - 2023-10-21 14:15:49 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:15:49 --> Database Driver Class Initialized
INFO - 2023-10-21 14:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:15:49 --> Parser Class Initialized
INFO - 2023-10-21 14:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:15:49 --> Pagination Class Initialized
INFO - 2023-10-21 14:15:49 --> Form Validation Class Initialized
INFO - 2023-10-21 14:15:49 --> Controller Class Initialized
INFO - 2023-10-21 14:15:49 --> Model Class Initialized
DEBUG - 2023-10-21 14:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:15:49 --> Final output sent to browser
DEBUG - 2023-10-21 14:15:49 --> Total execution time: 0.8779
ERROR - 2023-10-21 14:16:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:16:01 --> Config Class Initialized
INFO - 2023-10-21 14:16:01 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:16:01 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:16:01 --> Utf8 Class Initialized
INFO - 2023-10-21 14:16:01 --> URI Class Initialized
INFO - 2023-10-21 14:16:01 --> Router Class Initialized
INFO - 2023-10-21 14:16:01 --> Output Class Initialized
INFO - 2023-10-21 14:16:01 --> Security Class Initialized
DEBUG - 2023-10-21 14:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:16:01 --> Input Class Initialized
INFO - 2023-10-21 14:16:01 --> Language Class Initialized
INFO - 2023-10-21 14:16:01 --> Loader Class Initialized
INFO - 2023-10-21 14:16:01 --> Helper loaded: url_helper
INFO - 2023-10-21 14:16:01 --> Helper loaded: file_helper
INFO - 2023-10-21 14:16:01 --> Helper loaded: html_helper
INFO - 2023-10-21 14:16:01 --> Helper loaded: text_helper
INFO - 2023-10-21 14:16:01 --> Helper loaded: form_helper
INFO - 2023-10-21 14:16:01 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:16:01 --> Helper loaded: security_helper
INFO - 2023-10-21 14:16:01 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:16:01 --> Database Driver Class Initialized
INFO - 2023-10-21 14:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:16:01 --> Parser Class Initialized
INFO - 2023-10-21 14:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:16:01 --> Pagination Class Initialized
INFO - 2023-10-21 14:16:01 --> Form Validation Class Initialized
INFO - 2023-10-21 14:16:01 --> Controller Class Initialized
INFO - 2023-10-21 14:16:01 --> Model Class Initialized
DEBUG - 2023-10-21 14:16:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:16:01 --> Model Class Initialized
DEBUG - 2023-10-21 14:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:16:01 --> Model Class Initialized
INFO - 2023-10-21 14:16:01 --> Final output sent to browser
DEBUG - 2023-10-21 14:16:01 --> Total execution time: 0.1520
ERROR - 2023-10-21 14:16:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 14:16:04 --> Config Class Initialized
INFO - 2023-10-21 14:16:04 --> Hooks Class Initialized
DEBUG - 2023-10-21 14:16:04 --> UTF-8 Support Enabled
INFO - 2023-10-21 14:16:04 --> Utf8 Class Initialized
INFO - 2023-10-21 14:16:04 --> URI Class Initialized
INFO - 2023-10-21 14:16:04 --> Router Class Initialized
INFO - 2023-10-21 14:16:04 --> Output Class Initialized
INFO - 2023-10-21 14:16:04 --> Security Class Initialized
DEBUG - 2023-10-21 14:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 14:16:04 --> Input Class Initialized
INFO - 2023-10-21 14:16:04 --> Language Class Initialized
INFO - 2023-10-21 14:16:04 --> Loader Class Initialized
INFO - 2023-10-21 14:16:04 --> Helper loaded: url_helper
INFO - 2023-10-21 14:16:04 --> Helper loaded: file_helper
INFO - 2023-10-21 14:16:04 --> Helper loaded: html_helper
INFO - 2023-10-21 14:16:04 --> Helper loaded: text_helper
INFO - 2023-10-21 14:16:04 --> Helper loaded: form_helper
INFO - 2023-10-21 14:16:04 --> Helper loaded: lang_helper
INFO - 2023-10-21 14:16:04 --> Helper loaded: security_helper
INFO - 2023-10-21 14:16:04 --> Helper loaded: cookie_helper
INFO - 2023-10-21 14:16:04 --> Database Driver Class Initialized
INFO - 2023-10-21 14:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 14:16:04 --> Parser Class Initialized
INFO - 2023-10-21 14:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 14:16:04 --> Pagination Class Initialized
INFO - 2023-10-21 14:16:04 --> Form Validation Class Initialized
INFO - 2023-10-21 14:16:04 --> Controller Class Initialized
INFO - 2023-10-21 14:16:04 --> Model Class Initialized
DEBUG - 2023-10-21 14:16:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-21 14:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:16:04 --> Model Class Initialized
DEBUG - 2023-10-21 14:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 14:16:04 --> Model Class Initialized
INFO - 2023-10-21 14:16:04 --> Final output sent to browser
DEBUG - 2023-10-21 14:16:04 --> Total execution time: 0.1673
ERROR - 2023-10-21 21:12:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 21:12:01 --> Config Class Initialized
INFO - 2023-10-21 21:12:01 --> Hooks Class Initialized
DEBUG - 2023-10-21 21:12:01 --> UTF-8 Support Enabled
INFO - 2023-10-21 21:12:01 --> Utf8 Class Initialized
INFO - 2023-10-21 21:12:01 --> URI Class Initialized
DEBUG - 2023-10-21 21:12:01 --> No URI present. Default controller set.
INFO - 2023-10-21 21:12:01 --> Router Class Initialized
INFO - 2023-10-21 21:12:01 --> Output Class Initialized
INFO - 2023-10-21 21:12:01 --> Security Class Initialized
DEBUG - 2023-10-21 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 21:12:01 --> Input Class Initialized
INFO - 2023-10-21 21:12:01 --> Language Class Initialized
INFO - 2023-10-21 21:12:01 --> Loader Class Initialized
INFO - 2023-10-21 21:12:01 --> Helper loaded: url_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: file_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: html_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: text_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: form_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: lang_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: security_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: cookie_helper
INFO - 2023-10-21 21:12:01 --> Database Driver Class Initialized
INFO - 2023-10-21 21:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 21:12:01 --> Parser Class Initialized
INFO - 2023-10-21 21:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 21:12:01 --> Pagination Class Initialized
INFO - 2023-10-21 21:12:01 --> Form Validation Class Initialized
INFO - 2023-10-21 21:12:01 --> Controller Class Initialized
INFO - 2023-10-21 21:12:01 --> Model Class Initialized
DEBUG - 2023-10-21 21:12:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-21 21:12:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-21 21:12:01 --> Config Class Initialized
INFO - 2023-10-21 21:12:01 --> Hooks Class Initialized
DEBUG - 2023-10-21 21:12:01 --> UTF-8 Support Enabled
INFO - 2023-10-21 21:12:01 --> Utf8 Class Initialized
INFO - 2023-10-21 21:12:01 --> URI Class Initialized
INFO - 2023-10-21 21:12:01 --> Router Class Initialized
INFO - 2023-10-21 21:12:01 --> Output Class Initialized
INFO - 2023-10-21 21:12:01 --> Security Class Initialized
DEBUG - 2023-10-21 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-21 21:12:01 --> Input Class Initialized
INFO - 2023-10-21 21:12:01 --> Language Class Initialized
INFO - 2023-10-21 21:12:01 --> Loader Class Initialized
INFO - 2023-10-21 21:12:01 --> Helper loaded: url_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: file_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: html_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: text_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: form_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: lang_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: security_helper
INFO - 2023-10-21 21:12:01 --> Helper loaded: cookie_helper
INFO - 2023-10-21 21:12:01 --> Database Driver Class Initialized
INFO - 2023-10-21 21:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-21 21:12:01 --> Parser Class Initialized
INFO - 2023-10-21 21:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-21 21:12:01 --> Pagination Class Initialized
INFO - 2023-10-21 21:12:01 --> Form Validation Class Initialized
INFO - 2023-10-21 21:12:01 --> Controller Class Initialized
INFO - 2023-10-21 21:12:01 --> Model Class Initialized
DEBUG - 2023-10-21 21:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-21 21:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-21 21:12:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-21 21:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-21 21:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-21 21:12:01 --> Model Class Initialized
INFO - 2023-10-21 21:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-21 21:12:01 --> Final output sent to browser
DEBUG - 2023-10-21 21:12:01 --> Total execution time: 0.0366
