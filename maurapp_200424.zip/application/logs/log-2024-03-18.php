<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-18 04:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:31:57 --> Config Class Initialized
INFO - 2024-03-18 04:31:57 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:31:57 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:31:57 --> Utf8 Class Initialized
INFO - 2024-03-18 04:31:57 --> URI Class Initialized
DEBUG - 2024-03-18 04:31:57 --> No URI present. Default controller set.
INFO - 2024-03-18 04:31:57 --> Router Class Initialized
INFO - 2024-03-18 04:31:57 --> Output Class Initialized
INFO - 2024-03-18 04:31:57 --> Security Class Initialized
DEBUG - 2024-03-18 04:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:31:57 --> Input Class Initialized
INFO - 2024-03-18 04:31:57 --> Language Class Initialized
INFO - 2024-03-18 04:31:57 --> Loader Class Initialized
INFO - 2024-03-18 04:31:57 --> Helper loaded: url_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: file_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: html_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: text_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: form_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: security_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:31:57 --> Database Driver Class Initialized
INFO - 2024-03-18 04:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:31:57 --> Parser Class Initialized
INFO - 2024-03-18 04:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:31:57 --> Pagination Class Initialized
INFO - 2024-03-18 04:31:57 --> Form Validation Class Initialized
INFO - 2024-03-18 04:31:57 --> Controller Class Initialized
INFO - 2024-03-18 04:31:57 --> Model Class Initialized
DEBUG - 2024-03-18 04:31:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-18 04:31:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:31:57 --> Config Class Initialized
INFO - 2024-03-18 04:31:57 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:31:57 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:31:57 --> Utf8 Class Initialized
INFO - 2024-03-18 04:31:57 --> URI Class Initialized
INFO - 2024-03-18 04:31:57 --> Router Class Initialized
INFO - 2024-03-18 04:31:57 --> Output Class Initialized
INFO - 2024-03-18 04:31:57 --> Security Class Initialized
DEBUG - 2024-03-18 04:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:31:57 --> Input Class Initialized
INFO - 2024-03-18 04:31:57 --> Language Class Initialized
INFO - 2024-03-18 04:31:57 --> Loader Class Initialized
INFO - 2024-03-18 04:31:57 --> Helper loaded: url_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: file_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: html_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: text_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: form_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: security_helper
INFO - 2024-03-18 04:31:57 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:31:57 --> Database Driver Class Initialized
INFO - 2024-03-18 04:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:31:57 --> Parser Class Initialized
INFO - 2024-03-18 04:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:31:57 --> Pagination Class Initialized
INFO - 2024-03-18 04:31:57 --> Form Validation Class Initialized
INFO - 2024-03-18 04:31:57 --> Controller Class Initialized
INFO - 2024-03-18 04:31:57 --> Model Class Initialized
DEBUG - 2024-03-18 04:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-18 04:31:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 04:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 04:31:57 --> Model Class Initialized
INFO - 2024-03-18 04:31:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 04:31:57 --> Final output sent to browser
DEBUG - 2024-03-18 04:31:57 --> Total execution time: 0.0343
ERROR - 2024-03-18 04:32:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:32:24 --> Config Class Initialized
INFO - 2024-03-18 04:32:24 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:32:24 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:32:24 --> Utf8 Class Initialized
INFO - 2024-03-18 04:32:24 --> URI Class Initialized
INFO - 2024-03-18 04:32:24 --> Router Class Initialized
INFO - 2024-03-18 04:32:24 --> Output Class Initialized
INFO - 2024-03-18 04:32:24 --> Security Class Initialized
DEBUG - 2024-03-18 04:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:32:24 --> Input Class Initialized
INFO - 2024-03-18 04:32:24 --> Language Class Initialized
INFO - 2024-03-18 04:32:24 --> Loader Class Initialized
INFO - 2024-03-18 04:32:24 --> Helper loaded: url_helper
INFO - 2024-03-18 04:32:24 --> Helper loaded: file_helper
INFO - 2024-03-18 04:32:24 --> Helper loaded: html_helper
INFO - 2024-03-18 04:32:24 --> Helper loaded: text_helper
INFO - 2024-03-18 04:32:24 --> Helper loaded: form_helper
INFO - 2024-03-18 04:32:24 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:32:24 --> Helper loaded: security_helper
INFO - 2024-03-18 04:32:24 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:32:24 --> Database Driver Class Initialized
INFO - 2024-03-18 04:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:32:24 --> Parser Class Initialized
INFO - 2024-03-18 04:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:32:24 --> Pagination Class Initialized
INFO - 2024-03-18 04:32:24 --> Form Validation Class Initialized
INFO - 2024-03-18 04:32:24 --> Controller Class Initialized
INFO - 2024-03-18 04:32:24 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:24 --> Model Class Initialized
INFO - 2024-03-18 04:32:24 --> Final output sent to browser
DEBUG - 2024-03-18 04:32:24 --> Total execution time: 0.0223
ERROR - 2024-03-18 04:32:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:32:24 --> Config Class Initialized
INFO - 2024-03-18 04:32:24 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:32:24 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:32:24 --> Utf8 Class Initialized
INFO - 2024-03-18 04:32:24 --> URI Class Initialized
DEBUG - 2024-03-18 04:32:24 --> No URI present. Default controller set.
INFO - 2024-03-18 04:32:24 --> Router Class Initialized
INFO - 2024-03-18 04:32:24 --> Output Class Initialized
INFO - 2024-03-18 04:32:24 --> Security Class Initialized
DEBUG - 2024-03-18 04:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:32:25 --> Input Class Initialized
INFO - 2024-03-18 04:32:25 --> Language Class Initialized
INFO - 2024-03-18 04:32:25 --> Loader Class Initialized
INFO - 2024-03-18 04:32:25 --> Helper loaded: url_helper
INFO - 2024-03-18 04:32:25 --> Helper loaded: file_helper
INFO - 2024-03-18 04:32:25 --> Helper loaded: html_helper
INFO - 2024-03-18 04:32:25 --> Helper loaded: text_helper
INFO - 2024-03-18 04:32:25 --> Helper loaded: form_helper
INFO - 2024-03-18 04:32:25 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:32:25 --> Helper loaded: security_helper
INFO - 2024-03-18 04:32:25 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:32:25 --> Database Driver Class Initialized
INFO - 2024-03-18 04:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:32:25 --> Parser Class Initialized
INFO - 2024-03-18 04:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:32:25 --> Pagination Class Initialized
INFO - 2024-03-18 04:32:25 --> Form Validation Class Initialized
INFO - 2024-03-18 04:32:25 --> Controller Class Initialized
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 04:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
INFO - 2024-03-18 04:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-18 04:32:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 04:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 04:32:25 --> Model Class Initialized
INFO - 2024-03-18 04:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-18 04:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-18 04:32:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 04:32:25 --> Final output sent to browser
DEBUG - 2024-03-18 04:32:25 --> Total execution time: 0.2652
ERROR - 2024-03-18 04:32:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:32:35 --> Config Class Initialized
INFO - 2024-03-18 04:32:35 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:32:35 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:32:35 --> Utf8 Class Initialized
INFO - 2024-03-18 04:32:35 --> URI Class Initialized
INFO - 2024-03-18 04:32:35 --> Router Class Initialized
INFO - 2024-03-18 04:32:35 --> Output Class Initialized
INFO - 2024-03-18 04:32:35 --> Security Class Initialized
DEBUG - 2024-03-18 04:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:32:35 --> Input Class Initialized
INFO - 2024-03-18 04:32:35 --> Language Class Initialized
INFO - 2024-03-18 04:32:35 --> Loader Class Initialized
INFO - 2024-03-18 04:32:35 --> Helper loaded: url_helper
INFO - 2024-03-18 04:32:35 --> Helper loaded: file_helper
INFO - 2024-03-18 04:32:35 --> Helper loaded: html_helper
INFO - 2024-03-18 04:32:35 --> Helper loaded: text_helper
INFO - 2024-03-18 04:32:35 --> Helper loaded: form_helper
INFO - 2024-03-18 04:32:35 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:32:35 --> Helper loaded: security_helper
INFO - 2024-03-18 04:32:35 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:32:35 --> Database Driver Class Initialized
INFO - 2024-03-18 04:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:32:35 --> Parser Class Initialized
INFO - 2024-03-18 04:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:32:35 --> Pagination Class Initialized
INFO - 2024-03-18 04:32:35 --> Form Validation Class Initialized
INFO - 2024-03-18 04:32:35 --> Controller Class Initialized
INFO - 2024-03-18 04:32:35 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 04:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:35 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:35 --> Model Class Initialized
INFO - 2024-03-18 04:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-18 04:32:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 04:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 04:32:35 --> Model Class Initialized
INFO - 2024-03-18 04:32:35 --> Model Class Initialized
INFO - 2024-03-18 04:32:35 --> Model Class Initialized
INFO - 2024-03-18 04:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-18 04:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-18 04:32:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 04:32:35 --> Final output sent to browser
DEBUG - 2024-03-18 04:32:35 --> Total execution time: 0.1702
ERROR - 2024-03-18 04:32:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:32:36 --> Config Class Initialized
INFO - 2024-03-18 04:32:36 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:32:36 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:32:36 --> Utf8 Class Initialized
INFO - 2024-03-18 04:32:36 --> URI Class Initialized
INFO - 2024-03-18 04:32:36 --> Router Class Initialized
INFO - 2024-03-18 04:32:36 --> Output Class Initialized
INFO - 2024-03-18 04:32:36 --> Security Class Initialized
DEBUG - 2024-03-18 04:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:32:36 --> Input Class Initialized
INFO - 2024-03-18 04:32:36 --> Language Class Initialized
INFO - 2024-03-18 04:32:36 --> Loader Class Initialized
INFO - 2024-03-18 04:32:36 --> Helper loaded: url_helper
INFO - 2024-03-18 04:32:36 --> Helper loaded: file_helper
INFO - 2024-03-18 04:32:36 --> Helper loaded: html_helper
INFO - 2024-03-18 04:32:36 --> Helper loaded: text_helper
INFO - 2024-03-18 04:32:36 --> Helper loaded: form_helper
INFO - 2024-03-18 04:32:36 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:32:36 --> Helper loaded: security_helper
INFO - 2024-03-18 04:32:36 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:32:36 --> Database Driver Class Initialized
INFO - 2024-03-18 04:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:32:36 --> Parser Class Initialized
INFO - 2024-03-18 04:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:32:36 --> Pagination Class Initialized
INFO - 2024-03-18 04:32:36 --> Form Validation Class Initialized
INFO - 2024-03-18 04:32:36 --> Controller Class Initialized
INFO - 2024-03-18 04:32:36 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 04:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:36 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:36 --> Model Class Initialized
INFO - 2024-03-18 04:32:36 --> Final output sent to browser
DEBUG - 2024-03-18 04:32:36 --> Total execution time: 0.0454
ERROR - 2024-03-18 04:32:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:32:41 --> Config Class Initialized
INFO - 2024-03-18 04:32:41 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:32:41 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:32:41 --> Utf8 Class Initialized
INFO - 2024-03-18 04:32:41 --> URI Class Initialized
INFO - 2024-03-18 04:32:41 --> Router Class Initialized
INFO - 2024-03-18 04:32:41 --> Output Class Initialized
INFO - 2024-03-18 04:32:41 --> Security Class Initialized
DEBUG - 2024-03-18 04:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:32:41 --> Input Class Initialized
INFO - 2024-03-18 04:32:41 --> Language Class Initialized
INFO - 2024-03-18 04:32:41 --> Loader Class Initialized
INFO - 2024-03-18 04:32:41 --> Helper loaded: url_helper
INFO - 2024-03-18 04:32:41 --> Helper loaded: file_helper
INFO - 2024-03-18 04:32:41 --> Helper loaded: html_helper
INFO - 2024-03-18 04:32:41 --> Helper loaded: text_helper
INFO - 2024-03-18 04:32:41 --> Helper loaded: form_helper
INFO - 2024-03-18 04:32:41 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:32:41 --> Helper loaded: security_helper
INFO - 2024-03-18 04:32:41 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:32:41 --> Database Driver Class Initialized
INFO - 2024-03-18 04:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:32:41 --> Parser Class Initialized
INFO - 2024-03-18 04:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:32:41 --> Pagination Class Initialized
INFO - 2024-03-18 04:32:41 --> Form Validation Class Initialized
INFO - 2024-03-18 04:32:41 --> Controller Class Initialized
INFO - 2024-03-18 04:32:41 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 04:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:41 --> Model Class Initialized
DEBUG - 2024-03-18 04:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:32:41 --> Model Class Initialized
INFO - 2024-03-18 04:32:42 --> Final output sent to browser
DEBUG - 2024-03-18 04:32:42 --> Total execution time: 0.2766
ERROR - 2024-03-18 04:33:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 04:33:01 --> Config Class Initialized
INFO - 2024-03-18 04:33:01 --> Hooks Class Initialized
DEBUG - 2024-03-18 04:33:01 --> UTF-8 Support Enabled
INFO - 2024-03-18 04:33:01 --> Utf8 Class Initialized
INFO - 2024-03-18 04:33:01 --> URI Class Initialized
INFO - 2024-03-18 04:33:01 --> Router Class Initialized
INFO - 2024-03-18 04:33:01 --> Output Class Initialized
INFO - 2024-03-18 04:33:01 --> Security Class Initialized
DEBUG - 2024-03-18 04:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 04:33:01 --> Input Class Initialized
INFO - 2024-03-18 04:33:01 --> Language Class Initialized
INFO - 2024-03-18 04:33:01 --> Loader Class Initialized
INFO - 2024-03-18 04:33:01 --> Helper loaded: url_helper
INFO - 2024-03-18 04:33:01 --> Helper loaded: file_helper
INFO - 2024-03-18 04:33:01 --> Helper loaded: html_helper
INFO - 2024-03-18 04:33:01 --> Helper loaded: text_helper
INFO - 2024-03-18 04:33:01 --> Helper loaded: form_helper
INFO - 2024-03-18 04:33:01 --> Helper loaded: lang_helper
INFO - 2024-03-18 04:33:01 --> Helper loaded: security_helper
INFO - 2024-03-18 04:33:01 --> Helper loaded: cookie_helper
INFO - 2024-03-18 04:33:01 --> Database Driver Class Initialized
INFO - 2024-03-18 04:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 04:33:01 --> Parser Class Initialized
INFO - 2024-03-18 04:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 04:33:01 --> Pagination Class Initialized
INFO - 2024-03-18 04:33:01 --> Form Validation Class Initialized
INFO - 2024-03-18 04:33:01 --> Controller Class Initialized
INFO - 2024-03-18 04:33:01 --> Model Class Initialized
DEBUG - 2024-03-18 04:33:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 04:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:33:01 --> Model Class Initialized
DEBUG - 2024-03-18 04:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:33:01 --> Model Class Initialized
DEBUG - 2024-03-18 04:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-18 04:33:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 04:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 04:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 04:33:01 --> Model Class Initialized
INFO - 2024-03-18 04:33:01 --> Model Class Initialized
INFO - 2024-03-18 04:33:01 --> Model Class Initialized
INFO - 2024-03-18 04:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-18 04:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-18 04:33:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 04:33:01 --> Final output sent to browser
DEBUG - 2024-03-18 04:33:01 --> Total execution time: 0.1739
ERROR - 2024-03-18 06:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 06:31:05 --> Config Class Initialized
INFO - 2024-03-18 06:31:05 --> Hooks Class Initialized
DEBUG - 2024-03-18 06:31:05 --> UTF-8 Support Enabled
INFO - 2024-03-18 06:31:05 --> Utf8 Class Initialized
INFO - 2024-03-18 06:31:05 --> URI Class Initialized
DEBUG - 2024-03-18 06:31:05 --> No URI present. Default controller set.
INFO - 2024-03-18 06:31:05 --> Router Class Initialized
INFO - 2024-03-18 06:31:05 --> Output Class Initialized
INFO - 2024-03-18 06:31:05 --> Security Class Initialized
DEBUG - 2024-03-18 06:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 06:31:05 --> Input Class Initialized
INFO - 2024-03-18 06:31:05 --> Language Class Initialized
INFO - 2024-03-18 06:31:05 --> Loader Class Initialized
INFO - 2024-03-18 06:31:05 --> Helper loaded: url_helper
INFO - 2024-03-18 06:31:05 --> Helper loaded: file_helper
INFO - 2024-03-18 06:31:05 --> Helper loaded: html_helper
INFO - 2024-03-18 06:31:05 --> Helper loaded: text_helper
INFO - 2024-03-18 06:31:05 --> Helper loaded: form_helper
INFO - 2024-03-18 06:31:05 --> Helper loaded: lang_helper
INFO - 2024-03-18 06:31:05 --> Helper loaded: security_helper
INFO - 2024-03-18 06:31:05 --> Helper loaded: cookie_helper
INFO - 2024-03-18 06:31:05 --> Database Driver Class Initialized
INFO - 2024-03-18 06:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 06:31:05 --> Parser Class Initialized
INFO - 2024-03-18 06:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 06:31:05 --> Pagination Class Initialized
INFO - 2024-03-18 06:31:05 --> Form Validation Class Initialized
INFO - 2024-03-18 06:31:05 --> Controller Class Initialized
INFO - 2024-03-18 06:31:05 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-18 06:31:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 06:31:06 --> Config Class Initialized
INFO - 2024-03-18 06:31:06 --> Hooks Class Initialized
DEBUG - 2024-03-18 06:31:06 --> UTF-8 Support Enabled
INFO - 2024-03-18 06:31:06 --> Utf8 Class Initialized
INFO - 2024-03-18 06:31:06 --> URI Class Initialized
INFO - 2024-03-18 06:31:06 --> Router Class Initialized
INFO - 2024-03-18 06:31:06 --> Output Class Initialized
INFO - 2024-03-18 06:31:06 --> Security Class Initialized
DEBUG - 2024-03-18 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 06:31:06 --> Input Class Initialized
INFO - 2024-03-18 06:31:06 --> Language Class Initialized
INFO - 2024-03-18 06:31:06 --> Loader Class Initialized
INFO - 2024-03-18 06:31:06 --> Helper loaded: url_helper
INFO - 2024-03-18 06:31:06 --> Helper loaded: file_helper
INFO - 2024-03-18 06:31:06 --> Helper loaded: html_helper
INFO - 2024-03-18 06:31:06 --> Helper loaded: text_helper
INFO - 2024-03-18 06:31:06 --> Helper loaded: form_helper
INFO - 2024-03-18 06:31:06 --> Helper loaded: lang_helper
INFO - 2024-03-18 06:31:06 --> Helper loaded: security_helper
INFO - 2024-03-18 06:31:06 --> Helper loaded: cookie_helper
INFO - 2024-03-18 06:31:06 --> Database Driver Class Initialized
INFO - 2024-03-18 06:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 06:31:06 --> Parser Class Initialized
INFO - 2024-03-18 06:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 06:31:06 --> Pagination Class Initialized
INFO - 2024-03-18 06:31:06 --> Form Validation Class Initialized
INFO - 2024-03-18 06:31:06 --> Controller Class Initialized
INFO - 2024-03-18 06:31:06 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-18 06:31:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 06:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 06:31:06 --> Model Class Initialized
INFO - 2024-03-18 06:31:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 06:31:06 --> Final output sent to browser
DEBUG - 2024-03-18 06:31:06 --> Total execution time: 0.0409
ERROR - 2024-03-18 06:31:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 06:31:20 --> Config Class Initialized
INFO - 2024-03-18 06:31:20 --> Hooks Class Initialized
DEBUG - 2024-03-18 06:31:20 --> UTF-8 Support Enabled
INFO - 2024-03-18 06:31:20 --> Utf8 Class Initialized
INFO - 2024-03-18 06:31:20 --> URI Class Initialized
INFO - 2024-03-18 06:31:20 --> Router Class Initialized
INFO - 2024-03-18 06:31:20 --> Output Class Initialized
INFO - 2024-03-18 06:31:20 --> Security Class Initialized
DEBUG - 2024-03-18 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 06:31:20 --> Input Class Initialized
INFO - 2024-03-18 06:31:20 --> Language Class Initialized
INFO - 2024-03-18 06:31:20 --> Loader Class Initialized
INFO - 2024-03-18 06:31:20 --> Helper loaded: url_helper
INFO - 2024-03-18 06:31:20 --> Helper loaded: file_helper
INFO - 2024-03-18 06:31:20 --> Helper loaded: html_helper
INFO - 2024-03-18 06:31:20 --> Helper loaded: text_helper
INFO - 2024-03-18 06:31:20 --> Helper loaded: form_helper
INFO - 2024-03-18 06:31:20 --> Helper loaded: lang_helper
INFO - 2024-03-18 06:31:20 --> Helper loaded: security_helper
INFO - 2024-03-18 06:31:20 --> Helper loaded: cookie_helper
INFO - 2024-03-18 06:31:20 --> Database Driver Class Initialized
INFO - 2024-03-18 06:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 06:31:20 --> Parser Class Initialized
INFO - 2024-03-18 06:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 06:31:20 --> Pagination Class Initialized
INFO - 2024-03-18 06:31:20 --> Form Validation Class Initialized
INFO - 2024-03-18 06:31:20 --> Controller Class Initialized
INFO - 2024-03-18 06:31:20 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:20 --> Model Class Initialized
INFO - 2024-03-18 06:31:20 --> Final output sent to browser
DEBUG - 2024-03-18 06:31:20 --> Total execution time: 0.0199
ERROR - 2024-03-18 06:31:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 06:31:21 --> Config Class Initialized
INFO - 2024-03-18 06:31:21 --> Hooks Class Initialized
DEBUG - 2024-03-18 06:31:21 --> UTF-8 Support Enabled
INFO - 2024-03-18 06:31:21 --> Utf8 Class Initialized
INFO - 2024-03-18 06:31:21 --> URI Class Initialized
DEBUG - 2024-03-18 06:31:21 --> No URI present. Default controller set.
INFO - 2024-03-18 06:31:21 --> Router Class Initialized
INFO - 2024-03-18 06:31:21 --> Output Class Initialized
INFO - 2024-03-18 06:31:21 --> Security Class Initialized
DEBUG - 2024-03-18 06:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 06:31:21 --> Input Class Initialized
INFO - 2024-03-18 06:31:21 --> Language Class Initialized
INFO - 2024-03-18 06:31:21 --> Loader Class Initialized
INFO - 2024-03-18 06:31:21 --> Helper loaded: url_helper
INFO - 2024-03-18 06:31:21 --> Helper loaded: file_helper
INFO - 2024-03-18 06:31:21 --> Helper loaded: html_helper
INFO - 2024-03-18 06:31:21 --> Helper loaded: text_helper
INFO - 2024-03-18 06:31:21 --> Helper loaded: form_helper
INFO - 2024-03-18 06:31:21 --> Helper loaded: lang_helper
INFO - 2024-03-18 06:31:21 --> Helper loaded: security_helper
INFO - 2024-03-18 06:31:21 --> Helper loaded: cookie_helper
INFO - 2024-03-18 06:31:21 --> Database Driver Class Initialized
INFO - 2024-03-18 06:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 06:31:21 --> Parser Class Initialized
INFO - 2024-03-18 06:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 06:31:21 --> Pagination Class Initialized
INFO - 2024-03-18 06:31:21 --> Form Validation Class Initialized
INFO - 2024-03-18 06:31:21 --> Controller Class Initialized
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 06:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
INFO - 2024-03-18 06:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-18 06:31:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 06:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 06:31:21 --> Model Class Initialized
INFO - 2024-03-18 06:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-18 06:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-18 06:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 06:31:22 --> Final output sent to browser
DEBUG - 2024-03-18 06:31:22 --> Total execution time: 0.4611
ERROR - 2024-03-18 06:31:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 06:31:24 --> Config Class Initialized
INFO - 2024-03-18 06:31:24 --> Hooks Class Initialized
DEBUG - 2024-03-18 06:31:24 --> UTF-8 Support Enabled
INFO - 2024-03-18 06:31:24 --> Utf8 Class Initialized
INFO - 2024-03-18 06:31:24 --> URI Class Initialized
INFO - 2024-03-18 06:31:24 --> Router Class Initialized
INFO - 2024-03-18 06:31:24 --> Output Class Initialized
INFO - 2024-03-18 06:31:24 --> Security Class Initialized
DEBUG - 2024-03-18 06:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 06:31:24 --> Input Class Initialized
INFO - 2024-03-18 06:31:24 --> Language Class Initialized
INFO - 2024-03-18 06:31:24 --> Loader Class Initialized
INFO - 2024-03-18 06:31:24 --> Helper loaded: url_helper
INFO - 2024-03-18 06:31:24 --> Helper loaded: file_helper
INFO - 2024-03-18 06:31:24 --> Helper loaded: html_helper
INFO - 2024-03-18 06:31:24 --> Helper loaded: text_helper
INFO - 2024-03-18 06:31:24 --> Helper loaded: form_helper
INFO - 2024-03-18 06:31:24 --> Helper loaded: lang_helper
INFO - 2024-03-18 06:31:24 --> Helper loaded: security_helper
INFO - 2024-03-18 06:31:24 --> Helper loaded: cookie_helper
INFO - 2024-03-18 06:31:24 --> Database Driver Class Initialized
INFO - 2024-03-18 06:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 06:31:24 --> Parser Class Initialized
INFO - 2024-03-18 06:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 06:31:24 --> Pagination Class Initialized
INFO - 2024-03-18 06:31:24 --> Form Validation Class Initialized
INFO - 2024-03-18 06:31:24 --> Controller Class Initialized
DEBUG - 2024-03-18 06:31:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 06:31:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:24 --> Model Class Initialized
INFO - 2024-03-18 06:31:24 --> Final output sent to browser
DEBUG - 2024-03-18 06:31:24 --> Total execution time: 0.0135
ERROR - 2024-03-18 06:31:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 06:31:41 --> Config Class Initialized
INFO - 2024-03-18 06:31:41 --> Hooks Class Initialized
DEBUG - 2024-03-18 06:31:41 --> UTF-8 Support Enabled
INFO - 2024-03-18 06:31:41 --> Utf8 Class Initialized
INFO - 2024-03-18 06:31:41 --> URI Class Initialized
INFO - 2024-03-18 06:31:41 --> Router Class Initialized
INFO - 2024-03-18 06:31:41 --> Output Class Initialized
INFO - 2024-03-18 06:31:41 --> Security Class Initialized
DEBUG - 2024-03-18 06:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 06:31:41 --> Input Class Initialized
INFO - 2024-03-18 06:31:41 --> Language Class Initialized
INFO - 2024-03-18 06:31:41 --> Loader Class Initialized
INFO - 2024-03-18 06:31:41 --> Helper loaded: url_helper
INFO - 2024-03-18 06:31:41 --> Helper loaded: file_helper
INFO - 2024-03-18 06:31:41 --> Helper loaded: html_helper
INFO - 2024-03-18 06:31:41 --> Helper loaded: text_helper
INFO - 2024-03-18 06:31:41 --> Helper loaded: form_helper
INFO - 2024-03-18 06:31:41 --> Helper loaded: lang_helper
INFO - 2024-03-18 06:31:41 --> Helper loaded: security_helper
INFO - 2024-03-18 06:31:41 --> Helper loaded: cookie_helper
INFO - 2024-03-18 06:31:41 --> Database Driver Class Initialized
INFO - 2024-03-18 06:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 06:31:41 --> Parser Class Initialized
INFO - 2024-03-18 06:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 06:31:41 --> Pagination Class Initialized
INFO - 2024-03-18 06:31:41 --> Form Validation Class Initialized
INFO - 2024-03-18 06:31:41 --> Controller Class Initialized
INFO - 2024-03-18 06:31:41 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 06:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:41 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:41 --> Model Class Initialized
INFO - 2024-03-18 06:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-18 06:31:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 06:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 06:31:41 --> Model Class Initialized
INFO - 2024-03-18 06:31:41 --> Model Class Initialized
INFO - 2024-03-18 06:31:41 --> Model Class Initialized
INFO - 2024-03-18 06:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-18 06:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-18 06:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 06:31:41 --> Final output sent to browser
DEBUG - 2024-03-18 06:31:41 --> Total execution time: 0.2360
ERROR - 2024-03-18 06:31:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 06:31:42 --> Config Class Initialized
INFO - 2024-03-18 06:31:42 --> Hooks Class Initialized
DEBUG - 2024-03-18 06:31:42 --> UTF-8 Support Enabled
INFO - 2024-03-18 06:31:42 --> Utf8 Class Initialized
INFO - 2024-03-18 06:31:42 --> URI Class Initialized
INFO - 2024-03-18 06:31:42 --> Router Class Initialized
INFO - 2024-03-18 06:31:42 --> Output Class Initialized
INFO - 2024-03-18 06:31:42 --> Security Class Initialized
DEBUG - 2024-03-18 06:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 06:31:42 --> Input Class Initialized
INFO - 2024-03-18 06:31:42 --> Language Class Initialized
INFO - 2024-03-18 06:31:42 --> Loader Class Initialized
INFO - 2024-03-18 06:31:42 --> Helper loaded: url_helper
INFO - 2024-03-18 06:31:42 --> Helper loaded: file_helper
INFO - 2024-03-18 06:31:42 --> Helper loaded: html_helper
INFO - 2024-03-18 06:31:42 --> Helper loaded: text_helper
INFO - 2024-03-18 06:31:42 --> Helper loaded: form_helper
INFO - 2024-03-18 06:31:42 --> Helper loaded: lang_helper
INFO - 2024-03-18 06:31:42 --> Helper loaded: security_helper
INFO - 2024-03-18 06:31:42 --> Helper loaded: cookie_helper
INFO - 2024-03-18 06:31:42 --> Database Driver Class Initialized
INFO - 2024-03-18 06:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 06:31:42 --> Parser Class Initialized
INFO - 2024-03-18 06:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 06:31:42 --> Pagination Class Initialized
INFO - 2024-03-18 06:31:42 --> Form Validation Class Initialized
INFO - 2024-03-18 06:31:42 --> Controller Class Initialized
INFO - 2024-03-18 06:31:42 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 06:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:42 --> Model Class Initialized
DEBUG - 2024-03-18 06:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 06:31:42 --> Model Class Initialized
INFO - 2024-03-18 06:31:42 --> Final output sent to browser
DEBUG - 2024-03-18 06:31:42 --> Total execution time: 0.0632
ERROR - 2024-03-18 07:11:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 07:11:54 --> Config Class Initialized
INFO - 2024-03-18 07:11:54 --> Hooks Class Initialized
DEBUG - 2024-03-18 07:11:54 --> UTF-8 Support Enabled
INFO - 2024-03-18 07:11:54 --> Utf8 Class Initialized
INFO - 2024-03-18 07:11:54 --> URI Class Initialized
DEBUG - 2024-03-18 07:11:54 --> No URI present. Default controller set.
INFO - 2024-03-18 07:11:54 --> Router Class Initialized
INFO - 2024-03-18 07:11:54 --> Output Class Initialized
INFO - 2024-03-18 07:11:54 --> Security Class Initialized
DEBUG - 2024-03-18 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 07:11:54 --> Input Class Initialized
INFO - 2024-03-18 07:11:54 --> Language Class Initialized
INFO - 2024-03-18 07:11:54 --> Loader Class Initialized
INFO - 2024-03-18 07:11:54 --> Helper loaded: url_helper
INFO - 2024-03-18 07:11:54 --> Helper loaded: file_helper
INFO - 2024-03-18 07:11:54 --> Helper loaded: html_helper
INFO - 2024-03-18 07:11:54 --> Helper loaded: text_helper
INFO - 2024-03-18 07:11:54 --> Helper loaded: form_helper
INFO - 2024-03-18 07:11:54 --> Helper loaded: lang_helper
INFO - 2024-03-18 07:11:54 --> Helper loaded: security_helper
INFO - 2024-03-18 07:11:54 --> Helper loaded: cookie_helper
INFO - 2024-03-18 07:11:54 --> Database Driver Class Initialized
INFO - 2024-03-18 07:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 07:11:54 --> Parser Class Initialized
INFO - 2024-03-18 07:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 07:11:54 --> Pagination Class Initialized
INFO - 2024-03-18 07:11:54 --> Form Validation Class Initialized
INFO - 2024-03-18 07:11:54 --> Controller Class Initialized
INFO - 2024-03-18 07:11:54 --> Model Class Initialized
DEBUG - 2024-03-18 07:11:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-18 13:48:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 13:48:02 --> Config Class Initialized
INFO - 2024-03-18 13:48:02 --> Hooks Class Initialized
DEBUG - 2024-03-18 13:48:02 --> UTF-8 Support Enabled
INFO - 2024-03-18 13:48:02 --> Utf8 Class Initialized
INFO - 2024-03-18 13:48:02 --> URI Class Initialized
DEBUG - 2024-03-18 13:48:02 --> No URI present. Default controller set.
INFO - 2024-03-18 13:48:02 --> Router Class Initialized
INFO - 2024-03-18 13:48:02 --> Output Class Initialized
INFO - 2024-03-18 13:48:02 --> Security Class Initialized
DEBUG - 2024-03-18 13:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 13:48:02 --> Input Class Initialized
INFO - 2024-03-18 13:48:02 --> Language Class Initialized
INFO - 2024-03-18 13:48:02 --> Loader Class Initialized
INFO - 2024-03-18 13:48:02 --> Helper loaded: url_helper
INFO - 2024-03-18 13:48:02 --> Helper loaded: file_helper
INFO - 2024-03-18 13:48:02 --> Helper loaded: html_helper
INFO - 2024-03-18 13:48:02 --> Helper loaded: text_helper
INFO - 2024-03-18 13:48:02 --> Helper loaded: form_helper
INFO - 2024-03-18 13:48:02 --> Helper loaded: lang_helper
INFO - 2024-03-18 13:48:02 --> Helper loaded: security_helper
INFO - 2024-03-18 13:48:02 --> Helper loaded: cookie_helper
INFO - 2024-03-18 13:48:02 --> Database Driver Class Initialized
INFO - 2024-03-18 13:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 13:48:02 --> Parser Class Initialized
INFO - 2024-03-18 13:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 13:48:02 --> Pagination Class Initialized
INFO - 2024-03-18 13:48:02 --> Form Validation Class Initialized
INFO - 2024-03-18 13:48:02 --> Controller Class Initialized
INFO - 2024-03-18 13:48:02 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-18 13:48:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 13:48:03 --> Config Class Initialized
INFO - 2024-03-18 13:48:03 --> Hooks Class Initialized
DEBUG - 2024-03-18 13:48:03 --> UTF-8 Support Enabled
INFO - 2024-03-18 13:48:03 --> Utf8 Class Initialized
INFO - 2024-03-18 13:48:03 --> URI Class Initialized
INFO - 2024-03-18 13:48:03 --> Router Class Initialized
INFO - 2024-03-18 13:48:03 --> Output Class Initialized
INFO - 2024-03-18 13:48:03 --> Security Class Initialized
DEBUG - 2024-03-18 13:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 13:48:03 --> Input Class Initialized
INFO - 2024-03-18 13:48:03 --> Language Class Initialized
INFO - 2024-03-18 13:48:03 --> Loader Class Initialized
INFO - 2024-03-18 13:48:03 --> Helper loaded: url_helper
INFO - 2024-03-18 13:48:03 --> Helper loaded: file_helper
INFO - 2024-03-18 13:48:03 --> Helper loaded: html_helper
INFO - 2024-03-18 13:48:03 --> Helper loaded: text_helper
INFO - 2024-03-18 13:48:03 --> Helper loaded: form_helper
INFO - 2024-03-18 13:48:03 --> Helper loaded: lang_helper
INFO - 2024-03-18 13:48:03 --> Helper loaded: security_helper
INFO - 2024-03-18 13:48:03 --> Helper loaded: cookie_helper
INFO - 2024-03-18 13:48:03 --> Database Driver Class Initialized
INFO - 2024-03-18 13:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 13:48:03 --> Parser Class Initialized
INFO - 2024-03-18 13:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 13:48:03 --> Pagination Class Initialized
INFO - 2024-03-18 13:48:03 --> Form Validation Class Initialized
INFO - 2024-03-18 13:48:03 --> Controller Class Initialized
INFO - 2024-03-18 13:48:03 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-18 13:48:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 13:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 13:48:03 --> Model Class Initialized
INFO - 2024-03-18 13:48:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 13:48:03 --> Final output sent to browser
DEBUG - 2024-03-18 13:48:03 --> Total execution time: 0.0384
ERROR - 2024-03-18 13:48:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 13:48:15 --> Config Class Initialized
INFO - 2024-03-18 13:48:15 --> Hooks Class Initialized
DEBUG - 2024-03-18 13:48:15 --> UTF-8 Support Enabled
INFO - 2024-03-18 13:48:15 --> Utf8 Class Initialized
INFO - 2024-03-18 13:48:15 --> URI Class Initialized
INFO - 2024-03-18 13:48:15 --> Router Class Initialized
INFO - 2024-03-18 13:48:15 --> Output Class Initialized
INFO - 2024-03-18 13:48:15 --> Security Class Initialized
DEBUG - 2024-03-18 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 13:48:15 --> Input Class Initialized
INFO - 2024-03-18 13:48:15 --> Language Class Initialized
INFO - 2024-03-18 13:48:15 --> Loader Class Initialized
INFO - 2024-03-18 13:48:15 --> Helper loaded: url_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: file_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: html_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: text_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: form_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: lang_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: security_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: cookie_helper
INFO - 2024-03-18 13:48:15 --> Database Driver Class Initialized
INFO - 2024-03-18 13:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 13:48:15 --> Parser Class Initialized
INFO - 2024-03-18 13:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 13:48:15 --> Pagination Class Initialized
INFO - 2024-03-18 13:48:15 --> Form Validation Class Initialized
INFO - 2024-03-18 13:48:15 --> Controller Class Initialized
INFO - 2024-03-18 13:48:15 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:15 --> Model Class Initialized
INFO - 2024-03-18 13:48:15 --> Final output sent to browser
DEBUG - 2024-03-18 13:48:15 --> Total execution time: 0.0213
ERROR - 2024-03-18 13:48:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 13:48:15 --> Config Class Initialized
INFO - 2024-03-18 13:48:15 --> Hooks Class Initialized
DEBUG - 2024-03-18 13:48:15 --> UTF-8 Support Enabled
INFO - 2024-03-18 13:48:15 --> Utf8 Class Initialized
INFO - 2024-03-18 13:48:15 --> URI Class Initialized
DEBUG - 2024-03-18 13:48:15 --> No URI present. Default controller set.
INFO - 2024-03-18 13:48:15 --> Router Class Initialized
INFO - 2024-03-18 13:48:15 --> Output Class Initialized
INFO - 2024-03-18 13:48:15 --> Security Class Initialized
DEBUG - 2024-03-18 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 13:48:15 --> Input Class Initialized
INFO - 2024-03-18 13:48:15 --> Language Class Initialized
INFO - 2024-03-18 13:48:15 --> Loader Class Initialized
INFO - 2024-03-18 13:48:15 --> Helper loaded: url_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: file_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: html_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: text_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: form_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: lang_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: security_helper
INFO - 2024-03-18 13:48:15 --> Helper loaded: cookie_helper
INFO - 2024-03-18 13:48:15 --> Database Driver Class Initialized
INFO - 2024-03-18 13:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 13:48:15 --> Parser Class Initialized
INFO - 2024-03-18 13:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 13:48:15 --> Pagination Class Initialized
INFO - 2024-03-18 13:48:15 --> Form Validation Class Initialized
INFO - 2024-03-18 13:48:15 --> Controller Class Initialized
INFO - 2024-03-18 13:48:15 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:15 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:15 --> Model Class Initialized
INFO - 2024-03-18 13:48:15 --> Model Class Initialized
INFO - 2024-03-18 13:48:15 --> Model Class Initialized
INFO - 2024-03-18 13:48:16 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 13:48:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:16 --> Model Class Initialized
INFO - 2024-03-18 13:48:16 --> Model Class Initialized
INFO - 2024-03-18 13:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-18 13:48:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 13:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 13:48:16 --> Model Class Initialized
INFO - 2024-03-18 13:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-18 13:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-18 13:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 13:48:16 --> Final output sent to browser
DEBUG - 2024-03-18 13:48:16 --> Total execution time: 0.4699
ERROR - 2024-03-18 13:48:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 13:48:17 --> Config Class Initialized
INFO - 2024-03-18 13:48:17 --> Hooks Class Initialized
DEBUG - 2024-03-18 13:48:17 --> UTF-8 Support Enabled
INFO - 2024-03-18 13:48:17 --> Utf8 Class Initialized
INFO - 2024-03-18 13:48:17 --> URI Class Initialized
INFO - 2024-03-18 13:48:17 --> Router Class Initialized
INFO - 2024-03-18 13:48:17 --> Output Class Initialized
INFO - 2024-03-18 13:48:17 --> Security Class Initialized
DEBUG - 2024-03-18 13:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 13:48:17 --> Input Class Initialized
INFO - 2024-03-18 13:48:17 --> Language Class Initialized
INFO - 2024-03-18 13:48:17 --> Loader Class Initialized
INFO - 2024-03-18 13:48:17 --> Helper loaded: url_helper
INFO - 2024-03-18 13:48:17 --> Helper loaded: file_helper
INFO - 2024-03-18 13:48:17 --> Helper loaded: html_helper
INFO - 2024-03-18 13:48:17 --> Helper loaded: text_helper
INFO - 2024-03-18 13:48:17 --> Helper loaded: form_helper
INFO - 2024-03-18 13:48:17 --> Helper loaded: lang_helper
INFO - 2024-03-18 13:48:17 --> Helper loaded: security_helper
INFO - 2024-03-18 13:48:17 --> Helper loaded: cookie_helper
INFO - 2024-03-18 13:48:17 --> Database Driver Class Initialized
INFO - 2024-03-18 13:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 13:48:17 --> Parser Class Initialized
INFO - 2024-03-18 13:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 13:48:17 --> Pagination Class Initialized
INFO - 2024-03-18 13:48:17 --> Form Validation Class Initialized
INFO - 2024-03-18 13:48:17 --> Controller Class Initialized
DEBUG - 2024-03-18 13:48:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 13:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:17 --> Model Class Initialized
INFO - 2024-03-18 13:48:17 --> Final output sent to browser
DEBUG - 2024-03-18 13:48:17 --> Total execution time: 0.0137
ERROR - 2024-03-18 13:48:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 13:48:25 --> Config Class Initialized
INFO - 2024-03-18 13:48:25 --> Hooks Class Initialized
DEBUG - 2024-03-18 13:48:25 --> UTF-8 Support Enabled
INFO - 2024-03-18 13:48:25 --> Utf8 Class Initialized
INFO - 2024-03-18 13:48:25 --> URI Class Initialized
INFO - 2024-03-18 13:48:25 --> Router Class Initialized
INFO - 2024-03-18 13:48:25 --> Output Class Initialized
INFO - 2024-03-18 13:48:25 --> Security Class Initialized
DEBUG - 2024-03-18 13:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 13:48:25 --> Input Class Initialized
INFO - 2024-03-18 13:48:25 --> Language Class Initialized
INFO - 2024-03-18 13:48:25 --> Loader Class Initialized
INFO - 2024-03-18 13:48:25 --> Helper loaded: url_helper
INFO - 2024-03-18 13:48:25 --> Helper loaded: file_helper
INFO - 2024-03-18 13:48:25 --> Helper loaded: html_helper
INFO - 2024-03-18 13:48:25 --> Helper loaded: text_helper
INFO - 2024-03-18 13:48:25 --> Helper loaded: form_helper
INFO - 2024-03-18 13:48:25 --> Helper loaded: lang_helper
INFO - 2024-03-18 13:48:25 --> Helper loaded: security_helper
INFO - 2024-03-18 13:48:25 --> Helper loaded: cookie_helper
INFO - 2024-03-18 13:48:25 --> Database Driver Class Initialized
INFO - 2024-03-18 13:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 13:48:25 --> Parser Class Initialized
INFO - 2024-03-18 13:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 13:48:25 --> Pagination Class Initialized
INFO - 2024-03-18 13:48:25 --> Form Validation Class Initialized
INFO - 2024-03-18 13:48:25 --> Controller Class Initialized
INFO - 2024-03-18 13:48:25 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 13:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:25 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:25 --> Model Class Initialized
INFO - 2024-03-18 13:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-18 13:48:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-18 13:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-18 13:48:25 --> Model Class Initialized
INFO - 2024-03-18 13:48:25 --> Model Class Initialized
INFO - 2024-03-18 13:48:25 --> Model Class Initialized
INFO - 2024-03-18 13:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-18 13:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-18 13:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-18 13:48:25 --> Final output sent to browser
DEBUG - 2024-03-18 13:48:25 --> Total execution time: 0.2458
ERROR - 2024-03-18 13:48:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 13:48:26 --> Config Class Initialized
INFO - 2024-03-18 13:48:26 --> Hooks Class Initialized
DEBUG - 2024-03-18 13:48:26 --> UTF-8 Support Enabled
INFO - 2024-03-18 13:48:26 --> Utf8 Class Initialized
INFO - 2024-03-18 13:48:26 --> URI Class Initialized
INFO - 2024-03-18 13:48:26 --> Router Class Initialized
INFO - 2024-03-18 13:48:26 --> Output Class Initialized
INFO - 2024-03-18 13:48:26 --> Security Class Initialized
DEBUG - 2024-03-18 13:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 13:48:26 --> Input Class Initialized
INFO - 2024-03-18 13:48:26 --> Language Class Initialized
INFO - 2024-03-18 13:48:26 --> Loader Class Initialized
INFO - 2024-03-18 13:48:26 --> Helper loaded: url_helper
INFO - 2024-03-18 13:48:26 --> Helper loaded: file_helper
INFO - 2024-03-18 13:48:26 --> Helper loaded: html_helper
INFO - 2024-03-18 13:48:26 --> Helper loaded: text_helper
INFO - 2024-03-18 13:48:26 --> Helper loaded: form_helper
INFO - 2024-03-18 13:48:26 --> Helper loaded: lang_helper
INFO - 2024-03-18 13:48:26 --> Helper loaded: security_helper
INFO - 2024-03-18 13:48:26 --> Helper loaded: cookie_helper
INFO - 2024-03-18 13:48:26 --> Database Driver Class Initialized
INFO - 2024-03-18 13:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-18 13:48:26 --> Parser Class Initialized
INFO - 2024-03-18 13:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-18 13:48:26 --> Pagination Class Initialized
INFO - 2024-03-18 13:48:26 --> Form Validation Class Initialized
INFO - 2024-03-18 13:48:26 --> Controller Class Initialized
INFO - 2024-03-18 13:48:26 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-18 13:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:26 --> Model Class Initialized
DEBUG - 2024-03-18 13:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-18 13:48:26 --> Model Class Initialized
INFO - 2024-03-18 13:48:26 --> Final output sent to browser
DEBUG - 2024-03-18 13:48:26 --> Total execution time: 0.0646
ERROR - 2024-03-18 20:23:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 20:23:02 --> Config Class Initialized
INFO - 2024-03-18 20:23:02 --> Hooks Class Initialized
DEBUG - 2024-03-18 20:23:02 --> UTF-8 Support Enabled
INFO - 2024-03-18 20:23:02 --> Utf8 Class Initialized
INFO - 2024-03-18 20:23:02 --> URI Class Initialized
INFO - 2024-03-18 20:23:02 --> Router Class Initialized
INFO - 2024-03-18 20:23:02 --> Output Class Initialized
INFO - 2024-03-18 20:23:02 --> Security Class Initialized
DEBUG - 2024-03-18 20:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 20:23:02 --> Input Class Initialized
INFO - 2024-03-18 20:23:02 --> Language Class Initialized
ERROR - 2024-03-18 20:23:02 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-18 22:41:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-18 22:41:20 --> Config Class Initialized
INFO - 2024-03-18 22:41:20 --> Hooks Class Initialized
DEBUG - 2024-03-18 22:41:20 --> UTF-8 Support Enabled
INFO - 2024-03-18 22:41:20 --> Utf8 Class Initialized
INFO - 2024-03-18 22:41:20 --> URI Class Initialized
INFO - 2024-03-18 22:41:20 --> Router Class Initialized
INFO - 2024-03-18 22:41:20 --> Output Class Initialized
INFO - 2024-03-18 22:41:20 --> Security Class Initialized
DEBUG - 2024-03-18 22:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-18 22:41:20 --> Input Class Initialized
INFO - 2024-03-18 22:41:20 --> Language Class Initialized
ERROR - 2024-03-18 22:41:20 --> 404 Page Not Found: Well-known/assetlinks.json
