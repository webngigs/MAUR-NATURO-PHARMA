<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-26 02:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:14 --> Config Class Initialized
INFO - 2023-07-26 02:57:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:14 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:14 --> URI Class Initialized
DEBUG - 2023-07-26 02:57:14 --> No URI present. Default controller set.
INFO - 2023-07-26 02:57:14 --> Router Class Initialized
INFO - 2023-07-26 02:57:14 --> Output Class Initialized
INFO - 2023-07-26 02:57:14 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:14 --> Input Class Initialized
INFO - 2023-07-26 02:57:14 --> Language Class Initialized
INFO - 2023-07-26 02:57:14 --> Loader Class Initialized
INFO - 2023-07-26 02:57:14 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:14 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:14 --> Parser Class Initialized
INFO - 2023-07-26 02:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:14 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:14 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:14 --> Controller Class Initialized
INFO - 2023-07-26 02:57:14 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 02:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:14 --> Config Class Initialized
INFO - 2023-07-26 02:57:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:14 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:14 --> URI Class Initialized
INFO - 2023-07-26 02:57:14 --> Router Class Initialized
INFO - 2023-07-26 02:57:14 --> Output Class Initialized
INFO - 2023-07-26 02:57:14 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:14 --> Input Class Initialized
INFO - 2023-07-26 02:57:14 --> Language Class Initialized
INFO - 2023-07-26 02:57:14 --> Loader Class Initialized
INFO - 2023-07-26 02:57:14 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:14 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:14 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:14 --> Parser Class Initialized
INFO - 2023-07-26 02:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:14 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:14 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:14 --> Controller Class Initialized
INFO - 2023-07-26 02:57:14 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 02:57:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 02:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 02:57:14 --> Model Class Initialized
INFO - 2023-07-26 02:57:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 02:57:14 --> Final output sent to browser
DEBUG - 2023-07-26 02:57:14 --> Total execution time: 0.0325
ERROR - 2023-07-26 02:57:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:17 --> Config Class Initialized
INFO - 2023-07-26 02:57:17 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:17 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:17 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:17 --> URI Class Initialized
INFO - 2023-07-26 02:57:17 --> Router Class Initialized
INFO - 2023-07-26 02:57:17 --> Output Class Initialized
INFO - 2023-07-26 02:57:17 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:17 --> Input Class Initialized
INFO - 2023-07-26 02:57:17 --> Language Class Initialized
INFO - 2023-07-26 02:57:17 --> Loader Class Initialized
INFO - 2023-07-26 02:57:17 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:17 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:17 --> Parser Class Initialized
INFO - 2023-07-26 02:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:17 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:17 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:17 --> Controller Class Initialized
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
INFO - 2023-07-26 02:57:17 --> Final output sent to browser
DEBUG - 2023-07-26 02:57:17 --> Total execution time: 0.0189
ERROR - 2023-07-26 02:57:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:17 --> Config Class Initialized
INFO - 2023-07-26 02:57:17 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:17 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:17 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:17 --> URI Class Initialized
DEBUG - 2023-07-26 02:57:17 --> No URI present. Default controller set.
INFO - 2023-07-26 02:57:17 --> Router Class Initialized
INFO - 2023-07-26 02:57:17 --> Output Class Initialized
INFO - 2023-07-26 02:57:17 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:17 --> Input Class Initialized
INFO - 2023-07-26 02:57:17 --> Language Class Initialized
INFO - 2023-07-26 02:57:17 --> Loader Class Initialized
INFO - 2023-07-26 02:57:17 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:17 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:17 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:17 --> Parser Class Initialized
INFO - 2023-07-26 02:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:17 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:17 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:17 --> Controller Class Initialized
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 02:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
INFO - 2023-07-26 02:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 02:57:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 02:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 02:57:17 --> Model Class Initialized
INFO - 2023-07-26 02:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 02:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 02:57:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 02:57:17 --> Final output sent to browser
DEBUG - 2023-07-26 02:57:17 --> Total execution time: 0.1638
ERROR - 2023-07-26 02:57:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:18 --> Config Class Initialized
INFO - 2023-07-26 02:57:18 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:18 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:18 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:18 --> URI Class Initialized
INFO - 2023-07-26 02:57:18 --> Router Class Initialized
INFO - 2023-07-26 02:57:18 --> Output Class Initialized
INFO - 2023-07-26 02:57:18 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:18 --> Input Class Initialized
INFO - 2023-07-26 02:57:18 --> Language Class Initialized
INFO - 2023-07-26 02:57:18 --> Loader Class Initialized
INFO - 2023-07-26 02:57:18 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:18 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:18 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:18 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:18 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:18 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:18 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:18 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:18 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:18 --> Parser Class Initialized
INFO - 2023-07-26 02:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:18 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:18 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:18 --> Controller Class Initialized
DEBUG - 2023-07-26 02:57:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 02:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:18 --> Model Class Initialized
INFO - 2023-07-26 02:57:18 --> Final output sent to browser
DEBUG - 2023-07-26 02:57:18 --> Total execution time: 0.0129
ERROR - 2023-07-26 02:57:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:32 --> Config Class Initialized
INFO - 2023-07-26 02:57:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:32 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:32 --> URI Class Initialized
INFO - 2023-07-26 02:57:32 --> Router Class Initialized
INFO - 2023-07-26 02:57:32 --> Output Class Initialized
INFO - 2023-07-26 02:57:32 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:32 --> Input Class Initialized
INFO - 2023-07-26 02:57:32 --> Language Class Initialized
INFO - 2023-07-26 02:57:32 --> Loader Class Initialized
INFO - 2023-07-26 02:57:32 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:32 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:32 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:32 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:32 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:32 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:32 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:32 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:32 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:32 --> Parser Class Initialized
INFO - 2023-07-26 02:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:32 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:32 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:32 --> Controller Class Initialized
INFO - 2023-07-26 02:57:32 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 02:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:32 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:32 --> Model Class Initialized
INFO - 2023-07-26 02:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-26 02:57:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 02:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 02:57:32 --> Model Class Initialized
INFO - 2023-07-26 02:57:32 --> Model Class Initialized
INFO - 2023-07-26 02:57:32 --> Model Class Initialized
INFO - 2023-07-26 02:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 02:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 02:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 02:57:32 --> Final output sent to browser
DEBUG - 2023-07-26 02:57:32 --> Total execution time: 0.1331
ERROR - 2023-07-26 02:57:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:33 --> Config Class Initialized
INFO - 2023-07-26 02:57:33 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:33 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:33 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:33 --> URI Class Initialized
INFO - 2023-07-26 02:57:33 --> Router Class Initialized
INFO - 2023-07-26 02:57:33 --> Output Class Initialized
INFO - 2023-07-26 02:57:33 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:33 --> Input Class Initialized
INFO - 2023-07-26 02:57:33 --> Language Class Initialized
INFO - 2023-07-26 02:57:33 --> Loader Class Initialized
INFO - 2023-07-26 02:57:33 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:33 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:33 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:33 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:33 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:33 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:33 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:33 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:33 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:33 --> Parser Class Initialized
INFO - 2023-07-26 02:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:33 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:33 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:33 --> Controller Class Initialized
INFO - 2023-07-26 02:57:33 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 02:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:33 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:33 --> Model Class Initialized
INFO - 2023-07-26 02:57:33 --> Final output sent to browser
DEBUG - 2023-07-26 02:57:33 --> Total execution time: 0.0477
ERROR - 2023-07-26 02:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 02:57:36 --> Config Class Initialized
INFO - 2023-07-26 02:57:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 02:57:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 02:57:36 --> Utf8 Class Initialized
INFO - 2023-07-26 02:57:36 --> URI Class Initialized
INFO - 2023-07-26 02:57:36 --> Router Class Initialized
INFO - 2023-07-26 02:57:36 --> Output Class Initialized
INFO - 2023-07-26 02:57:36 --> Security Class Initialized
DEBUG - 2023-07-26 02:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 02:57:36 --> Input Class Initialized
INFO - 2023-07-26 02:57:36 --> Language Class Initialized
INFO - 2023-07-26 02:57:36 --> Loader Class Initialized
INFO - 2023-07-26 02:57:36 --> Helper loaded: url_helper
INFO - 2023-07-26 02:57:36 --> Helper loaded: file_helper
INFO - 2023-07-26 02:57:36 --> Helper loaded: html_helper
INFO - 2023-07-26 02:57:36 --> Helper loaded: text_helper
INFO - 2023-07-26 02:57:36 --> Helper loaded: form_helper
INFO - 2023-07-26 02:57:36 --> Helper loaded: lang_helper
INFO - 2023-07-26 02:57:36 --> Helper loaded: security_helper
INFO - 2023-07-26 02:57:36 --> Helper loaded: cookie_helper
INFO - 2023-07-26 02:57:36 --> Database Driver Class Initialized
INFO - 2023-07-26 02:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 02:57:36 --> Parser Class Initialized
INFO - 2023-07-26 02:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 02:57:36 --> Pagination Class Initialized
INFO - 2023-07-26 02:57:36 --> Form Validation Class Initialized
INFO - 2023-07-26 02:57:36 --> Controller Class Initialized
INFO - 2023-07-26 02:57:36 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 02:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:36 --> Model Class Initialized
DEBUG - 2023-07-26 02:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:36 --> Model Class Initialized
INFO - 2023-07-26 02:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-26 02:57:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 02:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 02:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 02:57:36 --> Model Class Initialized
INFO - 2023-07-26 02:57:36 --> Model Class Initialized
INFO - 2023-07-26 02:57:36 --> Model Class Initialized
INFO - 2023-07-26 02:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 02:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 02:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 02:57:36 --> Final output sent to browser
DEBUG - 2023-07-26 02:57:36 --> Total execution time: 0.1390
ERROR - 2023-07-26 04:02:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:02:02 --> Config Class Initialized
INFO - 2023-07-26 04:02:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:02:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:02:02 --> Utf8 Class Initialized
INFO - 2023-07-26 04:02:02 --> URI Class Initialized
DEBUG - 2023-07-26 04:02:02 --> No URI present. Default controller set.
INFO - 2023-07-26 04:02:02 --> Router Class Initialized
INFO - 2023-07-26 04:02:02 --> Output Class Initialized
INFO - 2023-07-26 04:02:02 --> Security Class Initialized
DEBUG - 2023-07-26 04:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:02:02 --> Input Class Initialized
INFO - 2023-07-26 04:02:02 --> Language Class Initialized
INFO - 2023-07-26 04:02:02 --> Loader Class Initialized
INFO - 2023-07-26 04:02:02 --> Helper loaded: url_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: file_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: html_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: text_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: form_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: security_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:02:02 --> Database Driver Class Initialized
INFO - 2023-07-26 04:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:02:02 --> Parser Class Initialized
INFO - 2023-07-26 04:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:02:02 --> Pagination Class Initialized
INFO - 2023-07-26 04:02:02 --> Form Validation Class Initialized
INFO - 2023-07-26 04:02:02 --> Controller Class Initialized
INFO - 2023-07-26 04:02:02 --> Model Class Initialized
DEBUG - 2023-07-26 04:02:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 04:02:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:02:02 --> Config Class Initialized
INFO - 2023-07-26 04:02:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:02:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:02:02 --> Utf8 Class Initialized
INFO - 2023-07-26 04:02:02 --> URI Class Initialized
INFO - 2023-07-26 04:02:02 --> Router Class Initialized
INFO - 2023-07-26 04:02:02 --> Output Class Initialized
INFO - 2023-07-26 04:02:02 --> Security Class Initialized
DEBUG - 2023-07-26 04:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:02:02 --> Input Class Initialized
INFO - 2023-07-26 04:02:02 --> Language Class Initialized
INFO - 2023-07-26 04:02:02 --> Loader Class Initialized
INFO - 2023-07-26 04:02:02 --> Helper loaded: url_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: file_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: html_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: text_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: form_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: security_helper
INFO - 2023-07-26 04:02:02 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:02:02 --> Database Driver Class Initialized
INFO - 2023-07-26 04:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:02:02 --> Parser Class Initialized
INFO - 2023-07-26 04:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:02:02 --> Pagination Class Initialized
INFO - 2023-07-26 04:02:02 --> Form Validation Class Initialized
INFO - 2023-07-26 04:02:02 --> Controller Class Initialized
INFO - 2023-07-26 04:02:02 --> Model Class Initialized
DEBUG - 2023-07-26 04:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:02:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 04:02:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:02:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 04:02:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 04:02:03 --> Model Class Initialized
INFO - 2023-07-26 04:02:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 04:02:03 --> Final output sent to browser
DEBUG - 2023-07-26 04:02:03 --> Total execution time: 0.0303
ERROR - 2023-07-26 04:04:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:04:37 --> Config Class Initialized
INFO - 2023-07-26 04:04:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:04:37 --> Utf8 Class Initialized
INFO - 2023-07-26 04:04:37 --> URI Class Initialized
INFO - 2023-07-26 04:04:37 --> Router Class Initialized
INFO - 2023-07-26 04:04:37 --> Output Class Initialized
INFO - 2023-07-26 04:04:37 --> Security Class Initialized
DEBUG - 2023-07-26 04:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:04:37 --> Input Class Initialized
INFO - 2023-07-26 04:04:37 --> Language Class Initialized
INFO - 2023-07-26 04:04:37 --> Loader Class Initialized
INFO - 2023-07-26 04:04:37 --> Helper loaded: url_helper
INFO - 2023-07-26 04:04:37 --> Helper loaded: file_helper
INFO - 2023-07-26 04:04:37 --> Helper loaded: html_helper
INFO - 2023-07-26 04:04:37 --> Helper loaded: text_helper
INFO - 2023-07-26 04:04:37 --> Helper loaded: form_helper
INFO - 2023-07-26 04:04:37 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:04:37 --> Helper loaded: security_helper
INFO - 2023-07-26 04:04:37 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:04:37 --> Database Driver Class Initialized
INFO - 2023-07-26 04:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:04:37 --> Parser Class Initialized
INFO - 2023-07-26 04:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:04:37 --> Pagination Class Initialized
INFO - 2023-07-26 04:04:37 --> Form Validation Class Initialized
INFO - 2023-07-26 04:04:37 --> Controller Class Initialized
INFO - 2023-07-26 04:04:37 --> Model Class Initialized
DEBUG - 2023-07-26 04:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:04:37 --> Model Class Initialized
INFO - 2023-07-26 04:04:37 --> Final output sent to browser
DEBUG - 2023-07-26 04:04:37 --> Total execution time: 0.0222
ERROR - 2023-07-26 04:04:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:04:38 --> Config Class Initialized
INFO - 2023-07-26 04:04:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:04:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:04:38 --> Utf8 Class Initialized
INFO - 2023-07-26 04:04:38 --> URI Class Initialized
DEBUG - 2023-07-26 04:04:38 --> No URI present. Default controller set.
INFO - 2023-07-26 04:04:38 --> Router Class Initialized
INFO - 2023-07-26 04:04:38 --> Output Class Initialized
INFO - 2023-07-26 04:04:38 --> Security Class Initialized
DEBUG - 2023-07-26 04:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:04:38 --> Input Class Initialized
INFO - 2023-07-26 04:04:38 --> Language Class Initialized
INFO - 2023-07-26 04:04:38 --> Loader Class Initialized
INFO - 2023-07-26 04:04:38 --> Helper loaded: url_helper
INFO - 2023-07-26 04:04:38 --> Helper loaded: file_helper
INFO - 2023-07-26 04:04:38 --> Helper loaded: html_helper
INFO - 2023-07-26 04:04:38 --> Helper loaded: text_helper
INFO - 2023-07-26 04:04:38 --> Helper loaded: form_helper
INFO - 2023-07-26 04:04:38 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:04:38 --> Helper loaded: security_helper
INFO - 2023-07-26 04:04:38 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:04:38 --> Database Driver Class Initialized
INFO - 2023-07-26 04:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:04:38 --> Parser Class Initialized
INFO - 2023-07-26 04:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:04:38 --> Pagination Class Initialized
INFO - 2023-07-26 04:04:38 --> Form Validation Class Initialized
INFO - 2023-07-26 04:04:38 --> Controller Class Initialized
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
DEBUG - 2023-07-26 04:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
DEBUG - 2023-07-26 04:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
DEBUG - 2023-07-26 04:04:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
INFO - 2023-07-26 04:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 04:04:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 04:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 04:04:38 --> Model Class Initialized
INFO - 2023-07-26 04:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 04:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 04:04:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 04:04:38 --> Final output sent to browser
DEBUG - 2023-07-26 04:04:38 --> Total execution time: 0.0914
ERROR - 2023-07-26 04:24:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:24:04 --> Config Class Initialized
INFO - 2023-07-26 04:24:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:24:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:24:04 --> Utf8 Class Initialized
INFO - 2023-07-26 04:24:04 --> URI Class Initialized
INFO - 2023-07-26 04:24:04 --> Router Class Initialized
INFO - 2023-07-26 04:24:04 --> Output Class Initialized
INFO - 2023-07-26 04:24:04 --> Security Class Initialized
DEBUG - 2023-07-26 04:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:24:04 --> Input Class Initialized
INFO - 2023-07-26 04:24:04 --> Language Class Initialized
INFO - 2023-07-26 04:24:04 --> Loader Class Initialized
INFO - 2023-07-26 04:24:04 --> Helper loaded: url_helper
INFO - 2023-07-26 04:24:04 --> Helper loaded: file_helper
INFO - 2023-07-26 04:24:04 --> Helper loaded: html_helper
INFO - 2023-07-26 04:24:04 --> Helper loaded: text_helper
INFO - 2023-07-26 04:24:04 --> Helper loaded: form_helper
INFO - 2023-07-26 04:24:04 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:24:04 --> Helper loaded: security_helper
INFO - 2023-07-26 04:24:04 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:24:04 --> Database Driver Class Initialized
INFO - 2023-07-26 04:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:24:04 --> Parser Class Initialized
INFO - 2023-07-26 04:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:24:04 --> Pagination Class Initialized
INFO - 2023-07-26 04:24:04 --> Form Validation Class Initialized
INFO - 2023-07-26 04:24:04 --> Controller Class Initialized
INFO - 2023-07-26 04:24:04 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:04 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:04 --> Model Class Initialized
INFO - 2023-07-26 04:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-26 04:24:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 04:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 04:24:04 --> Model Class Initialized
INFO - 2023-07-26 04:24:04 --> Model Class Initialized
INFO - 2023-07-26 04:24:04 --> Model Class Initialized
INFO - 2023-07-26 04:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 04:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 04:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 04:24:04 --> Final output sent to browser
DEBUG - 2023-07-26 04:24:04 --> Total execution time: 0.0840
ERROR - 2023-07-26 04:24:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:24:11 --> Config Class Initialized
INFO - 2023-07-26 04:24:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:24:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:24:11 --> Utf8 Class Initialized
INFO - 2023-07-26 04:24:11 --> URI Class Initialized
INFO - 2023-07-26 04:24:11 --> Router Class Initialized
INFO - 2023-07-26 04:24:11 --> Output Class Initialized
INFO - 2023-07-26 04:24:11 --> Security Class Initialized
DEBUG - 2023-07-26 04:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:24:11 --> Input Class Initialized
INFO - 2023-07-26 04:24:11 --> Language Class Initialized
INFO - 2023-07-26 04:24:11 --> Loader Class Initialized
INFO - 2023-07-26 04:24:11 --> Helper loaded: url_helper
INFO - 2023-07-26 04:24:11 --> Helper loaded: file_helper
INFO - 2023-07-26 04:24:11 --> Helper loaded: html_helper
INFO - 2023-07-26 04:24:11 --> Helper loaded: text_helper
INFO - 2023-07-26 04:24:11 --> Helper loaded: form_helper
INFO - 2023-07-26 04:24:11 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:24:11 --> Helper loaded: security_helper
INFO - 2023-07-26 04:24:11 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:24:11 --> Database Driver Class Initialized
INFO - 2023-07-26 04:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:24:11 --> Parser Class Initialized
INFO - 2023-07-26 04:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:24:11 --> Pagination Class Initialized
INFO - 2023-07-26 04:24:11 --> Form Validation Class Initialized
INFO - 2023-07-26 04:24:11 --> Controller Class Initialized
INFO - 2023-07-26 04:24:11 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:11 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:11 --> Model Class Initialized
INFO - 2023-07-26 04:24:11 --> Final output sent to browser
DEBUG - 2023-07-26 04:24:11 --> Total execution time: 0.0393
ERROR - 2023-07-26 04:24:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:24:27 --> Config Class Initialized
INFO - 2023-07-26 04:24:27 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:24:27 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:24:27 --> Utf8 Class Initialized
INFO - 2023-07-26 04:24:27 --> URI Class Initialized
INFO - 2023-07-26 04:24:27 --> Router Class Initialized
INFO - 2023-07-26 04:24:27 --> Output Class Initialized
INFO - 2023-07-26 04:24:27 --> Security Class Initialized
DEBUG - 2023-07-26 04:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:24:27 --> Input Class Initialized
INFO - 2023-07-26 04:24:27 --> Language Class Initialized
INFO - 2023-07-26 04:24:27 --> Loader Class Initialized
INFO - 2023-07-26 04:24:27 --> Helper loaded: url_helper
INFO - 2023-07-26 04:24:27 --> Helper loaded: file_helper
INFO - 2023-07-26 04:24:27 --> Helper loaded: html_helper
INFO - 2023-07-26 04:24:27 --> Helper loaded: text_helper
INFO - 2023-07-26 04:24:27 --> Helper loaded: form_helper
INFO - 2023-07-26 04:24:27 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:24:27 --> Helper loaded: security_helper
INFO - 2023-07-26 04:24:27 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:24:27 --> Database Driver Class Initialized
INFO - 2023-07-26 04:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:24:27 --> Parser Class Initialized
INFO - 2023-07-26 04:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:24:27 --> Pagination Class Initialized
INFO - 2023-07-26 04:24:27 --> Form Validation Class Initialized
INFO - 2023-07-26 04:24:27 --> Controller Class Initialized
INFO - 2023-07-26 04:24:27 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:27 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:27 --> Model Class Initialized
INFO - 2023-07-26 04:24:27 --> Final output sent to browser
DEBUG - 2023-07-26 04:24:27 --> Total execution time: 0.0456
ERROR - 2023-07-26 04:24:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:24:29 --> Config Class Initialized
INFO - 2023-07-26 04:24:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:24:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:24:29 --> Utf8 Class Initialized
INFO - 2023-07-26 04:24:29 --> URI Class Initialized
INFO - 2023-07-26 04:24:29 --> Router Class Initialized
INFO - 2023-07-26 04:24:29 --> Output Class Initialized
INFO - 2023-07-26 04:24:29 --> Security Class Initialized
DEBUG - 2023-07-26 04:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:24:29 --> Input Class Initialized
INFO - 2023-07-26 04:24:29 --> Language Class Initialized
INFO - 2023-07-26 04:24:29 --> Loader Class Initialized
INFO - 2023-07-26 04:24:29 --> Helper loaded: url_helper
INFO - 2023-07-26 04:24:29 --> Helper loaded: file_helper
INFO - 2023-07-26 04:24:29 --> Helper loaded: html_helper
INFO - 2023-07-26 04:24:29 --> Helper loaded: text_helper
INFO - 2023-07-26 04:24:29 --> Helper loaded: form_helper
INFO - 2023-07-26 04:24:29 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:24:29 --> Helper loaded: security_helper
INFO - 2023-07-26 04:24:29 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:24:29 --> Database Driver Class Initialized
INFO - 2023-07-26 04:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:24:29 --> Parser Class Initialized
INFO - 2023-07-26 04:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:24:29 --> Pagination Class Initialized
INFO - 2023-07-26 04:24:29 --> Form Validation Class Initialized
INFO - 2023-07-26 04:24:29 --> Controller Class Initialized
INFO - 2023-07-26 04:24:29 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:29 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:29 --> Model Class Initialized
INFO - 2023-07-26 04:24:29 --> Final output sent to browser
DEBUG - 2023-07-26 04:24:29 --> Total execution time: 0.0377
ERROR - 2023-07-26 04:24:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:24:41 --> Config Class Initialized
INFO - 2023-07-26 04:24:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:24:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:24:41 --> Utf8 Class Initialized
INFO - 2023-07-26 04:24:41 --> URI Class Initialized
INFO - 2023-07-26 04:24:41 --> Router Class Initialized
INFO - 2023-07-26 04:24:41 --> Output Class Initialized
INFO - 2023-07-26 04:24:41 --> Security Class Initialized
DEBUG - 2023-07-26 04:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:24:41 --> Input Class Initialized
INFO - 2023-07-26 04:24:41 --> Language Class Initialized
INFO - 2023-07-26 04:24:41 --> Loader Class Initialized
INFO - 2023-07-26 04:24:41 --> Helper loaded: url_helper
INFO - 2023-07-26 04:24:41 --> Helper loaded: file_helper
INFO - 2023-07-26 04:24:41 --> Helper loaded: html_helper
INFO - 2023-07-26 04:24:41 --> Helper loaded: text_helper
INFO - 2023-07-26 04:24:41 --> Helper loaded: form_helper
INFO - 2023-07-26 04:24:41 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:24:41 --> Helper loaded: security_helper
INFO - 2023-07-26 04:24:41 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:24:41 --> Database Driver Class Initialized
INFO - 2023-07-26 04:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:24:41 --> Parser Class Initialized
INFO - 2023-07-26 04:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:24:41 --> Pagination Class Initialized
INFO - 2023-07-26 04:24:41 --> Form Validation Class Initialized
INFO - 2023-07-26 04:24:41 --> Controller Class Initialized
INFO - 2023-07-26 04:24:41 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:41 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:41 --> Model Class Initialized
INFO - 2023-07-26 04:24:41 --> Final output sent to browser
DEBUG - 2023-07-26 04:24:41 --> Total execution time: 0.1079
ERROR - 2023-07-26 04:24:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:24:51 --> Config Class Initialized
INFO - 2023-07-26 04:24:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:24:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:24:51 --> Utf8 Class Initialized
INFO - 2023-07-26 04:24:51 --> URI Class Initialized
INFO - 2023-07-26 04:24:51 --> Router Class Initialized
INFO - 2023-07-26 04:24:51 --> Output Class Initialized
INFO - 2023-07-26 04:24:51 --> Security Class Initialized
DEBUG - 2023-07-26 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:24:51 --> Input Class Initialized
INFO - 2023-07-26 04:24:51 --> Language Class Initialized
INFO - 2023-07-26 04:24:51 --> Loader Class Initialized
INFO - 2023-07-26 04:24:51 --> Helper loaded: url_helper
INFO - 2023-07-26 04:24:51 --> Helper loaded: file_helper
INFO - 2023-07-26 04:24:51 --> Helper loaded: html_helper
INFO - 2023-07-26 04:24:51 --> Helper loaded: text_helper
INFO - 2023-07-26 04:24:51 --> Helper loaded: form_helper
INFO - 2023-07-26 04:24:51 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:24:51 --> Helper loaded: security_helper
INFO - 2023-07-26 04:24:51 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:24:51 --> Database Driver Class Initialized
INFO - 2023-07-26 04:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:24:51 --> Parser Class Initialized
INFO - 2023-07-26 04:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:24:51 --> Pagination Class Initialized
INFO - 2023-07-26 04:24:51 --> Form Validation Class Initialized
INFO - 2023-07-26 04:24:51 --> Controller Class Initialized
INFO - 2023-07-26 04:24:51 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:51 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:51 --> Model Class Initialized
DEBUG - 2023-07-26 04:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-26 04:24:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:24:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 04:24:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 04:24:51 --> Model Class Initialized
INFO - 2023-07-26 04:24:51 --> Model Class Initialized
INFO - 2023-07-26 04:24:51 --> Model Class Initialized
INFO - 2023-07-26 04:24:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 04:24:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 04:24:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 04:24:51 --> Final output sent to browser
DEBUG - 2023-07-26 04:24:51 --> Total execution time: 0.0852
ERROR - 2023-07-26 04:25:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:25:08 --> Config Class Initialized
INFO - 2023-07-26 04:25:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:25:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:25:08 --> Utf8 Class Initialized
INFO - 2023-07-26 04:25:08 --> URI Class Initialized
INFO - 2023-07-26 04:25:08 --> Router Class Initialized
INFO - 2023-07-26 04:25:08 --> Output Class Initialized
INFO - 2023-07-26 04:25:08 --> Security Class Initialized
DEBUG - 2023-07-26 04:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:25:08 --> Input Class Initialized
INFO - 2023-07-26 04:25:08 --> Language Class Initialized
INFO - 2023-07-26 04:25:08 --> Loader Class Initialized
INFO - 2023-07-26 04:25:08 --> Helper loaded: url_helper
INFO - 2023-07-26 04:25:08 --> Helper loaded: file_helper
INFO - 2023-07-26 04:25:08 --> Helper loaded: html_helper
INFO - 2023-07-26 04:25:08 --> Helper loaded: text_helper
INFO - 2023-07-26 04:25:08 --> Helper loaded: form_helper
INFO - 2023-07-26 04:25:08 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:25:08 --> Helper loaded: security_helper
INFO - 2023-07-26 04:25:08 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:25:08 --> Database Driver Class Initialized
INFO - 2023-07-26 04:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:25:08 --> Parser Class Initialized
INFO - 2023-07-26 04:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:25:08 --> Pagination Class Initialized
INFO - 2023-07-26 04:25:08 --> Form Validation Class Initialized
INFO - 2023-07-26 04:25:08 --> Controller Class Initialized
INFO - 2023-07-26 04:25:08 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:08 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:08 --> Model Class Initialized
INFO - 2023-07-26 04:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-26 04:25:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 04:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 04:25:08 --> Model Class Initialized
INFO - 2023-07-26 04:25:08 --> Model Class Initialized
INFO - 2023-07-26 04:25:08 --> Model Class Initialized
INFO - 2023-07-26 04:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 04:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 04:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 04:25:09 --> Final output sent to browser
DEBUG - 2023-07-26 04:25:09 --> Total execution time: 0.0879
ERROR - 2023-07-26 04:25:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:25:10 --> Config Class Initialized
INFO - 2023-07-26 04:25:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:25:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:25:10 --> Utf8 Class Initialized
INFO - 2023-07-26 04:25:10 --> URI Class Initialized
INFO - 2023-07-26 04:25:10 --> Router Class Initialized
INFO - 2023-07-26 04:25:10 --> Output Class Initialized
INFO - 2023-07-26 04:25:10 --> Security Class Initialized
DEBUG - 2023-07-26 04:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:25:10 --> Input Class Initialized
INFO - 2023-07-26 04:25:10 --> Language Class Initialized
INFO - 2023-07-26 04:25:10 --> Loader Class Initialized
INFO - 2023-07-26 04:25:10 --> Helper loaded: url_helper
INFO - 2023-07-26 04:25:10 --> Helper loaded: file_helper
INFO - 2023-07-26 04:25:10 --> Helper loaded: html_helper
INFO - 2023-07-26 04:25:10 --> Helper loaded: text_helper
INFO - 2023-07-26 04:25:10 --> Helper loaded: form_helper
INFO - 2023-07-26 04:25:10 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:25:10 --> Helper loaded: security_helper
INFO - 2023-07-26 04:25:10 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:25:10 --> Database Driver Class Initialized
INFO - 2023-07-26 04:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:25:10 --> Parser Class Initialized
INFO - 2023-07-26 04:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:25:10 --> Pagination Class Initialized
INFO - 2023-07-26 04:25:10 --> Form Validation Class Initialized
INFO - 2023-07-26 04:25:10 --> Controller Class Initialized
INFO - 2023-07-26 04:25:10 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:10 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:10 --> Model Class Initialized
INFO - 2023-07-26 04:25:10 --> Final output sent to browser
DEBUG - 2023-07-26 04:25:10 --> Total execution time: 0.0386
ERROR - 2023-07-26 04:25:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:25:27 --> Config Class Initialized
INFO - 2023-07-26 04:25:27 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:25:27 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:25:27 --> Utf8 Class Initialized
INFO - 2023-07-26 04:25:27 --> URI Class Initialized
INFO - 2023-07-26 04:25:27 --> Router Class Initialized
INFO - 2023-07-26 04:25:27 --> Output Class Initialized
INFO - 2023-07-26 04:25:27 --> Security Class Initialized
DEBUG - 2023-07-26 04:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:25:27 --> Input Class Initialized
INFO - 2023-07-26 04:25:27 --> Language Class Initialized
INFO - 2023-07-26 04:25:27 --> Loader Class Initialized
INFO - 2023-07-26 04:25:27 --> Helper loaded: url_helper
INFO - 2023-07-26 04:25:27 --> Helper loaded: file_helper
INFO - 2023-07-26 04:25:27 --> Helper loaded: html_helper
INFO - 2023-07-26 04:25:27 --> Helper loaded: text_helper
INFO - 2023-07-26 04:25:27 --> Helper loaded: form_helper
INFO - 2023-07-26 04:25:27 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:25:27 --> Helper loaded: security_helper
INFO - 2023-07-26 04:25:27 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:25:27 --> Database Driver Class Initialized
INFO - 2023-07-26 04:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:25:27 --> Parser Class Initialized
INFO - 2023-07-26 04:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:25:27 --> Pagination Class Initialized
INFO - 2023-07-26 04:25:27 --> Form Validation Class Initialized
INFO - 2023-07-26 04:25:27 --> Controller Class Initialized
INFO - 2023-07-26 04:25:27 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:27 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:27 --> Model Class Initialized
INFO - 2023-07-26 04:25:27 --> Final output sent to browser
DEBUG - 2023-07-26 04:25:27 --> Total execution time: 0.0366
ERROR - 2023-07-26 04:25:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:25:37 --> Config Class Initialized
INFO - 2023-07-26 04:25:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:25:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:25:37 --> Utf8 Class Initialized
INFO - 2023-07-26 04:25:37 --> URI Class Initialized
INFO - 2023-07-26 04:25:37 --> Router Class Initialized
INFO - 2023-07-26 04:25:37 --> Output Class Initialized
INFO - 2023-07-26 04:25:37 --> Security Class Initialized
DEBUG - 2023-07-26 04:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:25:37 --> Input Class Initialized
INFO - 2023-07-26 04:25:37 --> Language Class Initialized
INFO - 2023-07-26 04:25:37 --> Loader Class Initialized
INFO - 2023-07-26 04:25:37 --> Helper loaded: url_helper
INFO - 2023-07-26 04:25:37 --> Helper loaded: file_helper
INFO - 2023-07-26 04:25:37 --> Helper loaded: html_helper
INFO - 2023-07-26 04:25:37 --> Helper loaded: text_helper
INFO - 2023-07-26 04:25:37 --> Helper loaded: form_helper
INFO - 2023-07-26 04:25:37 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:25:37 --> Helper loaded: security_helper
INFO - 2023-07-26 04:25:37 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:25:37 --> Database Driver Class Initialized
INFO - 2023-07-26 04:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:25:37 --> Parser Class Initialized
INFO - 2023-07-26 04:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:25:37 --> Pagination Class Initialized
INFO - 2023-07-26 04:25:37 --> Form Validation Class Initialized
INFO - 2023-07-26 04:25:37 --> Controller Class Initialized
INFO - 2023-07-26 04:25:37 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:37 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:37 --> Model Class Initialized
INFO - 2023-07-26 04:25:37 --> Final output sent to browser
DEBUG - 2023-07-26 04:25:37 --> Total execution time: 0.0368
ERROR - 2023-07-26 04:25:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:25:50 --> Config Class Initialized
INFO - 2023-07-26 04:25:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:25:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:25:50 --> Utf8 Class Initialized
INFO - 2023-07-26 04:25:50 --> URI Class Initialized
INFO - 2023-07-26 04:25:50 --> Router Class Initialized
INFO - 2023-07-26 04:25:50 --> Output Class Initialized
INFO - 2023-07-26 04:25:50 --> Security Class Initialized
DEBUG - 2023-07-26 04:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:25:50 --> Input Class Initialized
INFO - 2023-07-26 04:25:50 --> Language Class Initialized
INFO - 2023-07-26 04:25:50 --> Loader Class Initialized
INFO - 2023-07-26 04:25:50 --> Helper loaded: url_helper
INFO - 2023-07-26 04:25:50 --> Helper loaded: file_helper
INFO - 2023-07-26 04:25:50 --> Helper loaded: html_helper
INFO - 2023-07-26 04:25:50 --> Helper loaded: text_helper
INFO - 2023-07-26 04:25:50 --> Helper loaded: form_helper
INFO - 2023-07-26 04:25:50 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:25:50 --> Helper loaded: security_helper
INFO - 2023-07-26 04:25:50 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:25:50 --> Database Driver Class Initialized
INFO - 2023-07-26 04:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:25:50 --> Parser Class Initialized
INFO - 2023-07-26 04:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:25:50 --> Pagination Class Initialized
INFO - 2023-07-26 04:25:50 --> Form Validation Class Initialized
INFO - 2023-07-26 04:25:50 --> Controller Class Initialized
INFO - 2023-07-26 04:25:50 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:50 --> Model Class Initialized
DEBUG - 2023-07-26 04:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:25:50 --> Model Class Initialized
INFO - 2023-07-26 04:25:50 --> Final output sent to browser
DEBUG - 2023-07-26 04:25:50 --> Total execution time: 0.0401
ERROR - 2023-07-26 04:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:26:01 --> Config Class Initialized
INFO - 2023-07-26 04:26:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:26:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:26:01 --> Utf8 Class Initialized
INFO - 2023-07-26 04:26:01 --> URI Class Initialized
INFO - 2023-07-26 04:26:01 --> Router Class Initialized
INFO - 2023-07-26 04:26:01 --> Output Class Initialized
INFO - 2023-07-26 04:26:01 --> Security Class Initialized
DEBUG - 2023-07-26 04:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:26:01 --> Input Class Initialized
INFO - 2023-07-26 04:26:01 --> Language Class Initialized
INFO - 2023-07-26 04:26:01 --> Loader Class Initialized
INFO - 2023-07-26 04:26:01 --> Helper loaded: url_helper
INFO - 2023-07-26 04:26:01 --> Helper loaded: file_helper
INFO - 2023-07-26 04:26:01 --> Helper loaded: html_helper
INFO - 2023-07-26 04:26:01 --> Helper loaded: text_helper
INFO - 2023-07-26 04:26:01 --> Helper loaded: form_helper
INFO - 2023-07-26 04:26:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:26:01 --> Helper loaded: security_helper
INFO - 2023-07-26 04:26:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:26:01 --> Database Driver Class Initialized
INFO - 2023-07-26 04:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:26:01 --> Parser Class Initialized
INFO - 2023-07-26 04:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:26:01 --> Pagination Class Initialized
INFO - 2023-07-26 04:26:01 --> Form Validation Class Initialized
INFO - 2023-07-26 04:26:01 --> Controller Class Initialized
INFO - 2023-07-26 04:26:01 --> Model Class Initialized
DEBUG - 2023-07-26 04:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:26:01 --> Model Class Initialized
DEBUG - 2023-07-26 04:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:26:01 --> Model Class Initialized
INFO - 2023-07-26 04:26:01 --> Final output sent to browser
DEBUG - 2023-07-26 04:26:01 --> Total execution time: 0.0408
ERROR - 2023-07-26 04:26:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 04:26:07 --> Config Class Initialized
INFO - 2023-07-26 04:26:07 --> Hooks Class Initialized
DEBUG - 2023-07-26 04:26:07 --> UTF-8 Support Enabled
INFO - 2023-07-26 04:26:07 --> Utf8 Class Initialized
INFO - 2023-07-26 04:26:07 --> URI Class Initialized
INFO - 2023-07-26 04:26:07 --> Router Class Initialized
INFO - 2023-07-26 04:26:07 --> Output Class Initialized
INFO - 2023-07-26 04:26:07 --> Security Class Initialized
DEBUG - 2023-07-26 04:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 04:26:07 --> Input Class Initialized
INFO - 2023-07-26 04:26:07 --> Language Class Initialized
INFO - 2023-07-26 04:26:07 --> Loader Class Initialized
INFO - 2023-07-26 04:26:07 --> Helper loaded: url_helper
INFO - 2023-07-26 04:26:07 --> Helper loaded: file_helper
INFO - 2023-07-26 04:26:07 --> Helper loaded: html_helper
INFO - 2023-07-26 04:26:07 --> Helper loaded: text_helper
INFO - 2023-07-26 04:26:07 --> Helper loaded: form_helper
INFO - 2023-07-26 04:26:07 --> Helper loaded: lang_helper
INFO - 2023-07-26 04:26:07 --> Helper loaded: security_helper
INFO - 2023-07-26 04:26:07 --> Helper loaded: cookie_helper
INFO - 2023-07-26 04:26:07 --> Database Driver Class Initialized
INFO - 2023-07-26 04:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 04:26:07 --> Parser Class Initialized
INFO - 2023-07-26 04:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 04:26:07 --> Pagination Class Initialized
INFO - 2023-07-26 04:26:07 --> Form Validation Class Initialized
INFO - 2023-07-26 04:26:07 --> Controller Class Initialized
INFO - 2023-07-26 04:26:07 --> Model Class Initialized
DEBUG - 2023-07-26 04:26:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 04:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:26:07 --> Model Class Initialized
DEBUG - 2023-07-26 04:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:26:07 --> Model Class Initialized
DEBUG - 2023-07-26 04:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-26 04:26:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 04:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 04:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 04:26:07 --> Model Class Initialized
INFO - 2023-07-26 04:26:07 --> Model Class Initialized
INFO - 2023-07-26 04:26:07 --> Model Class Initialized
INFO - 2023-07-26 04:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 04:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 04:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 04:26:07 --> Final output sent to browser
DEBUG - 2023-07-26 04:26:07 --> Total execution time: 0.0883
ERROR - 2023-07-26 07:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 07:29:09 --> Config Class Initialized
INFO - 2023-07-26 07:29:09 --> Hooks Class Initialized
DEBUG - 2023-07-26 07:29:09 --> UTF-8 Support Enabled
INFO - 2023-07-26 07:29:09 --> Utf8 Class Initialized
INFO - 2023-07-26 07:29:09 --> URI Class Initialized
DEBUG - 2023-07-26 07:29:09 --> No URI present. Default controller set.
INFO - 2023-07-26 07:29:09 --> Router Class Initialized
INFO - 2023-07-26 07:29:09 --> Output Class Initialized
INFO - 2023-07-26 07:29:09 --> Security Class Initialized
DEBUG - 2023-07-26 07:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 07:29:09 --> Input Class Initialized
INFO - 2023-07-26 07:29:09 --> Language Class Initialized
INFO - 2023-07-26 07:29:09 --> Loader Class Initialized
INFO - 2023-07-26 07:29:09 --> Helper loaded: url_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: file_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: html_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: text_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: form_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: lang_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: security_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: cookie_helper
INFO - 2023-07-26 07:29:09 --> Database Driver Class Initialized
INFO - 2023-07-26 07:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 07:29:09 --> Parser Class Initialized
INFO - 2023-07-26 07:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 07:29:09 --> Pagination Class Initialized
INFO - 2023-07-26 07:29:09 --> Form Validation Class Initialized
INFO - 2023-07-26 07:29:09 --> Controller Class Initialized
INFO - 2023-07-26 07:29:09 --> Model Class Initialized
DEBUG - 2023-07-26 07:29:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 07:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 07:29:09 --> Config Class Initialized
INFO - 2023-07-26 07:29:09 --> Hooks Class Initialized
DEBUG - 2023-07-26 07:29:09 --> UTF-8 Support Enabled
INFO - 2023-07-26 07:29:09 --> Utf8 Class Initialized
INFO - 2023-07-26 07:29:09 --> URI Class Initialized
INFO - 2023-07-26 07:29:09 --> Router Class Initialized
INFO - 2023-07-26 07:29:09 --> Output Class Initialized
INFO - 2023-07-26 07:29:09 --> Security Class Initialized
DEBUG - 2023-07-26 07:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 07:29:09 --> Input Class Initialized
INFO - 2023-07-26 07:29:09 --> Language Class Initialized
INFO - 2023-07-26 07:29:09 --> Loader Class Initialized
INFO - 2023-07-26 07:29:09 --> Helper loaded: url_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: file_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: html_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: text_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: form_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: lang_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: security_helper
INFO - 2023-07-26 07:29:09 --> Helper loaded: cookie_helper
INFO - 2023-07-26 07:29:09 --> Database Driver Class Initialized
INFO - 2023-07-26 07:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 07:29:09 --> Parser Class Initialized
INFO - 2023-07-26 07:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 07:29:09 --> Pagination Class Initialized
INFO - 2023-07-26 07:29:09 --> Form Validation Class Initialized
INFO - 2023-07-26 07:29:09 --> Controller Class Initialized
INFO - 2023-07-26 07:29:09 --> Model Class Initialized
DEBUG - 2023-07-26 07:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 07:29:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 07:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 07:29:09 --> Model Class Initialized
INFO - 2023-07-26 07:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 07:29:09 --> Final output sent to browser
DEBUG - 2023-07-26 07:29:09 --> Total execution time: 0.0316
ERROR - 2023-07-26 07:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 07:29:34 --> Config Class Initialized
INFO - 2023-07-26 07:29:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 07:29:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 07:29:34 --> Utf8 Class Initialized
INFO - 2023-07-26 07:29:34 --> URI Class Initialized
INFO - 2023-07-26 07:29:34 --> Router Class Initialized
INFO - 2023-07-26 07:29:34 --> Output Class Initialized
INFO - 2023-07-26 07:29:34 --> Security Class Initialized
DEBUG - 2023-07-26 07:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 07:29:34 --> Input Class Initialized
INFO - 2023-07-26 07:29:34 --> Language Class Initialized
INFO - 2023-07-26 07:29:34 --> Loader Class Initialized
INFO - 2023-07-26 07:29:34 --> Helper loaded: url_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: file_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: html_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: text_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: form_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: lang_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: security_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: cookie_helper
INFO - 2023-07-26 07:29:34 --> Database Driver Class Initialized
INFO - 2023-07-26 07:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 07:29:34 --> Parser Class Initialized
INFO - 2023-07-26 07:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 07:29:34 --> Pagination Class Initialized
INFO - 2023-07-26 07:29:34 --> Form Validation Class Initialized
INFO - 2023-07-26 07:29:34 --> Controller Class Initialized
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
DEBUG - 2023-07-26 07:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
INFO - 2023-07-26 07:29:34 --> Final output sent to browser
DEBUG - 2023-07-26 07:29:34 --> Total execution time: 0.0207
ERROR - 2023-07-26 07:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 07:29:34 --> Config Class Initialized
INFO - 2023-07-26 07:29:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 07:29:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 07:29:34 --> Utf8 Class Initialized
INFO - 2023-07-26 07:29:34 --> URI Class Initialized
DEBUG - 2023-07-26 07:29:34 --> No URI present. Default controller set.
INFO - 2023-07-26 07:29:34 --> Router Class Initialized
INFO - 2023-07-26 07:29:34 --> Output Class Initialized
INFO - 2023-07-26 07:29:34 --> Security Class Initialized
DEBUG - 2023-07-26 07:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 07:29:34 --> Input Class Initialized
INFO - 2023-07-26 07:29:34 --> Language Class Initialized
INFO - 2023-07-26 07:29:34 --> Loader Class Initialized
INFO - 2023-07-26 07:29:34 --> Helper loaded: url_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: file_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: html_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: text_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: form_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: lang_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: security_helper
INFO - 2023-07-26 07:29:34 --> Helper loaded: cookie_helper
INFO - 2023-07-26 07:29:34 --> Database Driver Class Initialized
INFO - 2023-07-26 07:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 07:29:34 --> Parser Class Initialized
INFO - 2023-07-26 07:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 07:29:34 --> Pagination Class Initialized
INFO - 2023-07-26 07:29:34 --> Form Validation Class Initialized
INFO - 2023-07-26 07:29:34 --> Controller Class Initialized
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
DEBUG - 2023-07-26 07:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
DEBUG - 2023-07-26 07:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
DEBUG - 2023-07-26 07:29:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 07:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
INFO - 2023-07-26 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 07:29:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 07:29:34 --> Model Class Initialized
INFO - 2023-07-26 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 07:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 07:29:34 --> Final output sent to browser
DEBUG - 2023-07-26 07:29:34 --> Total execution time: 0.0828
ERROR - 2023-07-26 07:30:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 07:30:02 --> Config Class Initialized
INFO - 2023-07-26 07:30:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 07:30:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 07:30:02 --> Utf8 Class Initialized
INFO - 2023-07-26 07:30:02 --> URI Class Initialized
INFO - 2023-07-26 07:30:02 --> Router Class Initialized
INFO - 2023-07-26 07:30:02 --> Output Class Initialized
INFO - 2023-07-26 07:30:02 --> Security Class Initialized
DEBUG - 2023-07-26 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 07:30:02 --> Input Class Initialized
INFO - 2023-07-26 07:30:02 --> Language Class Initialized
INFO - 2023-07-26 07:30:02 --> Loader Class Initialized
INFO - 2023-07-26 07:30:02 --> Helper loaded: url_helper
INFO - 2023-07-26 07:30:02 --> Helper loaded: file_helper
INFO - 2023-07-26 07:30:02 --> Helper loaded: html_helper
INFO - 2023-07-26 07:30:02 --> Helper loaded: text_helper
INFO - 2023-07-26 07:30:02 --> Helper loaded: form_helper
INFO - 2023-07-26 07:30:02 --> Helper loaded: lang_helper
INFO - 2023-07-26 07:30:02 --> Helper loaded: security_helper
INFO - 2023-07-26 07:30:02 --> Helper loaded: cookie_helper
INFO - 2023-07-26 07:30:02 --> Database Driver Class Initialized
INFO - 2023-07-26 07:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 07:30:02 --> Parser Class Initialized
INFO - 2023-07-26 07:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 07:30:02 --> Pagination Class Initialized
INFO - 2023-07-26 07:30:02 --> Form Validation Class Initialized
INFO - 2023-07-26 07:30:02 --> Controller Class Initialized
INFO - 2023-07-26 07:30:02 --> Model Class Initialized
DEBUG - 2023-07-26 07:30:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 07:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:02 --> Model Class Initialized
DEBUG - 2023-07-26 07:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:02 --> Model Class Initialized
INFO - 2023-07-26 07:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-26 07:30:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 07:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 07:30:02 --> Model Class Initialized
INFO - 2023-07-26 07:30:02 --> Model Class Initialized
INFO - 2023-07-26 07:30:02 --> Model Class Initialized
INFO - 2023-07-26 07:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 07:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 07:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 07:30:02 --> Final output sent to browser
DEBUG - 2023-07-26 07:30:02 --> Total execution time: 0.1030
ERROR - 2023-07-26 07:30:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 07:30:03 --> Config Class Initialized
INFO - 2023-07-26 07:30:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 07:30:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 07:30:03 --> Utf8 Class Initialized
INFO - 2023-07-26 07:30:03 --> URI Class Initialized
INFO - 2023-07-26 07:30:03 --> Router Class Initialized
INFO - 2023-07-26 07:30:03 --> Output Class Initialized
INFO - 2023-07-26 07:30:03 --> Security Class Initialized
DEBUG - 2023-07-26 07:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 07:30:03 --> Input Class Initialized
INFO - 2023-07-26 07:30:03 --> Language Class Initialized
INFO - 2023-07-26 07:30:03 --> Loader Class Initialized
INFO - 2023-07-26 07:30:03 --> Helper loaded: url_helper
INFO - 2023-07-26 07:30:03 --> Helper loaded: file_helper
INFO - 2023-07-26 07:30:03 --> Helper loaded: html_helper
INFO - 2023-07-26 07:30:03 --> Helper loaded: text_helper
INFO - 2023-07-26 07:30:03 --> Helper loaded: form_helper
INFO - 2023-07-26 07:30:03 --> Helper loaded: lang_helper
INFO - 2023-07-26 07:30:03 --> Helper loaded: security_helper
INFO - 2023-07-26 07:30:03 --> Helper loaded: cookie_helper
INFO - 2023-07-26 07:30:03 --> Database Driver Class Initialized
INFO - 2023-07-26 07:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 07:30:03 --> Parser Class Initialized
INFO - 2023-07-26 07:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 07:30:03 --> Pagination Class Initialized
INFO - 2023-07-26 07:30:03 --> Form Validation Class Initialized
INFO - 2023-07-26 07:30:03 --> Controller Class Initialized
INFO - 2023-07-26 07:30:03 --> Model Class Initialized
DEBUG - 2023-07-26 07:30:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 07:30:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:03 --> Model Class Initialized
DEBUG - 2023-07-26 07:30:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:03 --> Model Class Initialized
INFO - 2023-07-26 07:30:03 --> Final output sent to browser
DEBUG - 2023-07-26 07:30:03 --> Total execution time: 0.0469
ERROR - 2023-07-26 07:30:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 07:30:11 --> Config Class Initialized
INFO - 2023-07-26 07:30:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 07:30:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 07:30:11 --> Utf8 Class Initialized
INFO - 2023-07-26 07:30:11 --> URI Class Initialized
DEBUG - 2023-07-26 07:30:11 --> No URI present. Default controller set.
INFO - 2023-07-26 07:30:11 --> Router Class Initialized
INFO - 2023-07-26 07:30:11 --> Output Class Initialized
INFO - 2023-07-26 07:30:11 --> Security Class Initialized
DEBUG - 2023-07-26 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 07:30:11 --> Input Class Initialized
INFO - 2023-07-26 07:30:11 --> Language Class Initialized
INFO - 2023-07-26 07:30:11 --> Loader Class Initialized
INFO - 2023-07-26 07:30:11 --> Helper loaded: url_helper
INFO - 2023-07-26 07:30:11 --> Helper loaded: file_helper
INFO - 2023-07-26 07:30:11 --> Helper loaded: html_helper
INFO - 2023-07-26 07:30:11 --> Helper loaded: text_helper
INFO - 2023-07-26 07:30:11 --> Helper loaded: form_helper
INFO - 2023-07-26 07:30:11 --> Helper loaded: lang_helper
INFO - 2023-07-26 07:30:11 --> Helper loaded: security_helper
INFO - 2023-07-26 07:30:11 --> Helper loaded: cookie_helper
INFO - 2023-07-26 07:30:11 --> Database Driver Class Initialized
INFO - 2023-07-26 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 07:30:11 --> Parser Class Initialized
INFO - 2023-07-26 07:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 07:30:11 --> Pagination Class Initialized
INFO - 2023-07-26 07:30:11 --> Form Validation Class Initialized
INFO - 2023-07-26 07:30:11 --> Controller Class Initialized
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
DEBUG - 2023-07-26 07:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
DEBUG - 2023-07-26 07:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
DEBUG - 2023-07-26 07:30:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 07:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
INFO - 2023-07-26 07:30:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 07:30:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 07:30:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 07:30:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 07:30:11 --> Model Class Initialized
INFO - 2023-07-26 07:30:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 07:30:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 07:30:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 07:30:11 --> Final output sent to browser
DEBUG - 2023-07-26 07:30:11 --> Total execution time: 0.0842
ERROR - 2023-07-26 08:09:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:09:26 --> Config Class Initialized
INFO - 2023-07-26 08:09:26 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:09:26 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:09:26 --> Utf8 Class Initialized
INFO - 2023-07-26 08:09:26 --> URI Class Initialized
DEBUG - 2023-07-26 08:09:26 --> No URI present. Default controller set.
INFO - 2023-07-26 08:09:26 --> Router Class Initialized
INFO - 2023-07-26 08:09:26 --> Output Class Initialized
INFO - 2023-07-26 08:09:26 --> Security Class Initialized
DEBUG - 2023-07-26 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:09:26 --> Input Class Initialized
INFO - 2023-07-26 08:09:26 --> Language Class Initialized
INFO - 2023-07-26 08:09:26 --> Loader Class Initialized
INFO - 2023-07-26 08:09:26 --> Helper loaded: url_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: file_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: html_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: text_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: form_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: security_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:09:26 --> Database Driver Class Initialized
INFO - 2023-07-26 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:09:26 --> Parser Class Initialized
INFO - 2023-07-26 08:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:09:26 --> Pagination Class Initialized
INFO - 2023-07-26 08:09:26 --> Form Validation Class Initialized
INFO - 2023-07-26 08:09:26 --> Controller Class Initialized
INFO - 2023-07-26 08:09:26 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 08:09:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:09:26 --> Config Class Initialized
INFO - 2023-07-26 08:09:26 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:09:26 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:09:26 --> Utf8 Class Initialized
INFO - 2023-07-26 08:09:26 --> URI Class Initialized
INFO - 2023-07-26 08:09:26 --> Router Class Initialized
INFO - 2023-07-26 08:09:26 --> Output Class Initialized
INFO - 2023-07-26 08:09:26 --> Security Class Initialized
DEBUG - 2023-07-26 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:09:26 --> Input Class Initialized
INFO - 2023-07-26 08:09:26 --> Language Class Initialized
INFO - 2023-07-26 08:09:26 --> Loader Class Initialized
INFO - 2023-07-26 08:09:26 --> Helper loaded: url_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: file_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: html_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: text_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: form_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: security_helper
INFO - 2023-07-26 08:09:26 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:09:26 --> Database Driver Class Initialized
INFO - 2023-07-26 08:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:09:27 --> Parser Class Initialized
INFO - 2023-07-26 08:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:09:27 --> Pagination Class Initialized
INFO - 2023-07-26 08:09:27 --> Form Validation Class Initialized
INFO - 2023-07-26 08:09:27 --> Controller Class Initialized
INFO - 2023-07-26 08:09:27 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 08:09:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:09:27 --> Model Class Initialized
INFO - 2023-07-26 08:09:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:09:27 --> Final output sent to browser
DEBUG - 2023-07-26 08:09:27 --> Total execution time: 0.0326
ERROR - 2023-07-26 08:09:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:09:29 --> Config Class Initialized
INFO - 2023-07-26 08:09:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:09:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:09:29 --> Utf8 Class Initialized
INFO - 2023-07-26 08:09:29 --> URI Class Initialized
INFO - 2023-07-26 08:09:29 --> Router Class Initialized
INFO - 2023-07-26 08:09:29 --> Output Class Initialized
INFO - 2023-07-26 08:09:29 --> Security Class Initialized
DEBUG - 2023-07-26 08:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:09:29 --> Input Class Initialized
INFO - 2023-07-26 08:09:29 --> Language Class Initialized
INFO - 2023-07-26 08:09:29 --> Loader Class Initialized
INFO - 2023-07-26 08:09:29 --> Helper loaded: url_helper
INFO - 2023-07-26 08:09:29 --> Helper loaded: file_helper
INFO - 2023-07-26 08:09:29 --> Helper loaded: html_helper
INFO - 2023-07-26 08:09:29 --> Helper loaded: text_helper
INFO - 2023-07-26 08:09:29 --> Helper loaded: form_helper
INFO - 2023-07-26 08:09:29 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:09:29 --> Helper loaded: security_helper
INFO - 2023-07-26 08:09:29 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:09:29 --> Database Driver Class Initialized
INFO - 2023-07-26 08:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:09:29 --> Parser Class Initialized
INFO - 2023-07-26 08:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:09:29 --> Pagination Class Initialized
INFO - 2023-07-26 08:09:29 --> Form Validation Class Initialized
INFO - 2023-07-26 08:09:29 --> Controller Class Initialized
INFO - 2023-07-26 08:09:29 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:29 --> Model Class Initialized
INFO - 2023-07-26 08:09:29 --> Final output sent to browser
DEBUG - 2023-07-26 08:09:29 --> Total execution time: 0.0202
ERROR - 2023-07-26 08:09:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:09:30 --> Config Class Initialized
INFO - 2023-07-26 08:09:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:09:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:09:30 --> Utf8 Class Initialized
INFO - 2023-07-26 08:09:30 --> URI Class Initialized
DEBUG - 2023-07-26 08:09:30 --> No URI present. Default controller set.
INFO - 2023-07-26 08:09:30 --> Router Class Initialized
INFO - 2023-07-26 08:09:30 --> Output Class Initialized
INFO - 2023-07-26 08:09:30 --> Security Class Initialized
DEBUG - 2023-07-26 08:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:09:30 --> Input Class Initialized
INFO - 2023-07-26 08:09:30 --> Language Class Initialized
INFO - 2023-07-26 08:09:30 --> Loader Class Initialized
INFO - 2023-07-26 08:09:30 --> Helper loaded: url_helper
INFO - 2023-07-26 08:09:30 --> Helper loaded: file_helper
INFO - 2023-07-26 08:09:30 --> Helper loaded: html_helper
INFO - 2023-07-26 08:09:30 --> Helper loaded: text_helper
INFO - 2023-07-26 08:09:30 --> Helper loaded: form_helper
INFO - 2023-07-26 08:09:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:09:30 --> Helper loaded: security_helper
INFO - 2023-07-26 08:09:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:09:30 --> Database Driver Class Initialized
INFO - 2023-07-26 08:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:09:30 --> Parser Class Initialized
INFO - 2023-07-26 08:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:09:30 --> Pagination Class Initialized
INFO - 2023-07-26 08:09:30 --> Form Validation Class Initialized
INFO - 2023-07-26 08:09:30 --> Controller Class Initialized
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
INFO - 2023-07-26 08:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 08:09:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:09:30 --> Model Class Initialized
INFO - 2023-07-26 08:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:09:30 --> Final output sent to browser
DEBUG - 2023-07-26 08:09:30 --> Total execution time: 0.1899
ERROR - 2023-07-26 08:09:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:09:31 --> Config Class Initialized
INFO - 2023-07-26 08:09:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:09:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:09:31 --> Utf8 Class Initialized
INFO - 2023-07-26 08:09:31 --> URI Class Initialized
INFO - 2023-07-26 08:09:31 --> Router Class Initialized
INFO - 2023-07-26 08:09:31 --> Output Class Initialized
INFO - 2023-07-26 08:09:31 --> Security Class Initialized
DEBUG - 2023-07-26 08:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:09:31 --> Input Class Initialized
INFO - 2023-07-26 08:09:31 --> Language Class Initialized
INFO - 2023-07-26 08:09:31 --> Loader Class Initialized
INFO - 2023-07-26 08:09:31 --> Helper loaded: url_helper
INFO - 2023-07-26 08:09:31 --> Helper loaded: file_helper
INFO - 2023-07-26 08:09:31 --> Helper loaded: html_helper
INFO - 2023-07-26 08:09:31 --> Helper loaded: text_helper
INFO - 2023-07-26 08:09:31 --> Helper loaded: form_helper
INFO - 2023-07-26 08:09:31 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:09:31 --> Helper loaded: security_helper
INFO - 2023-07-26 08:09:31 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:09:31 --> Database Driver Class Initialized
INFO - 2023-07-26 08:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:09:31 --> Parser Class Initialized
INFO - 2023-07-26 08:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:09:31 --> Pagination Class Initialized
INFO - 2023-07-26 08:09:31 --> Form Validation Class Initialized
INFO - 2023-07-26 08:09:31 --> Controller Class Initialized
DEBUG - 2023-07-26 08:09:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:31 --> Model Class Initialized
INFO - 2023-07-26 08:09:31 --> Final output sent to browser
DEBUG - 2023-07-26 08:09:31 --> Total execution time: 0.0135
ERROR - 2023-07-26 08:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:09:55 --> Config Class Initialized
INFO - 2023-07-26 08:09:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:09:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:09:55 --> Utf8 Class Initialized
INFO - 2023-07-26 08:09:55 --> URI Class Initialized
INFO - 2023-07-26 08:09:55 --> Router Class Initialized
INFO - 2023-07-26 08:09:55 --> Output Class Initialized
INFO - 2023-07-26 08:09:55 --> Security Class Initialized
DEBUG - 2023-07-26 08:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:09:55 --> Input Class Initialized
INFO - 2023-07-26 08:09:55 --> Language Class Initialized
INFO - 2023-07-26 08:09:55 --> Loader Class Initialized
INFO - 2023-07-26 08:09:55 --> Helper loaded: url_helper
INFO - 2023-07-26 08:09:55 --> Helper loaded: file_helper
INFO - 2023-07-26 08:09:55 --> Helper loaded: html_helper
INFO - 2023-07-26 08:09:55 --> Helper loaded: text_helper
INFO - 2023-07-26 08:09:55 --> Helper loaded: form_helper
INFO - 2023-07-26 08:09:55 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:09:55 --> Helper loaded: security_helper
INFO - 2023-07-26 08:09:55 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:09:55 --> Database Driver Class Initialized
INFO - 2023-07-26 08:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:09:55 --> Parser Class Initialized
INFO - 2023-07-26 08:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:09:55 --> Pagination Class Initialized
INFO - 2023-07-26 08:09:55 --> Form Validation Class Initialized
INFO - 2023-07-26 08:09:55 --> Controller Class Initialized
INFO - 2023-07-26 08:09:55 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:55 --> Model Class Initialized
DEBUG - 2023-07-26 08:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-07-26 08:09:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:09:55 --> Model Class Initialized
INFO - 2023-07-26 08:09:55 --> Model Class Initialized
INFO - 2023-07-26 08:09:55 --> Model Class Initialized
INFO - 2023-07-26 08:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:09:56 --> Final output sent to browser
DEBUG - 2023-07-26 08:09:56 --> Total execution time: 0.1481
ERROR - 2023-07-26 08:10:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:10:04 --> Config Class Initialized
INFO - 2023-07-26 08:10:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:10:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:10:04 --> Utf8 Class Initialized
INFO - 2023-07-26 08:10:04 --> URI Class Initialized
INFO - 2023-07-26 08:10:04 --> Router Class Initialized
INFO - 2023-07-26 08:10:04 --> Output Class Initialized
INFO - 2023-07-26 08:10:04 --> Security Class Initialized
DEBUG - 2023-07-26 08:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:10:04 --> Input Class Initialized
INFO - 2023-07-26 08:10:04 --> Language Class Initialized
INFO - 2023-07-26 08:10:04 --> Loader Class Initialized
INFO - 2023-07-26 08:10:04 --> Helper loaded: url_helper
INFO - 2023-07-26 08:10:04 --> Helper loaded: file_helper
INFO - 2023-07-26 08:10:04 --> Helper loaded: html_helper
INFO - 2023-07-26 08:10:04 --> Helper loaded: text_helper
INFO - 2023-07-26 08:10:04 --> Helper loaded: form_helper
INFO - 2023-07-26 08:10:04 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:10:04 --> Helper loaded: security_helper
INFO - 2023-07-26 08:10:04 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:10:04 --> Database Driver Class Initialized
INFO - 2023-07-26 08:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:10:04 --> Parser Class Initialized
INFO - 2023-07-26 08:10:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:10:04 --> Pagination Class Initialized
INFO - 2023-07-26 08:10:04 --> Form Validation Class Initialized
INFO - 2023-07-26 08:10:04 --> Controller Class Initialized
INFO - 2023-07-26 08:10:04 --> Model Class Initialized
INFO - 2023-07-26 08:10:04 --> Final output sent to browser
DEBUG - 2023-07-26 08:10:04 --> Total execution time: 0.0147
ERROR - 2023-07-26 08:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:10:09 --> Config Class Initialized
INFO - 2023-07-26 08:10:09 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:10:09 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:10:09 --> Utf8 Class Initialized
INFO - 2023-07-26 08:10:09 --> URI Class Initialized
INFO - 2023-07-26 08:10:09 --> Router Class Initialized
INFO - 2023-07-26 08:10:09 --> Output Class Initialized
INFO - 2023-07-26 08:10:10 --> Security Class Initialized
DEBUG - 2023-07-26 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:10:10 --> Input Class Initialized
INFO - 2023-07-26 08:10:10 --> Language Class Initialized
INFO - 2023-07-26 08:10:10 --> Loader Class Initialized
INFO - 2023-07-26 08:10:10 --> Helper loaded: url_helper
INFO - 2023-07-26 08:10:10 --> Helper loaded: file_helper
INFO - 2023-07-26 08:10:10 --> Helper loaded: html_helper
INFO - 2023-07-26 08:10:10 --> Helper loaded: text_helper
INFO - 2023-07-26 08:10:10 --> Helper loaded: form_helper
INFO - 2023-07-26 08:10:10 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:10:10 --> Helper loaded: security_helper
INFO - 2023-07-26 08:10:10 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:10:10 --> Database Driver Class Initialized
INFO - 2023-07-26 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:10:10 --> Parser Class Initialized
INFO - 2023-07-26 08:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:10:10 --> Pagination Class Initialized
INFO - 2023-07-26 08:10:10 --> Form Validation Class Initialized
INFO - 2023-07-26 08:10:10 --> Controller Class Initialized
INFO - 2023-07-26 08:10:10 --> Model Class Initialized
DEBUG - 2023-07-26 08:10:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:10:10 --> Model Class Initialized
DEBUG - 2023-07-26 08:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:10:10 --> Model Class Initialized
INFO - 2023-07-26 08:10:10 --> Final output sent to browser
DEBUG - 2023-07-26 08:10:10 --> Total execution time: 0.0223
ERROR - 2023-07-26 08:52:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:52:44 --> Config Class Initialized
INFO - 2023-07-26 08:52:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:52:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:52:44 --> Utf8 Class Initialized
INFO - 2023-07-26 08:52:44 --> URI Class Initialized
INFO - 2023-07-26 08:52:44 --> Router Class Initialized
INFO - 2023-07-26 08:52:44 --> Output Class Initialized
INFO - 2023-07-26 08:52:44 --> Security Class Initialized
DEBUG - 2023-07-26 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:52:44 --> Input Class Initialized
INFO - 2023-07-26 08:52:44 --> Language Class Initialized
INFO - 2023-07-26 08:52:44 --> Loader Class Initialized
INFO - 2023-07-26 08:52:44 --> Helper loaded: url_helper
INFO - 2023-07-26 08:52:44 --> Helper loaded: file_helper
INFO - 2023-07-26 08:52:44 --> Helper loaded: html_helper
INFO - 2023-07-26 08:52:44 --> Helper loaded: text_helper
INFO - 2023-07-26 08:52:44 --> Helper loaded: form_helper
INFO - 2023-07-26 08:52:44 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:52:44 --> Helper loaded: security_helper
INFO - 2023-07-26 08:52:44 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:52:44 --> Database Driver Class Initialized
INFO - 2023-07-26 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:52:44 --> Parser Class Initialized
INFO - 2023-07-26 08:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:52:44 --> Pagination Class Initialized
INFO - 2023-07-26 08:52:44 --> Form Validation Class Initialized
INFO - 2023-07-26 08:52:44 --> Controller Class Initialized
DEBUG - 2023-07-26 08:52:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:44 --> Model Class Initialized
DEBUG - 2023-07-26 08:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:44 --> Model Class Initialized
DEBUG - 2023-07-26 08:52:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:44 --> Model Class Initialized
INFO - 2023-07-26 08:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-26 08:52:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:52:44 --> Model Class Initialized
INFO - 2023-07-26 08:52:44 --> Model Class Initialized
INFO - 2023-07-26 08:52:44 --> Model Class Initialized
INFO - 2023-07-26 08:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:52:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:52:44 --> Final output sent to browser
DEBUG - 2023-07-26 08:52:44 --> Total execution time: 0.1362
ERROR - 2023-07-26 08:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:52:45 --> Config Class Initialized
INFO - 2023-07-26 08:52:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:52:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:52:45 --> Utf8 Class Initialized
INFO - 2023-07-26 08:52:45 --> URI Class Initialized
INFO - 2023-07-26 08:52:45 --> Router Class Initialized
INFO - 2023-07-26 08:52:45 --> Output Class Initialized
INFO - 2023-07-26 08:52:45 --> Security Class Initialized
DEBUG - 2023-07-26 08:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:52:45 --> Input Class Initialized
INFO - 2023-07-26 08:52:45 --> Language Class Initialized
INFO - 2023-07-26 08:52:45 --> Loader Class Initialized
INFO - 2023-07-26 08:52:45 --> Helper loaded: url_helper
INFO - 2023-07-26 08:52:45 --> Helper loaded: file_helper
INFO - 2023-07-26 08:52:45 --> Helper loaded: html_helper
INFO - 2023-07-26 08:52:45 --> Helper loaded: text_helper
INFO - 2023-07-26 08:52:45 --> Helper loaded: form_helper
INFO - 2023-07-26 08:52:45 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:52:45 --> Helper loaded: security_helper
INFO - 2023-07-26 08:52:45 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:52:45 --> Database Driver Class Initialized
INFO - 2023-07-26 08:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:52:45 --> Parser Class Initialized
INFO - 2023-07-26 08:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:52:45 --> Pagination Class Initialized
INFO - 2023-07-26 08:52:45 --> Form Validation Class Initialized
INFO - 2023-07-26 08:52:45 --> Controller Class Initialized
DEBUG - 2023-07-26 08:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:45 --> Model Class Initialized
DEBUG - 2023-07-26 08:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:45 --> Model Class Initialized
INFO - 2023-07-26 08:52:45 --> Final output sent to browser
DEBUG - 2023-07-26 08:52:45 --> Total execution time: 0.0296
ERROR - 2023-07-26 08:52:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:52:53 --> Config Class Initialized
INFO - 2023-07-26 08:52:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:52:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:52:53 --> Utf8 Class Initialized
INFO - 2023-07-26 08:52:53 --> URI Class Initialized
INFO - 2023-07-26 08:52:53 --> Router Class Initialized
INFO - 2023-07-26 08:52:53 --> Output Class Initialized
INFO - 2023-07-26 08:52:53 --> Security Class Initialized
DEBUG - 2023-07-26 08:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:52:53 --> Input Class Initialized
INFO - 2023-07-26 08:52:53 --> Language Class Initialized
INFO - 2023-07-26 08:52:53 --> Loader Class Initialized
INFO - 2023-07-26 08:52:53 --> Helper loaded: url_helper
INFO - 2023-07-26 08:52:53 --> Helper loaded: file_helper
INFO - 2023-07-26 08:52:53 --> Helper loaded: html_helper
INFO - 2023-07-26 08:52:53 --> Helper loaded: text_helper
INFO - 2023-07-26 08:52:53 --> Helper loaded: form_helper
INFO - 2023-07-26 08:52:53 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:52:53 --> Helper loaded: security_helper
INFO - 2023-07-26 08:52:53 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:52:53 --> Database Driver Class Initialized
INFO - 2023-07-26 08:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:52:53 --> Parser Class Initialized
INFO - 2023-07-26 08:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:52:53 --> Pagination Class Initialized
INFO - 2023-07-26 08:52:53 --> Form Validation Class Initialized
INFO - 2023-07-26 08:52:53 --> Controller Class Initialized
DEBUG - 2023-07-26 08:52:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:53 --> Model Class Initialized
DEBUG - 2023-07-26 08:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:52:53 --> Model Class Initialized
INFO - 2023-07-26 08:52:53 --> Final output sent to browser
DEBUG - 2023-07-26 08:52:53 --> Total execution time: 0.1172
ERROR - 2023-07-26 08:53:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:53:14 --> Config Class Initialized
INFO - 2023-07-26 08:53:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:53:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:53:14 --> Utf8 Class Initialized
INFO - 2023-07-26 08:53:14 --> URI Class Initialized
INFO - 2023-07-26 08:53:14 --> Router Class Initialized
INFO - 2023-07-26 08:53:14 --> Output Class Initialized
INFO - 2023-07-26 08:53:14 --> Security Class Initialized
DEBUG - 2023-07-26 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:53:14 --> Input Class Initialized
INFO - 2023-07-26 08:53:14 --> Language Class Initialized
INFO - 2023-07-26 08:53:14 --> Loader Class Initialized
INFO - 2023-07-26 08:53:14 --> Helper loaded: url_helper
INFO - 2023-07-26 08:53:14 --> Helper loaded: file_helper
INFO - 2023-07-26 08:53:14 --> Helper loaded: html_helper
INFO - 2023-07-26 08:53:14 --> Helper loaded: text_helper
INFO - 2023-07-26 08:53:14 --> Helper loaded: form_helper
INFO - 2023-07-26 08:53:14 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:53:14 --> Helper loaded: security_helper
INFO - 2023-07-26 08:53:14 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:53:14 --> Database Driver Class Initialized
INFO - 2023-07-26 08:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:53:14 --> Parser Class Initialized
INFO - 2023-07-26 08:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:53:14 --> Pagination Class Initialized
INFO - 2023-07-26 08:53:14 --> Form Validation Class Initialized
INFO - 2023-07-26 08:53:14 --> Controller Class Initialized
DEBUG - 2023-07-26 08:53:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:14 --> Model Class Initialized
DEBUG - 2023-07-26 08:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:14 --> Model Class Initialized
INFO - 2023-07-26 08:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-26 08:53:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:53:14 --> Model Class Initialized
INFO - 2023-07-26 08:53:14 --> Model Class Initialized
INFO - 2023-07-26 08:53:14 --> Model Class Initialized
INFO - 2023-07-26 08:53:14 --> Model Class Initialized
INFO - 2023-07-26 08:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:53:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:53:14 --> Final output sent to browser
DEBUG - 2023-07-26 08:53:14 --> Total execution time: 0.1265
ERROR - 2023-07-26 08:53:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:53:31 --> Config Class Initialized
INFO - 2023-07-26 08:53:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:53:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:53:31 --> Utf8 Class Initialized
INFO - 2023-07-26 08:53:31 --> URI Class Initialized
DEBUG - 2023-07-26 08:53:31 --> No URI present. Default controller set.
INFO - 2023-07-26 08:53:31 --> Router Class Initialized
INFO - 2023-07-26 08:53:31 --> Output Class Initialized
INFO - 2023-07-26 08:53:31 --> Security Class Initialized
DEBUG - 2023-07-26 08:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:53:31 --> Input Class Initialized
INFO - 2023-07-26 08:53:31 --> Language Class Initialized
INFO - 2023-07-26 08:53:31 --> Loader Class Initialized
INFO - 2023-07-26 08:53:31 --> Helper loaded: url_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: file_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: html_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: text_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: form_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: security_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:53:31 --> Database Driver Class Initialized
INFO - 2023-07-26 08:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:53:31 --> Parser Class Initialized
INFO - 2023-07-26 08:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:53:31 --> Pagination Class Initialized
INFO - 2023-07-26 08:53:31 --> Form Validation Class Initialized
INFO - 2023-07-26 08:53:31 --> Controller Class Initialized
INFO - 2023-07-26 08:53:31 --> Model Class Initialized
DEBUG - 2023-07-26 08:53:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 08:53:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:53:31 --> Config Class Initialized
INFO - 2023-07-26 08:53:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:53:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:53:31 --> Utf8 Class Initialized
INFO - 2023-07-26 08:53:31 --> URI Class Initialized
INFO - 2023-07-26 08:53:31 --> Router Class Initialized
INFO - 2023-07-26 08:53:31 --> Output Class Initialized
INFO - 2023-07-26 08:53:31 --> Security Class Initialized
DEBUG - 2023-07-26 08:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:53:31 --> Input Class Initialized
INFO - 2023-07-26 08:53:31 --> Language Class Initialized
INFO - 2023-07-26 08:53:31 --> Loader Class Initialized
INFO - 2023-07-26 08:53:31 --> Helper loaded: url_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: file_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: html_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: text_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: form_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: security_helper
INFO - 2023-07-26 08:53:31 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:53:31 --> Database Driver Class Initialized
INFO - 2023-07-26 08:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:53:31 --> Parser Class Initialized
INFO - 2023-07-26 08:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:53:31 --> Pagination Class Initialized
INFO - 2023-07-26 08:53:31 --> Form Validation Class Initialized
INFO - 2023-07-26 08:53:31 --> Controller Class Initialized
INFO - 2023-07-26 08:53:31 --> Model Class Initialized
DEBUG - 2023-07-26 08:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 08:53:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:53:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:53:31 --> Model Class Initialized
INFO - 2023-07-26 08:53:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:53:31 --> Final output sent to browser
DEBUG - 2023-07-26 08:53:31 --> Total execution time: 0.0292
ERROR - 2023-07-26 08:53:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:53:47 --> Config Class Initialized
INFO - 2023-07-26 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-26 08:53:47 --> URI Class Initialized
INFO - 2023-07-26 08:53:47 --> Router Class Initialized
INFO - 2023-07-26 08:53:47 --> Output Class Initialized
INFO - 2023-07-26 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-26 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:53:47 --> Input Class Initialized
INFO - 2023-07-26 08:53:47 --> Language Class Initialized
INFO - 2023-07-26 08:53:47 --> Loader Class Initialized
INFO - 2023-07-26 08:53:47 --> Helper loaded: url_helper
INFO - 2023-07-26 08:53:47 --> Helper loaded: file_helper
INFO - 2023-07-26 08:53:47 --> Helper loaded: html_helper
INFO - 2023-07-26 08:53:47 --> Helper loaded: text_helper
INFO - 2023-07-26 08:53:47 --> Helper loaded: form_helper
INFO - 2023-07-26 08:53:47 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:53:47 --> Helper loaded: security_helper
INFO - 2023-07-26 08:53:47 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:53:47 --> Database Driver Class Initialized
INFO - 2023-07-26 08:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:53:47 --> Parser Class Initialized
INFO - 2023-07-26 08:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:53:47 --> Pagination Class Initialized
INFO - 2023-07-26 08:53:47 --> Form Validation Class Initialized
INFO - 2023-07-26 08:53:47 --> Controller Class Initialized
INFO - 2023-07-26 08:53:47 --> Model Class Initialized
DEBUG - 2023-07-26 08:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:47 --> Model Class Initialized
INFO - 2023-07-26 08:53:47 --> Final output sent to browser
DEBUG - 2023-07-26 08:53:47 --> Total execution time: 0.0191
ERROR - 2023-07-26 08:53:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:53:48 --> Config Class Initialized
INFO - 2023-07-26 08:53:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:53:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:53:48 --> Utf8 Class Initialized
INFO - 2023-07-26 08:53:48 --> URI Class Initialized
INFO - 2023-07-26 08:53:48 --> Router Class Initialized
INFO - 2023-07-26 08:53:48 --> Output Class Initialized
INFO - 2023-07-26 08:53:48 --> Security Class Initialized
DEBUG - 2023-07-26 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:53:48 --> Input Class Initialized
INFO - 2023-07-26 08:53:48 --> Language Class Initialized
INFO - 2023-07-26 08:53:48 --> Loader Class Initialized
INFO - 2023-07-26 08:53:48 --> Helper loaded: url_helper
INFO - 2023-07-26 08:53:48 --> Helper loaded: file_helper
INFO - 2023-07-26 08:53:48 --> Helper loaded: html_helper
INFO - 2023-07-26 08:53:48 --> Helper loaded: text_helper
INFO - 2023-07-26 08:53:48 --> Helper loaded: form_helper
INFO - 2023-07-26 08:53:48 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:53:48 --> Helper loaded: security_helper
INFO - 2023-07-26 08:53:48 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:53:48 --> Database Driver Class Initialized
INFO - 2023-07-26 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:53:48 --> Parser Class Initialized
INFO - 2023-07-26 08:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:53:48 --> Pagination Class Initialized
INFO - 2023-07-26 08:53:48 --> Form Validation Class Initialized
INFO - 2023-07-26 08:53:48 --> Controller Class Initialized
INFO - 2023-07-26 08:53:48 --> Model Class Initialized
DEBUG - 2023-07-26 08:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 08:53:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:53:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:53:48 --> Model Class Initialized
INFO - 2023-07-26 08:53:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:53:48 --> Final output sent to browser
DEBUG - 2023-07-26 08:53:48 --> Total execution time: 0.0284
ERROR - 2023-07-26 08:54:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:08 --> Config Class Initialized
INFO - 2023-07-26 08:54:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:08 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:08 --> URI Class Initialized
INFO - 2023-07-26 08:54:08 --> Router Class Initialized
INFO - 2023-07-26 08:54:08 --> Output Class Initialized
INFO - 2023-07-26 08:54:08 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:08 --> Input Class Initialized
INFO - 2023-07-26 08:54:08 --> Language Class Initialized
INFO - 2023-07-26 08:54:08 --> Loader Class Initialized
INFO - 2023-07-26 08:54:08 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:08 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:08 --> Parser Class Initialized
INFO - 2023-07-26 08:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:08 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:08 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:08 --> Controller Class Initialized
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
INFO - 2023-07-26 08:54:08 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:08 --> Total execution time: 0.0199
ERROR - 2023-07-26 08:54:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:08 --> Config Class Initialized
INFO - 2023-07-26 08:54:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:08 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:08 --> URI Class Initialized
DEBUG - 2023-07-26 08:54:08 --> No URI present. Default controller set.
INFO - 2023-07-26 08:54:08 --> Router Class Initialized
INFO - 2023-07-26 08:54:08 --> Output Class Initialized
INFO - 2023-07-26 08:54:08 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:08 --> Input Class Initialized
INFO - 2023-07-26 08:54:08 --> Language Class Initialized
INFO - 2023-07-26 08:54:08 --> Loader Class Initialized
INFO - 2023-07-26 08:54:08 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:08 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:08 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:08 --> Parser Class Initialized
INFO - 2023-07-26 08:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:08 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:08 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:08 --> Controller Class Initialized
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
INFO - 2023-07-26 08:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 08:54:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:54:08 --> Model Class Initialized
INFO - 2023-07-26 08:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:54:08 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:08 --> Total execution time: 0.0717
ERROR - 2023-07-26 08:54:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:14 --> Config Class Initialized
INFO - 2023-07-26 08:54:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:14 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:14 --> URI Class Initialized
INFO - 2023-07-26 08:54:14 --> Router Class Initialized
INFO - 2023-07-26 08:54:14 --> Output Class Initialized
INFO - 2023-07-26 08:54:14 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:14 --> Input Class Initialized
INFO - 2023-07-26 08:54:14 --> Language Class Initialized
INFO - 2023-07-26 08:54:14 --> Loader Class Initialized
INFO - 2023-07-26 08:54:14 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:14 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:14 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:14 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:14 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:14 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:14 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:14 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:14 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:14 --> Parser Class Initialized
INFO - 2023-07-26 08:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:14 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:14 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:14 --> Controller Class Initialized
INFO - 2023-07-26 08:54:14 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:14 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-26 08:54:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:54:14 --> Model Class Initialized
INFO - 2023-07-26 08:54:14 --> Model Class Initialized
INFO - 2023-07-26 08:54:14 --> Model Class Initialized
INFO - 2023-07-26 08:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:54:14 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:14 --> Total execution time: 0.0606
ERROR - 2023-07-26 08:54:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:23 --> Config Class Initialized
INFO - 2023-07-26 08:54:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:23 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:23 --> URI Class Initialized
INFO - 2023-07-26 08:54:23 --> Router Class Initialized
INFO - 2023-07-26 08:54:23 --> Output Class Initialized
INFO - 2023-07-26 08:54:23 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:23 --> Input Class Initialized
INFO - 2023-07-26 08:54:23 --> Language Class Initialized
INFO - 2023-07-26 08:54:23 --> Loader Class Initialized
INFO - 2023-07-26 08:54:23 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:23 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:23 --> Parser Class Initialized
INFO - 2023-07-26 08:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:23 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:23 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:23 --> Controller Class Initialized
INFO - 2023-07-26 08:54:23 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:23 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:23 --> Model Class Initialized
INFO - 2023-07-26 08:54:23 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:23 --> Total execution time: 0.0185
ERROR - 2023-07-26 08:54:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:23 --> Config Class Initialized
INFO - 2023-07-26 08:54:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:23 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:23 --> URI Class Initialized
INFO - 2023-07-26 08:54:23 --> Router Class Initialized
INFO - 2023-07-26 08:54:23 --> Output Class Initialized
INFO - 2023-07-26 08:54:23 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:23 --> Input Class Initialized
INFO - 2023-07-26 08:54:23 --> Language Class Initialized
INFO - 2023-07-26 08:54:23 --> Loader Class Initialized
INFO - 2023-07-26 08:54:23 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:23 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:23 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:23 --> Parser Class Initialized
INFO - 2023-07-26 08:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:23 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:23 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:23 --> Controller Class Initialized
INFO - 2023-07-26 08:54:23 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:23 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:23 --> Model Class Initialized
INFO - 2023-07-26 08:54:23 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:23 --> Total execution time: 0.0178
ERROR - 2023-07-26 08:54:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:25 --> Config Class Initialized
INFO - 2023-07-26 08:54:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:25 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:25 --> URI Class Initialized
INFO - 2023-07-26 08:54:25 --> Router Class Initialized
INFO - 2023-07-26 08:54:25 --> Output Class Initialized
INFO - 2023-07-26 08:54:25 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:25 --> Input Class Initialized
INFO - 2023-07-26 08:54:25 --> Language Class Initialized
INFO - 2023-07-26 08:54:25 --> Loader Class Initialized
INFO - 2023-07-26 08:54:25 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:25 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:25 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:25 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:25 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:25 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:25 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:25 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:25 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:25 --> Parser Class Initialized
INFO - 2023-07-26 08:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:25 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:25 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:25 --> Controller Class Initialized
INFO - 2023-07-26 08:54:25 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:25 --> Model Class Initialized
INFO - 2023-07-26 08:54:25 --> Model Class Initialized
INFO - 2023-07-26 08:54:25 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:25 --> Total execution time: 0.0208
ERROR - 2023-07-26 08:54:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:29 --> Config Class Initialized
INFO - 2023-07-26 08:54:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:29 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:29 --> URI Class Initialized
INFO - 2023-07-26 08:54:29 --> Router Class Initialized
INFO - 2023-07-26 08:54:29 --> Output Class Initialized
INFO - 2023-07-26 08:54:29 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:29 --> Input Class Initialized
INFO - 2023-07-26 08:54:29 --> Language Class Initialized
INFO - 2023-07-26 08:54:29 --> Loader Class Initialized
INFO - 2023-07-26 08:54:29 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:29 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:29 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:29 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:29 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:29 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:29 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:29 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:29 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:29 --> Parser Class Initialized
INFO - 2023-07-26 08:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:29 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:29 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:29 --> Controller Class Initialized
INFO - 2023-07-26 08:54:29 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:29 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:29 --> Model Class Initialized
INFO - 2023-07-26 08:54:29 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:29 --> Total execution time: 0.0177
ERROR - 2023-07-26 08:54:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:30 --> Config Class Initialized
INFO - 2023-07-26 08:54:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:30 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:30 --> URI Class Initialized
INFO - 2023-07-26 08:54:30 --> Router Class Initialized
INFO - 2023-07-26 08:54:30 --> Output Class Initialized
INFO - 2023-07-26 08:54:30 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:30 --> Input Class Initialized
INFO - 2023-07-26 08:54:30 --> Language Class Initialized
INFO - 2023-07-26 08:54:30 --> Loader Class Initialized
INFO - 2023-07-26 08:54:30 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:30 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:30 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:30 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:30 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:30 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:30 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:30 --> Parser Class Initialized
INFO - 2023-07-26 08:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:30 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:30 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:30 --> Controller Class Initialized
INFO - 2023-07-26 08:54:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:30 --> Model Class Initialized
INFO - 2023-07-26 08:54:30 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:30 --> Total execution time: 0.0183
ERROR - 2023-07-26 08:54:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:31 --> Config Class Initialized
INFO - 2023-07-26 08:54:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:31 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:31 --> URI Class Initialized
INFO - 2023-07-26 08:54:31 --> Router Class Initialized
INFO - 2023-07-26 08:54:31 --> Output Class Initialized
INFO - 2023-07-26 08:54:31 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:31 --> Input Class Initialized
INFO - 2023-07-26 08:54:31 --> Language Class Initialized
INFO - 2023-07-26 08:54:31 --> Loader Class Initialized
INFO - 2023-07-26 08:54:31 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:31 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:31 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:31 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:31 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:31 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:31 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:31 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:31 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:31 --> Parser Class Initialized
INFO - 2023-07-26 08:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:31 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:31 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:31 --> Controller Class Initialized
INFO - 2023-07-26 08:54:31 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:31 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:31 --> Model Class Initialized
INFO - 2023-07-26 08:54:31 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:31 --> Total execution time: 0.0175
ERROR - 2023-07-26 08:54:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:32 --> Config Class Initialized
INFO - 2023-07-26 08:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:32 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:32 --> URI Class Initialized
INFO - 2023-07-26 08:54:32 --> Router Class Initialized
INFO - 2023-07-26 08:54:32 --> Output Class Initialized
INFO - 2023-07-26 08:54:32 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:32 --> Input Class Initialized
INFO - 2023-07-26 08:54:32 --> Language Class Initialized
INFO - 2023-07-26 08:54:32 --> Loader Class Initialized
INFO - 2023-07-26 08:54:32 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:32 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:32 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:32 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:32 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:32 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:32 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:32 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:32 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:32 --> Parser Class Initialized
INFO - 2023-07-26 08:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:32 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:32 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:32 --> Controller Class Initialized
INFO - 2023-07-26 08:54:32 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:32 --> Model Class Initialized
INFO - 2023-07-26 08:54:32 --> Model Class Initialized
INFO - 2023-07-26 08:54:32 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:32 --> Total execution time: 0.0186
ERROR - 2023-07-26 08:54:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:41 --> Config Class Initialized
INFO - 2023-07-26 08:54:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:41 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:41 --> URI Class Initialized
INFO - 2023-07-26 08:54:41 --> Router Class Initialized
INFO - 2023-07-26 08:54:41 --> Output Class Initialized
INFO - 2023-07-26 08:54:41 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:41 --> Input Class Initialized
INFO - 2023-07-26 08:54:41 --> Language Class Initialized
INFO - 2023-07-26 08:54:41 --> Loader Class Initialized
INFO - 2023-07-26 08:54:41 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:41 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:41 --> Parser Class Initialized
INFO - 2023-07-26 08:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:41 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:41 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:41 --> Controller Class Initialized
INFO - 2023-07-26 08:54:41 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:41 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:41 --> Model Class Initialized
INFO - 2023-07-26 08:54:41 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:41 --> Total execution time: 0.0179
ERROR - 2023-07-26 08:54:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:41 --> Config Class Initialized
INFO - 2023-07-26 08:54:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:41 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:41 --> URI Class Initialized
INFO - 2023-07-26 08:54:41 --> Router Class Initialized
INFO - 2023-07-26 08:54:41 --> Output Class Initialized
INFO - 2023-07-26 08:54:41 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:41 --> Input Class Initialized
INFO - 2023-07-26 08:54:41 --> Language Class Initialized
INFO - 2023-07-26 08:54:41 --> Loader Class Initialized
INFO - 2023-07-26 08:54:41 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:41 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:41 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:41 --> Parser Class Initialized
INFO - 2023-07-26 08:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:41 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:41 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:41 --> Controller Class Initialized
INFO - 2023-07-26 08:54:41 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:41 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:41 --> Model Class Initialized
INFO - 2023-07-26 08:54:41 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:41 --> Total execution time: 0.0175
ERROR - 2023-07-26 08:54:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:43 --> Config Class Initialized
INFO - 2023-07-26 08:54:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:43 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:43 --> URI Class Initialized
INFO - 2023-07-26 08:54:43 --> Router Class Initialized
INFO - 2023-07-26 08:54:43 --> Output Class Initialized
INFO - 2023-07-26 08:54:43 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:43 --> Input Class Initialized
INFO - 2023-07-26 08:54:43 --> Language Class Initialized
INFO - 2023-07-26 08:54:43 --> Loader Class Initialized
INFO - 2023-07-26 08:54:43 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:43 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:43 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:43 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:43 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:43 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:43 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:43 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:43 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:43 --> Parser Class Initialized
INFO - 2023-07-26 08:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:43 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:43 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:43 --> Controller Class Initialized
INFO - 2023-07-26 08:54:43 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:43 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:43 --> Model Class Initialized
INFO - 2023-07-26 08:54:43 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:43 --> Total execution time: 0.0178
ERROR - 2023-07-26 08:54:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:54 --> Config Class Initialized
INFO - 2023-07-26 08:54:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:54 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:54 --> URI Class Initialized
INFO - 2023-07-26 08:54:54 --> Router Class Initialized
INFO - 2023-07-26 08:54:54 --> Output Class Initialized
INFO - 2023-07-26 08:54:54 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:54 --> Input Class Initialized
INFO - 2023-07-26 08:54:54 --> Language Class Initialized
INFO - 2023-07-26 08:54:54 --> Loader Class Initialized
INFO - 2023-07-26 08:54:54 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:54 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:54 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:54 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:54 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:54 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:54 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:54 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:54 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:54 --> Parser Class Initialized
INFO - 2023-07-26 08:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:54 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:54 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:54 --> Controller Class Initialized
INFO - 2023-07-26 08:54:54 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:54 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:54 --> Model Class Initialized
INFO - 2023-07-26 08:54:54 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:54 --> Total execution time: 0.0182
ERROR - 2023-07-26 08:54:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:55 --> Config Class Initialized
INFO - 2023-07-26 08:54:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:55 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:55 --> URI Class Initialized
INFO - 2023-07-26 08:54:55 --> Router Class Initialized
INFO - 2023-07-26 08:54:55 --> Output Class Initialized
INFO - 2023-07-26 08:54:55 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:55 --> Input Class Initialized
INFO - 2023-07-26 08:54:55 --> Language Class Initialized
INFO - 2023-07-26 08:54:55 --> Loader Class Initialized
INFO - 2023-07-26 08:54:55 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:55 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:55 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:55 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:55 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:55 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:55 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:55 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:55 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:55 --> Parser Class Initialized
INFO - 2023-07-26 08:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:55 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:55 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:55 --> Controller Class Initialized
INFO - 2023-07-26 08:54:55 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:55 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:55 --> Model Class Initialized
INFO - 2023-07-26 08:54:55 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:55 --> Total execution time: 0.0179
ERROR - 2023-07-26 08:54:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:54:58 --> Config Class Initialized
INFO - 2023-07-26 08:54:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:54:58 --> Utf8 Class Initialized
INFO - 2023-07-26 08:54:58 --> URI Class Initialized
INFO - 2023-07-26 08:54:58 --> Router Class Initialized
INFO - 2023-07-26 08:54:58 --> Output Class Initialized
INFO - 2023-07-26 08:54:58 --> Security Class Initialized
DEBUG - 2023-07-26 08:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:54:58 --> Input Class Initialized
INFO - 2023-07-26 08:54:58 --> Language Class Initialized
INFO - 2023-07-26 08:54:58 --> Loader Class Initialized
INFO - 2023-07-26 08:54:58 --> Helper loaded: url_helper
INFO - 2023-07-26 08:54:58 --> Helper loaded: file_helper
INFO - 2023-07-26 08:54:58 --> Helper loaded: html_helper
INFO - 2023-07-26 08:54:58 --> Helper loaded: text_helper
INFO - 2023-07-26 08:54:58 --> Helper loaded: form_helper
INFO - 2023-07-26 08:54:58 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:54:58 --> Helper loaded: security_helper
INFO - 2023-07-26 08:54:58 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:54:58 --> Database Driver Class Initialized
INFO - 2023-07-26 08:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:54:58 --> Parser Class Initialized
INFO - 2023-07-26 08:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:54:58 --> Pagination Class Initialized
INFO - 2023-07-26 08:54:58 --> Form Validation Class Initialized
INFO - 2023-07-26 08:54:58 --> Controller Class Initialized
INFO - 2023-07-26 08:54:58 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:58 --> Model Class Initialized
DEBUG - 2023-07-26 08:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:54:58 --> Model Class Initialized
INFO - 2023-07-26 08:54:58 --> Final output sent to browser
DEBUG - 2023-07-26 08:54:58 --> Total execution time: 0.0187
ERROR - 2023-07-26 08:55:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:00 --> Config Class Initialized
INFO - 2023-07-26 08:55:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:00 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:00 --> URI Class Initialized
INFO - 2023-07-26 08:55:00 --> Router Class Initialized
INFO - 2023-07-26 08:55:00 --> Output Class Initialized
INFO - 2023-07-26 08:55:00 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:00 --> Input Class Initialized
INFO - 2023-07-26 08:55:00 --> Language Class Initialized
INFO - 2023-07-26 08:55:00 --> Loader Class Initialized
INFO - 2023-07-26 08:55:00 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:00 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:00 --> Parser Class Initialized
INFO - 2023-07-26 08:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:00 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:00 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:00 --> Controller Class Initialized
INFO - 2023-07-26 08:55:00 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:00 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:00 --> Model Class Initialized
INFO - 2023-07-26 08:55:00 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:00 --> Total execution time: 0.0178
ERROR - 2023-07-26 08:55:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:00 --> Config Class Initialized
INFO - 2023-07-26 08:55:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:00 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:00 --> URI Class Initialized
INFO - 2023-07-26 08:55:00 --> Router Class Initialized
INFO - 2023-07-26 08:55:00 --> Output Class Initialized
INFO - 2023-07-26 08:55:00 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:00 --> Input Class Initialized
INFO - 2023-07-26 08:55:00 --> Language Class Initialized
INFO - 2023-07-26 08:55:00 --> Loader Class Initialized
INFO - 2023-07-26 08:55:00 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:00 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:00 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:00 --> Parser Class Initialized
INFO - 2023-07-26 08:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:00 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:00 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:00 --> Controller Class Initialized
INFO - 2023-07-26 08:55:00 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:00 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:00 --> Model Class Initialized
INFO - 2023-07-26 08:55:00 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:00 --> Total execution time: 0.0179
ERROR - 2023-07-26 08:55:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:03 --> Config Class Initialized
INFO - 2023-07-26 08:55:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:03 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:03 --> URI Class Initialized
INFO - 2023-07-26 08:55:03 --> Router Class Initialized
INFO - 2023-07-26 08:55:03 --> Output Class Initialized
INFO - 2023-07-26 08:55:03 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:03 --> Input Class Initialized
INFO - 2023-07-26 08:55:03 --> Language Class Initialized
INFO - 2023-07-26 08:55:03 --> Loader Class Initialized
INFO - 2023-07-26 08:55:03 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:03 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:03 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:03 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:03 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:03 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:03 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:03 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:03 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:03 --> Parser Class Initialized
INFO - 2023-07-26 08:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:03 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:03 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:03 --> Controller Class Initialized
INFO - 2023-07-26 08:55:03 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:03 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:03 --> Model Class Initialized
INFO - 2023-07-26 08:55:03 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:03 --> Total execution time: 0.0180
ERROR - 2023-07-26 08:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:05 --> Config Class Initialized
INFO - 2023-07-26 08:55:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:05 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:05 --> URI Class Initialized
INFO - 2023-07-26 08:55:05 --> Router Class Initialized
INFO - 2023-07-26 08:55:05 --> Output Class Initialized
INFO - 2023-07-26 08:55:05 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:05 --> Input Class Initialized
INFO - 2023-07-26 08:55:05 --> Language Class Initialized
INFO - 2023-07-26 08:55:05 --> Loader Class Initialized
INFO - 2023-07-26 08:55:05 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:05 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:05 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:05 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:05 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:05 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:05 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:05 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:05 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:05 --> Parser Class Initialized
INFO - 2023-07-26 08:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:05 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:05 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:05 --> Controller Class Initialized
INFO - 2023-07-26 08:55:05 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:05 --> Model Class Initialized
INFO - 2023-07-26 08:55:05 --> Model Class Initialized
INFO - 2023-07-26 08:55:05 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:05 --> Total execution time: 0.0205
ERROR - 2023-07-26 08:55:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:23 --> Config Class Initialized
INFO - 2023-07-26 08:55:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:23 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:23 --> URI Class Initialized
INFO - 2023-07-26 08:55:23 --> Router Class Initialized
INFO - 2023-07-26 08:55:23 --> Output Class Initialized
INFO - 2023-07-26 08:55:23 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:23 --> Input Class Initialized
INFO - 2023-07-26 08:55:23 --> Language Class Initialized
INFO - 2023-07-26 08:55:23 --> Loader Class Initialized
INFO - 2023-07-26 08:55:23 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:23 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:23 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:23 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:23 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:23 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:23 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:23 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:23 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:23 --> Parser Class Initialized
INFO - 2023-07-26 08:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:23 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:23 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:23 --> Controller Class Initialized
INFO - 2023-07-26 08:55:23 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:23 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:23 --> Model Class Initialized
INFO - 2023-07-26 08:55:23 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:23 --> Total execution time: 0.0214
ERROR - 2023-07-26 08:55:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:24 --> Config Class Initialized
INFO - 2023-07-26 08:55:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:24 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:24 --> URI Class Initialized
INFO - 2023-07-26 08:55:24 --> Router Class Initialized
INFO - 2023-07-26 08:55:24 --> Output Class Initialized
INFO - 2023-07-26 08:55:24 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:24 --> Input Class Initialized
INFO - 2023-07-26 08:55:24 --> Language Class Initialized
INFO - 2023-07-26 08:55:24 --> Loader Class Initialized
INFO - 2023-07-26 08:55:24 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:24 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:24 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:24 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:24 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:24 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:24 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:24 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:24 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:24 --> Parser Class Initialized
INFO - 2023-07-26 08:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:24 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:24 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:24 --> Controller Class Initialized
INFO - 2023-07-26 08:55:24 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:24 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:24 --> Model Class Initialized
INFO - 2023-07-26 08:55:24 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:24 --> Total execution time: 0.0205
ERROR - 2023-07-26 08:55:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:25 --> Config Class Initialized
INFO - 2023-07-26 08:55:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:25 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:25 --> URI Class Initialized
INFO - 2023-07-26 08:55:25 --> Router Class Initialized
INFO - 2023-07-26 08:55:25 --> Output Class Initialized
INFO - 2023-07-26 08:55:25 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:25 --> Input Class Initialized
INFO - 2023-07-26 08:55:25 --> Language Class Initialized
INFO - 2023-07-26 08:55:25 --> Loader Class Initialized
INFO - 2023-07-26 08:55:25 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:25 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:25 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:25 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:25 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:25 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:25 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:25 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:25 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:25 --> Parser Class Initialized
INFO - 2023-07-26 08:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:25 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:25 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:25 --> Controller Class Initialized
INFO - 2023-07-26 08:55:25 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:25 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:25 --> Model Class Initialized
INFO - 2023-07-26 08:55:25 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:25 --> Total execution time: 0.0169
ERROR - 2023-07-26 08:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:30 --> Config Class Initialized
INFO - 2023-07-26 08:55:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:30 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:30 --> URI Class Initialized
INFO - 2023-07-26 08:55:30 --> Router Class Initialized
INFO - 2023-07-26 08:55:30 --> Output Class Initialized
INFO - 2023-07-26 08:55:30 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:30 --> Input Class Initialized
INFO - 2023-07-26 08:55:30 --> Language Class Initialized
INFO - 2023-07-26 08:55:30 --> Loader Class Initialized
INFO - 2023-07-26 08:55:30 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:30 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:30 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:30 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:30 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:30 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:30 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:30 --> Parser Class Initialized
INFO - 2023-07-26 08:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:30 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:30 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:30 --> Controller Class Initialized
INFO - 2023-07-26 08:55:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:30 --> Model Class Initialized
INFO - 2023-07-26 08:55:30 --> Model Class Initialized
INFO - 2023-07-26 08:55:30 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:30 --> Total execution time: 0.0187
ERROR - 2023-07-26 08:55:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:45 --> Config Class Initialized
INFO - 2023-07-26 08:55:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:45 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:45 --> URI Class Initialized
INFO - 2023-07-26 08:55:45 --> Router Class Initialized
INFO - 2023-07-26 08:55:45 --> Output Class Initialized
INFO - 2023-07-26 08:55:45 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:45 --> Input Class Initialized
INFO - 2023-07-26 08:55:45 --> Language Class Initialized
INFO - 2023-07-26 08:55:45 --> Loader Class Initialized
INFO - 2023-07-26 08:55:45 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:45 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:45 --> Parser Class Initialized
INFO - 2023-07-26 08:55:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:45 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:45 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:45 --> Controller Class Initialized
INFO - 2023-07-26 08:55:45 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:45 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:45 --> Model Class Initialized
INFO - 2023-07-26 08:55:45 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:45 --> Total execution time: 0.0206
ERROR - 2023-07-26 08:55:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:45 --> Config Class Initialized
INFO - 2023-07-26 08:55:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:45 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:45 --> URI Class Initialized
INFO - 2023-07-26 08:55:45 --> Router Class Initialized
INFO - 2023-07-26 08:55:45 --> Output Class Initialized
INFO - 2023-07-26 08:55:45 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:45 --> Input Class Initialized
INFO - 2023-07-26 08:55:45 --> Language Class Initialized
INFO - 2023-07-26 08:55:45 --> Loader Class Initialized
INFO - 2023-07-26 08:55:45 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:45 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:45 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:45 --> Parser Class Initialized
INFO - 2023-07-26 08:55:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:45 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:45 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:45 --> Controller Class Initialized
INFO - 2023-07-26 08:55:45 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:45 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:45 --> Model Class Initialized
INFO - 2023-07-26 08:55:45 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:45 --> Total execution time: 0.0212
ERROR - 2023-07-26 08:55:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:46 --> Config Class Initialized
INFO - 2023-07-26 08:55:46 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:46 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:46 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:46 --> URI Class Initialized
INFO - 2023-07-26 08:55:46 --> Router Class Initialized
INFO - 2023-07-26 08:55:46 --> Output Class Initialized
INFO - 2023-07-26 08:55:46 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:46 --> Input Class Initialized
INFO - 2023-07-26 08:55:46 --> Language Class Initialized
INFO - 2023-07-26 08:55:46 --> Loader Class Initialized
INFO - 2023-07-26 08:55:46 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:46 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:46 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:46 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:46 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:46 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:46 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:46 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:46 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:46 --> Parser Class Initialized
INFO - 2023-07-26 08:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:46 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:46 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:46 --> Controller Class Initialized
INFO - 2023-07-26 08:55:46 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:46 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:46 --> Model Class Initialized
INFO - 2023-07-26 08:55:46 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:46 --> Total execution time: 0.0174
ERROR - 2023-07-26 08:55:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:48 --> Config Class Initialized
INFO - 2023-07-26 08:55:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:48 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:48 --> URI Class Initialized
INFO - 2023-07-26 08:55:48 --> Router Class Initialized
INFO - 2023-07-26 08:55:48 --> Output Class Initialized
INFO - 2023-07-26 08:55:48 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:48 --> Input Class Initialized
INFO - 2023-07-26 08:55:48 --> Language Class Initialized
INFO - 2023-07-26 08:55:48 --> Loader Class Initialized
INFO - 2023-07-26 08:55:48 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:48 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:48 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:48 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:48 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:48 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:48 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:48 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:48 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:48 --> Parser Class Initialized
INFO - 2023-07-26 08:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:48 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:48 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:48 --> Controller Class Initialized
INFO - 2023-07-26 08:55:48 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:48 --> Model Class Initialized
INFO - 2023-07-26 08:55:48 --> Model Class Initialized
INFO - 2023-07-26 08:55:48 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:48 --> Total execution time: 0.0175
ERROR - 2023-07-26 08:55:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:55:59 --> Config Class Initialized
INFO - 2023-07-26 08:55:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:59 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:59 --> URI Class Initialized
INFO - 2023-07-26 08:55:59 --> Router Class Initialized
INFO - 2023-07-26 08:55:59 --> Output Class Initialized
INFO - 2023-07-26 08:55:59 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:59 --> Input Class Initialized
INFO - 2023-07-26 08:55:59 --> Language Class Initialized
INFO - 2023-07-26 08:55:59 --> Loader Class Initialized
INFO - 2023-07-26 08:55:59 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:59 --> Helper loaded: file_helper
INFO - 2023-07-26 08:55:59 --> Helper loaded: html_helper
INFO - 2023-07-26 08:55:59 --> Helper loaded: text_helper
INFO - 2023-07-26 08:55:59 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:59 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:55:59 --> Helper loaded: security_helper
INFO - 2023-07-26 08:55:59 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:55:59 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:59 --> Parser Class Initialized
INFO - 2023-07-26 08:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:55:59 --> Pagination Class Initialized
INFO - 2023-07-26 08:55:59 --> Form Validation Class Initialized
INFO - 2023-07-26 08:55:59 --> Controller Class Initialized
INFO - 2023-07-26 08:55:59 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:59 --> Model Class Initialized
DEBUG - 2023-07-26 08:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:59 --> Model Class Initialized
INFO - 2023-07-26 08:55:59 --> Final output sent to browser
DEBUG - 2023-07-26 08:55:59 --> Total execution time: 0.0185
ERROR - 2023-07-26 08:56:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:56:02 --> Config Class Initialized
INFO - 2023-07-26 08:56:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:56:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:56:02 --> Utf8 Class Initialized
INFO - 2023-07-26 08:56:02 --> URI Class Initialized
INFO - 2023-07-26 08:56:02 --> Router Class Initialized
INFO - 2023-07-26 08:56:02 --> Output Class Initialized
INFO - 2023-07-26 08:56:02 --> Security Class Initialized
DEBUG - 2023-07-26 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:56:02 --> Input Class Initialized
INFO - 2023-07-26 08:56:02 --> Language Class Initialized
INFO - 2023-07-26 08:56:02 --> Loader Class Initialized
INFO - 2023-07-26 08:56:02 --> Helper loaded: url_helper
INFO - 2023-07-26 08:56:02 --> Helper loaded: file_helper
INFO - 2023-07-26 08:56:02 --> Helper loaded: html_helper
INFO - 2023-07-26 08:56:02 --> Helper loaded: text_helper
INFO - 2023-07-26 08:56:02 --> Helper loaded: form_helper
INFO - 2023-07-26 08:56:02 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:56:02 --> Helper loaded: security_helper
INFO - 2023-07-26 08:56:02 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:56:02 --> Database Driver Class Initialized
INFO - 2023-07-26 08:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:56:02 --> Parser Class Initialized
INFO - 2023-07-26 08:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:56:02 --> Pagination Class Initialized
INFO - 2023-07-26 08:56:02 --> Form Validation Class Initialized
INFO - 2023-07-26 08:56:02 --> Controller Class Initialized
INFO - 2023-07-26 08:56:02 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:02 --> Model Class Initialized
INFO - 2023-07-26 08:56:02 --> Model Class Initialized
INFO - 2023-07-26 08:56:02 --> Final output sent to browser
DEBUG - 2023-07-26 08:56:02 --> Total execution time: 0.0189
ERROR - 2023-07-26 08:56:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:56:25 --> Config Class Initialized
INFO - 2023-07-26 08:56:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:56:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:56:25 --> Utf8 Class Initialized
INFO - 2023-07-26 08:56:25 --> URI Class Initialized
INFO - 2023-07-26 08:56:25 --> Router Class Initialized
INFO - 2023-07-26 08:56:25 --> Output Class Initialized
INFO - 2023-07-26 08:56:25 --> Security Class Initialized
DEBUG - 2023-07-26 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:56:25 --> Input Class Initialized
INFO - 2023-07-26 08:56:25 --> Language Class Initialized
INFO - 2023-07-26 08:56:25 --> Loader Class Initialized
INFO - 2023-07-26 08:56:25 --> Helper loaded: url_helper
INFO - 2023-07-26 08:56:25 --> Helper loaded: file_helper
INFO - 2023-07-26 08:56:25 --> Helper loaded: html_helper
INFO - 2023-07-26 08:56:25 --> Helper loaded: text_helper
INFO - 2023-07-26 08:56:25 --> Helper loaded: form_helper
INFO - 2023-07-26 08:56:25 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:56:25 --> Helper loaded: security_helper
INFO - 2023-07-26 08:56:25 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:56:25 --> Database Driver Class Initialized
INFO - 2023-07-26 08:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:56:25 --> Parser Class Initialized
INFO - 2023-07-26 08:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:56:25 --> Pagination Class Initialized
INFO - 2023-07-26 08:56:25 --> Form Validation Class Initialized
INFO - 2023-07-26 08:56:25 --> Controller Class Initialized
INFO - 2023-07-26 08:56:25 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:25 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:25 --> Model Class Initialized
INFO - 2023-07-26 08:56:25 --> Final output sent to browser
DEBUG - 2023-07-26 08:56:25 --> Total execution time: 0.0209
ERROR - 2023-07-26 08:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:56:30 --> Config Class Initialized
INFO - 2023-07-26 08:56:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:56:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:56:30 --> Utf8 Class Initialized
INFO - 2023-07-26 08:56:30 --> URI Class Initialized
INFO - 2023-07-26 08:56:30 --> Router Class Initialized
INFO - 2023-07-26 08:56:30 --> Output Class Initialized
INFO - 2023-07-26 08:56:30 --> Security Class Initialized
DEBUG - 2023-07-26 08:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:56:30 --> Input Class Initialized
INFO - 2023-07-26 08:56:30 --> Language Class Initialized
INFO - 2023-07-26 08:56:30 --> Loader Class Initialized
INFO - 2023-07-26 08:56:30 --> Helper loaded: url_helper
INFO - 2023-07-26 08:56:30 --> Helper loaded: file_helper
INFO - 2023-07-26 08:56:30 --> Helper loaded: html_helper
INFO - 2023-07-26 08:56:30 --> Helper loaded: text_helper
INFO - 2023-07-26 08:56:30 --> Helper loaded: form_helper
INFO - 2023-07-26 08:56:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:56:30 --> Helper loaded: security_helper
INFO - 2023-07-26 08:56:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:56:30 --> Database Driver Class Initialized
INFO - 2023-07-26 08:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:56:30 --> Parser Class Initialized
INFO - 2023-07-26 08:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:56:30 --> Pagination Class Initialized
INFO - 2023-07-26 08:56:30 --> Form Validation Class Initialized
INFO - 2023-07-26 08:56:30 --> Controller Class Initialized
INFO - 2023-07-26 08:56:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:30 --> Model Class Initialized
INFO - 2023-07-26 08:56:30 --> Model Class Initialized
INFO - 2023-07-26 08:56:30 --> Final output sent to browser
DEBUG - 2023-07-26 08:56:30 --> Total execution time: 0.0202
ERROR - 2023-07-26 08:56:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:56:52 --> Config Class Initialized
INFO - 2023-07-26 08:56:52 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:56:52 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:56:52 --> Utf8 Class Initialized
INFO - 2023-07-26 08:56:52 --> URI Class Initialized
INFO - 2023-07-26 08:56:52 --> Router Class Initialized
INFO - 2023-07-26 08:56:52 --> Output Class Initialized
INFO - 2023-07-26 08:56:52 --> Security Class Initialized
DEBUG - 2023-07-26 08:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:56:52 --> Input Class Initialized
INFO - 2023-07-26 08:56:52 --> Language Class Initialized
INFO - 2023-07-26 08:56:52 --> Loader Class Initialized
INFO - 2023-07-26 08:56:52 --> Helper loaded: url_helper
INFO - 2023-07-26 08:56:52 --> Helper loaded: file_helper
INFO - 2023-07-26 08:56:52 --> Helper loaded: html_helper
INFO - 2023-07-26 08:56:52 --> Helper loaded: text_helper
INFO - 2023-07-26 08:56:52 --> Helper loaded: form_helper
INFO - 2023-07-26 08:56:52 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:56:52 --> Helper loaded: security_helper
INFO - 2023-07-26 08:56:52 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:56:52 --> Database Driver Class Initialized
INFO - 2023-07-26 08:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:56:52 --> Parser Class Initialized
INFO - 2023-07-26 08:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:56:52 --> Pagination Class Initialized
INFO - 2023-07-26 08:56:52 --> Form Validation Class Initialized
INFO - 2023-07-26 08:56:52 --> Controller Class Initialized
INFO - 2023-07-26 08:56:52 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:52 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:52 --> Model Class Initialized
INFO - 2023-07-26 08:56:52 --> Final output sent to browser
DEBUG - 2023-07-26 08:56:52 --> Total execution time: 0.0215
ERROR - 2023-07-26 08:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:56:53 --> Config Class Initialized
INFO - 2023-07-26 08:56:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:56:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:56:53 --> Utf8 Class Initialized
INFO - 2023-07-26 08:56:53 --> URI Class Initialized
INFO - 2023-07-26 08:56:53 --> Router Class Initialized
INFO - 2023-07-26 08:56:53 --> Output Class Initialized
INFO - 2023-07-26 08:56:53 --> Security Class Initialized
DEBUG - 2023-07-26 08:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:56:53 --> Input Class Initialized
INFO - 2023-07-26 08:56:53 --> Language Class Initialized
INFO - 2023-07-26 08:56:53 --> Loader Class Initialized
INFO - 2023-07-26 08:56:53 --> Helper loaded: url_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: file_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: html_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: text_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: form_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: security_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:56:53 --> Database Driver Class Initialized
INFO - 2023-07-26 08:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:56:53 --> Parser Class Initialized
INFO - 2023-07-26 08:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:56:53 --> Pagination Class Initialized
INFO - 2023-07-26 08:56:53 --> Form Validation Class Initialized
INFO - 2023-07-26 08:56:53 --> Controller Class Initialized
INFO - 2023-07-26 08:56:53 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:53 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:53 --> Model Class Initialized
INFO - 2023-07-26 08:56:53 --> Final output sent to browser
DEBUG - 2023-07-26 08:56:53 --> Total execution time: 0.0181
ERROR - 2023-07-26 08:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:56:53 --> Config Class Initialized
INFO - 2023-07-26 08:56:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:56:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:56:53 --> Utf8 Class Initialized
INFO - 2023-07-26 08:56:53 --> URI Class Initialized
INFO - 2023-07-26 08:56:53 --> Router Class Initialized
INFO - 2023-07-26 08:56:53 --> Output Class Initialized
INFO - 2023-07-26 08:56:53 --> Security Class Initialized
DEBUG - 2023-07-26 08:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:56:53 --> Input Class Initialized
INFO - 2023-07-26 08:56:53 --> Language Class Initialized
INFO - 2023-07-26 08:56:53 --> Loader Class Initialized
INFO - 2023-07-26 08:56:53 --> Helper loaded: url_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: file_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: html_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: text_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: form_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: security_helper
INFO - 2023-07-26 08:56:53 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:56:53 --> Database Driver Class Initialized
INFO - 2023-07-26 08:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:56:53 --> Parser Class Initialized
INFO - 2023-07-26 08:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:56:53 --> Pagination Class Initialized
INFO - 2023-07-26 08:56:53 --> Form Validation Class Initialized
INFO - 2023-07-26 08:56:53 --> Controller Class Initialized
INFO - 2023-07-26 08:56:53 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:53 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:53 --> Model Class Initialized
INFO - 2023-07-26 08:56:53 --> Final output sent to browser
DEBUG - 2023-07-26 08:56:53 --> Total execution time: 0.0179
ERROR - 2023-07-26 08:56:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:56:55 --> Config Class Initialized
INFO - 2023-07-26 08:56:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:56:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:56:55 --> Utf8 Class Initialized
INFO - 2023-07-26 08:56:55 --> URI Class Initialized
INFO - 2023-07-26 08:56:55 --> Router Class Initialized
INFO - 2023-07-26 08:56:55 --> Output Class Initialized
INFO - 2023-07-26 08:56:55 --> Security Class Initialized
DEBUG - 2023-07-26 08:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:56:55 --> Input Class Initialized
INFO - 2023-07-26 08:56:55 --> Language Class Initialized
INFO - 2023-07-26 08:56:55 --> Loader Class Initialized
INFO - 2023-07-26 08:56:55 --> Helper loaded: url_helper
INFO - 2023-07-26 08:56:55 --> Helper loaded: file_helper
INFO - 2023-07-26 08:56:55 --> Helper loaded: html_helper
INFO - 2023-07-26 08:56:55 --> Helper loaded: text_helper
INFO - 2023-07-26 08:56:55 --> Helper loaded: form_helper
INFO - 2023-07-26 08:56:55 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:56:55 --> Helper loaded: security_helper
INFO - 2023-07-26 08:56:55 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:56:55 --> Database Driver Class Initialized
INFO - 2023-07-26 08:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:56:55 --> Parser Class Initialized
INFO - 2023-07-26 08:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:56:55 --> Pagination Class Initialized
INFO - 2023-07-26 08:56:55 --> Form Validation Class Initialized
INFO - 2023-07-26 08:56:55 --> Controller Class Initialized
INFO - 2023-07-26 08:56:55 --> Model Class Initialized
DEBUG - 2023-07-26 08:56:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:56:55 --> Model Class Initialized
INFO - 2023-07-26 08:56:55 --> Model Class Initialized
INFO - 2023-07-26 08:56:55 --> Final output sent to browser
DEBUG - 2023-07-26 08:56:55 --> Total execution time: 0.0188
ERROR - 2023-07-26 08:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:07 --> Config Class Initialized
INFO - 2023-07-26 08:57:07 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:07 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:07 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:07 --> URI Class Initialized
INFO - 2023-07-26 08:57:07 --> Router Class Initialized
INFO - 2023-07-26 08:57:07 --> Output Class Initialized
INFO - 2023-07-26 08:57:07 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:07 --> Input Class Initialized
INFO - 2023-07-26 08:57:07 --> Language Class Initialized
INFO - 2023-07-26 08:57:07 --> Loader Class Initialized
INFO - 2023-07-26 08:57:07 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:07 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:07 --> Parser Class Initialized
INFO - 2023-07-26 08:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:07 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:07 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:07 --> Controller Class Initialized
INFO - 2023-07-26 08:57:07 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:07 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:07 --> Model Class Initialized
INFO - 2023-07-26 08:57:07 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:07 --> Total execution time: 0.0212
ERROR - 2023-07-26 08:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:07 --> Config Class Initialized
INFO - 2023-07-26 08:57:07 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:07 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:07 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:07 --> URI Class Initialized
INFO - 2023-07-26 08:57:07 --> Router Class Initialized
INFO - 2023-07-26 08:57:07 --> Output Class Initialized
INFO - 2023-07-26 08:57:07 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:07 --> Input Class Initialized
INFO - 2023-07-26 08:57:07 --> Language Class Initialized
INFO - 2023-07-26 08:57:07 --> Loader Class Initialized
INFO - 2023-07-26 08:57:07 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:07 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:07 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:07 --> Parser Class Initialized
INFO - 2023-07-26 08:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:07 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:07 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:07 --> Controller Class Initialized
INFO - 2023-07-26 08:57:07 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:07 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:07 --> Model Class Initialized
INFO - 2023-07-26 08:57:07 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:07 --> Total execution time: 0.0175
ERROR - 2023-07-26 08:57:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:08 --> Config Class Initialized
INFO - 2023-07-26 08:57:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:08 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:08 --> URI Class Initialized
INFO - 2023-07-26 08:57:08 --> Router Class Initialized
INFO - 2023-07-26 08:57:08 --> Output Class Initialized
INFO - 2023-07-26 08:57:08 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:08 --> Input Class Initialized
INFO - 2023-07-26 08:57:08 --> Language Class Initialized
INFO - 2023-07-26 08:57:08 --> Loader Class Initialized
INFO - 2023-07-26 08:57:08 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:08 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:08 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:08 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:08 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:08 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:08 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:08 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:08 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:08 --> Parser Class Initialized
INFO - 2023-07-26 08:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:08 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:08 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:08 --> Controller Class Initialized
INFO - 2023-07-26 08:57:08 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:08 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:08 --> Model Class Initialized
INFO - 2023-07-26 08:57:08 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:08 --> Total execution time: 0.0175
ERROR - 2023-07-26 08:57:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:09 --> Config Class Initialized
INFO - 2023-07-26 08:57:09 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:09 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:09 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:09 --> URI Class Initialized
INFO - 2023-07-26 08:57:09 --> Router Class Initialized
INFO - 2023-07-26 08:57:09 --> Output Class Initialized
INFO - 2023-07-26 08:57:09 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:09 --> Input Class Initialized
INFO - 2023-07-26 08:57:09 --> Language Class Initialized
INFO - 2023-07-26 08:57:09 --> Loader Class Initialized
INFO - 2023-07-26 08:57:09 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:09 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:09 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:09 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:09 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:09 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:09 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:09 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:09 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:09 --> Parser Class Initialized
INFO - 2023-07-26 08:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:09 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:09 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:09 --> Controller Class Initialized
INFO - 2023-07-26 08:57:09 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:09 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:09 --> Model Class Initialized
INFO - 2023-07-26 08:57:09 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:09 --> Total execution time: 0.0213
ERROR - 2023-07-26 08:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:10 --> Config Class Initialized
INFO - 2023-07-26 08:57:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:10 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:10 --> URI Class Initialized
INFO - 2023-07-26 08:57:10 --> Router Class Initialized
INFO - 2023-07-26 08:57:10 --> Output Class Initialized
INFO - 2023-07-26 08:57:10 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:10 --> Input Class Initialized
INFO - 2023-07-26 08:57:10 --> Language Class Initialized
INFO - 2023-07-26 08:57:10 --> Loader Class Initialized
INFO - 2023-07-26 08:57:10 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:10 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:10 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:10 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:10 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:10 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:10 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:10 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:10 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:10 --> Parser Class Initialized
INFO - 2023-07-26 08:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:10 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:10 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:10 --> Controller Class Initialized
INFO - 2023-07-26 08:57:10 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:10 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:10 --> Model Class Initialized
INFO - 2023-07-26 08:57:10 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:10 --> Total execution time: 0.0173
ERROR - 2023-07-26 08:57:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:13 --> Config Class Initialized
INFO - 2023-07-26 08:57:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:13 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:13 --> URI Class Initialized
INFO - 2023-07-26 08:57:13 --> Router Class Initialized
INFO - 2023-07-26 08:57:13 --> Output Class Initialized
INFO - 2023-07-26 08:57:13 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:13 --> Input Class Initialized
INFO - 2023-07-26 08:57:13 --> Language Class Initialized
INFO - 2023-07-26 08:57:13 --> Loader Class Initialized
INFO - 2023-07-26 08:57:13 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:13 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:13 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:13 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:13 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:13 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:13 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:13 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:13 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:13 --> Parser Class Initialized
INFO - 2023-07-26 08:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:13 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:13 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:13 --> Controller Class Initialized
INFO - 2023-07-26 08:57:13 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:13 --> Model Class Initialized
INFO - 2023-07-26 08:57:13 --> Model Class Initialized
INFO - 2023-07-26 08:57:13 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:13 --> Total execution time: 0.0198
ERROR - 2023-07-26 08:57:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:29 --> Config Class Initialized
INFO - 2023-07-26 08:57:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:29 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:29 --> URI Class Initialized
INFO - 2023-07-26 08:57:29 --> Router Class Initialized
INFO - 2023-07-26 08:57:29 --> Output Class Initialized
INFO - 2023-07-26 08:57:29 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:29 --> Input Class Initialized
INFO - 2023-07-26 08:57:29 --> Language Class Initialized
INFO - 2023-07-26 08:57:29 --> Loader Class Initialized
INFO - 2023-07-26 08:57:29 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:29 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:29 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:29 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:29 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:29 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:29 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:29 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:29 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:29 --> Parser Class Initialized
INFO - 2023-07-26 08:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:29 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:29 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:29 --> Controller Class Initialized
INFO - 2023-07-26 08:57:29 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:29 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:29 --> Model Class Initialized
INFO - 2023-07-26 08:57:29 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:29 --> Total execution time: 0.0210
ERROR - 2023-07-26 08:57:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:30 --> Config Class Initialized
INFO - 2023-07-26 08:57:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:30 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:30 --> URI Class Initialized
INFO - 2023-07-26 08:57:30 --> Router Class Initialized
INFO - 2023-07-26 08:57:30 --> Output Class Initialized
INFO - 2023-07-26 08:57:30 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:30 --> Input Class Initialized
INFO - 2023-07-26 08:57:30 --> Language Class Initialized
INFO - 2023-07-26 08:57:30 --> Loader Class Initialized
INFO - 2023-07-26 08:57:30 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:30 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:30 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:30 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:30 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:30 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:30 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:30 --> Parser Class Initialized
INFO - 2023-07-26 08:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:30 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:30 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:30 --> Controller Class Initialized
INFO - 2023-07-26 08:57:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:30 --> Model Class Initialized
INFO - 2023-07-26 08:57:30 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:30 --> Total execution time: 0.0182
ERROR - 2023-07-26 08:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:31 --> Config Class Initialized
INFO - 2023-07-26 08:57:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:31 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:31 --> URI Class Initialized
INFO - 2023-07-26 08:57:31 --> Router Class Initialized
INFO - 2023-07-26 08:57:31 --> Output Class Initialized
INFO - 2023-07-26 08:57:31 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:31 --> Input Class Initialized
INFO - 2023-07-26 08:57:31 --> Language Class Initialized
INFO - 2023-07-26 08:57:31 --> Loader Class Initialized
INFO - 2023-07-26 08:57:31 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:31 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:31 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:31 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:31 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:31 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:31 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:31 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:31 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:31 --> Parser Class Initialized
INFO - 2023-07-26 08:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:31 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:31 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:31 --> Controller Class Initialized
INFO - 2023-07-26 08:57:31 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:31 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:31 --> Model Class Initialized
INFO - 2023-07-26 08:57:31 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:31 --> Total execution time: 0.0168
ERROR - 2023-07-26 08:57:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:33 --> Config Class Initialized
INFO - 2023-07-26 08:57:33 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:33 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:33 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:33 --> URI Class Initialized
INFO - 2023-07-26 08:57:33 --> Router Class Initialized
INFO - 2023-07-26 08:57:33 --> Output Class Initialized
INFO - 2023-07-26 08:57:33 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:33 --> Input Class Initialized
INFO - 2023-07-26 08:57:33 --> Language Class Initialized
INFO - 2023-07-26 08:57:33 --> Loader Class Initialized
INFO - 2023-07-26 08:57:33 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:33 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:33 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:33 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:33 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:33 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:33 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:33 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:33 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:33 --> Parser Class Initialized
INFO - 2023-07-26 08:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:33 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:33 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:33 --> Controller Class Initialized
INFO - 2023-07-26 08:57:33 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:33 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:33 --> Model Class Initialized
INFO - 2023-07-26 08:57:33 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:33 --> Total execution time: 0.0179
ERROR - 2023-07-26 08:57:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:34 --> Config Class Initialized
INFO - 2023-07-26 08:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:34 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:34 --> URI Class Initialized
INFO - 2023-07-26 08:57:34 --> Router Class Initialized
INFO - 2023-07-26 08:57:34 --> Output Class Initialized
INFO - 2023-07-26 08:57:34 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:34 --> Input Class Initialized
INFO - 2023-07-26 08:57:34 --> Language Class Initialized
INFO - 2023-07-26 08:57:34 --> Loader Class Initialized
INFO - 2023-07-26 08:57:34 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:34 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:34 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:34 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:34 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:34 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:34 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:34 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:34 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:34 --> Parser Class Initialized
INFO - 2023-07-26 08:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:34 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:34 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:34 --> Controller Class Initialized
INFO - 2023-07-26 08:57:34 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:34 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:34 --> Model Class Initialized
INFO - 2023-07-26 08:57:34 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:34 --> Total execution time: 0.0177
ERROR - 2023-07-26 08:57:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:35 --> Config Class Initialized
INFO - 2023-07-26 08:57:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:35 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:35 --> URI Class Initialized
INFO - 2023-07-26 08:57:35 --> Router Class Initialized
INFO - 2023-07-26 08:57:35 --> Output Class Initialized
INFO - 2023-07-26 08:57:35 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:35 --> Input Class Initialized
INFO - 2023-07-26 08:57:35 --> Language Class Initialized
INFO - 2023-07-26 08:57:35 --> Loader Class Initialized
INFO - 2023-07-26 08:57:35 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:35 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:35 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:35 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:35 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:35 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:35 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:35 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:35 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:35 --> Parser Class Initialized
INFO - 2023-07-26 08:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:35 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:35 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:35 --> Controller Class Initialized
INFO - 2023-07-26 08:57:35 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:35 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:35 --> Model Class Initialized
INFO - 2023-07-26 08:57:35 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:35 --> Total execution time: 0.0179
ERROR - 2023-07-26 08:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:36 --> Config Class Initialized
INFO - 2023-07-26 08:57:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:36 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:36 --> URI Class Initialized
INFO - 2023-07-26 08:57:36 --> Router Class Initialized
INFO - 2023-07-26 08:57:36 --> Output Class Initialized
INFO - 2023-07-26 08:57:36 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:36 --> Input Class Initialized
INFO - 2023-07-26 08:57:36 --> Language Class Initialized
INFO - 2023-07-26 08:57:36 --> Loader Class Initialized
INFO - 2023-07-26 08:57:36 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:36 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:36 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:36 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:36 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:36 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:36 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:36 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:36 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:36 --> Parser Class Initialized
INFO - 2023-07-26 08:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:36 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:36 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:36 --> Controller Class Initialized
INFO - 2023-07-26 08:57:36 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:36 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:36 --> Model Class Initialized
INFO - 2023-07-26 08:57:36 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:36 --> Total execution time: 0.0179
ERROR - 2023-07-26 08:57:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:38 --> Config Class Initialized
INFO - 2023-07-26 08:57:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:38 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:38 --> URI Class Initialized
INFO - 2023-07-26 08:57:38 --> Router Class Initialized
INFO - 2023-07-26 08:57:38 --> Output Class Initialized
INFO - 2023-07-26 08:57:38 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:38 --> Input Class Initialized
INFO - 2023-07-26 08:57:38 --> Language Class Initialized
INFO - 2023-07-26 08:57:38 --> Loader Class Initialized
INFO - 2023-07-26 08:57:38 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:38 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:38 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:38 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:38 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:38 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:38 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:38 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:38 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:38 --> Parser Class Initialized
INFO - 2023-07-26 08:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:38 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:38 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:38 --> Controller Class Initialized
INFO - 2023-07-26 08:57:38 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:38 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:38 --> Model Class Initialized
INFO - 2023-07-26 08:57:38 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:38 --> Total execution time: 0.0175
ERROR - 2023-07-26 08:57:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:41 --> Config Class Initialized
INFO - 2023-07-26 08:57:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:41 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:41 --> URI Class Initialized
INFO - 2023-07-26 08:57:41 --> Router Class Initialized
INFO - 2023-07-26 08:57:41 --> Output Class Initialized
INFO - 2023-07-26 08:57:41 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:41 --> Input Class Initialized
INFO - 2023-07-26 08:57:41 --> Language Class Initialized
INFO - 2023-07-26 08:57:41 --> Loader Class Initialized
INFO - 2023-07-26 08:57:41 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:41 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:41 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:41 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:41 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:41 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:41 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:41 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:41 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:41 --> Parser Class Initialized
INFO - 2023-07-26 08:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:41 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:41 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:41 --> Controller Class Initialized
INFO - 2023-07-26 08:57:41 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:41 --> Model Class Initialized
INFO - 2023-07-26 08:57:41 --> Model Class Initialized
INFO - 2023-07-26 08:57:41 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:41 --> Total execution time: 0.0193
ERROR - 2023-07-26 08:57:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:57:59 --> Config Class Initialized
INFO - 2023-07-26 08:57:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:59 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:59 --> URI Class Initialized
INFO - 2023-07-26 08:57:59 --> Router Class Initialized
INFO - 2023-07-26 08:57:59 --> Output Class Initialized
INFO - 2023-07-26 08:57:59 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:59 --> Input Class Initialized
INFO - 2023-07-26 08:57:59 --> Language Class Initialized
INFO - 2023-07-26 08:57:59 --> Loader Class Initialized
INFO - 2023-07-26 08:57:59 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:59 --> Helper loaded: file_helper
INFO - 2023-07-26 08:57:59 --> Helper loaded: html_helper
INFO - 2023-07-26 08:57:59 --> Helper loaded: text_helper
INFO - 2023-07-26 08:57:59 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:59 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:57:59 --> Helper loaded: security_helper
INFO - 2023-07-26 08:57:59 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:57:59 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:59 --> Parser Class Initialized
INFO - 2023-07-26 08:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:57:59 --> Pagination Class Initialized
INFO - 2023-07-26 08:57:59 --> Form Validation Class Initialized
INFO - 2023-07-26 08:57:59 --> Controller Class Initialized
INFO - 2023-07-26 08:57:59 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:59 --> Model Class Initialized
DEBUG - 2023-07-26 08:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:59 --> Model Class Initialized
INFO - 2023-07-26 08:57:59 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:59 --> Total execution time: 0.0209
ERROR - 2023-07-26 08:58:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:01 --> Config Class Initialized
INFO - 2023-07-26 08:58:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:01 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:01 --> URI Class Initialized
INFO - 2023-07-26 08:58:01 --> Router Class Initialized
INFO - 2023-07-26 08:58:01 --> Output Class Initialized
INFO - 2023-07-26 08:58:01 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:01 --> Input Class Initialized
INFO - 2023-07-26 08:58:01 --> Language Class Initialized
INFO - 2023-07-26 08:58:01 --> Loader Class Initialized
INFO - 2023-07-26 08:58:01 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:01 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:01 --> Parser Class Initialized
INFO - 2023-07-26 08:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:01 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:01 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:01 --> Controller Class Initialized
INFO - 2023-07-26 08:58:01 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:01 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:01 --> Model Class Initialized
INFO - 2023-07-26 08:58:01 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:01 --> Total execution time: 0.0169
ERROR - 2023-07-26 08:58:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:01 --> Config Class Initialized
INFO - 2023-07-26 08:58:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:01 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:01 --> URI Class Initialized
INFO - 2023-07-26 08:58:01 --> Router Class Initialized
INFO - 2023-07-26 08:58:01 --> Output Class Initialized
INFO - 2023-07-26 08:58:01 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:01 --> Input Class Initialized
INFO - 2023-07-26 08:58:01 --> Language Class Initialized
INFO - 2023-07-26 08:58:01 --> Loader Class Initialized
INFO - 2023-07-26 08:58:01 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:01 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:01 --> Parser Class Initialized
INFO - 2023-07-26 08:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:01 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:01 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:01 --> Controller Class Initialized
INFO - 2023-07-26 08:58:01 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:01 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:01 --> Model Class Initialized
INFO - 2023-07-26 08:58:01 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:01 --> Total execution time: 0.0250
ERROR - 2023-07-26 08:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:04 --> Config Class Initialized
INFO - 2023-07-26 08:58:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:04 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:04 --> URI Class Initialized
INFO - 2023-07-26 08:58:04 --> Router Class Initialized
INFO - 2023-07-26 08:58:04 --> Output Class Initialized
INFO - 2023-07-26 08:58:04 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:04 --> Input Class Initialized
INFO - 2023-07-26 08:58:04 --> Language Class Initialized
INFO - 2023-07-26 08:58:04 --> Loader Class Initialized
INFO - 2023-07-26 08:58:04 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:04 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:04 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:04 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:04 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:04 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:04 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:04 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:04 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:04 --> Parser Class Initialized
INFO - 2023-07-26 08:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:04 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:04 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:04 --> Controller Class Initialized
INFO - 2023-07-26 08:58:04 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:04 --> Model Class Initialized
INFO - 2023-07-26 08:58:04 --> Model Class Initialized
INFO - 2023-07-26 08:58:04 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:04 --> Total execution time: 0.0183
ERROR - 2023-07-26 08:58:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:47 --> Config Class Initialized
INFO - 2023-07-26 08:58:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:47 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:47 --> URI Class Initialized
INFO - 2023-07-26 08:58:47 --> Router Class Initialized
INFO - 2023-07-26 08:58:47 --> Output Class Initialized
INFO - 2023-07-26 08:58:47 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:47 --> Input Class Initialized
INFO - 2023-07-26 08:58:47 --> Language Class Initialized
INFO - 2023-07-26 08:58:47 --> Loader Class Initialized
INFO - 2023-07-26 08:58:47 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:47 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:47 --> Parser Class Initialized
INFO - 2023-07-26 08:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:47 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:47 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:47 --> Controller Class Initialized
INFO - 2023-07-26 08:58:47 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:47 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:47 --> Model Class Initialized
INFO - 2023-07-26 08:58:47 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:47 --> Total execution time: 0.0217
ERROR - 2023-07-26 08:58:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:47 --> Config Class Initialized
INFO - 2023-07-26 08:58:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:47 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:47 --> URI Class Initialized
INFO - 2023-07-26 08:58:47 --> Router Class Initialized
INFO - 2023-07-26 08:58:47 --> Output Class Initialized
INFO - 2023-07-26 08:58:47 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:47 --> Input Class Initialized
INFO - 2023-07-26 08:58:47 --> Language Class Initialized
INFO - 2023-07-26 08:58:47 --> Loader Class Initialized
INFO - 2023-07-26 08:58:47 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:47 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:47 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:47 --> Parser Class Initialized
INFO - 2023-07-26 08:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:47 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:47 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:47 --> Controller Class Initialized
INFO - 2023-07-26 08:58:47 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:47 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:47 --> Model Class Initialized
INFO - 2023-07-26 08:58:47 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:47 --> Total execution time: 0.0177
ERROR - 2023-07-26 08:58:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:49 --> Config Class Initialized
INFO - 2023-07-26 08:58:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:49 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:49 --> URI Class Initialized
INFO - 2023-07-26 08:58:49 --> Router Class Initialized
INFO - 2023-07-26 08:58:49 --> Output Class Initialized
INFO - 2023-07-26 08:58:49 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:49 --> Input Class Initialized
INFO - 2023-07-26 08:58:49 --> Language Class Initialized
INFO - 2023-07-26 08:58:49 --> Loader Class Initialized
INFO - 2023-07-26 08:58:49 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:49 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:49 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:49 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:49 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:49 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:49 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:49 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:49 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:49 --> Parser Class Initialized
INFO - 2023-07-26 08:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:49 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:49 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:49 --> Controller Class Initialized
INFO - 2023-07-26 08:58:49 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:49 --> Model Class Initialized
INFO - 2023-07-26 08:58:49 --> Model Class Initialized
INFO - 2023-07-26 08:58:49 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:49 --> Total execution time: 0.0193
ERROR - 2023-07-26 08:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:56 --> Config Class Initialized
INFO - 2023-07-26 08:58:56 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:56 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:56 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:56 --> URI Class Initialized
INFO - 2023-07-26 08:58:56 --> Router Class Initialized
INFO - 2023-07-26 08:58:56 --> Output Class Initialized
INFO - 2023-07-26 08:58:56 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:56 --> Input Class Initialized
INFO - 2023-07-26 08:58:56 --> Language Class Initialized
INFO - 2023-07-26 08:58:56 --> Loader Class Initialized
INFO - 2023-07-26 08:58:56 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:56 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:56 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:56 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:56 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:56 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:56 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:56 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:56 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:56 --> Parser Class Initialized
INFO - 2023-07-26 08:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:56 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:56 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:56 --> Controller Class Initialized
INFO - 2023-07-26 08:58:56 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:56 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:56 --> Model Class Initialized
INFO - 2023-07-26 08:58:56 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:56 --> Total execution time: 0.0170
ERROR - 2023-07-26 08:58:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:57 --> Config Class Initialized
INFO - 2023-07-26 08:58:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:57 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:57 --> URI Class Initialized
INFO - 2023-07-26 08:58:57 --> Router Class Initialized
INFO - 2023-07-26 08:58:57 --> Output Class Initialized
INFO - 2023-07-26 08:58:57 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:57 --> Input Class Initialized
INFO - 2023-07-26 08:58:57 --> Language Class Initialized
INFO - 2023-07-26 08:58:57 --> Loader Class Initialized
INFO - 2023-07-26 08:58:57 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:57 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:57 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:57 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:57 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:57 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:57 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:57 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:57 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:57 --> Parser Class Initialized
INFO - 2023-07-26 08:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:57 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:57 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:57 --> Controller Class Initialized
INFO - 2023-07-26 08:58:57 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:57 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:57 --> Model Class Initialized
INFO - 2023-07-26 08:58:57 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:57 --> Total execution time: 0.0177
ERROR - 2023-07-26 08:58:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:58:58 --> Config Class Initialized
INFO - 2023-07-26 08:58:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:58:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:58:58 --> Utf8 Class Initialized
INFO - 2023-07-26 08:58:58 --> URI Class Initialized
INFO - 2023-07-26 08:58:58 --> Router Class Initialized
INFO - 2023-07-26 08:58:58 --> Output Class Initialized
INFO - 2023-07-26 08:58:58 --> Security Class Initialized
DEBUG - 2023-07-26 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:58:58 --> Input Class Initialized
INFO - 2023-07-26 08:58:58 --> Language Class Initialized
INFO - 2023-07-26 08:58:58 --> Loader Class Initialized
INFO - 2023-07-26 08:58:58 --> Helper loaded: url_helper
INFO - 2023-07-26 08:58:58 --> Helper loaded: file_helper
INFO - 2023-07-26 08:58:58 --> Helper loaded: html_helper
INFO - 2023-07-26 08:58:58 --> Helper loaded: text_helper
INFO - 2023-07-26 08:58:58 --> Helper loaded: form_helper
INFO - 2023-07-26 08:58:58 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:58:58 --> Helper loaded: security_helper
INFO - 2023-07-26 08:58:58 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:58:58 --> Database Driver Class Initialized
INFO - 2023-07-26 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:58:58 --> Parser Class Initialized
INFO - 2023-07-26 08:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:58:58 --> Pagination Class Initialized
INFO - 2023-07-26 08:58:58 --> Form Validation Class Initialized
INFO - 2023-07-26 08:58:58 --> Controller Class Initialized
INFO - 2023-07-26 08:58:58 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:58 --> Model Class Initialized
DEBUG - 2023-07-26 08:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:58:58 --> Model Class Initialized
INFO - 2023-07-26 08:58:58 --> Final output sent to browser
DEBUG - 2023-07-26 08:58:58 --> Total execution time: 0.0175
ERROR - 2023-07-26 08:59:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:01 --> Config Class Initialized
INFO - 2023-07-26 08:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:01 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:01 --> URI Class Initialized
INFO - 2023-07-26 08:59:01 --> Router Class Initialized
INFO - 2023-07-26 08:59:01 --> Output Class Initialized
INFO - 2023-07-26 08:59:01 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:01 --> Input Class Initialized
INFO - 2023-07-26 08:59:01 --> Language Class Initialized
INFO - 2023-07-26 08:59:01 --> Loader Class Initialized
INFO - 2023-07-26 08:59:01 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:01 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:01 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:01 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:01 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:01 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:01 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:01 --> Parser Class Initialized
INFO - 2023-07-26 08:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:01 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:01 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:01 --> Controller Class Initialized
INFO - 2023-07-26 08:59:01 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:01 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:01 --> Model Class Initialized
INFO - 2023-07-26 08:59:01 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:01 --> Total execution time: 0.0181
ERROR - 2023-07-26 08:59:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:02 --> Config Class Initialized
INFO - 2023-07-26 08:59:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:02 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:02 --> URI Class Initialized
INFO - 2023-07-26 08:59:02 --> Router Class Initialized
INFO - 2023-07-26 08:59:02 --> Output Class Initialized
INFO - 2023-07-26 08:59:02 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:02 --> Input Class Initialized
INFO - 2023-07-26 08:59:02 --> Language Class Initialized
INFO - 2023-07-26 08:59:02 --> Loader Class Initialized
INFO - 2023-07-26 08:59:02 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:02 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:02 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:02 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:02 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:02 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:02 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:02 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:02 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:02 --> Parser Class Initialized
INFO - 2023-07-26 08:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:02 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:02 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:02 --> Controller Class Initialized
INFO - 2023-07-26 08:59:02 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:02 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:02 --> Model Class Initialized
INFO - 2023-07-26 08:59:02 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:02 --> Total execution time: 0.0170
ERROR - 2023-07-26 08:59:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:03 --> Config Class Initialized
INFO - 2023-07-26 08:59:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:03 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:03 --> URI Class Initialized
INFO - 2023-07-26 08:59:03 --> Router Class Initialized
INFO - 2023-07-26 08:59:03 --> Output Class Initialized
INFO - 2023-07-26 08:59:03 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:03 --> Input Class Initialized
INFO - 2023-07-26 08:59:03 --> Language Class Initialized
INFO - 2023-07-26 08:59:03 --> Loader Class Initialized
INFO - 2023-07-26 08:59:03 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:03 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:03 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:03 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:03 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:03 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:03 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:03 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:03 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:03 --> Parser Class Initialized
INFO - 2023-07-26 08:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:03 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:03 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:03 --> Controller Class Initialized
INFO - 2023-07-26 08:59:03 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:03 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:03 --> Model Class Initialized
INFO - 2023-07-26 08:59:03 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:03 --> Total execution time: 0.0178
ERROR - 2023-07-26 08:59:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:04 --> Config Class Initialized
INFO - 2023-07-26 08:59:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:04 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:04 --> URI Class Initialized
INFO - 2023-07-26 08:59:04 --> Router Class Initialized
INFO - 2023-07-26 08:59:04 --> Output Class Initialized
INFO - 2023-07-26 08:59:04 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:04 --> Input Class Initialized
INFO - 2023-07-26 08:59:04 --> Language Class Initialized
INFO - 2023-07-26 08:59:04 --> Loader Class Initialized
INFO - 2023-07-26 08:59:04 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:04 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:04 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:04 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:04 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:04 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:04 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:04 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:04 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:04 --> Parser Class Initialized
INFO - 2023-07-26 08:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:04 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:04 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:04 --> Controller Class Initialized
INFO - 2023-07-26 08:59:04 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:04 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:04 --> Model Class Initialized
INFO - 2023-07-26 08:59:04 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:04 --> Total execution time: 0.0177
ERROR - 2023-07-26 08:59:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:06 --> Config Class Initialized
INFO - 2023-07-26 08:59:06 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:06 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:06 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:06 --> URI Class Initialized
INFO - 2023-07-26 08:59:06 --> Router Class Initialized
INFO - 2023-07-26 08:59:06 --> Output Class Initialized
INFO - 2023-07-26 08:59:06 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:06 --> Input Class Initialized
INFO - 2023-07-26 08:59:06 --> Language Class Initialized
INFO - 2023-07-26 08:59:06 --> Loader Class Initialized
INFO - 2023-07-26 08:59:06 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:06 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:06 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:06 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:06 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:06 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:06 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:06 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:06 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:06 --> Parser Class Initialized
INFO - 2023-07-26 08:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:06 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:06 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:06 --> Controller Class Initialized
INFO - 2023-07-26 08:59:06 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:06 --> Model Class Initialized
INFO - 2023-07-26 08:59:06 --> Model Class Initialized
INFO - 2023-07-26 08:59:06 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:06 --> Total execution time: 0.0192
ERROR - 2023-07-26 08:59:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:20 --> Config Class Initialized
INFO - 2023-07-26 08:59:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:20 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:20 --> URI Class Initialized
INFO - 2023-07-26 08:59:20 --> Router Class Initialized
INFO - 2023-07-26 08:59:20 --> Output Class Initialized
INFO - 2023-07-26 08:59:20 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:20 --> Input Class Initialized
INFO - 2023-07-26 08:59:20 --> Language Class Initialized
INFO - 2023-07-26 08:59:20 --> Loader Class Initialized
INFO - 2023-07-26 08:59:20 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:20 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:20 --> Parser Class Initialized
INFO - 2023-07-26 08:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:20 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:20 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:20 --> Controller Class Initialized
INFO - 2023-07-26 08:59:20 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:20 --> Model Class Initialized
INFO - 2023-07-26 08:59:20 --> Email Class Initialized
INFO - 2023-07-26 08:59:20 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-07-26 08:59:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:20 --> Config Class Initialized
INFO - 2023-07-26 08:59:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:20 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:20 --> URI Class Initialized
INFO - 2023-07-26 08:59:20 --> Router Class Initialized
INFO - 2023-07-26 08:59:20 --> Output Class Initialized
INFO - 2023-07-26 08:59:20 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:20 --> Input Class Initialized
INFO - 2023-07-26 08:59:20 --> Language Class Initialized
INFO - 2023-07-26 08:59:20 --> Loader Class Initialized
INFO - 2023-07-26 08:59:20 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:20 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:20 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:20 --> Parser Class Initialized
INFO - 2023-07-26 08:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:20 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:20 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:20 --> Controller Class Initialized
INFO - 2023-07-26 08:59:20 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:20 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-26 08:59:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:59:20 --> Model Class Initialized
INFO - 2023-07-26 08:59:20 --> Model Class Initialized
INFO - 2023-07-26 08:59:20 --> Model Class Initialized
INFO - 2023-07-26 08:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:59:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:59:20 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:20 --> Total execution time: 0.0624
ERROR - 2023-07-26 08:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:30 --> Config Class Initialized
INFO - 2023-07-26 08:59:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:30 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:30 --> URI Class Initialized
INFO - 2023-07-26 08:59:30 --> Router Class Initialized
INFO - 2023-07-26 08:59:30 --> Output Class Initialized
INFO - 2023-07-26 08:59:30 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:30 --> Input Class Initialized
INFO - 2023-07-26 08:59:30 --> Language Class Initialized
INFO - 2023-07-26 08:59:30 --> Loader Class Initialized
INFO - 2023-07-26 08:59:30 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:30 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:30 --> Parser Class Initialized
INFO - 2023-07-26 08:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:30 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:30 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:30 --> Controller Class Initialized
INFO - 2023-07-26 08:59:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:30 --> Model Class Initialized
INFO - 2023-07-26 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-07-26 08:59:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:59:30 --> Model Class Initialized
INFO - 2023-07-26 08:59:30 --> Model Class Initialized
INFO - 2023-07-26 08:59:30 --> Model Class Initialized
INFO - 2023-07-26 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:59:30 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:30 --> Total execution time: 0.0577
ERROR - 2023-07-26 08:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:30 --> Config Class Initialized
INFO - 2023-07-26 08:59:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:30 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:30 --> URI Class Initialized
INFO - 2023-07-26 08:59:30 --> Router Class Initialized
INFO - 2023-07-26 08:59:30 --> Output Class Initialized
INFO - 2023-07-26 08:59:30 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:30 --> Input Class Initialized
INFO - 2023-07-26 08:59:30 --> Language Class Initialized
INFO - 2023-07-26 08:59:30 --> Loader Class Initialized
INFO - 2023-07-26 08:59:30 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:30 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:30 --> Parser Class Initialized
INFO - 2023-07-26 08:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:30 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:30 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:30 --> Controller Class Initialized
INFO - 2023-07-26 08:59:30 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:30 --> Model Class Initialized
INFO - 2023-07-26 08:59:30 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:30 --> Total execution time: 0.0163
ERROR - 2023-07-26 08:59:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:38 --> Config Class Initialized
INFO - 2023-07-26 08:59:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:38 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:38 --> URI Class Initialized
INFO - 2023-07-26 08:59:38 --> Router Class Initialized
INFO - 2023-07-26 08:59:38 --> Output Class Initialized
INFO - 2023-07-26 08:59:38 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:38 --> Input Class Initialized
INFO - 2023-07-26 08:59:38 --> Language Class Initialized
INFO - 2023-07-26 08:59:38 --> Loader Class Initialized
INFO - 2023-07-26 08:59:38 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:38 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:38 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:38 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:38 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:38 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:38 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:38 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:38 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:38 --> Parser Class Initialized
INFO - 2023-07-26 08:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:38 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:38 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:38 --> Controller Class Initialized
INFO - 2023-07-26 08:59:38 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:38 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-07-26 08:59:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:59:38 --> Model Class Initialized
INFO - 2023-07-26 08:59:38 --> Model Class Initialized
INFO - 2023-07-26 08:59:38 --> Model Class Initialized
INFO - 2023-07-26 08:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:59:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:59:38 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:38 --> Total execution time: 0.0545
ERROR - 2023-07-26 08:59:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 08:59:58 --> Config Class Initialized
INFO - 2023-07-26 08:59:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:58 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:58 --> URI Class Initialized
DEBUG - 2023-07-26 08:59:58 --> No URI present. Default controller set.
INFO - 2023-07-26 08:59:58 --> Router Class Initialized
INFO - 2023-07-26 08:59:58 --> Output Class Initialized
INFO - 2023-07-26 08:59:58 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:58 --> Input Class Initialized
INFO - 2023-07-26 08:59:58 --> Language Class Initialized
INFO - 2023-07-26 08:59:58 --> Loader Class Initialized
INFO - 2023-07-26 08:59:58 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:58 --> Helper loaded: file_helper
INFO - 2023-07-26 08:59:58 --> Helper loaded: html_helper
INFO - 2023-07-26 08:59:58 --> Helper loaded: text_helper
INFO - 2023-07-26 08:59:58 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:58 --> Helper loaded: lang_helper
INFO - 2023-07-26 08:59:58 --> Helper loaded: security_helper
INFO - 2023-07-26 08:59:58 --> Helper loaded: cookie_helper
INFO - 2023-07-26 08:59:58 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:58 --> Parser Class Initialized
INFO - 2023-07-26 08:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 08:59:58 --> Pagination Class Initialized
INFO - 2023-07-26 08:59:58 --> Form Validation Class Initialized
INFO - 2023-07-26 08:59:58 --> Controller Class Initialized
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
DEBUG - 2023-07-26 08:59:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 08:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
INFO - 2023-07-26 08:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 08:59:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 08:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 08:59:58 --> Model Class Initialized
INFO - 2023-07-26 08:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 08:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 08:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 08:59:58 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:58 --> Total execution time: 0.1764
ERROR - 2023-07-26 09:00:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:00:23 --> Config Class Initialized
INFO - 2023-07-26 09:00:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:00:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:00:23 --> Utf8 Class Initialized
INFO - 2023-07-26 09:00:23 --> URI Class Initialized
INFO - 2023-07-26 09:00:23 --> Router Class Initialized
INFO - 2023-07-26 09:00:23 --> Output Class Initialized
INFO - 2023-07-26 09:00:23 --> Security Class Initialized
DEBUG - 2023-07-26 09:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:00:23 --> Input Class Initialized
INFO - 2023-07-26 09:00:23 --> Language Class Initialized
INFO - 2023-07-26 09:00:23 --> Loader Class Initialized
INFO - 2023-07-26 09:00:23 --> Helper loaded: url_helper
INFO - 2023-07-26 09:00:23 --> Helper loaded: file_helper
INFO - 2023-07-26 09:00:23 --> Helper loaded: html_helper
INFO - 2023-07-26 09:00:23 --> Helper loaded: text_helper
INFO - 2023-07-26 09:00:23 --> Helper loaded: form_helper
INFO - 2023-07-26 09:00:23 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:00:23 --> Helper loaded: security_helper
INFO - 2023-07-26 09:00:23 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:00:23 --> Database Driver Class Initialized
INFO - 2023-07-26 09:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:00:23 --> Parser Class Initialized
INFO - 2023-07-26 09:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:00:23 --> Pagination Class Initialized
INFO - 2023-07-26 09:00:23 --> Form Validation Class Initialized
INFO - 2023-07-26 09:00:23 --> Controller Class Initialized
INFO - 2023-07-26 09:00:23 --> Model Class Initialized
DEBUG - 2023-07-26 09:00:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:00:23 --> Model Class Initialized
INFO - 2023-07-26 09:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-07-26 09:00:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:00:23 --> Model Class Initialized
INFO - 2023-07-26 09:00:23 --> Model Class Initialized
INFO - 2023-07-26 09:00:23 --> Model Class Initialized
INFO - 2023-07-26 09:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:00:23 --> Final output sent to browser
DEBUG - 2023-07-26 09:00:23 --> Total execution time: 0.1563
ERROR - 2023-07-26 09:00:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:00:24 --> Config Class Initialized
INFO - 2023-07-26 09:00:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:00:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:00:24 --> Utf8 Class Initialized
INFO - 2023-07-26 09:00:24 --> URI Class Initialized
INFO - 2023-07-26 09:00:24 --> Router Class Initialized
INFO - 2023-07-26 09:00:24 --> Output Class Initialized
INFO - 2023-07-26 09:00:24 --> Security Class Initialized
DEBUG - 2023-07-26 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:00:24 --> Input Class Initialized
INFO - 2023-07-26 09:00:24 --> Language Class Initialized
INFO - 2023-07-26 09:00:24 --> Loader Class Initialized
INFO - 2023-07-26 09:00:24 --> Helper loaded: url_helper
INFO - 2023-07-26 09:00:24 --> Helper loaded: file_helper
INFO - 2023-07-26 09:00:24 --> Helper loaded: html_helper
INFO - 2023-07-26 09:00:24 --> Helper loaded: text_helper
INFO - 2023-07-26 09:00:24 --> Helper loaded: form_helper
INFO - 2023-07-26 09:00:24 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:00:24 --> Helper loaded: security_helper
INFO - 2023-07-26 09:00:24 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:00:24 --> Database Driver Class Initialized
INFO - 2023-07-26 09:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:00:24 --> Parser Class Initialized
INFO - 2023-07-26 09:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:00:24 --> Pagination Class Initialized
INFO - 2023-07-26 09:00:24 --> Form Validation Class Initialized
INFO - 2023-07-26 09:00:24 --> Controller Class Initialized
INFO - 2023-07-26 09:00:24 --> Model Class Initialized
DEBUG - 2023-07-26 09:00:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:00:24 --> Model Class Initialized
INFO - 2023-07-26 09:00:24 --> Final output sent to browser
DEBUG - 2023-07-26 09:00:24 --> Total execution time: 0.0207
ERROR - 2023-07-26 09:00:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:00:54 --> Config Class Initialized
INFO - 2023-07-26 09:00:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:00:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:00:54 --> Utf8 Class Initialized
INFO - 2023-07-26 09:00:54 --> URI Class Initialized
INFO - 2023-07-26 09:00:54 --> Router Class Initialized
INFO - 2023-07-26 09:00:54 --> Output Class Initialized
INFO - 2023-07-26 09:00:54 --> Security Class Initialized
DEBUG - 2023-07-26 09:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:00:54 --> Input Class Initialized
INFO - 2023-07-26 09:00:54 --> Language Class Initialized
INFO - 2023-07-26 09:00:54 --> Loader Class Initialized
INFO - 2023-07-26 09:00:54 --> Helper loaded: url_helper
INFO - 2023-07-26 09:00:54 --> Helper loaded: file_helper
INFO - 2023-07-26 09:00:54 --> Helper loaded: html_helper
INFO - 2023-07-26 09:00:54 --> Helper loaded: text_helper
INFO - 2023-07-26 09:00:54 --> Helper loaded: form_helper
INFO - 2023-07-26 09:00:54 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:00:54 --> Helper loaded: security_helper
INFO - 2023-07-26 09:00:54 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:00:54 --> Database Driver Class Initialized
INFO - 2023-07-26 09:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:00:54 --> Parser Class Initialized
INFO - 2023-07-26 09:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:00:54 --> Pagination Class Initialized
INFO - 2023-07-26 09:00:54 --> Form Validation Class Initialized
INFO - 2023-07-26 09:00:54 --> Controller Class Initialized
INFO - 2023-07-26 09:00:54 --> Model Class Initialized
INFO - 2023-07-26 09:00:54 --> Model Class Initialized
INFO - 2023-07-26 09:00:54 --> Model Class Initialized
INFO - 2023-07-26 09:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-26 09:00:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:00:54 --> Model Class Initialized
INFO - 2023-07-26 09:00:54 --> Model Class Initialized
INFO - 2023-07-26 09:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:00:54 --> Final output sent to browser
DEBUG - 2023-07-26 09:00:54 --> Total execution time: 0.1524
ERROR - 2023-07-26 09:00:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:00:54 --> Config Class Initialized
INFO - 2023-07-26 09:00:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:00:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:00:54 --> Utf8 Class Initialized
INFO - 2023-07-26 09:00:55 --> URI Class Initialized
INFO - 2023-07-26 09:00:55 --> Router Class Initialized
INFO - 2023-07-26 09:00:55 --> Output Class Initialized
INFO - 2023-07-26 09:00:55 --> Security Class Initialized
DEBUG - 2023-07-26 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:00:55 --> Input Class Initialized
INFO - 2023-07-26 09:00:55 --> Language Class Initialized
INFO - 2023-07-26 09:00:55 --> Loader Class Initialized
INFO - 2023-07-26 09:00:55 --> Helper loaded: url_helper
INFO - 2023-07-26 09:00:55 --> Helper loaded: file_helper
INFO - 2023-07-26 09:00:55 --> Helper loaded: html_helper
INFO - 2023-07-26 09:00:55 --> Helper loaded: text_helper
INFO - 2023-07-26 09:00:55 --> Helper loaded: form_helper
INFO - 2023-07-26 09:00:55 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:00:55 --> Helper loaded: security_helper
INFO - 2023-07-26 09:00:55 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:00:55 --> Database Driver Class Initialized
INFO - 2023-07-26 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:00:55 --> Parser Class Initialized
INFO - 2023-07-26 09:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:00:55 --> Pagination Class Initialized
INFO - 2023-07-26 09:00:55 --> Form Validation Class Initialized
INFO - 2023-07-26 09:00:55 --> Controller Class Initialized
INFO - 2023-07-26 09:00:55 --> Model Class Initialized
INFO - 2023-07-26 09:00:55 --> Model Class Initialized
INFO - 2023-07-26 09:00:55 --> Final output sent to browser
DEBUG - 2023-07-26 09:00:55 --> Total execution time: 0.0243
ERROR - 2023-07-26 09:01:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:01:00 --> Config Class Initialized
INFO - 2023-07-26 09:01:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:01:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:01:00 --> Utf8 Class Initialized
INFO - 2023-07-26 09:01:00 --> URI Class Initialized
INFO - 2023-07-26 09:01:00 --> Router Class Initialized
INFO - 2023-07-26 09:01:00 --> Output Class Initialized
INFO - 2023-07-26 09:01:00 --> Security Class Initialized
DEBUG - 2023-07-26 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:01:00 --> Input Class Initialized
INFO - 2023-07-26 09:01:00 --> Language Class Initialized
INFO - 2023-07-26 09:01:00 --> Loader Class Initialized
INFO - 2023-07-26 09:01:00 --> Helper loaded: url_helper
INFO - 2023-07-26 09:01:00 --> Helper loaded: file_helper
INFO - 2023-07-26 09:01:00 --> Helper loaded: html_helper
INFO - 2023-07-26 09:01:00 --> Helper loaded: text_helper
INFO - 2023-07-26 09:01:00 --> Helper loaded: form_helper
INFO - 2023-07-26 09:01:00 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:01:00 --> Helper loaded: security_helper
INFO - 2023-07-26 09:01:00 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:01:00 --> Database Driver Class Initialized
INFO - 2023-07-26 09:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:01:00 --> Parser Class Initialized
INFO - 2023-07-26 09:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:01:00 --> Pagination Class Initialized
INFO - 2023-07-26 09:01:00 --> Form Validation Class Initialized
INFO - 2023-07-26 09:01:00 --> Controller Class Initialized
INFO - 2023-07-26 09:01:00 --> Model Class Initialized
INFO - 2023-07-26 09:01:00 --> Model Class Initialized
INFO - 2023-07-26 09:01:00 --> Final output sent to browser
DEBUG - 2023-07-26 09:01:00 --> Total execution time: 0.0362
ERROR - 2023-07-26 09:02:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:02:42 --> Config Class Initialized
INFO - 2023-07-26 09:02:42 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:02:42 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:02:42 --> Utf8 Class Initialized
INFO - 2023-07-26 09:02:42 --> URI Class Initialized
DEBUG - 2023-07-26 09:02:42 --> No URI present. Default controller set.
INFO - 2023-07-26 09:02:42 --> Router Class Initialized
INFO - 2023-07-26 09:02:42 --> Output Class Initialized
INFO - 2023-07-26 09:02:42 --> Security Class Initialized
DEBUG - 2023-07-26 09:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:02:42 --> Input Class Initialized
INFO - 2023-07-26 09:02:42 --> Language Class Initialized
INFO - 2023-07-26 09:02:42 --> Loader Class Initialized
INFO - 2023-07-26 09:02:42 --> Helper loaded: url_helper
INFO - 2023-07-26 09:02:42 --> Helper loaded: file_helper
INFO - 2023-07-26 09:02:42 --> Helper loaded: html_helper
INFO - 2023-07-26 09:02:42 --> Helper loaded: text_helper
INFO - 2023-07-26 09:02:42 --> Helper loaded: form_helper
INFO - 2023-07-26 09:02:42 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:02:42 --> Helper loaded: security_helper
INFO - 2023-07-26 09:02:42 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:02:42 --> Database Driver Class Initialized
INFO - 2023-07-26 09:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:02:42 --> Parser Class Initialized
INFO - 2023-07-26 09:02:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:02:42 --> Pagination Class Initialized
INFO - 2023-07-26 09:02:42 --> Form Validation Class Initialized
INFO - 2023-07-26 09:02:42 --> Controller Class Initialized
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
DEBUG - 2023-07-26 09:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
DEBUG - 2023-07-26 09:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
DEBUG - 2023-07-26 09:02:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
INFO - 2023-07-26 09:02:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 09:02:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:02:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:02:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:02:42 --> Model Class Initialized
INFO - 2023-07-26 09:02:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:02:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:02:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:02:42 --> Final output sent to browser
DEBUG - 2023-07-26 09:02:42 --> Total execution time: 0.1978
ERROR - 2023-07-26 09:02:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:02:53 --> Config Class Initialized
INFO - 2023-07-26 09:02:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:02:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:02:53 --> Utf8 Class Initialized
INFO - 2023-07-26 09:02:53 --> URI Class Initialized
DEBUG - 2023-07-26 09:02:53 --> No URI present. Default controller set.
INFO - 2023-07-26 09:02:53 --> Router Class Initialized
INFO - 2023-07-26 09:02:53 --> Output Class Initialized
INFO - 2023-07-26 09:02:53 --> Security Class Initialized
DEBUG - 2023-07-26 09:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:02:53 --> Input Class Initialized
INFO - 2023-07-26 09:02:53 --> Language Class Initialized
INFO - 2023-07-26 09:02:53 --> Loader Class Initialized
INFO - 2023-07-26 09:02:53 --> Helper loaded: url_helper
INFO - 2023-07-26 09:02:53 --> Helper loaded: file_helper
INFO - 2023-07-26 09:02:53 --> Helper loaded: html_helper
INFO - 2023-07-26 09:02:53 --> Helper loaded: text_helper
INFO - 2023-07-26 09:02:53 --> Helper loaded: form_helper
INFO - 2023-07-26 09:02:53 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:02:53 --> Helper loaded: security_helper
INFO - 2023-07-26 09:02:53 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:02:53 --> Database Driver Class Initialized
INFO - 2023-07-26 09:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:02:53 --> Parser Class Initialized
INFO - 2023-07-26 09:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:02:53 --> Pagination Class Initialized
INFO - 2023-07-26 09:02:53 --> Form Validation Class Initialized
INFO - 2023-07-26 09:02:53 --> Controller Class Initialized
INFO - 2023-07-26 09:02:53 --> Model Class Initialized
DEBUG - 2023-07-26 09:02:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 09:02:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:02:54 --> Config Class Initialized
INFO - 2023-07-26 09:02:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:02:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:02:54 --> Utf8 Class Initialized
INFO - 2023-07-26 09:02:54 --> URI Class Initialized
INFO - 2023-07-26 09:02:54 --> Router Class Initialized
INFO - 2023-07-26 09:02:54 --> Output Class Initialized
INFO - 2023-07-26 09:02:54 --> Security Class Initialized
DEBUG - 2023-07-26 09:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:02:54 --> Input Class Initialized
INFO - 2023-07-26 09:02:54 --> Language Class Initialized
INFO - 2023-07-26 09:02:54 --> Loader Class Initialized
INFO - 2023-07-26 09:02:54 --> Helper loaded: url_helper
INFO - 2023-07-26 09:02:54 --> Helper loaded: file_helper
INFO - 2023-07-26 09:02:54 --> Helper loaded: html_helper
INFO - 2023-07-26 09:02:54 --> Helper loaded: text_helper
INFO - 2023-07-26 09:02:54 --> Helper loaded: form_helper
INFO - 2023-07-26 09:02:54 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:02:54 --> Helper loaded: security_helper
INFO - 2023-07-26 09:02:54 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:02:54 --> Database Driver Class Initialized
INFO - 2023-07-26 09:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:02:54 --> Parser Class Initialized
INFO - 2023-07-26 09:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:02:54 --> Pagination Class Initialized
INFO - 2023-07-26 09:02:54 --> Form Validation Class Initialized
INFO - 2023-07-26 09:02:54 --> Controller Class Initialized
INFO - 2023-07-26 09:02:54 --> Model Class Initialized
DEBUG - 2023-07-26 09:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 09:02:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:02:54 --> Model Class Initialized
INFO - 2023-07-26 09:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:02:54 --> Final output sent to browser
DEBUG - 2023-07-26 09:02:54 --> Total execution time: 0.0283
ERROR - 2023-07-26 09:02:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:02:55 --> Config Class Initialized
INFO - 2023-07-26 09:02:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:02:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:02:55 --> Utf8 Class Initialized
INFO - 2023-07-26 09:02:55 --> URI Class Initialized
INFO - 2023-07-26 09:02:55 --> Router Class Initialized
INFO - 2023-07-26 09:02:55 --> Output Class Initialized
INFO - 2023-07-26 09:02:55 --> Security Class Initialized
DEBUG - 2023-07-26 09:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:02:55 --> Input Class Initialized
INFO - 2023-07-26 09:02:55 --> Language Class Initialized
ERROR - 2023-07-26 09:02:55 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-07-26 09:02:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:02:55 --> Config Class Initialized
INFO - 2023-07-26 09:02:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:02:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:02:55 --> Utf8 Class Initialized
INFO - 2023-07-26 09:02:55 --> URI Class Initialized
INFO - 2023-07-26 09:02:55 --> Router Class Initialized
INFO - 2023-07-26 09:02:55 --> Output Class Initialized
INFO - 2023-07-26 09:02:55 --> Security Class Initialized
DEBUG - 2023-07-26 09:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:02:55 --> Input Class Initialized
INFO - 2023-07-26 09:02:55 --> Language Class Initialized
ERROR - 2023-07-26 09:02:55 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-07-26 09:03:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:02 --> Config Class Initialized
INFO - 2023-07-26 09:03:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:02 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:02 --> URI Class Initialized
INFO - 2023-07-26 09:03:02 --> Router Class Initialized
INFO - 2023-07-26 09:03:02 --> Output Class Initialized
INFO - 2023-07-26 09:03:02 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:02 --> Input Class Initialized
INFO - 2023-07-26 09:03:02 --> Language Class Initialized
INFO - 2023-07-26 09:03:02 --> Loader Class Initialized
INFO - 2023-07-26 09:03:02 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:02 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:02 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:02 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:02 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:02 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:02 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:02 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:02 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:02 --> Parser Class Initialized
INFO - 2023-07-26 09:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:02 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:02 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:02 --> Controller Class Initialized
INFO - 2023-07-26 09:03:02 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:02 --> Model Class Initialized
INFO - 2023-07-26 09:03:02 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:02 --> Total execution time: 0.0171
ERROR - 2023-07-26 09:03:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:03 --> Config Class Initialized
INFO - 2023-07-26 09:03:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:03 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:03 --> URI Class Initialized
DEBUG - 2023-07-26 09:03:03 --> No URI present. Default controller set.
INFO - 2023-07-26 09:03:03 --> Router Class Initialized
INFO - 2023-07-26 09:03:03 --> Output Class Initialized
INFO - 2023-07-26 09:03:03 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:03 --> Input Class Initialized
INFO - 2023-07-26 09:03:03 --> Language Class Initialized
INFO - 2023-07-26 09:03:03 --> Loader Class Initialized
INFO - 2023-07-26 09:03:03 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:03 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:03 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:03 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:03 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:03 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:03 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:03 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:03 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:03 --> Parser Class Initialized
INFO - 2023-07-26 09:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:03 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:03 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:03 --> Controller Class Initialized
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
INFO - 2023-07-26 09:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 09:03:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:03:03 --> Model Class Initialized
INFO - 2023-07-26 09:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:03:03 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:03 --> Total execution time: 0.0830
ERROR - 2023-07-26 09:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:12 --> Config Class Initialized
INFO - 2023-07-26 09:03:12 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:12 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:12 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:12 --> URI Class Initialized
INFO - 2023-07-26 09:03:12 --> Router Class Initialized
INFO - 2023-07-26 09:03:12 --> Output Class Initialized
INFO - 2023-07-26 09:03:12 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:12 --> Input Class Initialized
INFO - 2023-07-26 09:03:12 --> Language Class Initialized
INFO - 2023-07-26 09:03:12 --> Loader Class Initialized
INFO - 2023-07-26 09:03:12 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:12 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:12 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:12 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:12 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:12 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:12 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:12 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:12 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:12 --> Parser Class Initialized
INFO - 2023-07-26 09:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:12 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:12 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:12 --> Controller Class Initialized
INFO - 2023-07-26 09:03:12 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:12 --> Model Class Initialized
INFO - 2023-07-26 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-26 09:03:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:03:12 --> Model Class Initialized
INFO - 2023-07-26 09:03:12 --> Model Class Initialized
INFO - 2023-07-26 09:03:12 --> Model Class Initialized
INFO - 2023-07-26 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:03:12 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:12 --> Total execution time: 0.0714
ERROR - 2023-07-26 09:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:13 --> Config Class Initialized
INFO - 2023-07-26 09:03:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:13 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:13 --> URI Class Initialized
INFO - 2023-07-26 09:03:13 --> Router Class Initialized
INFO - 2023-07-26 09:03:13 --> Output Class Initialized
INFO - 2023-07-26 09:03:13 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:13 --> Input Class Initialized
INFO - 2023-07-26 09:03:13 --> Language Class Initialized
INFO - 2023-07-26 09:03:13 --> Loader Class Initialized
INFO - 2023-07-26 09:03:13 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:13 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:13 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:13 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:13 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:13 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:13 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:13 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:13 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:13 --> Parser Class Initialized
INFO - 2023-07-26 09:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:13 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:13 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:13 --> Controller Class Initialized
INFO - 2023-07-26 09:03:13 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:13 --> Model Class Initialized
INFO - 2023-07-26 09:03:13 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:13 --> Total execution time: 0.0228
ERROR - 2023-07-26 09:03:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:22 --> Config Class Initialized
INFO - 2023-07-26 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:22 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:22 --> URI Class Initialized
INFO - 2023-07-26 09:03:22 --> Router Class Initialized
INFO - 2023-07-26 09:03:22 --> Output Class Initialized
INFO - 2023-07-26 09:03:22 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:22 --> Input Class Initialized
INFO - 2023-07-26 09:03:22 --> Language Class Initialized
INFO - 2023-07-26 09:03:22 --> Loader Class Initialized
INFO - 2023-07-26 09:03:22 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:22 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:22 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:22 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:22 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:22 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:22 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:22 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:22 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:22 --> Parser Class Initialized
INFO - 2023-07-26 09:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:22 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:22 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:22 --> Controller Class Initialized
INFO - 2023-07-26 09:03:22 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:22 --> Model Class Initialized
INFO - 2023-07-26 09:03:22 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:22 --> Total execution time: 0.0224
ERROR - 2023-07-26 09:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:49 --> Config Class Initialized
INFO - 2023-07-26 09:03:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:49 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:49 --> URI Class Initialized
DEBUG - 2023-07-26 09:03:49 --> No URI present. Default controller set.
INFO - 2023-07-26 09:03:49 --> Router Class Initialized
INFO - 2023-07-26 09:03:49 --> Output Class Initialized
INFO - 2023-07-26 09:03:49 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:49 --> Input Class Initialized
INFO - 2023-07-26 09:03:49 --> Language Class Initialized
INFO - 2023-07-26 09:03:49 --> Loader Class Initialized
INFO - 2023-07-26 09:03:49 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:49 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:49 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:49 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:49 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:49 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:49 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:49 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:49 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:49 --> Parser Class Initialized
INFO - 2023-07-26 09:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:49 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:49 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:49 --> Controller Class Initialized
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
INFO - 2023-07-26 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 09:03:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:03:49 --> Model Class Initialized
INFO - 2023-07-26 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:03:49 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:49 --> Total execution time: 0.0739
ERROR - 2023-07-26 09:03:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:56 --> Config Class Initialized
INFO - 2023-07-26 09:03:56 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:56 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:56 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:56 --> URI Class Initialized
INFO - 2023-07-26 09:03:56 --> Router Class Initialized
INFO - 2023-07-26 09:03:56 --> Output Class Initialized
INFO - 2023-07-26 09:03:56 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:56 --> Input Class Initialized
INFO - 2023-07-26 09:03:56 --> Language Class Initialized
INFO - 2023-07-26 09:03:56 --> Loader Class Initialized
INFO - 2023-07-26 09:03:56 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:56 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:56 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:56 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:56 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:56 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:56 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:56 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:56 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:56 --> Parser Class Initialized
INFO - 2023-07-26 09:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:56 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:56 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:56 --> Controller Class Initialized
INFO - 2023-07-26 09:03:56 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:56 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-26 09:03:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:03:56 --> Model Class Initialized
INFO - 2023-07-26 09:03:56 --> Model Class Initialized
INFO - 2023-07-26 09:03:56 --> Model Class Initialized
INFO - 2023-07-26 09:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:03:56 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:56 --> Total execution time: 0.0599
ERROR - 2023-07-26 09:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:59 --> Config Class Initialized
INFO - 2023-07-26 09:03:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:59 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:59 --> URI Class Initialized
INFO - 2023-07-26 09:03:59 --> Router Class Initialized
INFO - 2023-07-26 09:03:59 --> Output Class Initialized
INFO - 2023-07-26 09:03:59 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:59 --> Input Class Initialized
INFO - 2023-07-26 09:03:59 --> Language Class Initialized
INFO - 2023-07-26 09:03:59 --> Loader Class Initialized
INFO - 2023-07-26 09:03:59 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:59 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:59 --> Parser Class Initialized
INFO - 2023-07-26 09:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:59 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:59 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:59 --> Controller Class Initialized
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
INFO - 2023-07-26 09:03:59 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:59 --> Total execution time: 0.0189
ERROR - 2023-07-26 09:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:59 --> Config Class Initialized
INFO - 2023-07-26 09:03:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:59 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:59 --> URI Class Initialized
INFO - 2023-07-26 09:03:59 --> Router Class Initialized
INFO - 2023-07-26 09:03:59 --> Output Class Initialized
INFO - 2023-07-26 09:03:59 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:59 --> Input Class Initialized
INFO - 2023-07-26 09:03:59 --> Language Class Initialized
INFO - 2023-07-26 09:03:59 --> Loader Class Initialized
INFO - 2023-07-26 09:03:59 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:59 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:59 --> Parser Class Initialized
INFO - 2023-07-26 09:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:59 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:59 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:59 --> Controller Class Initialized
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
INFO - 2023-07-26 09:03:59 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:59 --> Total execution time: 0.0173
ERROR - 2023-07-26 09:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:03:59 --> Config Class Initialized
INFO - 2023-07-26 09:03:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:03:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:03:59 --> Utf8 Class Initialized
INFO - 2023-07-26 09:03:59 --> URI Class Initialized
INFO - 2023-07-26 09:03:59 --> Router Class Initialized
INFO - 2023-07-26 09:03:59 --> Output Class Initialized
INFO - 2023-07-26 09:03:59 --> Security Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:03:59 --> Input Class Initialized
INFO - 2023-07-26 09:03:59 --> Language Class Initialized
INFO - 2023-07-26 09:03:59 --> Loader Class Initialized
INFO - 2023-07-26 09:03:59 --> Helper loaded: url_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: file_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: html_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: text_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: form_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: security_helper
INFO - 2023-07-26 09:03:59 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:03:59 --> Database Driver Class Initialized
INFO - 2023-07-26 09:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:03:59 --> Parser Class Initialized
INFO - 2023-07-26 09:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:03:59 --> Pagination Class Initialized
INFO - 2023-07-26 09:03:59 --> Form Validation Class Initialized
INFO - 2023-07-26 09:03:59 --> Controller Class Initialized
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
DEBUG - 2023-07-26 09:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:03:59 --> Model Class Initialized
INFO - 2023-07-26 09:03:59 --> Final output sent to browser
DEBUG - 2023-07-26 09:03:59 --> Total execution time: 0.0167
ERROR - 2023-07-26 09:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:01 --> Config Class Initialized
INFO - 2023-07-26 09:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:01 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:01 --> URI Class Initialized
INFO - 2023-07-26 09:04:01 --> Router Class Initialized
INFO - 2023-07-26 09:04:01 --> Output Class Initialized
INFO - 2023-07-26 09:04:01 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:01 --> Input Class Initialized
INFO - 2023-07-26 09:04:01 --> Language Class Initialized
INFO - 2023-07-26 09:04:01 --> Loader Class Initialized
INFO - 2023-07-26 09:04:01 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:01 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:01 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:01 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:01 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:01 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:01 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:01 --> Parser Class Initialized
INFO - 2023-07-26 09:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:01 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:01 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:01 --> Controller Class Initialized
INFO - 2023-07-26 09:04:01 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:01 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:01 --> Model Class Initialized
INFO - 2023-07-26 09:04:01 --> Final output sent to browser
DEBUG - 2023-07-26 09:04:01 --> Total execution time: 0.0173
ERROR - 2023-07-26 09:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:05 --> Config Class Initialized
INFO - 2023-07-26 09:04:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:05 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:05 --> URI Class Initialized
INFO - 2023-07-26 09:04:05 --> Router Class Initialized
INFO - 2023-07-26 09:04:05 --> Output Class Initialized
INFO - 2023-07-26 09:04:05 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:05 --> Input Class Initialized
INFO - 2023-07-26 09:04:05 --> Language Class Initialized
INFO - 2023-07-26 09:04:05 --> Loader Class Initialized
INFO - 2023-07-26 09:04:05 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:05 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:05 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:05 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:05 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:05 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:05 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:05 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:05 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:05 --> Parser Class Initialized
INFO - 2023-07-26 09:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:05 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:05 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:05 --> Controller Class Initialized
INFO - 2023-07-26 09:04:05 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:05 --> Model Class Initialized
INFO - 2023-07-26 09:04:05 --> Model Class Initialized
INFO - 2023-07-26 09:04:05 --> Final output sent to browser
DEBUG - 2023-07-26 09:04:05 --> Total execution time: 0.0212
ERROR - 2023-07-26 09:04:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:10 --> Config Class Initialized
INFO - 2023-07-26 09:04:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:10 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:10 --> URI Class Initialized
INFO - 2023-07-26 09:04:10 --> Router Class Initialized
INFO - 2023-07-26 09:04:10 --> Output Class Initialized
INFO - 2023-07-26 09:04:10 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:10 --> Input Class Initialized
INFO - 2023-07-26 09:04:10 --> Language Class Initialized
INFO - 2023-07-26 09:04:10 --> Loader Class Initialized
INFO - 2023-07-26 09:04:10 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:10 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:10 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:10 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:10 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:10 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:10 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:10 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:10 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:10 --> Parser Class Initialized
INFO - 2023-07-26 09:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:10 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:10 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:10 --> Controller Class Initialized
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
INFO - 2023-07-26 09:04:11 --> Final output sent to browser
DEBUG - 2023-07-26 09:04:11 --> Total execution time: 0.0180
ERROR - 2023-07-26 09:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:11 --> Config Class Initialized
INFO - 2023-07-26 09:04:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:11 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:11 --> URI Class Initialized
INFO - 2023-07-26 09:04:11 --> Router Class Initialized
INFO - 2023-07-26 09:04:11 --> Output Class Initialized
INFO - 2023-07-26 09:04:11 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:11 --> Input Class Initialized
INFO - 2023-07-26 09:04:11 --> Language Class Initialized
INFO - 2023-07-26 09:04:11 --> Loader Class Initialized
INFO - 2023-07-26 09:04:11 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:11 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:11 --> Parser Class Initialized
INFO - 2023-07-26 09:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:11 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:11 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:11 --> Controller Class Initialized
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
INFO - 2023-07-26 09:04:11 --> Final output sent to browser
DEBUG - 2023-07-26 09:04:11 --> Total execution time: 0.0169
ERROR - 2023-07-26 09:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:11 --> Config Class Initialized
INFO - 2023-07-26 09:04:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:11 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:11 --> URI Class Initialized
INFO - 2023-07-26 09:04:11 --> Router Class Initialized
INFO - 2023-07-26 09:04:11 --> Output Class Initialized
INFO - 2023-07-26 09:04:11 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:11 --> Input Class Initialized
INFO - 2023-07-26 09:04:11 --> Language Class Initialized
INFO - 2023-07-26 09:04:11 --> Loader Class Initialized
INFO - 2023-07-26 09:04:11 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:11 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:11 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:11 --> Parser Class Initialized
INFO - 2023-07-26 09:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:11 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:11 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:11 --> Controller Class Initialized
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:11 --> Model Class Initialized
INFO - 2023-07-26 09:04:11 --> Final output sent to browser
DEBUG - 2023-07-26 09:04:11 --> Total execution time: 0.0172
ERROR - 2023-07-26 09:04:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:13 --> Config Class Initialized
INFO - 2023-07-26 09:04:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:13 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:13 --> URI Class Initialized
INFO - 2023-07-26 09:04:13 --> Router Class Initialized
INFO - 2023-07-26 09:04:13 --> Output Class Initialized
INFO - 2023-07-26 09:04:13 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:13 --> Input Class Initialized
INFO - 2023-07-26 09:04:13 --> Language Class Initialized
INFO - 2023-07-26 09:04:13 --> Loader Class Initialized
INFO - 2023-07-26 09:04:13 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:13 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:13 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:13 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:13 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:13 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:13 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:13 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:13 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:13 --> Parser Class Initialized
INFO - 2023-07-26 09:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:13 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:13 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:13 --> Controller Class Initialized
INFO - 2023-07-26 09:04:13 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:13 --> Model Class Initialized
INFO - 2023-07-26 09:04:13 --> Model Class Initialized
INFO - 2023-07-26 09:04:13 --> Final output sent to browser
DEBUG - 2023-07-26 09:04:13 --> Total execution time: 0.0182
ERROR - 2023-07-26 09:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:21 --> Config Class Initialized
INFO - 2023-07-26 09:04:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:21 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:21 --> URI Class Initialized
INFO - 2023-07-26 09:04:21 --> Router Class Initialized
INFO - 2023-07-26 09:04:21 --> Output Class Initialized
INFO - 2023-07-26 09:04:21 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:21 --> Input Class Initialized
INFO - 2023-07-26 09:04:21 --> Language Class Initialized
INFO - 2023-07-26 09:04:21 --> Loader Class Initialized
INFO - 2023-07-26 09:04:22 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:22 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:22 --> Parser Class Initialized
INFO - 2023-07-26 09:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:22 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:22 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:22 --> Controller Class Initialized
INFO - 2023-07-26 09:04:22 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:22 --> Model Class Initialized
INFO - 2023-07-26 09:04:22 --> Email Class Initialized
INFO - 2023-07-26 09:04:22 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-07-26 09:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:04:22 --> Config Class Initialized
INFO - 2023-07-26 09:04:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:04:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:04:22 --> Utf8 Class Initialized
INFO - 2023-07-26 09:04:22 --> URI Class Initialized
INFO - 2023-07-26 09:04:22 --> Router Class Initialized
INFO - 2023-07-26 09:04:22 --> Output Class Initialized
INFO - 2023-07-26 09:04:22 --> Security Class Initialized
DEBUG - 2023-07-26 09:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:04:22 --> Input Class Initialized
INFO - 2023-07-26 09:04:22 --> Language Class Initialized
INFO - 2023-07-26 09:04:22 --> Loader Class Initialized
INFO - 2023-07-26 09:04:22 --> Helper loaded: url_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: file_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: html_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: text_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: form_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: security_helper
INFO - 2023-07-26 09:04:22 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:04:22 --> Database Driver Class Initialized
INFO - 2023-07-26 09:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:04:22 --> Parser Class Initialized
INFO - 2023-07-26 09:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:04:22 --> Pagination Class Initialized
INFO - 2023-07-26 09:04:22 --> Form Validation Class Initialized
INFO - 2023-07-26 09:04:22 --> Controller Class Initialized
INFO - 2023-07-26 09:04:22 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:22 --> Model Class Initialized
DEBUG - 2023-07-26 09:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-26 09:04:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:04:22 --> Model Class Initialized
INFO - 2023-07-26 09:04:22 --> Model Class Initialized
INFO - 2023-07-26 09:04:22 --> Model Class Initialized
INFO - 2023-07-26 09:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:04:22 --> Final output sent to browser
DEBUG - 2023-07-26 09:04:22 --> Total execution time: 0.0671
ERROR - 2023-07-26 09:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:05:44 --> Config Class Initialized
INFO - 2023-07-26 09:05:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:05:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:05:44 --> Utf8 Class Initialized
INFO - 2023-07-26 09:05:44 --> URI Class Initialized
INFO - 2023-07-26 09:05:44 --> Router Class Initialized
INFO - 2023-07-26 09:05:44 --> Output Class Initialized
INFO - 2023-07-26 09:05:44 --> Security Class Initialized
DEBUG - 2023-07-26 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:05:44 --> Input Class Initialized
INFO - 2023-07-26 09:05:44 --> Language Class Initialized
INFO - 2023-07-26 09:05:44 --> Loader Class Initialized
INFO - 2023-07-26 09:05:44 --> Helper loaded: url_helper
INFO - 2023-07-26 09:05:44 --> Helper loaded: file_helper
INFO - 2023-07-26 09:05:44 --> Helper loaded: html_helper
INFO - 2023-07-26 09:05:44 --> Helper loaded: text_helper
INFO - 2023-07-26 09:05:44 --> Helper loaded: form_helper
INFO - 2023-07-26 09:05:44 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:05:44 --> Helper loaded: security_helper
INFO - 2023-07-26 09:05:44 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:05:44 --> Database Driver Class Initialized
INFO - 2023-07-26 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:05:44 --> Parser Class Initialized
INFO - 2023-07-26 09:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:05:44 --> Pagination Class Initialized
INFO - 2023-07-26 09:05:44 --> Form Validation Class Initialized
INFO - 2023-07-26 09:05:44 --> Controller Class Initialized
INFO - 2023-07-26 09:05:44 --> Model Class Initialized
DEBUG - 2023-07-26 09:05:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:05:44 --> Model Class Initialized
DEBUG - 2023-07-26 09:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:05:44 --> Model Class Initialized
INFO - 2023-07-26 09:05:44 --> Final output sent to browser
DEBUG - 2023-07-26 09:05:44 --> Total execution time: 0.0217
ERROR - 2023-07-26 09:06:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:06:01 --> Config Class Initialized
INFO - 2023-07-26 09:06:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:01 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:01 --> URI Class Initialized
INFO - 2023-07-26 09:06:01 --> Router Class Initialized
INFO - 2023-07-26 09:06:01 --> Output Class Initialized
INFO - 2023-07-26 09:06:01 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:01 --> Input Class Initialized
INFO - 2023-07-26 09:06:01 --> Language Class Initialized
INFO - 2023-07-26 09:06:01 --> Loader Class Initialized
INFO - 2023-07-26 09:06:01 --> Helper loaded: url_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: file_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: html_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: text_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: form_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: security_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:06:01 --> Database Driver Class Initialized
INFO - 2023-07-26 09:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:06:01 --> Parser Class Initialized
INFO - 2023-07-26 09:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:06:01 --> Pagination Class Initialized
INFO - 2023-07-26 09:06:01 --> Form Validation Class Initialized
INFO - 2023-07-26 09:06:01 --> Controller Class Initialized
INFO - 2023-07-26 09:06:01 --> Model Class Initialized
DEBUG - 2023-07-26 09:06:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:06:01 --> Model Class Initialized
INFO - 2023-07-26 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-07-26 09:06:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:06:01 --> Model Class Initialized
INFO - 2023-07-26 09:06:01 --> Model Class Initialized
INFO - 2023-07-26 09:06:01 --> Model Class Initialized
INFO - 2023-07-26 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:06:01 --> Final output sent to browser
DEBUG - 2023-07-26 09:06:01 --> Total execution time: 0.0809
ERROR - 2023-07-26 09:06:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:06:01 --> Config Class Initialized
INFO - 2023-07-26 09:06:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:01 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:01 --> URI Class Initialized
INFO - 2023-07-26 09:06:01 --> Router Class Initialized
INFO - 2023-07-26 09:06:01 --> Output Class Initialized
INFO - 2023-07-26 09:06:01 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:01 --> Input Class Initialized
INFO - 2023-07-26 09:06:01 --> Language Class Initialized
INFO - 2023-07-26 09:06:01 --> Loader Class Initialized
INFO - 2023-07-26 09:06:01 --> Helper loaded: url_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: file_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: html_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: text_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: form_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: security_helper
INFO - 2023-07-26 09:06:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:06:01 --> Database Driver Class Initialized
INFO - 2023-07-26 09:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:06:01 --> Parser Class Initialized
INFO - 2023-07-26 09:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:06:01 --> Pagination Class Initialized
INFO - 2023-07-26 09:06:01 --> Form Validation Class Initialized
INFO - 2023-07-26 09:06:01 --> Controller Class Initialized
INFO - 2023-07-26 09:06:01 --> Model Class Initialized
DEBUG - 2023-07-26 09:06:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:06:01 --> Model Class Initialized
INFO - 2023-07-26 09:06:01 --> Final output sent to browser
DEBUG - 2023-07-26 09:06:01 --> Total execution time: 0.0250
ERROR - 2023-07-26 09:06:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:06:53 --> Config Class Initialized
INFO - 2023-07-26 09:06:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:53 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:53 --> URI Class Initialized
INFO - 2023-07-26 09:06:53 --> Router Class Initialized
INFO - 2023-07-26 09:06:53 --> Output Class Initialized
INFO - 2023-07-26 09:06:53 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:53 --> Input Class Initialized
INFO - 2023-07-26 09:06:53 --> Language Class Initialized
INFO - 2023-07-26 09:06:53 --> Loader Class Initialized
INFO - 2023-07-26 09:06:53 --> Helper loaded: url_helper
INFO - 2023-07-26 09:06:53 --> Helper loaded: file_helper
INFO - 2023-07-26 09:06:53 --> Helper loaded: html_helper
INFO - 2023-07-26 09:06:53 --> Helper loaded: text_helper
INFO - 2023-07-26 09:06:53 --> Helper loaded: form_helper
INFO - 2023-07-26 09:06:53 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:06:53 --> Helper loaded: security_helper
INFO - 2023-07-26 09:06:53 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:06:53 --> Database Driver Class Initialized
INFO - 2023-07-26 09:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:06:53 --> Parser Class Initialized
INFO - 2023-07-26 09:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:06:53 --> Pagination Class Initialized
INFO - 2023-07-26 09:06:53 --> Form Validation Class Initialized
INFO - 2023-07-26 09:06:53 --> Controller Class Initialized
INFO - 2023-07-26 09:06:53 --> Model Class Initialized
INFO - 2023-07-26 09:06:53 --> Model Class Initialized
INFO - 2023-07-26 09:06:53 --> Model Class Initialized
INFO - 2023-07-26 09:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-26 09:06:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:06:53 --> Model Class Initialized
INFO - 2023-07-26 09:06:53 --> Model Class Initialized
INFO - 2023-07-26 09:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:06:53 --> Final output sent to browser
DEBUG - 2023-07-26 09:06:53 --> Total execution time: 0.1550
ERROR - 2023-07-26 09:06:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:06:54 --> Config Class Initialized
INFO - 2023-07-26 09:06:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:54 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:54 --> URI Class Initialized
INFO - 2023-07-26 09:06:54 --> Router Class Initialized
INFO - 2023-07-26 09:06:54 --> Output Class Initialized
INFO - 2023-07-26 09:06:54 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:54 --> Input Class Initialized
INFO - 2023-07-26 09:06:54 --> Language Class Initialized
INFO - 2023-07-26 09:06:54 --> Loader Class Initialized
INFO - 2023-07-26 09:06:54 --> Helper loaded: url_helper
INFO - 2023-07-26 09:06:54 --> Helper loaded: file_helper
INFO - 2023-07-26 09:06:54 --> Helper loaded: html_helper
INFO - 2023-07-26 09:06:54 --> Helper loaded: text_helper
INFO - 2023-07-26 09:06:54 --> Helper loaded: form_helper
INFO - 2023-07-26 09:06:54 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:06:54 --> Helper loaded: security_helper
INFO - 2023-07-26 09:06:54 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:06:54 --> Database Driver Class Initialized
INFO - 2023-07-26 09:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:06:54 --> Parser Class Initialized
INFO - 2023-07-26 09:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:06:54 --> Pagination Class Initialized
INFO - 2023-07-26 09:06:54 --> Form Validation Class Initialized
INFO - 2023-07-26 09:06:54 --> Controller Class Initialized
INFO - 2023-07-26 09:06:54 --> Model Class Initialized
INFO - 2023-07-26 09:06:54 --> Model Class Initialized
INFO - 2023-07-26 09:06:54 --> Final output sent to browser
DEBUG - 2023-07-26 09:06:54 --> Total execution time: 0.0238
ERROR - 2023-07-26 09:06:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:06:57 --> Config Class Initialized
INFO - 2023-07-26 09:06:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:57 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:57 --> URI Class Initialized
INFO - 2023-07-26 09:06:57 --> Router Class Initialized
INFO - 2023-07-26 09:06:57 --> Output Class Initialized
INFO - 2023-07-26 09:06:57 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:57 --> Input Class Initialized
INFO - 2023-07-26 09:06:57 --> Language Class Initialized
INFO - 2023-07-26 09:06:57 --> Loader Class Initialized
INFO - 2023-07-26 09:06:57 --> Helper loaded: url_helper
INFO - 2023-07-26 09:06:57 --> Helper loaded: file_helper
INFO - 2023-07-26 09:06:57 --> Helper loaded: html_helper
INFO - 2023-07-26 09:06:57 --> Helper loaded: text_helper
INFO - 2023-07-26 09:06:57 --> Helper loaded: form_helper
INFO - 2023-07-26 09:06:57 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:06:57 --> Helper loaded: security_helper
INFO - 2023-07-26 09:06:57 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:06:57 --> Database Driver Class Initialized
INFO - 2023-07-26 09:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:06:57 --> Parser Class Initialized
INFO - 2023-07-26 09:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:06:57 --> Pagination Class Initialized
INFO - 2023-07-26 09:06:57 --> Form Validation Class Initialized
INFO - 2023-07-26 09:06:57 --> Controller Class Initialized
INFO - 2023-07-26 09:06:57 --> Model Class Initialized
INFO - 2023-07-26 09:06:57 --> Model Class Initialized
INFO - 2023-07-26 09:06:57 --> Final output sent to browser
DEBUG - 2023-07-26 09:06:57 --> Total execution time: 0.0471
ERROR - 2023-07-26 09:07:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:07:29 --> Config Class Initialized
INFO - 2023-07-26 09:07:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:29 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:29 --> URI Class Initialized
INFO - 2023-07-26 09:07:29 --> Router Class Initialized
INFO - 2023-07-26 09:07:29 --> Output Class Initialized
INFO - 2023-07-26 09:07:29 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:29 --> Input Class Initialized
INFO - 2023-07-26 09:07:29 --> Language Class Initialized
INFO - 2023-07-26 09:07:29 --> Loader Class Initialized
INFO - 2023-07-26 09:07:29 --> Helper loaded: url_helper
INFO - 2023-07-26 09:07:29 --> Helper loaded: file_helper
INFO - 2023-07-26 09:07:29 --> Helper loaded: html_helper
INFO - 2023-07-26 09:07:29 --> Helper loaded: text_helper
INFO - 2023-07-26 09:07:29 --> Helper loaded: form_helper
INFO - 2023-07-26 09:07:29 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:07:29 --> Helper loaded: security_helper
INFO - 2023-07-26 09:07:29 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:07:29 --> Database Driver Class Initialized
INFO - 2023-07-26 09:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:07:29 --> Parser Class Initialized
INFO - 2023-07-26 09:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:07:29 --> Pagination Class Initialized
INFO - 2023-07-26 09:07:29 --> Form Validation Class Initialized
INFO - 2023-07-26 09:07:29 --> Controller Class Initialized
INFO - 2023-07-26 09:07:29 --> Model Class Initialized
DEBUG - 2023-07-26 09:07:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:29 --> Model Class Initialized
INFO - 2023-07-26 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-26 09:07:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:07:29 --> Model Class Initialized
INFO - 2023-07-26 09:07:29 --> Model Class Initialized
INFO - 2023-07-26 09:07:29 --> Model Class Initialized
INFO - 2023-07-26 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:07:29 --> Final output sent to browser
DEBUG - 2023-07-26 09:07:29 --> Total execution time: 0.0716
ERROR - 2023-07-26 09:07:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:07:30 --> Config Class Initialized
INFO - 2023-07-26 09:07:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:30 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:30 --> URI Class Initialized
INFO - 2023-07-26 09:07:30 --> Router Class Initialized
INFO - 2023-07-26 09:07:30 --> Output Class Initialized
INFO - 2023-07-26 09:07:30 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:30 --> Input Class Initialized
INFO - 2023-07-26 09:07:30 --> Language Class Initialized
INFO - 2023-07-26 09:07:30 --> Loader Class Initialized
INFO - 2023-07-26 09:07:30 --> Helper loaded: url_helper
INFO - 2023-07-26 09:07:30 --> Helper loaded: file_helper
INFO - 2023-07-26 09:07:30 --> Helper loaded: html_helper
INFO - 2023-07-26 09:07:30 --> Helper loaded: text_helper
INFO - 2023-07-26 09:07:30 --> Helper loaded: form_helper
INFO - 2023-07-26 09:07:30 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:07:30 --> Helper loaded: security_helper
INFO - 2023-07-26 09:07:30 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:07:30 --> Database Driver Class Initialized
INFO - 2023-07-26 09:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:07:30 --> Parser Class Initialized
INFO - 2023-07-26 09:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:07:30 --> Pagination Class Initialized
INFO - 2023-07-26 09:07:30 --> Form Validation Class Initialized
INFO - 2023-07-26 09:07:30 --> Controller Class Initialized
INFO - 2023-07-26 09:07:30 --> Model Class Initialized
DEBUG - 2023-07-26 09:07:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:30 --> Model Class Initialized
INFO - 2023-07-26 09:07:30 --> Final output sent to browser
DEBUG - 2023-07-26 09:07:30 --> Total execution time: 0.0228
ERROR - 2023-07-26 09:07:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:07:43 --> Config Class Initialized
INFO - 2023-07-26 09:07:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:43 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:43 --> URI Class Initialized
INFO - 2023-07-26 09:07:43 --> Router Class Initialized
INFO - 2023-07-26 09:07:43 --> Output Class Initialized
INFO - 2023-07-26 09:07:43 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:43 --> Input Class Initialized
INFO - 2023-07-26 09:07:43 --> Language Class Initialized
INFO - 2023-07-26 09:07:43 --> Loader Class Initialized
INFO - 2023-07-26 09:07:43 --> Helper loaded: url_helper
INFO - 2023-07-26 09:07:43 --> Helper loaded: file_helper
INFO - 2023-07-26 09:07:43 --> Helper loaded: html_helper
INFO - 2023-07-26 09:07:43 --> Helper loaded: text_helper
INFO - 2023-07-26 09:07:43 --> Helper loaded: form_helper
INFO - 2023-07-26 09:07:43 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:07:43 --> Helper loaded: security_helper
INFO - 2023-07-26 09:07:43 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:07:43 --> Database Driver Class Initialized
INFO - 2023-07-26 09:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:07:43 --> Parser Class Initialized
INFO - 2023-07-26 09:07:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:07:43 --> Pagination Class Initialized
INFO - 2023-07-26 09:07:43 --> Form Validation Class Initialized
INFO - 2023-07-26 09:07:43 --> Controller Class Initialized
INFO - 2023-07-26 09:07:43 --> Model Class Initialized
DEBUG - 2023-07-26 09:07:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:43 --> Model Class Initialized
INFO - 2023-07-26 09:07:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-07-26 09:07:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:07:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:07:43 --> Model Class Initialized
INFO - 2023-07-26 09:07:43 --> Model Class Initialized
INFO - 2023-07-26 09:07:43 --> Model Class Initialized
INFO - 2023-07-26 09:07:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:07:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:07:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:07:43 --> Final output sent to browser
DEBUG - 2023-07-26 09:07:43 --> Total execution time: 0.1493
ERROR - 2023-07-26 09:07:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:07:44 --> Config Class Initialized
INFO - 2023-07-26 09:07:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:44 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:44 --> URI Class Initialized
INFO - 2023-07-26 09:07:44 --> Router Class Initialized
INFO - 2023-07-26 09:07:44 --> Output Class Initialized
INFO - 2023-07-26 09:07:44 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:44 --> Input Class Initialized
INFO - 2023-07-26 09:07:44 --> Language Class Initialized
INFO - 2023-07-26 09:07:44 --> Loader Class Initialized
INFO - 2023-07-26 09:07:44 --> Helper loaded: url_helper
INFO - 2023-07-26 09:07:44 --> Helper loaded: file_helper
INFO - 2023-07-26 09:07:44 --> Helper loaded: html_helper
INFO - 2023-07-26 09:07:44 --> Helper loaded: text_helper
INFO - 2023-07-26 09:07:44 --> Helper loaded: form_helper
INFO - 2023-07-26 09:07:44 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:07:44 --> Helper loaded: security_helper
INFO - 2023-07-26 09:07:44 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:07:44 --> Database Driver Class Initialized
INFO - 2023-07-26 09:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:07:44 --> Parser Class Initialized
INFO - 2023-07-26 09:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:07:44 --> Pagination Class Initialized
INFO - 2023-07-26 09:07:44 --> Form Validation Class Initialized
INFO - 2023-07-26 09:07:44 --> Controller Class Initialized
INFO - 2023-07-26 09:07:44 --> Model Class Initialized
DEBUG - 2023-07-26 09:07:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:44 --> Model Class Initialized
INFO - 2023-07-26 09:07:44 --> Final output sent to browser
DEBUG - 2023-07-26 09:07:44 --> Total execution time: 0.0223
ERROR - 2023-07-26 09:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:07:54 --> Config Class Initialized
INFO - 2023-07-26 09:07:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:54 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:54 --> URI Class Initialized
DEBUG - 2023-07-26 09:07:54 --> No URI present. Default controller set.
INFO - 2023-07-26 09:07:54 --> Router Class Initialized
INFO - 2023-07-26 09:07:54 --> Output Class Initialized
INFO - 2023-07-26 09:07:54 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:54 --> Input Class Initialized
INFO - 2023-07-26 09:07:54 --> Language Class Initialized
INFO - 2023-07-26 09:07:54 --> Loader Class Initialized
INFO - 2023-07-26 09:07:54 --> Helper loaded: url_helper
INFO - 2023-07-26 09:07:54 --> Helper loaded: file_helper
INFO - 2023-07-26 09:07:54 --> Helper loaded: html_helper
INFO - 2023-07-26 09:07:54 --> Helper loaded: text_helper
INFO - 2023-07-26 09:07:54 --> Helper loaded: form_helper
INFO - 2023-07-26 09:07:54 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:07:54 --> Helper loaded: security_helper
INFO - 2023-07-26 09:07:54 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:07:54 --> Database Driver Class Initialized
INFO - 2023-07-26 09:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:07:54 --> Parser Class Initialized
INFO - 2023-07-26 09:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:07:54 --> Pagination Class Initialized
INFO - 2023-07-26 09:07:54 --> Form Validation Class Initialized
INFO - 2023-07-26 09:07:54 --> Controller Class Initialized
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
DEBUG - 2023-07-26 09:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
DEBUG - 2023-07-26 09:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
DEBUG - 2023-07-26 09:07:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
INFO - 2023-07-26 09:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 09:07:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:07:54 --> Model Class Initialized
INFO - 2023-07-26 09:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:07:54 --> Final output sent to browser
DEBUG - 2023-07-26 09:07:54 --> Total execution time: 0.1920
ERROR - 2023-07-26 09:10:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:10:03 --> Config Class Initialized
INFO - 2023-07-26 09:10:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:10:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:10:03 --> Utf8 Class Initialized
INFO - 2023-07-26 09:10:03 --> URI Class Initialized
DEBUG - 2023-07-26 09:10:03 --> No URI present. Default controller set.
INFO - 2023-07-26 09:10:03 --> Router Class Initialized
INFO - 2023-07-26 09:10:03 --> Output Class Initialized
INFO - 2023-07-26 09:10:03 --> Security Class Initialized
DEBUG - 2023-07-26 09:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:10:03 --> Input Class Initialized
INFO - 2023-07-26 09:10:03 --> Language Class Initialized
INFO - 2023-07-26 09:10:03 --> Loader Class Initialized
INFO - 2023-07-26 09:10:03 --> Helper loaded: url_helper
INFO - 2023-07-26 09:10:03 --> Helper loaded: file_helper
INFO - 2023-07-26 09:10:03 --> Helper loaded: html_helper
INFO - 2023-07-26 09:10:03 --> Helper loaded: text_helper
INFO - 2023-07-26 09:10:03 --> Helper loaded: form_helper
INFO - 2023-07-26 09:10:03 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:10:03 --> Helper loaded: security_helper
INFO - 2023-07-26 09:10:03 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:10:03 --> Database Driver Class Initialized
INFO - 2023-07-26 09:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:10:03 --> Parser Class Initialized
INFO - 2023-07-26 09:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:10:03 --> Pagination Class Initialized
INFO - 2023-07-26 09:10:03 --> Form Validation Class Initialized
INFO - 2023-07-26 09:10:03 --> Controller Class Initialized
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
DEBUG - 2023-07-26 09:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
DEBUG - 2023-07-26 09:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
DEBUG - 2023-07-26 09:10:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
INFO - 2023-07-26 09:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 09:10:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:10:03 --> Model Class Initialized
INFO - 2023-07-26 09:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:10:03 --> Final output sent to browser
DEBUG - 2023-07-26 09:10:03 --> Total execution time: 0.0848
ERROR - 2023-07-26 09:15:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 09:15:06 --> Config Class Initialized
INFO - 2023-07-26 09:15:06 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:15:06 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:15:06 --> Utf8 Class Initialized
INFO - 2023-07-26 09:15:06 --> URI Class Initialized
DEBUG - 2023-07-26 09:15:06 --> No URI present. Default controller set.
INFO - 2023-07-26 09:15:06 --> Router Class Initialized
INFO - 2023-07-26 09:15:06 --> Output Class Initialized
INFO - 2023-07-26 09:15:06 --> Security Class Initialized
DEBUG - 2023-07-26 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:15:06 --> Input Class Initialized
INFO - 2023-07-26 09:15:06 --> Language Class Initialized
INFO - 2023-07-26 09:15:06 --> Loader Class Initialized
INFO - 2023-07-26 09:15:06 --> Helper loaded: url_helper
INFO - 2023-07-26 09:15:06 --> Helper loaded: file_helper
INFO - 2023-07-26 09:15:06 --> Helper loaded: html_helper
INFO - 2023-07-26 09:15:06 --> Helper loaded: text_helper
INFO - 2023-07-26 09:15:06 --> Helper loaded: form_helper
INFO - 2023-07-26 09:15:06 --> Helper loaded: lang_helper
INFO - 2023-07-26 09:15:06 --> Helper loaded: security_helper
INFO - 2023-07-26 09:15:06 --> Helper loaded: cookie_helper
INFO - 2023-07-26 09:15:06 --> Database Driver Class Initialized
INFO - 2023-07-26 09:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:15:06 --> Parser Class Initialized
INFO - 2023-07-26 09:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 09:15:06 --> Pagination Class Initialized
INFO - 2023-07-26 09:15:06 --> Form Validation Class Initialized
INFO - 2023-07-26 09:15:06 --> Controller Class Initialized
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
DEBUG - 2023-07-26 09:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
DEBUG - 2023-07-26 09:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
DEBUG - 2023-07-26 09:15:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 09:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
INFO - 2023-07-26 09:15:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 09:15:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:15:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 09:15:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 09:15:06 --> Model Class Initialized
INFO - 2023-07-26 09:15:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 09:15:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 09:15:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 09:15:06 --> Final output sent to browser
DEBUG - 2023-07-26 09:15:06 --> Total execution time: 0.0974
ERROR - 2023-07-26 14:14:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 14:14:43 --> Config Class Initialized
INFO - 2023-07-26 14:14:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 14:14:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 14:14:43 --> Utf8 Class Initialized
INFO - 2023-07-26 14:14:43 --> URI Class Initialized
DEBUG - 2023-07-26 14:14:43 --> No URI present. Default controller set.
INFO - 2023-07-26 14:14:43 --> Router Class Initialized
INFO - 2023-07-26 14:14:43 --> Output Class Initialized
INFO - 2023-07-26 14:14:43 --> Security Class Initialized
DEBUG - 2023-07-26 14:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 14:14:43 --> Input Class Initialized
INFO - 2023-07-26 14:14:43 --> Language Class Initialized
INFO - 2023-07-26 14:14:43 --> Loader Class Initialized
INFO - 2023-07-26 14:14:43 --> Helper loaded: url_helper
INFO - 2023-07-26 14:14:43 --> Helper loaded: file_helper
INFO - 2023-07-26 14:14:43 --> Helper loaded: html_helper
INFO - 2023-07-26 14:14:43 --> Helper loaded: text_helper
INFO - 2023-07-26 14:14:43 --> Helper loaded: form_helper
INFO - 2023-07-26 14:14:43 --> Helper loaded: lang_helper
INFO - 2023-07-26 14:14:43 --> Helper loaded: security_helper
INFO - 2023-07-26 14:14:43 --> Helper loaded: cookie_helper
INFO - 2023-07-26 14:14:43 --> Database Driver Class Initialized
INFO - 2023-07-26 14:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 14:14:43 --> Parser Class Initialized
INFO - 2023-07-26 14:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 14:14:43 --> Pagination Class Initialized
INFO - 2023-07-26 14:14:43 --> Form Validation Class Initialized
INFO - 2023-07-26 14:14:43 --> Controller Class Initialized
INFO - 2023-07-26 14:14:43 --> Model Class Initialized
DEBUG - 2023-07-26 14:14:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 14:14:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 14:14:44 --> Config Class Initialized
INFO - 2023-07-26 14:14:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 14:14:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 14:14:44 --> Utf8 Class Initialized
INFO - 2023-07-26 14:14:44 --> URI Class Initialized
INFO - 2023-07-26 14:14:44 --> Router Class Initialized
INFO - 2023-07-26 14:14:44 --> Output Class Initialized
INFO - 2023-07-26 14:14:44 --> Security Class Initialized
DEBUG - 2023-07-26 14:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 14:14:44 --> Input Class Initialized
INFO - 2023-07-26 14:14:44 --> Language Class Initialized
INFO - 2023-07-26 14:14:44 --> Loader Class Initialized
INFO - 2023-07-26 14:14:44 --> Helper loaded: url_helper
INFO - 2023-07-26 14:14:44 --> Helper loaded: file_helper
INFO - 2023-07-26 14:14:44 --> Helper loaded: html_helper
INFO - 2023-07-26 14:14:44 --> Helper loaded: text_helper
INFO - 2023-07-26 14:14:44 --> Helper loaded: form_helper
INFO - 2023-07-26 14:14:44 --> Helper loaded: lang_helper
INFO - 2023-07-26 14:14:44 --> Helper loaded: security_helper
INFO - 2023-07-26 14:14:44 --> Helper loaded: cookie_helper
INFO - 2023-07-26 14:14:44 --> Database Driver Class Initialized
INFO - 2023-07-26 14:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 14:14:44 --> Parser Class Initialized
INFO - 2023-07-26 14:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 14:14:44 --> Pagination Class Initialized
INFO - 2023-07-26 14:14:44 --> Form Validation Class Initialized
INFO - 2023-07-26 14:14:44 --> Controller Class Initialized
INFO - 2023-07-26 14:14:44 --> Model Class Initialized
DEBUG - 2023-07-26 14:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 14:14:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 14:14:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 14:14:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 14:14:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 14:14:44 --> Model Class Initialized
INFO - 2023-07-26 14:14:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 14:14:44 --> Final output sent to browser
DEBUG - 2023-07-26 14:14:44 --> Total execution time: 0.0323
ERROR - 2023-07-26 15:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 15:57:48 --> Config Class Initialized
INFO - 2023-07-26 15:57:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 15:57:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 15:57:48 --> Utf8 Class Initialized
INFO - 2023-07-26 15:57:48 --> URI Class Initialized
DEBUG - 2023-07-26 15:57:48 --> No URI present. Default controller set.
INFO - 2023-07-26 15:57:48 --> Router Class Initialized
INFO - 2023-07-26 15:57:48 --> Output Class Initialized
INFO - 2023-07-26 15:57:48 --> Security Class Initialized
DEBUG - 2023-07-26 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 15:57:48 --> Input Class Initialized
INFO - 2023-07-26 15:57:48 --> Language Class Initialized
INFO - 2023-07-26 15:57:48 --> Loader Class Initialized
INFO - 2023-07-26 15:57:48 --> Helper loaded: url_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: file_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: html_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: text_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: form_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: lang_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: security_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: cookie_helper
INFO - 2023-07-26 15:57:48 --> Database Driver Class Initialized
INFO - 2023-07-26 15:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 15:57:48 --> Parser Class Initialized
INFO - 2023-07-26 15:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 15:57:48 --> Pagination Class Initialized
INFO - 2023-07-26 15:57:48 --> Form Validation Class Initialized
INFO - 2023-07-26 15:57:48 --> Controller Class Initialized
INFO - 2023-07-26 15:57:48 --> Model Class Initialized
DEBUG - 2023-07-26 15:57:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 15:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 15:57:48 --> Config Class Initialized
INFO - 2023-07-26 15:57:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 15:57:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 15:57:48 --> Utf8 Class Initialized
INFO - 2023-07-26 15:57:48 --> URI Class Initialized
INFO - 2023-07-26 15:57:48 --> Router Class Initialized
INFO - 2023-07-26 15:57:48 --> Output Class Initialized
INFO - 2023-07-26 15:57:48 --> Security Class Initialized
DEBUG - 2023-07-26 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 15:57:48 --> Input Class Initialized
INFO - 2023-07-26 15:57:48 --> Language Class Initialized
INFO - 2023-07-26 15:57:48 --> Loader Class Initialized
INFO - 2023-07-26 15:57:48 --> Helper loaded: url_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: file_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: html_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: text_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: form_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: lang_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: security_helper
INFO - 2023-07-26 15:57:48 --> Helper loaded: cookie_helper
INFO - 2023-07-26 15:57:48 --> Database Driver Class Initialized
INFO - 2023-07-26 15:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 15:57:48 --> Parser Class Initialized
INFO - 2023-07-26 15:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 15:57:48 --> Pagination Class Initialized
INFO - 2023-07-26 15:57:48 --> Form Validation Class Initialized
INFO - 2023-07-26 15:57:48 --> Controller Class Initialized
INFO - 2023-07-26 15:57:48 --> Model Class Initialized
DEBUG - 2023-07-26 15:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 15:57:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 15:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 15:57:48 --> Model Class Initialized
INFO - 2023-07-26 15:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 15:57:48 --> Final output sent to browser
DEBUG - 2023-07-26 15:57:48 --> Total execution time: 0.0311
ERROR - 2023-07-26 15:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 15:57:53 --> Config Class Initialized
INFO - 2023-07-26 15:57:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 15:57:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 15:57:53 --> Utf8 Class Initialized
INFO - 2023-07-26 15:57:53 --> URI Class Initialized
INFO - 2023-07-26 15:57:53 --> Router Class Initialized
INFO - 2023-07-26 15:57:53 --> Output Class Initialized
INFO - 2023-07-26 15:57:53 --> Security Class Initialized
DEBUG - 2023-07-26 15:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 15:57:53 --> Input Class Initialized
INFO - 2023-07-26 15:57:53 --> Language Class Initialized
INFO - 2023-07-26 15:57:53 --> Loader Class Initialized
INFO - 2023-07-26 15:57:53 --> Helper loaded: url_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: file_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: html_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: text_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: form_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: lang_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: security_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: cookie_helper
INFO - 2023-07-26 15:57:53 --> Database Driver Class Initialized
INFO - 2023-07-26 15:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 15:57:53 --> Parser Class Initialized
INFO - 2023-07-26 15:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 15:57:53 --> Pagination Class Initialized
INFO - 2023-07-26 15:57:53 --> Form Validation Class Initialized
INFO - 2023-07-26 15:57:53 --> Controller Class Initialized
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
DEBUG - 2023-07-26 15:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
INFO - 2023-07-26 15:57:53 --> Final output sent to browser
DEBUG - 2023-07-26 15:57:53 --> Total execution time: 0.0200
ERROR - 2023-07-26 15:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 15:57:53 --> Config Class Initialized
INFO - 2023-07-26 15:57:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 15:57:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 15:57:53 --> Utf8 Class Initialized
INFO - 2023-07-26 15:57:53 --> URI Class Initialized
DEBUG - 2023-07-26 15:57:53 --> No URI present. Default controller set.
INFO - 2023-07-26 15:57:53 --> Router Class Initialized
INFO - 2023-07-26 15:57:53 --> Output Class Initialized
INFO - 2023-07-26 15:57:53 --> Security Class Initialized
DEBUG - 2023-07-26 15:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 15:57:53 --> Input Class Initialized
INFO - 2023-07-26 15:57:53 --> Language Class Initialized
INFO - 2023-07-26 15:57:53 --> Loader Class Initialized
INFO - 2023-07-26 15:57:53 --> Helper loaded: url_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: file_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: html_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: text_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: form_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: lang_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: security_helper
INFO - 2023-07-26 15:57:53 --> Helper loaded: cookie_helper
INFO - 2023-07-26 15:57:53 --> Database Driver Class Initialized
INFO - 2023-07-26 15:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 15:57:53 --> Parser Class Initialized
INFO - 2023-07-26 15:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 15:57:53 --> Pagination Class Initialized
INFO - 2023-07-26 15:57:53 --> Form Validation Class Initialized
INFO - 2023-07-26 15:57:53 --> Controller Class Initialized
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
DEBUG - 2023-07-26 15:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
DEBUG - 2023-07-26 15:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
DEBUG - 2023-07-26 15:57:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 15:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
INFO - 2023-07-26 15:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 15:57:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 15:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 15:57:53 --> Model Class Initialized
INFO - 2023-07-26 15:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 15:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 15:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 15:57:53 --> Final output sent to browser
DEBUG - 2023-07-26 15:57:53 --> Total execution time: 0.0940
ERROR - 2023-07-26 15:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 15:58:04 --> Config Class Initialized
INFO - 2023-07-26 15:58:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 15:58:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 15:58:04 --> Utf8 Class Initialized
INFO - 2023-07-26 15:58:04 --> URI Class Initialized
INFO - 2023-07-26 15:58:04 --> Router Class Initialized
INFO - 2023-07-26 15:58:04 --> Output Class Initialized
INFO - 2023-07-26 15:58:04 --> Security Class Initialized
DEBUG - 2023-07-26 15:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 15:58:04 --> Input Class Initialized
INFO - 2023-07-26 15:58:04 --> Language Class Initialized
INFO - 2023-07-26 15:58:04 --> Loader Class Initialized
INFO - 2023-07-26 15:58:04 --> Helper loaded: url_helper
INFO - 2023-07-26 15:58:04 --> Helper loaded: file_helper
INFO - 2023-07-26 15:58:04 --> Helper loaded: html_helper
INFO - 2023-07-26 15:58:04 --> Helper loaded: text_helper
INFO - 2023-07-26 15:58:04 --> Helper loaded: form_helper
INFO - 2023-07-26 15:58:04 --> Helper loaded: lang_helper
INFO - 2023-07-26 15:58:04 --> Helper loaded: security_helper
INFO - 2023-07-26 15:58:04 --> Helper loaded: cookie_helper
INFO - 2023-07-26 15:58:04 --> Database Driver Class Initialized
INFO - 2023-07-26 15:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 15:58:04 --> Parser Class Initialized
INFO - 2023-07-26 15:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 15:58:04 --> Pagination Class Initialized
INFO - 2023-07-26 15:58:04 --> Form Validation Class Initialized
INFO - 2023-07-26 15:58:04 --> Controller Class Initialized
INFO - 2023-07-26 15:58:04 --> Model Class Initialized
DEBUG - 2023-07-26 15:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 15:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:58:04 --> Model Class Initialized
INFO - 2023-07-26 15:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-26 15:58:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 15:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 15:58:04 --> Model Class Initialized
INFO - 2023-07-26 15:58:04 --> Model Class Initialized
INFO - 2023-07-26 15:58:04 --> Model Class Initialized
INFO - 2023-07-26 15:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 15:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 15:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 15:58:04 --> Final output sent to browser
DEBUG - 2023-07-26 15:58:04 --> Total execution time: 0.0713
ERROR - 2023-07-26 15:58:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 15:58:05 --> Config Class Initialized
INFO - 2023-07-26 15:58:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 15:58:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 15:58:05 --> Utf8 Class Initialized
INFO - 2023-07-26 15:58:05 --> URI Class Initialized
INFO - 2023-07-26 15:58:05 --> Router Class Initialized
INFO - 2023-07-26 15:58:05 --> Output Class Initialized
INFO - 2023-07-26 15:58:05 --> Security Class Initialized
DEBUG - 2023-07-26 15:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 15:58:05 --> Input Class Initialized
INFO - 2023-07-26 15:58:05 --> Language Class Initialized
INFO - 2023-07-26 15:58:05 --> Loader Class Initialized
INFO - 2023-07-26 15:58:05 --> Helper loaded: url_helper
INFO - 2023-07-26 15:58:05 --> Helper loaded: file_helper
INFO - 2023-07-26 15:58:05 --> Helper loaded: html_helper
INFO - 2023-07-26 15:58:05 --> Helper loaded: text_helper
INFO - 2023-07-26 15:58:05 --> Helper loaded: form_helper
INFO - 2023-07-26 15:58:05 --> Helper loaded: lang_helper
INFO - 2023-07-26 15:58:05 --> Helper loaded: security_helper
INFO - 2023-07-26 15:58:05 --> Helper loaded: cookie_helper
INFO - 2023-07-26 15:58:05 --> Database Driver Class Initialized
INFO - 2023-07-26 15:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 15:58:05 --> Parser Class Initialized
INFO - 2023-07-26 15:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 15:58:05 --> Pagination Class Initialized
INFO - 2023-07-26 15:58:05 --> Form Validation Class Initialized
INFO - 2023-07-26 15:58:05 --> Controller Class Initialized
INFO - 2023-07-26 15:58:05 --> Model Class Initialized
DEBUG - 2023-07-26 15:58:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 15:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:58:05 --> Model Class Initialized
INFO - 2023-07-26 15:58:05 --> Final output sent to browser
DEBUG - 2023-07-26 15:58:05 --> Total execution time: 0.0258
ERROR - 2023-07-26 15:58:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 15:58:12 --> Config Class Initialized
INFO - 2023-07-26 15:58:12 --> Hooks Class Initialized
DEBUG - 2023-07-26 15:58:12 --> UTF-8 Support Enabled
INFO - 2023-07-26 15:58:12 --> Utf8 Class Initialized
INFO - 2023-07-26 15:58:12 --> URI Class Initialized
INFO - 2023-07-26 15:58:12 --> Router Class Initialized
INFO - 2023-07-26 15:58:12 --> Output Class Initialized
INFO - 2023-07-26 15:58:12 --> Security Class Initialized
DEBUG - 2023-07-26 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 15:58:12 --> Input Class Initialized
INFO - 2023-07-26 15:58:12 --> Language Class Initialized
INFO - 2023-07-26 15:58:12 --> Loader Class Initialized
INFO - 2023-07-26 15:58:12 --> Helper loaded: url_helper
INFO - 2023-07-26 15:58:12 --> Helper loaded: file_helper
INFO - 2023-07-26 15:58:12 --> Helper loaded: html_helper
INFO - 2023-07-26 15:58:12 --> Helper loaded: text_helper
INFO - 2023-07-26 15:58:12 --> Helper loaded: form_helper
INFO - 2023-07-26 15:58:12 --> Helper loaded: lang_helper
INFO - 2023-07-26 15:58:12 --> Helper loaded: security_helper
INFO - 2023-07-26 15:58:12 --> Helper loaded: cookie_helper
INFO - 2023-07-26 15:58:12 --> Database Driver Class Initialized
INFO - 2023-07-26 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 15:58:12 --> Parser Class Initialized
INFO - 2023-07-26 15:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 15:58:12 --> Pagination Class Initialized
INFO - 2023-07-26 15:58:12 --> Form Validation Class Initialized
INFO - 2023-07-26 15:58:12 --> Controller Class Initialized
INFO - 2023-07-26 15:58:12 --> Model Class Initialized
DEBUG - 2023-07-26 15:58:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 15:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 15:58:12 --> Model Class Initialized
INFO - 2023-07-26 15:58:12 --> Final output sent to browser
DEBUG - 2023-07-26 15:58:12 --> Total execution time: 0.0235
ERROR - 2023-07-26 16:07:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:07:41 --> Config Class Initialized
INFO - 2023-07-26 16:07:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:07:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:07:41 --> Utf8 Class Initialized
INFO - 2023-07-26 16:07:41 --> URI Class Initialized
INFO - 2023-07-26 16:07:41 --> Router Class Initialized
INFO - 2023-07-26 16:07:41 --> Output Class Initialized
INFO - 2023-07-26 16:07:41 --> Security Class Initialized
DEBUG - 2023-07-26 16:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:07:41 --> Input Class Initialized
INFO - 2023-07-26 16:07:41 --> Language Class Initialized
INFO - 2023-07-26 16:07:41 --> Loader Class Initialized
INFO - 2023-07-26 16:07:41 --> Helper loaded: url_helper
INFO - 2023-07-26 16:07:41 --> Helper loaded: file_helper
INFO - 2023-07-26 16:07:41 --> Helper loaded: html_helper
INFO - 2023-07-26 16:07:41 --> Helper loaded: text_helper
INFO - 2023-07-26 16:07:41 --> Helper loaded: form_helper
INFO - 2023-07-26 16:07:41 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:07:41 --> Helper loaded: security_helper
INFO - 2023-07-26 16:07:41 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:07:41 --> Database Driver Class Initialized
INFO - 2023-07-26 16:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:07:41 --> Parser Class Initialized
INFO - 2023-07-26 16:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:07:41 --> Pagination Class Initialized
INFO - 2023-07-26 16:07:41 --> Form Validation Class Initialized
INFO - 2023-07-26 16:07:41 --> Controller Class Initialized
INFO - 2023-07-26 16:07:41 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:41 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:41 --> Model Class Initialized
INFO - 2023-07-26 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-26 16:07:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 16:07:41 --> Model Class Initialized
INFO - 2023-07-26 16:07:41 --> Model Class Initialized
INFO - 2023-07-26 16:07:41 --> Model Class Initialized
INFO - 2023-07-26 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 16:07:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 16:07:41 --> Final output sent to browser
DEBUG - 2023-07-26 16:07:41 --> Total execution time: 0.1138
ERROR - 2023-07-26 16:07:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:07:50 --> Config Class Initialized
INFO - 2023-07-26 16:07:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:07:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:07:50 --> Utf8 Class Initialized
INFO - 2023-07-26 16:07:50 --> URI Class Initialized
INFO - 2023-07-26 16:07:50 --> Router Class Initialized
INFO - 2023-07-26 16:07:50 --> Output Class Initialized
INFO - 2023-07-26 16:07:50 --> Security Class Initialized
DEBUG - 2023-07-26 16:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:07:50 --> Input Class Initialized
INFO - 2023-07-26 16:07:50 --> Language Class Initialized
INFO - 2023-07-26 16:07:50 --> Loader Class Initialized
INFO - 2023-07-26 16:07:50 --> Helper loaded: url_helper
INFO - 2023-07-26 16:07:50 --> Helper loaded: file_helper
INFO - 2023-07-26 16:07:50 --> Helper loaded: html_helper
INFO - 2023-07-26 16:07:50 --> Helper loaded: text_helper
INFO - 2023-07-26 16:07:50 --> Helper loaded: form_helper
INFO - 2023-07-26 16:07:50 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:07:50 --> Helper loaded: security_helper
INFO - 2023-07-26 16:07:50 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:07:50 --> Database Driver Class Initialized
INFO - 2023-07-26 16:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:07:50 --> Parser Class Initialized
INFO - 2023-07-26 16:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:07:50 --> Pagination Class Initialized
INFO - 2023-07-26 16:07:50 --> Form Validation Class Initialized
INFO - 2023-07-26 16:07:50 --> Controller Class Initialized
INFO - 2023-07-26 16:07:50 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:50 --> Final output sent to browser
DEBUG - 2023-07-26 16:07:50 --> Total execution time: 0.0161
ERROR - 2023-07-26 16:07:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:07:52 --> Config Class Initialized
INFO - 2023-07-26 16:07:52 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:07:52 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:07:52 --> Utf8 Class Initialized
INFO - 2023-07-26 16:07:52 --> URI Class Initialized
INFO - 2023-07-26 16:07:52 --> Router Class Initialized
INFO - 2023-07-26 16:07:52 --> Output Class Initialized
INFO - 2023-07-26 16:07:52 --> Security Class Initialized
DEBUG - 2023-07-26 16:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:07:52 --> Input Class Initialized
INFO - 2023-07-26 16:07:52 --> Language Class Initialized
INFO - 2023-07-26 16:07:52 --> Loader Class Initialized
INFO - 2023-07-26 16:07:52 --> Helper loaded: url_helper
INFO - 2023-07-26 16:07:52 --> Helper loaded: file_helper
INFO - 2023-07-26 16:07:52 --> Helper loaded: html_helper
INFO - 2023-07-26 16:07:52 --> Helper loaded: text_helper
INFO - 2023-07-26 16:07:52 --> Helper loaded: form_helper
INFO - 2023-07-26 16:07:52 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:07:52 --> Helper loaded: security_helper
INFO - 2023-07-26 16:07:52 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:07:52 --> Database Driver Class Initialized
INFO - 2023-07-26 16:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:07:52 --> Parser Class Initialized
INFO - 2023-07-26 16:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:07:52 --> Pagination Class Initialized
INFO - 2023-07-26 16:07:52 --> Form Validation Class Initialized
INFO - 2023-07-26 16:07:52 --> Controller Class Initialized
INFO - 2023-07-26 16:07:52 --> Final output sent to browser
DEBUG - 2023-07-26 16:07:52 --> Total execution time: 0.0142
ERROR - 2023-07-26 16:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:07:54 --> Config Class Initialized
INFO - 2023-07-26 16:07:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:07:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:07:54 --> Utf8 Class Initialized
INFO - 2023-07-26 16:07:54 --> URI Class Initialized
INFO - 2023-07-26 16:07:54 --> Router Class Initialized
INFO - 2023-07-26 16:07:54 --> Output Class Initialized
INFO - 2023-07-26 16:07:54 --> Security Class Initialized
DEBUG - 2023-07-26 16:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:07:54 --> Input Class Initialized
INFO - 2023-07-26 16:07:54 --> Language Class Initialized
INFO - 2023-07-26 16:07:54 --> Loader Class Initialized
INFO - 2023-07-26 16:07:54 --> Helper loaded: url_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: file_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: html_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: text_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: form_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: security_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:07:54 --> Database Driver Class Initialized
INFO - 2023-07-26 16:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:07:54 --> Parser Class Initialized
INFO - 2023-07-26 16:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:07:54 --> Pagination Class Initialized
INFO - 2023-07-26 16:07:54 --> Form Validation Class Initialized
INFO - 2023-07-26 16:07:54 --> Controller Class Initialized
INFO - 2023-07-26 16:07:54 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:54 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:54 --> Model Class Initialized
INFO - 2023-07-26 16:07:54 --> Final output sent to browser
DEBUG - 2023-07-26 16:07:54 --> Total execution time: 0.0407
ERROR - 2023-07-26 16:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:07:54 --> Config Class Initialized
INFO - 2023-07-26 16:07:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:07:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:07:54 --> Utf8 Class Initialized
INFO - 2023-07-26 16:07:54 --> URI Class Initialized
INFO - 2023-07-26 16:07:54 --> Router Class Initialized
INFO - 2023-07-26 16:07:54 --> Output Class Initialized
INFO - 2023-07-26 16:07:54 --> Security Class Initialized
DEBUG - 2023-07-26 16:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:07:54 --> Input Class Initialized
INFO - 2023-07-26 16:07:54 --> Language Class Initialized
INFO - 2023-07-26 16:07:54 --> Loader Class Initialized
INFO - 2023-07-26 16:07:54 --> Helper loaded: url_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: file_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: html_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: text_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: form_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: security_helper
INFO - 2023-07-26 16:07:54 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:07:54 --> Database Driver Class Initialized
INFO - 2023-07-26 16:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:07:54 --> Parser Class Initialized
INFO - 2023-07-26 16:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:07:54 --> Pagination Class Initialized
INFO - 2023-07-26 16:07:54 --> Form Validation Class Initialized
INFO - 2023-07-26 16:07:54 --> Controller Class Initialized
INFO - 2023-07-26 16:07:54 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:54 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:54 --> Model Class Initialized
INFO - 2023-07-26 16:07:54 --> Final output sent to browser
DEBUG - 2023-07-26 16:07:54 --> Total execution time: 0.0394
ERROR - 2023-07-26 16:07:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:07:55 --> Config Class Initialized
INFO - 2023-07-26 16:07:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:07:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:07:55 --> Utf8 Class Initialized
INFO - 2023-07-26 16:07:55 --> URI Class Initialized
INFO - 2023-07-26 16:07:55 --> Router Class Initialized
INFO - 2023-07-26 16:07:55 --> Output Class Initialized
INFO - 2023-07-26 16:07:55 --> Security Class Initialized
DEBUG - 2023-07-26 16:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:07:55 --> Input Class Initialized
INFO - 2023-07-26 16:07:55 --> Language Class Initialized
INFO - 2023-07-26 16:07:55 --> Loader Class Initialized
INFO - 2023-07-26 16:07:55 --> Helper loaded: url_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: file_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: html_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: text_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: form_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: security_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:07:55 --> Database Driver Class Initialized
INFO - 2023-07-26 16:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:07:55 --> Parser Class Initialized
INFO - 2023-07-26 16:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:07:55 --> Pagination Class Initialized
INFO - 2023-07-26 16:07:55 --> Form Validation Class Initialized
INFO - 2023-07-26 16:07:55 --> Controller Class Initialized
INFO - 2023-07-26 16:07:55 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:55 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:55 --> Model Class Initialized
INFO - 2023-07-26 16:07:55 --> Final output sent to browser
DEBUG - 2023-07-26 16:07:55 --> Total execution time: 0.0405
ERROR - 2023-07-26 16:07:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:07:55 --> Config Class Initialized
INFO - 2023-07-26 16:07:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:07:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:07:55 --> Utf8 Class Initialized
INFO - 2023-07-26 16:07:55 --> URI Class Initialized
INFO - 2023-07-26 16:07:55 --> Router Class Initialized
INFO - 2023-07-26 16:07:55 --> Output Class Initialized
INFO - 2023-07-26 16:07:55 --> Security Class Initialized
DEBUG - 2023-07-26 16:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:07:55 --> Input Class Initialized
INFO - 2023-07-26 16:07:55 --> Language Class Initialized
INFO - 2023-07-26 16:07:55 --> Loader Class Initialized
INFO - 2023-07-26 16:07:55 --> Helper loaded: url_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: file_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: html_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: text_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: form_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: security_helper
INFO - 2023-07-26 16:07:55 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:07:55 --> Database Driver Class Initialized
INFO - 2023-07-26 16:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:07:55 --> Parser Class Initialized
INFO - 2023-07-26 16:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:07:55 --> Pagination Class Initialized
INFO - 2023-07-26 16:07:55 --> Form Validation Class Initialized
INFO - 2023-07-26 16:07:55 --> Controller Class Initialized
INFO - 2023-07-26 16:07:55 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:55 --> Model Class Initialized
DEBUG - 2023-07-26 16:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:07:55 --> Model Class Initialized
INFO - 2023-07-26 16:07:55 --> Final output sent to browser
DEBUG - 2023-07-26 16:07:55 --> Total execution time: 0.0397
ERROR - 2023-07-26 16:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:01 --> Config Class Initialized
INFO - 2023-07-26 16:08:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:01 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:01 --> URI Class Initialized
INFO - 2023-07-26 16:08:01 --> Router Class Initialized
INFO - 2023-07-26 16:08:01 --> Output Class Initialized
INFO - 2023-07-26 16:08:01 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:01 --> Input Class Initialized
INFO - 2023-07-26 16:08:01 --> Language Class Initialized
INFO - 2023-07-26 16:08:01 --> Loader Class Initialized
INFO - 2023-07-26 16:08:01 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:01 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:01 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:01 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:01 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:01 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:01 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:01 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:01 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:01 --> Parser Class Initialized
INFO - 2023-07-26 16:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:01 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:01 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:01 --> Controller Class Initialized
INFO - 2023-07-26 16:08:01 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:01 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:01 --> Model Class Initialized
INFO - 2023-07-26 16:08:01 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:01 --> Total execution time: 0.0179
ERROR - 2023-07-26 16:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:02 --> Config Class Initialized
INFO - 2023-07-26 16:08:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:02 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:02 --> URI Class Initialized
INFO - 2023-07-26 16:08:02 --> Router Class Initialized
INFO - 2023-07-26 16:08:02 --> Output Class Initialized
INFO - 2023-07-26 16:08:02 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:02 --> Input Class Initialized
INFO - 2023-07-26 16:08:02 --> Language Class Initialized
INFO - 2023-07-26 16:08:02 --> Loader Class Initialized
INFO - 2023-07-26 16:08:02 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:02 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:02 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:02 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:02 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:02 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:02 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:02 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:02 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:02 --> Parser Class Initialized
INFO - 2023-07-26 16:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:02 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:02 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:02 --> Controller Class Initialized
INFO - 2023-07-26 16:08:02 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:02 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:02 --> Model Class Initialized
INFO - 2023-07-26 16:08:02 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:02 --> Total execution time: 0.0187
ERROR - 2023-07-26 16:08:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:04 --> Config Class Initialized
INFO - 2023-07-26 16:08:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:04 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:04 --> URI Class Initialized
INFO - 2023-07-26 16:08:04 --> Router Class Initialized
INFO - 2023-07-26 16:08:04 --> Output Class Initialized
INFO - 2023-07-26 16:08:04 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:04 --> Input Class Initialized
INFO - 2023-07-26 16:08:04 --> Language Class Initialized
INFO - 2023-07-26 16:08:04 --> Loader Class Initialized
INFO - 2023-07-26 16:08:04 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:04 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:04 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:04 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:04 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:04 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:04 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:04 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:04 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:04 --> Parser Class Initialized
INFO - 2023-07-26 16:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:04 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:04 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:04 --> Controller Class Initialized
INFO - 2023-07-26 16:08:04 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:04 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:04 --> Model Class Initialized
INFO - 2023-07-26 16:08:04 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:04 --> Total execution time: 0.0226
ERROR - 2023-07-26 16:08:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:05 --> Config Class Initialized
INFO - 2023-07-26 16:08:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:05 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:05 --> URI Class Initialized
INFO - 2023-07-26 16:08:05 --> Router Class Initialized
INFO - 2023-07-26 16:08:05 --> Output Class Initialized
INFO - 2023-07-26 16:08:05 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:05 --> Input Class Initialized
INFO - 2023-07-26 16:08:05 --> Language Class Initialized
INFO - 2023-07-26 16:08:05 --> Loader Class Initialized
INFO - 2023-07-26 16:08:05 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:05 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:05 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:05 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:05 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:05 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:05 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:05 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:05 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:05 --> Parser Class Initialized
INFO - 2023-07-26 16:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:05 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:05 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:05 --> Controller Class Initialized
INFO - 2023-07-26 16:08:05 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:05 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:05 --> Model Class Initialized
INFO - 2023-07-26 16:08:05 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:05 --> Total execution time: 0.0457
ERROR - 2023-07-26 16:08:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:06 --> Config Class Initialized
INFO - 2023-07-26 16:08:06 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:06 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:06 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:06 --> URI Class Initialized
INFO - 2023-07-26 16:08:06 --> Router Class Initialized
INFO - 2023-07-26 16:08:06 --> Output Class Initialized
INFO - 2023-07-26 16:08:06 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:06 --> Input Class Initialized
INFO - 2023-07-26 16:08:06 --> Language Class Initialized
INFO - 2023-07-26 16:08:06 --> Loader Class Initialized
INFO - 2023-07-26 16:08:06 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:06 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:06 --> Parser Class Initialized
INFO - 2023-07-26 16:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:06 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:06 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:06 --> Controller Class Initialized
INFO - 2023-07-26 16:08:06 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:06 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:06 --> Model Class Initialized
INFO - 2023-07-26 16:08:06 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:06 --> Total execution time: 0.0410
ERROR - 2023-07-26 16:08:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:06 --> Config Class Initialized
INFO - 2023-07-26 16:08:06 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:06 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:06 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:06 --> URI Class Initialized
INFO - 2023-07-26 16:08:06 --> Router Class Initialized
INFO - 2023-07-26 16:08:06 --> Output Class Initialized
INFO - 2023-07-26 16:08:06 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:06 --> Input Class Initialized
INFO - 2023-07-26 16:08:06 --> Language Class Initialized
INFO - 2023-07-26 16:08:06 --> Loader Class Initialized
INFO - 2023-07-26 16:08:06 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:06 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:06 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:06 --> Parser Class Initialized
INFO - 2023-07-26 16:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:06 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:06 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:06 --> Controller Class Initialized
INFO - 2023-07-26 16:08:06 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:06 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:06 --> Model Class Initialized
INFO - 2023-07-26 16:08:06 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:06 --> Total execution time: 0.0394
ERROR - 2023-07-26 16:08:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:07 --> Config Class Initialized
INFO - 2023-07-26 16:08:07 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:07 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:07 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:07 --> URI Class Initialized
INFO - 2023-07-26 16:08:07 --> Router Class Initialized
INFO - 2023-07-26 16:08:07 --> Output Class Initialized
INFO - 2023-07-26 16:08:07 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:07 --> Input Class Initialized
INFO - 2023-07-26 16:08:07 --> Language Class Initialized
INFO - 2023-07-26 16:08:07 --> Loader Class Initialized
INFO - 2023-07-26 16:08:07 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:07 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:07 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:07 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:07 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:07 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:07 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:07 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:07 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:07 --> Parser Class Initialized
INFO - 2023-07-26 16:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:07 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:07 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:07 --> Controller Class Initialized
INFO - 2023-07-26 16:08:07 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:07 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:07 --> Model Class Initialized
INFO - 2023-07-26 16:08:07 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:07 --> Total execution time: 0.0390
ERROR - 2023-07-26 16:08:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:08 --> Config Class Initialized
INFO - 2023-07-26 16:08:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:08 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:08 --> URI Class Initialized
INFO - 2023-07-26 16:08:08 --> Router Class Initialized
INFO - 2023-07-26 16:08:08 --> Output Class Initialized
INFO - 2023-07-26 16:08:08 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:08 --> Input Class Initialized
INFO - 2023-07-26 16:08:08 --> Language Class Initialized
INFO - 2023-07-26 16:08:08 --> Loader Class Initialized
INFO - 2023-07-26 16:08:08 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:08 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:08 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:08 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:08 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:08 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:08 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:08 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:08 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:08 --> Parser Class Initialized
INFO - 2023-07-26 16:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:08 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:08 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:08 --> Controller Class Initialized
INFO - 2023-07-26 16:08:08 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:08 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:08 --> Model Class Initialized
INFO - 2023-07-26 16:08:08 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:08 --> Total execution time: 0.0406
ERROR - 2023-07-26 16:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:25 --> Config Class Initialized
INFO - 2023-07-26 16:08:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:25 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:25 --> URI Class Initialized
INFO - 2023-07-26 16:08:25 --> Router Class Initialized
INFO - 2023-07-26 16:08:25 --> Output Class Initialized
INFO - 2023-07-26 16:08:25 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:25 --> Input Class Initialized
INFO - 2023-07-26 16:08:25 --> Language Class Initialized
INFO - 2023-07-26 16:08:25 --> Loader Class Initialized
INFO - 2023-07-26 16:08:25 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:25 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:25 --> Parser Class Initialized
INFO - 2023-07-26 16:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:25 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:25 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:25 --> Controller Class Initialized
INFO - 2023-07-26 16:08:25 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:25 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:25 --> Model Class Initialized
INFO - 2023-07-26 16:08:25 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:25 --> Total execution time: 0.0418
ERROR - 2023-07-26 16:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:25 --> Config Class Initialized
INFO - 2023-07-26 16:08:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:25 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:25 --> URI Class Initialized
INFO - 2023-07-26 16:08:25 --> Router Class Initialized
INFO - 2023-07-26 16:08:25 --> Output Class Initialized
INFO - 2023-07-26 16:08:25 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:25 --> Input Class Initialized
INFO - 2023-07-26 16:08:25 --> Language Class Initialized
INFO - 2023-07-26 16:08:25 --> Loader Class Initialized
INFO - 2023-07-26 16:08:25 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:25 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:25 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:25 --> Parser Class Initialized
INFO - 2023-07-26 16:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:25 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:25 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:25 --> Controller Class Initialized
INFO - 2023-07-26 16:08:25 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:25 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:25 --> Model Class Initialized
INFO - 2023-07-26 16:08:25 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:25 --> Total execution time: 0.0391
ERROR - 2023-07-26 16:08:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:26 --> Config Class Initialized
INFO - 2023-07-26 16:08:26 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:26 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:26 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:26 --> URI Class Initialized
INFO - 2023-07-26 16:08:26 --> Router Class Initialized
INFO - 2023-07-26 16:08:26 --> Output Class Initialized
INFO - 2023-07-26 16:08:26 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:26 --> Input Class Initialized
INFO - 2023-07-26 16:08:26 --> Language Class Initialized
INFO - 2023-07-26 16:08:26 --> Loader Class Initialized
INFO - 2023-07-26 16:08:26 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:26 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:26 --> Parser Class Initialized
INFO - 2023-07-26 16:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:26 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:26 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:26 --> Controller Class Initialized
INFO - 2023-07-26 16:08:26 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:26 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:26 --> Model Class Initialized
INFO - 2023-07-26 16:08:26 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:26 --> Total execution time: 0.0399
ERROR - 2023-07-26 16:08:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:26 --> Config Class Initialized
INFO - 2023-07-26 16:08:26 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:26 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:26 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:26 --> URI Class Initialized
INFO - 2023-07-26 16:08:26 --> Router Class Initialized
INFO - 2023-07-26 16:08:26 --> Output Class Initialized
INFO - 2023-07-26 16:08:26 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:26 --> Input Class Initialized
INFO - 2023-07-26 16:08:26 --> Language Class Initialized
INFO - 2023-07-26 16:08:26 --> Loader Class Initialized
INFO - 2023-07-26 16:08:26 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:26 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:26 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:26 --> Parser Class Initialized
INFO - 2023-07-26 16:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:26 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:26 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:26 --> Controller Class Initialized
INFO - 2023-07-26 16:08:26 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:26 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:26 --> Model Class Initialized
INFO - 2023-07-26 16:08:26 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:26 --> Total execution time: 0.0399
ERROR - 2023-07-26 16:08:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:27 --> Config Class Initialized
INFO - 2023-07-26 16:08:27 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:27 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:27 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:27 --> URI Class Initialized
INFO - 2023-07-26 16:08:27 --> Router Class Initialized
INFO - 2023-07-26 16:08:27 --> Output Class Initialized
INFO - 2023-07-26 16:08:27 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:27 --> Input Class Initialized
INFO - 2023-07-26 16:08:27 --> Language Class Initialized
INFO - 2023-07-26 16:08:27 --> Loader Class Initialized
INFO - 2023-07-26 16:08:27 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:27 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:27 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:27 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:27 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:27 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:27 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:27 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:27 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:27 --> Parser Class Initialized
INFO - 2023-07-26 16:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:27 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:27 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:27 --> Controller Class Initialized
INFO - 2023-07-26 16:08:27 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:27 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:27 --> Model Class Initialized
INFO - 2023-07-26 16:08:27 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:27 --> Total execution time: 0.0195
ERROR - 2023-07-26 16:08:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:29 --> Config Class Initialized
INFO - 2023-07-26 16:08:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:29 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:29 --> URI Class Initialized
INFO - 2023-07-26 16:08:29 --> Router Class Initialized
INFO - 2023-07-26 16:08:29 --> Output Class Initialized
INFO - 2023-07-26 16:08:29 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:29 --> Input Class Initialized
INFO - 2023-07-26 16:08:29 --> Language Class Initialized
INFO - 2023-07-26 16:08:29 --> Loader Class Initialized
INFO - 2023-07-26 16:08:29 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:29 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:29 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:29 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:29 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:29 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:29 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:29 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:29 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:29 --> Parser Class Initialized
INFO - 2023-07-26 16:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:29 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:29 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:29 --> Controller Class Initialized
INFO - 2023-07-26 16:08:29 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:29 --> Model Class Initialized
INFO - 2023-07-26 16:08:29 --> Model Class Initialized
INFO - 2023-07-26 16:08:29 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:29 --> Total execution time: 0.0195
ERROR - 2023-07-26 16:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:08:31 --> Config Class Initialized
INFO - 2023-07-26 16:08:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:08:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:08:31 --> Utf8 Class Initialized
INFO - 2023-07-26 16:08:31 --> URI Class Initialized
INFO - 2023-07-26 16:08:31 --> Router Class Initialized
INFO - 2023-07-26 16:08:31 --> Output Class Initialized
INFO - 2023-07-26 16:08:31 --> Security Class Initialized
DEBUG - 2023-07-26 16:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:08:31 --> Input Class Initialized
INFO - 2023-07-26 16:08:31 --> Language Class Initialized
INFO - 2023-07-26 16:08:31 --> Loader Class Initialized
INFO - 2023-07-26 16:08:31 --> Helper loaded: url_helper
INFO - 2023-07-26 16:08:31 --> Helper loaded: file_helper
INFO - 2023-07-26 16:08:31 --> Helper loaded: html_helper
INFO - 2023-07-26 16:08:31 --> Helper loaded: text_helper
INFO - 2023-07-26 16:08:31 --> Helper loaded: form_helper
INFO - 2023-07-26 16:08:31 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:08:31 --> Helper loaded: security_helper
INFO - 2023-07-26 16:08:31 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:08:31 --> Database Driver Class Initialized
INFO - 2023-07-26 16:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:08:31 --> Parser Class Initialized
INFO - 2023-07-26 16:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:08:31 --> Pagination Class Initialized
INFO - 2023-07-26 16:08:31 --> Form Validation Class Initialized
INFO - 2023-07-26 16:08:31 --> Controller Class Initialized
INFO - 2023-07-26 16:08:31 --> Model Class Initialized
DEBUG - 2023-07-26 16:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:08:31 --> Model Class Initialized
INFO - 2023-07-26 16:08:31 --> Final output sent to browser
DEBUG - 2023-07-26 16:08:31 --> Total execution time: 0.0206
ERROR - 2023-07-26 16:09:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:09:38 --> Config Class Initialized
INFO - 2023-07-26 16:09:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:09:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:09:38 --> Utf8 Class Initialized
INFO - 2023-07-26 16:09:38 --> URI Class Initialized
DEBUG - 2023-07-26 16:09:38 --> No URI present. Default controller set.
INFO - 2023-07-26 16:09:38 --> Router Class Initialized
INFO - 2023-07-26 16:09:38 --> Output Class Initialized
INFO - 2023-07-26 16:09:38 --> Security Class Initialized
DEBUG - 2023-07-26 16:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:09:38 --> Input Class Initialized
INFO - 2023-07-26 16:09:38 --> Language Class Initialized
INFO - 2023-07-26 16:09:38 --> Loader Class Initialized
INFO - 2023-07-26 16:09:38 --> Helper loaded: url_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: file_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: html_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: text_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: form_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: security_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:09:38 --> Database Driver Class Initialized
INFO - 2023-07-26 16:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:09:38 --> Parser Class Initialized
INFO - 2023-07-26 16:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:09:38 --> Pagination Class Initialized
INFO - 2023-07-26 16:09:38 --> Form Validation Class Initialized
INFO - 2023-07-26 16:09:38 --> Controller Class Initialized
INFO - 2023-07-26 16:09:38 --> Model Class Initialized
DEBUG - 2023-07-26 16:09:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 16:09:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:09:38 --> Config Class Initialized
INFO - 2023-07-26 16:09:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:09:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:09:38 --> Utf8 Class Initialized
INFO - 2023-07-26 16:09:38 --> URI Class Initialized
INFO - 2023-07-26 16:09:38 --> Router Class Initialized
INFO - 2023-07-26 16:09:38 --> Output Class Initialized
INFO - 2023-07-26 16:09:38 --> Security Class Initialized
DEBUG - 2023-07-26 16:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:09:38 --> Input Class Initialized
INFO - 2023-07-26 16:09:38 --> Language Class Initialized
INFO - 2023-07-26 16:09:38 --> Loader Class Initialized
INFO - 2023-07-26 16:09:38 --> Helper loaded: url_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: file_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: html_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: text_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: form_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: security_helper
INFO - 2023-07-26 16:09:38 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:09:38 --> Database Driver Class Initialized
INFO - 2023-07-26 16:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:09:38 --> Parser Class Initialized
INFO - 2023-07-26 16:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:09:38 --> Pagination Class Initialized
INFO - 2023-07-26 16:09:38 --> Form Validation Class Initialized
INFO - 2023-07-26 16:09:38 --> Controller Class Initialized
INFO - 2023-07-26 16:09:38 --> Model Class Initialized
DEBUG - 2023-07-26 16:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 16:09:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 16:09:38 --> Model Class Initialized
INFO - 2023-07-26 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 16:09:38 --> Final output sent to browser
DEBUG - 2023-07-26 16:09:38 --> Total execution time: 0.0361
ERROR - 2023-07-26 16:09:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:09:42 --> Config Class Initialized
INFO - 2023-07-26 16:09:42 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:09:42 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:09:42 --> Utf8 Class Initialized
INFO - 2023-07-26 16:09:42 --> URI Class Initialized
INFO - 2023-07-26 16:09:42 --> Router Class Initialized
INFO - 2023-07-26 16:09:42 --> Output Class Initialized
INFO - 2023-07-26 16:09:42 --> Security Class Initialized
DEBUG - 2023-07-26 16:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:09:42 --> Input Class Initialized
INFO - 2023-07-26 16:09:42 --> Language Class Initialized
INFO - 2023-07-26 16:09:42 --> Loader Class Initialized
INFO - 2023-07-26 16:09:42 --> Helper loaded: url_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: file_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: html_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: text_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: form_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: security_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:09:42 --> Database Driver Class Initialized
INFO - 2023-07-26 16:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:09:42 --> Parser Class Initialized
INFO - 2023-07-26 16:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:09:42 --> Pagination Class Initialized
INFO - 2023-07-26 16:09:42 --> Form Validation Class Initialized
INFO - 2023-07-26 16:09:42 --> Controller Class Initialized
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
DEBUG - 2023-07-26 16:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
INFO - 2023-07-26 16:09:42 --> Final output sent to browser
DEBUG - 2023-07-26 16:09:42 --> Total execution time: 0.0188
ERROR - 2023-07-26 16:09:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:09:42 --> Config Class Initialized
INFO - 2023-07-26 16:09:42 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:09:42 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:09:42 --> Utf8 Class Initialized
INFO - 2023-07-26 16:09:42 --> URI Class Initialized
DEBUG - 2023-07-26 16:09:42 --> No URI present. Default controller set.
INFO - 2023-07-26 16:09:42 --> Router Class Initialized
INFO - 2023-07-26 16:09:42 --> Output Class Initialized
INFO - 2023-07-26 16:09:42 --> Security Class Initialized
DEBUG - 2023-07-26 16:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:09:42 --> Input Class Initialized
INFO - 2023-07-26 16:09:42 --> Language Class Initialized
INFO - 2023-07-26 16:09:42 --> Loader Class Initialized
INFO - 2023-07-26 16:09:42 --> Helper loaded: url_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: file_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: html_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: text_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: form_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: security_helper
INFO - 2023-07-26 16:09:42 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:09:42 --> Database Driver Class Initialized
INFO - 2023-07-26 16:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:09:42 --> Parser Class Initialized
INFO - 2023-07-26 16:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:09:42 --> Pagination Class Initialized
INFO - 2023-07-26 16:09:42 --> Form Validation Class Initialized
INFO - 2023-07-26 16:09:42 --> Controller Class Initialized
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
DEBUG - 2023-07-26 16:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
DEBUG - 2023-07-26 16:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
DEBUG - 2023-07-26 16:09:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
INFO - 2023-07-26 16:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 16:09:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 16:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 16:09:42 --> Model Class Initialized
INFO - 2023-07-26 16:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 16:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 16:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 16:09:42 --> Final output sent to browser
DEBUG - 2023-07-26 16:09:42 --> Total execution time: 0.2387
ERROR - 2023-07-26 16:09:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:09:43 --> Config Class Initialized
INFO - 2023-07-26 16:09:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:09:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:09:43 --> Utf8 Class Initialized
INFO - 2023-07-26 16:09:43 --> URI Class Initialized
INFO - 2023-07-26 16:09:43 --> Router Class Initialized
INFO - 2023-07-26 16:09:43 --> Output Class Initialized
INFO - 2023-07-26 16:09:43 --> Security Class Initialized
DEBUG - 2023-07-26 16:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:09:43 --> Input Class Initialized
INFO - 2023-07-26 16:09:43 --> Language Class Initialized
INFO - 2023-07-26 16:09:43 --> Loader Class Initialized
INFO - 2023-07-26 16:09:43 --> Helper loaded: url_helper
INFO - 2023-07-26 16:09:43 --> Helper loaded: file_helper
INFO - 2023-07-26 16:09:43 --> Helper loaded: html_helper
INFO - 2023-07-26 16:09:43 --> Helper loaded: text_helper
INFO - 2023-07-26 16:09:43 --> Helper loaded: form_helper
INFO - 2023-07-26 16:09:43 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:09:43 --> Helper loaded: security_helper
INFO - 2023-07-26 16:09:43 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:09:43 --> Database Driver Class Initialized
INFO - 2023-07-26 16:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:09:43 --> Parser Class Initialized
INFO - 2023-07-26 16:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:09:43 --> Pagination Class Initialized
INFO - 2023-07-26 16:09:43 --> Form Validation Class Initialized
INFO - 2023-07-26 16:09:43 --> Controller Class Initialized
DEBUG - 2023-07-26 16:09:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:09:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:09:43 --> Model Class Initialized
INFO - 2023-07-26 16:09:43 --> Final output sent to browser
DEBUG - 2023-07-26 16:09:43 --> Total execution time: 0.0134
ERROR - 2023-07-26 16:10:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:10:12 --> Config Class Initialized
INFO - 2023-07-26 16:10:12 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:10:12 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:10:12 --> Utf8 Class Initialized
INFO - 2023-07-26 16:10:12 --> URI Class Initialized
DEBUG - 2023-07-26 16:10:12 --> No URI present. Default controller set.
INFO - 2023-07-26 16:10:12 --> Router Class Initialized
INFO - 2023-07-26 16:10:12 --> Output Class Initialized
INFO - 2023-07-26 16:10:12 --> Security Class Initialized
DEBUG - 2023-07-26 16:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:10:12 --> Input Class Initialized
INFO - 2023-07-26 16:10:12 --> Language Class Initialized
INFO - 2023-07-26 16:10:12 --> Loader Class Initialized
INFO - 2023-07-26 16:10:12 --> Helper loaded: url_helper
INFO - 2023-07-26 16:10:12 --> Helper loaded: file_helper
INFO - 2023-07-26 16:10:12 --> Helper loaded: html_helper
INFO - 2023-07-26 16:10:12 --> Helper loaded: text_helper
INFO - 2023-07-26 16:10:12 --> Helper loaded: form_helper
INFO - 2023-07-26 16:10:12 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:10:12 --> Helper loaded: security_helper
INFO - 2023-07-26 16:10:12 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:10:12 --> Database Driver Class Initialized
INFO - 2023-07-26 16:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:10:12 --> Parser Class Initialized
INFO - 2023-07-26 16:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:10:12 --> Pagination Class Initialized
INFO - 2023-07-26 16:10:12 --> Form Validation Class Initialized
INFO - 2023-07-26 16:10:12 --> Controller Class Initialized
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
INFO - 2023-07-26 16:10:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-26 16:10:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 16:10:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 16:10:12 --> Model Class Initialized
INFO - 2023-07-26 16:10:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 16:10:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 16:10:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 16:10:12 --> Final output sent to browser
DEBUG - 2023-07-26 16:10:12 --> Total execution time: 0.1876
ERROR - 2023-07-26 16:10:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:10:21 --> Config Class Initialized
INFO - 2023-07-26 16:10:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:10:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:10:21 --> Utf8 Class Initialized
INFO - 2023-07-26 16:10:21 --> URI Class Initialized
INFO - 2023-07-26 16:10:21 --> Router Class Initialized
INFO - 2023-07-26 16:10:21 --> Output Class Initialized
INFO - 2023-07-26 16:10:21 --> Security Class Initialized
DEBUG - 2023-07-26 16:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:10:21 --> Input Class Initialized
INFO - 2023-07-26 16:10:21 --> Language Class Initialized
INFO - 2023-07-26 16:10:21 --> Loader Class Initialized
INFO - 2023-07-26 16:10:21 --> Helper loaded: url_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: file_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: html_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: text_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: form_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: security_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:10:21 --> Database Driver Class Initialized
INFO - 2023-07-26 16:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:10:21 --> Parser Class Initialized
INFO - 2023-07-26 16:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:10:21 --> Pagination Class Initialized
INFO - 2023-07-26 16:10:21 --> Form Validation Class Initialized
INFO - 2023-07-26 16:10:21 --> Controller Class Initialized
INFO - 2023-07-26 16:10:21 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:21 --> Model Class Initialized
INFO - 2023-07-26 16:10:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-26 16:10:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 16:10:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 16:10:21 --> Model Class Initialized
INFO - 2023-07-26 16:10:21 --> Model Class Initialized
INFO - 2023-07-26 16:10:21 --> Model Class Initialized
INFO - 2023-07-26 16:10:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 16:10:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 16:10:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 16:10:21 --> Final output sent to browser
DEBUG - 2023-07-26 16:10:21 --> Total execution time: 0.1552
ERROR - 2023-07-26 16:10:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:10:21 --> Config Class Initialized
INFO - 2023-07-26 16:10:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:10:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:10:21 --> Utf8 Class Initialized
INFO - 2023-07-26 16:10:21 --> URI Class Initialized
INFO - 2023-07-26 16:10:21 --> Router Class Initialized
INFO - 2023-07-26 16:10:21 --> Output Class Initialized
INFO - 2023-07-26 16:10:21 --> Security Class Initialized
DEBUG - 2023-07-26 16:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:10:21 --> Input Class Initialized
INFO - 2023-07-26 16:10:21 --> Language Class Initialized
INFO - 2023-07-26 16:10:21 --> Loader Class Initialized
INFO - 2023-07-26 16:10:21 --> Helper loaded: url_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: file_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: html_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: text_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: form_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: security_helper
INFO - 2023-07-26 16:10:21 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:10:21 --> Database Driver Class Initialized
INFO - 2023-07-26 16:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:10:21 --> Parser Class Initialized
INFO - 2023-07-26 16:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:10:21 --> Pagination Class Initialized
INFO - 2023-07-26 16:10:21 --> Form Validation Class Initialized
INFO - 2023-07-26 16:10:21 --> Controller Class Initialized
INFO - 2023-07-26 16:10:21 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:21 --> Model Class Initialized
INFO - 2023-07-26 16:10:21 --> Final output sent to browser
DEBUG - 2023-07-26 16:10:21 --> Total execution time: 0.0289
ERROR - 2023-07-26 16:10:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:10:25 --> Config Class Initialized
INFO - 2023-07-26 16:10:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:10:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:10:25 --> Utf8 Class Initialized
INFO - 2023-07-26 16:10:25 --> URI Class Initialized
INFO - 2023-07-26 16:10:25 --> Router Class Initialized
INFO - 2023-07-26 16:10:25 --> Output Class Initialized
INFO - 2023-07-26 16:10:25 --> Security Class Initialized
DEBUG - 2023-07-26 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:10:25 --> Input Class Initialized
INFO - 2023-07-26 16:10:25 --> Language Class Initialized
INFO - 2023-07-26 16:10:25 --> Loader Class Initialized
INFO - 2023-07-26 16:10:25 --> Helper loaded: url_helper
INFO - 2023-07-26 16:10:25 --> Helper loaded: file_helper
INFO - 2023-07-26 16:10:25 --> Helper loaded: html_helper
INFO - 2023-07-26 16:10:25 --> Helper loaded: text_helper
INFO - 2023-07-26 16:10:25 --> Helper loaded: form_helper
INFO - 2023-07-26 16:10:25 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:10:25 --> Helper loaded: security_helper
INFO - 2023-07-26 16:10:25 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:10:25 --> Database Driver Class Initialized
INFO - 2023-07-26 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:10:25 --> Parser Class Initialized
INFO - 2023-07-26 16:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:10:25 --> Pagination Class Initialized
INFO - 2023-07-26 16:10:25 --> Form Validation Class Initialized
INFO - 2023-07-26 16:10:25 --> Controller Class Initialized
INFO - 2023-07-26 16:10:25 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:25 --> Model Class Initialized
INFO - 2023-07-26 16:10:25 --> Final output sent to browser
DEBUG - 2023-07-26 16:10:25 --> Total execution time: 0.0768
ERROR - 2023-07-26 16:10:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 16:10:40 --> Config Class Initialized
INFO - 2023-07-26 16:10:40 --> Hooks Class Initialized
DEBUG - 2023-07-26 16:10:40 --> UTF-8 Support Enabled
INFO - 2023-07-26 16:10:40 --> Utf8 Class Initialized
INFO - 2023-07-26 16:10:40 --> URI Class Initialized
INFO - 2023-07-26 16:10:40 --> Router Class Initialized
INFO - 2023-07-26 16:10:40 --> Output Class Initialized
INFO - 2023-07-26 16:10:40 --> Security Class Initialized
DEBUG - 2023-07-26 16:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 16:10:40 --> Input Class Initialized
INFO - 2023-07-26 16:10:40 --> Language Class Initialized
INFO - 2023-07-26 16:10:40 --> Loader Class Initialized
INFO - 2023-07-26 16:10:40 --> Helper loaded: url_helper
INFO - 2023-07-26 16:10:40 --> Helper loaded: file_helper
INFO - 2023-07-26 16:10:40 --> Helper loaded: html_helper
INFO - 2023-07-26 16:10:40 --> Helper loaded: text_helper
INFO - 2023-07-26 16:10:40 --> Helper loaded: form_helper
INFO - 2023-07-26 16:10:40 --> Helper loaded: lang_helper
INFO - 2023-07-26 16:10:40 --> Helper loaded: security_helper
INFO - 2023-07-26 16:10:40 --> Helper loaded: cookie_helper
INFO - 2023-07-26 16:10:40 --> Database Driver Class Initialized
INFO - 2023-07-26 16:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 16:10:40 --> Parser Class Initialized
INFO - 2023-07-26 16:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 16:10:40 --> Pagination Class Initialized
INFO - 2023-07-26 16:10:40 --> Form Validation Class Initialized
INFO - 2023-07-26 16:10:40 --> Controller Class Initialized
INFO - 2023-07-26 16:10:40 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 16:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:40 --> Model Class Initialized
DEBUG - 2023-07-26 16:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-07-26 16:10:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 16:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 16:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 16:10:40 --> Model Class Initialized
INFO - 2023-07-26 16:10:40 --> Model Class Initialized
INFO - 2023-07-26 16:10:40 --> Model Class Initialized
INFO - 2023-07-26 16:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-26 16:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-26 16:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 16:10:40 --> Final output sent to browser
DEBUG - 2023-07-26 16:10:40 --> Total execution time: 0.1459
ERROR - 2023-07-26 17:04:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 17:04:37 --> Config Class Initialized
INFO - 2023-07-26 17:04:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 17:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 17:04:37 --> Utf8 Class Initialized
INFO - 2023-07-26 17:04:37 --> URI Class Initialized
DEBUG - 2023-07-26 17:04:37 --> No URI present. Default controller set.
INFO - 2023-07-26 17:04:37 --> Router Class Initialized
INFO - 2023-07-26 17:04:37 --> Output Class Initialized
INFO - 2023-07-26 17:04:37 --> Security Class Initialized
DEBUG - 2023-07-26 17:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 17:04:37 --> Input Class Initialized
INFO - 2023-07-26 17:04:37 --> Language Class Initialized
INFO - 2023-07-26 17:04:37 --> Loader Class Initialized
INFO - 2023-07-26 17:04:37 --> Helper loaded: url_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: file_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: html_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: text_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: form_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: lang_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: security_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: cookie_helper
INFO - 2023-07-26 17:04:37 --> Database Driver Class Initialized
INFO - 2023-07-26 17:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 17:04:37 --> Parser Class Initialized
INFO - 2023-07-26 17:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 17:04:37 --> Pagination Class Initialized
INFO - 2023-07-26 17:04:37 --> Form Validation Class Initialized
INFO - 2023-07-26 17:04:37 --> Controller Class Initialized
INFO - 2023-07-26 17:04:37 --> Model Class Initialized
DEBUG - 2023-07-26 17:04:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 17:04:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 17:04:37 --> Config Class Initialized
INFO - 2023-07-26 17:04:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 17:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 17:04:37 --> Utf8 Class Initialized
INFO - 2023-07-26 17:04:37 --> URI Class Initialized
INFO - 2023-07-26 17:04:37 --> Router Class Initialized
INFO - 2023-07-26 17:04:37 --> Output Class Initialized
INFO - 2023-07-26 17:04:37 --> Security Class Initialized
DEBUG - 2023-07-26 17:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 17:04:37 --> Input Class Initialized
INFO - 2023-07-26 17:04:37 --> Language Class Initialized
INFO - 2023-07-26 17:04:37 --> Loader Class Initialized
INFO - 2023-07-26 17:04:37 --> Helper loaded: url_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: file_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: html_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: text_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: form_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: lang_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: security_helper
INFO - 2023-07-26 17:04:37 --> Helper loaded: cookie_helper
INFO - 2023-07-26 17:04:37 --> Database Driver Class Initialized
INFO - 2023-07-26 17:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 17:04:37 --> Parser Class Initialized
INFO - 2023-07-26 17:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 17:04:37 --> Pagination Class Initialized
INFO - 2023-07-26 17:04:37 --> Form Validation Class Initialized
INFO - 2023-07-26 17:04:37 --> Controller Class Initialized
INFO - 2023-07-26 17:04:37 --> Model Class Initialized
DEBUG - 2023-07-26 17:04:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 17:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 17:04:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 17:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 17:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 17:04:37 --> Model Class Initialized
INFO - 2023-07-26 17:04:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 17:04:37 --> Final output sent to browser
DEBUG - 2023-07-26 17:04:37 --> Total execution time: 0.0333
ERROR - 2023-07-26 17:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 17:11:32 --> Config Class Initialized
INFO - 2023-07-26 17:11:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 17:11:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 17:11:32 --> Utf8 Class Initialized
INFO - 2023-07-26 17:11:32 --> URI Class Initialized
DEBUG - 2023-07-26 17:11:32 --> No URI present. Default controller set.
INFO - 2023-07-26 17:11:32 --> Router Class Initialized
INFO - 2023-07-26 17:11:32 --> Output Class Initialized
INFO - 2023-07-26 17:11:32 --> Security Class Initialized
DEBUG - 2023-07-26 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 17:11:32 --> Input Class Initialized
INFO - 2023-07-26 17:11:32 --> Language Class Initialized
INFO - 2023-07-26 17:11:32 --> Loader Class Initialized
INFO - 2023-07-26 17:11:32 --> Helper loaded: url_helper
INFO - 2023-07-26 17:11:32 --> Helper loaded: file_helper
INFO - 2023-07-26 17:11:32 --> Helper loaded: html_helper
INFO - 2023-07-26 17:11:32 --> Helper loaded: text_helper
INFO - 2023-07-26 17:11:32 --> Helper loaded: form_helper
INFO - 2023-07-26 17:11:32 --> Helper loaded: lang_helper
INFO - 2023-07-26 17:11:32 --> Helper loaded: security_helper
INFO - 2023-07-26 17:11:32 --> Helper loaded: cookie_helper
INFO - 2023-07-26 17:11:32 --> Database Driver Class Initialized
INFO - 2023-07-26 17:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 17:11:32 --> Parser Class Initialized
INFO - 2023-07-26 17:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 17:11:32 --> Pagination Class Initialized
INFO - 2023-07-26 17:11:32 --> Form Validation Class Initialized
INFO - 2023-07-26 17:11:32 --> Controller Class Initialized
INFO - 2023-07-26 17:11:32 --> Model Class Initialized
DEBUG - 2023-07-26 17:11:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 17:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 17:11:34 --> Config Class Initialized
INFO - 2023-07-26 17:11:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 17:11:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 17:11:34 --> Utf8 Class Initialized
INFO - 2023-07-26 17:11:34 --> URI Class Initialized
INFO - 2023-07-26 17:11:34 --> Router Class Initialized
INFO - 2023-07-26 17:11:34 --> Output Class Initialized
INFO - 2023-07-26 17:11:34 --> Security Class Initialized
DEBUG - 2023-07-26 17:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 17:11:34 --> Input Class Initialized
INFO - 2023-07-26 17:11:34 --> Language Class Initialized
INFO - 2023-07-26 17:11:34 --> Loader Class Initialized
INFO - 2023-07-26 17:11:34 --> Helper loaded: url_helper
INFO - 2023-07-26 17:11:34 --> Helper loaded: file_helper
INFO - 2023-07-26 17:11:34 --> Helper loaded: html_helper
INFO - 2023-07-26 17:11:34 --> Helper loaded: text_helper
INFO - 2023-07-26 17:11:34 --> Helper loaded: form_helper
INFO - 2023-07-26 17:11:34 --> Helper loaded: lang_helper
INFO - 2023-07-26 17:11:34 --> Helper loaded: security_helper
INFO - 2023-07-26 17:11:34 --> Helper loaded: cookie_helper
INFO - 2023-07-26 17:11:34 --> Database Driver Class Initialized
INFO - 2023-07-26 17:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 17:11:34 --> Parser Class Initialized
INFO - 2023-07-26 17:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 17:11:34 --> Pagination Class Initialized
INFO - 2023-07-26 17:11:34 --> Form Validation Class Initialized
INFO - 2023-07-26 17:11:34 --> Controller Class Initialized
INFO - 2023-07-26 17:11:34 --> Model Class Initialized
DEBUG - 2023-07-26 17:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 17:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 17:11:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 17:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 17:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 17:11:34 --> Model Class Initialized
INFO - 2023-07-26 17:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 17:11:34 --> Final output sent to browser
DEBUG - 2023-07-26 17:11:34 --> Total execution time: 0.0310
ERROR - 2023-07-26 17:11:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 17:11:59 --> Config Class Initialized
INFO - 2023-07-26 17:11:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 17:11:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 17:11:59 --> Utf8 Class Initialized
INFO - 2023-07-26 17:11:59 --> URI Class Initialized
INFO - 2023-07-26 17:11:59 --> Router Class Initialized
INFO - 2023-07-26 17:11:59 --> Output Class Initialized
INFO - 2023-07-26 17:11:59 --> Security Class Initialized
DEBUG - 2023-07-26 17:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 17:11:59 --> Input Class Initialized
INFO - 2023-07-26 17:11:59 --> Language Class Initialized
INFO - 2023-07-26 17:11:59 --> Loader Class Initialized
INFO - 2023-07-26 17:11:59 --> Helper loaded: url_helper
INFO - 2023-07-26 17:11:59 --> Helper loaded: file_helper
INFO - 2023-07-26 17:11:59 --> Helper loaded: html_helper
INFO - 2023-07-26 17:11:59 --> Helper loaded: text_helper
INFO - 2023-07-26 17:11:59 --> Helper loaded: form_helper
INFO - 2023-07-26 17:11:59 --> Helper loaded: lang_helper
INFO - 2023-07-26 17:11:59 --> Helper loaded: security_helper
INFO - 2023-07-26 17:11:59 --> Helper loaded: cookie_helper
INFO - 2023-07-26 17:11:59 --> Database Driver Class Initialized
INFO - 2023-07-26 17:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 17:11:59 --> Parser Class Initialized
INFO - 2023-07-26 17:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 17:11:59 --> Pagination Class Initialized
INFO - 2023-07-26 17:11:59 --> Form Validation Class Initialized
INFO - 2023-07-26 17:11:59 --> Controller Class Initialized
INFO - 2023-07-26 17:11:59 --> Model Class Initialized
DEBUG - 2023-07-26 17:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 17:11:59 --> Model Class Initialized
INFO - 2023-07-26 17:11:59 --> Final output sent to browser
DEBUG - 2023-07-26 17:11:59 --> Total execution time: 0.0224
ERROR - 2023-07-26 17:12:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 17:12:00 --> Config Class Initialized
INFO - 2023-07-26 17:12:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 17:12:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 17:12:00 --> Utf8 Class Initialized
INFO - 2023-07-26 17:12:00 --> URI Class Initialized
INFO - 2023-07-26 17:12:00 --> Router Class Initialized
INFO - 2023-07-26 17:12:00 --> Output Class Initialized
INFO - 2023-07-26 17:12:00 --> Security Class Initialized
DEBUG - 2023-07-26 17:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 17:12:00 --> Input Class Initialized
INFO - 2023-07-26 17:12:00 --> Language Class Initialized
INFO - 2023-07-26 17:12:00 --> Loader Class Initialized
INFO - 2023-07-26 17:12:00 --> Helper loaded: url_helper
INFO - 2023-07-26 17:12:00 --> Helper loaded: file_helper
INFO - 2023-07-26 17:12:00 --> Helper loaded: html_helper
INFO - 2023-07-26 17:12:00 --> Helper loaded: text_helper
INFO - 2023-07-26 17:12:00 --> Helper loaded: form_helper
INFO - 2023-07-26 17:12:00 --> Helper loaded: lang_helper
INFO - 2023-07-26 17:12:00 --> Helper loaded: security_helper
INFO - 2023-07-26 17:12:00 --> Helper loaded: cookie_helper
INFO - 2023-07-26 17:12:00 --> Database Driver Class Initialized
INFO - 2023-07-26 17:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 17:12:00 --> Parser Class Initialized
INFO - 2023-07-26 17:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 17:12:00 --> Pagination Class Initialized
INFO - 2023-07-26 17:12:00 --> Form Validation Class Initialized
INFO - 2023-07-26 17:12:00 --> Controller Class Initialized
INFO - 2023-07-26 17:12:00 --> Model Class Initialized
DEBUG - 2023-07-26 17:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 17:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-26 17:12:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-26 17:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-26 17:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-26 17:12:00 --> Model Class Initialized
INFO - 2023-07-26 17:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-26 17:12:00 --> Final output sent to browser
DEBUG - 2023-07-26 17:12:00 --> Total execution time: 0.0325
ERROR - 2023-07-26 19:37:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 19:37:55 --> Config Class Initialized
INFO - 2023-07-26 19:37:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 19:37:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 19:37:55 --> Utf8 Class Initialized
INFO - 2023-07-26 19:37:55 --> URI Class Initialized
DEBUG - 2023-07-26 19:37:55 --> No URI present. Default controller set.
INFO - 2023-07-26 19:37:55 --> Router Class Initialized
INFO - 2023-07-26 19:37:55 --> Output Class Initialized
INFO - 2023-07-26 19:37:55 --> Security Class Initialized
DEBUG - 2023-07-26 19:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 19:37:55 --> Input Class Initialized
INFO - 2023-07-26 19:37:55 --> Language Class Initialized
INFO - 2023-07-26 19:37:55 --> Loader Class Initialized
INFO - 2023-07-26 19:37:55 --> Helper loaded: url_helper
INFO - 2023-07-26 19:37:55 --> Helper loaded: file_helper
INFO - 2023-07-26 19:37:55 --> Helper loaded: html_helper
INFO - 2023-07-26 19:37:55 --> Helper loaded: text_helper
INFO - 2023-07-26 19:37:55 --> Helper loaded: form_helper
INFO - 2023-07-26 19:37:55 --> Helper loaded: lang_helper
INFO - 2023-07-26 19:37:55 --> Helper loaded: security_helper
INFO - 2023-07-26 19:37:55 --> Helper loaded: cookie_helper
INFO - 2023-07-26 19:37:55 --> Database Driver Class Initialized
INFO - 2023-07-26 19:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 19:37:55 --> Parser Class Initialized
INFO - 2023-07-26 19:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 19:37:55 --> Pagination Class Initialized
INFO - 2023-07-26 19:37:55 --> Form Validation Class Initialized
INFO - 2023-07-26 19:37:55 --> Controller Class Initialized
INFO - 2023-07-26 19:37:55 --> Model Class Initialized
DEBUG - 2023-07-26 19:37:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-26 21:02:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-26 21:02:22 --> Config Class Initialized
INFO - 2023-07-26 21:02:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 21:02:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 21:02:22 --> Utf8 Class Initialized
INFO - 2023-07-26 21:02:22 --> URI Class Initialized
DEBUG - 2023-07-26 21:02:22 --> No URI present. Default controller set.
INFO - 2023-07-26 21:02:22 --> Router Class Initialized
INFO - 2023-07-26 21:02:22 --> Output Class Initialized
INFO - 2023-07-26 21:02:22 --> Security Class Initialized
DEBUG - 2023-07-26 21:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 21:02:22 --> Input Class Initialized
INFO - 2023-07-26 21:02:22 --> Language Class Initialized
INFO - 2023-07-26 21:02:22 --> Loader Class Initialized
INFO - 2023-07-26 21:02:22 --> Helper loaded: url_helper
INFO - 2023-07-26 21:02:22 --> Helper loaded: file_helper
INFO - 2023-07-26 21:02:22 --> Helper loaded: html_helper
INFO - 2023-07-26 21:02:22 --> Helper loaded: text_helper
INFO - 2023-07-26 21:02:22 --> Helper loaded: form_helper
INFO - 2023-07-26 21:02:22 --> Helper loaded: lang_helper
INFO - 2023-07-26 21:02:22 --> Helper loaded: security_helper
INFO - 2023-07-26 21:02:22 --> Helper loaded: cookie_helper
INFO - 2023-07-26 21:02:22 --> Database Driver Class Initialized
INFO - 2023-07-26 21:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 21:02:23 --> Parser Class Initialized
INFO - 2023-07-26 21:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-26 21:02:23 --> Pagination Class Initialized
INFO - 2023-07-26 21:02:23 --> Form Validation Class Initialized
INFO - 2023-07-26 21:02:23 --> Controller Class Initialized
INFO - 2023-07-26 21:02:23 --> Model Class Initialized
DEBUG - 2023-07-26 21:02:23 --> Session class already loaded. Second attempt ignored.
