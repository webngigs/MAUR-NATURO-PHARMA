<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-08 06:43:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 06:43:03 --> Config Class Initialized
INFO - 2023-05-08 06:43:03 --> Hooks Class Initialized
DEBUG - 2023-05-08 06:43:03 --> UTF-8 Support Enabled
INFO - 2023-05-08 06:43:03 --> Utf8 Class Initialized
INFO - 2023-05-08 06:43:03 --> URI Class Initialized
DEBUG - 2023-05-08 06:43:03 --> No URI present. Default controller set.
INFO - 2023-05-08 06:43:03 --> Router Class Initialized
INFO - 2023-05-08 06:43:03 --> Output Class Initialized
INFO - 2023-05-08 06:43:03 --> Security Class Initialized
DEBUG - 2023-05-08 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 06:43:03 --> Input Class Initialized
INFO - 2023-05-08 06:43:03 --> Language Class Initialized
INFO - 2023-05-08 06:43:03 --> Loader Class Initialized
INFO - 2023-05-08 06:43:03 --> Helper loaded: url_helper
INFO - 2023-05-08 06:43:03 --> Helper loaded: file_helper
INFO - 2023-05-08 06:43:03 --> Helper loaded: html_helper
INFO - 2023-05-08 06:43:03 --> Helper loaded: text_helper
INFO - 2023-05-08 06:43:03 --> Helper loaded: form_helper
INFO - 2023-05-08 06:43:03 --> Helper loaded: lang_helper
INFO - 2023-05-08 06:43:03 --> Helper loaded: security_helper
INFO - 2023-05-08 06:43:03 --> Helper loaded: cookie_helper
INFO - 2023-05-08 06:43:03 --> Database Driver Class Initialized
INFO - 2023-05-08 06:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 06:43:03 --> Parser Class Initialized
INFO - 2023-05-08 06:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 06:43:03 --> Pagination Class Initialized
INFO - 2023-05-08 06:43:03 --> Form Validation Class Initialized
INFO - 2023-05-08 06:43:03 --> Controller Class Initialized
INFO - 2023-05-08 06:43:03 --> Model Class Initialized
DEBUG - 2023-05-08 06:43:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 06:43:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 06:43:04 --> Config Class Initialized
INFO - 2023-05-08 06:43:04 --> Hooks Class Initialized
DEBUG - 2023-05-08 06:43:04 --> UTF-8 Support Enabled
INFO - 2023-05-08 06:43:04 --> Utf8 Class Initialized
INFO - 2023-05-08 06:43:04 --> URI Class Initialized
INFO - 2023-05-08 06:43:04 --> Router Class Initialized
INFO - 2023-05-08 06:43:04 --> Output Class Initialized
INFO - 2023-05-08 06:43:04 --> Security Class Initialized
DEBUG - 2023-05-08 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 06:43:04 --> Input Class Initialized
INFO - 2023-05-08 06:43:04 --> Language Class Initialized
INFO - 2023-05-08 06:43:04 --> Loader Class Initialized
INFO - 2023-05-08 06:43:04 --> Helper loaded: url_helper
INFO - 2023-05-08 06:43:04 --> Helper loaded: file_helper
INFO - 2023-05-08 06:43:04 --> Helper loaded: html_helper
INFO - 2023-05-08 06:43:04 --> Helper loaded: text_helper
INFO - 2023-05-08 06:43:04 --> Helper loaded: form_helper
INFO - 2023-05-08 06:43:04 --> Helper loaded: lang_helper
INFO - 2023-05-08 06:43:04 --> Helper loaded: security_helper
INFO - 2023-05-08 06:43:04 --> Helper loaded: cookie_helper
INFO - 2023-05-08 06:43:04 --> Database Driver Class Initialized
INFO - 2023-05-08 06:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 06:43:04 --> Parser Class Initialized
INFO - 2023-05-08 06:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 06:43:04 --> Pagination Class Initialized
INFO - 2023-05-08 06:43:04 --> Form Validation Class Initialized
INFO - 2023-05-08 06:43:04 --> Controller Class Initialized
INFO - 2023-05-08 06:43:04 --> Model Class Initialized
DEBUG - 2023-05-08 06:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 06:43:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 06:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 06:43:04 --> Model Class Initialized
INFO - 2023-05-08 06:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 06:43:04 --> Final output sent to browser
DEBUG - 2023-05-08 06:43:04 --> Total execution time: 0.0321
ERROR - 2023-05-08 06:43:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 06:43:16 --> Config Class Initialized
INFO - 2023-05-08 06:43:16 --> Hooks Class Initialized
DEBUG - 2023-05-08 06:43:16 --> UTF-8 Support Enabled
INFO - 2023-05-08 06:43:16 --> Utf8 Class Initialized
INFO - 2023-05-08 06:43:16 --> URI Class Initialized
INFO - 2023-05-08 06:43:16 --> Router Class Initialized
INFO - 2023-05-08 06:43:16 --> Output Class Initialized
INFO - 2023-05-08 06:43:16 --> Security Class Initialized
DEBUG - 2023-05-08 06:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 06:43:16 --> Input Class Initialized
INFO - 2023-05-08 06:43:16 --> Language Class Initialized
INFO - 2023-05-08 06:43:16 --> Loader Class Initialized
INFO - 2023-05-08 06:43:16 --> Helper loaded: url_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: file_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: html_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: text_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: form_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: lang_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: security_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: cookie_helper
INFO - 2023-05-08 06:43:16 --> Database Driver Class Initialized
INFO - 2023-05-08 06:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 06:43:16 --> Parser Class Initialized
INFO - 2023-05-08 06:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 06:43:16 --> Pagination Class Initialized
INFO - 2023-05-08 06:43:16 --> Form Validation Class Initialized
INFO - 2023-05-08 06:43:16 --> Controller Class Initialized
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
DEBUG - 2023-05-08 06:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
INFO - 2023-05-08 06:43:16 --> Final output sent to browser
DEBUG - 2023-05-08 06:43:16 --> Total execution time: 0.0217
ERROR - 2023-05-08 06:43:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 06:43:16 --> Config Class Initialized
INFO - 2023-05-08 06:43:16 --> Hooks Class Initialized
DEBUG - 2023-05-08 06:43:16 --> UTF-8 Support Enabled
INFO - 2023-05-08 06:43:16 --> Utf8 Class Initialized
INFO - 2023-05-08 06:43:16 --> URI Class Initialized
DEBUG - 2023-05-08 06:43:16 --> No URI present. Default controller set.
INFO - 2023-05-08 06:43:16 --> Router Class Initialized
INFO - 2023-05-08 06:43:16 --> Output Class Initialized
INFO - 2023-05-08 06:43:16 --> Security Class Initialized
DEBUG - 2023-05-08 06:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 06:43:16 --> Input Class Initialized
INFO - 2023-05-08 06:43:16 --> Language Class Initialized
INFO - 2023-05-08 06:43:16 --> Loader Class Initialized
INFO - 2023-05-08 06:43:16 --> Helper loaded: url_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: file_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: html_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: text_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: form_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: lang_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: security_helper
INFO - 2023-05-08 06:43:16 --> Helper loaded: cookie_helper
INFO - 2023-05-08 06:43:16 --> Database Driver Class Initialized
INFO - 2023-05-08 06:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 06:43:16 --> Parser Class Initialized
INFO - 2023-05-08 06:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 06:43:16 --> Pagination Class Initialized
INFO - 2023-05-08 06:43:16 --> Form Validation Class Initialized
INFO - 2023-05-08 06:43:16 --> Controller Class Initialized
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
DEBUG - 2023-05-08 06:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
DEBUG - 2023-05-08 06:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
DEBUG - 2023-05-08 06:43:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 06:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
INFO - 2023-05-08 06:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 06:43:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 06:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 06:43:16 --> Model Class Initialized
INFO - 2023-05-08 06:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 06:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 06:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 06:43:16 --> Final output sent to browser
DEBUG - 2023-05-08 06:43:16 --> Total execution time: 0.0661
ERROR - 2023-05-08 06:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 06:44:26 --> Config Class Initialized
INFO - 2023-05-08 06:44:26 --> Hooks Class Initialized
DEBUG - 2023-05-08 06:44:26 --> UTF-8 Support Enabled
INFO - 2023-05-08 06:44:26 --> Utf8 Class Initialized
INFO - 2023-05-08 06:44:26 --> URI Class Initialized
INFO - 2023-05-08 06:44:26 --> Router Class Initialized
INFO - 2023-05-08 06:44:26 --> Output Class Initialized
INFO - 2023-05-08 06:44:26 --> Security Class Initialized
DEBUG - 2023-05-08 06:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 06:44:26 --> Input Class Initialized
INFO - 2023-05-08 06:44:26 --> Language Class Initialized
INFO - 2023-05-08 06:44:26 --> Loader Class Initialized
INFO - 2023-05-08 06:44:26 --> Helper loaded: url_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: file_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: html_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: text_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: form_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: lang_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: security_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: cookie_helper
INFO - 2023-05-08 06:44:26 --> Database Driver Class Initialized
INFO - 2023-05-08 06:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 06:44:26 --> Parser Class Initialized
INFO - 2023-05-08 06:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 06:44:26 --> Pagination Class Initialized
INFO - 2023-05-08 06:44:26 --> Form Validation Class Initialized
INFO - 2023-05-08 06:44:26 --> Controller Class Initialized
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
DEBUG - 2023-05-08 06:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 06:44:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 06:44:26 --> Final output sent to browser
DEBUG - 2023-05-08 06:44:26 --> Total execution time: 0.0367
ERROR - 2023-05-08 06:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 06:44:26 --> Config Class Initialized
INFO - 2023-05-08 06:44:26 --> Hooks Class Initialized
DEBUG - 2023-05-08 06:44:26 --> UTF-8 Support Enabled
INFO - 2023-05-08 06:44:26 --> Utf8 Class Initialized
INFO - 2023-05-08 06:44:26 --> URI Class Initialized
INFO - 2023-05-08 06:44:26 --> Router Class Initialized
INFO - 2023-05-08 06:44:26 --> Output Class Initialized
INFO - 2023-05-08 06:44:26 --> Security Class Initialized
DEBUG - 2023-05-08 06:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 06:44:26 --> Input Class Initialized
INFO - 2023-05-08 06:44:26 --> Language Class Initialized
INFO - 2023-05-08 06:44:26 --> Loader Class Initialized
INFO - 2023-05-08 06:44:26 --> Helper loaded: url_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: file_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: html_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: text_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: form_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: lang_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: security_helper
INFO - 2023-05-08 06:44:26 --> Helper loaded: cookie_helper
INFO - 2023-05-08 06:44:26 --> Database Driver Class Initialized
INFO - 2023-05-08 06:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 06:44:26 --> Parser Class Initialized
INFO - 2023-05-08 06:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 06:44:26 --> Pagination Class Initialized
INFO - 2023-05-08 06:44:26 --> Form Validation Class Initialized
INFO - 2023-05-08 06:44:26 --> Controller Class Initialized
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
DEBUG - 2023-05-08 06:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
DEBUG - 2023-05-08 06:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
DEBUG - 2023-05-08 06:44:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 06:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 06:44:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 06:44:26 --> Model Class Initialized
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 06:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 06:44:26 --> Final output sent to browser
DEBUG - 2023-05-08 06:44:26 --> Total execution time: 0.0620
ERROR - 2023-05-08 06:44:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 06:44:43 --> Config Class Initialized
INFO - 2023-05-08 06:44:43 --> Hooks Class Initialized
DEBUG - 2023-05-08 06:44:43 --> UTF-8 Support Enabled
INFO - 2023-05-08 06:44:43 --> Utf8 Class Initialized
INFO - 2023-05-08 06:44:43 --> URI Class Initialized
DEBUG - 2023-05-08 06:44:43 --> No URI present. Default controller set.
INFO - 2023-05-08 06:44:43 --> Router Class Initialized
INFO - 2023-05-08 06:44:43 --> Output Class Initialized
INFO - 2023-05-08 06:44:43 --> Security Class Initialized
DEBUG - 2023-05-08 06:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 06:44:43 --> Input Class Initialized
INFO - 2023-05-08 06:44:43 --> Language Class Initialized
INFO - 2023-05-08 06:44:43 --> Loader Class Initialized
INFO - 2023-05-08 06:44:43 --> Helper loaded: url_helper
INFO - 2023-05-08 06:44:43 --> Helper loaded: file_helper
INFO - 2023-05-08 06:44:43 --> Helper loaded: html_helper
INFO - 2023-05-08 06:44:43 --> Helper loaded: text_helper
INFO - 2023-05-08 06:44:43 --> Helper loaded: form_helper
INFO - 2023-05-08 06:44:43 --> Helper loaded: lang_helper
INFO - 2023-05-08 06:44:43 --> Helper loaded: security_helper
INFO - 2023-05-08 06:44:43 --> Helper loaded: cookie_helper
INFO - 2023-05-08 06:44:43 --> Database Driver Class Initialized
INFO - 2023-05-08 06:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 06:44:43 --> Parser Class Initialized
INFO - 2023-05-08 06:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 06:44:43 --> Pagination Class Initialized
INFO - 2023-05-08 06:44:43 --> Form Validation Class Initialized
INFO - 2023-05-08 06:44:43 --> Controller Class Initialized
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
DEBUG - 2023-05-08 06:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
DEBUG - 2023-05-08 06:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
DEBUG - 2023-05-08 06:44:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 06:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
INFO - 2023-05-08 06:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 06:44:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 06:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 06:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 06:44:43 --> Model Class Initialized
INFO - 2023-05-08 06:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 06:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 06:44:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 06:44:43 --> Final output sent to browser
DEBUG - 2023-05-08 06:44:43 --> Total execution time: 0.0584
ERROR - 2023-05-08 08:29:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 08:29:58 --> Config Class Initialized
INFO - 2023-05-08 08:29:58 --> Hooks Class Initialized
DEBUG - 2023-05-08 08:29:58 --> UTF-8 Support Enabled
INFO - 2023-05-08 08:29:58 --> Utf8 Class Initialized
INFO - 2023-05-08 08:29:58 --> URI Class Initialized
DEBUG - 2023-05-08 08:29:58 --> No URI present. Default controller set.
INFO - 2023-05-08 08:29:58 --> Router Class Initialized
INFO - 2023-05-08 08:29:58 --> Output Class Initialized
INFO - 2023-05-08 08:29:58 --> Security Class Initialized
DEBUG - 2023-05-08 08:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 08:29:58 --> Input Class Initialized
INFO - 2023-05-08 08:29:58 --> Language Class Initialized
INFO - 2023-05-08 08:29:58 --> Loader Class Initialized
INFO - 2023-05-08 08:29:58 --> Helper loaded: url_helper
INFO - 2023-05-08 08:29:58 --> Helper loaded: file_helper
INFO - 2023-05-08 08:29:58 --> Helper loaded: html_helper
INFO - 2023-05-08 08:29:58 --> Helper loaded: text_helper
INFO - 2023-05-08 08:29:58 --> Helper loaded: form_helper
INFO - 2023-05-08 08:29:58 --> Helper loaded: lang_helper
INFO - 2023-05-08 08:29:58 --> Helper loaded: security_helper
INFO - 2023-05-08 08:29:58 --> Helper loaded: cookie_helper
INFO - 2023-05-08 08:29:58 --> Database Driver Class Initialized
INFO - 2023-05-08 08:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 08:29:58 --> Parser Class Initialized
INFO - 2023-05-08 08:29:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 08:29:58 --> Pagination Class Initialized
INFO - 2023-05-08 08:29:58 --> Form Validation Class Initialized
INFO - 2023-05-08 08:29:58 --> Controller Class Initialized
INFO - 2023-05-08 08:29:58 --> Model Class Initialized
DEBUG - 2023-05-08 08:29:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 08:33:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 08:33:27 --> Config Class Initialized
INFO - 2023-05-08 08:33:27 --> Hooks Class Initialized
DEBUG - 2023-05-08 08:33:27 --> UTF-8 Support Enabled
INFO - 2023-05-08 08:33:27 --> Utf8 Class Initialized
INFO - 2023-05-08 08:33:27 --> URI Class Initialized
DEBUG - 2023-05-08 08:33:27 --> No URI present. Default controller set.
INFO - 2023-05-08 08:33:27 --> Router Class Initialized
INFO - 2023-05-08 08:33:27 --> Output Class Initialized
INFO - 2023-05-08 08:33:27 --> Security Class Initialized
DEBUG - 2023-05-08 08:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 08:33:27 --> Input Class Initialized
INFO - 2023-05-08 08:33:27 --> Language Class Initialized
INFO - 2023-05-08 08:33:27 --> Loader Class Initialized
INFO - 2023-05-08 08:33:27 --> Helper loaded: url_helper
INFO - 2023-05-08 08:33:27 --> Helper loaded: file_helper
INFO - 2023-05-08 08:33:27 --> Helper loaded: html_helper
INFO - 2023-05-08 08:33:27 --> Helper loaded: text_helper
INFO - 2023-05-08 08:33:27 --> Helper loaded: form_helper
INFO - 2023-05-08 08:33:27 --> Helper loaded: lang_helper
INFO - 2023-05-08 08:33:27 --> Helper loaded: security_helper
INFO - 2023-05-08 08:33:27 --> Helper loaded: cookie_helper
INFO - 2023-05-08 08:33:27 --> Database Driver Class Initialized
INFO - 2023-05-08 08:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 08:33:27 --> Parser Class Initialized
INFO - 2023-05-08 08:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 08:33:27 --> Pagination Class Initialized
INFO - 2023-05-08 08:33:27 --> Form Validation Class Initialized
INFO - 2023-05-08 08:33:27 --> Controller Class Initialized
INFO - 2023-05-08 08:33:27 --> Model Class Initialized
DEBUG - 2023-05-08 08:33:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 13:19:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:27 --> Config Class Initialized
INFO - 2023-05-08 13:19:27 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:27 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:27 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:27 --> URI Class Initialized
DEBUG - 2023-05-08 13:19:27 --> No URI present. Default controller set.
INFO - 2023-05-08 13:19:27 --> Router Class Initialized
INFO - 2023-05-08 13:19:27 --> Output Class Initialized
INFO - 2023-05-08 13:19:27 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:27 --> Input Class Initialized
INFO - 2023-05-08 13:19:27 --> Language Class Initialized
INFO - 2023-05-08 13:19:27 --> Loader Class Initialized
INFO - 2023-05-08 13:19:27 --> Helper loaded: url_helper
INFO - 2023-05-08 13:19:27 --> Helper loaded: file_helper
INFO - 2023-05-08 13:19:27 --> Helper loaded: html_helper
INFO - 2023-05-08 13:19:27 --> Helper loaded: text_helper
INFO - 2023-05-08 13:19:27 --> Helper loaded: form_helper
INFO - 2023-05-08 13:19:27 --> Helper loaded: lang_helper
INFO - 2023-05-08 13:19:27 --> Helper loaded: security_helper
INFO - 2023-05-08 13:19:27 --> Helper loaded: cookie_helper
INFO - 2023-05-08 13:19:27 --> Database Driver Class Initialized
INFO - 2023-05-08 13:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 13:19:27 --> Parser Class Initialized
INFO - 2023-05-08 13:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 13:19:27 --> Pagination Class Initialized
INFO - 2023-05-08 13:19:27 --> Form Validation Class Initialized
INFO - 2023-05-08 13:19:27 --> Controller Class Initialized
INFO - 2023-05-08 13:19:27 --> Model Class Initialized
DEBUG - 2023-05-08 13:19:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 13:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:28 --> Config Class Initialized
INFO - 2023-05-08 13:19:28 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:28 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:28 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:28 --> URI Class Initialized
INFO - 2023-05-08 13:19:28 --> Router Class Initialized
INFO - 2023-05-08 13:19:28 --> Output Class Initialized
INFO - 2023-05-08 13:19:28 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:28 --> Input Class Initialized
INFO - 2023-05-08 13:19:28 --> Language Class Initialized
INFO - 2023-05-08 13:19:28 --> Loader Class Initialized
INFO - 2023-05-08 13:19:28 --> Helper loaded: url_helper
INFO - 2023-05-08 13:19:28 --> Helper loaded: file_helper
INFO - 2023-05-08 13:19:28 --> Helper loaded: html_helper
INFO - 2023-05-08 13:19:28 --> Helper loaded: text_helper
INFO - 2023-05-08 13:19:28 --> Helper loaded: form_helper
INFO - 2023-05-08 13:19:28 --> Helper loaded: lang_helper
INFO - 2023-05-08 13:19:28 --> Helper loaded: security_helper
INFO - 2023-05-08 13:19:28 --> Helper loaded: cookie_helper
INFO - 2023-05-08 13:19:28 --> Database Driver Class Initialized
INFO - 2023-05-08 13:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 13:19:28 --> Parser Class Initialized
INFO - 2023-05-08 13:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 13:19:28 --> Pagination Class Initialized
INFO - 2023-05-08 13:19:28 --> Form Validation Class Initialized
INFO - 2023-05-08 13:19:28 --> Controller Class Initialized
INFO - 2023-05-08 13:19:28 --> Model Class Initialized
DEBUG - 2023-05-08 13:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 13:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 13:19:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 13:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 13:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 13:19:28 --> Model Class Initialized
INFO - 2023-05-08 13:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 13:19:28 --> Final output sent to browser
DEBUG - 2023-05-08 13:19:28 --> Total execution time: 0.0312
ERROR - 2023-05-08 13:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:28 --> Config Class Initialized
INFO - 2023-05-08 13:19:28 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:28 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:28 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:28 --> URI Class Initialized
INFO - 2023-05-08 13:19:28 --> Router Class Initialized
INFO - 2023-05-08 13:19:28 --> Output Class Initialized
INFO - 2023-05-08 13:19:28 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:28 --> Input Class Initialized
INFO - 2023-05-08 13:19:28 --> Language Class Initialized
ERROR - 2023-05-08 13:19:28 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2023-05-08 13:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:28 --> Config Class Initialized
INFO - 2023-05-08 13:19:28 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:28 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:28 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:28 --> URI Class Initialized
INFO - 2023-05-08 13:19:28 --> Router Class Initialized
INFO - 2023-05-08 13:19:28 --> Output Class Initialized
INFO - 2023-05-08 13:19:28 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:28 --> Input Class Initialized
INFO - 2023-05-08 13:19:28 --> Language Class Initialized
ERROR - 2023-05-08 13:19:28 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2023-05-08 13:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:29 --> Config Class Initialized
INFO - 2023-05-08 13:19:29 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:29 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:29 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:29 --> URI Class Initialized
INFO - 2023-05-08 13:19:29 --> Router Class Initialized
INFO - 2023-05-08 13:19:29 --> Output Class Initialized
INFO - 2023-05-08 13:19:29 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:29 --> Input Class Initialized
INFO - 2023-05-08 13:19:29 --> Language Class Initialized
ERROR - 2023-05-08 13:19:29 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-05-08 13:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:29 --> Config Class Initialized
INFO - 2023-05-08 13:19:29 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:29 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:29 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:29 --> URI Class Initialized
INFO - 2023-05-08 13:19:29 --> Router Class Initialized
INFO - 2023-05-08 13:19:29 --> Output Class Initialized
INFO - 2023-05-08 13:19:29 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:29 --> Input Class Initialized
INFO - 2023-05-08 13:19:29 --> Language Class Initialized
ERROR - 2023-05-08 13:19:29 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-05-08 13:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:48 --> Config Class Initialized
INFO - 2023-05-08 13:19:48 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:48 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:48 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:48 --> URI Class Initialized
INFO - 2023-05-08 13:19:48 --> Router Class Initialized
INFO - 2023-05-08 13:19:48 --> Output Class Initialized
INFO - 2023-05-08 13:19:48 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:48 --> Input Class Initialized
INFO - 2023-05-08 13:19:48 --> Language Class Initialized
INFO - 2023-05-08 13:19:48 --> Loader Class Initialized
INFO - 2023-05-08 13:19:48 --> Helper loaded: url_helper
INFO - 2023-05-08 13:19:48 --> Helper loaded: file_helper
INFO - 2023-05-08 13:19:48 --> Helper loaded: html_helper
INFO - 2023-05-08 13:19:48 --> Helper loaded: text_helper
INFO - 2023-05-08 13:19:48 --> Helper loaded: form_helper
INFO - 2023-05-08 13:19:48 --> Helper loaded: lang_helper
INFO - 2023-05-08 13:19:48 --> Helper loaded: security_helper
INFO - 2023-05-08 13:19:48 --> Helper loaded: cookie_helper
INFO - 2023-05-08 13:19:48 --> Database Driver Class Initialized
INFO - 2023-05-08 13:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 13:19:48 --> Parser Class Initialized
INFO - 2023-05-08 13:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 13:19:48 --> Pagination Class Initialized
INFO - 2023-05-08 13:19:48 --> Form Validation Class Initialized
INFO - 2023-05-08 13:19:48 --> Controller Class Initialized
INFO - 2023-05-08 13:19:48 --> Model Class Initialized
DEBUG - 2023-05-08 13:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 13:19:48 --> Model Class Initialized
INFO - 2023-05-08 13:19:48 --> Final output sent to browser
DEBUG - 2023-05-08 13:19:48 --> Total execution time: 0.0203
ERROR - 2023-05-08 13:19:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:49 --> Config Class Initialized
INFO - 2023-05-08 13:19:49 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:49 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:49 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:49 --> URI Class Initialized
DEBUG - 2023-05-08 13:19:49 --> No URI present. Default controller set.
INFO - 2023-05-08 13:19:49 --> Router Class Initialized
INFO - 2023-05-08 13:19:49 --> Output Class Initialized
INFO - 2023-05-08 13:19:49 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:49 --> Input Class Initialized
INFO - 2023-05-08 13:19:49 --> Language Class Initialized
INFO - 2023-05-08 13:19:49 --> Loader Class Initialized
INFO - 2023-05-08 13:19:49 --> Helper loaded: url_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: file_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: html_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: text_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: form_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: lang_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: security_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: cookie_helper
INFO - 2023-05-08 13:19:49 --> Database Driver Class Initialized
INFO - 2023-05-08 13:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 13:19:49 --> Parser Class Initialized
INFO - 2023-05-08 13:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 13:19:49 --> Pagination Class Initialized
INFO - 2023-05-08 13:19:49 --> Form Validation Class Initialized
INFO - 2023-05-08 13:19:49 --> Controller Class Initialized
INFO - 2023-05-08 13:19:49 --> Model Class Initialized
DEBUG - 2023-05-08 13:19:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 13:19:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:19:49 --> Config Class Initialized
INFO - 2023-05-08 13:19:49 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:19:49 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:19:49 --> Utf8 Class Initialized
INFO - 2023-05-08 13:19:49 --> URI Class Initialized
INFO - 2023-05-08 13:19:49 --> Router Class Initialized
INFO - 2023-05-08 13:19:49 --> Output Class Initialized
INFO - 2023-05-08 13:19:49 --> Security Class Initialized
DEBUG - 2023-05-08 13:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:19:49 --> Input Class Initialized
INFO - 2023-05-08 13:19:49 --> Language Class Initialized
INFO - 2023-05-08 13:19:49 --> Loader Class Initialized
INFO - 2023-05-08 13:19:49 --> Helper loaded: url_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: file_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: html_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: text_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: form_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: lang_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: security_helper
INFO - 2023-05-08 13:19:49 --> Helper loaded: cookie_helper
INFO - 2023-05-08 13:19:49 --> Database Driver Class Initialized
INFO - 2023-05-08 13:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 13:19:49 --> Parser Class Initialized
INFO - 2023-05-08 13:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 13:19:49 --> Pagination Class Initialized
INFO - 2023-05-08 13:19:49 --> Form Validation Class Initialized
INFO - 2023-05-08 13:19:49 --> Controller Class Initialized
INFO - 2023-05-08 13:19:49 --> Model Class Initialized
DEBUG - 2023-05-08 13:19:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 13:19:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 13:19:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 13:19:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 13:19:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 13:19:49 --> Model Class Initialized
INFO - 2023-05-08 13:19:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 13:19:49 --> Final output sent to browser
DEBUG - 2023-05-08 13:19:49 --> Total execution time: 0.0304
ERROR - 2023-05-08 13:44:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 13:44:03 --> Config Class Initialized
INFO - 2023-05-08 13:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-08 13:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-08 13:44:03 --> Utf8 Class Initialized
INFO - 2023-05-08 13:44:03 --> URI Class Initialized
INFO - 2023-05-08 13:44:03 --> Router Class Initialized
INFO - 2023-05-08 13:44:03 --> Output Class Initialized
INFO - 2023-05-08 13:44:03 --> Security Class Initialized
DEBUG - 2023-05-08 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 13:44:03 --> Input Class Initialized
INFO - 2023-05-08 13:44:03 --> Language Class Initialized
INFO - 2023-05-08 13:44:03 --> Loader Class Initialized
INFO - 2023-05-08 13:44:03 --> Helper loaded: url_helper
INFO - 2023-05-08 13:44:03 --> Helper loaded: file_helper
INFO - 2023-05-08 13:44:03 --> Helper loaded: html_helper
INFO - 2023-05-08 13:44:03 --> Helper loaded: text_helper
INFO - 2023-05-08 13:44:03 --> Helper loaded: form_helper
INFO - 2023-05-08 13:44:03 --> Helper loaded: lang_helper
INFO - 2023-05-08 13:44:03 --> Helper loaded: security_helper
INFO - 2023-05-08 13:44:03 --> Helper loaded: cookie_helper
INFO - 2023-05-08 13:44:03 --> Database Driver Class Initialized
INFO - 2023-05-08 13:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 13:44:03 --> Parser Class Initialized
INFO - 2023-05-08 13:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 13:44:03 --> Pagination Class Initialized
INFO - 2023-05-08 13:44:03 --> Form Validation Class Initialized
INFO - 2023-05-08 13:44:03 --> Controller Class Initialized
ERROR - 2023-05-08 15:18:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:18:09 --> Config Class Initialized
INFO - 2023-05-08 15:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:18:09 --> Utf8 Class Initialized
INFO - 2023-05-08 15:18:09 --> URI Class Initialized
DEBUG - 2023-05-08 15:18:09 --> No URI present. Default controller set.
INFO - 2023-05-08 15:18:09 --> Router Class Initialized
INFO - 2023-05-08 15:18:09 --> Output Class Initialized
INFO - 2023-05-08 15:18:09 --> Security Class Initialized
DEBUG - 2023-05-08 15:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:18:09 --> Input Class Initialized
INFO - 2023-05-08 15:18:09 --> Language Class Initialized
INFO - 2023-05-08 15:18:09 --> Loader Class Initialized
INFO - 2023-05-08 15:18:09 --> Helper loaded: url_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: file_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: html_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: text_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: form_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: security_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:18:09 --> Database Driver Class Initialized
INFO - 2023-05-08 15:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:18:09 --> Parser Class Initialized
INFO - 2023-05-08 15:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:18:09 --> Pagination Class Initialized
INFO - 2023-05-08 15:18:09 --> Form Validation Class Initialized
INFO - 2023-05-08 15:18:09 --> Controller Class Initialized
INFO - 2023-05-08 15:18:09 --> Model Class Initialized
DEBUG - 2023-05-08 15:18:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 15:18:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:18:09 --> Config Class Initialized
INFO - 2023-05-08 15:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:18:09 --> Utf8 Class Initialized
INFO - 2023-05-08 15:18:09 --> URI Class Initialized
INFO - 2023-05-08 15:18:09 --> Router Class Initialized
INFO - 2023-05-08 15:18:09 --> Output Class Initialized
INFO - 2023-05-08 15:18:09 --> Security Class Initialized
DEBUG - 2023-05-08 15:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:18:09 --> Input Class Initialized
INFO - 2023-05-08 15:18:09 --> Language Class Initialized
INFO - 2023-05-08 15:18:09 --> Loader Class Initialized
INFO - 2023-05-08 15:18:09 --> Helper loaded: url_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: file_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: html_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: text_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: form_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: security_helper
INFO - 2023-05-08 15:18:09 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:18:09 --> Database Driver Class Initialized
INFO - 2023-05-08 15:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:18:09 --> Parser Class Initialized
INFO - 2023-05-08 15:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:18:09 --> Pagination Class Initialized
INFO - 2023-05-08 15:18:09 --> Form Validation Class Initialized
INFO - 2023-05-08 15:18:09 --> Controller Class Initialized
INFO - 2023-05-08 15:18:09 --> Model Class Initialized
DEBUG - 2023-05-08 15:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 15:18:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:18:09 --> Model Class Initialized
INFO - 2023-05-08 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:18:09 --> Final output sent to browser
DEBUG - 2023-05-08 15:18:09 --> Total execution time: 0.0307
ERROR - 2023-05-08 15:18:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:18:21 --> Config Class Initialized
INFO - 2023-05-08 15:18:21 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:18:21 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:18:21 --> Utf8 Class Initialized
INFO - 2023-05-08 15:18:21 --> URI Class Initialized
DEBUG - 2023-05-08 15:18:21 --> No URI present. Default controller set.
INFO - 2023-05-08 15:18:21 --> Router Class Initialized
INFO - 2023-05-08 15:18:21 --> Output Class Initialized
INFO - 2023-05-08 15:18:21 --> Security Class Initialized
DEBUG - 2023-05-08 15:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:18:21 --> Input Class Initialized
INFO - 2023-05-08 15:18:21 --> Language Class Initialized
INFO - 2023-05-08 15:18:21 --> Loader Class Initialized
INFO - 2023-05-08 15:18:21 --> Helper loaded: url_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: file_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: html_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: text_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: form_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: security_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:18:21 --> Database Driver Class Initialized
INFO - 2023-05-08 15:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:18:21 --> Parser Class Initialized
INFO - 2023-05-08 15:18:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:18:21 --> Pagination Class Initialized
INFO - 2023-05-08 15:18:21 --> Form Validation Class Initialized
INFO - 2023-05-08 15:18:21 --> Controller Class Initialized
INFO - 2023-05-08 15:18:21 --> Model Class Initialized
DEBUG - 2023-05-08 15:18:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 15:18:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:18:21 --> Config Class Initialized
INFO - 2023-05-08 15:18:21 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:18:21 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:18:21 --> Utf8 Class Initialized
INFO - 2023-05-08 15:18:21 --> URI Class Initialized
INFO - 2023-05-08 15:18:21 --> Router Class Initialized
INFO - 2023-05-08 15:18:21 --> Output Class Initialized
INFO - 2023-05-08 15:18:21 --> Security Class Initialized
DEBUG - 2023-05-08 15:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:18:21 --> Input Class Initialized
INFO - 2023-05-08 15:18:21 --> Language Class Initialized
INFO - 2023-05-08 15:18:21 --> Loader Class Initialized
INFO - 2023-05-08 15:18:21 --> Helper loaded: url_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: file_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: html_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: text_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: form_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: security_helper
INFO - 2023-05-08 15:18:21 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:18:21 --> Database Driver Class Initialized
INFO - 2023-05-08 15:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:18:21 --> Parser Class Initialized
INFO - 2023-05-08 15:18:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:18:21 --> Pagination Class Initialized
INFO - 2023-05-08 15:18:21 --> Form Validation Class Initialized
INFO - 2023-05-08 15:18:21 --> Controller Class Initialized
INFO - 2023-05-08 15:18:21 --> Model Class Initialized
DEBUG - 2023-05-08 15:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 15:18:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:18:21 --> Model Class Initialized
INFO - 2023-05-08 15:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:18:21 --> Final output sent to browser
DEBUG - 2023-05-08 15:18:21 --> Total execution time: 0.0280
ERROR - 2023-05-08 15:19:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:19:58 --> Config Class Initialized
INFO - 2023-05-08 15:19:58 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:19:58 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:19:58 --> Utf8 Class Initialized
INFO - 2023-05-08 15:19:58 --> URI Class Initialized
INFO - 2023-05-08 15:19:58 --> Router Class Initialized
INFO - 2023-05-08 15:19:58 --> Output Class Initialized
INFO - 2023-05-08 15:19:58 --> Security Class Initialized
DEBUG - 2023-05-08 15:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:19:58 --> Input Class Initialized
INFO - 2023-05-08 15:19:58 --> Language Class Initialized
INFO - 2023-05-08 15:19:58 --> Loader Class Initialized
INFO - 2023-05-08 15:19:58 --> Helper loaded: url_helper
INFO - 2023-05-08 15:19:58 --> Helper loaded: file_helper
INFO - 2023-05-08 15:19:58 --> Helper loaded: html_helper
INFO - 2023-05-08 15:19:58 --> Helper loaded: text_helper
INFO - 2023-05-08 15:19:58 --> Helper loaded: form_helper
INFO - 2023-05-08 15:19:58 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:19:58 --> Helper loaded: security_helper
INFO - 2023-05-08 15:19:58 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:19:58 --> Database Driver Class Initialized
INFO - 2023-05-08 15:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:19:58 --> Parser Class Initialized
INFO - 2023-05-08 15:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:19:58 --> Pagination Class Initialized
INFO - 2023-05-08 15:19:58 --> Form Validation Class Initialized
INFO - 2023-05-08 15:19:58 --> Controller Class Initialized
ERROR - 2023-05-08 15:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:19:59 --> Config Class Initialized
INFO - 2023-05-08 15:19:59 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:19:59 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:19:59 --> Utf8 Class Initialized
INFO - 2023-05-08 15:19:59 --> URI Class Initialized
INFO - 2023-05-08 15:19:59 --> Router Class Initialized
INFO - 2023-05-08 15:19:59 --> Output Class Initialized
INFO - 2023-05-08 15:19:59 --> Security Class Initialized
DEBUG - 2023-05-08 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:19:59 --> Input Class Initialized
INFO - 2023-05-08 15:19:59 --> Language Class Initialized
INFO - 2023-05-08 15:19:59 --> Loader Class Initialized
INFO - 2023-05-08 15:19:59 --> Helper loaded: url_helper
INFO - 2023-05-08 15:19:59 --> Helper loaded: file_helper
INFO - 2023-05-08 15:19:59 --> Helper loaded: html_helper
INFO - 2023-05-08 15:19:59 --> Helper loaded: text_helper
INFO - 2023-05-08 15:19:59 --> Helper loaded: form_helper
INFO - 2023-05-08 15:19:59 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:19:59 --> Helper loaded: security_helper
INFO - 2023-05-08 15:19:59 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:19:59 --> Database Driver Class Initialized
INFO - 2023-05-08 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:19:59 --> Parser Class Initialized
INFO - 2023-05-08 15:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:19:59 --> Pagination Class Initialized
INFO - 2023-05-08 15:19:59 --> Form Validation Class Initialized
INFO - 2023-05-08 15:19:59 --> Controller Class Initialized
INFO - 2023-05-08 15:19:59 --> Model Class Initialized
DEBUG - 2023-05-08 15:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 15:19:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:19:59 --> Model Class Initialized
INFO - 2023-05-08 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:19:59 --> Final output sent to browser
DEBUG - 2023-05-08 15:19:59 --> Total execution time: 0.0403
ERROR - 2023-05-08 15:20:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:20:05 --> Config Class Initialized
INFO - 2023-05-08 15:20:05 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:20:05 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:20:05 --> Utf8 Class Initialized
INFO - 2023-05-08 15:20:05 --> URI Class Initialized
INFO - 2023-05-08 15:20:05 --> Router Class Initialized
INFO - 2023-05-08 15:20:05 --> Output Class Initialized
INFO - 2023-05-08 15:20:05 --> Security Class Initialized
DEBUG - 2023-05-08 15:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:20:05 --> Input Class Initialized
INFO - 2023-05-08 15:20:05 --> Language Class Initialized
INFO - 2023-05-08 15:20:05 --> Loader Class Initialized
INFO - 2023-05-08 15:20:05 --> Helper loaded: url_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: file_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: html_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: text_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: form_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: security_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:20:05 --> Database Driver Class Initialized
INFO - 2023-05-08 15:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:20:05 --> Parser Class Initialized
INFO - 2023-05-08 15:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:20:05 --> Pagination Class Initialized
INFO - 2023-05-08 15:20:05 --> Form Validation Class Initialized
INFO - 2023-05-08 15:20:05 --> Controller Class Initialized
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
DEBUG - 2023-05-08 15:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
INFO - 2023-05-08 15:20:05 --> Final output sent to browser
DEBUG - 2023-05-08 15:20:05 --> Total execution time: 0.0176
ERROR - 2023-05-08 15:20:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:20:05 --> Config Class Initialized
INFO - 2023-05-08 15:20:05 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:20:05 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:20:05 --> Utf8 Class Initialized
INFO - 2023-05-08 15:20:05 --> URI Class Initialized
DEBUG - 2023-05-08 15:20:05 --> No URI present. Default controller set.
INFO - 2023-05-08 15:20:05 --> Router Class Initialized
INFO - 2023-05-08 15:20:05 --> Output Class Initialized
INFO - 2023-05-08 15:20:05 --> Security Class Initialized
DEBUG - 2023-05-08 15:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:20:05 --> Input Class Initialized
INFO - 2023-05-08 15:20:05 --> Language Class Initialized
INFO - 2023-05-08 15:20:05 --> Loader Class Initialized
INFO - 2023-05-08 15:20:05 --> Helper loaded: url_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: file_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: html_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: text_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: form_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: security_helper
INFO - 2023-05-08 15:20:05 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:20:05 --> Database Driver Class Initialized
INFO - 2023-05-08 15:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:20:05 --> Parser Class Initialized
INFO - 2023-05-08 15:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:20:05 --> Pagination Class Initialized
INFO - 2023-05-08 15:20:05 --> Form Validation Class Initialized
INFO - 2023-05-08 15:20:05 --> Controller Class Initialized
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
DEBUG - 2023-05-08 15:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
DEBUG - 2023-05-08 15:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
DEBUG - 2023-05-08 15:20:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
INFO - 2023-05-08 15:20:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 15:20:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:20:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:20:05 --> Model Class Initialized
INFO - 2023-05-08 15:20:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:20:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:20:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:20:05 --> Final output sent to browser
DEBUG - 2023-05-08 15:20:05 --> Total execution time: 0.0728
ERROR - 2023-05-08 15:20:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:20:13 --> Config Class Initialized
INFO - 2023-05-08 15:20:13 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:20:13 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:20:13 --> Utf8 Class Initialized
INFO - 2023-05-08 15:20:13 --> URI Class Initialized
INFO - 2023-05-08 15:20:13 --> Router Class Initialized
INFO - 2023-05-08 15:20:13 --> Output Class Initialized
INFO - 2023-05-08 15:20:13 --> Security Class Initialized
DEBUG - 2023-05-08 15:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:20:13 --> Input Class Initialized
INFO - 2023-05-08 15:20:13 --> Language Class Initialized
INFO - 2023-05-08 15:20:13 --> Loader Class Initialized
INFO - 2023-05-08 15:20:13 --> Helper loaded: url_helper
INFO - 2023-05-08 15:20:13 --> Helper loaded: file_helper
INFO - 2023-05-08 15:20:13 --> Helper loaded: html_helper
INFO - 2023-05-08 15:20:13 --> Helper loaded: text_helper
INFO - 2023-05-08 15:20:13 --> Helper loaded: form_helper
INFO - 2023-05-08 15:20:13 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:20:13 --> Helper loaded: security_helper
INFO - 2023-05-08 15:20:13 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:20:13 --> Database Driver Class Initialized
INFO - 2023-05-08 15:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:20:13 --> Parser Class Initialized
INFO - 2023-05-08 15:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:20:13 --> Pagination Class Initialized
INFO - 2023-05-08 15:20:13 --> Form Validation Class Initialized
INFO - 2023-05-08 15:20:13 --> Controller Class Initialized
INFO - 2023-05-08 15:20:13 --> Model Class Initialized
DEBUG - 2023-05-08 15:20:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:13 --> Model Class Initialized
INFO - 2023-05-08 15:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-08 15:20:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:20:13 --> Model Class Initialized
INFO - 2023-05-08 15:20:13 --> Model Class Initialized
INFO - 2023-05-08 15:20:13 --> Model Class Initialized
INFO - 2023-05-08 15:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:20:13 --> Final output sent to browser
DEBUG - 2023-05-08 15:20:13 --> Total execution time: 0.0610
ERROR - 2023-05-08 15:20:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:20:14 --> Config Class Initialized
INFO - 2023-05-08 15:20:14 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:20:14 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:20:14 --> Utf8 Class Initialized
INFO - 2023-05-08 15:20:14 --> URI Class Initialized
INFO - 2023-05-08 15:20:14 --> Router Class Initialized
INFO - 2023-05-08 15:20:14 --> Output Class Initialized
INFO - 2023-05-08 15:20:14 --> Security Class Initialized
DEBUG - 2023-05-08 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:20:14 --> Input Class Initialized
INFO - 2023-05-08 15:20:14 --> Language Class Initialized
INFO - 2023-05-08 15:20:14 --> Loader Class Initialized
INFO - 2023-05-08 15:20:14 --> Helper loaded: url_helper
INFO - 2023-05-08 15:20:14 --> Helper loaded: file_helper
INFO - 2023-05-08 15:20:14 --> Helper loaded: html_helper
INFO - 2023-05-08 15:20:14 --> Helper loaded: text_helper
INFO - 2023-05-08 15:20:14 --> Helper loaded: form_helper
INFO - 2023-05-08 15:20:14 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:20:14 --> Helper loaded: security_helper
INFO - 2023-05-08 15:20:14 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:20:14 --> Database Driver Class Initialized
INFO - 2023-05-08 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:20:14 --> Parser Class Initialized
INFO - 2023-05-08 15:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:20:14 --> Pagination Class Initialized
INFO - 2023-05-08 15:20:14 --> Form Validation Class Initialized
INFO - 2023-05-08 15:20:14 --> Controller Class Initialized
INFO - 2023-05-08 15:20:14 --> Model Class Initialized
DEBUG - 2023-05-08 15:20:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:14 --> Model Class Initialized
INFO - 2023-05-08 15:20:14 --> Final output sent to browser
DEBUG - 2023-05-08 15:20:14 --> Total execution time: 0.0211
ERROR - 2023-05-08 15:20:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:20:22 --> Config Class Initialized
INFO - 2023-05-08 15:20:22 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:20:22 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:20:22 --> Utf8 Class Initialized
INFO - 2023-05-08 15:20:22 --> URI Class Initialized
INFO - 2023-05-08 15:20:22 --> Router Class Initialized
INFO - 2023-05-08 15:20:22 --> Output Class Initialized
INFO - 2023-05-08 15:20:22 --> Security Class Initialized
DEBUG - 2023-05-08 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:20:22 --> Input Class Initialized
INFO - 2023-05-08 15:20:22 --> Language Class Initialized
INFO - 2023-05-08 15:20:22 --> Loader Class Initialized
INFO - 2023-05-08 15:20:22 --> Helper loaded: url_helper
INFO - 2023-05-08 15:20:22 --> Helper loaded: file_helper
INFO - 2023-05-08 15:20:22 --> Helper loaded: html_helper
INFO - 2023-05-08 15:20:22 --> Helper loaded: text_helper
INFO - 2023-05-08 15:20:22 --> Helper loaded: form_helper
INFO - 2023-05-08 15:20:22 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:20:22 --> Helper loaded: security_helper
INFO - 2023-05-08 15:20:22 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:20:22 --> Database Driver Class Initialized
INFO - 2023-05-08 15:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:20:22 --> Parser Class Initialized
INFO - 2023-05-08 15:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:20:22 --> Pagination Class Initialized
INFO - 2023-05-08 15:20:22 --> Form Validation Class Initialized
INFO - 2023-05-08 15:20:22 --> Controller Class Initialized
INFO - 2023-05-08 15:20:22 --> Model Class Initialized
DEBUG - 2023-05-08 15:20:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:20:22 --> Model Class Initialized
INFO - 2023-05-08 15:20:22 --> Final output sent to browser
DEBUG - 2023-05-08 15:20:22 --> Total execution time: 0.0199
ERROR - 2023-05-08 15:21:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:21:21 --> Config Class Initialized
INFO - 2023-05-08 15:21:21 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:21:21 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:21:21 --> Utf8 Class Initialized
INFO - 2023-05-08 15:21:21 --> URI Class Initialized
DEBUG - 2023-05-08 15:21:21 --> No URI present. Default controller set.
INFO - 2023-05-08 15:21:21 --> Router Class Initialized
INFO - 2023-05-08 15:21:21 --> Output Class Initialized
INFO - 2023-05-08 15:21:21 --> Security Class Initialized
DEBUG - 2023-05-08 15:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:21:21 --> Input Class Initialized
INFO - 2023-05-08 15:21:21 --> Language Class Initialized
INFO - 2023-05-08 15:21:21 --> Loader Class Initialized
INFO - 2023-05-08 15:21:21 --> Helper loaded: url_helper
INFO - 2023-05-08 15:21:21 --> Helper loaded: file_helper
INFO - 2023-05-08 15:21:21 --> Helper loaded: html_helper
INFO - 2023-05-08 15:21:21 --> Helper loaded: text_helper
INFO - 2023-05-08 15:21:21 --> Helper loaded: form_helper
INFO - 2023-05-08 15:21:21 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:21:21 --> Helper loaded: security_helper
INFO - 2023-05-08 15:21:21 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:21:21 --> Database Driver Class Initialized
INFO - 2023-05-08 15:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:21:21 --> Parser Class Initialized
INFO - 2023-05-08 15:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:21:21 --> Pagination Class Initialized
INFO - 2023-05-08 15:21:21 --> Form Validation Class Initialized
INFO - 2023-05-08 15:21:21 --> Controller Class Initialized
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
INFO - 2023-05-08 15:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 15:21:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:21:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:21:21 --> Model Class Initialized
INFO - 2023-05-08 15:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:21:22 --> Final output sent to browser
DEBUG - 2023-05-08 15:21:22 --> Total execution time: 0.0751
ERROR - 2023-05-08 15:21:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:21:30 --> Config Class Initialized
INFO - 2023-05-08 15:21:30 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:21:30 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:21:30 --> Utf8 Class Initialized
INFO - 2023-05-08 15:21:30 --> URI Class Initialized
INFO - 2023-05-08 15:21:30 --> Router Class Initialized
INFO - 2023-05-08 15:21:30 --> Output Class Initialized
INFO - 2023-05-08 15:21:30 --> Security Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:21:30 --> Input Class Initialized
INFO - 2023-05-08 15:21:30 --> Language Class Initialized
INFO - 2023-05-08 15:21:30 --> Loader Class Initialized
INFO - 2023-05-08 15:21:30 --> Helper loaded: url_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: file_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: html_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: text_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: form_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: security_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:21:30 --> Database Driver Class Initialized
INFO - 2023-05-08 15:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:21:30 --> Parser Class Initialized
INFO - 2023-05-08 15:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:21:30 --> Pagination Class Initialized
INFO - 2023-05-08 15:21:30 --> Form Validation Class Initialized
INFO - 2023-05-08 15:21:30 --> Controller Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:30 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
INFO - 2023-05-08 15:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-05-08 15:21:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
INFO - 2023-05-08 15:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:21:30 --> Final output sent to browser
DEBUG - 2023-05-08 15:21:30 --> Total execution time: 0.0715
ERROR - 2023-05-08 15:21:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:21:30 --> Config Class Initialized
INFO - 2023-05-08 15:21:30 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:21:30 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:21:30 --> Utf8 Class Initialized
INFO - 2023-05-08 15:21:30 --> URI Class Initialized
INFO - 2023-05-08 15:21:30 --> Router Class Initialized
INFO - 2023-05-08 15:21:30 --> Output Class Initialized
INFO - 2023-05-08 15:21:30 --> Security Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:21:30 --> Input Class Initialized
INFO - 2023-05-08 15:21:30 --> Language Class Initialized
INFO - 2023-05-08 15:21:30 --> Loader Class Initialized
INFO - 2023-05-08 15:21:30 --> Helper loaded: url_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: file_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: html_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: text_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: form_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: security_helper
INFO - 2023-05-08 15:21:30 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:21:30 --> Database Driver Class Initialized
INFO - 2023-05-08 15:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:21:30 --> Parser Class Initialized
INFO - 2023-05-08 15:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:21:30 --> Pagination Class Initialized
INFO - 2023-05-08 15:21:30 --> Form Validation Class Initialized
INFO - 2023-05-08 15:21:30 --> Controller Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:30 --> Model Class Initialized
INFO - 2023-05-08 15:21:30 --> Final output sent to browser
DEBUG - 2023-05-08 15:21:30 --> Total execution time: 0.0200
ERROR - 2023-05-08 15:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:21:54 --> Config Class Initialized
INFO - 2023-05-08 15:21:54 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:21:54 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:21:54 --> Utf8 Class Initialized
INFO - 2023-05-08 15:21:54 --> URI Class Initialized
INFO - 2023-05-08 15:21:54 --> Router Class Initialized
INFO - 2023-05-08 15:21:54 --> Output Class Initialized
INFO - 2023-05-08 15:21:54 --> Security Class Initialized
DEBUG - 2023-05-08 15:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:21:54 --> Input Class Initialized
INFO - 2023-05-08 15:21:54 --> Language Class Initialized
INFO - 2023-05-08 15:21:54 --> Loader Class Initialized
INFO - 2023-05-08 15:21:54 --> Helper loaded: url_helper
INFO - 2023-05-08 15:21:54 --> Helper loaded: file_helper
INFO - 2023-05-08 15:21:54 --> Helper loaded: html_helper
INFO - 2023-05-08 15:21:54 --> Helper loaded: text_helper
INFO - 2023-05-08 15:21:54 --> Helper loaded: form_helper
INFO - 2023-05-08 15:21:54 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:21:54 --> Helper loaded: security_helper
INFO - 2023-05-08 15:21:54 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:21:54 --> Database Driver Class Initialized
INFO - 2023-05-08 15:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:21:54 --> Parser Class Initialized
INFO - 2023-05-08 15:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:21:54 --> Pagination Class Initialized
INFO - 2023-05-08 15:21:54 --> Form Validation Class Initialized
INFO - 2023-05-08 15:21:54 --> Controller Class Initialized
INFO - 2023-05-08 15:21:54 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:54 --> Model Class Initialized
INFO - 2023-05-08 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-08 15:21:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:21:54 --> Model Class Initialized
INFO - 2023-05-08 15:21:54 --> Model Class Initialized
INFO - 2023-05-08 15:21:54 --> Model Class Initialized
INFO - 2023-05-08 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:21:54 --> Final output sent to browser
DEBUG - 2023-05-08 15:21:54 --> Total execution time: 0.0658
ERROR - 2023-05-08 15:21:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:21:55 --> Config Class Initialized
INFO - 2023-05-08 15:21:55 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:21:55 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:21:55 --> Utf8 Class Initialized
INFO - 2023-05-08 15:21:55 --> URI Class Initialized
INFO - 2023-05-08 15:21:55 --> Router Class Initialized
INFO - 2023-05-08 15:21:55 --> Output Class Initialized
INFO - 2023-05-08 15:21:55 --> Security Class Initialized
DEBUG - 2023-05-08 15:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:21:55 --> Input Class Initialized
INFO - 2023-05-08 15:21:55 --> Language Class Initialized
INFO - 2023-05-08 15:21:55 --> Loader Class Initialized
INFO - 2023-05-08 15:21:55 --> Helper loaded: url_helper
INFO - 2023-05-08 15:21:55 --> Helper loaded: file_helper
INFO - 2023-05-08 15:21:55 --> Helper loaded: html_helper
INFO - 2023-05-08 15:21:55 --> Helper loaded: text_helper
INFO - 2023-05-08 15:21:55 --> Helper loaded: form_helper
INFO - 2023-05-08 15:21:55 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:21:55 --> Helper loaded: security_helper
INFO - 2023-05-08 15:21:55 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:21:55 --> Database Driver Class Initialized
INFO - 2023-05-08 15:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:21:55 --> Parser Class Initialized
INFO - 2023-05-08 15:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:21:55 --> Pagination Class Initialized
INFO - 2023-05-08 15:21:55 --> Form Validation Class Initialized
INFO - 2023-05-08 15:21:55 --> Controller Class Initialized
INFO - 2023-05-08 15:21:55 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:55 --> Model Class Initialized
INFO - 2023-05-08 15:21:55 --> Final output sent to browser
DEBUG - 2023-05-08 15:21:55 --> Total execution time: 0.0215
ERROR - 2023-05-08 15:21:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:21:59 --> Config Class Initialized
INFO - 2023-05-08 15:21:59 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:21:59 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:21:59 --> Utf8 Class Initialized
INFO - 2023-05-08 15:21:59 --> URI Class Initialized
INFO - 2023-05-08 15:21:59 --> Router Class Initialized
INFO - 2023-05-08 15:21:59 --> Output Class Initialized
INFO - 2023-05-08 15:21:59 --> Security Class Initialized
DEBUG - 2023-05-08 15:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:21:59 --> Input Class Initialized
INFO - 2023-05-08 15:21:59 --> Language Class Initialized
INFO - 2023-05-08 15:21:59 --> Loader Class Initialized
INFO - 2023-05-08 15:21:59 --> Helper loaded: url_helper
INFO - 2023-05-08 15:21:59 --> Helper loaded: file_helper
INFO - 2023-05-08 15:21:59 --> Helper loaded: html_helper
INFO - 2023-05-08 15:21:59 --> Helper loaded: text_helper
INFO - 2023-05-08 15:21:59 --> Helper loaded: form_helper
INFO - 2023-05-08 15:21:59 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:21:59 --> Helper loaded: security_helper
INFO - 2023-05-08 15:21:59 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:21:59 --> Database Driver Class Initialized
INFO - 2023-05-08 15:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:21:59 --> Parser Class Initialized
INFO - 2023-05-08 15:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:21:59 --> Pagination Class Initialized
INFO - 2023-05-08 15:21:59 --> Form Validation Class Initialized
INFO - 2023-05-08 15:21:59 --> Controller Class Initialized
INFO - 2023-05-08 15:21:59 --> Model Class Initialized
DEBUG - 2023-05-08 15:21:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:21:59 --> Model Class Initialized
INFO - 2023-05-08 15:21:59 --> Final output sent to browser
DEBUG - 2023-05-08 15:21:59 --> Total execution time: 0.0220
ERROR - 2023-05-08 15:24:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:08 --> Config Class Initialized
INFO - 2023-05-08 15:24:08 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:08 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:08 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:08 --> URI Class Initialized
INFO - 2023-05-08 15:24:08 --> Router Class Initialized
INFO - 2023-05-08 15:24:08 --> Output Class Initialized
INFO - 2023-05-08 15:24:08 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:08 --> Input Class Initialized
INFO - 2023-05-08 15:24:08 --> Language Class Initialized
INFO - 2023-05-08 15:24:08 --> Loader Class Initialized
INFO - 2023-05-08 15:24:08 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:08 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:08 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:08 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:08 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:08 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:08 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:08 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:08 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:08 --> Parser Class Initialized
INFO - 2023-05-08 15:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:08 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:08 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:08 --> Controller Class Initialized
INFO - 2023-05-08 15:24:08 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:08 --> Model Class Initialized
INFO - 2023-05-08 15:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-08 15:24:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:24:08 --> Model Class Initialized
INFO - 2023-05-08 15:24:08 --> Model Class Initialized
INFO - 2023-05-08 15:24:08 --> Model Class Initialized
INFO - 2023-05-08 15:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:24:08 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:08 --> Total execution time: 0.0776
ERROR - 2023-05-08 15:24:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:09 --> Config Class Initialized
INFO - 2023-05-08 15:24:09 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:09 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:09 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:09 --> URI Class Initialized
INFO - 2023-05-08 15:24:09 --> Router Class Initialized
INFO - 2023-05-08 15:24:09 --> Output Class Initialized
INFO - 2023-05-08 15:24:09 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:09 --> Input Class Initialized
INFO - 2023-05-08 15:24:09 --> Language Class Initialized
INFO - 2023-05-08 15:24:09 --> Loader Class Initialized
INFO - 2023-05-08 15:24:09 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:09 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:09 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:09 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:09 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:09 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:09 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:09 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:09 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:09 --> Parser Class Initialized
INFO - 2023-05-08 15:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:09 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:09 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:09 --> Controller Class Initialized
INFO - 2023-05-08 15:24:09 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:09 --> Model Class Initialized
INFO - 2023-05-08 15:24:09 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:09 --> Total execution time: 0.0290
ERROR - 2023-05-08 15:24:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:12 --> Config Class Initialized
INFO - 2023-05-08 15:24:12 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:12 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:12 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:12 --> URI Class Initialized
INFO - 2023-05-08 15:24:12 --> Router Class Initialized
INFO - 2023-05-08 15:24:12 --> Output Class Initialized
INFO - 2023-05-08 15:24:12 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:12 --> Input Class Initialized
INFO - 2023-05-08 15:24:12 --> Language Class Initialized
INFO - 2023-05-08 15:24:12 --> Loader Class Initialized
INFO - 2023-05-08 15:24:12 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:12 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:12 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:12 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:12 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:12 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:12 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:12 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:12 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:12 --> Parser Class Initialized
INFO - 2023-05-08 15:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:12 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:12 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:12 --> Controller Class Initialized
INFO - 2023-05-08 15:24:12 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:12 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-08 15:24:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:24:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:24:12 --> Model Class Initialized
INFO - 2023-05-08 15:24:12 --> Model Class Initialized
INFO - 2023-05-08 15:24:12 --> Model Class Initialized
INFO - 2023-05-08 15:24:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:24:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:24:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:24:12 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:12 --> Total execution time: 0.0714
ERROR - 2023-05-08 15:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:20 --> Config Class Initialized
INFO - 2023-05-08 15:24:20 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:20 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:20 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:20 --> URI Class Initialized
INFO - 2023-05-08 15:24:20 --> Router Class Initialized
INFO - 2023-05-08 15:24:20 --> Output Class Initialized
INFO - 2023-05-08 15:24:20 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:20 --> Input Class Initialized
INFO - 2023-05-08 15:24:20 --> Language Class Initialized
INFO - 2023-05-08 15:24:20 --> Loader Class Initialized
INFO - 2023-05-08 15:24:20 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:20 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:20 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:20 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:20 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:20 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:20 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:20 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:20 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:20 --> Parser Class Initialized
INFO - 2023-05-08 15:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:20 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:20 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:20 --> Controller Class Initialized
INFO - 2023-05-08 15:24:20 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:20 --> Model Class Initialized
INFO - 2023-05-08 15:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-08 15:24:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:24:20 --> Model Class Initialized
INFO - 2023-05-08 15:24:20 --> Model Class Initialized
INFO - 2023-05-08 15:24:20 --> Model Class Initialized
INFO - 2023-05-08 15:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:24:20 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:20 --> Total execution time: 0.0682
ERROR - 2023-05-08 15:24:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:21 --> Config Class Initialized
INFO - 2023-05-08 15:24:21 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:21 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:21 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:21 --> URI Class Initialized
INFO - 2023-05-08 15:24:21 --> Router Class Initialized
INFO - 2023-05-08 15:24:21 --> Output Class Initialized
INFO - 2023-05-08 15:24:21 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:21 --> Input Class Initialized
INFO - 2023-05-08 15:24:21 --> Language Class Initialized
INFO - 2023-05-08 15:24:21 --> Loader Class Initialized
INFO - 2023-05-08 15:24:21 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:21 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:21 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:21 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:21 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:21 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:21 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:21 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:21 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:21 --> Parser Class Initialized
INFO - 2023-05-08 15:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:21 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:21 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:21 --> Controller Class Initialized
INFO - 2023-05-08 15:24:21 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:21 --> Model Class Initialized
INFO - 2023-05-08 15:24:21 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:21 --> Total execution time: 0.0294
ERROR - 2023-05-08 15:24:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:24 --> Config Class Initialized
INFO - 2023-05-08 15:24:24 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:24 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:24 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:24 --> URI Class Initialized
INFO - 2023-05-08 15:24:24 --> Router Class Initialized
INFO - 2023-05-08 15:24:24 --> Output Class Initialized
INFO - 2023-05-08 15:24:24 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:24 --> Input Class Initialized
INFO - 2023-05-08 15:24:24 --> Language Class Initialized
INFO - 2023-05-08 15:24:24 --> Loader Class Initialized
INFO - 2023-05-08 15:24:24 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:24 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:24 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:24 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:24 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:24 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:24 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:24 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:24 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:24 --> Parser Class Initialized
INFO - 2023-05-08 15:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:24 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:24 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:24 --> Controller Class Initialized
INFO - 2023-05-08 15:24:24 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:24 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-08 15:24:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:24:24 --> Model Class Initialized
INFO - 2023-05-08 15:24:24 --> Model Class Initialized
INFO - 2023-05-08 15:24:24 --> Model Class Initialized
INFO - 2023-05-08 15:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:24:24 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:24 --> Total execution time: 0.0690
ERROR - 2023-05-08 15:24:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:28 --> Config Class Initialized
INFO - 2023-05-08 15:24:28 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:28 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:28 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:28 --> URI Class Initialized
INFO - 2023-05-08 15:24:28 --> Router Class Initialized
INFO - 2023-05-08 15:24:28 --> Output Class Initialized
INFO - 2023-05-08 15:24:28 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:28 --> Input Class Initialized
INFO - 2023-05-08 15:24:28 --> Language Class Initialized
INFO - 2023-05-08 15:24:28 --> Loader Class Initialized
INFO - 2023-05-08 15:24:28 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:28 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:28 --> Parser Class Initialized
INFO - 2023-05-08 15:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:28 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:28 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:28 --> Controller Class Initialized
INFO - 2023-05-08 15:24:28 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:28 --> Model Class Initialized
INFO - 2023-05-08 15:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-08 15:24:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:24:28 --> Model Class Initialized
INFO - 2023-05-08 15:24:28 --> Model Class Initialized
INFO - 2023-05-08 15:24:28 --> Model Class Initialized
INFO - 2023-05-08 15:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:24:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:24:28 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:28 --> Total execution time: 0.0812
ERROR - 2023-05-08 15:24:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:28 --> Config Class Initialized
INFO - 2023-05-08 15:24:28 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:28 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:28 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:28 --> URI Class Initialized
INFO - 2023-05-08 15:24:28 --> Router Class Initialized
INFO - 2023-05-08 15:24:28 --> Output Class Initialized
INFO - 2023-05-08 15:24:28 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:28 --> Input Class Initialized
INFO - 2023-05-08 15:24:28 --> Language Class Initialized
INFO - 2023-05-08 15:24:28 --> Loader Class Initialized
INFO - 2023-05-08 15:24:28 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:28 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:28 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:28 --> Parser Class Initialized
INFO - 2023-05-08 15:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:28 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:28 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:28 --> Controller Class Initialized
INFO - 2023-05-08 15:24:28 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:28 --> Model Class Initialized
INFO - 2023-05-08 15:24:28 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:28 --> Total execution time: 0.0272
ERROR - 2023-05-08 15:24:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:33 --> Config Class Initialized
INFO - 2023-05-08 15:24:33 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:33 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:33 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:33 --> URI Class Initialized
INFO - 2023-05-08 15:24:33 --> Router Class Initialized
INFO - 2023-05-08 15:24:33 --> Output Class Initialized
INFO - 2023-05-08 15:24:33 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:33 --> Input Class Initialized
INFO - 2023-05-08 15:24:33 --> Language Class Initialized
INFO - 2023-05-08 15:24:33 --> Loader Class Initialized
INFO - 2023-05-08 15:24:33 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:33 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:33 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:33 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:33 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:33 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:33 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:33 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:33 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:33 --> Parser Class Initialized
INFO - 2023-05-08 15:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:33 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:33 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:33 --> Controller Class Initialized
INFO - 2023-05-08 15:24:33 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:33 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-08 15:24:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:24:33 --> Model Class Initialized
INFO - 2023-05-08 15:24:33 --> Model Class Initialized
INFO - 2023-05-08 15:24:33 --> Model Class Initialized
INFO - 2023-05-08 15:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:24:33 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:33 --> Total execution time: 0.0664
ERROR - 2023-05-08 15:24:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:49 --> Config Class Initialized
INFO - 2023-05-08 15:24:49 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:49 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:49 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:49 --> URI Class Initialized
INFO - 2023-05-08 15:24:49 --> Router Class Initialized
INFO - 2023-05-08 15:24:49 --> Output Class Initialized
INFO - 2023-05-08 15:24:49 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:49 --> Input Class Initialized
INFO - 2023-05-08 15:24:49 --> Language Class Initialized
INFO - 2023-05-08 15:24:49 --> Loader Class Initialized
INFO - 2023-05-08 15:24:49 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:49 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:49 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:49 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:49 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:49 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:49 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:49 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:49 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:49 --> Parser Class Initialized
INFO - 2023-05-08 15:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:49 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:49 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:49 --> Controller Class Initialized
INFO - 2023-05-08 15:24:49 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:49 --> Model Class Initialized
INFO - 2023-05-08 15:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-08 15:24:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:24:49 --> Model Class Initialized
INFO - 2023-05-08 15:24:49 --> Model Class Initialized
INFO - 2023-05-08 15:24:49 --> Model Class Initialized
INFO - 2023-05-08 15:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:24:49 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:49 --> Total execution time: 0.0601
ERROR - 2023-05-08 15:24:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:50 --> Config Class Initialized
INFO - 2023-05-08 15:24:50 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:50 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:50 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:50 --> URI Class Initialized
INFO - 2023-05-08 15:24:50 --> Router Class Initialized
INFO - 2023-05-08 15:24:50 --> Output Class Initialized
INFO - 2023-05-08 15:24:50 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:50 --> Input Class Initialized
INFO - 2023-05-08 15:24:50 --> Language Class Initialized
INFO - 2023-05-08 15:24:50 --> Loader Class Initialized
INFO - 2023-05-08 15:24:50 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:50 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:50 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:50 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:50 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:50 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:50 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:50 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:50 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:50 --> Parser Class Initialized
INFO - 2023-05-08 15:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:50 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:50 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:50 --> Controller Class Initialized
INFO - 2023-05-08 15:24:50 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:50 --> Model Class Initialized
INFO - 2023-05-08 15:24:50 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:50 --> Total execution time: 0.0190
ERROR - 2023-05-08 15:24:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:24:58 --> Config Class Initialized
INFO - 2023-05-08 15:24:58 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:24:58 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:24:58 --> Utf8 Class Initialized
INFO - 2023-05-08 15:24:58 --> URI Class Initialized
INFO - 2023-05-08 15:24:58 --> Router Class Initialized
INFO - 2023-05-08 15:24:58 --> Output Class Initialized
INFO - 2023-05-08 15:24:58 --> Security Class Initialized
DEBUG - 2023-05-08 15:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:24:58 --> Input Class Initialized
INFO - 2023-05-08 15:24:58 --> Language Class Initialized
INFO - 2023-05-08 15:24:58 --> Loader Class Initialized
INFO - 2023-05-08 15:24:58 --> Helper loaded: url_helper
INFO - 2023-05-08 15:24:58 --> Helper loaded: file_helper
INFO - 2023-05-08 15:24:58 --> Helper loaded: html_helper
INFO - 2023-05-08 15:24:58 --> Helper loaded: text_helper
INFO - 2023-05-08 15:24:58 --> Helper loaded: form_helper
INFO - 2023-05-08 15:24:58 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:24:58 --> Helper loaded: security_helper
INFO - 2023-05-08 15:24:58 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:24:58 --> Database Driver Class Initialized
INFO - 2023-05-08 15:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:24:58 --> Parser Class Initialized
INFO - 2023-05-08 15:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:24:58 --> Pagination Class Initialized
INFO - 2023-05-08 15:24:58 --> Form Validation Class Initialized
INFO - 2023-05-08 15:24:58 --> Controller Class Initialized
INFO - 2023-05-08 15:24:58 --> Model Class Initialized
DEBUG - 2023-05-08 15:24:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:24:58 --> Model Class Initialized
INFO - 2023-05-08 15:24:58 --> Final output sent to browser
DEBUG - 2023-05-08 15:24:58 --> Total execution time: 0.0215
ERROR - 2023-05-08 15:25:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:25:06 --> Config Class Initialized
INFO - 2023-05-08 15:25:06 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:25:06 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:25:06 --> Utf8 Class Initialized
INFO - 2023-05-08 15:25:06 --> URI Class Initialized
DEBUG - 2023-05-08 15:25:06 --> No URI present. Default controller set.
INFO - 2023-05-08 15:25:06 --> Router Class Initialized
INFO - 2023-05-08 15:25:06 --> Output Class Initialized
INFO - 2023-05-08 15:25:06 --> Security Class Initialized
DEBUG - 2023-05-08 15:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:25:06 --> Input Class Initialized
INFO - 2023-05-08 15:25:06 --> Language Class Initialized
INFO - 2023-05-08 15:25:06 --> Loader Class Initialized
INFO - 2023-05-08 15:25:06 --> Helper loaded: url_helper
INFO - 2023-05-08 15:25:06 --> Helper loaded: file_helper
INFO - 2023-05-08 15:25:06 --> Helper loaded: html_helper
INFO - 2023-05-08 15:25:06 --> Helper loaded: text_helper
INFO - 2023-05-08 15:25:06 --> Helper loaded: form_helper
INFO - 2023-05-08 15:25:06 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:25:06 --> Helper loaded: security_helper
INFO - 2023-05-08 15:25:06 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:25:06 --> Database Driver Class Initialized
INFO - 2023-05-08 15:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:25:06 --> Parser Class Initialized
INFO - 2023-05-08 15:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:25:06 --> Pagination Class Initialized
INFO - 2023-05-08 15:25:06 --> Form Validation Class Initialized
INFO - 2023-05-08 15:25:06 --> Controller Class Initialized
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
DEBUG - 2023-05-08 15:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
DEBUG - 2023-05-08 15:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
DEBUG - 2023-05-08 15:25:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
INFO - 2023-05-08 15:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 15:25:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:25:06 --> Model Class Initialized
INFO - 2023-05-08 15:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:25:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:25:06 --> Final output sent to browser
DEBUG - 2023-05-08 15:25:06 --> Total execution time: 0.0750
ERROR - 2023-05-08 15:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:25:16 --> Config Class Initialized
INFO - 2023-05-08 15:25:16 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:25:16 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:25:16 --> Utf8 Class Initialized
INFO - 2023-05-08 15:25:16 --> URI Class Initialized
INFO - 2023-05-08 15:25:16 --> Router Class Initialized
INFO - 2023-05-08 15:25:16 --> Output Class Initialized
INFO - 2023-05-08 15:25:16 --> Security Class Initialized
DEBUG - 2023-05-08 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:25:16 --> Input Class Initialized
INFO - 2023-05-08 15:25:16 --> Language Class Initialized
INFO - 2023-05-08 15:25:16 --> Loader Class Initialized
INFO - 2023-05-08 15:25:16 --> Helper loaded: url_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: file_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: html_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: text_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: form_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: security_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:25:16 --> Database Driver Class Initialized
INFO - 2023-05-08 15:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:25:16 --> Parser Class Initialized
INFO - 2023-05-08 15:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:25:16 --> Pagination Class Initialized
INFO - 2023-05-08 15:25:16 --> Form Validation Class Initialized
INFO - 2023-05-08 15:25:16 --> Controller Class Initialized
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
DEBUG - 2023-05-08 15:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
DEBUG - 2023-05-08 15:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
INFO - 2023-05-08 15:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-08 15:25:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
INFO - 2023-05-08 15:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:25:16 --> Final output sent to browser
DEBUG - 2023-05-08 15:25:16 --> Total execution time: 0.0650
ERROR - 2023-05-08 15:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:25:16 --> Config Class Initialized
INFO - 2023-05-08 15:25:16 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:25:16 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:25:16 --> Utf8 Class Initialized
INFO - 2023-05-08 15:25:16 --> URI Class Initialized
INFO - 2023-05-08 15:25:16 --> Router Class Initialized
INFO - 2023-05-08 15:25:16 --> Output Class Initialized
INFO - 2023-05-08 15:25:16 --> Security Class Initialized
DEBUG - 2023-05-08 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:25:16 --> Input Class Initialized
INFO - 2023-05-08 15:25:16 --> Language Class Initialized
INFO - 2023-05-08 15:25:16 --> Loader Class Initialized
INFO - 2023-05-08 15:25:16 --> Helper loaded: url_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: file_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: html_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: text_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: form_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: security_helper
INFO - 2023-05-08 15:25:16 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:25:16 --> Database Driver Class Initialized
INFO - 2023-05-08 15:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:25:16 --> Parser Class Initialized
INFO - 2023-05-08 15:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:25:16 --> Pagination Class Initialized
INFO - 2023-05-08 15:25:16 --> Form Validation Class Initialized
INFO - 2023-05-08 15:25:16 --> Controller Class Initialized
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
DEBUG - 2023-05-08 15:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
DEBUG - 2023-05-08 15:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:25:16 --> Model Class Initialized
INFO - 2023-05-08 15:25:17 --> Final output sent to browser
DEBUG - 2023-05-08 15:25:17 --> Total execution time: 0.0346
ERROR - 2023-05-08 15:26:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:26:18 --> Config Class Initialized
INFO - 2023-05-08 15:26:18 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:26:18 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:26:18 --> Utf8 Class Initialized
INFO - 2023-05-08 15:26:18 --> URI Class Initialized
DEBUG - 2023-05-08 15:26:18 --> No URI present. Default controller set.
INFO - 2023-05-08 15:26:18 --> Router Class Initialized
INFO - 2023-05-08 15:26:18 --> Output Class Initialized
INFO - 2023-05-08 15:26:18 --> Security Class Initialized
DEBUG - 2023-05-08 15:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:26:18 --> Input Class Initialized
INFO - 2023-05-08 15:26:18 --> Language Class Initialized
INFO - 2023-05-08 15:26:18 --> Loader Class Initialized
INFO - 2023-05-08 15:26:18 --> Helper loaded: url_helper
INFO - 2023-05-08 15:26:18 --> Helper loaded: file_helper
INFO - 2023-05-08 15:26:18 --> Helper loaded: html_helper
INFO - 2023-05-08 15:26:18 --> Helper loaded: text_helper
INFO - 2023-05-08 15:26:18 --> Helper loaded: form_helper
INFO - 2023-05-08 15:26:18 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:26:18 --> Helper loaded: security_helper
INFO - 2023-05-08 15:26:18 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:26:18 --> Database Driver Class Initialized
INFO - 2023-05-08 15:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:26:18 --> Parser Class Initialized
INFO - 2023-05-08 15:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:26:18 --> Pagination Class Initialized
INFO - 2023-05-08 15:26:18 --> Form Validation Class Initialized
INFO - 2023-05-08 15:26:18 --> Controller Class Initialized
INFO - 2023-05-08 15:26:18 --> Model Class Initialized
DEBUG - 2023-05-08 15:26:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-08 15:26:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:26:19 --> Config Class Initialized
INFO - 2023-05-08 15:26:19 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:26:19 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:26:19 --> Utf8 Class Initialized
INFO - 2023-05-08 15:26:19 --> URI Class Initialized
INFO - 2023-05-08 15:26:19 --> Router Class Initialized
INFO - 2023-05-08 15:26:19 --> Output Class Initialized
INFO - 2023-05-08 15:26:19 --> Security Class Initialized
DEBUG - 2023-05-08 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:26:19 --> Input Class Initialized
INFO - 2023-05-08 15:26:19 --> Language Class Initialized
INFO - 2023-05-08 15:26:19 --> Loader Class Initialized
INFO - 2023-05-08 15:26:19 --> Helper loaded: url_helper
INFO - 2023-05-08 15:26:19 --> Helper loaded: file_helper
INFO - 2023-05-08 15:26:19 --> Helper loaded: html_helper
INFO - 2023-05-08 15:26:19 --> Helper loaded: text_helper
INFO - 2023-05-08 15:26:19 --> Helper loaded: form_helper
INFO - 2023-05-08 15:26:19 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:26:19 --> Helper loaded: security_helper
INFO - 2023-05-08 15:26:19 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:26:19 --> Database Driver Class Initialized
INFO - 2023-05-08 15:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:26:19 --> Parser Class Initialized
INFO - 2023-05-08 15:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:26:19 --> Pagination Class Initialized
INFO - 2023-05-08 15:26:19 --> Form Validation Class Initialized
INFO - 2023-05-08 15:26:19 --> Controller Class Initialized
INFO - 2023-05-08 15:26:19 --> Model Class Initialized
DEBUG - 2023-05-08 15:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-08 15:26:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:26:19 --> Model Class Initialized
INFO - 2023-05-08 15:26:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:26:19 --> Final output sent to browser
DEBUG - 2023-05-08 15:26:19 --> Total execution time: 0.0289
ERROR - 2023-05-08 15:26:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:26:51 --> Config Class Initialized
INFO - 2023-05-08 15:26:51 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:26:51 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:26:51 --> Utf8 Class Initialized
INFO - 2023-05-08 15:26:51 --> URI Class Initialized
INFO - 2023-05-08 15:26:51 --> Router Class Initialized
INFO - 2023-05-08 15:26:51 --> Output Class Initialized
INFO - 2023-05-08 15:26:51 --> Security Class Initialized
DEBUG - 2023-05-08 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:26:51 --> Input Class Initialized
INFO - 2023-05-08 15:26:51 --> Language Class Initialized
INFO - 2023-05-08 15:26:51 --> Loader Class Initialized
INFO - 2023-05-08 15:26:51 --> Helper loaded: url_helper
INFO - 2023-05-08 15:26:51 --> Helper loaded: file_helper
INFO - 2023-05-08 15:26:51 --> Helper loaded: html_helper
INFO - 2023-05-08 15:26:51 --> Helper loaded: text_helper
INFO - 2023-05-08 15:26:51 --> Helper loaded: form_helper
INFO - 2023-05-08 15:26:51 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:26:51 --> Helper loaded: security_helper
INFO - 2023-05-08 15:26:51 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:26:51 --> Database Driver Class Initialized
INFO - 2023-05-08 15:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:26:51 --> Parser Class Initialized
INFO - 2023-05-08 15:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:26:51 --> Pagination Class Initialized
INFO - 2023-05-08 15:26:51 --> Form Validation Class Initialized
INFO - 2023-05-08 15:26:51 --> Controller Class Initialized
INFO - 2023-05-08 15:26:51 --> Model Class Initialized
DEBUG - 2023-05-08 15:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:51 --> Model Class Initialized
INFO - 2023-05-08 15:26:51 --> Final output sent to browser
DEBUG - 2023-05-08 15:26:51 --> Total execution time: 0.0216
ERROR - 2023-05-08 15:26:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:26:52 --> Config Class Initialized
INFO - 2023-05-08 15:26:52 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:26:52 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:26:52 --> Utf8 Class Initialized
INFO - 2023-05-08 15:26:52 --> URI Class Initialized
DEBUG - 2023-05-08 15:26:52 --> No URI present. Default controller set.
INFO - 2023-05-08 15:26:52 --> Router Class Initialized
INFO - 2023-05-08 15:26:52 --> Output Class Initialized
INFO - 2023-05-08 15:26:52 --> Security Class Initialized
DEBUG - 2023-05-08 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:26:52 --> Input Class Initialized
INFO - 2023-05-08 15:26:52 --> Language Class Initialized
INFO - 2023-05-08 15:26:52 --> Loader Class Initialized
INFO - 2023-05-08 15:26:52 --> Helper loaded: url_helper
INFO - 2023-05-08 15:26:52 --> Helper loaded: file_helper
INFO - 2023-05-08 15:26:52 --> Helper loaded: html_helper
INFO - 2023-05-08 15:26:52 --> Helper loaded: text_helper
INFO - 2023-05-08 15:26:52 --> Helper loaded: form_helper
INFO - 2023-05-08 15:26:52 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:26:52 --> Helper loaded: security_helper
INFO - 2023-05-08 15:26:52 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:26:52 --> Database Driver Class Initialized
INFO - 2023-05-08 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:26:52 --> Parser Class Initialized
INFO - 2023-05-08 15:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:26:52 --> Pagination Class Initialized
INFO - 2023-05-08 15:26:52 --> Form Validation Class Initialized
INFO - 2023-05-08 15:26:52 --> Controller Class Initialized
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
DEBUG - 2023-05-08 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
DEBUG - 2023-05-08 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
DEBUG - 2023-05-08 15:26:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
INFO - 2023-05-08 15:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 15:26:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:26:52 --> Model Class Initialized
INFO - 2023-05-08 15:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:26:52 --> Final output sent to browser
DEBUG - 2023-05-08 15:26:52 --> Total execution time: 0.1654
ERROR - 2023-05-08 15:26:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:26:53 --> Config Class Initialized
INFO - 2023-05-08 15:26:53 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:26:53 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:26:53 --> Utf8 Class Initialized
INFO - 2023-05-08 15:26:53 --> URI Class Initialized
INFO - 2023-05-08 15:26:53 --> Router Class Initialized
INFO - 2023-05-08 15:26:53 --> Output Class Initialized
INFO - 2023-05-08 15:26:53 --> Security Class Initialized
DEBUG - 2023-05-08 15:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:26:53 --> Input Class Initialized
INFO - 2023-05-08 15:26:53 --> Language Class Initialized
INFO - 2023-05-08 15:26:53 --> Loader Class Initialized
INFO - 2023-05-08 15:26:53 --> Helper loaded: url_helper
INFO - 2023-05-08 15:26:53 --> Helper loaded: file_helper
INFO - 2023-05-08 15:26:53 --> Helper loaded: html_helper
INFO - 2023-05-08 15:26:53 --> Helper loaded: text_helper
INFO - 2023-05-08 15:26:53 --> Helper loaded: form_helper
INFO - 2023-05-08 15:26:53 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:26:53 --> Helper loaded: security_helper
INFO - 2023-05-08 15:26:53 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:26:53 --> Database Driver Class Initialized
INFO - 2023-05-08 15:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:26:53 --> Parser Class Initialized
INFO - 2023-05-08 15:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:26:53 --> Pagination Class Initialized
INFO - 2023-05-08 15:26:53 --> Form Validation Class Initialized
INFO - 2023-05-08 15:26:53 --> Controller Class Initialized
DEBUG - 2023-05-08 15:26:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:26:53 --> Model Class Initialized
INFO - 2023-05-08 15:26:53 --> Final output sent to browser
DEBUG - 2023-05-08 15:26:53 --> Total execution time: 0.0146
ERROR - 2023-05-08 15:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:03 --> Config Class Initialized
INFO - 2023-05-08 15:27:03 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:03 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:03 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:03 --> URI Class Initialized
INFO - 2023-05-08 15:27:03 --> Router Class Initialized
INFO - 2023-05-08 15:27:03 --> Output Class Initialized
INFO - 2023-05-08 15:27:03 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:03 --> Input Class Initialized
INFO - 2023-05-08 15:27:03 --> Language Class Initialized
INFO - 2023-05-08 15:27:03 --> Loader Class Initialized
INFO - 2023-05-08 15:27:03 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:03 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:03 --> Parser Class Initialized
INFO - 2023-05-08 15:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:03 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:03 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:03 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:03 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
INFO - 2023-05-08 15:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-08 15:27:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
INFO - 2023-05-08 15:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:27:03 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:03 --> Total execution time: 0.1494
ERROR - 2023-05-08 15:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:03 --> Config Class Initialized
INFO - 2023-05-08 15:27:03 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:03 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:03 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:03 --> URI Class Initialized
INFO - 2023-05-08 15:27:03 --> Router Class Initialized
INFO - 2023-05-08 15:27:03 --> Output Class Initialized
INFO - 2023-05-08 15:27:03 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:03 --> Input Class Initialized
INFO - 2023-05-08 15:27:03 --> Language Class Initialized
INFO - 2023-05-08 15:27:03 --> Loader Class Initialized
INFO - 2023-05-08 15:27:03 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:03 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:03 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:03 --> Parser Class Initialized
INFO - 2023-05-08 15:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:03 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:03 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:03 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:03 --> Model Class Initialized
INFO - 2023-05-08 15:27:03 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:03 --> Total execution time: 0.0294
ERROR - 2023-05-08 15:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:14 --> Config Class Initialized
INFO - 2023-05-08 15:27:14 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:14 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:14 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:14 --> URI Class Initialized
INFO - 2023-05-08 15:27:14 --> Router Class Initialized
INFO - 2023-05-08 15:27:14 --> Output Class Initialized
INFO - 2023-05-08 15:27:14 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:14 --> Input Class Initialized
INFO - 2023-05-08 15:27:14 --> Language Class Initialized
INFO - 2023-05-08 15:27:14 --> Loader Class Initialized
INFO - 2023-05-08 15:27:14 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:14 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:14 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:14 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:14 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:14 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:14 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:14 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:14 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:14 --> Parser Class Initialized
INFO - 2023-05-08 15:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:14 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:14 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:14 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:14 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:14 --> Model Class Initialized
INFO - 2023-05-08 15:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-05-08 15:27:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:27:14 --> Model Class Initialized
INFO - 2023-05-08 15:27:14 --> Model Class Initialized
INFO - 2023-05-08 15:27:14 --> Model Class Initialized
INFO - 2023-05-08 15:27:14 --> Model Class Initialized
INFO - 2023-05-08 15:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:27:14 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:14 --> Total execution time: 0.1300
ERROR - 2023-05-08 15:27:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:29 --> Config Class Initialized
INFO - 2023-05-08 15:27:29 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:29 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:29 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:29 --> URI Class Initialized
INFO - 2023-05-08 15:27:29 --> Router Class Initialized
INFO - 2023-05-08 15:27:29 --> Output Class Initialized
INFO - 2023-05-08 15:27:29 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:29 --> Input Class Initialized
INFO - 2023-05-08 15:27:29 --> Language Class Initialized
INFO - 2023-05-08 15:27:29 --> Loader Class Initialized
INFO - 2023-05-08 15:27:29 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:29 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:29 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:29 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:29 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:29 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:29 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:29 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:29 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:29 --> Parser Class Initialized
INFO - 2023-05-08 15:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:29 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:29 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:29 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:29 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:29 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:29 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:29 --> Model Class Initialized
INFO - 2023-05-08 15:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-08 15:27:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:27:29 --> Model Class Initialized
INFO - 2023-05-08 15:27:29 --> Model Class Initialized
INFO - 2023-05-08 15:27:29 --> Model Class Initialized
INFO - 2023-05-08 15:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:27:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:27:29 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:29 --> Total execution time: 0.1199
ERROR - 2023-05-08 15:27:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:30 --> Config Class Initialized
INFO - 2023-05-08 15:27:30 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:30 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:30 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:30 --> URI Class Initialized
INFO - 2023-05-08 15:27:30 --> Router Class Initialized
INFO - 2023-05-08 15:27:30 --> Output Class Initialized
INFO - 2023-05-08 15:27:30 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:30 --> Input Class Initialized
INFO - 2023-05-08 15:27:30 --> Language Class Initialized
INFO - 2023-05-08 15:27:30 --> Loader Class Initialized
INFO - 2023-05-08 15:27:30 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:30 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:30 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:30 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:30 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:30 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:30 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:30 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:30 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:30 --> Parser Class Initialized
INFO - 2023-05-08 15:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:30 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:30 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:30 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:30 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:30 --> Model Class Initialized
INFO - 2023-05-08 15:27:30 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:30 --> Total execution time: 0.0295
ERROR - 2023-05-08 15:27:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:38 --> Config Class Initialized
INFO - 2023-05-08 15:27:38 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:38 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:38 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:38 --> URI Class Initialized
INFO - 2023-05-08 15:27:38 --> Router Class Initialized
INFO - 2023-05-08 15:27:38 --> Output Class Initialized
INFO - 2023-05-08 15:27:38 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:38 --> Input Class Initialized
INFO - 2023-05-08 15:27:38 --> Language Class Initialized
INFO - 2023-05-08 15:27:38 --> Loader Class Initialized
INFO - 2023-05-08 15:27:38 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:38 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:38 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:38 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:38 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:38 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:38 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:38 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:38 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:38 --> Parser Class Initialized
INFO - 2023-05-08 15:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:38 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:38 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:38 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:38 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:38 --> Model Class Initialized
INFO - 2023-05-08 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-05-08 15:27:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:27:38 --> Model Class Initialized
INFO - 2023-05-08 15:27:38 --> Model Class Initialized
INFO - 2023-05-08 15:27:38 --> Model Class Initialized
INFO - 2023-05-08 15:27:38 --> Model Class Initialized
INFO - 2023-05-08 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:27:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:27:38 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:38 --> Total execution time: 0.1601
ERROR - 2023-05-08 15:27:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:46 --> Config Class Initialized
INFO - 2023-05-08 15:27:46 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:46 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:46 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:46 --> URI Class Initialized
INFO - 2023-05-08 15:27:46 --> Router Class Initialized
INFO - 2023-05-08 15:27:46 --> Output Class Initialized
INFO - 2023-05-08 15:27:46 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:46 --> Input Class Initialized
INFO - 2023-05-08 15:27:46 --> Language Class Initialized
INFO - 2023-05-08 15:27:46 --> Loader Class Initialized
INFO - 2023-05-08 15:27:46 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:46 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:46 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:46 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:46 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:46 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:46 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:46 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:46 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:46 --> Parser Class Initialized
INFO - 2023-05-08 15:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:46 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:46 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:46 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:46 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:46 --> Model Class Initialized
ERROR - 2023-05-08 15:27:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:47 --> Config Class Initialized
INFO - 2023-05-08 15:27:47 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:47 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:47 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:47 --> URI Class Initialized
INFO - 2023-05-08 15:27:47 --> Router Class Initialized
INFO - 2023-05-08 15:27:47 --> Output Class Initialized
INFO - 2023-05-08 15:27:47 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:47 --> Input Class Initialized
INFO - 2023-05-08 15:27:47 --> Language Class Initialized
INFO - 2023-05-08 15:27:47 --> Loader Class Initialized
INFO - 2023-05-08 15:27:47 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:47 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:47 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:47 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:47 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:47 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:47 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:47 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:47 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:47 --> Parser Class Initialized
INFO - 2023-05-08 15:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:47 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:47 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:47 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:47 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:47 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:47 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:47 --> Model Class Initialized
INFO - 2023-05-08 15:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-08 15:27:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:27:47 --> Model Class Initialized
INFO - 2023-05-08 15:27:47 --> Model Class Initialized
INFO - 2023-05-08 15:27:47 --> Model Class Initialized
INFO - 2023-05-08 15:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:27:47 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:47 --> Total execution time: 0.1371
ERROR - 2023-05-08 15:27:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:48 --> Config Class Initialized
INFO - 2023-05-08 15:27:48 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:48 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:48 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:48 --> URI Class Initialized
INFO - 2023-05-08 15:27:48 --> Router Class Initialized
INFO - 2023-05-08 15:27:48 --> Output Class Initialized
INFO - 2023-05-08 15:27:48 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:48 --> Input Class Initialized
INFO - 2023-05-08 15:27:48 --> Language Class Initialized
INFO - 2023-05-08 15:27:48 --> Loader Class Initialized
INFO - 2023-05-08 15:27:48 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:48 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:48 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:48 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:48 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:48 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:48 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:48 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:48 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:48 --> Parser Class Initialized
INFO - 2023-05-08 15:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:48 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:48 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:48 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:48 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:48 --> Model Class Initialized
INFO - 2023-05-08 15:27:48 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:48 --> Total execution time: 0.0279
ERROR - 2023-05-08 15:27:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:53 --> Config Class Initialized
INFO - 2023-05-08 15:27:53 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:53 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:53 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:53 --> URI Class Initialized
INFO - 2023-05-08 15:27:53 --> Router Class Initialized
INFO - 2023-05-08 15:27:53 --> Output Class Initialized
INFO - 2023-05-08 15:27:53 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:53 --> Input Class Initialized
INFO - 2023-05-08 15:27:53 --> Language Class Initialized
INFO - 2023-05-08 15:27:53 --> Loader Class Initialized
INFO - 2023-05-08 15:27:53 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:53 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:53 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:53 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:53 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:53 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:53 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:53 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:53 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:53 --> Parser Class Initialized
INFO - 2023-05-08 15:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:53 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:53 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:53 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:53 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:53 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:53 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:53 --> Model Class Initialized
INFO - 2023-05-08 15:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-08 15:27:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 15:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 15:27:53 --> Model Class Initialized
INFO - 2023-05-08 15:27:53 --> Model Class Initialized
INFO - 2023-05-08 15:27:53 --> Model Class Initialized
INFO - 2023-05-08 15:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 15:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 15:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 15:27:53 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:53 --> Total execution time: 0.1374
ERROR - 2023-05-08 15:27:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 15:27:54 --> Config Class Initialized
INFO - 2023-05-08 15:27:54 --> Hooks Class Initialized
DEBUG - 2023-05-08 15:27:54 --> UTF-8 Support Enabled
INFO - 2023-05-08 15:27:54 --> Utf8 Class Initialized
INFO - 2023-05-08 15:27:54 --> URI Class Initialized
INFO - 2023-05-08 15:27:54 --> Router Class Initialized
INFO - 2023-05-08 15:27:54 --> Output Class Initialized
INFO - 2023-05-08 15:27:54 --> Security Class Initialized
DEBUG - 2023-05-08 15:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 15:27:54 --> Input Class Initialized
INFO - 2023-05-08 15:27:54 --> Language Class Initialized
INFO - 2023-05-08 15:27:54 --> Loader Class Initialized
INFO - 2023-05-08 15:27:54 --> Helper loaded: url_helper
INFO - 2023-05-08 15:27:54 --> Helper loaded: file_helper
INFO - 2023-05-08 15:27:54 --> Helper loaded: html_helper
INFO - 2023-05-08 15:27:54 --> Helper loaded: text_helper
INFO - 2023-05-08 15:27:54 --> Helper loaded: form_helper
INFO - 2023-05-08 15:27:54 --> Helper loaded: lang_helper
INFO - 2023-05-08 15:27:54 --> Helper loaded: security_helper
INFO - 2023-05-08 15:27:54 --> Helper loaded: cookie_helper
INFO - 2023-05-08 15:27:54 --> Database Driver Class Initialized
INFO - 2023-05-08 15:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 15:27:54 --> Parser Class Initialized
INFO - 2023-05-08 15:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 15:27:54 --> Pagination Class Initialized
INFO - 2023-05-08 15:27:54 --> Form Validation Class Initialized
INFO - 2023-05-08 15:27:54 --> Controller Class Initialized
DEBUG - 2023-05-08 15:27:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 15:27:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:54 --> Model Class Initialized
DEBUG - 2023-05-08 15:27:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 15:27:54 --> Model Class Initialized
INFO - 2023-05-08 15:27:54 --> Final output sent to browser
DEBUG - 2023-05-08 15:27:54 --> Total execution time: 0.0367
ERROR - 2023-05-08 16:09:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:09:35 --> Config Class Initialized
INFO - 2023-05-08 16:09:35 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:09:35 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:09:35 --> Utf8 Class Initialized
INFO - 2023-05-08 16:09:35 --> URI Class Initialized
DEBUG - 2023-05-08 16:09:35 --> No URI present. Default controller set.
INFO - 2023-05-08 16:09:35 --> Router Class Initialized
INFO - 2023-05-08 16:09:35 --> Output Class Initialized
INFO - 2023-05-08 16:09:35 --> Security Class Initialized
DEBUG - 2023-05-08 16:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:09:35 --> Input Class Initialized
INFO - 2023-05-08 16:09:35 --> Language Class Initialized
INFO - 2023-05-08 16:09:35 --> Loader Class Initialized
INFO - 2023-05-08 16:09:35 --> Helper loaded: url_helper
INFO - 2023-05-08 16:09:35 --> Helper loaded: file_helper
INFO - 2023-05-08 16:09:35 --> Helper loaded: html_helper
INFO - 2023-05-08 16:09:35 --> Helper loaded: text_helper
INFO - 2023-05-08 16:09:35 --> Helper loaded: form_helper
INFO - 2023-05-08 16:09:35 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:09:35 --> Helper loaded: security_helper
INFO - 2023-05-08 16:09:35 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:09:35 --> Database Driver Class Initialized
INFO - 2023-05-08 16:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:09:35 --> Parser Class Initialized
INFO - 2023-05-08 16:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:09:35 --> Pagination Class Initialized
INFO - 2023-05-08 16:09:35 --> Form Validation Class Initialized
INFO - 2023-05-08 16:09:35 --> Controller Class Initialized
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
DEBUG - 2023-05-08 16:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
DEBUG - 2023-05-08 16:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
DEBUG - 2023-05-08 16:09:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
INFO - 2023-05-08 16:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 16:09:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:09:35 --> Model Class Initialized
INFO - 2023-05-08 16:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:09:35 --> Final output sent to browser
DEBUG - 2023-05-08 16:09:35 --> Total execution time: 0.1635
ERROR - 2023-05-08 16:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:09:55 --> Config Class Initialized
INFO - 2023-05-08 16:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:09:55 --> Utf8 Class Initialized
INFO - 2023-05-08 16:09:55 --> URI Class Initialized
INFO - 2023-05-08 16:09:55 --> Router Class Initialized
INFO - 2023-05-08 16:09:55 --> Output Class Initialized
INFO - 2023-05-08 16:09:55 --> Security Class Initialized
DEBUG - 2023-05-08 16:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:09:55 --> Input Class Initialized
INFO - 2023-05-08 16:09:55 --> Language Class Initialized
INFO - 2023-05-08 16:09:55 --> Loader Class Initialized
INFO - 2023-05-08 16:09:55 --> Helper loaded: url_helper
INFO - 2023-05-08 16:09:55 --> Helper loaded: file_helper
INFO - 2023-05-08 16:09:55 --> Helper loaded: html_helper
INFO - 2023-05-08 16:09:55 --> Helper loaded: text_helper
INFO - 2023-05-08 16:09:55 --> Helper loaded: form_helper
INFO - 2023-05-08 16:09:55 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:09:55 --> Helper loaded: security_helper
INFO - 2023-05-08 16:09:55 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:09:55 --> Database Driver Class Initialized
INFO - 2023-05-08 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:09:55 --> Parser Class Initialized
INFO - 2023-05-08 16:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:09:55 --> Pagination Class Initialized
INFO - 2023-05-08 16:09:55 --> Form Validation Class Initialized
INFO - 2023-05-08 16:09:55 --> Controller Class Initialized
INFO - 2023-05-08 16:09:55 --> Model Class Initialized
DEBUG - 2023-05-08 16:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:09:55 --> Model Class Initialized
INFO - 2023-05-08 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-08 16:09:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:09:55 --> Model Class Initialized
INFO - 2023-05-08 16:09:55 --> Model Class Initialized
INFO - 2023-05-08 16:09:55 --> Model Class Initialized
INFO - 2023-05-08 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:09:55 --> Final output sent to browser
DEBUG - 2023-05-08 16:09:55 --> Total execution time: 0.1512
ERROR - 2023-05-08 16:09:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:09:57 --> Config Class Initialized
INFO - 2023-05-08 16:09:57 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:09:57 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:09:57 --> Utf8 Class Initialized
INFO - 2023-05-08 16:09:57 --> URI Class Initialized
INFO - 2023-05-08 16:09:57 --> Router Class Initialized
INFO - 2023-05-08 16:09:57 --> Output Class Initialized
INFO - 2023-05-08 16:09:57 --> Security Class Initialized
DEBUG - 2023-05-08 16:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:09:57 --> Input Class Initialized
INFO - 2023-05-08 16:09:57 --> Language Class Initialized
INFO - 2023-05-08 16:09:57 --> Loader Class Initialized
INFO - 2023-05-08 16:09:57 --> Helper loaded: url_helper
INFO - 2023-05-08 16:09:57 --> Helper loaded: file_helper
INFO - 2023-05-08 16:09:57 --> Helper loaded: html_helper
INFO - 2023-05-08 16:09:57 --> Helper loaded: text_helper
INFO - 2023-05-08 16:09:57 --> Helper loaded: form_helper
INFO - 2023-05-08 16:09:57 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:09:57 --> Helper loaded: security_helper
INFO - 2023-05-08 16:09:57 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:09:57 --> Database Driver Class Initialized
INFO - 2023-05-08 16:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:09:57 --> Parser Class Initialized
INFO - 2023-05-08 16:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:09:57 --> Pagination Class Initialized
INFO - 2023-05-08 16:09:57 --> Form Validation Class Initialized
INFO - 2023-05-08 16:09:57 --> Controller Class Initialized
INFO - 2023-05-08 16:09:57 --> Model Class Initialized
DEBUG - 2023-05-08 16:09:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:09:57 --> Model Class Initialized
INFO - 2023-05-08 16:09:57 --> Final output sent to browser
DEBUG - 2023-05-08 16:09:57 --> Total execution time: 0.0296
ERROR - 2023-05-08 16:10:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:04 --> Config Class Initialized
INFO - 2023-05-08 16:10:04 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:04 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:04 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:04 --> URI Class Initialized
INFO - 2023-05-08 16:10:04 --> Router Class Initialized
INFO - 2023-05-08 16:10:04 --> Output Class Initialized
INFO - 2023-05-08 16:10:04 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:04 --> Input Class Initialized
INFO - 2023-05-08 16:10:04 --> Language Class Initialized
INFO - 2023-05-08 16:10:04 --> Loader Class Initialized
INFO - 2023-05-08 16:10:04 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:04 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:04 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:04 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:04 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:04 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:04 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:04 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:04 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:04 --> Parser Class Initialized
INFO - 2023-05-08 16:10:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:04 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:04 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:04 --> Controller Class Initialized
INFO - 2023-05-08 16:10:04 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:04 --> Model Class Initialized
INFO - 2023-05-08 16:10:04 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:04 --> Total execution time: 0.0559
ERROR - 2023-05-08 16:10:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:10 --> Config Class Initialized
INFO - 2023-05-08 16:10:10 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:10 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:10 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:10 --> URI Class Initialized
INFO - 2023-05-08 16:10:10 --> Router Class Initialized
INFO - 2023-05-08 16:10:10 --> Output Class Initialized
INFO - 2023-05-08 16:10:10 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:10 --> Input Class Initialized
INFO - 2023-05-08 16:10:10 --> Language Class Initialized
INFO - 2023-05-08 16:10:10 --> Loader Class Initialized
INFO - 2023-05-08 16:10:10 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:10 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:10 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:10 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:10 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:10 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:10 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:10 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:10 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:10 --> Parser Class Initialized
INFO - 2023-05-08 16:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:10 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:10 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:10 --> Controller Class Initialized
INFO - 2023-05-08 16:10:10 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:10 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-08 16:10:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:10:10 --> Model Class Initialized
INFO - 2023-05-08 16:10:10 --> Model Class Initialized
INFO - 2023-05-08 16:10:10 --> Model Class Initialized
INFO - 2023-05-08 16:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:10:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:10:11 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:11 --> Total execution time: 0.1461
ERROR - 2023-05-08 16:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:16 --> Config Class Initialized
INFO - 2023-05-08 16:10:16 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:16 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:16 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:16 --> URI Class Initialized
INFO - 2023-05-08 16:10:16 --> Router Class Initialized
INFO - 2023-05-08 16:10:16 --> Output Class Initialized
INFO - 2023-05-08 16:10:16 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:16 --> Input Class Initialized
INFO - 2023-05-08 16:10:16 --> Language Class Initialized
INFO - 2023-05-08 16:10:16 --> Loader Class Initialized
INFO - 2023-05-08 16:10:16 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:16 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:16 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:16 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:16 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:16 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:16 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:16 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:16 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:16 --> Parser Class Initialized
INFO - 2023-05-08 16:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:16 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:16 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:16 --> Controller Class Initialized
INFO - 2023-05-08 16:10:16 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:16 --> Model Class Initialized
INFO - 2023-05-08 16:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-08 16:10:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:10:16 --> Model Class Initialized
INFO - 2023-05-08 16:10:16 --> Model Class Initialized
INFO - 2023-05-08 16:10:16 --> Model Class Initialized
INFO - 2023-05-08 16:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:10:16 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:16 --> Total execution time: 0.1315
ERROR - 2023-05-08 16:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:17 --> Config Class Initialized
INFO - 2023-05-08 16:10:17 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:17 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:17 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:17 --> URI Class Initialized
INFO - 2023-05-08 16:10:17 --> Router Class Initialized
INFO - 2023-05-08 16:10:17 --> Output Class Initialized
INFO - 2023-05-08 16:10:17 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:17 --> Input Class Initialized
INFO - 2023-05-08 16:10:17 --> Language Class Initialized
INFO - 2023-05-08 16:10:17 --> Loader Class Initialized
INFO - 2023-05-08 16:10:17 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:17 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:17 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:17 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:17 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:17 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:17 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:17 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:17 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:17 --> Parser Class Initialized
INFO - 2023-05-08 16:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:17 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:17 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:17 --> Controller Class Initialized
INFO - 2023-05-08 16:10:17 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:17 --> Model Class Initialized
INFO - 2023-05-08 16:10:17 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:17 --> Total execution time: 0.0264
ERROR - 2023-05-08 16:10:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:25 --> Config Class Initialized
INFO - 2023-05-08 16:10:25 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:25 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:25 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:25 --> URI Class Initialized
INFO - 2023-05-08 16:10:25 --> Router Class Initialized
INFO - 2023-05-08 16:10:25 --> Output Class Initialized
INFO - 2023-05-08 16:10:25 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:25 --> Input Class Initialized
INFO - 2023-05-08 16:10:25 --> Language Class Initialized
INFO - 2023-05-08 16:10:25 --> Loader Class Initialized
INFO - 2023-05-08 16:10:25 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:25 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:25 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:25 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:25 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:25 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:25 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:25 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:25 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:25 --> Parser Class Initialized
INFO - 2023-05-08 16:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:25 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:25 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:25 --> Controller Class Initialized
INFO - 2023-05-08 16:10:25 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:25 --> Model Class Initialized
INFO - 2023-05-08 16:10:25 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:25 --> Total execution time: 0.0465
ERROR - 2023-05-08 16:10:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:29 --> Config Class Initialized
INFO - 2023-05-08 16:10:29 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:29 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:29 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:29 --> URI Class Initialized
INFO - 2023-05-08 16:10:29 --> Router Class Initialized
INFO - 2023-05-08 16:10:29 --> Output Class Initialized
INFO - 2023-05-08 16:10:29 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:29 --> Input Class Initialized
INFO - 2023-05-08 16:10:29 --> Language Class Initialized
INFO - 2023-05-08 16:10:29 --> Loader Class Initialized
INFO - 2023-05-08 16:10:29 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:29 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:29 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:29 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:29 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:29 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:29 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:29 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:30 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:30 --> Parser Class Initialized
INFO - 2023-05-08 16:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:30 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:30 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:30 --> Controller Class Initialized
INFO - 2023-05-08 16:10:30 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:30 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-08 16:10:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:10:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:10:30 --> Model Class Initialized
INFO - 2023-05-08 16:10:30 --> Model Class Initialized
INFO - 2023-05-08 16:10:30 --> Model Class Initialized
INFO - 2023-05-08 16:10:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:10:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:10:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:10:30 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:30 --> Total execution time: 0.1289
ERROR - 2023-05-08 16:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:33 --> Config Class Initialized
INFO - 2023-05-08 16:10:33 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:33 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:33 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:33 --> URI Class Initialized
INFO - 2023-05-08 16:10:33 --> Router Class Initialized
INFO - 2023-05-08 16:10:33 --> Output Class Initialized
INFO - 2023-05-08 16:10:33 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:33 --> Input Class Initialized
INFO - 2023-05-08 16:10:33 --> Language Class Initialized
INFO - 2023-05-08 16:10:33 --> Loader Class Initialized
INFO - 2023-05-08 16:10:33 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:33 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:33 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:33 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:33 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:33 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:33 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:33 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:33 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:33 --> Parser Class Initialized
INFO - 2023-05-08 16:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:33 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:33 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:33 --> Controller Class Initialized
INFO - 2023-05-08 16:10:33 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:33 --> Model Class Initialized
INFO - 2023-05-08 16:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-08 16:10:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:10:33 --> Model Class Initialized
INFO - 2023-05-08 16:10:33 --> Model Class Initialized
INFO - 2023-05-08 16:10:33 --> Model Class Initialized
INFO - 2023-05-08 16:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:10:34 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:34 --> Total execution time: 0.1302
ERROR - 2023-05-08 16:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:34 --> Config Class Initialized
INFO - 2023-05-08 16:10:34 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:34 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:34 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:34 --> URI Class Initialized
INFO - 2023-05-08 16:10:34 --> Router Class Initialized
INFO - 2023-05-08 16:10:34 --> Output Class Initialized
INFO - 2023-05-08 16:10:34 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:34 --> Input Class Initialized
INFO - 2023-05-08 16:10:34 --> Language Class Initialized
INFO - 2023-05-08 16:10:34 --> Loader Class Initialized
INFO - 2023-05-08 16:10:34 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:34 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:34 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:34 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:34 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:34 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:34 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:34 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:34 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:34 --> Parser Class Initialized
INFO - 2023-05-08 16:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:34 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:34 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:34 --> Controller Class Initialized
INFO - 2023-05-08 16:10:34 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:34 --> Model Class Initialized
INFO - 2023-05-08 16:10:34 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:34 --> Total execution time: 0.0302
ERROR - 2023-05-08 16:10:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:39 --> Config Class Initialized
INFO - 2023-05-08 16:10:39 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:39 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:39 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:39 --> URI Class Initialized
DEBUG - 2023-05-08 16:10:39 --> No URI present. Default controller set.
INFO - 2023-05-08 16:10:39 --> Router Class Initialized
INFO - 2023-05-08 16:10:39 --> Output Class Initialized
INFO - 2023-05-08 16:10:39 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:39 --> Input Class Initialized
INFO - 2023-05-08 16:10:39 --> Language Class Initialized
INFO - 2023-05-08 16:10:39 --> Loader Class Initialized
INFO - 2023-05-08 16:10:39 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:39 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:39 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:39 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:39 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:39 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:39 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:39 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:39 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:39 --> Parser Class Initialized
INFO - 2023-05-08 16:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:39 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:39 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:39 --> Controller Class Initialized
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
DEBUG - 2023-05-08 16:10:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-08 16:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
INFO - 2023-05-08 16:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-08 16:10:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:10:39 --> Model Class Initialized
INFO - 2023-05-08 16:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:10:39 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:39 --> Total execution time: 0.1594
ERROR - 2023-05-08 16:10:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:54 --> Config Class Initialized
INFO - 2023-05-08 16:10:54 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:54 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:54 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:54 --> URI Class Initialized
INFO - 2023-05-08 16:10:54 --> Router Class Initialized
INFO - 2023-05-08 16:10:54 --> Output Class Initialized
INFO - 2023-05-08 16:10:54 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:54 --> Input Class Initialized
INFO - 2023-05-08 16:10:54 --> Language Class Initialized
INFO - 2023-05-08 16:10:54 --> Loader Class Initialized
INFO - 2023-05-08 16:10:54 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:54 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:54 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:54 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:54 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:54 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:54 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:54 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:54 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:54 --> Parser Class Initialized
INFO - 2023-05-08 16:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:54 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:54 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:54 --> Controller Class Initialized
INFO - 2023-05-08 16:10:54 --> Model Class Initialized
INFO - 2023-05-08 16:10:54 --> Model Class Initialized
INFO - 2023-05-08 16:10:54 --> Model Class Initialized
INFO - 2023-05-08 16:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-08 16:10:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-08 16:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-08 16:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-08 16:10:54 --> Model Class Initialized
INFO - 2023-05-08 16:10:54 --> Model Class Initialized
INFO - 2023-05-08 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-08 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-08 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-08 16:10:55 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:55 --> Total execution time: 0.1285
ERROR - 2023-05-08 16:10:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:10:56 --> Config Class Initialized
INFO - 2023-05-08 16:10:56 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:10:56 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:10:56 --> Utf8 Class Initialized
INFO - 2023-05-08 16:10:56 --> URI Class Initialized
INFO - 2023-05-08 16:10:56 --> Router Class Initialized
INFO - 2023-05-08 16:10:56 --> Output Class Initialized
INFO - 2023-05-08 16:10:56 --> Security Class Initialized
DEBUG - 2023-05-08 16:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:10:56 --> Input Class Initialized
INFO - 2023-05-08 16:10:56 --> Language Class Initialized
INFO - 2023-05-08 16:10:56 --> Loader Class Initialized
INFO - 2023-05-08 16:10:56 --> Helper loaded: url_helper
INFO - 2023-05-08 16:10:56 --> Helper loaded: file_helper
INFO - 2023-05-08 16:10:56 --> Helper loaded: html_helper
INFO - 2023-05-08 16:10:56 --> Helper loaded: text_helper
INFO - 2023-05-08 16:10:56 --> Helper loaded: form_helper
INFO - 2023-05-08 16:10:56 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:10:56 --> Helper loaded: security_helper
INFO - 2023-05-08 16:10:56 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:10:56 --> Database Driver Class Initialized
INFO - 2023-05-08 16:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:10:56 --> Parser Class Initialized
INFO - 2023-05-08 16:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:10:56 --> Pagination Class Initialized
INFO - 2023-05-08 16:10:56 --> Form Validation Class Initialized
INFO - 2023-05-08 16:10:56 --> Controller Class Initialized
INFO - 2023-05-08 16:10:56 --> Model Class Initialized
INFO - 2023-05-08 16:10:56 --> Model Class Initialized
INFO - 2023-05-08 16:10:56 --> Final output sent to browser
DEBUG - 2023-05-08 16:10:56 --> Total execution time: 0.0223
ERROR - 2023-05-08 16:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-08 16:11:01 --> Config Class Initialized
INFO - 2023-05-08 16:11:01 --> Hooks Class Initialized
DEBUG - 2023-05-08 16:11:01 --> UTF-8 Support Enabled
INFO - 2023-05-08 16:11:01 --> Utf8 Class Initialized
INFO - 2023-05-08 16:11:01 --> URI Class Initialized
INFO - 2023-05-08 16:11:01 --> Router Class Initialized
INFO - 2023-05-08 16:11:01 --> Output Class Initialized
INFO - 2023-05-08 16:11:01 --> Security Class Initialized
DEBUG - 2023-05-08 16:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-08 16:11:01 --> Input Class Initialized
INFO - 2023-05-08 16:11:01 --> Language Class Initialized
INFO - 2023-05-08 16:11:01 --> Loader Class Initialized
INFO - 2023-05-08 16:11:01 --> Helper loaded: url_helper
INFO - 2023-05-08 16:11:01 --> Helper loaded: file_helper
INFO - 2023-05-08 16:11:01 --> Helper loaded: html_helper
INFO - 2023-05-08 16:11:01 --> Helper loaded: text_helper
INFO - 2023-05-08 16:11:01 --> Helper loaded: form_helper
INFO - 2023-05-08 16:11:01 --> Helper loaded: lang_helper
INFO - 2023-05-08 16:11:01 --> Helper loaded: security_helper
INFO - 2023-05-08 16:11:01 --> Helper loaded: cookie_helper
INFO - 2023-05-08 16:11:01 --> Database Driver Class Initialized
INFO - 2023-05-08 16:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-08 16:11:01 --> Parser Class Initialized
INFO - 2023-05-08 16:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-08 16:11:01 --> Pagination Class Initialized
INFO - 2023-05-08 16:11:01 --> Form Validation Class Initialized
INFO - 2023-05-08 16:11:01 --> Controller Class Initialized
INFO - 2023-05-08 16:11:01 --> Model Class Initialized
INFO - 2023-05-08 16:11:01 --> Model Class Initialized
INFO - 2023-05-08 16:11:01 --> Final output sent to browser
DEBUG - 2023-05-08 16:11:01 --> Total execution time: 0.0306
