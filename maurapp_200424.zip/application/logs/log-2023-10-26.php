<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-26 04:05:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 04:05:19 --> Config Class Initialized
INFO - 2023-10-26 04:05:19 --> Hooks Class Initialized
DEBUG - 2023-10-26 04:05:19 --> UTF-8 Support Enabled
INFO - 2023-10-26 04:05:19 --> Utf8 Class Initialized
INFO - 2023-10-26 04:05:19 --> URI Class Initialized
INFO - 2023-10-26 04:05:19 --> Router Class Initialized
INFO - 2023-10-26 04:05:19 --> Output Class Initialized
INFO - 2023-10-26 04:05:19 --> Security Class Initialized
DEBUG - 2023-10-26 04:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 04:05:19 --> Input Class Initialized
INFO - 2023-10-26 04:05:19 --> Language Class Initialized
ERROR - 2023-10-26 04:05:19 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-26 06:02:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 06:02:21 --> Config Class Initialized
INFO - 2023-10-26 06:02:21 --> Hooks Class Initialized
DEBUG - 2023-10-26 06:02:21 --> UTF-8 Support Enabled
INFO - 2023-10-26 06:02:21 --> Utf8 Class Initialized
INFO - 2023-10-26 06:02:21 --> URI Class Initialized
DEBUG - 2023-10-26 06:02:21 --> No URI present. Default controller set.
INFO - 2023-10-26 06:02:21 --> Router Class Initialized
INFO - 2023-10-26 06:02:21 --> Output Class Initialized
INFO - 2023-10-26 06:02:21 --> Security Class Initialized
DEBUG - 2023-10-26 06:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 06:02:21 --> Input Class Initialized
INFO - 2023-10-26 06:02:21 --> Language Class Initialized
INFO - 2023-10-26 06:02:21 --> Loader Class Initialized
INFO - 2023-10-26 06:02:21 --> Helper loaded: url_helper
INFO - 2023-10-26 06:02:21 --> Helper loaded: file_helper
INFO - 2023-10-26 06:02:21 --> Helper loaded: html_helper
INFO - 2023-10-26 06:02:21 --> Helper loaded: text_helper
INFO - 2023-10-26 06:02:21 --> Helper loaded: form_helper
INFO - 2023-10-26 06:02:21 --> Helper loaded: lang_helper
INFO - 2023-10-26 06:02:21 --> Helper loaded: security_helper
INFO - 2023-10-26 06:02:21 --> Helper loaded: cookie_helper
INFO - 2023-10-26 06:02:21 --> Database Driver Class Initialized
INFO - 2023-10-26 06:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 06:02:21 --> Parser Class Initialized
INFO - 2023-10-26 06:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 06:02:21 --> Pagination Class Initialized
INFO - 2023-10-26 06:02:21 --> Form Validation Class Initialized
INFO - 2023-10-26 06:02:21 --> Controller Class Initialized
INFO - 2023-10-26 06:02:21 --> Model Class Initialized
DEBUG - 2023-10-26 06:02:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-26 06:02:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 06:02:22 --> Config Class Initialized
INFO - 2023-10-26 06:02:22 --> Hooks Class Initialized
DEBUG - 2023-10-26 06:02:22 --> UTF-8 Support Enabled
INFO - 2023-10-26 06:02:22 --> Utf8 Class Initialized
INFO - 2023-10-26 06:02:22 --> URI Class Initialized
INFO - 2023-10-26 06:02:22 --> Router Class Initialized
INFO - 2023-10-26 06:02:22 --> Output Class Initialized
INFO - 2023-10-26 06:02:22 --> Security Class Initialized
DEBUG - 2023-10-26 06:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 06:02:22 --> Input Class Initialized
INFO - 2023-10-26 06:02:22 --> Language Class Initialized
INFO - 2023-10-26 06:02:22 --> Loader Class Initialized
INFO - 2023-10-26 06:02:22 --> Helper loaded: url_helper
INFO - 2023-10-26 06:02:22 --> Helper loaded: file_helper
INFO - 2023-10-26 06:02:22 --> Helper loaded: html_helper
INFO - 2023-10-26 06:02:22 --> Helper loaded: text_helper
INFO - 2023-10-26 06:02:22 --> Helper loaded: form_helper
INFO - 2023-10-26 06:02:22 --> Helper loaded: lang_helper
INFO - 2023-10-26 06:02:22 --> Helper loaded: security_helper
INFO - 2023-10-26 06:02:22 --> Helper loaded: cookie_helper
INFO - 2023-10-26 06:02:22 --> Database Driver Class Initialized
INFO - 2023-10-26 06:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 06:02:22 --> Parser Class Initialized
INFO - 2023-10-26 06:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 06:02:22 --> Pagination Class Initialized
INFO - 2023-10-26 06:02:22 --> Form Validation Class Initialized
INFO - 2023-10-26 06:02:22 --> Controller Class Initialized
INFO - 2023-10-26 06:02:22 --> Model Class Initialized
DEBUG - 2023-10-26 06:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 06:02:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-26 06:02:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-26 06:02:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-26 06:02:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-26 06:02:22 --> Model Class Initialized
INFO - 2023-10-26 06:02:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-26 06:02:22 --> Final output sent to browser
DEBUG - 2023-10-26 06:02:22 --> Total execution time: 0.0341
ERROR - 2023-10-26 11:30:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:30:11 --> Config Class Initialized
INFO - 2023-10-26 11:30:11 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:30:11 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:30:11 --> Utf8 Class Initialized
INFO - 2023-10-26 11:30:11 --> URI Class Initialized
DEBUG - 2023-10-26 11:30:11 --> No URI present. Default controller set.
INFO - 2023-10-26 11:30:11 --> Router Class Initialized
INFO - 2023-10-26 11:30:11 --> Output Class Initialized
INFO - 2023-10-26 11:30:11 --> Security Class Initialized
DEBUG - 2023-10-26 11:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:30:11 --> Input Class Initialized
INFO - 2023-10-26 11:30:11 --> Language Class Initialized
INFO - 2023-10-26 11:30:11 --> Loader Class Initialized
INFO - 2023-10-26 11:30:11 --> Helper loaded: url_helper
INFO - 2023-10-26 11:30:11 --> Helper loaded: file_helper
INFO - 2023-10-26 11:30:11 --> Helper loaded: html_helper
INFO - 2023-10-26 11:30:11 --> Helper loaded: text_helper
INFO - 2023-10-26 11:30:11 --> Helper loaded: form_helper
INFO - 2023-10-26 11:30:11 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:30:11 --> Helper loaded: security_helper
INFO - 2023-10-26 11:30:11 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:30:11 --> Database Driver Class Initialized
INFO - 2023-10-26 11:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:30:11 --> Parser Class Initialized
INFO - 2023-10-26 11:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:30:11 --> Pagination Class Initialized
INFO - 2023-10-26 11:30:11 --> Form Validation Class Initialized
INFO - 2023-10-26 11:30:11 --> Controller Class Initialized
INFO - 2023-10-26 11:30:11 --> Model Class Initialized
DEBUG - 2023-10-26 11:30:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-26 11:30:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:30:12 --> Config Class Initialized
INFO - 2023-10-26 11:30:12 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:30:12 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:30:12 --> Utf8 Class Initialized
INFO - 2023-10-26 11:30:12 --> URI Class Initialized
INFO - 2023-10-26 11:30:12 --> Router Class Initialized
INFO - 2023-10-26 11:30:12 --> Output Class Initialized
INFO - 2023-10-26 11:30:12 --> Security Class Initialized
DEBUG - 2023-10-26 11:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:30:12 --> Input Class Initialized
INFO - 2023-10-26 11:30:12 --> Language Class Initialized
INFO - 2023-10-26 11:30:12 --> Loader Class Initialized
INFO - 2023-10-26 11:30:12 --> Helper loaded: url_helper
INFO - 2023-10-26 11:30:12 --> Helper loaded: file_helper
INFO - 2023-10-26 11:30:12 --> Helper loaded: html_helper
INFO - 2023-10-26 11:30:12 --> Helper loaded: text_helper
INFO - 2023-10-26 11:30:12 --> Helper loaded: form_helper
INFO - 2023-10-26 11:30:12 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:30:12 --> Helper loaded: security_helper
INFO - 2023-10-26 11:30:12 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:30:12 --> Database Driver Class Initialized
INFO - 2023-10-26 11:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:30:12 --> Parser Class Initialized
INFO - 2023-10-26 11:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:30:12 --> Pagination Class Initialized
INFO - 2023-10-26 11:30:12 --> Form Validation Class Initialized
INFO - 2023-10-26 11:30:12 --> Controller Class Initialized
INFO - 2023-10-26 11:30:12 --> Model Class Initialized
DEBUG - 2023-10-26 11:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-26 11:30:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-26 11:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-26 11:30:12 --> Model Class Initialized
INFO - 2023-10-26 11:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-26 11:30:12 --> Final output sent to browser
DEBUG - 2023-10-26 11:30:12 --> Total execution time: 0.0325
ERROR - 2023-10-26 11:30:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:30:14 --> Config Class Initialized
INFO - 2023-10-26 11:30:14 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:30:14 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:30:14 --> Utf8 Class Initialized
INFO - 2023-10-26 11:30:14 --> URI Class Initialized
INFO - 2023-10-26 11:30:14 --> Router Class Initialized
INFO - 2023-10-26 11:30:14 --> Output Class Initialized
INFO - 2023-10-26 11:30:14 --> Security Class Initialized
DEBUG - 2023-10-26 11:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:30:14 --> Input Class Initialized
INFO - 2023-10-26 11:30:14 --> Language Class Initialized
INFO - 2023-10-26 11:30:14 --> Loader Class Initialized
INFO - 2023-10-26 11:30:14 --> Helper loaded: url_helper
INFO - 2023-10-26 11:30:14 --> Helper loaded: file_helper
INFO - 2023-10-26 11:30:14 --> Helper loaded: html_helper
INFO - 2023-10-26 11:30:14 --> Helper loaded: text_helper
INFO - 2023-10-26 11:30:14 --> Helper loaded: form_helper
INFO - 2023-10-26 11:30:14 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:30:14 --> Helper loaded: security_helper
INFO - 2023-10-26 11:30:14 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:30:14 --> Database Driver Class Initialized
INFO - 2023-10-26 11:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:30:14 --> Parser Class Initialized
INFO - 2023-10-26 11:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:30:14 --> Pagination Class Initialized
INFO - 2023-10-26 11:30:14 --> Form Validation Class Initialized
INFO - 2023-10-26 11:30:14 --> Controller Class Initialized
INFO - 2023-10-26 11:30:14 --> Model Class Initialized
DEBUG - 2023-10-26 11:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:14 --> Model Class Initialized
INFO - 2023-10-26 11:30:14 --> Final output sent to browser
DEBUG - 2023-10-26 11:30:14 --> Total execution time: 0.0174
ERROR - 2023-10-26 11:30:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:30:15 --> Config Class Initialized
INFO - 2023-10-26 11:30:15 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:30:15 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:30:15 --> Utf8 Class Initialized
INFO - 2023-10-26 11:30:15 --> URI Class Initialized
DEBUG - 2023-10-26 11:30:15 --> No URI present. Default controller set.
INFO - 2023-10-26 11:30:15 --> Router Class Initialized
INFO - 2023-10-26 11:30:15 --> Output Class Initialized
INFO - 2023-10-26 11:30:15 --> Security Class Initialized
DEBUG - 2023-10-26 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:30:15 --> Input Class Initialized
INFO - 2023-10-26 11:30:15 --> Language Class Initialized
INFO - 2023-10-26 11:30:15 --> Loader Class Initialized
INFO - 2023-10-26 11:30:15 --> Helper loaded: url_helper
INFO - 2023-10-26 11:30:15 --> Helper loaded: file_helper
INFO - 2023-10-26 11:30:15 --> Helper loaded: html_helper
INFO - 2023-10-26 11:30:15 --> Helper loaded: text_helper
INFO - 2023-10-26 11:30:15 --> Helper loaded: form_helper
INFO - 2023-10-26 11:30:15 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:30:15 --> Helper loaded: security_helper
INFO - 2023-10-26 11:30:15 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:30:15 --> Database Driver Class Initialized
INFO - 2023-10-26 11:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:30:15 --> Parser Class Initialized
INFO - 2023-10-26 11:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:30:15 --> Pagination Class Initialized
INFO - 2023-10-26 11:30:15 --> Form Validation Class Initialized
INFO - 2023-10-26 11:30:15 --> Controller Class Initialized
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
DEBUG - 2023-10-26 11:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
DEBUG - 2023-10-26 11:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
DEBUG - 2023-10-26 11:30:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 11:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
INFO - 2023-10-26 11:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-26 11:30:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-26 11:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-26 11:30:15 --> Model Class Initialized
INFO - 2023-10-26 11:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-26 11:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-26 11:30:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-26 11:30:15 --> Final output sent to browser
DEBUG - 2023-10-26 11:30:15 --> Total execution time: 0.3609
ERROR - 2023-10-26 11:30:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:30:16 --> Config Class Initialized
INFO - 2023-10-26 11:30:16 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:30:16 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:30:16 --> Utf8 Class Initialized
INFO - 2023-10-26 11:30:16 --> URI Class Initialized
INFO - 2023-10-26 11:30:16 --> Router Class Initialized
INFO - 2023-10-26 11:30:16 --> Output Class Initialized
INFO - 2023-10-26 11:30:16 --> Security Class Initialized
DEBUG - 2023-10-26 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:30:16 --> Input Class Initialized
INFO - 2023-10-26 11:30:16 --> Language Class Initialized
INFO - 2023-10-26 11:30:16 --> Loader Class Initialized
INFO - 2023-10-26 11:30:16 --> Helper loaded: url_helper
INFO - 2023-10-26 11:30:16 --> Helper loaded: file_helper
INFO - 2023-10-26 11:30:16 --> Helper loaded: html_helper
INFO - 2023-10-26 11:30:16 --> Helper loaded: text_helper
INFO - 2023-10-26 11:30:16 --> Helper loaded: form_helper
INFO - 2023-10-26 11:30:16 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:30:16 --> Helper loaded: security_helper
INFO - 2023-10-26 11:30:16 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:30:16 --> Database Driver Class Initialized
INFO - 2023-10-26 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:30:16 --> Parser Class Initialized
INFO - 2023-10-26 11:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:30:16 --> Pagination Class Initialized
INFO - 2023-10-26 11:30:16 --> Form Validation Class Initialized
INFO - 2023-10-26 11:30:16 --> Controller Class Initialized
DEBUG - 2023-10-26 11:30:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 11:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:30:16 --> Model Class Initialized
INFO - 2023-10-26 11:30:16 --> Final output sent to browser
DEBUG - 2023-10-26 11:30:16 --> Total execution time: 0.0133
ERROR - 2023-10-26 11:31:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:31:21 --> Config Class Initialized
INFO - 2023-10-26 11:31:21 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:31:21 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:31:21 --> Utf8 Class Initialized
INFO - 2023-10-26 11:31:21 --> URI Class Initialized
INFO - 2023-10-26 11:31:21 --> Router Class Initialized
INFO - 2023-10-26 11:31:21 --> Output Class Initialized
INFO - 2023-10-26 11:31:21 --> Security Class Initialized
DEBUG - 2023-10-26 11:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:31:21 --> Input Class Initialized
INFO - 2023-10-26 11:31:21 --> Language Class Initialized
INFO - 2023-10-26 11:31:21 --> Loader Class Initialized
INFO - 2023-10-26 11:31:21 --> Helper loaded: url_helper
INFO - 2023-10-26 11:31:21 --> Helper loaded: file_helper
INFO - 2023-10-26 11:31:21 --> Helper loaded: html_helper
INFO - 2023-10-26 11:31:21 --> Helper loaded: text_helper
INFO - 2023-10-26 11:31:21 --> Helper loaded: form_helper
INFO - 2023-10-26 11:31:21 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:31:21 --> Helper loaded: security_helper
INFO - 2023-10-26 11:31:21 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:31:21 --> Database Driver Class Initialized
INFO - 2023-10-26 11:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:31:21 --> Parser Class Initialized
INFO - 2023-10-26 11:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:31:21 --> Pagination Class Initialized
INFO - 2023-10-26 11:31:21 --> Form Validation Class Initialized
INFO - 2023-10-26 11:31:21 --> Controller Class Initialized
INFO - 2023-10-26 11:31:21 --> Model Class Initialized
DEBUG - 2023-10-26 11:31:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 11:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:31:21 --> Model Class Initialized
DEBUG - 2023-10-26 11:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:31:21 --> Model Class Initialized
INFO - 2023-10-26 11:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-26 11:31:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-26 11:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-26 11:31:21 --> Model Class Initialized
INFO - 2023-10-26 11:31:21 --> Model Class Initialized
INFO - 2023-10-26 11:31:21 --> Model Class Initialized
INFO - 2023-10-26 11:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-26 11:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-26 11:31:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-26 11:31:21 --> Final output sent to browser
DEBUG - 2023-10-26 11:31:21 --> Total execution time: 0.1968
ERROR - 2023-10-26 11:31:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:31:22 --> Config Class Initialized
INFO - 2023-10-26 11:31:22 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:31:22 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:31:22 --> Utf8 Class Initialized
INFO - 2023-10-26 11:31:22 --> URI Class Initialized
INFO - 2023-10-26 11:31:22 --> Router Class Initialized
INFO - 2023-10-26 11:31:22 --> Output Class Initialized
INFO - 2023-10-26 11:31:22 --> Security Class Initialized
DEBUG - 2023-10-26 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:31:22 --> Input Class Initialized
INFO - 2023-10-26 11:31:22 --> Language Class Initialized
INFO - 2023-10-26 11:31:22 --> Loader Class Initialized
INFO - 2023-10-26 11:31:22 --> Helper loaded: url_helper
INFO - 2023-10-26 11:31:22 --> Helper loaded: file_helper
INFO - 2023-10-26 11:31:22 --> Helper loaded: html_helper
INFO - 2023-10-26 11:31:22 --> Helper loaded: text_helper
INFO - 2023-10-26 11:31:22 --> Helper loaded: form_helper
INFO - 2023-10-26 11:31:22 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:31:22 --> Helper loaded: security_helper
INFO - 2023-10-26 11:31:22 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:31:22 --> Database Driver Class Initialized
INFO - 2023-10-26 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:31:22 --> Parser Class Initialized
INFO - 2023-10-26 11:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:31:22 --> Pagination Class Initialized
INFO - 2023-10-26 11:31:22 --> Form Validation Class Initialized
INFO - 2023-10-26 11:31:22 --> Controller Class Initialized
INFO - 2023-10-26 11:31:22 --> Model Class Initialized
DEBUG - 2023-10-26 11:31:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 11:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:31:22 --> Model Class Initialized
DEBUG - 2023-10-26 11:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:31:22 --> Model Class Initialized
INFO - 2023-10-26 11:31:22 --> Final output sent to browser
DEBUG - 2023-10-26 11:31:22 --> Total execution time: 0.0609
ERROR - 2023-10-26 11:33:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:33:18 --> Config Class Initialized
INFO - 2023-10-26 11:33:18 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:33:18 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:33:18 --> Utf8 Class Initialized
INFO - 2023-10-26 11:33:18 --> URI Class Initialized
INFO - 2023-10-26 11:33:18 --> Router Class Initialized
INFO - 2023-10-26 11:33:18 --> Output Class Initialized
INFO - 2023-10-26 11:33:18 --> Security Class Initialized
DEBUG - 2023-10-26 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:33:18 --> Input Class Initialized
INFO - 2023-10-26 11:33:18 --> Language Class Initialized
INFO - 2023-10-26 11:33:18 --> Loader Class Initialized
INFO - 2023-10-26 11:33:18 --> Helper loaded: url_helper
INFO - 2023-10-26 11:33:18 --> Helper loaded: file_helper
INFO - 2023-10-26 11:33:18 --> Helper loaded: html_helper
INFO - 2023-10-26 11:33:18 --> Helper loaded: text_helper
INFO - 2023-10-26 11:33:18 --> Helper loaded: form_helper
INFO - 2023-10-26 11:33:18 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:33:18 --> Helper loaded: security_helper
INFO - 2023-10-26 11:33:18 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:33:18 --> Database Driver Class Initialized
INFO - 2023-10-26 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:33:18 --> Parser Class Initialized
INFO - 2023-10-26 11:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:33:18 --> Pagination Class Initialized
INFO - 2023-10-26 11:33:18 --> Form Validation Class Initialized
INFO - 2023-10-26 11:33:18 --> Controller Class Initialized
INFO - 2023-10-26 11:33:18 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:18 --> Final output sent to browser
DEBUG - 2023-10-26 11:33:18 --> Total execution time: 0.0149
ERROR - 2023-10-26 11:33:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:33:19 --> Config Class Initialized
INFO - 2023-10-26 11:33:19 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:33:19 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:33:19 --> Utf8 Class Initialized
INFO - 2023-10-26 11:33:19 --> URI Class Initialized
INFO - 2023-10-26 11:33:19 --> Router Class Initialized
INFO - 2023-10-26 11:33:19 --> Output Class Initialized
INFO - 2023-10-26 11:33:19 --> Security Class Initialized
DEBUG - 2023-10-26 11:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:33:19 --> Input Class Initialized
INFO - 2023-10-26 11:33:19 --> Language Class Initialized
INFO - 2023-10-26 11:33:19 --> Loader Class Initialized
INFO - 2023-10-26 11:33:19 --> Helper loaded: url_helper
INFO - 2023-10-26 11:33:19 --> Helper loaded: file_helper
INFO - 2023-10-26 11:33:19 --> Helper loaded: html_helper
INFO - 2023-10-26 11:33:19 --> Helper loaded: text_helper
INFO - 2023-10-26 11:33:19 --> Helper loaded: form_helper
INFO - 2023-10-26 11:33:19 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:33:19 --> Helper loaded: security_helper
INFO - 2023-10-26 11:33:19 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:33:19 --> Database Driver Class Initialized
INFO - 2023-10-26 11:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:33:19 --> Parser Class Initialized
INFO - 2023-10-26 11:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:33:19 --> Pagination Class Initialized
INFO - 2023-10-26 11:33:19 --> Form Validation Class Initialized
INFO - 2023-10-26 11:33:19 --> Controller Class Initialized
INFO - 2023-10-26 11:33:19 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-26 11:33:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-26 11:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-26 11:33:19 --> Model Class Initialized
INFO - 2023-10-26 11:33:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-26 11:33:19 --> Final output sent to browser
DEBUG - 2023-10-26 11:33:19 --> Total execution time: 0.0393
ERROR - 2023-10-26 11:33:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:33:25 --> Config Class Initialized
INFO - 2023-10-26 11:33:25 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:33:25 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:33:25 --> Utf8 Class Initialized
INFO - 2023-10-26 11:33:25 --> URI Class Initialized
INFO - 2023-10-26 11:33:25 --> Router Class Initialized
INFO - 2023-10-26 11:33:25 --> Output Class Initialized
INFO - 2023-10-26 11:33:25 --> Security Class Initialized
DEBUG - 2023-10-26 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:33:25 --> Input Class Initialized
INFO - 2023-10-26 11:33:25 --> Language Class Initialized
INFO - 2023-10-26 11:33:25 --> Loader Class Initialized
INFO - 2023-10-26 11:33:25 --> Helper loaded: url_helper
INFO - 2023-10-26 11:33:25 --> Helper loaded: file_helper
INFO - 2023-10-26 11:33:25 --> Helper loaded: html_helper
INFO - 2023-10-26 11:33:25 --> Helper loaded: text_helper
INFO - 2023-10-26 11:33:25 --> Helper loaded: form_helper
INFO - 2023-10-26 11:33:25 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:33:25 --> Helper loaded: security_helper
INFO - 2023-10-26 11:33:25 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:33:25 --> Database Driver Class Initialized
INFO - 2023-10-26 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:33:25 --> Parser Class Initialized
INFO - 2023-10-26 11:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:33:25 --> Pagination Class Initialized
INFO - 2023-10-26 11:33:25 --> Form Validation Class Initialized
INFO - 2023-10-26 11:33:25 --> Controller Class Initialized
INFO - 2023-10-26 11:33:25 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:25 --> Model Class Initialized
INFO - 2023-10-26 11:33:25 --> Final output sent to browser
DEBUG - 2023-10-26 11:33:25 --> Total execution time: 0.0169
ERROR - 2023-10-26 11:33:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:33:26 --> Config Class Initialized
INFO - 2023-10-26 11:33:26 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:33:26 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:33:26 --> Utf8 Class Initialized
INFO - 2023-10-26 11:33:26 --> URI Class Initialized
DEBUG - 2023-10-26 11:33:26 --> No URI present. Default controller set.
INFO - 2023-10-26 11:33:26 --> Router Class Initialized
INFO - 2023-10-26 11:33:26 --> Output Class Initialized
INFO - 2023-10-26 11:33:26 --> Security Class Initialized
DEBUG - 2023-10-26 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:33:26 --> Input Class Initialized
INFO - 2023-10-26 11:33:26 --> Language Class Initialized
INFO - 2023-10-26 11:33:26 --> Loader Class Initialized
INFO - 2023-10-26 11:33:26 --> Helper loaded: url_helper
INFO - 2023-10-26 11:33:26 --> Helper loaded: file_helper
INFO - 2023-10-26 11:33:26 --> Helper loaded: html_helper
INFO - 2023-10-26 11:33:26 --> Helper loaded: text_helper
INFO - 2023-10-26 11:33:26 --> Helper loaded: form_helper
INFO - 2023-10-26 11:33:26 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:33:26 --> Helper loaded: security_helper
INFO - 2023-10-26 11:33:26 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:33:26 --> Database Driver Class Initialized
INFO - 2023-10-26 11:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:33:26 --> Parser Class Initialized
INFO - 2023-10-26 11:33:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:33:26 --> Pagination Class Initialized
INFO - 2023-10-26 11:33:26 --> Form Validation Class Initialized
INFO - 2023-10-26 11:33:26 --> Controller Class Initialized
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 11:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
INFO - 2023-10-26 11:33:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-26 11:33:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-26 11:33:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-26 11:33:26 --> Model Class Initialized
INFO - 2023-10-26 11:33:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-26 11:33:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-26 11:33:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-26 11:33:26 --> Final output sent to browser
DEBUG - 2023-10-26 11:33:26 --> Total execution time: 0.3775
ERROR - 2023-10-26 11:33:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:33:27 --> Config Class Initialized
INFO - 2023-10-26 11:33:27 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:33:27 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:33:27 --> Utf8 Class Initialized
INFO - 2023-10-26 11:33:27 --> URI Class Initialized
INFO - 2023-10-26 11:33:27 --> Router Class Initialized
INFO - 2023-10-26 11:33:27 --> Output Class Initialized
INFO - 2023-10-26 11:33:27 --> Security Class Initialized
DEBUG - 2023-10-26 11:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:33:27 --> Input Class Initialized
INFO - 2023-10-26 11:33:27 --> Language Class Initialized
INFO - 2023-10-26 11:33:27 --> Loader Class Initialized
INFO - 2023-10-26 11:33:27 --> Helper loaded: url_helper
INFO - 2023-10-26 11:33:27 --> Helper loaded: file_helper
INFO - 2023-10-26 11:33:27 --> Helper loaded: html_helper
INFO - 2023-10-26 11:33:27 --> Helper loaded: text_helper
INFO - 2023-10-26 11:33:27 --> Helper loaded: form_helper
INFO - 2023-10-26 11:33:27 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:33:27 --> Helper loaded: security_helper
INFO - 2023-10-26 11:33:27 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:33:27 --> Database Driver Class Initialized
INFO - 2023-10-26 11:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:33:27 --> Parser Class Initialized
INFO - 2023-10-26 11:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:33:27 --> Pagination Class Initialized
INFO - 2023-10-26 11:33:27 --> Form Validation Class Initialized
INFO - 2023-10-26 11:33:27 --> Controller Class Initialized
DEBUG - 2023-10-26 11:33:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 11:33:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:27 --> Model Class Initialized
INFO - 2023-10-26 11:33:27 --> Final output sent to browser
DEBUG - 2023-10-26 11:33:27 --> Total execution time: 0.0156
ERROR - 2023-10-26 11:33:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:33:37 --> Config Class Initialized
INFO - 2023-10-26 11:33:37 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:33:37 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:33:37 --> Utf8 Class Initialized
INFO - 2023-10-26 11:33:37 --> URI Class Initialized
INFO - 2023-10-26 11:33:37 --> Router Class Initialized
INFO - 2023-10-26 11:33:37 --> Output Class Initialized
INFO - 2023-10-26 11:33:37 --> Security Class Initialized
DEBUG - 2023-10-26 11:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:33:37 --> Input Class Initialized
INFO - 2023-10-26 11:33:37 --> Language Class Initialized
INFO - 2023-10-26 11:33:37 --> Loader Class Initialized
INFO - 2023-10-26 11:33:37 --> Helper loaded: url_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: file_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: html_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: text_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: form_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: security_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:33:37 --> Database Driver Class Initialized
INFO - 2023-10-26 11:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:33:37 --> Parser Class Initialized
INFO - 2023-10-26 11:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:33:37 --> Pagination Class Initialized
INFO - 2023-10-26 11:33:37 --> Form Validation Class Initialized
INFO - 2023-10-26 11:33:37 --> Controller Class Initialized
INFO - 2023-10-26 11:33:37 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:37 --> Final output sent to browser
DEBUG - 2023-10-26 11:33:37 --> Total execution time: 0.0133
ERROR - 2023-10-26 11:33:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 11:33:37 --> Config Class Initialized
INFO - 2023-10-26 11:33:37 --> Hooks Class Initialized
DEBUG - 2023-10-26 11:33:37 --> UTF-8 Support Enabled
INFO - 2023-10-26 11:33:37 --> Utf8 Class Initialized
INFO - 2023-10-26 11:33:37 --> URI Class Initialized
INFO - 2023-10-26 11:33:37 --> Router Class Initialized
INFO - 2023-10-26 11:33:37 --> Output Class Initialized
INFO - 2023-10-26 11:33:37 --> Security Class Initialized
DEBUG - 2023-10-26 11:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 11:33:37 --> Input Class Initialized
INFO - 2023-10-26 11:33:37 --> Language Class Initialized
INFO - 2023-10-26 11:33:37 --> Loader Class Initialized
INFO - 2023-10-26 11:33:37 --> Helper loaded: url_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: file_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: html_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: text_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: form_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: lang_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: security_helper
INFO - 2023-10-26 11:33:37 --> Helper loaded: cookie_helper
INFO - 2023-10-26 11:33:37 --> Database Driver Class Initialized
INFO - 2023-10-26 11:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 11:33:37 --> Parser Class Initialized
INFO - 2023-10-26 11:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-26 11:33:37 --> Pagination Class Initialized
INFO - 2023-10-26 11:33:37 --> Form Validation Class Initialized
INFO - 2023-10-26 11:33:37 --> Controller Class Initialized
INFO - 2023-10-26 11:33:37 --> Model Class Initialized
DEBUG - 2023-10-26 11:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-26 11:33:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-26 11:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-26 11:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-26 11:33:37 --> Model Class Initialized
INFO - 2023-10-26 11:33:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-26 11:33:37 --> Final output sent to browser
DEBUG - 2023-10-26 11:33:37 --> Total execution time: 0.0280
ERROR - 2023-10-26 22:02:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-26 22:02:26 --> Config Class Initialized
INFO - 2023-10-26 22:02:26 --> Hooks Class Initialized
DEBUG - 2023-10-26 22:02:26 --> UTF-8 Support Enabled
INFO - 2023-10-26 22:02:26 --> Utf8 Class Initialized
INFO - 2023-10-26 22:02:26 --> URI Class Initialized
INFO - 2023-10-26 22:02:26 --> Router Class Initialized
INFO - 2023-10-26 22:02:26 --> Output Class Initialized
INFO - 2023-10-26 22:02:26 --> Security Class Initialized
DEBUG - 2023-10-26 22:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 22:02:26 --> Input Class Initialized
INFO - 2023-10-26 22:02:26 --> Language Class Initialized
ERROR - 2023-10-26 22:02:26 --> 404 Page Not Found: Well-known/assetlinks.json
