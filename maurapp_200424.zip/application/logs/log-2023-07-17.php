<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-17 08:16:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 08:16:25 --> Config Class Initialized
INFO - 2023-07-17 08:16:25 --> Hooks Class Initialized
DEBUG - 2023-07-17 08:16:25 --> UTF-8 Support Enabled
INFO - 2023-07-17 08:16:25 --> Utf8 Class Initialized
INFO - 2023-07-17 08:16:25 --> URI Class Initialized
DEBUG - 2023-07-17 08:16:25 --> No URI present. Default controller set.
INFO - 2023-07-17 08:16:25 --> Router Class Initialized
INFO - 2023-07-17 08:16:25 --> Output Class Initialized
INFO - 2023-07-17 08:16:25 --> Security Class Initialized
DEBUG - 2023-07-17 08:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 08:16:25 --> Input Class Initialized
INFO - 2023-07-17 08:16:25 --> Language Class Initialized
INFO - 2023-07-17 08:16:25 --> Loader Class Initialized
INFO - 2023-07-17 08:16:25 --> Helper loaded: url_helper
INFO - 2023-07-17 08:16:25 --> Helper loaded: file_helper
INFO - 2023-07-17 08:16:25 --> Helper loaded: html_helper
INFO - 2023-07-17 08:16:25 --> Helper loaded: text_helper
INFO - 2023-07-17 08:16:25 --> Helper loaded: form_helper
INFO - 2023-07-17 08:16:25 --> Helper loaded: lang_helper
INFO - 2023-07-17 08:16:25 --> Helper loaded: security_helper
INFO - 2023-07-17 08:16:25 --> Helper loaded: cookie_helper
INFO - 2023-07-17 08:16:25 --> Database Driver Class Initialized
INFO - 2023-07-17 08:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 08:16:25 --> Parser Class Initialized
INFO - 2023-07-17 08:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 08:16:25 --> Pagination Class Initialized
INFO - 2023-07-17 08:16:25 --> Form Validation Class Initialized
INFO - 2023-07-17 08:16:25 --> Controller Class Initialized
INFO - 2023-07-17 08:16:25 --> Model Class Initialized
DEBUG - 2023-07-17 08:16:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-17 08:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 08:16:26 --> Config Class Initialized
INFO - 2023-07-17 08:16:26 --> Hooks Class Initialized
DEBUG - 2023-07-17 08:16:26 --> UTF-8 Support Enabled
INFO - 2023-07-17 08:16:26 --> Utf8 Class Initialized
INFO - 2023-07-17 08:16:26 --> URI Class Initialized
INFO - 2023-07-17 08:16:26 --> Router Class Initialized
INFO - 2023-07-17 08:16:26 --> Output Class Initialized
INFO - 2023-07-17 08:16:26 --> Security Class Initialized
DEBUG - 2023-07-17 08:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 08:16:26 --> Input Class Initialized
INFO - 2023-07-17 08:16:26 --> Language Class Initialized
INFO - 2023-07-17 08:16:26 --> Loader Class Initialized
INFO - 2023-07-17 08:16:26 --> Helper loaded: url_helper
INFO - 2023-07-17 08:16:26 --> Helper loaded: file_helper
INFO - 2023-07-17 08:16:26 --> Helper loaded: html_helper
INFO - 2023-07-17 08:16:26 --> Helper loaded: text_helper
INFO - 2023-07-17 08:16:26 --> Helper loaded: form_helper
INFO - 2023-07-17 08:16:26 --> Helper loaded: lang_helper
INFO - 2023-07-17 08:16:26 --> Helper loaded: security_helper
INFO - 2023-07-17 08:16:26 --> Helper loaded: cookie_helper
INFO - 2023-07-17 08:16:26 --> Database Driver Class Initialized
INFO - 2023-07-17 08:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 08:16:26 --> Parser Class Initialized
INFO - 2023-07-17 08:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 08:16:26 --> Pagination Class Initialized
INFO - 2023-07-17 08:16:26 --> Form Validation Class Initialized
INFO - 2023-07-17 08:16:26 --> Controller Class Initialized
INFO - 2023-07-17 08:16:26 --> Model Class Initialized
DEBUG - 2023-07-17 08:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 08:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-17 08:16:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 08:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 08:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 08:16:26 --> Model Class Initialized
INFO - 2023-07-17 08:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 08:16:26 --> Final output sent to browser
DEBUG - 2023-07-17 08:16:26 --> Total execution time: 0.0363
ERROR - 2023-07-17 09:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 09:14:54 --> Config Class Initialized
INFO - 2023-07-17 09:14:54 --> Hooks Class Initialized
DEBUG - 2023-07-17 09:14:54 --> UTF-8 Support Enabled
INFO - 2023-07-17 09:14:54 --> Utf8 Class Initialized
INFO - 2023-07-17 09:14:54 --> URI Class Initialized
DEBUG - 2023-07-17 09:14:54 --> No URI present. Default controller set.
INFO - 2023-07-17 09:14:54 --> Router Class Initialized
INFO - 2023-07-17 09:14:54 --> Output Class Initialized
INFO - 2023-07-17 09:14:54 --> Security Class Initialized
DEBUG - 2023-07-17 09:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 09:14:54 --> Input Class Initialized
INFO - 2023-07-17 09:14:54 --> Language Class Initialized
INFO - 2023-07-17 09:14:54 --> Loader Class Initialized
INFO - 2023-07-17 09:14:54 --> Helper loaded: url_helper
INFO - 2023-07-17 09:14:54 --> Helper loaded: file_helper
INFO - 2023-07-17 09:14:54 --> Helper loaded: html_helper
INFO - 2023-07-17 09:14:54 --> Helper loaded: text_helper
INFO - 2023-07-17 09:14:54 --> Helper loaded: form_helper
INFO - 2023-07-17 09:14:54 --> Helper loaded: lang_helper
INFO - 2023-07-17 09:14:54 --> Helper loaded: security_helper
INFO - 2023-07-17 09:14:54 --> Helper loaded: cookie_helper
INFO - 2023-07-17 09:14:54 --> Database Driver Class Initialized
INFO - 2023-07-17 09:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 09:14:54 --> Parser Class Initialized
INFO - 2023-07-17 09:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 09:14:54 --> Pagination Class Initialized
INFO - 2023-07-17 09:14:54 --> Form Validation Class Initialized
INFO - 2023-07-17 09:14:54 --> Controller Class Initialized
INFO - 2023-07-17 09:14:54 --> Model Class Initialized
DEBUG - 2023-07-17 09:14:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-17 09:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 09:14:55 --> Config Class Initialized
INFO - 2023-07-17 09:14:55 --> Hooks Class Initialized
DEBUG - 2023-07-17 09:14:55 --> UTF-8 Support Enabled
INFO - 2023-07-17 09:14:55 --> Utf8 Class Initialized
INFO - 2023-07-17 09:14:55 --> URI Class Initialized
INFO - 2023-07-17 09:14:55 --> Router Class Initialized
INFO - 2023-07-17 09:14:55 --> Output Class Initialized
INFO - 2023-07-17 09:14:55 --> Security Class Initialized
DEBUG - 2023-07-17 09:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 09:14:55 --> Input Class Initialized
INFO - 2023-07-17 09:14:55 --> Language Class Initialized
INFO - 2023-07-17 09:14:55 --> Loader Class Initialized
INFO - 2023-07-17 09:14:55 --> Helper loaded: url_helper
INFO - 2023-07-17 09:14:55 --> Helper loaded: file_helper
INFO - 2023-07-17 09:14:55 --> Helper loaded: html_helper
INFO - 2023-07-17 09:14:55 --> Helper loaded: text_helper
INFO - 2023-07-17 09:14:55 --> Helper loaded: form_helper
INFO - 2023-07-17 09:14:55 --> Helper loaded: lang_helper
INFO - 2023-07-17 09:14:55 --> Helper loaded: security_helper
INFO - 2023-07-17 09:14:55 --> Helper loaded: cookie_helper
INFO - 2023-07-17 09:14:55 --> Database Driver Class Initialized
INFO - 2023-07-17 09:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 09:14:55 --> Parser Class Initialized
INFO - 2023-07-17 09:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 09:14:55 --> Pagination Class Initialized
INFO - 2023-07-17 09:14:55 --> Form Validation Class Initialized
INFO - 2023-07-17 09:14:55 --> Controller Class Initialized
INFO - 2023-07-17 09:14:55 --> Model Class Initialized
DEBUG - 2023-07-17 09:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 09:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-17 09:14:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 09:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 09:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 09:14:55 --> Model Class Initialized
INFO - 2023-07-17 09:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 09:14:55 --> Final output sent to browser
DEBUG - 2023-07-17 09:14:55 --> Total execution time: 0.0340
ERROR - 2023-07-17 11:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 11:46:19 --> Config Class Initialized
INFO - 2023-07-17 11:46:19 --> Hooks Class Initialized
DEBUG - 2023-07-17 11:46:19 --> UTF-8 Support Enabled
INFO - 2023-07-17 11:46:19 --> Utf8 Class Initialized
INFO - 2023-07-17 11:46:19 --> URI Class Initialized
DEBUG - 2023-07-17 11:46:19 --> No URI present. Default controller set.
INFO - 2023-07-17 11:46:19 --> Router Class Initialized
INFO - 2023-07-17 11:46:19 --> Output Class Initialized
INFO - 2023-07-17 11:46:19 --> Security Class Initialized
DEBUG - 2023-07-17 11:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 11:46:19 --> Input Class Initialized
INFO - 2023-07-17 11:46:19 --> Language Class Initialized
INFO - 2023-07-17 11:46:19 --> Loader Class Initialized
INFO - 2023-07-17 11:46:19 --> Helper loaded: url_helper
INFO - 2023-07-17 11:46:19 --> Helper loaded: file_helper
INFO - 2023-07-17 11:46:19 --> Helper loaded: html_helper
INFO - 2023-07-17 11:46:19 --> Helper loaded: text_helper
INFO - 2023-07-17 11:46:19 --> Helper loaded: form_helper
INFO - 2023-07-17 11:46:19 --> Helper loaded: lang_helper
INFO - 2023-07-17 11:46:19 --> Helper loaded: security_helper
INFO - 2023-07-17 11:46:19 --> Helper loaded: cookie_helper
INFO - 2023-07-17 11:46:19 --> Database Driver Class Initialized
INFO - 2023-07-17 11:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 11:46:19 --> Parser Class Initialized
INFO - 2023-07-17 11:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 11:46:19 --> Pagination Class Initialized
INFO - 2023-07-17 11:46:19 --> Form Validation Class Initialized
INFO - 2023-07-17 11:46:19 --> Controller Class Initialized
INFO - 2023-07-17 11:46:19 --> Model Class Initialized
DEBUG - 2023-07-17 11:46:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-17 11:46:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 11:46:20 --> Config Class Initialized
INFO - 2023-07-17 11:46:20 --> Hooks Class Initialized
DEBUG - 2023-07-17 11:46:20 --> UTF-8 Support Enabled
INFO - 2023-07-17 11:46:20 --> Utf8 Class Initialized
INFO - 2023-07-17 11:46:20 --> URI Class Initialized
INFO - 2023-07-17 11:46:20 --> Router Class Initialized
INFO - 2023-07-17 11:46:20 --> Output Class Initialized
INFO - 2023-07-17 11:46:20 --> Security Class Initialized
DEBUG - 2023-07-17 11:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 11:46:20 --> Input Class Initialized
INFO - 2023-07-17 11:46:20 --> Language Class Initialized
INFO - 2023-07-17 11:46:20 --> Loader Class Initialized
INFO - 2023-07-17 11:46:20 --> Helper loaded: url_helper
INFO - 2023-07-17 11:46:20 --> Helper loaded: file_helper
INFO - 2023-07-17 11:46:20 --> Helper loaded: html_helper
INFO - 2023-07-17 11:46:20 --> Helper loaded: text_helper
INFO - 2023-07-17 11:46:20 --> Helper loaded: form_helper
INFO - 2023-07-17 11:46:20 --> Helper loaded: lang_helper
INFO - 2023-07-17 11:46:20 --> Helper loaded: security_helper
INFO - 2023-07-17 11:46:20 --> Helper loaded: cookie_helper
INFO - 2023-07-17 11:46:20 --> Database Driver Class Initialized
INFO - 2023-07-17 11:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 11:46:20 --> Parser Class Initialized
INFO - 2023-07-17 11:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 11:46:20 --> Pagination Class Initialized
INFO - 2023-07-17 11:46:20 --> Form Validation Class Initialized
INFO - 2023-07-17 11:46:20 --> Controller Class Initialized
INFO - 2023-07-17 11:46:20 --> Model Class Initialized
DEBUG - 2023-07-17 11:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-17 11:46:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 11:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 11:46:20 --> Model Class Initialized
INFO - 2023-07-17 11:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 11:46:20 --> Final output sent to browser
DEBUG - 2023-07-17 11:46:20 --> Total execution time: 0.0360
ERROR - 2023-07-17 11:46:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 11:46:23 --> Config Class Initialized
INFO - 2023-07-17 11:46:23 --> Hooks Class Initialized
DEBUG - 2023-07-17 11:46:23 --> UTF-8 Support Enabled
INFO - 2023-07-17 11:46:23 --> Utf8 Class Initialized
INFO - 2023-07-17 11:46:23 --> URI Class Initialized
INFO - 2023-07-17 11:46:23 --> Router Class Initialized
INFO - 2023-07-17 11:46:23 --> Output Class Initialized
INFO - 2023-07-17 11:46:23 --> Security Class Initialized
DEBUG - 2023-07-17 11:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 11:46:23 --> Input Class Initialized
INFO - 2023-07-17 11:46:23 --> Language Class Initialized
INFO - 2023-07-17 11:46:23 --> Loader Class Initialized
INFO - 2023-07-17 11:46:23 --> Helper loaded: url_helper
INFO - 2023-07-17 11:46:23 --> Helper loaded: file_helper
INFO - 2023-07-17 11:46:23 --> Helper loaded: html_helper
INFO - 2023-07-17 11:46:23 --> Helper loaded: text_helper
INFO - 2023-07-17 11:46:23 --> Helper loaded: form_helper
INFO - 2023-07-17 11:46:23 --> Helper loaded: lang_helper
INFO - 2023-07-17 11:46:23 --> Helper loaded: security_helper
INFO - 2023-07-17 11:46:23 --> Helper loaded: cookie_helper
INFO - 2023-07-17 11:46:23 --> Database Driver Class Initialized
INFO - 2023-07-17 11:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 11:46:23 --> Parser Class Initialized
INFO - 2023-07-17 11:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 11:46:23 --> Pagination Class Initialized
INFO - 2023-07-17 11:46:23 --> Form Validation Class Initialized
INFO - 2023-07-17 11:46:23 --> Controller Class Initialized
INFO - 2023-07-17 11:46:23 --> Model Class Initialized
DEBUG - 2023-07-17 11:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:23 --> Model Class Initialized
INFO - 2023-07-17 11:46:23 --> Final output sent to browser
DEBUG - 2023-07-17 11:46:23 --> Total execution time: 0.0190
ERROR - 2023-07-17 11:46:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 11:46:24 --> Config Class Initialized
INFO - 2023-07-17 11:46:24 --> Hooks Class Initialized
DEBUG - 2023-07-17 11:46:24 --> UTF-8 Support Enabled
INFO - 2023-07-17 11:46:24 --> Utf8 Class Initialized
INFO - 2023-07-17 11:46:24 --> URI Class Initialized
DEBUG - 2023-07-17 11:46:24 --> No URI present. Default controller set.
INFO - 2023-07-17 11:46:24 --> Router Class Initialized
INFO - 2023-07-17 11:46:24 --> Output Class Initialized
INFO - 2023-07-17 11:46:24 --> Security Class Initialized
DEBUG - 2023-07-17 11:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 11:46:24 --> Input Class Initialized
INFO - 2023-07-17 11:46:24 --> Language Class Initialized
INFO - 2023-07-17 11:46:24 --> Loader Class Initialized
INFO - 2023-07-17 11:46:24 --> Helper loaded: url_helper
INFO - 2023-07-17 11:46:24 --> Helper loaded: file_helper
INFO - 2023-07-17 11:46:24 --> Helper loaded: html_helper
INFO - 2023-07-17 11:46:24 --> Helper loaded: text_helper
INFO - 2023-07-17 11:46:24 --> Helper loaded: form_helper
INFO - 2023-07-17 11:46:24 --> Helper loaded: lang_helper
INFO - 2023-07-17 11:46:24 --> Helper loaded: security_helper
INFO - 2023-07-17 11:46:24 --> Helper loaded: cookie_helper
INFO - 2023-07-17 11:46:24 --> Database Driver Class Initialized
INFO - 2023-07-17 11:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 11:46:24 --> Parser Class Initialized
INFO - 2023-07-17 11:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 11:46:24 --> Pagination Class Initialized
INFO - 2023-07-17 11:46:24 --> Form Validation Class Initialized
INFO - 2023-07-17 11:46:24 --> Controller Class Initialized
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
DEBUG - 2023-07-17 11:46:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
DEBUG - 2023-07-17 11:46:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
DEBUG - 2023-07-17 11:46:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 11:46:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
INFO - 2023-07-17 11:46:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-17 11:46:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 11:46:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 11:46:24 --> Model Class Initialized
INFO - 2023-07-17 11:46:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-17 11:46:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-17 11:46:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 11:46:24 --> Final output sent to browser
DEBUG - 2023-07-17 11:46:24 --> Total execution time: 0.2139
ERROR - 2023-07-17 11:46:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 11:46:25 --> Config Class Initialized
INFO - 2023-07-17 11:46:25 --> Hooks Class Initialized
DEBUG - 2023-07-17 11:46:25 --> UTF-8 Support Enabled
INFO - 2023-07-17 11:46:25 --> Utf8 Class Initialized
INFO - 2023-07-17 11:46:25 --> URI Class Initialized
INFO - 2023-07-17 11:46:25 --> Router Class Initialized
INFO - 2023-07-17 11:46:25 --> Output Class Initialized
INFO - 2023-07-17 11:46:25 --> Security Class Initialized
DEBUG - 2023-07-17 11:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 11:46:25 --> Input Class Initialized
INFO - 2023-07-17 11:46:25 --> Language Class Initialized
INFO - 2023-07-17 11:46:25 --> Loader Class Initialized
INFO - 2023-07-17 11:46:25 --> Helper loaded: url_helper
INFO - 2023-07-17 11:46:25 --> Helper loaded: file_helper
INFO - 2023-07-17 11:46:25 --> Helper loaded: html_helper
INFO - 2023-07-17 11:46:25 --> Helper loaded: text_helper
INFO - 2023-07-17 11:46:25 --> Helper loaded: form_helper
INFO - 2023-07-17 11:46:25 --> Helper loaded: lang_helper
INFO - 2023-07-17 11:46:25 --> Helper loaded: security_helper
INFO - 2023-07-17 11:46:25 --> Helper loaded: cookie_helper
INFO - 2023-07-17 11:46:25 --> Database Driver Class Initialized
INFO - 2023-07-17 11:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 11:46:25 --> Parser Class Initialized
INFO - 2023-07-17 11:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 11:46:25 --> Pagination Class Initialized
INFO - 2023-07-17 11:46:25 --> Form Validation Class Initialized
INFO - 2023-07-17 11:46:25 --> Controller Class Initialized
DEBUG - 2023-07-17 11:46:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 11:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 11:46:25 --> Model Class Initialized
INFO - 2023-07-17 11:46:25 --> Final output sent to browser
DEBUG - 2023-07-17 11:46:25 --> Total execution time: 0.0136
ERROR - 2023-07-17 12:00:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:00:11 --> Config Class Initialized
INFO - 2023-07-17 12:00:11 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:00:11 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:00:11 --> Utf8 Class Initialized
INFO - 2023-07-17 12:00:11 --> URI Class Initialized
DEBUG - 2023-07-17 12:00:11 --> No URI present. Default controller set.
INFO - 2023-07-17 12:00:11 --> Router Class Initialized
INFO - 2023-07-17 12:00:11 --> Output Class Initialized
INFO - 2023-07-17 12:00:11 --> Security Class Initialized
DEBUG - 2023-07-17 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:00:11 --> Input Class Initialized
INFO - 2023-07-17 12:00:11 --> Language Class Initialized
INFO - 2023-07-17 12:00:11 --> Loader Class Initialized
INFO - 2023-07-17 12:00:11 --> Helper loaded: url_helper
INFO - 2023-07-17 12:00:11 --> Helper loaded: file_helper
INFO - 2023-07-17 12:00:11 --> Helper loaded: html_helper
INFO - 2023-07-17 12:00:11 --> Helper loaded: text_helper
INFO - 2023-07-17 12:00:11 --> Helper loaded: form_helper
INFO - 2023-07-17 12:00:11 --> Helper loaded: lang_helper
INFO - 2023-07-17 12:00:11 --> Helper loaded: security_helper
INFO - 2023-07-17 12:00:11 --> Helper loaded: cookie_helper
INFO - 2023-07-17 12:00:11 --> Database Driver Class Initialized
INFO - 2023-07-17 12:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 12:00:11 --> Parser Class Initialized
INFO - 2023-07-17 12:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 12:00:11 --> Pagination Class Initialized
INFO - 2023-07-17 12:00:11 --> Form Validation Class Initialized
INFO - 2023-07-17 12:00:11 --> Controller Class Initialized
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
DEBUG - 2023-07-17 12:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
DEBUG - 2023-07-17 12:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
DEBUG - 2023-07-17 12:00:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 12:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
INFO - 2023-07-17 12:00:11 --> Model Class Initialized
INFO - 2023-07-17 12:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-17 12:00:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 12:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 12:00:12 --> Model Class Initialized
INFO - 2023-07-17 12:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-17 12:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-17 12:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 12:00:12 --> Final output sent to browser
DEBUG - 2023-07-17 12:00:12 --> Total execution time: 0.2076
ERROR - 2023-07-17 12:00:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:00:34 --> Config Class Initialized
INFO - 2023-07-17 12:00:34 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:00:34 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:00:34 --> Utf8 Class Initialized
INFO - 2023-07-17 12:00:34 --> URI Class Initialized
DEBUG - 2023-07-17 12:00:34 --> No URI present. Default controller set.
INFO - 2023-07-17 12:00:34 --> Router Class Initialized
INFO - 2023-07-17 12:00:34 --> Output Class Initialized
INFO - 2023-07-17 12:00:34 --> Security Class Initialized
DEBUG - 2023-07-17 12:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:00:34 --> Input Class Initialized
INFO - 2023-07-17 12:00:34 --> Language Class Initialized
INFO - 2023-07-17 12:00:34 --> Loader Class Initialized
INFO - 2023-07-17 12:00:34 --> Helper loaded: url_helper
INFO - 2023-07-17 12:00:34 --> Helper loaded: file_helper
INFO - 2023-07-17 12:00:34 --> Helper loaded: html_helper
INFO - 2023-07-17 12:00:34 --> Helper loaded: text_helper
INFO - 2023-07-17 12:00:34 --> Helper loaded: form_helper
INFO - 2023-07-17 12:00:34 --> Helper loaded: lang_helper
INFO - 2023-07-17 12:00:34 --> Helper loaded: security_helper
INFO - 2023-07-17 12:00:34 --> Helper loaded: cookie_helper
INFO - 2023-07-17 12:00:34 --> Database Driver Class Initialized
INFO - 2023-07-17 12:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 12:00:34 --> Parser Class Initialized
INFO - 2023-07-17 12:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 12:00:34 --> Pagination Class Initialized
INFO - 2023-07-17 12:00:34 --> Form Validation Class Initialized
INFO - 2023-07-17 12:00:34 --> Controller Class Initialized
INFO - 2023-07-17 12:00:34 --> Model Class Initialized
DEBUG - 2023-07-17 12:00:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-17 12:00:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:00:41 --> Config Class Initialized
INFO - 2023-07-17 12:00:41 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:00:41 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:00:41 --> Utf8 Class Initialized
INFO - 2023-07-17 12:00:41 --> URI Class Initialized
INFO - 2023-07-17 12:00:41 --> Router Class Initialized
INFO - 2023-07-17 12:00:41 --> Output Class Initialized
INFO - 2023-07-17 12:00:41 --> Security Class Initialized
DEBUG - 2023-07-17 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:00:41 --> Input Class Initialized
INFO - 2023-07-17 12:00:41 --> Language Class Initialized
INFO - 2023-07-17 12:00:41 --> Loader Class Initialized
INFO - 2023-07-17 12:00:41 --> Helper loaded: url_helper
INFO - 2023-07-17 12:00:41 --> Helper loaded: file_helper
INFO - 2023-07-17 12:00:41 --> Helper loaded: html_helper
INFO - 2023-07-17 12:00:41 --> Helper loaded: text_helper
INFO - 2023-07-17 12:00:41 --> Helper loaded: form_helper
INFO - 2023-07-17 12:00:41 --> Helper loaded: lang_helper
INFO - 2023-07-17 12:00:41 --> Helper loaded: security_helper
INFO - 2023-07-17 12:00:41 --> Helper loaded: cookie_helper
INFO - 2023-07-17 12:00:41 --> Database Driver Class Initialized
INFO - 2023-07-17 12:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 12:00:41 --> Parser Class Initialized
INFO - 2023-07-17 12:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 12:00:41 --> Pagination Class Initialized
INFO - 2023-07-17 12:00:41 --> Form Validation Class Initialized
INFO - 2023-07-17 12:00:41 --> Controller Class Initialized
INFO - 2023-07-17 12:00:41 --> Model Class Initialized
DEBUG - 2023-07-17 12:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-17 12:00:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 12:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 12:00:41 --> Model Class Initialized
INFO - 2023-07-17 12:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 12:00:41 --> Final output sent to browser
DEBUG - 2023-07-17 12:00:41 --> Total execution time: 0.0340
ERROR - 2023-07-17 12:00:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:00:43 --> Config Class Initialized
INFO - 2023-07-17 12:00:43 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:00:43 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:00:43 --> Utf8 Class Initialized
INFO - 2023-07-17 12:00:43 --> URI Class Initialized
INFO - 2023-07-17 12:00:43 --> Router Class Initialized
INFO - 2023-07-17 12:00:43 --> Output Class Initialized
INFO - 2023-07-17 12:00:43 --> Security Class Initialized
DEBUG - 2023-07-17 12:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:00:43 --> Input Class Initialized
INFO - 2023-07-17 12:00:43 --> Language Class Initialized
ERROR - 2023-07-17 12:00:43 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-07-17 12:00:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:00:46 --> Config Class Initialized
INFO - 2023-07-17 12:00:46 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:00:46 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:00:46 --> Utf8 Class Initialized
INFO - 2023-07-17 12:00:46 --> URI Class Initialized
INFO - 2023-07-17 12:00:46 --> Router Class Initialized
INFO - 2023-07-17 12:00:46 --> Output Class Initialized
INFO - 2023-07-17 12:00:46 --> Security Class Initialized
DEBUG - 2023-07-17 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:00:46 --> Input Class Initialized
INFO - 2023-07-17 12:00:46 --> Language Class Initialized
ERROR - 2023-07-17 12:00:46 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-07-17 12:00:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:00:59 --> Config Class Initialized
INFO - 2023-07-17 12:00:59 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:00:59 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:00:59 --> Utf8 Class Initialized
INFO - 2023-07-17 12:00:59 --> URI Class Initialized
INFO - 2023-07-17 12:00:59 --> Router Class Initialized
INFO - 2023-07-17 12:00:59 --> Output Class Initialized
INFO - 2023-07-17 12:00:59 --> Security Class Initialized
DEBUG - 2023-07-17 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:00:59 --> Input Class Initialized
INFO - 2023-07-17 12:00:59 --> Language Class Initialized
INFO - 2023-07-17 12:00:59 --> Loader Class Initialized
INFO - 2023-07-17 12:00:59 --> Helper loaded: url_helper
INFO - 2023-07-17 12:00:59 --> Helper loaded: file_helper
INFO - 2023-07-17 12:00:59 --> Helper loaded: html_helper
INFO - 2023-07-17 12:00:59 --> Helper loaded: text_helper
INFO - 2023-07-17 12:00:59 --> Helper loaded: form_helper
INFO - 2023-07-17 12:00:59 --> Helper loaded: lang_helper
INFO - 2023-07-17 12:00:59 --> Helper loaded: security_helper
INFO - 2023-07-17 12:00:59 --> Helper loaded: cookie_helper
INFO - 2023-07-17 12:00:59 --> Database Driver Class Initialized
INFO - 2023-07-17 12:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 12:00:59 --> Parser Class Initialized
INFO - 2023-07-17 12:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 12:00:59 --> Pagination Class Initialized
INFO - 2023-07-17 12:00:59 --> Form Validation Class Initialized
INFO - 2023-07-17 12:00:59 --> Controller Class Initialized
INFO - 2023-07-17 12:00:59 --> Model Class Initialized
DEBUG - 2023-07-17 12:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:00:59 --> Model Class Initialized
INFO - 2023-07-17 12:00:59 --> Final output sent to browser
DEBUG - 2023-07-17 12:00:59 --> Total execution time: 0.0204
ERROR - 2023-07-17 12:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:01:01 --> Config Class Initialized
INFO - 2023-07-17 12:01:01 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:01:01 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:01:01 --> Utf8 Class Initialized
INFO - 2023-07-17 12:01:01 --> URI Class Initialized
DEBUG - 2023-07-17 12:01:01 --> No URI present. Default controller set.
INFO - 2023-07-17 12:01:01 --> Router Class Initialized
INFO - 2023-07-17 12:01:01 --> Output Class Initialized
INFO - 2023-07-17 12:01:01 --> Security Class Initialized
DEBUG - 2023-07-17 12:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:01:01 --> Input Class Initialized
INFO - 2023-07-17 12:01:01 --> Language Class Initialized
INFO - 2023-07-17 12:01:01 --> Loader Class Initialized
INFO - 2023-07-17 12:01:01 --> Helper loaded: url_helper
INFO - 2023-07-17 12:01:01 --> Helper loaded: file_helper
INFO - 2023-07-17 12:01:01 --> Helper loaded: html_helper
INFO - 2023-07-17 12:01:01 --> Helper loaded: text_helper
INFO - 2023-07-17 12:01:01 --> Helper loaded: form_helper
INFO - 2023-07-17 12:01:01 --> Helper loaded: lang_helper
INFO - 2023-07-17 12:01:01 --> Helper loaded: security_helper
INFO - 2023-07-17 12:01:01 --> Helper loaded: cookie_helper
INFO - 2023-07-17 12:01:01 --> Database Driver Class Initialized
INFO - 2023-07-17 12:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 12:01:01 --> Parser Class Initialized
INFO - 2023-07-17 12:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 12:01:01 --> Pagination Class Initialized
INFO - 2023-07-17 12:01:01 --> Form Validation Class Initialized
INFO - 2023-07-17 12:01:01 --> Controller Class Initialized
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
DEBUG - 2023-07-17 12:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
DEBUG - 2023-07-17 12:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
DEBUG - 2023-07-17 12:01:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 12:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
INFO - 2023-07-17 12:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-17 12:01:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 12:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 12:01:01 --> Model Class Initialized
INFO - 2023-07-17 12:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-17 12:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-17 12:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 12:01:01 --> Final output sent to browser
DEBUG - 2023-07-17 12:01:01 --> Total execution time: 0.0874
ERROR - 2023-07-17 12:01:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 12:01:08 --> Config Class Initialized
INFO - 2023-07-17 12:01:08 --> Hooks Class Initialized
DEBUG - 2023-07-17 12:01:08 --> UTF-8 Support Enabled
INFO - 2023-07-17 12:01:08 --> Utf8 Class Initialized
INFO - 2023-07-17 12:01:08 --> URI Class Initialized
INFO - 2023-07-17 12:01:08 --> Router Class Initialized
INFO - 2023-07-17 12:01:08 --> Output Class Initialized
INFO - 2023-07-17 12:01:08 --> Security Class Initialized
DEBUG - 2023-07-17 12:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 12:01:08 --> Input Class Initialized
INFO - 2023-07-17 12:01:08 --> Language Class Initialized
INFO - 2023-07-17 12:01:08 --> Loader Class Initialized
INFO - 2023-07-17 12:01:08 --> Helper loaded: url_helper
INFO - 2023-07-17 12:01:08 --> Helper loaded: file_helper
INFO - 2023-07-17 12:01:08 --> Helper loaded: html_helper
INFO - 2023-07-17 12:01:08 --> Helper loaded: text_helper
INFO - 2023-07-17 12:01:08 --> Helper loaded: form_helper
INFO - 2023-07-17 12:01:08 --> Helper loaded: lang_helper
INFO - 2023-07-17 12:01:08 --> Helper loaded: security_helper
INFO - 2023-07-17 12:01:08 --> Helper loaded: cookie_helper
INFO - 2023-07-17 12:01:08 --> Database Driver Class Initialized
INFO - 2023-07-17 12:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 12:01:08 --> Parser Class Initialized
INFO - 2023-07-17 12:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 12:01:08 --> Pagination Class Initialized
INFO - 2023-07-17 12:01:08 --> Form Validation Class Initialized
INFO - 2023-07-17 12:01:08 --> Controller Class Initialized
INFO - 2023-07-17 12:01:08 --> Model Class Initialized
DEBUG - 2023-07-17 12:01:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-17 12:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:01:08 --> Model Class Initialized
INFO - 2023-07-17 12:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-17 12:01:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 12:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 12:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 12:01:08 --> Model Class Initialized
INFO - 2023-07-17 12:01:08 --> Model Class Initialized
INFO - 2023-07-17 12:01:08 --> Model Class Initialized
INFO - 2023-07-17 12:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-17 12:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-17 12:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 12:01:08 --> Final output sent to browser
DEBUG - 2023-07-17 12:01:08 --> Total execution time: 0.0783
ERROR - 2023-07-17 13:54:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 13:54:42 --> Config Class Initialized
INFO - 2023-07-17 13:54:42 --> Hooks Class Initialized
DEBUG - 2023-07-17 13:54:42 --> UTF-8 Support Enabled
INFO - 2023-07-17 13:54:42 --> Utf8 Class Initialized
INFO - 2023-07-17 13:54:42 --> URI Class Initialized
DEBUG - 2023-07-17 13:54:42 --> No URI present. Default controller set.
INFO - 2023-07-17 13:54:42 --> Router Class Initialized
INFO - 2023-07-17 13:54:42 --> Output Class Initialized
INFO - 2023-07-17 13:54:42 --> Security Class Initialized
DEBUG - 2023-07-17 13:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 13:54:42 --> Input Class Initialized
INFO - 2023-07-17 13:54:42 --> Language Class Initialized
INFO - 2023-07-17 13:54:42 --> Loader Class Initialized
INFO - 2023-07-17 13:54:42 --> Helper loaded: url_helper
INFO - 2023-07-17 13:54:42 --> Helper loaded: file_helper
INFO - 2023-07-17 13:54:42 --> Helper loaded: html_helper
INFO - 2023-07-17 13:54:42 --> Helper loaded: text_helper
INFO - 2023-07-17 13:54:42 --> Helper loaded: form_helper
INFO - 2023-07-17 13:54:42 --> Helper loaded: lang_helper
INFO - 2023-07-17 13:54:42 --> Helper loaded: security_helper
INFO - 2023-07-17 13:54:42 --> Helper loaded: cookie_helper
INFO - 2023-07-17 13:54:42 --> Database Driver Class Initialized
INFO - 2023-07-17 13:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 13:54:42 --> Parser Class Initialized
INFO - 2023-07-17 13:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 13:54:42 --> Pagination Class Initialized
INFO - 2023-07-17 13:54:42 --> Form Validation Class Initialized
INFO - 2023-07-17 13:54:42 --> Controller Class Initialized
INFO - 2023-07-17 13:54:42 --> Model Class Initialized
DEBUG - 2023-07-17 13:54:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-17 13:54:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 13:54:43 --> Config Class Initialized
INFO - 2023-07-17 13:54:43 --> Hooks Class Initialized
DEBUG - 2023-07-17 13:54:43 --> UTF-8 Support Enabled
INFO - 2023-07-17 13:54:43 --> Utf8 Class Initialized
INFO - 2023-07-17 13:54:43 --> URI Class Initialized
INFO - 2023-07-17 13:54:43 --> Router Class Initialized
INFO - 2023-07-17 13:54:43 --> Output Class Initialized
INFO - 2023-07-17 13:54:43 --> Security Class Initialized
DEBUG - 2023-07-17 13:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 13:54:43 --> Input Class Initialized
INFO - 2023-07-17 13:54:43 --> Language Class Initialized
INFO - 2023-07-17 13:54:43 --> Loader Class Initialized
INFO - 2023-07-17 13:54:43 --> Helper loaded: url_helper
INFO - 2023-07-17 13:54:43 --> Helper loaded: file_helper
INFO - 2023-07-17 13:54:43 --> Helper loaded: html_helper
INFO - 2023-07-17 13:54:43 --> Helper loaded: text_helper
INFO - 2023-07-17 13:54:43 --> Helper loaded: form_helper
INFO - 2023-07-17 13:54:43 --> Helper loaded: lang_helper
INFO - 2023-07-17 13:54:43 --> Helper loaded: security_helper
INFO - 2023-07-17 13:54:43 --> Helper loaded: cookie_helper
INFO - 2023-07-17 13:54:43 --> Database Driver Class Initialized
INFO - 2023-07-17 13:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 13:54:43 --> Parser Class Initialized
INFO - 2023-07-17 13:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 13:54:43 --> Pagination Class Initialized
INFO - 2023-07-17 13:54:43 --> Form Validation Class Initialized
INFO - 2023-07-17 13:54:43 --> Controller Class Initialized
INFO - 2023-07-17 13:54:43 --> Model Class Initialized
DEBUG - 2023-07-17 13:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 13:54:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-17 13:54:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 13:54:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 13:54:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 13:54:43 --> Model Class Initialized
INFO - 2023-07-17 13:54:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 13:54:43 --> Final output sent to browser
DEBUG - 2023-07-17 13:54:43 --> Total execution time: 0.0349
ERROR - 2023-07-17 14:54:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 14:54:10 --> Config Class Initialized
INFO - 2023-07-17 14:54:10 --> Hooks Class Initialized
DEBUG - 2023-07-17 14:54:10 --> UTF-8 Support Enabled
INFO - 2023-07-17 14:54:10 --> Utf8 Class Initialized
INFO - 2023-07-17 14:54:10 --> URI Class Initialized
DEBUG - 2023-07-17 14:54:10 --> No URI present. Default controller set.
INFO - 2023-07-17 14:54:10 --> Router Class Initialized
INFO - 2023-07-17 14:54:10 --> Output Class Initialized
INFO - 2023-07-17 14:54:10 --> Security Class Initialized
DEBUG - 2023-07-17 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 14:54:10 --> Input Class Initialized
INFO - 2023-07-17 14:54:10 --> Language Class Initialized
INFO - 2023-07-17 14:54:10 --> Loader Class Initialized
INFO - 2023-07-17 14:54:10 --> Helper loaded: url_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: file_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: html_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: text_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: form_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: lang_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: security_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: cookie_helper
INFO - 2023-07-17 14:54:10 --> Database Driver Class Initialized
INFO - 2023-07-17 14:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 14:54:10 --> Parser Class Initialized
INFO - 2023-07-17 14:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 14:54:10 --> Pagination Class Initialized
INFO - 2023-07-17 14:54:10 --> Form Validation Class Initialized
INFO - 2023-07-17 14:54:10 --> Controller Class Initialized
INFO - 2023-07-17 14:54:10 --> Model Class Initialized
DEBUG - 2023-07-17 14:54:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-17 14:54:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 14:54:10 --> Config Class Initialized
INFO - 2023-07-17 14:54:10 --> Hooks Class Initialized
DEBUG - 2023-07-17 14:54:10 --> UTF-8 Support Enabled
INFO - 2023-07-17 14:54:10 --> Utf8 Class Initialized
INFO - 2023-07-17 14:54:10 --> URI Class Initialized
INFO - 2023-07-17 14:54:10 --> Router Class Initialized
INFO - 2023-07-17 14:54:10 --> Output Class Initialized
INFO - 2023-07-17 14:54:10 --> Security Class Initialized
DEBUG - 2023-07-17 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 14:54:10 --> Input Class Initialized
INFO - 2023-07-17 14:54:10 --> Language Class Initialized
INFO - 2023-07-17 14:54:10 --> Loader Class Initialized
INFO - 2023-07-17 14:54:10 --> Helper loaded: url_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: file_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: html_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: text_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: form_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: lang_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: security_helper
INFO - 2023-07-17 14:54:10 --> Helper loaded: cookie_helper
INFO - 2023-07-17 14:54:10 --> Database Driver Class Initialized
INFO - 2023-07-17 14:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 14:54:10 --> Parser Class Initialized
INFO - 2023-07-17 14:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 14:54:10 --> Pagination Class Initialized
INFO - 2023-07-17 14:54:10 --> Form Validation Class Initialized
INFO - 2023-07-17 14:54:10 --> Controller Class Initialized
INFO - 2023-07-17 14:54:10 --> Model Class Initialized
DEBUG - 2023-07-17 14:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 14:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-17 14:54:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 14:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 14:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 14:54:10 --> Model Class Initialized
INFO - 2023-07-17 14:54:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 14:54:10 --> Final output sent to browser
DEBUG - 2023-07-17 14:54:10 --> Total execution time: 0.0353
ERROR - 2023-07-17 18:52:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 18:52:27 --> Config Class Initialized
INFO - 2023-07-17 18:52:27 --> Hooks Class Initialized
DEBUG - 2023-07-17 18:52:27 --> UTF-8 Support Enabled
INFO - 2023-07-17 18:52:27 --> Utf8 Class Initialized
INFO - 2023-07-17 18:52:27 --> URI Class Initialized
DEBUG - 2023-07-17 18:52:27 --> No URI present. Default controller set.
INFO - 2023-07-17 18:52:27 --> Router Class Initialized
INFO - 2023-07-17 18:52:27 --> Output Class Initialized
INFO - 2023-07-17 18:52:27 --> Security Class Initialized
DEBUG - 2023-07-17 18:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 18:52:27 --> Input Class Initialized
INFO - 2023-07-17 18:52:27 --> Language Class Initialized
INFO - 2023-07-17 18:52:27 --> Loader Class Initialized
INFO - 2023-07-17 18:52:27 --> Helper loaded: url_helper
INFO - 2023-07-17 18:52:27 --> Helper loaded: file_helper
INFO - 2023-07-17 18:52:27 --> Helper loaded: html_helper
INFO - 2023-07-17 18:52:27 --> Helper loaded: text_helper
INFO - 2023-07-17 18:52:27 --> Helper loaded: form_helper
INFO - 2023-07-17 18:52:27 --> Helper loaded: lang_helper
INFO - 2023-07-17 18:52:27 --> Helper loaded: security_helper
INFO - 2023-07-17 18:52:27 --> Helper loaded: cookie_helper
INFO - 2023-07-17 18:52:27 --> Database Driver Class Initialized
INFO - 2023-07-17 18:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 18:52:27 --> Parser Class Initialized
INFO - 2023-07-17 18:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 18:52:27 --> Pagination Class Initialized
INFO - 2023-07-17 18:52:27 --> Form Validation Class Initialized
INFO - 2023-07-17 18:52:27 --> Controller Class Initialized
INFO - 2023-07-17 18:52:27 --> Model Class Initialized
DEBUG - 2023-07-17 18:52:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-17 18:52:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-17 18:52:28 --> Config Class Initialized
INFO - 2023-07-17 18:52:28 --> Hooks Class Initialized
DEBUG - 2023-07-17 18:52:28 --> UTF-8 Support Enabled
INFO - 2023-07-17 18:52:28 --> Utf8 Class Initialized
INFO - 2023-07-17 18:52:28 --> URI Class Initialized
INFO - 2023-07-17 18:52:28 --> Router Class Initialized
INFO - 2023-07-17 18:52:28 --> Output Class Initialized
INFO - 2023-07-17 18:52:28 --> Security Class Initialized
DEBUG - 2023-07-17 18:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-17 18:52:28 --> Input Class Initialized
INFO - 2023-07-17 18:52:28 --> Language Class Initialized
INFO - 2023-07-17 18:52:28 --> Loader Class Initialized
INFO - 2023-07-17 18:52:28 --> Helper loaded: url_helper
INFO - 2023-07-17 18:52:28 --> Helper loaded: file_helper
INFO - 2023-07-17 18:52:28 --> Helper loaded: html_helper
INFO - 2023-07-17 18:52:28 --> Helper loaded: text_helper
INFO - 2023-07-17 18:52:28 --> Helper loaded: form_helper
INFO - 2023-07-17 18:52:28 --> Helper loaded: lang_helper
INFO - 2023-07-17 18:52:28 --> Helper loaded: security_helper
INFO - 2023-07-17 18:52:28 --> Helper loaded: cookie_helper
INFO - 2023-07-17 18:52:28 --> Database Driver Class Initialized
INFO - 2023-07-17 18:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-17 18:52:28 --> Parser Class Initialized
INFO - 2023-07-17 18:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-17 18:52:28 --> Pagination Class Initialized
INFO - 2023-07-17 18:52:28 --> Form Validation Class Initialized
INFO - 2023-07-17 18:52:28 --> Controller Class Initialized
INFO - 2023-07-17 18:52:28 --> Model Class Initialized
DEBUG - 2023-07-17 18:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-17 18:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-17 18:52:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-17 18:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-17 18:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-17 18:52:28 --> Model Class Initialized
INFO - 2023-07-17 18:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-17 18:52:28 --> Final output sent to browser
DEBUG - 2023-07-17 18:52:28 --> Total execution time: 0.0359
