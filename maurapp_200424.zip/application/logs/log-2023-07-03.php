<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-03 03:50:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 03:50:31 --> Config Class Initialized
INFO - 2023-07-03 03:50:31 --> Hooks Class Initialized
DEBUG - 2023-07-03 03:50:31 --> UTF-8 Support Enabled
INFO - 2023-07-03 03:50:31 --> Utf8 Class Initialized
INFO - 2023-07-03 03:50:31 --> URI Class Initialized
DEBUG - 2023-07-03 03:50:31 --> No URI present. Default controller set.
INFO - 2023-07-03 03:50:31 --> Router Class Initialized
INFO - 2023-07-03 03:50:31 --> Output Class Initialized
INFO - 2023-07-03 03:50:31 --> Security Class Initialized
DEBUG - 2023-07-03 03:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 03:50:31 --> Input Class Initialized
INFO - 2023-07-03 03:50:31 --> Language Class Initialized
INFO - 2023-07-03 03:50:31 --> Loader Class Initialized
INFO - 2023-07-03 03:50:31 --> Helper loaded: url_helper
INFO - 2023-07-03 03:50:31 --> Helper loaded: file_helper
INFO - 2023-07-03 03:50:31 --> Helper loaded: html_helper
INFO - 2023-07-03 03:50:31 --> Helper loaded: text_helper
INFO - 2023-07-03 03:50:31 --> Helper loaded: form_helper
INFO - 2023-07-03 03:50:31 --> Helper loaded: lang_helper
INFO - 2023-07-03 03:50:31 --> Helper loaded: security_helper
INFO - 2023-07-03 03:50:31 --> Helper loaded: cookie_helper
INFO - 2023-07-03 03:50:31 --> Database Driver Class Initialized
INFO - 2023-07-03 03:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 03:50:31 --> Parser Class Initialized
INFO - 2023-07-03 03:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 03:50:31 --> Pagination Class Initialized
INFO - 2023-07-03 03:50:31 --> Form Validation Class Initialized
INFO - 2023-07-03 03:50:31 --> Controller Class Initialized
INFO - 2023-07-03 03:50:31 --> Model Class Initialized
DEBUG - 2023-07-03 03:50:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 03:50:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 03:50:32 --> Config Class Initialized
INFO - 2023-07-03 03:50:32 --> Hooks Class Initialized
DEBUG - 2023-07-03 03:50:32 --> UTF-8 Support Enabled
INFO - 2023-07-03 03:50:32 --> Utf8 Class Initialized
INFO - 2023-07-03 03:50:32 --> URI Class Initialized
INFO - 2023-07-03 03:50:32 --> Router Class Initialized
INFO - 2023-07-03 03:50:32 --> Output Class Initialized
INFO - 2023-07-03 03:50:32 --> Security Class Initialized
DEBUG - 2023-07-03 03:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 03:50:32 --> Input Class Initialized
INFO - 2023-07-03 03:50:32 --> Language Class Initialized
INFO - 2023-07-03 03:50:32 --> Loader Class Initialized
INFO - 2023-07-03 03:50:32 --> Helper loaded: url_helper
INFO - 2023-07-03 03:50:32 --> Helper loaded: file_helper
INFO - 2023-07-03 03:50:32 --> Helper loaded: html_helper
INFO - 2023-07-03 03:50:32 --> Helper loaded: text_helper
INFO - 2023-07-03 03:50:32 --> Helper loaded: form_helper
INFO - 2023-07-03 03:50:32 --> Helper loaded: lang_helper
INFO - 2023-07-03 03:50:32 --> Helper loaded: security_helper
INFO - 2023-07-03 03:50:32 --> Helper loaded: cookie_helper
INFO - 2023-07-03 03:50:32 --> Database Driver Class Initialized
INFO - 2023-07-03 03:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 03:50:32 --> Parser Class Initialized
INFO - 2023-07-03 03:50:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 03:50:32 --> Pagination Class Initialized
INFO - 2023-07-03 03:50:32 --> Form Validation Class Initialized
INFO - 2023-07-03 03:50:32 --> Controller Class Initialized
INFO - 2023-07-03 03:50:32 --> Model Class Initialized
DEBUG - 2023-07-03 03:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 03:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 03:50:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 03:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 03:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 03:50:32 --> Model Class Initialized
INFO - 2023-07-03 03:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 03:50:32 --> Final output sent to browser
DEBUG - 2023-07-03 03:50:32 --> Total execution time: 0.0310
ERROR - 2023-07-03 05:14:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:03 --> Config Class Initialized
INFO - 2023-07-03 05:14:03 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:03 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:03 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:03 --> URI Class Initialized
INFO - 2023-07-03 05:14:03 --> Router Class Initialized
INFO - 2023-07-03 05:14:03 --> Output Class Initialized
INFO - 2023-07-03 05:14:03 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:03 --> Input Class Initialized
INFO - 2023-07-03 05:14:03 --> Language Class Initialized
INFO - 2023-07-03 05:14:03 --> Loader Class Initialized
INFO - 2023-07-03 05:14:03 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:03 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:03 --> Parser Class Initialized
INFO - 2023-07-03 05:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:03 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:03 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:03 --> Controller Class Initialized
ERROR - 2023-07-03 05:14:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:03 --> Config Class Initialized
INFO - 2023-07-03 05:14:03 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:03 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:03 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:03 --> URI Class Initialized
INFO - 2023-07-03 05:14:03 --> Router Class Initialized
INFO - 2023-07-03 05:14:03 --> Output Class Initialized
INFO - 2023-07-03 05:14:03 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:03 --> Input Class Initialized
INFO - 2023-07-03 05:14:03 --> Language Class Initialized
INFO - 2023-07-03 05:14:03 --> Loader Class Initialized
INFO - 2023-07-03 05:14:03 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:03 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:03 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:03 --> Parser Class Initialized
INFO - 2023-07-03 05:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:03 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:03 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:03 --> Controller Class Initialized
ERROR - 2023-07-03 05:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:07 --> Config Class Initialized
INFO - 2023-07-03 05:14:07 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:07 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:07 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:07 --> URI Class Initialized
INFO - 2023-07-03 05:14:07 --> Router Class Initialized
INFO - 2023-07-03 05:14:07 --> Output Class Initialized
INFO - 2023-07-03 05:14:07 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:07 --> Input Class Initialized
INFO - 2023-07-03 05:14:07 --> Language Class Initialized
INFO - 2023-07-03 05:14:07 --> Loader Class Initialized
INFO - 2023-07-03 05:14:07 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:07 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:07 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:07 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:07 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:07 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:07 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:07 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:07 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:07 --> Parser Class Initialized
INFO - 2023-07-03 05:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:07 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:07 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:07 --> Controller Class Initialized
ERROR - 2023-07-03 05:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:08 --> Config Class Initialized
INFO - 2023-07-03 05:14:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:08 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:08 --> URI Class Initialized
INFO - 2023-07-03 05:14:08 --> Router Class Initialized
INFO - 2023-07-03 05:14:08 --> Output Class Initialized
INFO - 2023-07-03 05:14:08 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:08 --> Input Class Initialized
INFO - 2023-07-03 05:14:08 --> Language Class Initialized
INFO - 2023-07-03 05:14:08 --> Loader Class Initialized
INFO - 2023-07-03 05:14:08 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:08 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:08 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:08 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:08 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:08 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:08 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:08 --> Parser Class Initialized
INFO - 2023-07-03 05:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:08 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:08 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:08 --> Controller Class Initialized
INFO - 2023-07-03 05:14:08 --> Model Class Initialized
DEBUG - 2023-07-03 05:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 05:14:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 05:14:08 --> Model Class Initialized
INFO - 2023-07-03 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 05:14:08 --> Final output sent to browser
DEBUG - 2023-07-03 05:14:08 --> Total execution time: 0.0290
ERROR - 2023-07-03 05:14:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:38 --> Config Class Initialized
INFO - 2023-07-03 05:14:38 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:38 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:38 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:38 --> URI Class Initialized
INFO - 2023-07-03 05:14:38 --> Router Class Initialized
INFO - 2023-07-03 05:14:38 --> Output Class Initialized
INFO - 2023-07-03 05:14:38 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:38 --> Input Class Initialized
INFO - 2023-07-03 05:14:38 --> Language Class Initialized
INFO - 2023-07-03 05:14:38 --> Loader Class Initialized
INFO - 2023-07-03 05:14:38 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:38 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:38 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:38 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:38 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:38 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:38 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:38 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:38 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:38 --> Parser Class Initialized
INFO - 2023-07-03 05:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:38 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:38 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:38 --> Controller Class Initialized
INFO - 2023-07-03 05:14:38 --> Model Class Initialized
DEBUG - 2023-07-03 05:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 05:14:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 05:14:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 05:14:38 --> Model Class Initialized
INFO - 2023-07-03 05:14:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 05:14:38 --> Final output sent to browser
DEBUG - 2023-07-03 05:14:38 --> Total execution time: 0.0307
ERROR - 2023-07-03 05:14:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:49 --> Config Class Initialized
INFO - 2023-07-03 05:14:49 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:49 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:49 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:49 --> URI Class Initialized
INFO - 2023-07-03 05:14:49 --> Router Class Initialized
INFO - 2023-07-03 05:14:49 --> Output Class Initialized
INFO - 2023-07-03 05:14:49 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:49 --> Input Class Initialized
INFO - 2023-07-03 05:14:49 --> Language Class Initialized
INFO - 2023-07-03 05:14:49 --> Loader Class Initialized
INFO - 2023-07-03 05:14:49 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:49 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:49 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:49 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:49 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:49 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:49 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:49 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:49 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:49 --> Parser Class Initialized
INFO - 2023-07-03 05:14:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:49 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:49 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:49 --> Controller Class Initialized
INFO - 2023-07-03 05:14:49 --> Model Class Initialized
DEBUG - 2023-07-03 05:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 05:14:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 05:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 05:14:49 --> Model Class Initialized
INFO - 2023-07-03 05:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 05:14:49 --> Final output sent to browser
DEBUG - 2023-07-03 05:14:49 --> Total execution time: 0.0285
ERROR - 2023-07-03 05:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:54 --> Config Class Initialized
INFO - 2023-07-03 05:14:54 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:54 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:54 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:54 --> URI Class Initialized
INFO - 2023-07-03 05:14:54 --> Router Class Initialized
INFO - 2023-07-03 05:14:54 --> Output Class Initialized
INFO - 2023-07-03 05:14:54 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:54 --> Input Class Initialized
INFO - 2023-07-03 05:14:54 --> Language Class Initialized
INFO - 2023-07-03 05:14:54 --> Loader Class Initialized
INFO - 2023-07-03 05:14:54 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:54 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:54 --> Parser Class Initialized
INFO - 2023-07-03 05:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:54 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:54 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:54 --> Controller Class Initialized
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
DEBUG - 2023-07-03 05:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
INFO - 2023-07-03 05:14:54 --> Final output sent to browser
DEBUG - 2023-07-03 05:14:54 --> Total execution time: 0.0175
ERROR - 2023-07-03 05:14:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:14:54 --> Config Class Initialized
INFO - 2023-07-03 05:14:54 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:14:54 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:14:54 --> Utf8 Class Initialized
INFO - 2023-07-03 05:14:54 --> URI Class Initialized
DEBUG - 2023-07-03 05:14:54 --> No URI present. Default controller set.
INFO - 2023-07-03 05:14:54 --> Router Class Initialized
INFO - 2023-07-03 05:14:54 --> Output Class Initialized
INFO - 2023-07-03 05:14:54 --> Security Class Initialized
DEBUG - 2023-07-03 05:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:14:54 --> Input Class Initialized
INFO - 2023-07-03 05:14:54 --> Language Class Initialized
INFO - 2023-07-03 05:14:54 --> Loader Class Initialized
INFO - 2023-07-03 05:14:54 --> Helper loaded: url_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: file_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: html_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: text_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: form_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: security_helper
INFO - 2023-07-03 05:14:54 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:14:54 --> Database Driver Class Initialized
INFO - 2023-07-03 05:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:14:54 --> Parser Class Initialized
INFO - 2023-07-03 05:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:14:54 --> Pagination Class Initialized
INFO - 2023-07-03 05:14:54 --> Form Validation Class Initialized
INFO - 2023-07-03 05:14:54 --> Controller Class Initialized
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
DEBUG - 2023-07-03 05:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
DEBUG - 2023-07-03 05:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
DEBUG - 2023-07-03 05:14:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 05:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
INFO - 2023-07-03 05:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 05:14:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 05:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 05:14:54 --> Model Class Initialized
INFO - 2023-07-03 05:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 05:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 05:14:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 05:14:54 --> Final output sent to browser
DEBUG - 2023-07-03 05:14:54 --> Total execution time: 0.0885
ERROR - 2023-07-03 05:15:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:15:05 --> Config Class Initialized
INFO - 2023-07-03 05:15:05 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:15:05 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:15:05 --> Utf8 Class Initialized
INFO - 2023-07-03 05:15:05 --> URI Class Initialized
INFO - 2023-07-03 05:15:05 --> Router Class Initialized
INFO - 2023-07-03 05:15:05 --> Output Class Initialized
INFO - 2023-07-03 05:15:05 --> Security Class Initialized
DEBUG - 2023-07-03 05:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:15:05 --> Input Class Initialized
INFO - 2023-07-03 05:15:05 --> Language Class Initialized
INFO - 2023-07-03 05:15:05 --> Loader Class Initialized
INFO - 2023-07-03 05:15:05 --> Helper loaded: url_helper
INFO - 2023-07-03 05:15:05 --> Helper loaded: file_helper
INFO - 2023-07-03 05:15:05 --> Helper loaded: html_helper
INFO - 2023-07-03 05:15:05 --> Helper loaded: text_helper
INFO - 2023-07-03 05:15:05 --> Helper loaded: form_helper
INFO - 2023-07-03 05:15:05 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:15:05 --> Helper loaded: security_helper
INFO - 2023-07-03 05:15:05 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:15:05 --> Database Driver Class Initialized
INFO - 2023-07-03 05:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:15:05 --> Parser Class Initialized
INFO - 2023-07-03 05:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:15:05 --> Pagination Class Initialized
INFO - 2023-07-03 05:15:05 --> Form Validation Class Initialized
INFO - 2023-07-03 05:15:05 --> Controller Class Initialized
INFO - 2023-07-03 05:15:05 --> Model Class Initialized
DEBUG - 2023-07-03 05:15:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 05:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:15:05 --> Model Class Initialized
DEBUG - 2023-07-03 05:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:15:05 --> Model Class Initialized
INFO - 2023-07-03 05:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 05:15:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 05:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 05:15:05 --> Model Class Initialized
INFO - 2023-07-03 05:15:05 --> Model Class Initialized
INFO - 2023-07-03 05:15:05 --> Model Class Initialized
INFO - 2023-07-03 05:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 05:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 05:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 05:15:05 --> Final output sent to browser
DEBUG - 2023-07-03 05:15:05 --> Total execution time: 0.0684
ERROR - 2023-07-03 05:15:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 05:15:06 --> Config Class Initialized
INFO - 2023-07-03 05:15:06 --> Hooks Class Initialized
DEBUG - 2023-07-03 05:15:06 --> UTF-8 Support Enabled
INFO - 2023-07-03 05:15:06 --> Utf8 Class Initialized
INFO - 2023-07-03 05:15:06 --> URI Class Initialized
INFO - 2023-07-03 05:15:06 --> Router Class Initialized
INFO - 2023-07-03 05:15:06 --> Output Class Initialized
INFO - 2023-07-03 05:15:06 --> Security Class Initialized
DEBUG - 2023-07-03 05:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 05:15:06 --> Input Class Initialized
INFO - 2023-07-03 05:15:06 --> Language Class Initialized
INFO - 2023-07-03 05:15:06 --> Loader Class Initialized
INFO - 2023-07-03 05:15:06 --> Helper loaded: url_helper
INFO - 2023-07-03 05:15:06 --> Helper loaded: file_helper
INFO - 2023-07-03 05:15:06 --> Helper loaded: html_helper
INFO - 2023-07-03 05:15:06 --> Helper loaded: text_helper
INFO - 2023-07-03 05:15:06 --> Helper loaded: form_helper
INFO - 2023-07-03 05:15:06 --> Helper loaded: lang_helper
INFO - 2023-07-03 05:15:06 --> Helper loaded: security_helper
INFO - 2023-07-03 05:15:06 --> Helper loaded: cookie_helper
INFO - 2023-07-03 05:15:06 --> Database Driver Class Initialized
INFO - 2023-07-03 05:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 05:15:06 --> Parser Class Initialized
INFO - 2023-07-03 05:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 05:15:06 --> Pagination Class Initialized
INFO - 2023-07-03 05:15:06 --> Form Validation Class Initialized
INFO - 2023-07-03 05:15:06 --> Controller Class Initialized
INFO - 2023-07-03 05:15:06 --> Model Class Initialized
DEBUG - 2023-07-03 05:15:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 05:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:15:06 --> Model Class Initialized
DEBUG - 2023-07-03 05:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 05:15:06 --> Model Class Initialized
INFO - 2023-07-03 05:15:06 --> Final output sent to browser
DEBUG - 2023-07-03 05:15:06 --> Total execution time: 0.0501
ERROR - 2023-07-03 06:16:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 06:16:13 --> Config Class Initialized
INFO - 2023-07-03 06:16:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 06:16:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 06:16:13 --> Utf8 Class Initialized
INFO - 2023-07-03 06:16:13 --> URI Class Initialized
DEBUG - 2023-07-03 06:16:13 --> No URI present. Default controller set.
INFO - 2023-07-03 06:16:13 --> Router Class Initialized
INFO - 2023-07-03 06:16:13 --> Output Class Initialized
INFO - 2023-07-03 06:16:13 --> Security Class Initialized
DEBUG - 2023-07-03 06:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 06:16:13 --> Input Class Initialized
INFO - 2023-07-03 06:16:13 --> Language Class Initialized
INFO - 2023-07-03 06:16:13 --> Loader Class Initialized
INFO - 2023-07-03 06:16:13 --> Helper loaded: url_helper
INFO - 2023-07-03 06:16:13 --> Helper loaded: file_helper
INFO - 2023-07-03 06:16:13 --> Helper loaded: html_helper
INFO - 2023-07-03 06:16:13 --> Helper loaded: text_helper
INFO - 2023-07-03 06:16:13 --> Helper loaded: form_helper
INFO - 2023-07-03 06:16:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 06:16:13 --> Helper loaded: security_helper
INFO - 2023-07-03 06:16:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 06:16:13 --> Database Driver Class Initialized
INFO - 2023-07-03 06:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 06:16:13 --> Parser Class Initialized
INFO - 2023-07-03 06:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 06:16:13 --> Pagination Class Initialized
INFO - 2023-07-03 06:16:13 --> Form Validation Class Initialized
INFO - 2023-07-03 06:16:13 --> Controller Class Initialized
INFO - 2023-07-03 06:16:13 --> Model Class Initialized
DEBUG - 2023-07-03 06:16:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 06:16:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 06:16:14 --> Config Class Initialized
INFO - 2023-07-03 06:16:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 06:16:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 06:16:14 --> Utf8 Class Initialized
INFO - 2023-07-03 06:16:14 --> URI Class Initialized
INFO - 2023-07-03 06:16:14 --> Router Class Initialized
INFO - 2023-07-03 06:16:14 --> Output Class Initialized
INFO - 2023-07-03 06:16:14 --> Security Class Initialized
DEBUG - 2023-07-03 06:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 06:16:14 --> Input Class Initialized
INFO - 2023-07-03 06:16:14 --> Language Class Initialized
INFO - 2023-07-03 06:16:14 --> Loader Class Initialized
INFO - 2023-07-03 06:16:14 --> Helper loaded: url_helper
INFO - 2023-07-03 06:16:14 --> Helper loaded: file_helper
INFO - 2023-07-03 06:16:14 --> Helper loaded: html_helper
INFO - 2023-07-03 06:16:14 --> Helper loaded: text_helper
INFO - 2023-07-03 06:16:14 --> Helper loaded: form_helper
INFO - 2023-07-03 06:16:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 06:16:14 --> Helper loaded: security_helper
INFO - 2023-07-03 06:16:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 06:16:14 --> Database Driver Class Initialized
INFO - 2023-07-03 06:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 06:16:14 --> Parser Class Initialized
INFO - 2023-07-03 06:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 06:16:14 --> Pagination Class Initialized
INFO - 2023-07-03 06:16:14 --> Form Validation Class Initialized
INFO - 2023-07-03 06:16:14 --> Controller Class Initialized
INFO - 2023-07-03 06:16:14 --> Model Class Initialized
DEBUG - 2023-07-03 06:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 06:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 06:16:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 06:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 06:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 06:16:14 --> Model Class Initialized
INFO - 2023-07-03 06:16:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 06:16:14 --> Final output sent to browser
DEBUG - 2023-07-03 06:16:14 --> Total execution time: 0.0308
ERROR - 2023-07-03 10:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:48:53 --> Config Class Initialized
INFO - 2023-07-03 10:48:53 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:48:53 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:48:53 --> Utf8 Class Initialized
INFO - 2023-07-03 10:48:53 --> URI Class Initialized
DEBUG - 2023-07-03 10:48:53 --> No URI present. Default controller set.
INFO - 2023-07-03 10:48:53 --> Router Class Initialized
INFO - 2023-07-03 10:48:53 --> Output Class Initialized
INFO - 2023-07-03 10:48:53 --> Security Class Initialized
DEBUG - 2023-07-03 10:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:48:53 --> Input Class Initialized
INFO - 2023-07-03 10:48:53 --> Language Class Initialized
INFO - 2023-07-03 10:48:53 --> Loader Class Initialized
INFO - 2023-07-03 10:48:53 --> Helper loaded: url_helper
INFO - 2023-07-03 10:48:53 --> Helper loaded: file_helper
INFO - 2023-07-03 10:48:53 --> Helper loaded: html_helper
INFO - 2023-07-03 10:48:53 --> Helper loaded: text_helper
INFO - 2023-07-03 10:48:53 --> Helper loaded: form_helper
INFO - 2023-07-03 10:48:53 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:48:53 --> Helper loaded: security_helper
INFO - 2023-07-03 10:48:53 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:48:53 --> Database Driver Class Initialized
INFO - 2023-07-03 10:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:48:53 --> Parser Class Initialized
INFO - 2023-07-03 10:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:48:53 --> Pagination Class Initialized
INFO - 2023-07-03 10:48:53 --> Form Validation Class Initialized
INFO - 2023-07-03 10:48:53 --> Controller Class Initialized
INFO - 2023-07-03 10:48:53 --> Model Class Initialized
DEBUG - 2023-07-03 10:48:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 10:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:48:54 --> Config Class Initialized
INFO - 2023-07-03 10:48:54 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:48:54 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:48:54 --> Utf8 Class Initialized
INFO - 2023-07-03 10:48:54 --> URI Class Initialized
INFO - 2023-07-03 10:48:54 --> Router Class Initialized
INFO - 2023-07-03 10:48:54 --> Output Class Initialized
INFO - 2023-07-03 10:48:54 --> Security Class Initialized
DEBUG - 2023-07-03 10:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:48:54 --> Input Class Initialized
INFO - 2023-07-03 10:48:54 --> Language Class Initialized
INFO - 2023-07-03 10:48:54 --> Loader Class Initialized
INFO - 2023-07-03 10:48:54 --> Helper loaded: url_helper
INFO - 2023-07-03 10:48:54 --> Helper loaded: file_helper
INFO - 2023-07-03 10:48:54 --> Helper loaded: html_helper
INFO - 2023-07-03 10:48:54 --> Helper loaded: text_helper
INFO - 2023-07-03 10:48:54 --> Helper loaded: form_helper
INFO - 2023-07-03 10:48:54 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:48:54 --> Helper loaded: security_helper
INFO - 2023-07-03 10:48:54 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:48:54 --> Database Driver Class Initialized
INFO - 2023-07-03 10:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:48:54 --> Parser Class Initialized
INFO - 2023-07-03 10:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:48:54 --> Pagination Class Initialized
INFO - 2023-07-03 10:48:54 --> Form Validation Class Initialized
INFO - 2023-07-03 10:48:54 --> Controller Class Initialized
INFO - 2023-07-03 10:48:54 --> Model Class Initialized
DEBUG - 2023-07-03 10:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 10:48:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:48:54 --> Model Class Initialized
INFO - 2023-07-03 10:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:48:54 --> Final output sent to browser
DEBUG - 2023-07-03 10:48:54 --> Total execution time: 0.0389
ERROR - 2023-07-03 10:49:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:08 --> Config Class Initialized
INFO - 2023-07-03 10:49:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:08 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:08 --> URI Class Initialized
INFO - 2023-07-03 10:49:08 --> Router Class Initialized
INFO - 2023-07-03 10:49:08 --> Output Class Initialized
INFO - 2023-07-03 10:49:08 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:08 --> Input Class Initialized
INFO - 2023-07-03 10:49:08 --> Language Class Initialized
INFO - 2023-07-03 10:49:08 --> Loader Class Initialized
INFO - 2023-07-03 10:49:08 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:08 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:08 --> Parser Class Initialized
INFO - 2023-07-03 10:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:08 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:08 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:08 --> Controller Class Initialized
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
INFO - 2023-07-03 10:49:08 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:08 --> Total execution time: 0.0207
ERROR - 2023-07-03 10:49:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:08 --> Config Class Initialized
INFO - 2023-07-03 10:49:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:08 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:08 --> URI Class Initialized
DEBUG - 2023-07-03 10:49:08 --> No URI present. Default controller set.
INFO - 2023-07-03 10:49:08 --> Router Class Initialized
INFO - 2023-07-03 10:49:08 --> Output Class Initialized
INFO - 2023-07-03 10:49:08 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:08 --> Input Class Initialized
INFO - 2023-07-03 10:49:08 --> Language Class Initialized
INFO - 2023-07-03 10:49:08 --> Loader Class Initialized
INFO - 2023-07-03 10:49:08 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:08 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:08 --> Parser Class Initialized
INFO - 2023-07-03 10:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:08 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:08 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:08 --> Controller Class Initialized
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
INFO - 2023-07-03 10:49:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:49:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:49:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:49:08 --> Model Class Initialized
INFO - 2023-07-03 10:49:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:49:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:49:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:49:08 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:08 --> Total execution time: 0.1951
ERROR - 2023-07-03 10:49:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:10 --> Config Class Initialized
INFO - 2023-07-03 10:49:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:10 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:10 --> URI Class Initialized
INFO - 2023-07-03 10:49:10 --> Router Class Initialized
INFO - 2023-07-03 10:49:10 --> Output Class Initialized
INFO - 2023-07-03 10:49:10 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:10 --> Input Class Initialized
INFO - 2023-07-03 10:49:10 --> Language Class Initialized
INFO - 2023-07-03 10:49:10 --> Loader Class Initialized
INFO - 2023-07-03 10:49:10 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:10 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:10 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:10 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:10 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:10 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:10 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:10 --> Parser Class Initialized
INFO - 2023-07-03 10:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:10 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:10 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:10 --> Controller Class Initialized
DEBUG - 2023-07-03 10:49:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:10 --> Model Class Initialized
INFO - 2023-07-03 10:49:10 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:10 --> Total execution time: 0.0133
ERROR - 2023-07-03 10:49:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:19 --> Config Class Initialized
INFO - 2023-07-03 10:49:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:19 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:19 --> URI Class Initialized
DEBUG - 2023-07-03 10:49:19 --> No URI present. Default controller set.
INFO - 2023-07-03 10:49:19 --> Router Class Initialized
INFO - 2023-07-03 10:49:19 --> Output Class Initialized
INFO - 2023-07-03 10:49:19 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:19 --> Input Class Initialized
INFO - 2023-07-03 10:49:19 --> Language Class Initialized
INFO - 2023-07-03 10:49:19 --> Loader Class Initialized
INFO - 2023-07-03 10:49:19 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:19 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:19 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:19 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:19 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:19 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:19 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:19 --> Parser Class Initialized
INFO - 2023-07-03 10:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:19 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:19 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:19 --> Controller Class Initialized
INFO - 2023-07-03 10:49:19 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 10:49:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:20 --> Config Class Initialized
INFO - 2023-07-03 10:49:20 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:20 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:20 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:20 --> URI Class Initialized
INFO - 2023-07-03 10:49:20 --> Router Class Initialized
INFO - 2023-07-03 10:49:20 --> Output Class Initialized
INFO - 2023-07-03 10:49:20 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:20 --> Input Class Initialized
INFO - 2023-07-03 10:49:20 --> Language Class Initialized
INFO - 2023-07-03 10:49:20 --> Loader Class Initialized
INFO - 2023-07-03 10:49:20 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:20 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:20 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:20 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:20 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:20 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:20 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:20 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:20 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:20 --> Parser Class Initialized
INFO - 2023-07-03 10:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:20 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:20 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:20 --> Controller Class Initialized
INFO - 2023-07-03 10:49:20 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 10:49:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:49:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:49:20 --> Model Class Initialized
INFO - 2023-07-03 10:49:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:49:20 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:20 --> Total execution time: 0.0290
ERROR - 2023-07-03 10:49:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:28 --> Config Class Initialized
INFO - 2023-07-03 10:49:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:28 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:28 --> URI Class Initialized
INFO - 2023-07-03 10:49:28 --> Router Class Initialized
INFO - 2023-07-03 10:49:28 --> Output Class Initialized
INFO - 2023-07-03 10:49:28 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:28 --> Input Class Initialized
INFO - 2023-07-03 10:49:28 --> Language Class Initialized
INFO - 2023-07-03 10:49:28 --> Loader Class Initialized
INFO - 2023-07-03 10:49:28 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:28 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:28 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:28 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:28 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:28 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:28 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:28 --> Parser Class Initialized
INFO - 2023-07-03 10:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:28 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:28 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:28 --> Controller Class Initialized
INFO - 2023-07-03 10:49:28 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:28 --> Model Class Initialized
INFO - 2023-07-03 10:49:28 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:28 --> Total execution time: 0.0162
ERROR - 2023-07-03 10:49:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:29 --> Config Class Initialized
INFO - 2023-07-03 10:49:29 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:29 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:29 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:29 --> URI Class Initialized
DEBUG - 2023-07-03 10:49:29 --> No URI present. Default controller set.
INFO - 2023-07-03 10:49:29 --> Router Class Initialized
INFO - 2023-07-03 10:49:29 --> Output Class Initialized
INFO - 2023-07-03 10:49:29 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:29 --> Input Class Initialized
INFO - 2023-07-03 10:49:29 --> Language Class Initialized
INFO - 2023-07-03 10:49:29 --> Loader Class Initialized
INFO - 2023-07-03 10:49:29 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:29 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:29 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:29 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:29 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:29 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:29 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:29 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:29 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:29 --> Parser Class Initialized
INFO - 2023-07-03 10:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:29 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:29 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:29 --> Controller Class Initialized
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
INFO - 2023-07-03 10:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:49:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:49:29 --> Model Class Initialized
INFO - 2023-07-03 10:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:49:29 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:29 --> Total execution time: 0.0950
ERROR - 2023-07-03 10:49:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:47 --> Config Class Initialized
INFO - 2023-07-03 10:49:47 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:47 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:47 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:47 --> URI Class Initialized
INFO - 2023-07-03 10:49:47 --> Router Class Initialized
INFO - 2023-07-03 10:49:47 --> Output Class Initialized
INFO - 2023-07-03 10:49:47 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:47 --> Input Class Initialized
INFO - 2023-07-03 10:49:47 --> Language Class Initialized
INFO - 2023-07-03 10:49:47 --> Loader Class Initialized
INFO - 2023-07-03 10:49:47 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:47 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:47 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:47 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:47 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:47 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:47 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:47 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:47 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:47 --> Parser Class Initialized
INFO - 2023-07-03 10:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:47 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:47 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:47 --> Controller Class Initialized
INFO - 2023-07-03 10:49:47 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:47 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:47 --> Model Class Initialized
INFO - 2023-07-03 10:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 10:49:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:49:47 --> Model Class Initialized
INFO - 2023-07-03 10:49:47 --> Model Class Initialized
INFO - 2023-07-03 10:49:47 --> Model Class Initialized
INFO - 2023-07-03 10:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:49:47 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:47 --> Total execution time: 0.0813
ERROR - 2023-07-03 10:49:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:49:48 --> Config Class Initialized
INFO - 2023-07-03 10:49:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:49:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:49:48 --> Utf8 Class Initialized
INFO - 2023-07-03 10:49:48 --> URI Class Initialized
INFO - 2023-07-03 10:49:48 --> Router Class Initialized
INFO - 2023-07-03 10:49:48 --> Output Class Initialized
INFO - 2023-07-03 10:49:48 --> Security Class Initialized
DEBUG - 2023-07-03 10:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:49:48 --> Input Class Initialized
INFO - 2023-07-03 10:49:48 --> Language Class Initialized
INFO - 2023-07-03 10:49:48 --> Loader Class Initialized
INFO - 2023-07-03 10:49:48 --> Helper loaded: url_helper
INFO - 2023-07-03 10:49:48 --> Helper loaded: file_helper
INFO - 2023-07-03 10:49:48 --> Helper loaded: html_helper
INFO - 2023-07-03 10:49:48 --> Helper loaded: text_helper
INFO - 2023-07-03 10:49:48 --> Helper loaded: form_helper
INFO - 2023-07-03 10:49:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:49:48 --> Helper loaded: security_helper
INFO - 2023-07-03 10:49:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:49:48 --> Database Driver Class Initialized
INFO - 2023-07-03 10:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:49:48 --> Parser Class Initialized
INFO - 2023-07-03 10:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:49:48 --> Pagination Class Initialized
INFO - 2023-07-03 10:49:48 --> Form Validation Class Initialized
INFO - 2023-07-03 10:49:48 --> Controller Class Initialized
INFO - 2023-07-03 10:49:48 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:48 --> Model Class Initialized
DEBUG - 2023-07-03 10:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:49:48 --> Model Class Initialized
INFO - 2023-07-03 10:49:48 --> Final output sent to browser
DEBUG - 2023-07-03 10:49:48 --> Total execution time: 0.0650
ERROR - 2023-07-03 10:50:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:05 --> Config Class Initialized
INFO - 2023-07-03 10:50:05 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:05 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:05 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:05 --> URI Class Initialized
INFO - 2023-07-03 10:50:05 --> Router Class Initialized
INFO - 2023-07-03 10:50:05 --> Output Class Initialized
INFO - 2023-07-03 10:50:05 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:05 --> Input Class Initialized
INFO - 2023-07-03 10:50:05 --> Language Class Initialized
INFO - 2023-07-03 10:50:05 --> Loader Class Initialized
INFO - 2023-07-03 10:50:05 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:05 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:05 --> Parser Class Initialized
INFO - 2023-07-03 10:50:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:05 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:05 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:05 --> Controller Class Initialized
INFO - 2023-07-03 10:50:05 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:05 --> Model Class Initialized
INFO - 2023-07-03 10:50:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-03 10:50:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:50:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:50:05 --> Model Class Initialized
INFO - 2023-07-03 10:50:05 --> Model Class Initialized
INFO - 2023-07-03 10:50:05 --> Model Class Initialized
INFO - 2023-07-03 10:50:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:50:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:50:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:50:05 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:05 --> Total execution time: 0.0610
ERROR - 2023-07-03 10:50:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:05 --> Config Class Initialized
INFO - 2023-07-03 10:50:05 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:05 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:05 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:05 --> URI Class Initialized
INFO - 2023-07-03 10:50:05 --> Router Class Initialized
INFO - 2023-07-03 10:50:05 --> Output Class Initialized
INFO - 2023-07-03 10:50:05 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:05 --> Input Class Initialized
INFO - 2023-07-03 10:50:05 --> Language Class Initialized
INFO - 2023-07-03 10:50:05 --> Loader Class Initialized
INFO - 2023-07-03 10:50:05 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:05 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:05 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:05 --> Parser Class Initialized
INFO - 2023-07-03 10:50:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:05 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:05 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:05 --> Controller Class Initialized
INFO - 2023-07-03 10:50:05 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:05 --> Model Class Initialized
INFO - 2023-07-03 10:50:05 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:05 --> Total execution time: 0.0196
ERROR - 2023-07-03 10:50:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:18 --> Config Class Initialized
INFO - 2023-07-03 10:50:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:18 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:18 --> URI Class Initialized
INFO - 2023-07-03 10:50:18 --> Router Class Initialized
INFO - 2023-07-03 10:50:18 --> Output Class Initialized
INFO - 2023-07-03 10:50:18 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:18 --> Input Class Initialized
INFO - 2023-07-03 10:50:18 --> Language Class Initialized
INFO - 2023-07-03 10:50:18 --> Loader Class Initialized
INFO - 2023-07-03 10:50:18 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:18 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:18 --> Parser Class Initialized
INFO - 2023-07-03 10:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:18 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:18 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:18 --> Controller Class Initialized
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
INFO - 2023-07-03 10:50:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 10:50:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:50:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
INFO - 2023-07-03 10:50:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:50:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:50:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:50:18 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:18 --> Total execution time: 0.0759
ERROR - 2023-07-03 10:50:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:18 --> Config Class Initialized
INFO - 2023-07-03 10:50:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:18 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:18 --> URI Class Initialized
INFO - 2023-07-03 10:50:18 --> Router Class Initialized
INFO - 2023-07-03 10:50:18 --> Output Class Initialized
INFO - 2023-07-03 10:50:18 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:18 --> Input Class Initialized
INFO - 2023-07-03 10:50:18 --> Language Class Initialized
INFO - 2023-07-03 10:50:18 --> Loader Class Initialized
INFO - 2023-07-03 10:50:18 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:18 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:18 --> Parser Class Initialized
INFO - 2023-07-03 10:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:18 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:18 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:18 --> Controller Class Initialized
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:18 --> Model Class Initialized
INFO - 2023-07-03 10:50:18 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:18 --> Total execution time: 0.0498
ERROR - 2023-07-03 10:50:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:22 --> Config Class Initialized
INFO - 2023-07-03 10:50:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:22 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:22 --> URI Class Initialized
INFO - 2023-07-03 10:50:22 --> Router Class Initialized
INFO - 2023-07-03 10:50:22 --> Output Class Initialized
INFO - 2023-07-03 10:50:22 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:22 --> Input Class Initialized
INFO - 2023-07-03 10:50:22 --> Language Class Initialized
INFO - 2023-07-03 10:50:22 --> Loader Class Initialized
INFO - 2023-07-03 10:50:22 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:22 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:22 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:22 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:22 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:22 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:22 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:22 --> Parser Class Initialized
INFO - 2023-07-03 10:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:22 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:22 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:22 --> Controller Class Initialized
INFO - 2023-07-03 10:50:22 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:22 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:22 --> Model Class Initialized
INFO - 2023-07-03 10:50:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 10:50:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:50:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:50:22 --> Model Class Initialized
INFO - 2023-07-03 10:50:22 --> Model Class Initialized
INFO - 2023-07-03 10:50:22 --> Model Class Initialized
INFO - 2023-07-03 10:50:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:50:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:50:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:50:22 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:22 --> Total execution time: 0.0790
ERROR - 2023-07-03 10:50:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:23 --> Config Class Initialized
INFO - 2023-07-03 10:50:23 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:23 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:23 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:23 --> URI Class Initialized
INFO - 2023-07-03 10:50:23 --> Router Class Initialized
INFO - 2023-07-03 10:50:23 --> Output Class Initialized
INFO - 2023-07-03 10:50:23 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:23 --> Input Class Initialized
INFO - 2023-07-03 10:50:23 --> Language Class Initialized
INFO - 2023-07-03 10:50:23 --> Loader Class Initialized
INFO - 2023-07-03 10:50:23 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:23 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:23 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:23 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:23 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:23 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:23 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:23 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:23 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:23 --> Parser Class Initialized
INFO - 2023-07-03 10:50:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:23 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:23 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:23 --> Controller Class Initialized
INFO - 2023-07-03 10:50:23 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:23 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:23 --> Model Class Initialized
INFO - 2023-07-03 10:50:23 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:23 --> Total execution time: 0.0241
ERROR - 2023-07-03 10:50:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:29 --> Config Class Initialized
INFO - 2023-07-03 10:50:29 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:29 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:29 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:29 --> URI Class Initialized
INFO - 2023-07-03 10:50:29 --> Router Class Initialized
INFO - 2023-07-03 10:50:29 --> Output Class Initialized
INFO - 2023-07-03 10:50:29 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:29 --> Input Class Initialized
INFO - 2023-07-03 10:50:29 --> Language Class Initialized
INFO - 2023-07-03 10:50:29 --> Loader Class Initialized
INFO - 2023-07-03 10:50:29 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:29 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:29 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:29 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:29 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:29 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:29 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:29 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:29 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:29 --> Parser Class Initialized
INFO - 2023-07-03 10:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:29 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:29 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:29 --> Controller Class Initialized
INFO - 2023-07-03 10:50:29 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:29 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:29 --> Model Class Initialized
INFO - 2023-07-03 10:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 10:50:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:50:29 --> Model Class Initialized
INFO - 2023-07-03 10:50:29 --> Model Class Initialized
INFO - 2023-07-03 10:50:29 --> Model Class Initialized
INFO - 2023-07-03 10:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:50:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:50:29 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:29 --> Total execution time: 0.0752
ERROR - 2023-07-03 10:50:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:30 --> Config Class Initialized
INFO - 2023-07-03 10:50:30 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:30 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:30 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:30 --> URI Class Initialized
INFO - 2023-07-03 10:50:30 --> Router Class Initialized
INFO - 2023-07-03 10:50:30 --> Output Class Initialized
INFO - 2023-07-03 10:50:30 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:30 --> Input Class Initialized
INFO - 2023-07-03 10:50:30 --> Language Class Initialized
INFO - 2023-07-03 10:50:30 --> Loader Class Initialized
INFO - 2023-07-03 10:50:30 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:30 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:30 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:30 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:30 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:30 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:30 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:30 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:30 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:30 --> Parser Class Initialized
INFO - 2023-07-03 10:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:30 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:30 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:30 --> Controller Class Initialized
INFO - 2023-07-03 10:50:30 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:30 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:30 --> Model Class Initialized
INFO - 2023-07-03 10:50:30 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:30 --> Total execution time: 0.0436
ERROR - 2023-07-03 10:50:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:47 --> Config Class Initialized
INFO - 2023-07-03 10:50:47 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:47 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:47 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:47 --> URI Class Initialized
INFO - 2023-07-03 10:50:47 --> Router Class Initialized
INFO - 2023-07-03 10:50:47 --> Output Class Initialized
INFO - 2023-07-03 10:50:47 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:47 --> Input Class Initialized
INFO - 2023-07-03 10:50:47 --> Language Class Initialized
INFO - 2023-07-03 10:50:47 --> Loader Class Initialized
INFO - 2023-07-03 10:50:47 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:47 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:47 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:47 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:47 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:47 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:47 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:47 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:47 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:47 --> Parser Class Initialized
INFO - 2023-07-03 10:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:47 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:47 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:47 --> Controller Class Initialized
INFO - 2023-07-03 10:50:47 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:47 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:47 --> Total execution time: 0.0140
ERROR - 2023-07-03 10:50:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:48 --> Config Class Initialized
INFO - 2023-07-03 10:50:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:48 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:48 --> URI Class Initialized
INFO - 2023-07-03 10:50:48 --> Router Class Initialized
INFO - 2023-07-03 10:50:48 --> Output Class Initialized
INFO - 2023-07-03 10:50:48 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:48 --> Input Class Initialized
INFO - 2023-07-03 10:50:48 --> Language Class Initialized
INFO - 2023-07-03 10:50:48 --> Loader Class Initialized
INFO - 2023-07-03 10:50:48 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:48 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:48 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:48 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:48 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:48 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:48 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:48 --> Parser Class Initialized
INFO - 2023-07-03 10:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:48 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:48 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:48 --> Controller Class Initialized
INFO - 2023-07-03 10:50:48 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 10:50:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:50:48 --> Model Class Initialized
INFO - 2023-07-03 10:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:50:48 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:48 --> Total execution time: 0.0332
ERROR - 2023-07-03 10:50:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:50:59 --> Config Class Initialized
INFO - 2023-07-03 10:50:59 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:50:59 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:50:59 --> Utf8 Class Initialized
INFO - 2023-07-03 10:50:59 --> URI Class Initialized
INFO - 2023-07-03 10:50:59 --> Router Class Initialized
INFO - 2023-07-03 10:50:59 --> Output Class Initialized
INFO - 2023-07-03 10:50:59 --> Security Class Initialized
DEBUG - 2023-07-03 10:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:50:59 --> Input Class Initialized
INFO - 2023-07-03 10:50:59 --> Language Class Initialized
INFO - 2023-07-03 10:50:59 --> Loader Class Initialized
INFO - 2023-07-03 10:50:59 --> Helper loaded: url_helper
INFO - 2023-07-03 10:50:59 --> Helper loaded: file_helper
INFO - 2023-07-03 10:50:59 --> Helper loaded: html_helper
INFO - 2023-07-03 10:50:59 --> Helper loaded: text_helper
INFO - 2023-07-03 10:50:59 --> Helper loaded: form_helper
INFO - 2023-07-03 10:50:59 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:50:59 --> Helper loaded: security_helper
INFO - 2023-07-03 10:50:59 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:50:59 --> Database Driver Class Initialized
INFO - 2023-07-03 10:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:50:59 --> Parser Class Initialized
INFO - 2023-07-03 10:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:50:59 --> Pagination Class Initialized
INFO - 2023-07-03 10:50:59 --> Form Validation Class Initialized
INFO - 2023-07-03 10:50:59 --> Controller Class Initialized
DEBUG - 2023-07-03 10:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:59 --> Model Class Initialized
INFO - 2023-07-03 10:50:59 --> Model Class Initialized
DEBUG - 2023-07-03 10:50:59 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:59 --> Model Class Initialized
INFO - 2023-07-03 10:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-07-03 10:50:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:50:59 --> Model Class Initialized
INFO - 2023-07-03 10:50:59 --> Model Class Initialized
INFO - 2023-07-03 10:50:59 --> Model Class Initialized
INFO - 2023-07-03 10:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:50:59 --> Final output sent to browser
DEBUG - 2023-07-03 10:50:59 --> Total execution time: 0.1431
ERROR - 2023-07-03 10:51:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:00 --> Config Class Initialized
INFO - 2023-07-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:00 --> URI Class Initialized
INFO - 2023-07-03 10:51:00 --> Router Class Initialized
INFO - 2023-07-03 10:51:00 --> Output Class Initialized
INFO - 2023-07-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:00 --> Input Class Initialized
INFO - 2023-07-03 10:51:00 --> Language Class Initialized
INFO - 2023-07-03 10:51:00 --> Loader Class Initialized
INFO - 2023-07-03 10:51:00 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:00 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:00 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:00 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:00 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:00 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:00 --> Parser Class Initialized
INFO - 2023-07-03 10:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:00 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:00 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:00 --> Controller Class Initialized
DEBUG - 2023-07-03 10:51:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:00 --> Model Class Initialized
INFO - 2023-07-03 10:51:00 --> Model Class Initialized
INFO - 2023-07-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:00 --> Total execution time: 0.0205
ERROR - 2023-07-03 10:51:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:10 --> Config Class Initialized
INFO - 2023-07-03 10:51:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:10 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:10 --> URI Class Initialized
INFO - 2023-07-03 10:51:10 --> Router Class Initialized
INFO - 2023-07-03 10:51:10 --> Output Class Initialized
INFO - 2023-07-03 10:51:10 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:10 --> Input Class Initialized
INFO - 2023-07-03 10:51:10 --> Language Class Initialized
INFO - 2023-07-03 10:51:10 --> Loader Class Initialized
INFO - 2023-07-03 10:51:10 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:10 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:10 --> Parser Class Initialized
INFO - 2023-07-03 10:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:10 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:10 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:10 --> Controller Class Initialized
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
INFO - 2023-07-03 10:51:10 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:10 --> Total execution time: 0.0199
ERROR - 2023-07-03 10:51:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:10 --> Config Class Initialized
INFO - 2023-07-03 10:51:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:10 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:10 --> URI Class Initialized
DEBUG - 2023-07-03 10:51:10 --> No URI present. Default controller set.
INFO - 2023-07-03 10:51:10 --> Router Class Initialized
INFO - 2023-07-03 10:51:10 --> Output Class Initialized
INFO - 2023-07-03 10:51:10 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:10 --> Input Class Initialized
INFO - 2023-07-03 10:51:10 --> Language Class Initialized
INFO - 2023-07-03 10:51:10 --> Loader Class Initialized
INFO - 2023-07-03 10:51:10 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:10 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:10 --> Parser Class Initialized
INFO - 2023-07-03 10:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:10 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:10 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:10 --> Controller Class Initialized
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
INFO - 2023-07-03 10:51:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:51:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:51:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:51:10 --> Model Class Initialized
INFO - 2023-07-03 10:51:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:51:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:51:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:51:10 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:10 --> Total execution time: 0.0842
ERROR - 2023-07-03 10:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:17 --> Config Class Initialized
INFO - 2023-07-03 10:51:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:17 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:17 --> URI Class Initialized
INFO - 2023-07-03 10:51:17 --> Router Class Initialized
INFO - 2023-07-03 10:51:17 --> Output Class Initialized
INFO - 2023-07-03 10:51:17 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:17 --> Input Class Initialized
INFO - 2023-07-03 10:51:17 --> Language Class Initialized
INFO - 2023-07-03 10:51:17 --> Loader Class Initialized
INFO - 2023-07-03 10:51:17 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:17 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:17 --> Parser Class Initialized
INFO - 2023-07-03 10:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:17 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:17 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:17 --> Controller Class Initialized
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
INFO - 2023-07-03 10:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 10:51:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
INFO - 2023-07-03 10:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:51:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:51:17 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:17 --> Total execution time: 0.0825
ERROR - 2023-07-03 10:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:17 --> Config Class Initialized
INFO - 2023-07-03 10:51:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:17 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:17 --> URI Class Initialized
INFO - 2023-07-03 10:51:17 --> Router Class Initialized
INFO - 2023-07-03 10:51:17 --> Output Class Initialized
INFO - 2023-07-03 10:51:17 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:17 --> Input Class Initialized
INFO - 2023-07-03 10:51:17 --> Language Class Initialized
INFO - 2023-07-03 10:51:17 --> Loader Class Initialized
INFO - 2023-07-03 10:51:17 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:17 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:17 --> Parser Class Initialized
INFO - 2023-07-03 10:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:17 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:17 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:17 --> Controller Class Initialized
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:17 --> Model Class Initialized
INFO - 2023-07-03 10:51:17 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:17 --> Total execution time: 0.0489
ERROR - 2023-07-03 10:51:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:25 --> Config Class Initialized
INFO - 2023-07-03 10:51:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:25 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:25 --> URI Class Initialized
INFO - 2023-07-03 10:51:25 --> Router Class Initialized
INFO - 2023-07-03 10:51:25 --> Output Class Initialized
INFO - 2023-07-03 10:51:25 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:25 --> Input Class Initialized
INFO - 2023-07-03 10:51:25 --> Language Class Initialized
INFO - 2023-07-03 10:51:25 --> Loader Class Initialized
INFO - 2023-07-03 10:51:25 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:25 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:25 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:25 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:25 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:25 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:25 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:25 --> Parser Class Initialized
INFO - 2023-07-03 10:51:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:25 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:25 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:25 --> Controller Class Initialized
INFO - 2023-07-03 10:51:25 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:25 --> Model Class Initialized
INFO - 2023-07-03 10:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-07-03 10:51:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:51:25 --> Model Class Initialized
INFO - 2023-07-03 10:51:25 --> Model Class Initialized
INFO - 2023-07-03 10:51:25 --> Model Class Initialized
INFO - 2023-07-03 10:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:51:25 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:25 --> Total execution time: 0.0654
ERROR - 2023-07-03 10:51:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:26 --> Config Class Initialized
INFO - 2023-07-03 10:51:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:26 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:26 --> URI Class Initialized
INFO - 2023-07-03 10:51:26 --> Router Class Initialized
INFO - 2023-07-03 10:51:26 --> Output Class Initialized
INFO - 2023-07-03 10:51:26 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:26 --> Input Class Initialized
INFO - 2023-07-03 10:51:26 --> Language Class Initialized
INFO - 2023-07-03 10:51:26 --> Loader Class Initialized
INFO - 2023-07-03 10:51:26 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:26 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:26 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:26 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:26 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:26 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:26 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:26 --> Parser Class Initialized
INFO - 2023-07-03 10:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:26 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:26 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:26 --> Controller Class Initialized
INFO - 2023-07-03 10:51:26 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:26 --> Model Class Initialized
INFO - 2023-07-03 10:51:26 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:26 --> Total execution time: 0.0172
ERROR - 2023-07-03 10:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:27 --> Config Class Initialized
INFO - 2023-07-03 10:51:27 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:27 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:27 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:27 --> URI Class Initialized
INFO - 2023-07-03 10:51:27 --> Router Class Initialized
INFO - 2023-07-03 10:51:27 --> Output Class Initialized
INFO - 2023-07-03 10:51:27 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:27 --> Input Class Initialized
INFO - 2023-07-03 10:51:27 --> Language Class Initialized
INFO - 2023-07-03 10:51:27 --> Loader Class Initialized
INFO - 2023-07-03 10:51:27 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:27 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:27 --> Parser Class Initialized
INFO - 2023-07-03 10:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:27 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:27 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:27 --> Controller Class Initialized
INFO - 2023-07-03 10:51:27 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:27 --> Model Class Initialized
INFO - 2023-07-03 10:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-03 10:51:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:51:27 --> Model Class Initialized
INFO - 2023-07-03 10:51:27 --> Model Class Initialized
INFO - 2023-07-03 10:51:27 --> Model Class Initialized
INFO - 2023-07-03 10:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:51:27 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:27 --> Total execution time: 0.0640
ERROR - 2023-07-03 10:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:27 --> Config Class Initialized
INFO - 2023-07-03 10:51:27 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:27 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:27 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:27 --> URI Class Initialized
INFO - 2023-07-03 10:51:27 --> Router Class Initialized
INFO - 2023-07-03 10:51:27 --> Output Class Initialized
INFO - 2023-07-03 10:51:27 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:27 --> Input Class Initialized
INFO - 2023-07-03 10:51:27 --> Language Class Initialized
INFO - 2023-07-03 10:51:27 --> Loader Class Initialized
INFO - 2023-07-03 10:51:27 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:27 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:27 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:27 --> Parser Class Initialized
INFO - 2023-07-03 10:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:27 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:27 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:27 --> Controller Class Initialized
INFO - 2023-07-03 10:51:27 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:27 --> Model Class Initialized
INFO - 2023-07-03 10:51:27 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:27 --> Total execution time: 0.0272
ERROR - 2023-07-03 10:51:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:42 --> Config Class Initialized
INFO - 2023-07-03 10:51:42 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:42 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:42 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:42 --> URI Class Initialized
INFO - 2023-07-03 10:51:42 --> Router Class Initialized
INFO - 2023-07-03 10:51:42 --> Output Class Initialized
INFO - 2023-07-03 10:51:42 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:42 --> Input Class Initialized
INFO - 2023-07-03 10:51:42 --> Language Class Initialized
INFO - 2023-07-03 10:51:42 --> Loader Class Initialized
INFO - 2023-07-03 10:51:42 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:42 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:42 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:42 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:42 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:42 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:42 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:42 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:42 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:42 --> Parser Class Initialized
INFO - 2023-07-03 10:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:42 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:42 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:42 --> Controller Class Initialized
INFO - 2023-07-03 10:51:42 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:42 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:42 --> Model Class Initialized
INFO - 2023-07-03 10:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-03 10:51:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:51:42 --> Model Class Initialized
INFO - 2023-07-03 10:51:42 --> Model Class Initialized
INFO - 2023-07-03 10:51:42 --> Model Class Initialized
INFO - 2023-07-03 10:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:51:42 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:42 --> Total execution time: 0.1052
ERROR - 2023-07-03 10:51:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:45 --> Config Class Initialized
INFO - 2023-07-03 10:51:45 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:45 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:45 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:45 --> URI Class Initialized
INFO - 2023-07-03 10:51:45 --> Router Class Initialized
INFO - 2023-07-03 10:51:45 --> Output Class Initialized
INFO - 2023-07-03 10:51:45 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:45 --> Input Class Initialized
INFO - 2023-07-03 10:51:45 --> Language Class Initialized
INFO - 2023-07-03 10:51:45 --> Loader Class Initialized
INFO - 2023-07-03 10:51:45 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:45 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:45 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:45 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:45 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:45 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:45 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:45 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:45 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:45 --> Parser Class Initialized
INFO - 2023-07-03 10:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:45 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:45 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:45 --> Controller Class Initialized
INFO - 2023-07-03 10:51:45 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:45 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:45 --> Total execution time: 0.0162
ERROR - 2023-07-03 10:51:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:46 --> Config Class Initialized
INFO - 2023-07-03 10:51:46 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:46 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:46 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:46 --> URI Class Initialized
INFO - 2023-07-03 10:51:46 --> Router Class Initialized
INFO - 2023-07-03 10:51:46 --> Output Class Initialized
INFO - 2023-07-03 10:51:46 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:46 --> Input Class Initialized
INFO - 2023-07-03 10:51:46 --> Language Class Initialized
INFO - 2023-07-03 10:51:46 --> Loader Class Initialized
INFO - 2023-07-03 10:51:46 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:46 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:46 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:46 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:46 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:46 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:46 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:46 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:46 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:46 --> Parser Class Initialized
INFO - 2023-07-03 10:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:46 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:46 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:46 --> Controller Class Initialized
INFO - 2023-07-03 10:51:46 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:46 --> Total execution time: 0.0144
ERROR - 2023-07-03 10:51:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:48 --> Config Class Initialized
INFO - 2023-07-03 10:51:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:48 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:48 --> URI Class Initialized
INFO - 2023-07-03 10:51:48 --> Router Class Initialized
INFO - 2023-07-03 10:51:48 --> Output Class Initialized
INFO - 2023-07-03 10:51:48 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:48 --> Input Class Initialized
INFO - 2023-07-03 10:51:48 --> Language Class Initialized
INFO - 2023-07-03 10:51:48 --> Loader Class Initialized
INFO - 2023-07-03 10:51:48 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:48 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:48 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:48 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:48 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:48 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:48 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:48 --> Parser Class Initialized
INFO - 2023-07-03 10:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:48 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:48 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:48 --> Controller Class Initialized
INFO - 2023-07-03 10:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:48 --> Model Class Initialized
INFO - 2023-07-03 10:51:48 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:48 --> Total execution time: 0.0195
ERROR - 2023-07-03 10:51:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:50 --> Config Class Initialized
INFO - 2023-07-03 10:51:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:50 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:50 --> URI Class Initialized
INFO - 2023-07-03 10:51:50 --> Router Class Initialized
INFO - 2023-07-03 10:51:50 --> Output Class Initialized
INFO - 2023-07-03 10:51:50 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:50 --> Input Class Initialized
INFO - 2023-07-03 10:51:50 --> Language Class Initialized
INFO - 2023-07-03 10:51:50 --> Loader Class Initialized
INFO - 2023-07-03 10:51:50 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:50 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:50 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:50 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:50 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:50 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:50 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:50 --> Parser Class Initialized
INFO - 2023-07-03 10:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:50 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:50 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:50 --> Controller Class Initialized
INFO - 2023-07-03 10:51:50 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:50 --> Model Class Initialized
INFO - 2023-07-03 10:51:50 --> Model Class Initialized
INFO - 2023-07-03 10:51:50 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:50 --> Total execution time: 0.0192
ERROR - 2023-07-03 10:51:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:51:51 --> Config Class Initialized
INFO - 2023-07-03 10:51:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:51:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:51:51 --> Utf8 Class Initialized
INFO - 2023-07-03 10:51:51 --> URI Class Initialized
INFO - 2023-07-03 10:51:51 --> Router Class Initialized
INFO - 2023-07-03 10:51:51 --> Output Class Initialized
INFO - 2023-07-03 10:51:51 --> Security Class Initialized
DEBUG - 2023-07-03 10:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:51:51 --> Input Class Initialized
INFO - 2023-07-03 10:51:51 --> Language Class Initialized
INFO - 2023-07-03 10:51:51 --> Loader Class Initialized
INFO - 2023-07-03 10:51:51 --> Helper loaded: url_helper
INFO - 2023-07-03 10:51:51 --> Helper loaded: file_helper
INFO - 2023-07-03 10:51:51 --> Helper loaded: html_helper
INFO - 2023-07-03 10:51:51 --> Helper loaded: text_helper
INFO - 2023-07-03 10:51:51 --> Helper loaded: form_helper
INFO - 2023-07-03 10:51:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:51:51 --> Helper loaded: security_helper
INFO - 2023-07-03 10:51:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:51:51 --> Database Driver Class Initialized
INFO - 2023-07-03 10:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:51:51 --> Parser Class Initialized
INFO - 2023-07-03 10:51:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:51:51 --> Pagination Class Initialized
INFO - 2023-07-03 10:51:51 --> Form Validation Class Initialized
INFO - 2023-07-03 10:51:51 --> Controller Class Initialized
INFO - 2023-07-03 10:51:51 --> Model Class Initialized
DEBUG - 2023-07-03 10:51:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:51:51 --> Model Class Initialized
INFO - 2023-07-03 10:51:51 --> Final output sent to browser
DEBUG - 2023-07-03 10:51:51 --> Total execution time: 0.0153
ERROR - 2023-07-03 10:52:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:52:10 --> Config Class Initialized
INFO - 2023-07-03 10:52:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:52:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:52:10 --> Utf8 Class Initialized
INFO - 2023-07-03 10:52:10 --> URI Class Initialized
INFO - 2023-07-03 10:52:10 --> Router Class Initialized
INFO - 2023-07-03 10:52:10 --> Output Class Initialized
INFO - 2023-07-03 10:52:10 --> Security Class Initialized
DEBUG - 2023-07-03 10:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:52:10 --> Input Class Initialized
INFO - 2023-07-03 10:52:10 --> Language Class Initialized
INFO - 2023-07-03 10:52:10 --> Loader Class Initialized
INFO - 2023-07-03 10:52:10 --> Helper loaded: url_helper
INFO - 2023-07-03 10:52:10 --> Helper loaded: file_helper
INFO - 2023-07-03 10:52:10 --> Helper loaded: html_helper
INFO - 2023-07-03 10:52:10 --> Helper loaded: text_helper
INFO - 2023-07-03 10:52:10 --> Helper loaded: form_helper
INFO - 2023-07-03 10:52:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:52:10 --> Helper loaded: security_helper
INFO - 2023-07-03 10:52:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:52:10 --> Database Driver Class Initialized
INFO - 2023-07-03 10:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:52:10 --> Parser Class Initialized
INFO - 2023-07-03 10:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:52:10 --> Pagination Class Initialized
INFO - 2023-07-03 10:52:10 --> Form Validation Class Initialized
INFO - 2023-07-03 10:52:10 --> Controller Class Initialized
INFO - 2023-07-03 10:52:10 --> Model Class Initialized
INFO - 2023-07-03 10:52:10 --> Model Class Initialized
INFO - 2023-07-03 10:52:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-03 10:52:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:52:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:52:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:52:10 --> Model Class Initialized
INFO - 2023-07-03 10:52:10 --> Model Class Initialized
INFO - 2023-07-03 10:52:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:52:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:52:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:52:10 --> Final output sent to browser
DEBUG - 2023-07-03 10:52:10 --> Total execution time: 0.1454
ERROR - 2023-07-03 10:52:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:52:11 --> Config Class Initialized
INFO - 2023-07-03 10:52:11 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:52:11 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:52:11 --> Utf8 Class Initialized
INFO - 2023-07-03 10:52:11 --> URI Class Initialized
INFO - 2023-07-03 10:52:11 --> Router Class Initialized
INFO - 2023-07-03 10:52:11 --> Output Class Initialized
INFO - 2023-07-03 10:52:11 --> Security Class Initialized
DEBUG - 2023-07-03 10:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:52:11 --> Input Class Initialized
INFO - 2023-07-03 10:52:11 --> Language Class Initialized
INFO - 2023-07-03 10:52:11 --> Loader Class Initialized
INFO - 2023-07-03 10:52:11 --> Helper loaded: url_helper
INFO - 2023-07-03 10:52:11 --> Helper loaded: file_helper
INFO - 2023-07-03 10:52:11 --> Helper loaded: html_helper
INFO - 2023-07-03 10:52:11 --> Helper loaded: text_helper
INFO - 2023-07-03 10:52:11 --> Helper loaded: form_helper
INFO - 2023-07-03 10:52:11 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:52:11 --> Helper loaded: security_helper
INFO - 2023-07-03 10:52:11 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:52:11 --> Database Driver Class Initialized
INFO - 2023-07-03 10:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:52:11 --> Parser Class Initialized
INFO - 2023-07-03 10:52:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:52:11 --> Pagination Class Initialized
INFO - 2023-07-03 10:52:11 --> Form Validation Class Initialized
INFO - 2023-07-03 10:52:11 --> Controller Class Initialized
INFO - 2023-07-03 10:52:11 --> Model Class Initialized
INFO - 2023-07-03 10:52:11 --> Model Class Initialized
INFO - 2023-07-03 10:52:11 --> Final output sent to browser
DEBUG - 2023-07-03 10:52:11 --> Total execution time: 0.0231
ERROR - 2023-07-03 10:52:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:52:14 --> Config Class Initialized
INFO - 2023-07-03 10:52:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:52:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:52:14 --> Utf8 Class Initialized
INFO - 2023-07-03 10:52:14 --> URI Class Initialized
INFO - 2023-07-03 10:52:14 --> Router Class Initialized
INFO - 2023-07-03 10:52:14 --> Output Class Initialized
INFO - 2023-07-03 10:52:14 --> Security Class Initialized
DEBUG - 2023-07-03 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:52:14 --> Input Class Initialized
INFO - 2023-07-03 10:52:14 --> Language Class Initialized
INFO - 2023-07-03 10:52:14 --> Loader Class Initialized
INFO - 2023-07-03 10:52:14 --> Helper loaded: url_helper
INFO - 2023-07-03 10:52:14 --> Helper loaded: file_helper
INFO - 2023-07-03 10:52:15 --> Helper loaded: html_helper
INFO - 2023-07-03 10:52:15 --> Helper loaded: text_helper
INFO - 2023-07-03 10:52:15 --> Helper loaded: form_helper
INFO - 2023-07-03 10:52:15 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:52:15 --> Helper loaded: security_helper
INFO - 2023-07-03 10:52:15 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:52:15 --> Database Driver Class Initialized
INFO - 2023-07-03 10:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:52:15 --> Parser Class Initialized
INFO - 2023-07-03 10:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:52:15 --> Pagination Class Initialized
INFO - 2023-07-03 10:52:15 --> Form Validation Class Initialized
INFO - 2023-07-03 10:52:15 --> Controller Class Initialized
INFO - 2023-07-03 10:52:15 --> Model Class Initialized
INFO - 2023-07-03 10:52:15 --> Model Class Initialized
INFO - 2023-07-03 10:52:15 --> Final output sent to browser
DEBUG - 2023-07-03 10:52:15 --> Total execution time: 0.0337
ERROR - 2023-07-03 10:52:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:52:18 --> Config Class Initialized
INFO - 2023-07-03 10:52:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:52:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:52:18 --> Utf8 Class Initialized
INFO - 2023-07-03 10:52:18 --> URI Class Initialized
INFO - 2023-07-03 10:52:18 --> Router Class Initialized
INFO - 2023-07-03 10:52:18 --> Output Class Initialized
INFO - 2023-07-03 10:52:18 --> Security Class Initialized
DEBUG - 2023-07-03 10:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:52:18 --> Input Class Initialized
INFO - 2023-07-03 10:52:18 --> Language Class Initialized
INFO - 2023-07-03 10:52:18 --> Loader Class Initialized
INFO - 2023-07-03 10:52:18 --> Helper loaded: url_helper
INFO - 2023-07-03 10:52:18 --> Helper loaded: file_helper
INFO - 2023-07-03 10:52:18 --> Helper loaded: html_helper
INFO - 2023-07-03 10:52:18 --> Helper loaded: text_helper
INFO - 2023-07-03 10:52:18 --> Helper loaded: form_helper
INFO - 2023-07-03 10:52:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:52:18 --> Helper loaded: security_helper
INFO - 2023-07-03 10:52:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:52:18 --> Database Driver Class Initialized
INFO - 2023-07-03 10:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:52:18 --> Parser Class Initialized
INFO - 2023-07-03 10:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:52:18 --> Pagination Class Initialized
INFO - 2023-07-03 10:52:18 --> Form Validation Class Initialized
INFO - 2023-07-03 10:52:18 --> Controller Class Initialized
DEBUG - 2023-07-03 10:52:18 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:52:18 --> Model Class Initialized
INFO - 2023-07-03 10:52:18 --> Model Class Initialized
INFO - 2023-07-03 10:52:18 --> Model Class Initialized
INFO - 2023-07-03 10:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-03 10:52:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:52:18 --> Model Class Initialized
INFO - 2023-07-03 10:52:18 --> Model Class Initialized
INFO - 2023-07-03 10:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:52:18 --> Final output sent to browser
DEBUG - 2023-07-03 10:52:18 --> Total execution time: 0.1819
ERROR - 2023-07-03 10:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:52:48 --> Config Class Initialized
INFO - 2023-07-03 10:52:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:52:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:52:48 --> Utf8 Class Initialized
INFO - 2023-07-03 10:52:48 --> URI Class Initialized
INFO - 2023-07-03 10:52:48 --> Router Class Initialized
INFO - 2023-07-03 10:52:48 --> Output Class Initialized
INFO - 2023-07-03 10:52:48 --> Security Class Initialized
DEBUG - 2023-07-03 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:52:48 --> Input Class Initialized
INFO - 2023-07-03 10:52:48 --> Language Class Initialized
INFO - 2023-07-03 10:52:48 --> Loader Class Initialized
INFO - 2023-07-03 10:52:48 --> Helper loaded: url_helper
INFO - 2023-07-03 10:52:48 --> Helper loaded: file_helper
INFO - 2023-07-03 10:52:48 --> Helper loaded: html_helper
INFO - 2023-07-03 10:52:48 --> Helper loaded: text_helper
INFO - 2023-07-03 10:52:48 --> Helper loaded: form_helper
INFO - 2023-07-03 10:52:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:52:48 --> Helper loaded: security_helper
INFO - 2023-07-03 10:52:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:52:48 --> Database Driver Class Initialized
INFO - 2023-07-03 10:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:52:48 --> Parser Class Initialized
INFO - 2023-07-03 10:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:52:48 --> Pagination Class Initialized
INFO - 2023-07-03 10:52:48 --> Form Validation Class Initialized
INFO - 2023-07-03 10:52:48 --> Controller Class Initialized
INFO - 2023-07-03 10:52:48 --> Model Class Initialized
DEBUG - 2023-07-03 10:52:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:52:48 --> Model Class Initialized
INFO - 2023-07-03 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-03 10:52:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:52:48 --> Model Class Initialized
INFO - 2023-07-03 10:52:48 --> Model Class Initialized
INFO - 2023-07-03 10:52:48 --> Model Class Initialized
INFO - 2023-07-03 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:52:48 --> Final output sent to browser
DEBUG - 2023-07-03 10:52:48 --> Total execution time: 0.0825
ERROR - 2023-07-03 10:52:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:52:49 --> Config Class Initialized
INFO - 2023-07-03 10:52:49 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:52:49 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:52:49 --> Utf8 Class Initialized
INFO - 2023-07-03 10:52:49 --> URI Class Initialized
INFO - 2023-07-03 10:52:49 --> Router Class Initialized
INFO - 2023-07-03 10:52:49 --> Output Class Initialized
INFO - 2023-07-03 10:52:49 --> Security Class Initialized
DEBUG - 2023-07-03 10:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:52:49 --> Input Class Initialized
INFO - 2023-07-03 10:52:49 --> Language Class Initialized
INFO - 2023-07-03 10:52:49 --> Loader Class Initialized
INFO - 2023-07-03 10:52:49 --> Helper loaded: url_helper
INFO - 2023-07-03 10:52:49 --> Helper loaded: file_helper
INFO - 2023-07-03 10:52:49 --> Helper loaded: html_helper
INFO - 2023-07-03 10:52:49 --> Helper loaded: text_helper
INFO - 2023-07-03 10:52:49 --> Helper loaded: form_helper
INFO - 2023-07-03 10:52:49 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:52:49 --> Helper loaded: security_helper
INFO - 2023-07-03 10:52:49 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:52:49 --> Database Driver Class Initialized
INFO - 2023-07-03 10:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:52:49 --> Parser Class Initialized
INFO - 2023-07-03 10:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:52:49 --> Pagination Class Initialized
INFO - 2023-07-03 10:52:49 --> Form Validation Class Initialized
INFO - 2023-07-03 10:52:49 --> Controller Class Initialized
INFO - 2023-07-03 10:52:49 --> Model Class Initialized
DEBUG - 2023-07-03 10:52:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:52:49 --> Model Class Initialized
INFO - 2023-07-03 10:52:49 --> Final output sent to browser
DEBUG - 2023-07-03 10:52:49 --> Total execution time: 0.0303
ERROR - 2023-07-03 10:52:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:52:59 --> Config Class Initialized
INFO - 2023-07-03 10:52:59 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:52:59 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:52:59 --> Utf8 Class Initialized
INFO - 2023-07-03 10:52:59 --> URI Class Initialized
INFO - 2023-07-03 10:52:59 --> Router Class Initialized
INFO - 2023-07-03 10:52:59 --> Output Class Initialized
INFO - 2023-07-03 10:52:59 --> Security Class Initialized
DEBUG - 2023-07-03 10:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:52:59 --> Input Class Initialized
INFO - 2023-07-03 10:52:59 --> Language Class Initialized
INFO - 2023-07-03 10:52:59 --> Loader Class Initialized
INFO - 2023-07-03 10:52:59 --> Helper loaded: url_helper
INFO - 2023-07-03 10:52:59 --> Helper loaded: file_helper
INFO - 2023-07-03 10:52:59 --> Helper loaded: html_helper
INFO - 2023-07-03 10:52:59 --> Helper loaded: text_helper
INFO - 2023-07-03 10:52:59 --> Helper loaded: form_helper
INFO - 2023-07-03 10:52:59 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:52:59 --> Helper loaded: security_helper
INFO - 2023-07-03 10:52:59 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:52:59 --> Database Driver Class Initialized
INFO - 2023-07-03 10:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:52:59 --> Parser Class Initialized
INFO - 2023-07-03 10:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:52:59 --> Pagination Class Initialized
INFO - 2023-07-03 10:52:59 --> Form Validation Class Initialized
INFO - 2023-07-03 10:52:59 --> Controller Class Initialized
INFO - 2023-07-03 10:52:59 --> Model Class Initialized
INFO - 2023-07-03 10:52:59 --> Model Class Initialized
INFO - 2023-07-03 10:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-03 10:52:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:52:59 --> Model Class Initialized
INFO - 2023-07-03 10:52:59 --> Model Class Initialized
INFO - 2023-07-03 10:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:52:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:52:59 --> Final output sent to browser
DEBUG - 2023-07-03 10:52:59 --> Total execution time: 0.1410
ERROR - 2023-07-03 10:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:53:00 --> Config Class Initialized
INFO - 2023-07-03 10:53:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:53:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:53:00 --> Utf8 Class Initialized
INFO - 2023-07-03 10:53:00 --> URI Class Initialized
INFO - 2023-07-03 10:53:00 --> Router Class Initialized
INFO - 2023-07-03 10:53:00 --> Output Class Initialized
INFO - 2023-07-03 10:53:00 --> Security Class Initialized
DEBUG - 2023-07-03 10:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:53:00 --> Input Class Initialized
INFO - 2023-07-03 10:53:00 --> Language Class Initialized
INFO - 2023-07-03 10:53:00 --> Loader Class Initialized
INFO - 2023-07-03 10:53:00 --> Helper loaded: url_helper
INFO - 2023-07-03 10:53:00 --> Helper loaded: file_helper
INFO - 2023-07-03 10:53:00 --> Helper loaded: html_helper
INFO - 2023-07-03 10:53:00 --> Helper loaded: text_helper
INFO - 2023-07-03 10:53:00 --> Helper loaded: form_helper
INFO - 2023-07-03 10:53:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:53:00 --> Helper loaded: security_helper
INFO - 2023-07-03 10:53:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:53:00 --> Database Driver Class Initialized
INFO - 2023-07-03 10:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:53:00 --> Parser Class Initialized
INFO - 2023-07-03 10:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:53:00 --> Pagination Class Initialized
INFO - 2023-07-03 10:53:00 --> Form Validation Class Initialized
INFO - 2023-07-03 10:53:00 --> Controller Class Initialized
INFO - 2023-07-03 10:53:00 --> Model Class Initialized
INFO - 2023-07-03 10:53:00 --> Model Class Initialized
INFO - 2023-07-03 10:53:00 --> Final output sent to browser
DEBUG - 2023-07-03 10:53:00 --> Total execution time: 0.0211
ERROR - 2023-07-03 10:55:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:55:32 --> Config Class Initialized
INFO - 2023-07-03 10:55:32 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:55:32 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:55:32 --> Utf8 Class Initialized
INFO - 2023-07-03 10:55:32 --> URI Class Initialized
INFO - 2023-07-03 10:55:32 --> Router Class Initialized
INFO - 2023-07-03 10:55:32 --> Output Class Initialized
INFO - 2023-07-03 10:55:32 --> Security Class Initialized
DEBUG - 2023-07-03 10:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:55:32 --> Input Class Initialized
INFO - 2023-07-03 10:55:32 --> Language Class Initialized
INFO - 2023-07-03 10:55:32 --> Loader Class Initialized
INFO - 2023-07-03 10:55:32 --> Helper loaded: url_helper
INFO - 2023-07-03 10:55:32 --> Helper loaded: file_helper
INFO - 2023-07-03 10:55:32 --> Helper loaded: html_helper
INFO - 2023-07-03 10:55:32 --> Helper loaded: text_helper
INFO - 2023-07-03 10:55:32 --> Helper loaded: form_helper
INFO - 2023-07-03 10:55:32 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:55:32 --> Helper loaded: security_helper
INFO - 2023-07-03 10:55:32 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:55:32 --> Database Driver Class Initialized
INFO - 2023-07-03 10:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:55:32 --> Parser Class Initialized
INFO - 2023-07-03 10:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:55:32 --> Pagination Class Initialized
INFO - 2023-07-03 10:55:32 --> Form Validation Class Initialized
INFO - 2023-07-03 10:55:32 --> Controller Class Initialized
DEBUG - 2023-07-03 10:55:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:55:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:55:32 --> Model Class Initialized
INFO - 2023-07-03 10:55:32 --> Model Class Initialized
INFO - 2023-07-03 10:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-07-03 10:55:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:55:32 --> Model Class Initialized
INFO - 2023-07-03 10:55:32 --> Model Class Initialized
INFO - 2023-07-03 10:55:32 --> Model Class Initialized
INFO - 2023-07-03 10:55:32 --> Model Class Initialized
INFO - 2023-07-03 10:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:55:32 --> Final output sent to browser
DEBUG - 2023-07-03 10:55:32 --> Total execution time: 0.1521
ERROR - 2023-07-03 10:56:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:56:12 --> Config Class Initialized
INFO - 2023-07-03 10:56:12 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:56:12 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:56:12 --> Utf8 Class Initialized
INFO - 2023-07-03 10:56:12 --> URI Class Initialized
DEBUG - 2023-07-03 10:56:12 --> No URI present. Default controller set.
INFO - 2023-07-03 10:56:12 --> Router Class Initialized
INFO - 2023-07-03 10:56:12 --> Output Class Initialized
INFO - 2023-07-03 10:56:12 --> Security Class Initialized
DEBUG - 2023-07-03 10:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:56:12 --> Input Class Initialized
INFO - 2023-07-03 10:56:12 --> Language Class Initialized
INFO - 2023-07-03 10:56:12 --> Loader Class Initialized
INFO - 2023-07-03 10:56:12 --> Helper loaded: url_helper
INFO - 2023-07-03 10:56:12 --> Helper loaded: file_helper
INFO - 2023-07-03 10:56:12 --> Helper loaded: html_helper
INFO - 2023-07-03 10:56:12 --> Helper loaded: text_helper
INFO - 2023-07-03 10:56:12 --> Helper loaded: form_helper
INFO - 2023-07-03 10:56:12 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:56:12 --> Helper loaded: security_helper
INFO - 2023-07-03 10:56:12 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:56:12 --> Database Driver Class Initialized
INFO - 2023-07-03 10:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:56:12 --> Parser Class Initialized
INFO - 2023-07-03 10:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:56:12 --> Pagination Class Initialized
INFO - 2023-07-03 10:56:12 --> Form Validation Class Initialized
INFO - 2023-07-03 10:56:12 --> Controller Class Initialized
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
DEBUG - 2023-07-03 10:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
DEBUG - 2023-07-03 10:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
DEBUG - 2023-07-03 10:56:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
INFO - 2023-07-03 10:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:56:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:56:12 --> Model Class Initialized
INFO - 2023-07-03 10:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:56:12 --> Final output sent to browser
DEBUG - 2023-07-03 10:56:12 --> Total execution time: 0.1832
ERROR - 2023-07-03 10:56:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:56:25 --> Config Class Initialized
INFO - 2023-07-03 10:56:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:56:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:56:25 --> Utf8 Class Initialized
INFO - 2023-07-03 10:56:25 --> URI Class Initialized
INFO - 2023-07-03 10:56:25 --> Router Class Initialized
INFO - 2023-07-03 10:56:25 --> Output Class Initialized
INFO - 2023-07-03 10:56:25 --> Security Class Initialized
DEBUG - 2023-07-03 10:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:56:25 --> Input Class Initialized
INFO - 2023-07-03 10:56:25 --> Language Class Initialized
INFO - 2023-07-03 10:56:25 --> Loader Class Initialized
INFO - 2023-07-03 10:56:25 --> Helper loaded: url_helper
INFO - 2023-07-03 10:56:25 --> Helper loaded: file_helper
INFO - 2023-07-03 10:56:25 --> Helper loaded: html_helper
INFO - 2023-07-03 10:56:25 --> Helper loaded: text_helper
INFO - 2023-07-03 10:56:25 --> Helper loaded: form_helper
INFO - 2023-07-03 10:56:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:56:25 --> Helper loaded: security_helper
INFO - 2023-07-03 10:56:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:56:25 --> Database Driver Class Initialized
INFO - 2023-07-03 10:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:56:25 --> Parser Class Initialized
INFO - 2023-07-03 10:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:56:25 --> Pagination Class Initialized
INFO - 2023-07-03 10:56:25 --> Form Validation Class Initialized
INFO - 2023-07-03 10:56:25 --> Controller Class Initialized
INFO - 2023-07-03 10:56:25 --> Model Class Initialized
INFO - 2023-07-03 10:56:25 --> Model Class Initialized
INFO - 2023-07-03 10:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-03 10:56:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:56:25 --> Model Class Initialized
INFO - 2023-07-03 10:56:25 --> Model Class Initialized
INFO - 2023-07-03 10:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:56:25 --> Final output sent to browser
DEBUG - 2023-07-03 10:56:25 --> Total execution time: 0.1475
ERROR - 2023-07-03 10:56:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:56:26 --> Config Class Initialized
INFO - 2023-07-03 10:56:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:56:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:56:26 --> Utf8 Class Initialized
INFO - 2023-07-03 10:56:26 --> URI Class Initialized
INFO - 2023-07-03 10:56:26 --> Router Class Initialized
INFO - 2023-07-03 10:56:26 --> Output Class Initialized
INFO - 2023-07-03 10:56:26 --> Security Class Initialized
DEBUG - 2023-07-03 10:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:56:26 --> Input Class Initialized
INFO - 2023-07-03 10:56:26 --> Language Class Initialized
INFO - 2023-07-03 10:56:26 --> Loader Class Initialized
INFO - 2023-07-03 10:56:26 --> Helper loaded: url_helper
INFO - 2023-07-03 10:56:26 --> Helper loaded: file_helper
INFO - 2023-07-03 10:56:26 --> Helper loaded: html_helper
INFO - 2023-07-03 10:56:26 --> Helper loaded: text_helper
INFO - 2023-07-03 10:56:26 --> Helper loaded: form_helper
INFO - 2023-07-03 10:56:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:56:26 --> Helper loaded: security_helper
INFO - 2023-07-03 10:56:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:56:26 --> Database Driver Class Initialized
INFO - 2023-07-03 10:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:56:26 --> Parser Class Initialized
INFO - 2023-07-03 10:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:56:26 --> Pagination Class Initialized
INFO - 2023-07-03 10:56:26 --> Form Validation Class Initialized
INFO - 2023-07-03 10:56:26 --> Controller Class Initialized
INFO - 2023-07-03 10:56:26 --> Model Class Initialized
INFO - 2023-07-03 10:56:26 --> Model Class Initialized
INFO - 2023-07-03 10:56:26 --> Final output sent to browser
DEBUG - 2023-07-03 10:56:26 --> Total execution time: 0.0221
ERROR - 2023-07-03 10:59:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:04 --> Config Class Initialized
INFO - 2023-07-03 10:59:04 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:04 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:04 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:04 --> URI Class Initialized
INFO - 2023-07-03 10:59:04 --> Router Class Initialized
INFO - 2023-07-03 10:59:04 --> Output Class Initialized
INFO - 2023-07-03 10:59:04 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:04 --> Input Class Initialized
INFO - 2023-07-03 10:59:04 --> Language Class Initialized
INFO - 2023-07-03 10:59:04 --> Loader Class Initialized
INFO - 2023-07-03 10:59:04 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:04 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:04 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:04 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:04 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:04 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:04 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:04 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:04 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:04 --> Parser Class Initialized
INFO - 2023-07-03 10:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:04 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:04 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:04 --> Controller Class Initialized
INFO - 2023-07-03 10:59:04 --> Model Class Initialized
INFO - 2023-07-03 10:59:04 --> Model Class Initialized
INFO - 2023-07-03 10:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-07-03 10:59:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:04 --> Model Class Initialized
INFO - 2023-07-03 10:59:04 --> Model Class Initialized
INFO - 2023-07-03 10:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:04 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:04 --> Total execution time: 0.1487
ERROR - 2023-07-03 10:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:05 --> Config Class Initialized
INFO - 2023-07-03 10:59:05 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:05 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:05 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:05 --> URI Class Initialized
INFO - 2023-07-03 10:59:05 --> Router Class Initialized
INFO - 2023-07-03 10:59:05 --> Output Class Initialized
INFO - 2023-07-03 10:59:05 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:05 --> Input Class Initialized
INFO - 2023-07-03 10:59:05 --> Language Class Initialized
INFO - 2023-07-03 10:59:05 --> Loader Class Initialized
INFO - 2023-07-03 10:59:05 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:05 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:05 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:05 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:05 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:05 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:05 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:05 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:05 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:05 --> Parser Class Initialized
INFO - 2023-07-03 10:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:05 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:05 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:05 --> Controller Class Initialized
INFO - 2023-07-03 10:59:05 --> Model Class Initialized
INFO - 2023-07-03 10:59:05 --> Model Class Initialized
INFO - 2023-07-03 10:59:05 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:05 --> Total execution time: 0.0348
ERROR - 2023-07-03 10:59:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:07 --> Config Class Initialized
INFO - 2023-07-03 10:59:07 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:07 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:07 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:07 --> URI Class Initialized
INFO - 2023-07-03 10:59:07 --> Router Class Initialized
INFO - 2023-07-03 10:59:07 --> Output Class Initialized
INFO - 2023-07-03 10:59:07 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:07 --> Input Class Initialized
INFO - 2023-07-03 10:59:07 --> Language Class Initialized
INFO - 2023-07-03 10:59:07 --> Loader Class Initialized
INFO - 2023-07-03 10:59:07 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:07 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:07 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:07 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:07 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:07 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:07 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:07 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:07 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:07 --> Parser Class Initialized
INFO - 2023-07-03 10:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:07 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:07 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:07 --> Controller Class Initialized
INFO - 2023-07-03 10:59:07 --> Model Class Initialized
INFO - 2023-07-03 10:59:07 --> Model Class Initialized
INFO - 2023-07-03 10:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-03 10:59:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:07 --> Model Class Initialized
INFO - 2023-07-03 10:59:07 --> Model Class Initialized
INFO - 2023-07-03 10:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:07 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:07 --> Total execution time: 0.1316
ERROR - 2023-07-03 10:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:08 --> Config Class Initialized
INFO - 2023-07-03 10:59:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:08 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:08 --> URI Class Initialized
INFO - 2023-07-03 10:59:08 --> Router Class Initialized
INFO - 2023-07-03 10:59:08 --> Output Class Initialized
INFO - 2023-07-03 10:59:08 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:08 --> Input Class Initialized
INFO - 2023-07-03 10:59:08 --> Language Class Initialized
INFO - 2023-07-03 10:59:08 --> Loader Class Initialized
INFO - 2023-07-03 10:59:08 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:08 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:08 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:08 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:08 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:08 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:08 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:08 --> Parser Class Initialized
INFO - 2023-07-03 10:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:08 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:08 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:08 --> Controller Class Initialized
INFO - 2023-07-03 10:59:08 --> Model Class Initialized
INFO - 2023-07-03 10:59:08 --> Model Class Initialized
INFO - 2023-07-03 10:59:08 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:08 --> Total execution time: 0.0194
ERROR - 2023-07-03 10:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:10 --> Config Class Initialized
INFO - 2023-07-03 10:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:10 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:10 --> URI Class Initialized
INFO - 2023-07-03 10:59:10 --> Router Class Initialized
INFO - 2023-07-03 10:59:10 --> Output Class Initialized
INFO - 2023-07-03 10:59:10 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:10 --> Input Class Initialized
INFO - 2023-07-03 10:59:10 --> Language Class Initialized
INFO - 2023-07-03 10:59:10 --> Loader Class Initialized
INFO - 2023-07-03 10:59:10 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:10 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:10 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:10 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:10 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:10 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:10 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:10 --> Parser Class Initialized
INFO - 2023-07-03 10:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:10 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:10 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:10 --> Controller Class Initialized
INFO - 2023-07-03 10:59:10 --> Model Class Initialized
INFO - 2023-07-03 10:59:10 --> Model Class Initialized
INFO - 2023-07-03 10:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-03 10:59:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:10 --> Model Class Initialized
INFO - 2023-07-03 10:59:10 --> Model Class Initialized
INFO - 2023-07-03 10:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:10 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:10 --> Total execution time: 0.1298
ERROR - 2023-07-03 10:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:11 --> Config Class Initialized
INFO - 2023-07-03 10:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:11 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:11 --> URI Class Initialized
INFO - 2023-07-03 10:59:11 --> Router Class Initialized
INFO - 2023-07-03 10:59:11 --> Output Class Initialized
INFO - 2023-07-03 10:59:11 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:11 --> Input Class Initialized
INFO - 2023-07-03 10:59:11 --> Language Class Initialized
INFO - 2023-07-03 10:59:11 --> Loader Class Initialized
INFO - 2023-07-03 10:59:11 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:11 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:11 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:11 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:11 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:11 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:11 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:11 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:11 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:11 --> Parser Class Initialized
INFO - 2023-07-03 10:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:11 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:11 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:11 --> Controller Class Initialized
INFO - 2023-07-03 10:59:11 --> Model Class Initialized
INFO - 2023-07-03 10:59:11 --> Model Class Initialized
INFO - 2023-07-03 10:59:11 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:11 --> Total execution time: 0.0181
ERROR - 2023-07-03 10:59:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:12 --> Config Class Initialized
INFO - 2023-07-03 10:59:12 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:12 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:12 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:12 --> URI Class Initialized
INFO - 2023-07-03 10:59:12 --> Router Class Initialized
INFO - 2023-07-03 10:59:12 --> Output Class Initialized
INFO - 2023-07-03 10:59:12 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:12 --> Input Class Initialized
INFO - 2023-07-03 10:59:12 --> Language Class Initialized
INFO - 2023-07-03 10:59:12 --> Loader Class Initialized
INFO - 2023-07-03 10:59:12 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:12 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:12 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:12 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:12 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:12 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:12 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:12 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:12 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:12 --> Parser Class Initialized
INFO - 2023-07-03 10:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:12 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:12 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:12 --> Controller Class Initialized
DEBUG - 2023-07-03 10:59:12 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:12 --> Model Class Initialized
INFO - 2023-07-03 10:59:12 --> Model Class Initialized
INFO - 2023-07-03 10:59:12 --> Model Class Initialized
INFO - 2023-07-03 10:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-03 10:59:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:12 --> Model Class Initialized
INFO - 2023-07-03 10:59:12 --> Model Class Initialized
INFO - 2023-07-03 10:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:12 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:12 --> Total execution time: 0.1584
ERROR - 2023-07-03 10:59:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:16 --> Config Class Initialized
INFO - 2023-07-03 10:59:16 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:16 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:16 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:16 --> URI Class Initialized
INFO - 2023-07-03 10:59:16 --> Router Class Initialized
INFO - 2023-07-03 10:59:16 --> Output Class Initialized
INFO - 2023-07-03 10:59:16 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:16 --> Input Class Initialized
INFO - 2023-07-03 10:59:16 --> Language Class Initialized
INFO - 2023-07-03 10:59:16 --> Loader Class Initialized
INFO - 2023-07-03 10:59:16 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:16 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:16 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:16 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:16 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:16 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:16 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:16 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:17 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:17 --> Parser Class Initialized
INFO - 2023-07-03 10:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:17 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:17 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:17 --> Controller Class Initialized
INFO - 2023-07-03 10:59:17 --> Model Class Initialized
INFO - 2023-07-03 10:59:17 --> Model Class Initialized
INFO - 2023-07-03 10:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-03 10:59:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:17 --> Model Class Initialized
INFO - 2023-07-03 10:59:17 --> Model Class Initialized
INFO - 2023-07-03 10:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:17 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:17 --> Total execution time: 0.1202
ERROR - 2023-07-03 10:59:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:17 --> Config Class Initialized
INFO - 2023-07-03 10:59:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:17 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:17 --> URI Class Initialized
INFO - 2023-07-03 10:59:17 --> Router Class Initialized
INFO - 2023-07-03 10:59:17 --> Output Class Initialized
INFO - 2023-07-03 10:59:17 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:17 --> Input Class Initialized
INFO - 2023-07-03 10:59:17 --> Language Class Initialized
INFO - 2023-07-03 10:59:17 --> Loader Class Initialized
INFO - 2023-07-03 10:59:17 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:17 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:17 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:17 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:17 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:17 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:17 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:17 --> Parser Class Initialized
INFO - 2023-07-03 10:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:17 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:17 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:17 --> Controller Class Initialized
INFO - 2023-07-03 10:59:17 --> Model Class Initialized
INFO - 2023-07-03 10:59:17 --> Model Class Initialized
INFO - 2023-07-03 10:59:17 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:17 --> Total execution time: 0.0176
ERROR - 2023-07-03 10:59:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:19 --> Config Class Initialized
INFO - 2023-07-03 10:59:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:19 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:19 --> URI Class Initialized
INFO - 2023-07-03 10:59:19 --> Router Class Initialized
INFO - 2023-07-03 10:59:19 --> Output Class Initialized
INFO - 2023-07-03 10:59:19 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:19 --> Input Class Initialized
INFO - 2023-07-03 10:59:19 --> Language Class Initialized
INFO - 2023-07-03 10:59:19 --> Loader Class Initialized
INFO - 2023-07-03 10:59:19 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:19 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:19 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:19 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:19 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:19 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:19 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:19 --> Parser Class Initialized
INFO - 2023-07-03 10:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:19 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:19 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:19 --> Controller Class Initialized
DEBUG - 2023-07-03 10:59:19 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:19 --> Model Class Initialized
INFO - 2023-07-03 10:59:19 --> Model Class Initialized
INFO - 2023-07-03 10:59:19 --> Model Class Initialized
INFO - 2023-07-03 10:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-03 10:59:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:19 --> Model Class Initialized
INFO - 2023-07-03 10:59:19 --> Model Class Initialized
INFO - 2023-07-03 10:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:19 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:19 --> Total execution time: 0.1741
ERROR - 2023-07-03 10:59:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:21 --> Config Class Initialized
INFO - 2023-07-03 10:59:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:21 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:21 --> URI Class Initialized
INFO - 2023-07-03 10:59:21 --> Router Class Initialized
INFO - 2023-07-03 10:59:21 --> Output Class Initialized
INFO - 2023-07-03 10:59:21 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:21 --> Input Class Initialized
INFO - 2023-07-03 10:59:21 --> Language Class Initialized
INFO - 2023-07-03 10:59:21 --> Loader Class Initialized
INFO - 2023-07-03 10:59:21 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:21 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:21 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:21 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:21 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:21 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:21 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:21 --> Parser Class Initialized
INFO - 2023-07-03 10:59:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:21 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:21 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:21 --> Controller Class Initialized
INFO - 2023-07-03 10:59:21 --> Model Class Initialized
INFO - 2023-07-03 10:59:21 --> Model Class Initialized
INFO - 2023-07-03 10:59:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-03 10:59:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:21 --> Model Class Initialized
INFO - 2023-07-03 10:59:21 --> Model Class Initialized
INFO - 2023-07-03 10:59:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:21 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:21 --> Total execution time: 0.1347
ERROR - 2023-07-03 10:59:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:22 --> Config Class Initialized
INFO - 2023-07-03 10:59:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:22 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:22 --> URI Class Initialized
INFO - 2023-07-03 10:59:22 --> Router Class Initialized
INFO - 2023-07-03 10:59:22 --> Output Class Initialized
INFO - 2023-07-03 10:59:22 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:22 --> Input Class Initialized
INFO - 2023-07-03 10:59:22 --> Language Class Initialized
INFO - 2023-07-03 10:59:22 --> Loader Class Initialized
INFO - 2023-07-03 10:59:22 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:22 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:22 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:22 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:22 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:22 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:22 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:22 --> Parser Class Initialized
INFO - 2023-07-03 10:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:22 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:22 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:22 --> Controller Class Initialized
INFO - 2023-07-03 10:59:22 --> Model Class Initialized
INFO - 2023-07-03 10:59:22 --> Model Class Initialized
INFO - 2023-07-03 10:59:22 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:22 --> Total execution time: 0.0179
ERROR - 2023-07-03 10:59:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:23 --> Config Class Initialized
INFO - 2023-07-03 10:59:23 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:23 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:23 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:23 --> URI Class Initialized
INFO - 2023-07-03 10:59:23 --> Router Class Initialized
INFO - 2023-07-03 10:59:23 --> Output Class Initialized
INFO - 2023-07-03 10:59:23 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:23 --> Input Class Initialized
INFO - 2023-07-03 10:59:23 --> Language Class Initialized
INFO - 2023-07-03 10:59:23 --> Loader Class Initialized
INFO - 2023-07-03 10:59:23 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:23 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:23 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:23 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:23 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:23 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:23 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:23 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:23 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:23 --> Parser Class Initialized
INFO - 2023-07-03 10:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:23 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:23 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:23 --> Controller Class Initialized
DEBUG - 2023-07-03 10:59:23 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:23 --> Model Class Initialized
INFO - 2023-07-03 10:59:23 --> Model Class Initialized
INFO - 2023-07-03 10:59:23 --> Model Class Initialized
INFO - 2023-07-03 10:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-03 10:59:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:23 --> Model Class Initialized
INFO - 2023-07-03 10:59:23 --> Model Class Initialized
INFO - 2023-07-03 10:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:23 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:23 --> Total execution time: 0.1500
ERROR - 2023-07-03 10:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:29 --> Config Class Initialized
INFO - 2023-07-03 10:59:29 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:29 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:29 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:29 --> URI Class Initialized
INFO - 2023-07-03 10:59:29 --> Router Class Initialized
INFO - 2023-07-03 10:59:29 --> Output Class Initialized
INFO - 2023-07-03 10:59:29 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:29 --> Input Class Initialized
INFO - 2023-07-03 10:59:29 --> Language Class Initialized
INFO - 2023-07-03 10:59:29 --> Loader Class Initialized
INFO - 2023-07-03 10:59:29 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:29 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:29 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:29 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:29 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:29 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:29 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:29 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:29 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:29 --> Parser Class Initialized
INFO - 2023-07-03 10:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:29 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:29 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:29 --> Controller Class Initialized
INFO - 2023-07-03 10:59:29 --> Model Class Initialized
INFO - 2023-07-03 10:59:29 --> Model Class Initialized
INFO - 2023-07-03 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_detail.php
DEBUG - 2023-07-03 10:59:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:30 --> Model Class Initialized
INFO - 2023-07-03 10:59:30 --> Model Class Initialized
INFO - 2023-07-03 10:59:30 --> Model Class Initialized
INFO - 2023-07-03 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:30 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:30 --> Total execution time: 0.1473
ERROR - 2023-07-03 10:59:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:32 --> Config Class Initialized
INFO - 2023-07-03 10:59:32 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:32 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:32 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:32 --> URI Class Initialized
DEBUG - 2023-07-03 10:59:32 --> No URI present. Default controller set.
INFO - 2023-07-03 10:59:32 --> Router Class Initialized
INFO - 2023-07-03 10:59:32 --> Output Class Initialized
INFO - 2023-07-03 10:59:32 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:32 --> Input Class Initialized
INFO - 2023-07-03 10:59:32 --> Language Class Initialized
INFO - 2023-07-03 10:59:32 --> Loader Class Initialized
INFO - 2023-07-03 10:59:32 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:32 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:32 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:32 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:32 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:32 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:32 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:32 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:32 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:32 --> Parser Class Initialized
INFO - 2023-07-03 10:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:32 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:32 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:32 --> Controller Class Initialized
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
INFO - 2023-07-03 10:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:59:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:32 --> Model Class Initialized
INFO - 2023-07-03 10:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:32 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:32 --> Total execution time: 0.1809
ERROR - 2023-07-03 10:59:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:50 --> Config Class Initialized
INFO - 2023-07-03 10:59:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:50 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:50 --> URI Class Initialized
DEBUG - 2023-07-03 10:59:50 --> No URI present. Default controller set.
INFO - 2023-07-03 10:59:50 --> Router Class Initialized
INFO - 2023-07-03 10:59:50 --> Output Class Initialized
INFO - 2023-07-03 10:59:50 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:50 --> Input Class Initialized
INFO - 2023-07-03 10:59:50 --> Language Class Initialized
INFO - 2023-07-03 10:59:50 --> Loader Class Initialized
INFO - 2023-07-03 10:59:50 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:50 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:50 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:50 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:50 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:50 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:50 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:50 --> Parser Class Initialized
INFO - 2023-07-03 10:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:50 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:50 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:50 --> Controller Class Initialized
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
INFO - 2023-07-03 10:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:59:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:50 --> Model Class Initialized
INFO - 2023-07-03 10:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:50 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:50 --> Total execution time: 0.1950
ERROR - 2023-07-03 10:59:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:58 --> Config Class Initialized
INFO - 2023-07-03 10:59:58 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:58 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:58 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:58 --> URI Class Initialized
DEBUG - 2023-07-03 10:59:58 --> No URI present. Default controller set.
INFO - 2023-07-03 10:59:58 --> Router Class Initialized
INFO - 2023-07-03 10:59:58 --> Output Class Initialized
INFO - 2023-07-03 10:59:58 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:58 --> Input Class Initialized
INFO - 2023-07-03 10:59:58 --> Language Class Initialized
INFO - 2023-07-03 10:59:58 --> Loader Class Initialized
INFO - 2023-07-03 10:59:58 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:58 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:58 --> Parser Class Initialized
INFO - 2023-07-03 10:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:58 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:58 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:58 --> Controller Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:59:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
ERROR - 2023-07-03 10:59:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 10:59:58 --> Config Class Initialized
INFO - 2023-07-03 10:59:58 --> Hooks Class Initialized
DEBUG - 2023-07-03 10:59:58 --> UTF-8 Support Enabled
INFO - 2023-07-03 10:59:58 --> Utf8 Class Initialized
INFO - 2023-07-03 10:59:58 --> URI Class Initialized
DEBUG - 2023-07-03 10:59:58 --> No URI present. Default controller set.
INFO - 2023-07-03 10:59:58 --> Router Class Initialized
INFO - 2023-07-03 10:59:58 --> Output Class Initialized
INFO - 2023-07-03 10:59:58 --> Security Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 10:59:58 --> Input Class Initialized
INFO - 2023-07-03 10:59:58 --> Language Class Initialized
INFO - 2023-07-03 10:59:58 --> Loader Class Initialized
INFO - 2023-07-03 10:59:58 --> Helper loaded: url_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: file_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: html_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: text_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: form_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: lang_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: security_helper
INFO - 2023-07-03 10:59:58 --> Helper loaded: cookie_helper
INFO - 2023-07-03 10:59:58 --> Database Driver Class Initialized
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:58 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:58 --> Total execution time: 0.1731
INFO - 2023-07-03 10:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 10:59:58 --> Parser Class Initialized
INFO - 2023-07-03 10:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 10:59:58 --> Pagination Class Initialized
INFO - 2023-07-03 10:59:58 --> Form Validation Class Initialized
INFO - 2023-07-03 10:59:58 --> Controller Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
DEBUG - 2023-07-03 10:59:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 10:59:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 10:59:58 --> Model Class Initialized
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 10:59:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 10:59:58 --> Final output sent to browser
DEBUG - 2023-07-03 10:59:58 --> Total execution time: 0.2569
ERROR - 2023-07-03 11:00:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:00:06 --> Config Class Initialized
INFO - 2023-07-03 11:00:06 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:00:06 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:00:06 --> Utf8 Class Initialized
INFO - 2023-07-03 11:00:06 --> URI Class Initialized
DEBUG - 2023-07-03 11:00:06 --> No URI present. Default controller set.
INFO - 2023-07-03 11:00:06 --> Router Class Initialized
INFO - 2023-07-03 11:00:06 --> Output Class Initialized
INFO - 2023-07-03 11:00:06 --> Security Class Initialized
DEBUG - 2023-07-03 11:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:00:06 --> Input Class Initialized
INFO - 2023-07-03 11:00:06 --> Language Class Initialized
INFO - 2023-07-03 11:00:06 --> Loader Class Initialized
INFO - 2023-07-03 11:00:06 --> Helper loaded: url_helper
INFO - 2023-07-03 11:00:06 --> Helper loaded: file_helper
INFO - 2023-07-03 11:00:06 --> Helper loaded: html_helper
INFO - 2023-07-03 11:00:06 --> Helper loaded: text_helper
INFO - 2023-07-03 11:00:06 --> Helper loaded: form_helper
INFO - 2023-07-03 11:00:06 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:00:06 --> Helper loaded: security_helper
INFO - 2023-07-03 11:00:06 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:00:06 --> Database Driver Class Initialized
INFO - 2023-07-03 11:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:00:06 --> Parser Class Initialized
INFO - 2023-07-03 11:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:00:06 --> Pagination Class Initialized
INFO - 2023-07-03 11:00:06 --> Form Validation Class Initialized
INFO - 2023-07-03 11:00:06 --> Controller Class Initialized
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
INFO - 2023-07-03 11:00:06 --> Model Class Initialized
INFO - 2023-07-03 11:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:00:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:00:07 --> Model Class Initialized
INFO - 2023-07-03 11:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:00:07 --> Final output sent to browser
DEBUG - 2023-07-03 11:00:07 --> Total execution time: 0.1898
ERROR - 2023-07-03 11:00:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:00:44 --> Config Class Initialized
INFO - 2023-07-03 11:00:44 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:00:44 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:00:44 --> Utf8 Class Initialized
INFO - 2023-07-03 11:00:44 --> URI Class Initialized
DEBUG - 2023-07-03 11:00:44 --> No URI present. Default controller set.
INFO - 2023-07-03 11:00:44 --> Router Class Initialized
INFO - 2023-07-03 11:00:44 --> Output Class Initialized
INFO - 2023-07-03 11:00:44 --> Security Class Initialized
DEBUG - 2023-07-03 11:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:00:44 --> Input Class Initialized
INFO - 2023-07-03 11:00:44 --> Language Class Initialized
INFO - 2023-07-03 11:00:44 --> Loader Class Initialized
INFO - 2023-07-03 11:00:44 --> Helper loaded: url_helper
INFO - 2023-07-03 11:00:44 --> Helper loaded: file_helper
INFO - 2023-07-03 11:00:44 --> Helper loaded: html_helper
INFO - 2023-07-03 11:00:44 --> Helper loaded: text_helper
INFO - 2023-07-03 11:00:44 --> Helper loaded: form_helper
INFO - 2023-07-03 11:00:44 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:00:44 --> Helper loaded: security_helper
INFO - 2023-07-03 11:00:44 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:00:44 --> Database Driver Class Initialized
INFO - 2023-07-03 11:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:00:44 --> Parser Class Initialized
INFO - 2023-07-03 11:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:00:44 --> Pagination Class Initialized
INFO - 2023-07-03 11:00:44 --> Form Validation Class Initialized
INFO - 2023-07-03 11:00:44 --> Controller Class Initialized
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
INFO - 2023-07-03 11:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:00:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:00:44 --> Model Class Initialized
INFO - 2023-07-03 11:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:00:44 --> Final output sent to browser
DEBUG - 2023-07-03 11:00:44 --> Total execution time: 0.1827
ERROR - 2023-07-03 11:00:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:00:51 --> Config Class Initialized
INFO - 2023-07-03 11:00:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:00:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:00:51 --> Utf8 Class Initialized
INFO - 2023-07-03 11:00:51 --> URI Class Initialized
DEBUG - 2023-07-03 11:00:51 --> No URI present. Default controller set.
INFO - 2023-07-03 11:00:51 --> Router Class Initialized
INFO - 2023-07-03 11:00:51 --> Output Class Initialized
INFO - 2023-07-03 11:00:51 --> Security Class Initialized
DEBUG - 2023-07-03 11:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:00:51 --> Input Class Initialized
INFO - 2023-07-03 11:00:51 --> Language Class Initialized
INFO - 2023-07-03 11:00:51 --> Loader Class Initialized
INFO - 2023-07-03 11:00:51 --> Helper loaded: url_helper
INFO - 2023-07-03 11:00:51 --> Helper loaded: file_helper
INFO - 2023-07-03 11:00:51 --> Helper loaded: html_helper
INFO - 2023-07-03 11:00:51 --> Helper loaded: text_helper
INFO - 2023-07-03 11:00:51 --> Helper loaded: form_helper
INFO - 2023-07-03 11:00:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:00:51 --> Helper loaded: security_helper
INFO - 2023-07-03 11:00:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:00:51 --> Database Driver Class Initialized
INFO - 2023-07-03 11:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:00:51 --> Parser Class Initialized
INFO - 2023-07-03 11:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:00:51 --> Pagination Class Initialized
INFO - 2023-07-03 11:00:51 --> Form Validation Class Initialized
INFO - 2023-07-03 11:00:51 --> Controller Class Initialized
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:00:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
INFO - 2023-07-03 11:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:00:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:00:51 --> Model Class Initialized
INFO - 2023-07-03 11:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:00:51 --> Final output sent to browser
DEBUG - 2023-07-03 11:00:51 --> Total execution time: 0.1701
ERROR - 2023-07-03 11:01:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:01:08 --> Config Class Initialized
INFO - 2023-07-03 11:01:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:01:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:01:08 --> Utf8 Class Initialized
INFO - 2023-07-03 11:01:08 --> URI Class Initialized
DEBUG - 2023-07-03 11:01:08 --> No URI present. Default controller set.
INFO - 2023-07-03 11:01:08 --> Router Class Initialized
INFO - 2023-07-03 11:01:08 --> Output Class Initialized
INFO - 2023-07-03 11:01:08 --> Security Class Initialized
DEBUG - 2023-07-03 11:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:01:08 --> Input Class Initialized
INFO - 2023-07-03 11:01:08 --> Language Class Initialized
INFO - 2023-07-03 11:01:08 --> Loader Class Initialized
INFO - 2023-07-03 11:01:08 --> Helper loaded: url_helper
INFO - 2023-07-03 11:01:08 --> Helper loaded: file_helper
INFO - 2023-07-03 11:01:08 --> Helper loaded: html_helper
INFO - 2023-07-03 11:01:08 --> Helper loaded: text_helper
INFO - 2023-07-03 11:01:08 --> Helper loaded: form_helper
INFO - 2023-07-03 11:01:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:01:08 --> Helper loaded: security_helper
INFO - 2023-07-03 11:01:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:01:08 --> Database Driver Class Initialized
INFO - 2023-07-03 11:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:01:08 --> Parser Class Initialized
INFO - 2023-07-03 11:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:01:08 --> Pagination Class Initialized
INFO - 2023-07-03 11:01:08 --> Form Validation Class Initialized
INFO - 2023-07-03 11:01:08 --> Controller Class Initialized
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
DEBUG - 2023-07-03 11:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
DEBUG - 2023-07-03 11:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
DEBUG - 2023-07-03 11:01:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
INFO - 2023-07-03 11:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:01:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:01:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:01:08 --> Model Class Initialized
INFO - 2023-07-03 11:01:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:01:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:01:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:01:09 --> Final output sent to browser
DEBUG - 2023-07-03 11:01:09 --> Total execution time: 0.2024
ERROR - 2023-07-03 11:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:18 --> Config Class Initialized
INFO - 2023-07-03 11:42:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:18 --> URI Class Initialized
DEBUG - 2023-07-03 11:42:18 --> No URI present. Default controller set.
INFO - 2023-07-03 11:42:18 --> Router Class Initialized
INFO - 2023-07-03 11:42:18 --> Output Class Initialized
INFO - 2023-07-03 11:42:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:18 --> Input Class Initialized
INFO - 2023-07-03 11:42:18 --> Language Class Initialized
INFO - 2023-07-03 11:42:18 --> Loader Class Initialized
INFO - 2023-07-03 11:42:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:18 --> Parser Class Initialized
INFO - 2023-07-03 11:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:18 --> Controller Class Initialized
INFO - 2023-07-03 11:42:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 11:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:18 --> Config Class Initialized
INFO - 2023-07-03 11:42:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:18 --> URI Class Initialized
INFO - 2023-07-03 11:42:18 --> Router Class Initialized
INFO - 2023-07-03 11:42:18 --> Output Class Initialized
INFO - 2023-07-03 11:42:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:18 --> Input Class Initialized
INFO - 2023-07-03 11:42:18 --> Language Class Initialized
INFO - 2023-07-03 11:42:18 --> Loader Class Initialized
INFO - 2023-07-03 11:42:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:18 --> Parser Class Initialized
INFO - 2023-07-03 11:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:18 --> Controller Class Initialized
INFO - 2023-07-03 11:42:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 11:42:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:42:18 --> Model Class Initialized
INFO - 2023-07-03 11:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:42:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:18 --> Total execution time: 0.0340
ERROR - 2023-07-03 11:42:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:21 --> Config Class Initialized
INFO - 2023-07-03 11:42:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:21 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:21 --> URI Class Initialized
INFO - 2023-07-03 11:42:21 --> Router Class Initialized
INFO - 2023-07-03 11:42:21 --> Output Class Initialized
INFO - 2023-07-03 11:42:21 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:21 --> Input Class Initialized
INFO - 2023-07-03 11:42:21 --> Language Class Initialized
INFO - 2023-07-03 11:42:21 --> Loader Class Initialized
INFO - 2023-07-03 11:42:21 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:21 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:21 --> Parser Class Initialized
INFO - 2023-07-03 11:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:21 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:21 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:21 --> Controller Class Initialized
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
INFO - 2023-07-03 11:42:21 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:21 --> Total execution time: 0.0175
ERROR - 2023-07-03 11:42:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:21 --> Config Class Initialized
INFO - 2023-07-03 11:42:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:21 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:21 --> URI Class Initialized
DEBUG - 2023-07-03 11:42:21 --> No URI present. Default controller set.
INFO - 2023-07-03 11:42:21 --> Router Class Initialized
INFO - 2023-07-03 11:42:21 --> Output Class Initialized
INFO - 2023-07-03 11:42:21 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:21 --> Input Class Initialized
INFO - 2023-07-03 11:42:21 --> Language Class Initialized
INFO - 2023-07-03 11:42:21 --> Loader Class Initialized
INFO - 2023-07-03 11:42:21 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:21 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:21 --> Parser Class Initialized
INFO - 2023-07-03 11:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:21 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:21 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:21 --> Controller Class Initialized
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
INFO - 2023-07-03 11:42:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:42:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:42:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:42:21 --> Model Class Initialized
INFO - 2023-07-03 11:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:42:22 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:22 --> Total execution time: 0.1859
ERROR - 2023-07-03 11:42:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:22 --> Config Class Initialized
INFO - 2023-07-03 11:42:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:22 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:22 --> URI Class Initialized
INFO - 2023-07-03 11:42:22 --> Router Class Initialized
INFO - 2023-07-03 11:42:22 --> Output Class Initialized
INFO - 2023-07-03 11:42:22 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:22 --> Input Class Initialized
INFO - 2023-07-03 11:42:22 --> Language Class Initialized
INFO - 2023-07-03 11:42:22 --> Loader Class Initialized
INFO - 2023-07-03 11:42:22 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:22 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:22 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:22 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:22 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:22 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:22 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:22 --> Parser Class Initialized
INFO - 2023-07-03 11:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:22 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:22 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:22 --> Controller Class Initialized
DEBUG - 2023-07-03 11:42:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:22 --> Model Class Initialized
INFO - 2023-07-03 11:42:22 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:22 --> Total execution time: 0.0130
ERROR - 2023-07-03 11:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:35 --> Config Class Initialized
INFO - 2023-07-03 11:42:35 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:35 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:35 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:35 --> URI Class Initialized
DEBUG - 2023-07-03 11:42:35 --> No URI present. Default controller set.
INFO - 2023-07-03 11:42:35 --> Router Class Initialized
INFO - 2023-07-03 11:42:35 --> Output Class Initialized
INFO - 2023-07-03 11:42:35 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:35 --> Input Class Initialized
INFO - 2023-07-03 11:42:35 --> Language Class Initialized
INFO - 2023-07-03 11:42:35 --> Loader Class Initialized
INFO - 2023-07-03 11:42:35 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:35 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:35 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:35 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:35 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:35 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:35 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:35 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:35 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:35 --> Parser Class Initialized
INFO - 2023-07-03 11:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:35 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:35 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:35 --> Controller Class Initialized
INFO - 2023-07-03 11:42:35 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 11:42:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:36 --> Config Class Initialized
INFO - 2023-07-03 11:42:36 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:36 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:36 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:36 --> URI Class Initialized
INFO - 2023-07-03 11:42:36 --> Router Class Initialized
INFO - 2023-07-03 11:42:36 --> Output Class Initialized
INFO - 2023-07-03 11:42:36 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:36 --> Input Class Initialized
INFO - 2023-07-03 11:42:36 --> Language Class Initialized
INFO - 2023-07-03 11:42:36 --> Loader Class Initialized
INFO - 2023-07-03 11:42:36 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:36 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:36 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:36 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:36 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:36 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:36 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:36 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:36 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:36 --> Parser Class Initialized
INFO - 2023-07-03 11:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:36 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:36 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:36 --> Controller Class Initialized
INFO - 2023-07-03 11:42:36 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 11:42:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:42:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:42:36 --> Model Class Initialized
INFO - 2023-07-03 11:42:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:42:36 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:36 --> Total execution time: 0.0340
ERROR - 2023-07-03 11:42:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:36 --> Config Class Initialized
INFO - 2023-07-03 11:42:36 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:36 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:36 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:36 --> URI Class Initialized
INFO - 2023-07-03 11:42:36 --> Router Class Initialized
INFO - 2023-07-03 11:42:36 --> Output Class Initialized
INFO - 2023-07-03 11:42:36 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:36 --> Input Class Initialized
INFO - 2023-07-03 11:42:36 --> Language Class Initialized
ERROR - 2023-07-03 11:42:36 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-07-03 11:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:37 --> Config Class Initialized
INFO - 2023-07-03 11:42:37 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:37 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:37 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:37 --> URI Class Initialized
INFO - 2023-07-03 11:42:37 --> Router Class Initialized
INFO - 2023-07-03 11:42:37 --> Output Class Initialized
INFO - 2023-07-03 11:42:37 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:37 --> Input Class Initialized
INFO - 2023-07-03 11:42:37 --> Language Class Initialized
ERROR - 2023-07-03 11:42:37 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-07-03 11:42:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:40 --> Config Class Initialized
INFO - 2023-07-03 11:42:40 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:40 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:40 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:40 --> URI Class Initialized
INFO - 2023-07-03 11:42:40 --> Router Class Initialized
INFO - 2023-07-03 11:42:40 --> Output Class Initialized
INFO - 2023-07-03 11:42:40 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:40 --> Input Class Initialized
INFO - 2023-07-03 11:42:40 --> Language Class Initialized
INFO - 2023-07-03 11:42:40 --> Loader Class Initialized
INFO - 2023-07-03 11:42:40 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:40 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:40 --> Parser Class Initialized
INFO - 2023-07-03 11:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:40 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:40 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:40 --> Controller Class Initialized
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
INFO - 2023-07-03 11:42:40 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:40 --> Total execution time: 0.0162
ERROR - 2023-07-03 11:42:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:40 --> Config Class Initialized
INFO - 2023-07-03 11:42:40 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:40 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:40 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:40 --> URI Class Initialized
DEBUG - 2023-07-03 11:42:40 --> No URI present. Default controller set.
INFO - 2023-07-03 11:42:40 --> Router Class Initialized
INFO - 2023-07-03 11:42:40 --> Output Class Initialized
INFO - 2023-07-03 11:42:40 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:40 --> Input Class Initialized
INFO - 2023-07-03 11:42:40 --> Language Class Initialized
INFO - 2023-07-03 11:42:40 --> Loader Class Initialized
INFO - 2023-07-03 11:42:40 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:40 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:40 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:40 --> Parser Class Initialized
INFO - 2023-07-03 11:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:40 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:40 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:40 --> Controller Class Initialized
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
INFO - 2023-07-03 11:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:42:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:42:40 --> Model Class Initialized
INFO - 2023-07-03 11:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:42:40 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:40 --> Total execution time: 0.0817
ERROR - 2023-07-03 11:42:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:45 --> Config Class Initialized
INFO - 2023-07-03 11:42:45 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:45 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:45 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:45 --> URI Class Initialized
INFO - 2023-07-03 11:42:45 --> Router Class Initialized
INFO - 2023-07-03 11:42:45 --> Output Class Initialized
INFO - 2023-07-03 11:42:45 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:45 --> Input Class Initialized
INFO - 2023-07-03 11:42:45 --> Language Class Initialized
INFO - 2023-07-03 11:42:45 --> Loader Class Initialized
INFO - 2023-07-03 11:42:45 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:45 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:45 --> Parser Class Initialized
INFO - 2023-07-03 11:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:45 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:45 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:45 --> Controller Class Initialized
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
INFO - 2023-07-03 11:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 11:42:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
INFO - 2023-07-03 11:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:42:45 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:45 --> Total execution time: 0.0774
ERROR - 2023-07-03 11:42:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:42:45 --> Config Class Initialized
INFO - 2023-07-03 11:42:45 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:42:45 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:42:45 --> Utf8 Class Initialized
INFO - 2023-07-03 11:42:45 --> URI Class Initialized
INFO - 2023-07-03 11:42:45 --> Router Class Initialized
INFO - 2023-07-03 11:42:45 --> Output Class Initialized
INFO - 2023-07-03 11:42:45 --> Security Class Initialized
DEBUG - 2023-07-03 11:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:42:45 --> Input Class Initialized
INFO - 2023-07-03 11:42:45 --> Language Class Initialized
INFO - 2023-07-03 11:42:45 --> Loader Class Initialized
INFO - 2023-07-03 11:42:45 --> Helper loaded: url_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: file_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: html_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: text_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: form_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: security_helper
INFO - 2023-07-03 11:42:45 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:42:45 --> Database Driver Class Initialized
INFO - 2023-07-03 11:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:42:45 --> Parser Class Initialized
INFO - 2023-07-03 11:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:42:45 --> Pagination Class Initialized
INFO - 2023-07-03 11:42:45 --> Form Validation Class Initialized
INFO - 2023-07-03 11:42:45 --> Controller Class Initialized
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
DEBUG - 2023-07-03 11:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:42:45 --> Model Class Initialized
INFO - 2023-07-03 11:42:45 --> Final output sent to browser
DEBUG - 2023-07-03 11:42:45 --> Total execution time: 0.0533
ERROR - 2023-07-03 11:43:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:43:19 --> Config Class Initialized
INFO - 2023-07-03 11:43:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:43:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:43:19 --> Utf8 Class Initialized
INFO - 2023-07-03 11:43:19 --> URI Class Initialized
INFO - 2023-07-03 11:43:19 --> Router Class Initialized
INFO - 2023-07-03 11:43:19 --> Output Class Initialized
INFO - 2023-07-03 11:43:19 --> Security Class Initialized
DEBUG - 2023-07-03 11:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:43:19 --> Input Class Initialized
INFO - 2023-07-03 11:43:19 --> Language Class Initialized
INFO - 2023-07-03 11:43:19 --> Loader Class Initialized
INFO - 2023-07-03 11:43:19 --> Helper loaded: url_helper
INFO - 2023-07-03 11:43:19 --> Helper loaded: file_helper
INFO - 2023-07-03 11:43:19 --> Helper loaded: html_helper
INFO - 2023-07-03 11:43:19 --> Helper loaded: text_helper
INFO - 2023-07-03 11:43:19 --> Helper loaded: form_helper
INFO - 2023-07-03 11:43:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:43:19 --> Helper loaded: security_helper
INFO - 2023-07-03 11:43:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:43:19 --> Database Driver Class Initialized
INFO - 2023-07-03 11:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:43:19 --> Parser Class Initialized
INFO - 2023-07-03 11:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:43:19 --> Pagination Class Initialized
INFO - 2023-07-03 11:43:19 --> Form Validation Class Initialized
INFO - 2023-07-03 11:43:19 --> Controller Class Initialized
INFO - 2023-07-03 11:43:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:43:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:43:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:43:19 --> Model Class Initialized
INFO - 2023-07-03 11:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 11:43:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:43:19 --> Model Class Initialized
INFO - 2023-07-03 11:43:19 --> Model Class Initialized
INFO - 2023-07-03 11:43:19 --> Model Class Initialized
INFO - 2023-07-03 11:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:43:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:43:19 --> Final output sent to browser
DEBUG - 2023-07-03 11:43:19 --> Total execution time: 0.0784
ERROR - 2023-07-03 11:43:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:43:20 --> Config Class Initialized
INFO - 2023-07-03 11:43:20 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:43:20 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:43:20 --> Utf8 Class Initialized
INFO - 2023-07-03 11:43:20 --> URI Class Initialized
INFO - 2023-07-03 11:43:20 --> Router Class Initialized
INFO - 2023-07-03 11:43:20 --> Output Class Initialized
INFO - 2023-07-03 11:43:20 --> Security Class Initialized
DEBUG - 2023-07-03 11:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:43:20 --> Input Class Initialized
INFO - 2023-07-03 11:43:20 --> Language Class Initialized
INFO - 2023-07-03 11:43:20 --> Loader Class Initialized
INFO - 2023-07-03 11:43:20 --> Helper loaded: url_helper
INFO - 2023-07-03 11:43:20 --> Helper loaded: file_helper
INFO - 2023-07-03 11:43:20 --> Helper loaded: html_helper
INFO - 2023-07-03 11:43:20 --> Helper loaded: text_helper
INFO - 2023-07-03 11:43:20 --> Helper loaded: form_helper
INFO - 2023-07-03 11:43:20 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:43:20 --> Helper loaded: security_helper
INFO - 2023-07-03 11:43:20 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:43:20 --> Database Driver Class Initialized
INFO - 2023-07-03 11:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:43:20 --> Parser Class Initialized
INFO - 2023-07-03 11:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:43:20 --> Pagination Class Initialized
INFO - 2023-07-03 11:43:20 --> Form Validation Class Initialized
INFO - 2023-07-03 11:43:20 --> Controller Class Initialized
INFO - 2023-07-03 11:43:20 --> Model Class Initialized
DEBUG - 2023-07-03 11:43:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:43:20 --> Model Class Initialized
DEBUG - 2023-07-03 11:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:43:20 --> Model Class Initialized
INFO - 2023-07-03 11:43:20 --> Final output sent to browser
DEBUG - 2023-07-03 11:43:20 --> Total execution time: 0.0475
ERROR - 2023-07-03 11:44:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:44:01 --> Config Class Initialized
INFO - 2023-07-03 11:44:01 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:44:01 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:44:01 --> Utf8 Class Initialized
INFO - 2023-07-03 11:44:01 --> URI Class Initialized
DEBUG - 2023-07-03 11:44:01 --> No URI present. Default controller set.
INFO - 2023-07-03 11:44:01 --> Router Class Initialized
INFO - 2023-07-03 11:44:01 --> Output Class Initialized
INFO - 2023-07-03 11:44:01 --> Security Class Initialized
DEBUG - 2023-07-03 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:44:01 --> Input Class Initialized
INFO - 2023-07-03 11:44:01 --> Language Class Initialized
INFO - 2023-07-03 11:44:01 --> Loader Class Initialized
INFO - 2023-07-03 11:44:01 --> Helper loaded: url_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: file_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: html_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: text_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: form_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: security_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:44:01 --> Database Driver Class Initialized
INFO - 2023-07-03 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:44:01 --> Parser Class Initialized
INFO - 2023-07-03 11:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:44:01 --> Pagination Class Initialized
INFO - 2023-07-03 11:44:01 --> Form Validation Class Initialized
INFO - 2023-07-03 11:44:01 --> Controller Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:44:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:44:01 --> Final output sent to browser
DEBUG - 2023-07-03 11:44:01 --> Total execution time: 0.1930
ERROR - 2023-07-03 11:44:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:44:01 --> Config Class Initialized
INFO - 2023-07-03 11:44:01 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:44:01 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:44:01 --> Utf8 Class Initialized
INFO - 2023-07-03 11:44:01 --> URI Class Initialized
INFO - 2023-07-03 11:44:01 --> Router Class Initialized
INFO - 2023-07-03 11:44:01 --> Output Class Initialized
INFO - 2023-07-03 11:44:01 --> Security Class Initialized
DEBUG - 2023-07-03 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:44:01 --> Input Class Initialized
INFO - 2023-07-03 11:44:01 --> Language Class Initialized
INFO - 2023-07-03 11:44:01 --> Loader Class Initialized
INFO - 2023-07-03 11:44:01 --> Helper loaded: url_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: file_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: html_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: text_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: form_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: security_helper
INFO - 2023-07-03 11:44:01 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:44:01 --> Database Driver Class Initialized
INFO - 2023-07-03 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:44:01 --> Parser Class Initialized
INFO - 2023-07-03 11:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:44:01 --> Pagination Class Initialized
INFO - 2023-07-03 11:44:01 --> Form Validation Class Initialized
INFO - 2023-07-03 11:44:01 --> Controller Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-03 11:44:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> Model Class Initialized
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:44:01 --> Final output sent to browser
DEBUG - 2023-07-03 11:44:01 --> Total execution time: 0.1450
ERROR - 2023-07-03 11:44:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:44:03 --> Config Class Initialized
INFO - 2023-07-03 11:44:03 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:44:03 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:44:03 --> Utf8 Class Initialized
INFO - 2023-07-03 11:44:03 --> URI Class Initialized
INFO - 2023-07-03 11:44:03 --> Router Class Initialized
INFO - 2023-07-03 11:44:03 --> Output Class Initialized
INFO - 2023-07-03 11:44:03 --> Security Class Initialized
DEBUG - 2023-07-03 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:44:03 --> Input Class Initialized
INFO - 2023-07-03 11:44:03 --> Language Class Initialized
INFO - 2023-07-03 11:44:03 --> Loader Class Initialized
INFO - 2023-07-03 11:44:03 --> Helper loaded: url_helper
INFO - 2023-07-03 11:44:03 --> Helper loaded: file_helper
INFO - 2023-07-03 11:44:03 --> Helper loaded: html_helper
INFO - 2023-07-03 11:44:03 --> Helper loaded: text_helper
INFO - 2023-07-03 11:44:03 --> Helper loaded: form_helper
INFO - 2023-07-03 11:44:03 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:44:03 --> Helper loaded: security_helper
INFO - 2023-07-03 11:44:03 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:44:03 --> Database Driver Class Initialized
INFO - 2023-07-03 11:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:44:03 --> Parser Class Initialized
INFO - 2023-07-03 11:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:44:03 --> Pagination Class Initialized
INFO - 2023-07-03 11:44:03 --> Form Validation Class Initialized
INFO - 2023-07-03 11:44:03 --> Controller Class Initialized
INFO - 2023-07-03 11:44:03 --> Model Class Initialized
INFO - 2023-07-03 11:44:03 --> Model Class Initialized
INFO - 2023-07-03 11:44:03 --> Final output sent to browser
DEBUG - 2023-07-03 11:44:03 --> Total execution time: 0.0272
ERROR - 2023-07-03 11:44:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:44:22 --> Config Class Initialized
INFO - 2023-07-03 11:44:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:44:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:44:22 --> Utf8 Class Initialized
INFO - 2023-07-03 11:44:22 --> URI Class Initialized
INFO - 2023-07-03 11:44:22 --> Router Class Initialized
INFO - 2023-07-03 11:44:22 --> Output Class Initialized
INFO - 2023-07-03 11:44:22 --> Security Class Initialized
DEBUG - 2023-07-03 11:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:44:22 --> Input Class Initialized
INFO - 2023-07-03 11:44:22 --> Language Class Initialized
INFO - 2023-07-03 11:44:22 --> Loader Class Initialized
INFO - 2023-07-03 11:44:22 --> Helper loaded: url_helper
INFO - 2023-07-03 11:44:22 --> Helper loaded: file_helper
INFO - 2023-07-03 11:44:22 --> Helper loaded: html_helper
INFO - 2023-07-03 11:44:22 --> Helper loaded: text_helper
INFO - 2023-07-03 11:44:22 --> Helper loaded: form_helper
INFO - 2023-07-03 11:44:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:44:22 --> Helper loaded: security_helper
INFO - 2023-07-03 11:44:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:44:22 --> Database Driver Class Initialized
INFO - 2023-07-03 11:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:44:22 --> Parser Class Initialized
INFO - 2023-07-03 11:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:44:22 --> Pagination Class Initialized
INFO - 2023-07-03 11:44:22 --> Form Validation Class Initialized
INFO - 2023-07-03 11:44:22 --> Controller Class Initialized
INFO - 2023-07-03 11:44:22 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:22 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:22 --> Model Class Initialized
INFO - 2023-07-03 11:44:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:44:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:44:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:44:22 --> Model Class Initialized
INFO - 2023-07-03 11:44:22 --> Model Class Initialized
INFO - 2023-07-03 11:44:22 --> Model Class Initialized
INFO - 2023-07-03 11:44:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:44:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:44:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:44:22 --> Final output sent to browser
DEBUG - 2023-07-03 11:44:22 --> Total execution time: 0.1596
ERROR - 2023-07-03 11:44:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:44:23 --> Config Class Initialized
INFO - 2023-07-03 11:44:23 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:44:23 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:44:23 --> Utf8 Class Initialized
INFO - 2023-07-03 11:44:23 --> URI Class Initialized
INFO - 2023-07-03 11:44:23 --> Router Class Initialized
INFO - 2023-07-03 11:44:23 --> Output Class Initialized
INFO - 2023-07-03 11:44:23 --> Security Class Initialized
DEBUG - 2023-07-03 11:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:44:23 --> Input Class Initialized
INFO - 2023-07-03 11:44:23 --> Language Class Initialized
INFO - 2023-07-03 11:44:23 --> Loader Class Initialized
INFO - 2023-07-03 11:44:23 --> Helper loaded: url_helper
INFO - 2023-07-03 11:44:23 --> Helper loaded: file_helper
INFO - 2023-07-03 11:44:23 --> Helper loaded: html_helper
INFO - 2023-07-03 11:44:23 --> Helper loaded: text_helper
INFO - 2023-07-03 11:44:23 --> Helper loaded: form_helper
INFO - 2023-07-03 11:44:23 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:44:23 --> Helper loaded: security_helper
INFO - 2023-07-03 11:44:23 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:44:23 --> Database Driver Class Initialized
INFO - 2023-07-03 11:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:44:23 --> Parser Class Initialized
INFO - 2023-07-03 11:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:44:23 --> Pagination Class Initialized
INFO - 2023-07-03 11:44:23 --> Form Validation Class Initialized
INFO - 2023-07-03 11:44:23 --> Controller Class Initialized
INFO - 2023-07-03 11:44:23 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:23 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:23 --> Model Class Initialized
INFO - 2023-07-03 11:44:23 --> Final output sent to browser
DEBUG - 2023-07-03 11:44:23 --> Total execution time: 0.0580
ERROR - 2023-07-03 11:44:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:44:31 --> Config Class Initialized
INFO - 2023-07-03 11:44:31 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:44:31 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:44:31 --> Utf8 Class Initialized
INFO - 2023-07-03 11:44:31 --> URI Class Initialized
INFO - 2023-07-03 11:44:31 --> Router Class Initialized
INFO - 2023-07-03 11:44:31 --> Output Class Initialized
INFO - 2023-07-03 11:44:31 --> Security Class Initialized
DEBUG - 2023-07-03 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:44:31 --> Input Class Initialized
INFO - 2023-07-03 11:44:31 --> Language Class Initialized
INFO - 2023-07-03 11:44:31 --> Loader Class Initialized
INFO - 2023-07-03 11:44:31 --> Helper loaded: url_helper
INFO - 2023-07-03 11:44:31 --> Helper loaded: file_helper
INFO - 2023-07-03 11:44:31 --> Helper loaded: html_helper
INFO - 2023-07-03 11:44:31 --> Helper loaded: text_helper
INFO - 2023-07-03 11:44:31 --> Helper loaded: form_helper
INFO - 2023-07-03 11:44:31 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:44:31 --> Helper loaded: security_helper
INFO - 2023-07-03 11:44:31 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:44:31 --> Database Driver Class Initialized
INFO - 2023-07-03 11:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:44:31 --> Parser Class Initialized
INFO - 2023-07-03 11:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:44:31 --> Pagination Class Initialized
INFO - 2023-07-03 11:44:31 --> Form Validation Class Initialized
INFO - 2023-07-03 11:44:31 --> Controller Class Initialized
INFO - 2023-07-03 11:44:31 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:31 --> Model Class Initialized
DEBUG - 2023-07-03 11:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:44:31 --> Model Class Initialized
INFO - 2023-07-03 11:44:31 --> Final output sent to browser
DEBUG - 2023-07-03 11:44:31 --> Total execution time: 0.3436
ERROR - 2023-07-03 11:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:45:22 --> Config Class Initialized
INFO - 2023-07-03 11:45:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:45:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:45:22 --> Utf8 Class Initialized
INFO - 2023-07-03 11:45:22 --> URI Class Initialized
DEBUG - 2023-07-03 11:45:22 --> No URI present. Default controller set.
INFO - 2023-07-03 11:45:22 --> Router Class Initialized
INFO - 2023-07-03 11:45:22 --> Output Class Initialized
INFO - 2023-07-03 11:45:22 --> Security Class Initialized
DEBUG - 2023-07-03 11:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:45:22 --> Input Class Initialized
INFO - 2023-07-03 11:45:22 --> Language Class Initialized
INFO - 2023-07-03 11:45:22 --> Loader Class Initialized
INFO - 2023-07-03 11:45:22 --> Helper loaded: url_helper
INFO - 2023-07-03 11:45:22 --> Helper loaded: file_helper
INFO - 2023-07-03 11:45:22 --> Helper loaded: html_helper
INFO - 2023-07-03 11:45:22 --> Helper loaded: text_helper
INFO - 2023-07-03 11:45:22 --> Helper loaded: form_helper
INFO - 2023-07-03 11:45:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:45:22 --> Helper loaded: security_helper
INFO - 2023-07-03 11:45:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:45:22 --> Database Driver Class Initialized
INFO - 2023-07-03 11:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:45:22 --> Parser Class Initialized
INFO - 2023-07-03 11:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:45:22 --> Pagination Class Initialized
INFO - 2023-07-03 11:45:22 --> Form Validation Class Initialized
INFO - 2023-07-03 11:45:22 --> Controller Class Initialized
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
DEBUG - 2023-07-03 11:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
DEBUG - 2023-07-03 11:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
DEBUG - 2023-07-03 11:45:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
INFO - 2023-07-03 11:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:45:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:45:22 --> Model Class Initialized
INFO - 2023-07-03 11:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:45:22 --> Final output sent to browser
DEBUG - 2023-07-03 11:45:22 --> Total execution time: 0.1938
ERROR - 2023-07-03 11:45:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:45:50 --> Config Class Initialized
INFO - 2023-07-03 11:45:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:45:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:45:50 --> Utf8 Class Initialized
INFO - 2023-07-03 11:45:50 --> URI Class Initialized
INFO - 2023-07-03 11:45:50 --> Router Class Initialized
INFO - 2023-07-03 11:45:50 --> Output Class Initialized
INFO - 2023-07-03 11:45:50 --> Security Class Initialized
DEBUG - 2023-07-03 11:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:45:50 --> Input Class Initialized
INFO - 2023-07-03 11:45:50 --> Language Class Initialized
INFO - 2023-07-03 11:45:50 --> Loader Class Initialized
INFO - 2023-07-03 11:45:50 --> Helper loaded: url_helper
INFO - 2023-07-03 11:45:50 --> Helper loaded: file_helper
INFO - 2023-07-03 11:45:50 --> Helper loaded: html_helper
INFO - 2023-07-03 11:45:50 --> Helper loaded: text_helper
INFO - 2023-07-03 11:45:50 --> Helper loaded: form_helper
INFO - 2023-07-03 11:45:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:45:50 --> Helper loaded: security_helper
INFO - 2023-07-03 11:45:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:45:50 --> Database Driver Class Initialized
INFO - 2023-07-03 11:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:45:50 --> Parser Class Initialized
INFO - 2023-07-03 11:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:45:50 --> Pagination Class Initialized
INFO - 2023-07-03 11:45:50 --> Form Validation Class Initialized
INFO - 2023-07-03 11:45:50 --> Controller Class Initialized
DEBUG - 2023-07-03 11:45:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/return/form.php
DEBUG - 2023-07-03 11:45:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:45:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:45:50 --> Model Class Initialized
INFO - 2023-07-03 11:45:50 --> Model Class Initialized
INFO - 2023-07-03 11:45:50 --> Model Class Initialized
INFO - 2023-07-03 11:45:50 --> Model Class Initialized
INFO - 2023-07-03 11:45:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:45:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:45:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:45:50 --> Final output sent to browser
DEBUG - 2023-07-03 11:45:50 --> Total execution time: 0.1586
ERROR - 2023-07-03 11:45:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:45:55 --> Config Class Initialized
INFO - 2023-07-03 11:45:55 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:45:55 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:45:55 --> Utf8 Class Initialized
INFO - 2023-07-03 11:45:55 --> URI Class Initialized
INFO - 2023-07-03 11:45:55 --> Router Class Initialized
INFO - 2023-07-03 11:45:55 --> Output Class Initialized
INFO - 2023-07-03 11:45:55 --> Security Class Initialized
DEBUG - 2023-07-03 11:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:45:55 --> Input Class Initialized
INFO - 2023-07-03 11:45:55 --> Language Class Initialized
INFO - 2023-07-03 11:45:55 --> Loader Class Initialized
INFO - 2023-07-03 11:45:55 --> Helper loaded: url_helper
INFO - 2023-07-03 11:45:55 --> Helper loaded: file_helper
INFO - 2023-07-03 11:45:55 --> Helper loaded: html_helper
INFO - 2023-07-03 11:45:55 --> Helper loaded: text_helper
INFO - 2023-07-03 11:45:55 --> Helper loaded: form_helper
INFO - 2023-07-03 11:45:55 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:45:55 --> Helper loaded: security_helper
INFO - 2023-07-03 11:45:55 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:45:55 --> Database Driver Class Initialized
INFO - 2023-07-03 11:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:45:55 --> Parser Class Initialized
INFO - 2023-07-03 11:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:45:55 --> Pagination Class Initialized
INFO - 2023-07-03 11:45:55 --> Form Validation Class Initialized
INFO - 2023-07-03 11:45:55 --> Controller Class Initialized
INFO - 2023-07-03 11:45:55 --> Model Class Initialized
DEBUG - 2023-07-03 11:45:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:55 --> Model Class Initialized
INFO - 2023-07-03 11:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-03 11:45:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:45:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:45:55 --> Model Class Initialized
INFO - 2023-07-03 11:45:55 --> Model Class Initialized
INFO - 2023-07-03 11:45:55 --> Model Class Initialized
INFO - 2023-07-03 11:45:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:45:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:45:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:45:56 --> Final output sent to browser
DEBUG - 2023-07-03 11:45:56 --> Total execution time: 0.1591
ERROR - 2023-07-03 11:45:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:45:56 --> Config Class Initialized
INFO - 2023-07-03 11:45:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:45:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:45:56 --> Utf8 Class Initialized
INFO - 2023-07-03 11:45:56 --> URI Class Initialized
INFO - 2023-07-03 11:45:56 --> Router Class Initialized
INFO - 2023-07-03 11:45:56 --> Output Class Initialized
INFO - 2023-07-03 11:45:56 --> Security Class Initialized
DEBUG - 2023-07-03 11:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:45:56 --> Input Class Initialized
INFO - 2023-07-03 11:45:56 --> Language Class Initialized
INFO - 2023-07-03 11:45:56 --> Loader Class Initialized
INFO - 2023-07-03 11:45:56 --> Helper loaded: url_helper
INFO - 2023-07-03 11:45:56 --> Helper loaded: file_helper
INFO - 2023-07-03 11:45:56 --> Helper loaded: html_helper
INFO - 2023-07-03 11:45:56 --> Helper loaded: text_helper
INFO - 2023-07-03 11:45:56 --> Helper loaded: form_helper
INFO - 2023-07-03 11:45:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:45:56 --> Helper loaded: security_helper
INFO - 2023-07-03 11:45:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:45:56 --> Database Driver Class Initialized
INFO - 2023-07-03 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:45:56 --> Parser Class Initialized
INFO - 2023-07-03 11:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:45:56 --> Pagination Class Initialized
INFO - 2023-07-03 11:45:56 --> Form Validation Class Initialized
INFO - 2023-07-03 11:45:56 --> Controller Class Initialized
INFO - 2023-07-03 11:45:56 --> Model Class Initialized
DEBUG - 2023-07-03 11:45:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:45:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:45:56 --> Model Class Initialized
INFO - 2023-07-03 11:45:56 --> Final output sent to browser
DEBUG - 2023-07-03 11:45:56 --> Total execution time: 0.0294
ERROR - 2023-07-03 11:46:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:46:00 --> Config Class Initialized
INFO - 2023-07-03 11:46:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:46:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:46:00 --> Utf8 Class Initialized
INFO - 2023-07-03 11:46:00 --> URI Class Initialized
INFO - 2023-07-03 11:46:00 --> Router Class Initialized
INFO - 2023-07-03 11:46:00 --> Output Class Initialized
INFO - 2023-07-03 11:46:00 --> Security Class Initialized
DEBUG - 2023-07-03 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:46:00 --> Input Class Initialized
INFO - 2023-07-03 11:46:00 --> Language Class Initialized
INFO - 2023-07-03 11:46:00 --> Loader Class Initialized
INFO - 2023-07-03 11:46:00 --> Helper loaded: url_helper
INFO - 2023-07-03 11:46:00 --> Helper loaded: file_helper
INFO - 2023-07-03 11:46:00 --> Helper loaded: html_helper
INFO - 2023-07-03 11:46:00 --> Helper loaded: text_helper
INFO - 2023-07-03 11:46:00 --> Helper loaded: form_helper
INFO - 2023-07-03 11:46:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:46:00 --> Helper loaded: security_helper
INFO - 2023-07-03 11:46:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:46:00 --> Database Driver Class Initialized
INFO - 2023-07-03 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:46:00 --> Parser Class Initialized
INFO - 2023-07-03 11:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:46:00 --> Pagination Class Initialized
INFO - 2023-07-03 11:46:00 --> Form Validation Class Initialized
INFO - 2023-07-03 11:46:00 --> Controller Class Initialized
INFO - 2023-07-03 11:46:00 --> Model Class Initialized
DEBUG - 2023-07-03 11:46:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:00 --> Model Class Initialized
INFO - 2023-07-03 11:46:01 --> Final output sent to browser
DEBUG - 2023-07-03 11:46:01 --> Total execution time: 0.0732
ERROR - 2023-07-03 11:46:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:46:13 --> Config Class Initialized
INFO - 2023-07-03 11:46:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:46:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:46:13 --> Utf8 Class Initialized
INFO - 2023-07-03 11:46:13 --> URI Class Initialized
INFO - 2023-07-03 11:46:13 --> Router Class Initialized
INFO - 2023-07-03 11:46:13 --> Output Class Initialized
INFO - 2023-07-03 11:46:13 --> Security Class Initialized
DEBUG - 2023-07-03 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:46:13 --> Input Class Initialized
INFO - 2023-07-03 11:46:13 --> Language Class Initialized
INFO - 2023-07-03 11:46:13 --> Loader Class Initialized
INFO - 2023-07-03 11:46:13 --> Helper loaded: url_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: file_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: html_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: text_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: form_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: security_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:46:13 --> Database Driver Class Initialized
INFO - 2023-07-03 11:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:46:13 --> Parser Class Initialized
INFO - 2023-07-03 11:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:46:13 --> Pagination Class Initialized
INFO - 2023-07-03 11:46:13 --> Form Validation Class Initialized
INFO - 2023-07-03 11:46:13 --> Controller Class Initialized
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:46:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-03 11:46:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:46:13 --> Final output sent to browser
DEBUG - 2023-07-03 11:46:13 --> Total execution time: 0.1490
ERROR - 2023-07-03 11:46:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:46:13 --> Config Class Initialized
INFO - 2023-07-03 11:46:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:46:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:46:13 --> Utf8 Class Initialized
INFO - 2023-07-03 11:46:13 --> URI Class Initialized
INFO - 2023-07-03 11:46:13 --> Router Class Initialized
INFO - 2023-07-03 11:46:13 --> Output Class Initialized
INFO - 2023-07-03 11:46:13 --> Security Class Initialized
DEBUG - 2023-07-03 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:46:13 --> Input Class Initialized
INFO - 2023-07-03 11:46:13 --> Language Class Initialized
INFO - 2023-07-03 11:46:13 --> Loader Class Initialized
INFO - 2023-07-03 11:46:13 --> Helper loaded: url_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: file_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: html_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: text_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: form_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: security_helper
INFO - 2023-07-03 11:46:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:46:13 --> Database Driver Class Initialized
INFO - 2023-07-03 11:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:46:13 --> Parser Class Initialized
INFO - 2023-07-03 11:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:46:13 --> Pagination Class Initialized
INFO - 2023-07-03 11:46:13 --> Form Validation Class Initialized
INFO - 2023-07-03 11:46:13 --> Controller Class Initialized
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:46:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-03 11:46:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> Model Class Initialized
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:46:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:46:13 --> Final output sent to browser
DEBUG - 2023-07-03 11:46:13 --> Total execution time: 0.1468
ERROR - 2023-07-03 11:46:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:46:14 --> Config Class Initialized
INFO - 2023-07-03 11:46:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:46:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:46:14 --> Utf8 Class Initialized
INFO - 2023-07-03 11:46:14 --> URI Class Initialized
INFO - 2023-07-03 11:46:14 --> Router Class Initialized
INFO - 2023-07-03 11:46:14 --> Output Class Initialized
INFO - 2023-07-03 11:46:14 --> Security Class Initialized
DEBUG - 2023-07-03 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:46:14 --> Input Class Initialized
INFO - 2023-07-03 11:46:14 --> Language Class Initialized
INFO - 2023-07-03 11:46:14 --> Loader Class Initialized
INFO - 2023-07-03 11:46:14 --> Helper loaded: url_helper
INFO - 2023-07-03 11:46:14 --> Helper loaded: file_helper
INFO - 2023-07-03 11:46:14 --> Helper loaded: html_helper
INFO - 2023-07-03 11:46:14 --> Helper loaded: text_helper
INFO - 2023-07-03 11:46:14 --> Helper loaded: form_helper
INFO - 2023-07-03 11:46:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:46:14 --> Helper loaded: security_helper
INFO - 2023-07-03 11:46:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:46:14 --> Database Driver Class Initialized
INFO - 2023-07-03 11:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:46:14 --> Parser Class Initialized
INFO - 2023-07-03 11:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:46:14 --> Pagination Class Initialized
INFO - 2023-07-03 11:46:14 --> Form Validation Class Initialized
INFO - 2023-07-03 11:46:14 --> Controller Class Initialized
INFO - 2023-07-03 11:46:14 --> Model Class Initialized
DEBUG - 2023-07-03 11:46:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:14 --> Model Class Initialized
INFO - 2023-07-03 11:46:14 --> Final output sent to browser
DEBUG - 2023-07-03 11:46:14 --> Total execution time: 0.0280
ERROR - 2023-07-03 11:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:46:28 --> Config Class Initialized
INFO - 2023-07-03 11:46:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:46:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:46:28 --> Utf8 Class Initialized
INFO - 2023-07-03 11:46:28 --> URI Class Initialized
INFO - 2023-07-03 11:46:28 --> Router Class Initialized
INFO - 2023-07-03 11:46:28 --> Output Class Initialized
INFO - 2023-07-03 11:46:28 --> Security Class Initialized
DEBUG - 2023-07-03 11:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:46:28 --> Input Class Initialized
INFO - 2023-07-03 11:46:28 --> Language Class Initialized
INFO - 2023-07-03 11:46:28 --> Loader Class Initialized
INFO - 2023-07-03 11:46:28 --> Helper loaded: url_helper
INFO - 2023-07-03 11:46:28 --> Helper loaded: file_helper
INFO - 2023-07-03 11:46:28 --> Helper loaded: html_helper
INFO - 2023-07-03 11:46:28 --> Helper loaded: text_helper
INFO - 2023-07-03 11:46:28 --> Helper loaded: form_helper
INFO - 2023-07-03 11:46:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:46:28 --> Helper loaded: security_helper
INFO - 2023-07-03 11:46:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:46:28 --> Database Driver Class Initialized
INFO - 2023-07-03 11:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:46:28 --> Parser Class Initialized
INFO - 2023-07-03 11:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:46:28 --> Pagination Class Initialized
INFO - 2023-07-03 11:46:28 --> Form Validation Class Initialized
INFO - 2023-07-03 11:46:28 --> Controller Class Initialized
DEBUG - 2023-07-03 11:46:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:28 --> Model Class Initialized
DEBUG - 2023-07-03 11:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:28 --> Model Class Initialized
DEBUG - 2023-07-03 11:46:28 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:28 --> Model Class Initialized
INFO - 2023-07-03 11:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 11:46:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:46:28 --> Model Class Initialized
INFO - 2023-07-03 11:46:28 --> Model Class Initialized
INFO - 2023-07-03 11:46:28 --> Model Class Initialized
INFO - 2023-07-03 11:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:46:28 --> Final output sent to browser
DEBUG - 2023-07-03 11:46:28 --> Total execution time: 0.1502
ERROR - 2023-07-03 11:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:46:29 --> Config Class Initialized
INFO - 2023-07-03 11:46:29 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:46:29 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:46:29 --> Utf8 Class Initialized
INFO - 2023-07-03 11:46:29 --> URI Class Initialized
INFO - 2023-07-03 11:46:29 --> Router Class Initialized
INFO - 2023-07-03 11:46:29 --> Output Class Initialized
INFO - 2023-07-03 11:46:29 --> Security Class Initialized
DEBUG - 2023-07-03 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:46:29 --> Input Class Initialized
INFO - 2023-07-03 11:46:29 --> Language Class Initialized
INFO - 2023-07-03 11:46:29 --> Loader Class Initialized
INFO - 2023-07-03 11:46:29 --> Helper loaded: url_helper
INFO - 2023-07-03 11:46:29 --> Helper loaded: file_helper
INFO - 2023-07-03 11:46:29 --> Helper loaded: html_helper
INFO - 2023-07-03 11:46:29 --> Helper loaded: text_helper
INFO - 2023-07-03 11:46:29 --> Helper loaded: form_helper
INFO - 2023-07-03 11:46:29 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:46:29 --> Helper loaded: security_helper
INFO - 2023-07-03 11:46:29 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:46:29 --> Database Driver Class Initialized
INFO - 2023-07-03 11:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:46:29 --> Parser Class Initialized
INFO - 2023-07-03 11:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:46:29 --> Pagination Class Initialized
INFO - 2023-07-03 11:46:29 --> Form Validation Class Initialized
INFO - 2023-07-03 11:46:29 --> Controller Class Initialized
DEBUG - 2023-07-03 11:46:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:29 --> Model Class Initialized
DEBUG - 2023-07-03 11:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:46:29 --> Model Class Initialized
INFO - 2023-07-03 11:46:29 --> Final output sent to browser
DEBUG - 2023-07-03 11:46:29 --> Total execution time: 0.0310
ERROR - 2023-07-03 11:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:47:13 --> Config Class Initialized
INFO - 2023-07-03 11:47:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:47:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:47:13 --> Utf8 Class Initialized
INFO - 2023-07-03 11:47:13 --> URI Class Initialized
INFO - 2023-07-03 11:47:13 --> Router Class Initialized
INFO - 2023-07-03 11:47:13 --> Output Class Initialized
INFO - 2023-07-03 11:47:13 --> Security Class Initialized
DEBUG - 2023-07-03 11:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:47:13 --> Input Class Initialized
INFO - 2023-07-03 11:47:13 --> Language Class Initialized
INFO - 2023-07-03 11:47:13 --> Loader Class Initialized
INFO - 2023-07-03 11:47:13 --> Helper loaded: url_helper
INFO - 2023-07-03 11:47:13 --> Helper loaded: file_helper
INFO - 2023-07-03 11:47:13 --> Helper loaded: html_helper
INFO - 2023-07-03 11:47:13 --> Helper loaded: text_helper
INFO - 2023-07-03 11:47:13 --> Helper loaded: form_helper
INFO - 2023-07-03 11:47:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:47:13 --> Helper loaded: security_helper
INFO - 2023-07-03 11:47:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:47:13 --> Database Driver Class Initialized
INFO - 2023-07-03 11:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:47:13 --> Parser Class Initialized
INFO - 2023-07-03 11:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:47:13 --> Pagination Class Initialized
INFO - 2023-07-03 11:47:13 --> Form Validation Class Initialized
INFO - 2023-07-03 11:47:13 --> Controller Class Initialized
INFO - 2023-07-03 11:47:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:47:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:47:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:47:13 --> Model Class Initialized
INFO - 2023-07-03 11:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:47:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:47:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:47:13 --> Model Class Initialized
INFO - 2023-07-03 11:47:13 --> Model Class Initialized
INFO - 2023-07-03 11:47:13 --> Model Class Initialized
INFO - 2023-07-03 11:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:47:14 --> Final output sent to browser
DEBUG - 2023-07-03 11:47:14 --> Total execution time: 0.1480
ERROR - 2023-07-03 11:47:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:47:14 --> Config Class Initialized
INFO - 2023-07-03 11:47:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:47:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:47:14 --> Utf8 Class Initialized
INFO - 2023-07-03 11:47:14 --> URI Class Initialized
INFO - 2023-07-03 11:47:14 --> Router Class Initialized
INFO - 2023-07-03 11:47:14 --> Output Class Initialized
INFO - 2023-07-03 11:47:14 --> Security Class Initialized
DEBUG - 2023-07-03 11:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:47:14 --> Input Class Initialized
INFO - 2023-07-03 11:47:14 --> Language Class Initialized
INFO - 2023-07-03 11:47:14 --> Loader Class Initialized
INFO - 2023-07-03 11:47:14 --> Helper loaded: url_helper
INFO - 2023-07-03 11:47:14 --> Helper loaded: file_helper
INFO - 2023-07-03 11:47:14 --> Helper loaded: html_helper
INFO - 2023-07-03 11:47:14 --> Helper loaded: text_helper
INFO - 2023-07-03 11:47:14 --> Helper loaded: form_helper
INFO - 2023-07-03 11:47:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:47:14 --> Helper loaded: security_helper
INFO - 2023-07-03 11:47:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:47:14 --> Database Driver Class Initialized
INFO - 2023-07-03 11:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:47:14 --> Parser Class Initialized
INFO - 2023-07-03 11:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:47:14 --> Pagination Class Initialized
INFO - 2023-07-03 11:47:14 --> Form Validation Class Initialized
INFO - 2023-07-03 11:47:14 --> Controller Class Initialized
INFO - 2023-07-03 11:47:14 --> Model Class Initialized
DEBUG - 2023-07-03 11:47:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:47:14 --> Model Class Initialized
DEBUG - 2023-07-03 11:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:47:14 --> Model Class Initialized
INFO - 2023-07-03 11:47:14 --> Final output sent to browser
DEBUG - 2023-07-03 11:47:14 --> Total execution time: 0.0578
ERROR - 2023-07-03 11:47:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:47:19 --> Config Class Initialized
INFO - 2023-07-03 11:47:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:47:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:47:19 --> Utf8 Class Initialized
INFO - 2023-07-03 11:47:19 --> URI Class Initialized
INFO - 2023-07-03 11:47:19 --> Router Class Initialized
INFO - 2023-07-03 11:47:19 --> Output Class Initialized
INFO - 2023-07-03 11:47:19 --> Security Class Initialized
DEBUG - 2023-07-03 11:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:47:19 --> Input Class Initialized
INFO - 2023-07-03 11:47:19 --> Language Class Initialized
INFO - 2023-07-03 11:47:19 --> Loader Class Initialized
INFO - 2023-07-03 11:47:19 --> Helper loaded: url_helper
INFO - 2023-07-03 11:47:19 --> Helper loaded: file_helper
INFO - 2023-07-03 11:47:19 --> Helper loaded: html_helper
INFO - 2023-07-03 11:47:19 --> Helper loaded: text_helper
INFO - 2023-07-03 11:47:19 --> Helper loaded: form_helper
INFO - 2023-07-03 11:47:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:47:19 --> Helper loaded: security_helper
INFO - 2023-07-03 11:47:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:47:19 --> Database Driver Class Initialized
INFO - 2023-07-03 11:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:47:19 --> Parser Class Initialized
INFO - 2023-07-03 11:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:47:19 --> Pagination Class Initialized
INFO - 2023-07-03 11:47:19 --> Form Validation Class Initialized
INFO - 2023-07-03 11:47:19 --> Controller Class Initialized
INFO - 2023-07-03 11:47:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:47:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:47:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:47:19 --> Model Class Initialized
INFO - 2023-07-03 11:47:19 --> Final output sent to browser
DEBUG - 2023-07-03 11:47:19 --> Total execution time: 0.3294
ERROR - 2023-07-03 11:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:48:53 --> Config Class Initialized
INFO - 2023-07-03 11:48:53 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:48:53 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:48:53 --> Utf8 Class Initialized
INFO - 2023-07-03 11:48:53 --> URI Class Initialized
INFO - 2023-07-03 11:48:53 --> Router Class Initialized
INFO - 2023-07-03 11:48:53 --> Output Class Initialized
INFO - 2023-07-03 11:48:53 --> Security Class Initialized
DEBUG - 2023-07-03 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:48:53 --> Input Class Initialized
INFO - 2023-07-03 11:48:53 --> Language Class Initialized
INFO - 2023-07-03 11:48:53 --> Loader Class Initialized
INFO - 2023-07-03 11:48:53 --> Helper loaded: url_helper
INFO - 2023-07-03 11:48:53 --> Helper loaded: file_helper
INFO - 2023-07-03 11:48:53 --> Helper loaded: html_helper
INFO - 2023-07-03 11:48:53 --> Helper loaded: text_helper
INFO - 2023-07-03 11:48:53 --> Helper loaded: form_helper
INFO - 2023-07-03 11:48:53 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:48:53 --> Helper loaded: security_helper
INFO - 2023-07-03 11:48:53 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:48:53 --> Database Driver Class Initialized
INFO - 2023-07-03 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:48:53 --> Parser Class Initialized
INFO - 2023-07-03 11:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:48:53 --> Pagination Class Initialized
INFO - 2023-07-03 11:48:53 --> Form Validation Class Initialized
INFO - 2023-07-03 11:48:53 --> Controller Class Initialized
DEBUG - 2023-07-03 11:48:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:53 --> Model Class Initialized
DEBUG - 2023-07-03 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:53 --> Model Class Initialized
DEBUG - 2023-07-03 11:48:53 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:53 --> Model Class Initialized
INFO - 2023-07-03 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 11:48:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:48:53 --> Model Class Initialized
INFO - 2023-07-03 11:48:53 --> Model Class Initialized
INFO - 2023-07-03 11:48:53 --> Model Class Initialized
INFO - 2023-07-03 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:48:53 --> Final output sent to browser
DEBUG - 2023-07-03 11:48:53 --> Total execution time: 0.1477
ERROR - 2023-07-03 11:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:48:54 --> Config Class Initialized
INFO - 2023-07-03 11:48:54 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:48:54 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:48:54 --> Utf8 Class Initialized
INFO - 2023-07-03 11:48:54 --> URI Class Initialized
INFO - 2023-07-03 11:48:54 --> Router Class Initialized
INFO - 2023-07-03 11:48:54 --> Output Class Initialized
INFO - 2023-07-03 11:48:54 --> Security Class Initialized
DEBUG - 2023-07-03 11:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:48:54 --> Input Class Initialized
INFO - 2023-07-03 11:48:54 --> Language Class Initialized
INFO - 2023-07-03 11:48:54 --> Loader Class Initialized
INFO - 2023-07-03 11:48:54 --> Helper loaded: url_helper
INFO - 2023-07-03 11:48:54 --> Helper loaded: file_helper
INFO - 2023-07-03 11:48:54 --> Helper loaded: html_helper
INFO - 2023-07-03 11:48:54 --> Helper loaded: text_helper
INFO - 2023-07-03 11:48:54 --> Helper loaded: form_helper
INFO - 2023-07-03 11:48:54 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:48:54 --> Helper loaded: security_helper
INFO - 2023-07-03 11:48:54 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:48:54 --> Database Driver Class Initialized
INFO - 2023-07-03 11:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:48:54 --> Parser Class Initialized
INFO - 2023-07-03 11:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:48:54 --> Pagination Class Initialized
INFO - 2023-07-03 11:48:54 --> Form Validation Class Initialized
INFO - 2023-07-03 11:48:54 --> Controller Class Initialized
DEBUG - 2023-07-03 11:48:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:54 --> Model Class Initialized
DEBUG - 2023-07-03 11:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:54 --> Model Class Initialized
INFO - 2023-07-03 11:48:54 --> Final output sent to browser
DEBUG - 2023-07-03 11:48:54 --> Total execution time: 0.0319
ERROR - 2023-07-03 11:48:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:48:57 --> Config Class Initialized
INFO - 2023-07-03 11:48:57 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:48:57 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:48:57 --> Utf8 Class Initialized
INFO - 2023-07-03 11:48:57 --> URI Class Initialized
INFO - 2023-07-03 11:48:57 --> Router Class Initialized
INFO - 2023-07-03 11:48:57 --> Output Class Initialized
INFO - 2023-07-03 11:48:57 --> Security Class Initialized
DEBUG - 2023-07-03 11:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:48:57 --> Input Class Initialized
INFO - 2023-07-03 11:48:57 --> Language Class Initialized
INFO - 2023-07-03 11:48:57 --> Loader Class Initialized
INFO - 2023-07-03 11:48:57 --> Helper loaded: url_helper
INFO - 2023-07-03 11:48:57 --> Helper loaded: file_helper
INFO - 2023-07-03 11:48:57 --> Helper loaded: html_helper
INFO - 2023-07-03 11:48:57 --> Helper loaded: text_helper
INFO - 2023-07-03 11:48:57 --> Helper loaded: form_helper
INFO - 2023-07-03 11:48:57 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:48:57 --> Helper loaded: security_helper
INFO - 2023-07-03 11:48:57 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:48:57 --> Database Driver Class Initialized
INFO - 2023-07-03 11:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:48:57 --> Parser Class Initialized
INFO - 2023-07-03 11:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:48:57 --> Pagination Class Initialized
INFO - 2023-07-03 11:48:57 --> Form Validation Class Initialized
INFO - 2023-07-03 11:48:57 --> Controller Class Initialized
DEBUG - 2023-07-03 11:48:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:57 --> Model Class Initialized
DEBUG - 2023-07-03 11:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:57 --> Model Class Initialized
INFO - 2023-07-03 11:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-03 11:48:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:48:57 --> Model Class Initialized
INFO - 2023-07-03 11:48:57 --> Model Class Initialized
INFO - 2023-07-03 11:48:57 --> Model Class Initialized
INFO - 2023-07-03 11:48:57 --> Model Class Initialized
INFO - 2023-07-03 11:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:48:57 --> Final output sent to browser
DEBUG - 2023-07-03 11:48:57 --> Total execution time: 0.1421
ERROR - 2023-07-03 11:49:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:49:18 --> Config Class Initialized
INFO - 2023-07-03 11:49:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:49:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:49:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:49:18 --> URI Class Initialized
DEBUG - 2023-07-03 11:49:18 --> No URI present. Default controller set.
INFO - 2023-07-03 11:49:18 --> Router Class Initialized
INFO - 2023-07-03 11:49:18 --> Output Class Initialized
INFO - 2023-07-03 11:49:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:49:18 --> Input Class Initialized
INFO - 2023-07-03 11:49:18 --> Language Class Initialized
INFO - 2023-07-03 11:49:18 --> Loader Class Initialized
INFO - 2023-07-03 11:49:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:49:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:49:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:49:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:49:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:49:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:49:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:49:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:49:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:49:18 --> Parser Class Initialized
INFO - 2023-07-03 11:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:49:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:49:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:49:18 --> Controller Class Initialized
INFO - 2023-07-03 11:49:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 11:49:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:49:19 --> Config Class Initialized
INFO - 2023-07-03 11:49:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:49:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:49:19 --> Utf8 Class Initialized
INFO - 2023-07-03 11:49:19 --> URI Class Initialized
INFO - 2023-07-03 11:49:19 --> Router Class Initialized
INFO - 2023-07-03 11:49:19 --> Output Class Initialized
INFO - 2023-07-03 11:49:19 --> Security Class Initialized
DEBUG - 2023-07-03 11:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:49:19 --> Input Class Initialized
INFO - 2023-07-03 11:49:19 --> Language Class Initialized
INFO - 2023-07-03 11:49:19 --> Loader Class Initialized
INFO - 2023-07-03 11:49:19 --> Helper loaded: url_helper
INFO - 2023-07-03 11:49:19 --> Helper loaded: file_helper
INFO - 2023-07-03 11:49:19 --> Helper loaded: html_helper
INFO - 2023-07-03 11:49:19 --> Helper loaded: text_helper
INFO - 2023-07-03 11:49:19 --> Helper loaded: form_helper
INFO - 2023-07-03 11:49:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:49:19 --> Helper loaded: security_helper
INFO - 2023-07-03 11:49:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:49:19 --> Database Driver Class Initialized
INFO - 2023-07-03 11:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:49:19 --> Parser Class Initialized
INFO - 2023-07-03 11:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:49:19 --> Pagination Class Initialized
INFO - 2023-07-03 11:49:19 --> Form Validation Class Initialized
INFO - 2023-07-03 11:49:19 --> Controller Class Initialized
INFO - 2023-07-03 11:49:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 11:49:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:49:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:49:19 --> Model Class Initialized
INFO - 2023-07-03 11:49:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:49:19 --> Final output sent to browser
DEBUG - 2023-07-03 11:49:19 --> Total execution time: 0.0282
ERROR - 2023-07-03 11:49:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:49:44 --> Config Class Initialized
INFO - 2023-07-03 11:49:44 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:49:44 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:49:44 --> Utf8 Class Initialized
INFO - 2023-07-03 11:49:44 --> URI Class Initialized
INFO - 2023-07-03 11:49:44 --> Router Class Initialized
INFO - 2023-07-03 11:49:44 --> Output Class Initialized
INFO - 2023-07-03 11:49:44 --> Security Class Initialized
DEBUG - 2023-07-03 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:49:44 --> Input Class Initialized
INFO - 2023-07-03 11:49:44 --> Language Class Initialized
INFO - 2023-07-03 11:49:44 --> Loader Class Initialized
INFO - 2023-07-03 11:49:44 --> Helper loaded: url_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: file_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: html_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: text_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: form_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: security_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:49:44 --> Database Driver Class Initialized
INFO - 2023-07-03 11:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:49:44 --> Parser Class Initialized
INFO - 2023-07-03 11:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:49:44 --> Pagination Class Initialized
INFO - 2023-07-03 11:49:44 --> Form Validation Class Initialized
INFO - 2023-07-03 11:49:44 --> Controller Class Initialized
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
INFO - 2023-07-03 11:49:44 --> Final output sent to browser
DEBUG - 2023-07-03 11:49:44 --> Total execution time: 0.0193
ERROR - 2023-07-03 11:49:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:49:44 --> Config Class Initialized
INFO - 2023-07-03 11:49:44 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:49:44 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:49:44 --> Utf8 Class Initialized
INFO - 2023-07-03 11:49:44 --> URI Class Initialized
DEBUG - 2023-07-03 11:49:44 --> No URI present. Default controller set.
INFO - 2023-07-03 11:49:44 --> Router Class Initialized
INFO - 2023-07-03 11:49:44 --> Output Class Initialized
INFO - 2023-07-03 11:49:44 --> Security Class Initialized
DEBUG - 2023-07-03 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:49:44 --> Input Class Initialized
INFO - 2023-07-03 11:49:44 --> Language Class Initialized
INFO - 2023-07-03 11:49:44 --> Loader Class Initialized
INFO - 2023-07-03 11:49:44 --> Helper loaded: url_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: file_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: html_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: text_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: form_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: security_helper
INFO - 2023-07-03 11:49:44 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:49:44 --> Database Driver Class Initialized
INFO - 2023-07-03 11:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:49:44 --> Parser Class Initialized
INFO - 2023-07-03 11:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:49:44 --> Pagination Class Initialized
INFO - 2023-07-03 11:49:44 --> Form Validation Class Initialized
INFO - 2023-07-03 11:49:44 --> Controller Class Initialized
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
INFO - 2023-07-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 11:49:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:49:44 --> Model Class Initialized
INFO - 2023-07-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:49:44 --> Final output sent to browser
DEBUG - 2023-07-03 11:49:44 --> Total execution time: 0.0680
ERROR - 2023-07-03 11:49:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:49:50 --> Config Class Initialized
INFO - 2023-07-03 11:49:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:49:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:49:50 --> Utf8 Class Initialized
INFO - 2023-07-03 11:49:50 --> URI Class Initialized
INFO - 2023-07-03 11:49:50 --> Router Class Initialized
INFO - 2023-07-03 11:49:50 --> Output Class Initialized
INFO - 2023-07-03 11:49:50 --> Security Class Initialized
DEBUG - 2023-07-03 11:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:49:50 --> Input Class Initialized
INFO - 2023-07-03 11:49:50 --> Language Class Initialized
INFO - 2023-07-03 11:49:50 --> Loader Class Initialized
INFO - 2023-07-03 11:49:50 --> Helper loaded: url_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: file_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: html_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: text_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: form_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: security_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:49:50 --> Database Driver Class Initialized
INFO - 2023-07-03 11:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:49:50 --> Parser Class Initialized
INFO - 2023-07-03 11:49:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:49:50 --> Pagination Class Initialized
INFO - 2023-07-03 11:49:50 --> Form Validation Class Initialized
INFO - 2023-07-03 11:49:50 --> Controller Class Initialized
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
INFO - 2023-07-03 11:49:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:49:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:49:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
INFO - 2023-07-03 11:49:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:49:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:49:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:49:50 --> Final output sent to browser
DEBUG - 2023-07-03 11:49:50 --> Total execution time: 0.0651
ERROR - 2023-07-03 11:49:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:49:50 --> Config Class Initialized
INFO - 2023-07-03 11:49:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:49:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:49:50 --> Utf8 Class Initialized
INFO - 2023-07-03 11:49:50 --> URI Class Initialized
INFO - 2023-07-03 11:49:50 --> Router Class Initialized
INFO - 2023-07-03 11:49:50 --> Output Class Initialized
INFO - 2023-07-03 11:49:50 --> Security Class Initialized
DEBUG - 2023-07-03 11:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:49:50 --> Input Class Initialized
INFO - 2023-07-03 11:49:50 --> Language Class Initialized
INFO - 2023-07-03 11:49:50 --> Loader Class Initialized
INFO - 2023-07-03 11:49:50 --> Helper loaded: url_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: file_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: html_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: text_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: form_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: security_helper
INFO - 2023-07-03 11:49:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:49:50 --> Database Driver Class Initialized
INFO - 2023-07-03 11:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:49:50 --> Parser Class Initialized
INFO - 2023-07-03 11:49:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:49:50 --> Pagination Class Initialized
INFO - 2023-07-03 11:49:50 --> Form Validation Class Initialized
INFO - 2023-07-03 11:49:50 --> Controller Class Initialized
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
DEBUG - 2023-07-03 11:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:49:50 --> Model Class Initialized
INFO - 2023-07-03 11:49:50 --> Final output sent to browser
DEBUG - 2023-07-03 11:49:50 --> Total execution time: 0.0185
ERROR - 2023-07-03 11:50:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:01 --> Config Class Initialized
INFO - 2023-07-03 11:50:01 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:01 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:01 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:01 --> URI Class Initialized
INFO - 2023-07-03 11:50:01 --> Router Class Initialized
INFO - 2023-07-03 11:50:01 --> Output Class Initialized
INFO - 2023-07-03 11:50:01 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:01 --> Input Class Initialized
INFO - 2023-07-03 11:50:01 --> Language Class Initialized
INFO - 2023-07-03 11:50:01 --> Loader Class Initialized
INFO - 2023-07-03 11:50:01 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:01 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:01 --> Parser Class Initialized
INFO - 2023-07-03 11:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:01 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:01 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:01 --> Controller Class Initialized
INFO - 2023-07-03 11:50:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:01 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:01 --> Total execution time: 0.0130
ERROR - 2023-07-03 11:50:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:01 --> Config Class Initialized
INFO - 2023-07-03 11:50:01 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:01 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:01 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:01 --> URI Class Initialized
INFO - 2023-07-03 11:50:01 --> Router Class Initialized
INFO - 2023-07-03 11:50:01 --> Output Class Initialized
INFO - 2023-07-03 11:50:01 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:01 --> Input Class Initialized
INFO - 2023-07-03 11:50:01 --> Language Class Initialized
INFO - 2023-07-03 11:50:01 --> Loader Class Initialized
INFO - 2023-07-03 11:50:01 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:01 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:01 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:01 --> Parser Class Initialized
INFO - 2023-07-03 11:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:01 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:01 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:01 --> Controller Class Initialized
INFO - 2023-07-03 11:50:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 11:50:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:50:01 --> Model Class Initialized
INFO - 2023-07-03 11:50:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:50:01 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:01 --> Total execution time: 0.0441
ERROR - 2023-07-03 11:50:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:10 --> Config Class Initialized
INFO - 2023-07-03 11:50:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:10 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:10 --> URI Class Initialized
INFO - 2023-07-03 11:50:10 --> Router Class Initialized
INFO - 2023-07-03 11:50:10 --> Output Class Initialized
INFO - 2023-07-03 11:50:10 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:10 --> Input Class Initialized
INFO - 2023-07-03 11:50:10 --> Language Class Initialized
INFO - 2023-07-03 11:50:10 --> Loader Class Initialized
INFO - 2023-07-03 11:50:10 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:10 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:10 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:10 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:10 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:10 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:10 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:10 --> Parser Class Initialized
INFO - 2023-07-03 11:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:10 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:10 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:10 --> Controller Class Initialized
DEBUG - 2023-07-03 11:50:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:10 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:10 --> Model Class Initialized
INFO - 2023-07-03 11:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 11:50:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:50:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:50:10 --> Model Class Initialized
INFO - 2023-07-03 11:50:10 --> Model Class Initialized
INFO - 2023-07-03 11:50:10 --> Model Class Initialized
INFO - 2023-07-03 11:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:50:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:50:11 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:11 --> Total execution time: 0.1397
ERROR - 2023-07-03 11:50:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:11 --> Config Class Initialized
INFO - 2023-07-03 11:50:11 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:11 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:11 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:11 --> URI Class Initialized
INFO - 2023-07-03 11:50:11 --> Router Class Initialized
INFO - 2023-07-03 11:50:11 --> Output Class Initialized
INFO - 2023-07-03 11:50:11 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:11 --> Input Class Initialized
INFO - 2023-07-03 11:50:11 --> Language Class Initialized
INFO - 2023-07-03 11:50:11 --> Loader Class Initialized
INFO - 2023-07-03 11:50:11 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:11 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:11 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:11 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:11 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:11 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:11 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:11 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:11 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:11 --> Parser Class Initialized
INFO - 2023-07-03 11:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:11 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:11 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:11 --> Controller Class Initialized
DEBUG - 2023-07-03 11:50:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:11 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:11 --> Model Class Initialized
INFO - 2023-07-03 11:50:11 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:11 --> Total execution time: 0.0308
ERROR - 2023-07-03 11:50:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:19 --> Config Class Initialized
INFO - 2023-07-03 11:50:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:19 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:19 --> URI Class Initialized
INFO - 2023-07-03 11:50:19 --> Router Class Initialized
INFO - 2023-07-03 11:50:19 --> Output Class Initialized
INFO - 2023-07-03 11:50:19 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:19 --> Input Class Initialized
INFO - 2023-07-03 11:50:19 --> Language Class Initialized
INFO - 2023-07-03 11:50:19 --> Loader Class Initialized
INFO - 2023-07-03 11:50:19 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:19 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:19 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:19 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:19 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:19 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:19 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:19 --> Parser Class Initialized
INFO - 2023-07-03 11:50:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:19 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:19 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:19 --> Controller Class Initialized
DEBUG - 2023-07-03 11:50:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:19 --> Model Class Initialized
INFO - 2023-07-03 11:50:20 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:20 --> Total execution time: 0.1132
ERROR - 2023-07-03 11:50:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:46 --> Config Class Initialized
INFO - 2023-07-03 11:50:46 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:46 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:46 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:46 --> URI Class Initialized
INFO - 2023-07-03 11:50:46 --> Router Class Initialized
INFO - 2023-07-03 11:50:46 --> Output Class Initialized
INFO - 2023-07-03 11:50:46 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:46 --> Input Class Initialized
INFO - 2023-07-03 11:50:46 --> Language Class Initialized
INFO - 2023-07-03 11:50:46 --> Loader Class Initialized
INFO - 2023-07-03 11:50:46 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:46 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:46 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:46 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:46 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:46 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:46 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:46 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:46 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:46 --> Parser Class Initialized
INFO - 2023-07-03 11:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:46 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:46 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:46 --> Controller Class Initialized
INFO - 2023-07-03 11:50:46 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:46 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:46 --> Model Class Initialized
INFO - 2023-07-03 11:50:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:50:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:50:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:50:46 --> Model Class Initialized
INFO - 2023-07-03 11:50:46 --> Model Class Initialized
INFO - 2023-07-03 11:50:46 --> Model Class Initialized
INFO - 2023-07-03 11:50:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:50:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:50:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:50:46 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:46 --> Total execution time: 0.1691
ERROR - 2023-07-03 11:50:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:47 --> Config Class Initialized
INFO - 2023-07-03 11:50:47 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:47 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:47 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:47 --> URI Class Initialized
INFO - 2023-07-03 11:50:47 --> Router Class Initialized
INFO - 2023-07-03 11:50:47 --> Output Class Initialized
INFO - 2023-07-03 11:50:47 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:47 --> Input Class Initialized
INFO - 2023-07-03 11:50:47 --> Language Class Initialized
INFO - 2023-07-03 11:50:47 --> Loader Class Initialized
INFO - 2023-07-03 11:50:47 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:47 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:47 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:47 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:47 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:47 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:47 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:47 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:47 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:47 --> Parser Class Initialized
INFO - 2023-07-03 11:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:47 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:47 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:47 --> Controller Class Initialized
INFO - 2023-07-03 11:50:47 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:47 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:47 --> Model Class Initialized
INFO - 2023-07-03 11:50:47 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:47 --> Total execution time: 0.0609
ERROR - 2023-07-03 11:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:50:56 --> Config Class Initialized
INFO - 2023-07-03 11:50:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:50:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:50:56 --> Utf8 Class Initialized
INFO - 2023-07-03 11:50:56 --> URI Class Initialized
INFO - 2023-07-03 11:50:56 --> Router Class Initialized
INFO - 2023-07-03 11:50:56 --> Output Class Initialized
INFO - 2023-07-03 11:50:56 --> Security Class Initialized
DEBUG - 2023-07-03 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:50:56 --> Input Class Initialized
INFO - 2023-07-03 11:50:56 --> Language Class Initialized
INFO - 2023-07-03 11:50:56 --> Loader Class Initialized
INFO - 2023-07-03 11:50:56 --> Helper loaded: url_helper
INFO - 2023-07-03 11:50:56 --> Helper loaded: file_helper
INFO - 2023-07-03 11:50:56 --> Helper loaded: html_helper
INFO - 2023-07-03 11:50:56 --> Helper loaded: text_helper
INFO - 2023-07-03 11:50:56 --> Helper loaded: form_helper
INFO - 2023-07-03 11:50:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:50:56 --> Helper loaded: security_helper
INFO - 2023-07-03 11:50:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:50:56 --> Database Driver Class Initialized
INFO - 2023-07-03 11:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:50:56 --> Parser Class Initialized
INFO - 2023-07-03 11:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:50:56 --> Pagination Class Initialized
INFO - 2023-07-03 11:50:56 --> Form Validation Class Initialized
INFO - 2023-07-03 11:50:56 --> Controller Class Initialized
INFO - 2023-07-03 11:50:56 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:56 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:56 --> Model Class Initialized
DEBUG - 2023-07-03 11:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-03 11:50:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:50:56 --> Model Class Initialized
INFO - 2023-07-03 11:50:56 --> Model Class Initialized
INFO - 2023-07-03 11:50:56 --> Model Class Initialized
INFO - 2023-07-03 11:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:50:56 --> Final output sent to browser
DEBUG - 2023-07-03 11:50:56 --> Total execution time: 0.1611
ERROR - 2023-07-03 11:51:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:06 --> Config Class Initialized
INFO - 2023-07-03 11:51:06 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:06 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:06 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:06 --> URI Class Initialized
INFO - 2023-07-03 11:51:06 --> Router Class Initialized
INFO - 2023-07-03 11:51:06 --> Output Class Initialized
INFO - 2023-07-03 11:51:06 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:06 --> Input Class Initialized
INFO - 2023-07-03 11:51:06 --> Language Class Initialized
INFO - 2023-07-03 11:51:06 --> Loader Class Initialized
INFO - 2023-07-03 11:51:06 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:06 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:06 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:06 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:06 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:06 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:06 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:06 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:06 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:06 --> Parser Class Initialized
INFO - 2023-07-03 11:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:06 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:06 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:06 --> Controller Class Initialized
DEBUG - 2023-07-03 11:51:06 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:06 --> Model Class Initialized
INFO - 2023-07-03 11:51:06 --> Model Class Initialized
INFO - 2023-07-03 11:51:06 --> Model Class Initialized
INFO - 2023-07-03 11:51:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-07-03 11:51:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:51:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:51:06 --> Model Class Initialized
INFO - 2023-07-03 11:51:06 --> Model Class Initialized
INFO - 2023-07-03 11:51:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:51:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:51:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:51:06 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:06 --> Total execution time: 0.1482
ERROR - 2023-07-03 11:51:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:07 --> Config Class Initialized
INFO - 2023-07-03 11:51:07 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:07 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:07 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:07 --> URI Class Initialized
INFO - 2023-07-03 11:51:07 --> Router Class Initialized
INFO - 2023-07-03 11:51:07 --> Output Class Initialized
INFO - 2023-07-03 11:51:07 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:07 --> Input Class Initialized
INFO - 2023-07-03 11:51:07 --> Language Class Initialized
INFO - 2023-07-03 11:51:07 --> Loader Class Initialized
INFO - 2023-07-03 11:51:07 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:07 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:07 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:07 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:07 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:07 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:07 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:07 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:07 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:07 --> Parser Class Initialized
INFO - 2023-07-03 11:51:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:07 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:07 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:07 --> Controller Class Initialized
DEBUG - 2023-07-03 11:51:07 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:07 --> Model Class Initialized
INFO - 2023-07-03 11:51:07 --> Model Class Initialized
INFO - 2023-07-03 11:51:07 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:07 --> Total execution time: 0.0496
ERROR - 2023-07-03 11:51:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:17 --> Config Class Initialized
INFO - 2023-07-03 11:51:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:17 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:17 --> URI Class Initialized
INFO - 2023-07-03 11:51:17 --> Router Class Initialized
INFO - 2023-07-03 11:51:17 --> Output Class Initialized
INFO - 2023-07-03 11:51:17 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:17 --> Input Class Initialized
INFO - 2023-07-03 11:51:17 --> Language Class Initialized
INFO - 2023-07-03 11:51:17 --> Loader Class Initialized
INFO - 2023-07-03 11:51:17 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:17 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:17 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:17 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:17 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:17 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:17 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:17 --> Parser Class Initialized
INFO - 2023-07-03 11:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:17 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:17 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:17 --> Controller Class Initialized
DEBUG - 2023-07-03 11:51:17 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:17 --> Model Class Initialized
INFO - 2023-07-03 11:51:17 --> Model Class Initialized
INFO - 2023-07-03 11:51:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:18 --> Total execution time: 0.1221
ERROR - 2023-07-03 11:51:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:34 --> Config Class Initialized
INFO - 2023-07-03 11:51:34 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:34 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:34 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:34 --> URI Class Initialized
INFO - 2023-07-03 11:51:34 --> Router Class Initialized
INFO - 2023-07-03 11:51:34 --> Output Class Initialized
INFO - 2023-07-03 11:51:34 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:34 --> Input Class Initialized
INFO - 2023-07-03 11:51:34 --> Language Class Initialized
INFO - 2023-07-03 11:51:34 --> Loader Class Initialized
INFO - 2023-07-03 11:51:34 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:34 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:34 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:34 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:34 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:34 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:34 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:34 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:34 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:34 --> Parser Class Initialized
INFO - 2023-07-03 11:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:34 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:34 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:34 --> Controller Class Initialized
DEBUG - 2023-07-03 11:51:34 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-07-03 11:51:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> Model Class Initialized
INFO - 2023-07-03 11:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:51:34 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:34 --> Total execution time: 0.1779
ERROR - 2023-07-03 11:51:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:42 --> Config Class Initialized
INFO - 2023-07-03 11:51:42 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:42 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:42 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:42 --> URI Class Initialized
INFO - 2023-07-03 11:51:42 --> Router Class Initialized
INFO - 2023-07-03 11:51:42 --> Output Class Initialized
INFO - 2023-07-03 11:51:42 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:42 --> Input Class Initialized
INFO - 2023-07-03 11:51:42 --> Language Class Initialized
INFO - 2023-07-03 11:51:42 --> Loader Class Initialized
INFO - 2023-07-03 11:51:42 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:42 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:42 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:42 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:42 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:42 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:42 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:42 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:42 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:42 --> Parser Class Initialized
INFO - 2023-07-03 11:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:42 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:42 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:42 --> Controller Class Initialized
INFO - 2023-07-03 11:51:42 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:42 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:42 --> Model Class Initialized
INFO - 2023-07-03 11:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:51:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:51:42 --> Model Class Initialized
INFO - 2023-07-03 11:51:42 --> Model Class Initialized
INFO - 2023-07-03 11:51:42 --> Model Class Initialized
INFO - 2023-07-03 11:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:51:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:51:42 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:42 --> Total execution time: 0.1425
ERROR - 2023-07-03 11:51:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:43 --> Config Class Initialized
INFO - 2023-07-03 11:51:43 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:43 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:43 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:43 --> URI Class Initialized
INFO - 2023-07-03 11:51:43 --> Router Class Initialized
INFO - 2023-07-03 11:51:43 --> Output Class Initialized
INFO - 2023-07-03 11:51:43 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:43 --> Input Class Initialized
INFO - 2023-07-03 11:51:43 --> Language Class Initialized
INFO - 2023-07-03 11:51:43 --> Loader Class Initialized
INFO - 2023-07-03 11:51:43 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:43 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:43 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:43 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:43 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:43 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:43 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:43 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:43 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:43 --> Parser Class Initialized
INFO - 2023-07-03 11:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:43 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:43 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:43 --> Controller Class Initialized
INFO - 2023-07-03 11:51:43 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:43 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:43 --> Model Class Initialized
INFO - 2023-07-03 11:51:43 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:43 --> Total execution time: 0.0527
ERROR - 2023-07-03 11:51:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:47 --> Config Class Initialized
INFO - 2023-07-03 11:51:47 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:47 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:47 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:47 --> URI Class Initialized
INFO - 2023-07-03 11:51:47 --> Router Class Initialized
INFO - 2023-07-03 11:51:47 --> Output Class Initialized
INFO - 2023-07-03 11:51:47 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:47 --> Input Class Initialized
INFO - 2023-07-03 11:51:47 --> Language Class Initialized
INFO - 2023-07-03 11:51:47 --> Loader Class Initialized
INFO - 2023-07-03 11:51:47 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:47 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:47 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:47 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:47 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:47 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:47 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:47 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:47 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:47 --> Parser Class Initialized
INFO - 2023-07-03 11:51:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:47 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:47 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:47 --> Controller Class Initialized
INFO - 2023-07-03 11:51:47 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:47 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:47 --> Model Class Initialized
ERROR - 2023-07-03 11:51:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-07-03 11:51:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-07-03 11:51:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:51:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:51:47 --> Model Class Initialized
INFO - 2023-07-03 11:51:47 --> Model Class Initialized
INFO - 2023-07-03 11:51:47 --> Model Class Initialized
INFO - 2023-07-03 11:51:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:51:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:51:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:51:47 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:47 --> Total execution time: 0.1689
ERROR - 2023-07-03 11:51:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:48 --> Config Class Initialized
INFO - 2023-07-03 11:51:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:51:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:48 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:48 --> URI Class Initialized
INFO - 2023-07-03 11:51:48 --> Router Class Initialized
INFO - 2023-07-03 11:51:48 --> Output Class Initialized
INFO - 2023-07-03 11:51:48 --> Security Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:48 --> Input Class Initialized
INFO - 2023-07-03 11:51:48 --> Language Class Initialized
INFO - 2023-07-03 11:51:48 --> Loader Class Initialized
INFO - 2023-07-03 11:51:48 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: text_helper
ERROR - 2023-07-03 11:51:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:51:48 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:48 --> Config Class Initialized
INFO - 2023-07-03 11:51:48 --> Hooks Class Initialized
INFO - 2023-07-03 11:51:48 --> Helper loaded: cookie_helper
DEBUG - 2023-07-03 11:51:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:51:48 --> Utf8 Class Initialized
INFO - 2023-07-03 11:51:48 --> URI Class Initialized
INFO - 2023-07-03 11:51:48 --> Router Class Initialized
INFO - 2023-07-03 11:51:48 --> Output Class Initialized
INFO - 2023-07-03 11:51:48 --> Security Class Initialized
INFO - 2023-07-03 11:51:48 --> Database Driver Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:51:48 --> Input Class Initialized
INFO - 2023-07-03 11:51:48 --> Language Class Initialized
INFO - 2023-07-03 11:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:48 --> Parser Class Initialized
INFO - 2023-07-03 11:51:48 --> Loader Class Initialized
INFO - 2023-07-03 11:51:48 --> Helper loaded: url_helper
INFO - 2023-07-03 11:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:48 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:48 --> Helper loaded: file_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: html_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: text_helper
INFO - 2023-07-03 11:51:48 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:48 --> Controller Class Initialized
INFO - 2023-07-03 11:51:48 --> Helper loaded: form_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: security_helper
INFO - 2023-07-03 11:51:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:48 --> Database Driver Class Initialized
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:48 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:48 --> Total execution time: 0.0226
INFO - 2023-07-03 11:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:51:48 --> Parser Class Initialized
INFO - 2023-07-03 11:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:51:48 --> Pagination Class Initialized
INFO - 2023-07-03 11:51:48 --> Form Validation Class Initialized
INFO - 2023-07-03 11:51:48 --> Controller Class Initialized
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
INFO - 2023-07-03 11:51:48 --> Model Class Initialized
DEBUG - 2023-07-03 11:51:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:51:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:51:48 --> Final output sent to browser
DEBUG - 2023-07-03 11:51:48 --> Total execution time: 0.0230
ERROR - 2023-07-03 11:52:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:52:28 --> Config Class Initialized
INFO - 2023-07-03 11:52:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:52:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:52:28 --> Utf8 Class Initialized
INFO - 2023-07-03 11:52:28 --> URI Class Initialized
INFO - 2023-07-03 11:52:28 --> Router Class Initialized
INFO - 2023-07-03 11:52:28 --> Output Class Initialized
INFO - 2023-07-03 11:52:28 --> Security Class Initialized
DEBUG - 2023-07-03 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:52:28 --> Input Class Initialized
INFO - 2023-07-03 11:52:28 --> Language Class Initialized
INFO - 2023-07-03 11:52:28 --> Loader Class Initialized
INFO - 2023-07-03 11:52:28 --> Helper loaded: url_helper
INFO - 2023-07-03 11:52:28 --> Helper loaded: file_helper
INFO - 2023-07-03 11:52:28 --> Helper loaded: html_helper
INFO - 2023-07-03 11:52:28 --> Helper loaded: text_helper
INFO - 2023-07-03 11:52:28 --> Helper loaded: form_helper
INFO - 2023-07-03 11:52:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:52:28 --> Helper loaded: security_helper
INFO - 2023-07-03 11:52:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:52:28 --> Database Driver Class Initialized
INFO - 2023-07-03 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:52:28 --> Parser Class Initialized
INFO - 2023-07-03 11:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:52:28 --> Pagination Class Initialized
INFO - 2023-07-03 11:52:28 --> Form Validation Class Initialized
INFO - 2023-07-03 11:52:28 --> Controller Class Initialized
INFO - 2023-07-03 11:52:28 --> Model Class Initialized
DEBUG - 2023-07-03 11:52:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:28 --> Model Class Initialized
DEBUG - 2023-07-03 11:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:28 --> Model Class Initialized
INFO - 2023-07-03 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:52:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:52:28 --> Model Class Initialized
INFO - 2023-07-03 11:52:28 --> Model Class Initialized
INFO - 2023-07-03 11:52:28 --> Model Class Initialized
INFO - 2023-07-03 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:52:28 --> Final output sent to browser
DEBUG - 2023-07-03 11:52:28 --> Total execution time: 0.1482
ERROR - 2023-07-03 11:52:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:52:29 --> Config Class Initialized
INFO - 2023-07-03 11:52:29 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:52:29 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:52:29 --> Utf8 Class Initialized
INFO - 2023-07-03 11:52:29 --> URI Class Initialized
INFO - 2023-07-03 11:52:29 --> Router Class Initialized
INFO - 2023-07-03 11:52:29 --> Output Class Initialized
INFO - 2023-07-03 11:52:29 --> Security Class Initialized
DEBUG - 2023-07-03 11:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:52:29 --> Input Class Initialized
INFO - 2023-07-03 11:52:29 --> Language Class Initialized
INFO - 2023-07-03 11:52:29 --> Loader Class Initialized
INFO - 2023-07-03 11:52:29 --> Helper loaded: url_helper
INFO - 2023-07-03 11:52:29 --> Helper loaded: file_helper
INFO - 2023-07-03 11:52:29 --> Helper loaded: html_helper
INFO - 2023-07-03 11:52:29 --> Helper loaded: text_helper
INFO - 2023-07-03 11:52:29 --> Helper loaded: form_helper
INFO - 2023-07-03 11:52:29 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:52:29 --> Helper loaded: security_helper
INFO - 2023-07-03 11:52:29 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:52:29 --> Database Driver Class Initialized
INFO - 2023-07-03 11:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:52:29 --> Parser Class Initialized
INFO - 2023-07-03 11:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:52:29 --> Pagination Class Initialized
INFO - 2023-07-03 11:52:29 --> Form Validation Class Initialized
INFO - 2023-07-03 11:52:29 --> Controller Class Initialized
INFO - 2023-07-03 11:52:29 --> Model Class Initialized
DEBUG - 2023-07-03 11:52:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:29 --> Model Class Initialized
DEBUG - 2023-07-03 11:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:29 --> Model Class Initialized
INFO - 2023-07-03 11:52:29 --> Final output sent to browser
DEBUG - 2023-07-03 11:52:29 --> Total execution time: 0.0606
ERROR - 2023-07-03 11:52:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:52:32 --> Config Class Initialized
INFO - 2023-07-03 11:52:32 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:52:32 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:52:32 --> Utf8 Class Initialized
INFO - 2023-07-03 11:52:32 --> URI Class Initialized
INFO - 2023-07-03 11:52:32 --> Router Class Initialized
INFO - 2023-07-03 11:52:32 --> Output Class Initialized
INFO - 2023-07-03 11:52:32 --> Security Class Initialized
DEBUG - 2023-07-03 11:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:52:32 --> Input Class Initialized
INFO - 2023-07-03 11:52:32 --> Language Class Initialized
INFO - 2023-07-03 11:52:32 --> Loader Class Initialized
INFO - 2023-07-03 11:52:32 --> Helper loaded: url_helper
INFO - 2023-07-03 11:52:32 --> Helper loaded: file_helper
INFO - 2023-07-03 11:52:32 --> Helper loaded: html_helper
INFO - 2023-07-03 11:52:32 --> Helper loaded: text_helper
INFO - 2023-07-03 11:52:32 --> Helper loaded: form_helper
INFO - 2023-07-03 11:52:32 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:52:32 --> Helper loaded: security_helper
INFO - 2023-07-03 11:52:32 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:52:32 --> Database Driver Class Initialized
INFO - 2023-07-03 11:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:52:32 --> Parser Class Initialized
INFO - 2023-07-03 11:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:52:32 --> Pagination Class Initialized
INFO - 2023-07-03 11:52:32 --> Form Validation Class Initialized
INFO - 2023-07-03 11:52:32 --> Controller Class Initialized
INFO - 2023-07-03 11:52:32 --> Model Class Initialized
DEBUG - 2023-07-03 11:52:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:32 --> Model Class Initialized
DEBUG - 2023-07-03 11:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:32 --> Model Class Initialized
DEBUG - 2023-07-03 11:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-03 11:52:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:52:32 --> Model Class Initialized
INFO - 2023-07-03 11:52:32 --> Model Class Initialized
INFO - 2023-07-03 11:52:32 --> Model Class Initialized
INFO - 2023-07-03 11:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:52:32 --> Final output sent to browser
DEBUG - 2023-07-03 11:52:32 --> Total execution time: 0.1540
ERROR - 2023-07-03 11:53:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:53:06 --> Config Class Initialized
INFO - 2023-07-03 11:53:06 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:53:06 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:53:06 --> Utf8 Class Initialized
INFO - 2023-07-03 11:53:06 --> URI Class Initialized
INFO - 2023-07-03 11:53:06 --> Router Class Initialized
INFO - 2023-07-03 11:53:06 --> Output Class Initialized
INFO - 2023-07-03 11:53:06 --> Security Class Initialized
DEBUG - 2023-07-03 11:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:53:06 --> Input Class Initialized
INFO - 2023-07-03 11:53:06 --> Language Class Initialized
INFO - 2023-07-03 11:53:06 --> Loader Class Initialized
INFO - 2023-07-03 11:53:06 --> Helper loaded: url_helper
INFO - 2023-07-03 11:53:06 --> Helper loaded: file_helper
INFO - 2023-07-03 11:53:06 --> Helper loaded: html_helper
INFO - 2023-07-03 11:53:06 --> Helper loaded: text_helper
INFO - 2023-07-03 11:53:06 --> Helper loaded: form_helper
INFO - 2023-07-03 11:53:06 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:53:06 --> Helper loaded: security_helper
INFO - 2023-07-03 11:53:06 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:53:06 --> Database Driver Class Initialized
INFO - 2023-07-03 11:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:53:06 --> Parser Class Initialized
INFO - 2023-07-03 11:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:53:06 --> Pagination Class Initialized
INFO - 2023-07-03 11:53:06 --> Form Validation Class Initialized
INFO - 2023-07-03 11:53:06 --> Controller Class Initialized
INFO - 2023-07-03 11:53:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:53:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:06 --> Model Class Initialized
INFO - 2023-07-03 11:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 11:53:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:53:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:53:06 --> Model Class Initialized
INFO - 2023-07-03 11:53:06 --> Model Class Initialized
INFO - 2023-07-03 11:53:06 --> Model Class Initialized
INFO - 2023-07-03 11:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:53:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:53:07 --> Final output sent to browser
DEBUG - 2023-07-03 11:53:07 --> Total execution time: 0.1471
ERROR - 2023-07-03 11:53:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:53:07 --> Config Class Initialized
INFO - 2023-07-03 11:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:53:07 --> Utf8 Class Initialized
INFO - 2023-07-03 11:53:07 --> URI Class Initialized
INFO - 2023-07-03 11:53:07 --> Router Class Initialized
INFO - 2023-07-03 11:53:07 --> Output Class Initialized
INFO - 2023-07-03 11:53:07 --> Security Class Initialized
DEBUG - 2023-07-03 11:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:53:07 --> Input Class Initialized
INFO - 2023-07-03 11:53:07 --> Language Class Initialized
INFO - 2023-07-03 11:53:07 --> Loader Class Initialized
INFO - 2023-07-03 11:53:07 --> Helper loaded: url_helper
INFO - 2023-07-03 11:53:07 --> Helper loaded: file_helper
INFO - 2023-07-03 11:53:07 --> Helper loaded: html_helper
INFO - 2023-07-03 11:53:07 --> Helper loaded: text_helper
INFO - 2023-07-03 11:53:07 --> Helper loaded: form_helper
INFO - 2023-07-03 11:53:07 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:53:07 --> Helper loaded: security_helper
INFO - 2023-07-03 11:53:07 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:53:07 --> Database Driver Class Initialized
INFO - 2023-07-03 11:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:53:07 --> Parser Class Initialized
INFO - 2023-07-03 11:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:53:07 --> Pagination Class Initialized
INFO - 2023-07-03 11:53:07 --> Form Validation Class Initialized
INFO - 2023-07-03 11:53:07 --> Controller Class Initialized
INFO - 2023-07-03 11:53:07 --> Model Class Initialized
DEBUG - 2023-07-03 11:53:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:07 --> Model Class Initialized
DEBUG - 2023-07-03 11:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:07 --> Model Class Initialized
INFO - 2023-07-03 11:53:07 --> Final output sent to browser
DEBUG - 2023-07-03 11:53:07 --> Total execution time: 0.0513
ERROR - 2023-07-03 11:53:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:53:13 --> Config Class Initialized
INFO - 2023-07-03 11:53:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:53:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:53:13 --> Utf8 Class Initialized
INFO - 2023-07-03 11:53:13 --> URI Class Initialized
INFO - 2023-07-03 11:53:13 --> Router Class Initialized
INFO - 2023-07-03 11:53:13 --> Output Class Initialized
INFO - 2023-07-03 11:53:13 --> Security Class Initialized
DEBUG - 2023-07-03 11:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:53:13 --> Input Class Initialized
INFO - 2023-07-03 11:53:13 --> Language Class Initialized
INFO - 2023-07-03 11:53:13 --> Loader Class Initialized
INFO - 2023-07-03 11:53:13 --> Helper loaded: url_helper
INFO - 2023-07-03 11:53:13 --> Helper loaded: file_helper
INFO - 2023-07-03 11:53:13 --> Helper loaded: html_helper
INFO - 2023-07-03 11:53:13 --> Helper loaded: text_helper
INFO - 2023-07-03 11:53:13 --> Helper loaded: form_helper
INFO - 2023-07-03 11:53:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:53:13 --> Helper loaded: security_helper
INFO - 2023-07-03 11:53:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:53:13 --> Database Driver Class Initialized
INFO - 2023-07-03 11:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:53:13 --> Parser Class Initialized
INFO - 2023-07-03 11:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:53:13 --> Pagination Class Initialized
INFO - 2023-07-03 11:53:13 --> Form Validation Class Initialized
INFO - 2023-07-03 11:53:13 --> Controller Class Initialized
INFO - 2023-07-03 11:53:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:53:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:13 --> Model Class Initialized
INFO - 2023-07-03 11:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-07-03 11:53:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:53:13 --> Model Class Initialized
INFO - 2023-07-03 11:53:13 --> Model Class Initialized
INFO - 2023-07-03 11:53:13 --> Model Class Initialized
INFO - 2023-07-03 11:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:53:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:53:13 --> Final output sent to browser
DEBUG - 2023-07-03 11:53:13 --> Total execution time: 0.1561
ERROR - 2023-07-03 11:54:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:13 --> Config Class Initialized
INFO - 2023-07-03 11:54:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:13 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:13 --> URI Class Initialized
INFO - 2023-07-03 11:54:13 --> Router Class Initialized
INFO - 2023-07-03 11:54:13 --> Output Class Initialized
INFO - 2023-07-03 11:54:13 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:13 --> Input Class Initialized
INFO - 2023-07-03 11:54:13 --> Language Class Initialized
INFO - 2023-07-03 11:54:13 --> Loader Class Initialized
INFO - 2023-07-03 11:54:13 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:13 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:13 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:13 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:13 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:13 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:13 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:13 --> Parser Class Initialized
INFO - 2023-07-03 11:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:13 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:13 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:13 --> Controller Class Initialized
INFO - 2023-07-03 11:54:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:13 --> Model Class Initialized
INFO - 2023-07-03 11:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 11:54:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:54:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:54:13 --> Model Class Initialized
INFO - 2023-07-03 11:54:13 --> Model Class Initialized
INFO - 2023-07-03 11:54:13 --> Model Class Initialized
INFO - 2023-07-03 11:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:54:14 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:14 --> Total execution time: 0.1475
ERROR - 2023-07-03 11:54:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:14 --> Config Class Initialized
INFO - 2023-07-03 11:54:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:14 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:14 --> URI Class Initialized
INFO - 2023-07-03 11:54:14 --> Router Class Initialized
INFO - 2023-07-03 11:54:14 --> Output Class Initialized
INFO - 2023-07-03 11:54:14 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:14 --> Input Class Initialized
INFO - 2023-07-03 11:54:14 --> Language Class Initialized
INFO - 2023-07-03 11:54:14 --> Loader Class Initialized
INFO - 2023-07-03 11:54:14 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:14 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:14 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:14 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:14 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:14 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:14 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:14 --> Parser Class Initialized
INFO - 2023-07-03 11:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:14 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:14 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:14 --> Controller Class Initialized
INFO - 2023-07-03 11:54:14 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:14 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:14 --> Model Class Initialized
INFO - 2023-07-03 11:54:14 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:14 --> Total execution time: 0.0493
ERROR - 2023-07-03 11:54:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:19 --> Config Class Initialized
INFO - 2023-07-03 11:54:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:19 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:19 --> URI Class Initialized
INFO - 2023-07-03 11:54:19 --> Router Class Initialized
INFO - 2023-07-03 11:54:19 --> Output Class Initialized
INFO - 2023-07-03 11:54:19 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:19 --> Input Class Initialized
INFO - 2023-07-03 11:54:19 --> Language Class Initialized
INFO - 2023-07-03 11:54:19 --> Loader Class Initialized
INFO - 2023-07-03 11:54:19 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:19 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:19 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:19 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:19 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:19 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:19 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:19 --> Parser Class Initialized
INFO - 2023-07-03 11:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:19 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:19 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:19 --> Controller Class Initialized
INFO - 2023-07-03 11:54:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:19 --> Model Class Initialized
INFO - 2023-07-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:54:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:54:19 --> Model Class Initialized
INFO - 2023-07-03 11:54:19 --> Model Class Initialized
INFO - 2023-07-03 11:54:19 --> Model Class Initialized
INFO - 2023-07-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:54:19 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:19 --> Total execution time: 0.1505
ERROR - 2023-07-03 11:54:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:20 --> Config Class Initialized
INFO - 2023-07-03 11:54:20 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:20 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:20 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:20 --> URI Class Initialized
INFO - 2023-07-03 11:54:20 --> Router Class Initialized
INFO - 2023-07-03 11:54:20 --> Output Class Initialized
INFO - 2023-07-03 11:54:20 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:20 --> Input Class Initialized
INFO - 2023-07-03 11:54:20 --> Language Class Initialized
INFO - 2023-07-03 11:54:20 --> Loader Class Initialized
INFO - 2023-07-03 11:54:20 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:20 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:20 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:20 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:20 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:20 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:20 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:20 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:20 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:20 --> Parser Class Initialized
INFO - 2023-07-03 11:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:20 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:20 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:20 --> Controller Class Initialized
INFO - 2023-07-03 11:54:20 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:20 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:20 --> Model Class Initialized
INFO - 2023-07-03 11:54:20 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:20 --> Total execution time: 0.0592
ERROR - 2023-07-03 11:54:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:23 --> Config Class Initialized
INFO - 2023-07-03 11:54:23 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:23 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:23 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:23 --> URI Class Initialized
INFO - 2023-07-03 11:54:23 --> Router Class Initialized
INFO - 2023-07-03 11:54:23 --> Output Class Initialized
INFO - 2023-07-03 11:54:23 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:23 --> Input Class Initialized
INFO - 2023-07-03 11:54:23 --> Language Class Initialized
INFO - 2023-07-03 11:54:23 --> Loader Class Initialized
INFO - 2023-07-03 11:54:23 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:23 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:23 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:23 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:23 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:23 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:23 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:23 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:23 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:23 --> Parser Class Initialized
INFO - 2023-07-03 11:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:23 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:23 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:23 --> Controller Class Initialized
DEBUG - 2023-07-03 11:54:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:23 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:23 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:23 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:23 --> Model Class Initialized
INFO - 2023-07-03 11:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 11:54:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:54:23 --> Model Class Initialized
INFO - 2023-07-03 11:54:23 --> Model Class Initialized
INFO - 2023-07-03 11:54:23 --> Model Class Initialized
INFO - 2023-07-03 11:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:54:23 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:23 --> Total execution time: 0.1403
ERROR - 2023-07-03 11:54:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:24 --> Config Class Initialized
INFO - 2023-07-03 11:54:24 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:24 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:24 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:24 --> URI Class Initialized
INFO - 2023-07-03 11:54:24 --> Router Class Initialized
INFO - 2023-07-03 11:54:24 --> Output Class Initialized
INFO - 2023-07-03 11:54:24 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:24 --> Input Class Initialized
INFO - 2023-07-03 11:54:24 --> Language Class Initialized
INFO - 2023-07-03 11:54:24 --> Loader Class Initialized
INFO - 2023-07-03 11:54:24 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:24 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:24 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:24 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:24 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:24 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:24 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:24 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:24 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:24 --> Parser Class Initialized
INFO - 2023-07-03 11:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:24 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:24 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:24 --> Controller Class Initialized
DEBUG - 2023-07-03 11:54:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:24 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:24 --> Model Class Initialized
INFO - 2023-07-03 11:54:24 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:24 --> Total execution time: 0.0282
ERROR - 2023-07-03 11:54:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:42 --> Config Class Initialized
INFO - 2023-07-03 11:54:42 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:42 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:42 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:42 --> URI Class Initialized
INFO - 2023-07-03 11:54:42 --> Router Class Initialized
INFO - 2023-07-03 11:54:42 --> Output Class Initialized
INFO - 2023-07-03 11:54:42 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:42 --> Input Class Initialized
INFO - 2023-07-03 11:54:42 --> Language Class Initialized
INFO - 2023-07-03 11:54:42 --> Loader Class Initialized
INFO - 2023-07-03 11:54:42 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:42 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:42 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:42 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:42 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:42 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:42 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:42 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:42 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:42 --> Parser Class Initialized
INFO - 2023-07-03 11:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:42 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:42 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:42 --> Controller Class Initialized
INFO - 2023-07-03 11:54:42 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:42 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:42 --> Model Class Initialized
INFO - 2023-07-03 11:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 11:54:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:54:42 --> Model Class Initialized
INFO - 2023-07-03 11:54:42 --> Model Class Initialized
INFO - 2023-07-03 11:54:42 --> Model Class Initialized
INFO - 2023-07-03 11:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:54:42 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:42 --> Total execution time: 0.1303
ERROR - 2023-07-03 11:54:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:43 --> Config Class Initialized
INFO - 2023-07-03 11:54:43 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:43 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:43 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:43 --> URI Class Initialized
INFO - 2023-07-03 11:54:43 --> Router Class Initialized
INFO - 2023-07-03 11:54:43 --> Output Class Initialized
INFO - 2023-07-03 11:54:43 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:43 --> Input Class Initialized
INFO - 2023-07-03 11:54:43 --> Language Class Initialized
INFO - 2023-07-03 11:54:43 --> Loader Class Initialized
INFO - 2023-07-03 11:54:43 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:43 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:43 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:43 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:43 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:43 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:43 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:43 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:43 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:43 --> Parser Class Initialized
INFO - 2023-07-03 11:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:43 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:43 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:43 --> Controller Class Initialized
INFO - 2023-07-03 11:54:43 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:43 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:43 --> Model Class Initialized
INFO - 2023-07-03 11:54:43 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:43 --> Total execution time: 0.0587
ERROR - 2023-07-03 11:54:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:54 --> Config Class Initialized
INFO - 2023-07-03 11:54:54 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:54 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:54 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:54 --> URI Class Initialized
INFO - 2023-07-03 11:54:54 --> Router Class Initialized
INFO - 2023-07-03 11:54:54 --> Output Class Initialized
INFO - 2023-07-03 11:54:54 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:54 --> Input Class Initialized
INFO - 2023-07-03 11:54:54 --> Language Class Initialized
INFO - 2023-07-03 11:54:54 --> Loader Class Initialized
INFO - 2023-07-03 11:54:54 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:54 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:54 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:54 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:54 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:54 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:54 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:54 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:54 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:54 --> Parser Class Initialized
INFO - 2023-07-03 11:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:54 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:54 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:54 --> Controller Class Initialized
INFO - 2023-07-03 11:54:54 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:54 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:54 --> Model Class Initialized
INFO - 2023-07-03 11:54:54 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:54 --> Total execution time: 0.0586
ERROR - 2023-07-03 11:54:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:54:56 --> Config Class Initialized
INFO - 2023-07-03 11:54:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:54:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:54:56 --> Utf8 Class Initialized
INFO - 2023-07-03 11:54:56 --> URI Class Initialized
INFO - 2023-07-03 11:54:56 --> Router Class Initialized
INFO - 2023-07-03 11:54:56 --> Output Class Initialized
INFO - 2023-07-03 11:54:56 --> Security Class Initialized
DEBUG - 2023-07-03 11:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:54:56 --> Input Class Initialized
INFO - 2023-07-03 11:54:56 --> Language Class Initialized
INFO - 2023-07-03 11:54:56 --> Loader Class Initialized
INFO - 2023-07-03 11:54:56 --> Helper loaded: url_helper
INFO - 2023-07-03 11:54:56 --> Helper loaded: file_helper
INFO - 2023-07-03 11:54:56 --> Helper loaded: html_helper
INFO - 2023-07-03 11:54:56 --> Helper loaded: text_helper
INFO - 2023-07-03 11:54:56 --> Helper loaded: form_helper
INFO - 2023-07-03 11:54:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:54:56 --> Helper loaded: security_helper
INFO - 2023-07-03 11:54:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:54:56 --> Database Driver Class Initialized
INFO - 2023-07-03 11:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:54:56 --> Parser Class Initialized
INFO - 2023-07-03 11:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:54:56 --> Pagination Class Initialized
INFO - 2023-07-03 11:54:56 --> Form Validation Class Initialized
INFO - 2023-07-03 11:54:56 --> Controller Class Initialized
INFO - 2023-07-03 11:54:56 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:56 --> Model Class Initialized
DEBUG - 2023-07-03 11:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:54:56 --> Model Class Initialized
INFO - 2023-07-03 11:54:56 --> Final output sent to browser
DEBUG - 2023-07-03 11:54:56 --> Total execution time: 0.0259
ERROR - 2023-07-03 11:55:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:55:13 --> Config Class Initialized
INFO - 2023-07-03 11:55:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:55:13 --> Utf8 Class Initialized
INFO - 2023-07-03 11:55:13 --> URI Class Initialized
INFO - 2023-07-03 11:55:13 --> Router Class Initialized
INFO - 2023-07-03 11:55:13 --> Output Class Initialized
INFO - 2023-07-03 11:55:13 --> Security Class Initialized
DEBUG - 2023-07-03 11:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:55:13 --> Input Class Initialized
INFO - 2023-07-03 11:55:13 --> Language Class Initialized
INFO - 2023-07-03 11:55:13 --> Loader Class Initialized
INFO - 2023-07-03 11:55:13 --> Helper loaded: url_helper
INFO - 2023-07-03 11:55:13 --> Helper loaded: file_helper
INFO - 2023-07-03 11:55:13 --> Helper loaded: html_helper
INFO - 2023-07-03 11:55:13 --> Helper loaded: text_helper
INFO - 2023-07-03 11:55:13 --> Helper loaded: form_helper
INFO - 2023-07-03 11:55:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:55:13 --> Helper loaded: security_helper
INFO - 2023-07-03 11:55:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:55:13 --> Database Driver Class Initialized
INFO - 2023-07-03 11:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:55:13 --> Parser Class Initialized
INFO - 2023-07-03 11:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:55:13 --> Pagination Class Initialized
INFO - 2023-07-03 11:55:13 --> Form Validation Class Initialized
INFO - 2023-07-03 11:55:13 --> Controller Class Initialized
INFO - 2023-07-03 11:55:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:13 --> Model Class Initialized
INFO - 2023-07-03 11:55:13 --> Final output sent to browser
DEBUG - 2023-07-03 11:55:13 --> Total execution time: 0.0598
ERROR - 2023-07-03 11:55:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:55:15 --> Config Class Initialized
INFO - 2023-07-03 11:55:15 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:55:15 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:55:15 --> Utf8 Class Initialized
INFO - 2023-07-03 11:55:15 --> URI Class Initialized
INFO - 2023-07-03 11:55:15 --> Router Class Initialized
INFO - 2023-07-03 11:55:15 --> Output Class Initialized
INFO - 2023-07-03 11:55:15 --> Security Class Initialized
DEBUG - 2023-07-03 11:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:55:15 --> Input Class Initialized
INFO - 2023-07-03 11:55:15 --> Language Class Initialized
INFO - 2023-07-03 11:55:15 --> Loader Class Initialized
INFO - 2023-07-03 11:55:15 --> Helper loaded: url_helper
INFO - 2023-07-03 11:55:15 --> Helper loaded: file_helper
INFO - 2023-07-03 11:55:15 --> Helper loaded: html_helper
INFO - 2023-07-03 11:55:15 --> Helper loaded: text_helper
INFO - 2023-07-03 11:55:15 --> Helper loaded: form_helper
INFO - 2023-07-03 11:55:15 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:55:15 --> Helper loaded: security_helper
INFO - 2023-07-03 11:55:15 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:55:15 --> Database Driver Class Initialized
INFO - 2023-07-03 11:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:55:15 --> Parser Class Initialized
INFO - 2023-07-03 11:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:55:15 --> Pagination Class Initialized
INFO - 2023-07-03 11:55:15 --> Form Validation Class Initialized
INFO - 2023-07-03 11:55:15 --> Controller Class Initialized
INFO - 2023-07-03 11:55:15 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:15 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:15 --> Model Class Initialized
INFO - 2023-07-03 11:55:15 --> Final output sent to browser
DEBUG - 2023-07-03 11:55:15 --> Total execution time: 0.0566
ERROR - 2023-07-03 11:55:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:55:23 --> Config Class Initialized
INFO - 2023-07-03 11:55:23 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:55:23 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:55:23 --> Utf8 Class Initialized
INFO - 2023-07-03 11:55:23 --> URI Class Initialized
INFO - 2023-07-03 11:55:23 --> Router Class Initialized
INFO - 2023-07-03 11:55:23 --> Output Class Initialized
INFO - 2023-07-03 11:55:23 --> Security Class Initialized
DEBUG - 2023-07-03 11:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:55:23 --> Input Class Initialized
INFO - 2023-07-03 11:55:23 --> Language Class Initialized
INFO - 2023-07-03 11:55:23 --> Loader Class Initialized
INFO - 2023-07-03 11:55:23 --> Helper loaded: url_helper
INFO - 2023-07-03 11:55:23 --> Helper loaded: file_helper
INFO - 2023-07-03 11:55:23 --> Helper loaded: html_helper
INFO - 2023-07-03 11:55:23 --> Helper loaded: text_helper
INFO - 2023-07-03 11:55:23 --> Helper loaded: form_helper
INFO - 2023-07-03 11:55:23 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:55:23 --> Helper loaded: security_helper
INFO - 2023-07-03 11:55:23 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:55:23 --> Database Driver Class Initialized
INFO - 2023-07-03 11:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:55:23 --> Parser Class Initialized
INFO - 2023-07-03 11:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:55:23 --> Pagination Class Initialized
INFO - 2023-07-03 11:55:23 --> Form Validation Class Initialized
INFO - 2023-07-03 11:55:23 --> Controller Class Initialized
INFO - 2023-07-03 11:55:23 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:23 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:23 --> Model Class Initialized
INFO - 2023-07-03 11:55:23 --> Final output sent to browser
DEBUG - 2023-07-03 11:55:23 --> Total execution time: 0.2681
ERROR - 2023-07-03 11:55:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:55:26 --> Config Class Initialized
INFO - 2023-07-03 11:55:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:55:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:55:26 --> Utf8 Class Initialized
INFO - 2023-07-03 11:55:26 --> URI Class Initialized
INFO - 2023-07-03 11:55:26 --> Router Class Initialized
INFO - 2023-07-03 11:55:26 --> Output Class Initialized
INFO - 2023-07-03 11:55:26 --> Security Class Initialized
DEBUG - 2023-07-03 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:55:26 --> Input Class Initialized
INFO - 2023-07-03 11:55:26 --> Language Class Initialized
INFO - 2023-07-03 11:55:26 --> Loader Class Initialized
INFO - 2023-07-03 11:55:26 --> Helper loaded: url_helper
INFO - 2023-07-03 11:55:26 --> Helper loaded: file_helper
INFO - 2023-07-03 11:55:26 --> Helper loaded: html_helper
INFO - 2023-07-03 11:55:26 --> Helper loaded: text_helper
INFO - 2023-07-03 11:55:26 --> Helper loaded: form_helper
INFO - 2023-07-03 11:55:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:55:26 --> Helper loaded: security_helper
INFO - 2023-07-03 11:55:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:55:26 --> Database Driver Class Initialized
INFO - 2023-07-03 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:55:26 --> Parser Class Initialized
INFO - 2023-07-03 11:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:55:26 --> Pagination Class Initialized
INFO - 2023-07-03 11:55:26 --> Form Validation Class Initialized
INFO - 2023-07-03 11:55:26 --> Controller Class Initialized
INFO - 2023-07-03 11:55:26 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:26 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:26 --> Model Class Initialized
INFO - 2023-07-03 11:55:26 --> Final output sent to browser
DEBUG - 2023-07-03 11:55:26 --> Total execution time: 0.2829
ERROR - 2023-07-03 11:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:55:44 --> Config Class Initialized
INFO - 2023-07-03 11:55:44 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:55:44 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:55:44 --> Utf8 Class Initialized
INFO - 2023-07-03 11:55:44 --> URI Class Initialized
INFO - 2023-07-03 11:55:44 --> Router Class Initialized
INFO - 2023-07-03 11:55:44 --> Output Class Initialized
INFO - 2023-07-03 11:55:44 --> Security Class Initialized
DEBUG - 2023-07-03 11:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:55:44 --> Input Class Initialized
INFO - 2023-07-03 11:55:44 --> Language Class Initialized
INFO - 2023-07-03 11:55:44 --> Loader Class Initialized
INFO - 2023-07-03 11:55:44 --> Helper loaded: url_helper
INFO - 2023-07-03 11:55:44 --> Helper loaded: file_helper
INFO - 2023-07-03 11:55:44 --> Helper loaded: html_helper
INFO - 2023-07-03 11:55:44 --> Helper loaded: text_helper
INFO - 2023-07-03 11:55:44 --> Helper loaded: form_helper
INFO - 2023-07-03 11:55:44 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:55:44 --> Helper loaded: security_helper
INFO - 2023-07-03 11:55:44 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:55:44 --> Database Driver Class Initialized
INFO - 2023-07-03 11:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:55:44 --> Parser Class Initialized
INFO - 2023-07-03 11:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:55:44 --> Pagination Class Initialized
INFO - 2023-07-03 11:55:44 --> Form Validation Class Initialized
INFO - 2023-07-03 11:55:44 --> Controller Class Initialized
INFO - 2023-07-03 11:55:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:44 --> Model Class Initialized
DEBUG - 2023-07-03 11:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:55:44 --> Model Class Initialized
INFO - 2023-07-03 11:55:44 --> Final output sent to browser
DEBUG - 2023-07-03 11:55:44 --> Total execution time: 0.0601
ERROR - 2023-07-03 11:56:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:01 --> Config Class Initialized
INFO - 2023-07-03 11:56:01 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:01 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:01 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:01 --> URI Class Initialized
INFO - 2023-07-03 11:56:01 --> Router Class Initialized
INFO - 2023-07-03 11:56:01 --> Output Class Initialized
INFO - 2023-07-03 11:56:01 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:01 --> Input Class Initialized
INFO - 2023-07-03 11:56:01 --> Language Class Initialized
INFO - 2023-07-03 11:56:01 --> Loader Class Initialized
INFO - 2023-07-03 11:56:01 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:01 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:01 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:01 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:01 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:01 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:01 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:01 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:01 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:01 --> Parser Class Initialized
INFO - 2023-07-03 11:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:01 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:01 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:01 --> Controller Class Initialized
INFO - 2023-07-03 11:56:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:01 --> Model Class Initialized
INFO - 2023-07-03 11:56:01 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:01 --> Total execution time: 0.0619
ERROR - 2023-07-03 11:56:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:11 --> Config Class Initialized
INFO - 2023-07-03 11:56:11 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:11 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:11 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:11 --> URI Class Initialized
INFO - 2023-07-03 11:56:11 --> Router Class Initialized
INFO - 2023-07-03 11:56:11 --> Output Class Initialized
INFO - 2023-07-03 11:56:11 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:11 --> Input Class Initialized
INFO - 2023-07-03 11:56:11 --> Language Class Initialized
INFO - 2023-07-03 11:56:11 --> Loader Class Initialized
INFO - 2023-07-03 11:56:11 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:11 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:11 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:11 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:11 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:11 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:11 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:11 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:11 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:11 --> Parser Class Initialized
INFO - 2023-07-03 11:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:11 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:11 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:11 --> Controller Class Initialized
INFO - 2023-07-03 11:56:11 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:11 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:11 --> Model Class Initialized
INFO - 2023-07-03 11:56:11 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:11 --> Total execution time: 0.0626
ERROR - 2023-07-03 11:56:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:13 --> Config Class Initialized
INFO - 2023-07-03 11:56:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:13 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:13 --> URI Class Initialized
INFO - 2023-07-03 11:56:13 --> Router Class Initialized
INFO - 2023-07-03 11:56:13 --> Output Class Initialized
INFO - 2023-07-03 11:56:13 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:13 --> Input Class Initialized
INFO - 2023-07-03 11:56:13 --> Language Class Initialized
INFO - 2023-07-03 11:56:13 --> Loader Class Initialized
INFO - 2023-07-03 11:56:13 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:13 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:13 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:13 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:13 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:13 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:13 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:13 --> Parser Class Initialized
INFO - 2023-07-03 11:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:13 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:13 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:13 --> Controller Class Initialized
INFO - 2023-07-03 11:56:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:13 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:13 --> Model Class Initialized
INFO - 2023-07-03 11:56:13 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:13 --> Total execution time: 0.0583
ERROR - 2023-07-03 11:56:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:16 --> Config Class Initialized
INFO - 2023-07-03 11:56:16 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:16 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:16 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:16 --> URI Class Initialized
INFO - 2023-07-03 11:56:16 --> Router Class Initialized
INFO - 2023-07-03 11:56:16 --> Output Class Initialized
INFO - 2023-07-03 11:56:16 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:16 --> Input Class Initialized
INFO - 2023-07-03 11:56:16 --> Language Class Initialized
INFO - 2023-07-03 11:56:16 --> Loader Class Initialized
INFO - 2023-07-03 11:56:16 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:16 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:16 --> Parser Class Initialized
INFO - 2023-07-03 11:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:16 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:16 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:16 --> Controller Class Initialized
INFO - 2023-07-03 11:56:16 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:16 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:16 --> Model Class Initialized
INFO - 2023-07-03 11:56:16 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:16 --> Total execution time: 0.0607
ERROR - 2023-07-03 11:56:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:16 --> Config Class Initialized
INFO - 2023-07-03 11:56:16 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:16 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:16 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:16 --> URI Class Initialized
INFO - 2023-07-03 11:56:16 --> Router Class Initialized
INFO - 2023-07-03 11:56:16 --> Output Class Initialized
INFO - 2023-07-03 11:56:16 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:16 --> Input Class Initialized
INFO - 2023-07-03 11:56:16 --> Language Class Initialized
INFO - 2023-07-03 11:56:16 --> Loader Class Initialized
INFO - 2023-07-03 11:56:16 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:16 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:16 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:16 --> Parser Class Initialized
INFO - 2023-07-03 11:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:16 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:16 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:16 --> Controller Class Initialized
INFO - 2023-07-03 11:56:16 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:16 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:16 --> Model Class Initialized
INFO - 2023-07-03 11:56:17 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:17 --> Total execution time: 0.0598
ERROR - 2023-07-03 11:56:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:17 --> Config Class Initialized
INFO - 2023-07-03 11:56:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:17 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:17 --> URI Class Initialized
INFO - 2023-07-03 11:56:17 --> Router Class Initialized
INFO - 2023-07-03 11:56:17 --> Output Class Initialized
INFO - 2023-07-03 11:56:17 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:17 --> Input Class Initialized
INFO - 2023-07-03 11:56:17 --> Language Class Initialized
INFO - 2023-07-03 11:56:17 --> Loader Class Initialized
INFO - 2023-07-03 11:56:17 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:17 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:17 --> Parser Class Initialized
INFO - 2023-07-03 11:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:17 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:17 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:17 --> Controller Class Initialized
INFO - 2023-07-03 11:56:17 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:17 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:17 --> Model Class Initialized
INFO - 2023-07-03 11:56:17 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:17 --> Total execution time: 0.0515
ERROR - 2023-07-03 11:56:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:17 --> Config Class Initialized
INFO - 2023-07-03 11:56:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:17 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:17 --> URI Class Initialized
INFO - 2023-07-03 11:56:17 --> Router Class Initialized
INFO - 2023-07-03 11:56:17 --> Output Class Initialized
INFO - 2023-07-03 11:56:17 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:17 --> Input Class Initialized
INFO - 2023-07-03 11:56:17 --> Language Class Initialized
INFO - 2023-07-03 11:56:17 --> Loader Class Initialized
INFO - 2023-07-03 11:56:17 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:17 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:17 --> Parser Class Initialized
INFO - 2023-07-03 11:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:17 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:17 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:17 --> Controller Class Initialized
INFO - 2023-07-03 11:56:17 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:17 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:17 --> Model Class Initialized
INFO - 2023-07-03 11:56:17 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:17 --> Total execution time: 0.0477
ERROR - 2023-07-03 11:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:18 --> Config Class Initialized
INFO - 2023-07-03 11:56:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:18 --> URI Class Initialized
INFO - 2023-07-03 11:56:18 --> Router Class Initialized
INFO - 2023-07-03 11:56:18 --> Output Class Initialized
INFO - 2023-07-03 11:56:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:18 --> Input Class Initialized
INFO - 2023-07-03 11:56:18 --> Language Class Initialized
INFO - 2023-07-03 11:56:18 --> Loader Class Initialized
INFO - 2023-07-03 11:56:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:18 --> Parser Class Initialized
INFO - 2023-07-03 11:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:18 --> Controller Class Initialized
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
ERROR - 2023-07-03 11:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:18 --> Config Class Initialized
INFO - 2023-07-03 11:56:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:18 --> URI Class Initialized
INFO - 2023-07-03 11:56:18 --> Router Class Initialized
INFO - 2023-07-03 11:56:18 --> Output Class Initialized
INFO - 2023-07-03 11:56:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:18 --> Input Class Initialized
INFO - 2023-07-03 11:56:18 --> Language Class Initialized
INFO - 2023-07-03 11:56:18 --> Loader Class Initialized
INFO - 2023-07-03 11:56:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:18 --> Total execution time: 0.0469
INFO - 2023-07-03 11:56:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:18 --> Parser Class Initialized
INFO - 2023-07-03 11:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:18 --> Controller Class Initialized
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
INFO - 2023-07-03 11:56:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:18 --> Total execution time: 0.0508
ERROR - 2023-07-03 11:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:18 --> Config Class Initialized
INFO - 2023-07-03 11:56:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:18 --> URI Class Initialized
INFO - 2023-07-03 11:56:18 --> Router Class Initialized
INFO - 2023-07-03 11:56:18 --> Output Class Initialized
INFO - 2023-07-03 11:56:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:18 --> Input Class Initialized
INFO - 2023-07-03 11:56:18 --> Language Class Initialized
INFO - 2023-07-03 11:56:18 --> Loader Class Initialized
INFO - 2023-07-03 11:56:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:18 --> Parser Class Initialized
INFO - 2023-07-03 11:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:18 --> Controller Class Initialized
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
INFO - 2023-07-03 11:56:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:18 --> Total execution time: 0.0504
ERROR - 2023-07-03 11:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:18 --> Config Class Initialized
INFO - 2023-07-03 11:56:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:18 --> URI Class Initialized
INFO - 2023-07-03 11:56:18 --> Router Class Initialized
INFO - 2023-07-03 11:56:18 --> Output Class Initialized
INFO - 2023-07-03 11:56:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:18 --> Input Class Initialized
INFO - 2023-07-03 11:56:18 --> Language Class Initialized
INFO - 2023-07-03 11:56:18 --> Loader Class Initialized
INFO - 2023-07-03 11:56:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:18 --> Parser Class Initialized
INFO - 2023-07-03 11:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:18 --> Controller Class Initialized
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
INFO - 2023-07-03 11:56:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:18 --> Total execution time: 0.0504
ERROR - 2023-07-03 11:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:18 --> Config Class Initialized
INFO - 2023-07-03 11:56:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:18 --> URI Class Initialized
INFO - 2023-07-03 11:56:18 --> Router Class Initialized
INFO - 2023-07-03 11:56:18 --> Output Class Initialized
INFO - 2023-07-03 11:56:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:18 --> Input Class Initialized
INFO - 2023-07-03 11:56:18 --> Language Class Initialized
INFO - 2023-07-03 11:56:18 --> Loader Class Initialized
INFO - 2023-07-03 11:56:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:18 --> Parser Class Initialized
INFO - 2023-07-03 11:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:18 --> Controller Class Initialized
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
INFO - 2023-07-03 11:56:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:18 --> Total execution time: 0.0481
ERROR - 2023-07-03 11:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:18 --> Config Class Initialized
INFO - 2023-07-03 11:56:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:18 --> URI Class Initialized
INFO - 2023-07-03 11:56:18 --> Router Class Initialized
INFO - 2023-07-03 11:56:18 --> Output Class Initialized
INFO - 2023-07-03 11:56:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:18 --> Input Class Initialized
INFO - 2023-07-03 11:56:18 --> Language Class Initialized
INFO - 2023-07-03 11:56:18 --> Loader Class Initialized
INFO - 2023-07-03 11:56:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:18 --> Parser Class Initialized
INFO - 2023-07-03 11:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:18 --> Controller Class Initialized
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:18 --> Model Class Initialized
INFO - 2023-07-03 11:56:18 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:18 --> Total execution time: 0.0459
ERROR - 2023-07-03 11:56:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:19 --> Config Class Initialized
INFO - 2023-07-03 11:56:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:19 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:19 --> URI Class Initialized
INFO - 2023-07-03 11:56:19 --> Router Class Initialized
INFO - 2023-07-03 11:56:19 --> Output Class Initialized
INFO - 2023-07-03 11:56:19 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:19 --> Input Class Initialized
INFO - 2023-07-03 11:56:19 --> Language Class Initialized
INFO - 2023-07-03 11:56:19 --> Loader Class Initialized
INFO - 2023-07-03 11:56:19 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:19 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:19 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:19 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:19 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:19 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:19 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:19 --> Parser Class Initialized
INFO - 2023-07-03 11:56:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:19 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:19 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:19 --> Controller Class Initialized
INFO - 2023-07-03 11:56:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:19 --> Model Class Initialized
INFO - 2023-07-03 11:56:19 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:19 --> Total execution time: 0.0445
ERROR - 2023-07-03 11:56:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:33 --> Config Class Initialized
INFO - 2023-07-03 11:56:33 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:33 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:33 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:33 --> URI Class Initialized
INFO - 2023-07-03 11:56:33 --> Router Class Initialized
INFO - 2023-07-03 11:56:33 --> Output Class Initialized
INFO - 2023-07-03 11:56:33 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:33 --> Input Class Initialized
INFO - 2023-07-03 11:56:33 --> Language Class Initialized
INFO - 2023-07-03 11:56:33 --> Loader Class Initialized
INFO - 2023-07-03 11:56:33 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:33 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:33 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:33 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:33 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:33 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:33 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:33 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:33 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:33 --> Parser Class Initialized
INFO - 2023-07-03 11:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:33 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:33 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:33 --> Controller Class Initialized
INFO - 2023-07-03 11:56:33 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:33 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:33 --> Model Class Initialized
INFO - 2023-07-03 11:56:33 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:33 --> Total execution time: 0.0393
ERROR - 2023-07-03 11:56:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:34 --> Config Class Initialized
INFO - 2023-07-03 11:56:34 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:34 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:34 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:34 --> URI Class Initialized
INFO - 2023-07-03 11:56:34 --> Router Class Initialized
INFO - 2023-07-03 11:56:34 --> Output Class Initialized
INFO - 2023-07-03 11:56:34 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:34 --> Input Class Initialized
INFO - 2023-07-03 11:56:34 --> Language Class Initialized
INFO - 2023-07-03 11:56:34 --> Loader Class Initialized
INFO - 2023-07-03 11:56:34 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:34 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:34 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:34 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:34 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:34 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:34 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:34 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:34 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:34 --> Parser Class Initialized
INFO - 2023-07-03 11:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:34 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:34 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:34 --> Controller Class Initialized
INFO - 2023-07-03 11:56:34 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:34 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:34 --> Model Class Initialized
INFO - 2023-07-03 11:56:34 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:34 --> Total execution time: 0.0277
ERROR - 2023-07-03 11:56:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:35 --> Config Class Initialized
INFO - 2023-07-03 11:56:35 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:35 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:35 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:35 --> URI Class Initialized
INFO - 2023-07-03 11:56:35 --> Router Class Initialized
INFO - 2023-07-03 11:56:35 --> Output Class Initialized
INFO - 2023-07-03 11:56:35 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:35 --> Input Class Initialized
INFO - 2023-07-03 11:56:35 --> Language Class Initialized
INFO - 2023-07-03 11:56:35 --> Loader Class Initialized
INFO - 2023-07-03 11:56:35 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:35 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:35 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:35 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:35 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:35 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:35 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:35 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:35 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:35 --> Parser Class Initialized
INFO - 2023-07-03 11:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:35 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:35 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:35 --> Controller Class Initialized
INFO - 2023-07-03 11:56:35 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:35 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:35 --> Model Class Initialized
INFO - 2023-07-03 11:56:35 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:35 --> Total execution time: 0.0203
ERROR - 2023-07-03 11:56:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:38 --> Config Class Initialized
INFO - 2023-07-03 11:56:38 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:38 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:38 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:38 --> URI Class Initialized
INFO - 2023-07-03 11:56:38 --> Router Class Initialized
INFO - 2023-07-03 11:56:38 --> Output Class Initialized
INFO - 2023-07-03 11:56:38 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:38 --> Input Class Initialized
INFO - 2023-07-03 11:56:38 --> Language Class Initialized
INFO - 2023-07-03 11:56:38 --> Loader Class Initialized
INFO - 2023-07-03 11:56:38 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:38 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:38 --> Parser Class Initialized
INFO - 2023-07-03 11:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:38 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:38 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:38 --> Controller Class Initialized
INFO - 2023-07-03 11:56:38 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:38 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:38 --> Model Class Initialized
INFO - 2023-07-03 11:56:38 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:38 --> Total execution time: 0.0282
ERROR - 2023-07-03 11:56:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:38 --> Config Class Initialized
INFO - 2023-07-03 11:56:38 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:38 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:38 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:38 --> URI Class Initialized
INFO - 2023-07-03 11:56:38 --> Router Class Initialized
INFO - 2023-07-03 11:56:38 --> Output Class Initialized
INFO - 2023-07-03 11:56:38 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:38 --> Input Class Initialized
INFO - 2023-07-03 11:56:38 --> Language Class Initialized
INFO - 2023-07-03 11:56:38 --> Loader Class Initialized
INFO - 2023-07-03 11:56:38 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:38 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:38 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:38 --> Parser Class Initialized
INFO - 2023-07-03 11:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:38 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:38 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:38 --> Controller Class Initialized
INFO - 2023-07-03 11:56:38 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:38 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:38 --> Model Class Initialized
INFO - 2023-07-03 11:56:38 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:38 --> Total execution time: 0.0545
ERROR - 2023-07-03 11:56:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:47 --> Config Class Initialized
INFO - 2023-07-03 11:56:47 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:47 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:47 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:47 --> URI Class Initialized
INFO - 2023-07-03 11:56:47 --> Router Class Initialized
INFO - 2023-07-03 11:56:47 --> Output Class Initialized
INFO - 2023-07-03 11:56:47 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:47 --> Input Class Initialized
INFO - 2023-07-03 11:56:47 --> Language Class Initialized
INFO - 2023-07-03 11:56:47 --> Loader Class Initialized
INFO - 2023-07-03 11:56:47 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:47 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:47 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:47 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:47 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:47 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:47 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:47 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:47 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:47 --> Parser Class Initialized
INFO - 2023-07-03 11:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:47 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:47 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:47 --> Controller Class Initialized
INFO - 2023-07-03 11:56:47 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:47 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:47 --> Model Class Initialized
INFO - 2023-07-03 11:56:47 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:47 --> Total execution time: 0.0594
ERROR - 2023-07-03 11:56:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:49 --> Config Class Initialized
INFO - 2023-07-03 11:56:49 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:49 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:49 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:49 --> URI Class Initialized
INFO - 2023-07-03 11:56:49 --> Router Class Initialized
INFO - 2023-07-03 11:56:49 --> Output Class Initialized
INFO - 2023-07-03 11:56:49 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:49 --> Input Class Initialized
INFO - 2023-07-03 11:56:49 --> Language Class Initialized
INFO - 2023-07-03 11:56:49 --> Loader Class Initialized
INFO - 2023-07-03 11:56:49 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:49 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:49 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:49 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:49 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:49 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:49 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:49 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:49 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:49 --> Parser Class Initialized
INFO - 2023-07-03 11:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:49 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:49 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:49 --> Controller Class Initialized
INFO - 2023-07-03 11:56:49 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:49 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:49 --> Model Class Initialized
INFO - 2023-07-03 11:56:49 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:49 --> Total execution time: 0.0633
ERROR - 2023-07-03 11:56:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:50 --> Config Class Initialized
INFO - 2023-07-03 11:56:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:50 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:50 --> URI Class Initialized
INFO - 2023-07-03 11:56:50 --> Router Class Initialized
INFO - 2023-07-03 11:56:50 --> Output Class Initialized
INFO - 2023-07-03 11:56:50 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:50 --> Input Class Initialized
INFO - 2023-07-03 11:56:50 --> Language Class Initialized
INFO - 2023-07-03 11:56:50 --> Loader Class Initialized
INFO - 2023-07-03 11:56:50 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:50 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:50 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:50 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:50 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:50 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:50 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:50 --> Parser Class Initialized
INFO - 2023-07-03 11:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:50 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:50 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:50 --> Controller Class Initialized
INFO - 2023-07-03 11:56:50 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:50 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:50 --> Model Class Initialized
INFO - 2023-07-03 11:56:50 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:50 --> Total execution time: 0.0743
ERROR - 2023-07-03 11:56:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:51 --> Config Class Initialized
INFO - 2023-07-03 11:56:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:51 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:51 --> URI Class Initialized
INFO - 2023-07-03 11:56:51 --> Router Class Initialized
INFO - 2023-07-03 11:56:51 --> Output Class Initialized
INFO - 2023-07-03 11:56:51 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:51 --> Input Class Initialized
INFO - 2023-07-03 11:56:51 --> Language Class Initialized
INFO - 2023-07-03 11:56:51 --> Loader Class Initialized
INFO - 2023-07-03 11:56:51 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:51 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:51 --> Parser Class Initialized
INFO - 2023-07-03 11:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:51 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:51 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:51 --> Controller Class Initialized
INFO - 2023-07-03 11:56:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:51 --> Model Class Initialized
INFO - 2023-07-03 11:56:51 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:51 --> Total execution time: 0.0722
ERROR - 2023-07-03 11:56:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:51 --> Config Class Initialized
INFO - 2023-07-03 11:56:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:51 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:51 --> URI Class Initialized
INFO - 2023-07-03 11:56:51 --> Router Class Initialized
INFO - 2023-07-03 11:56:51 --> Output Class Initialized
INFO - 2023-07-03 11:56:51 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:51 --> Input Class Initialized
INFO - 2023-07-03 11:56:51 --> Language Class Initialized
INFO - 2023-07-03 11:56:51 --> Loader Class Initialized
INFO - 2023-07-03 11:56:51 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:51 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:51 --> Parser Class Initialized
INFO - 2023-07-03 11:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:51 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:51 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:51 --> Controller Class Initialized
INFO - 2023-07-03 11:56:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:51 --> Model Class Initialized
INFO - 2023-07-03 11:56:51 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:51 --> Total execution time: 0.0494
ERROR - 2023-07-03 11:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:56:53 --> Config Class Initialized
INFO - 2023-07-03 11:56:53 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:56:53 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:56:53 --> Utf8 Class Initialized
INFO - 2023-07-03 11:56:53 --> URI Class Initialized
INFO - 2023-07-03 11:56:53 --> Router Class Initialized
INFO - 2023-07-03 11:56:53 --> Output Class Initialized
INFO - 2023-07-03 11:56:53 --> Security Class Initialized
DEBUG - 2023-07-03 11:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:56:53 --> Input Class Initialized
INFO - 2023-07-03 11:56:53 --> Language Class Initialized
INFO - 2023-07-03 11:56:53 --> Loader Class Initialized
INFO - 2023-07-03 11:56:53 --> Helper loaded: url_helper
INFO - 2023-07-03 11:56:53 --> Helper loaded: file_helper
INFO - 2023-07-03 11:56:53 --> Helper loaded: html_helper
INFO - 2023-07-03 11:56:53 --> Helper loaded: text_helper
INFO - 2023-07-03 11:56:53 --> Helper loaded: form_helper
INFO - 2023-07-03 11:56:53 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:56:53 --> Helper loaded: security_helper
INFO - 2023-07-03 11:56:53 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:56:53 --> Database Driver Class Initialized
INFO - 2023-07-03 11:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:56:53 --> Parser Class Initialized
INFO - 2023-07-03 11:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:56:53 --> Pagination Class Initialized
INFO - 2023-07-03 11:56:53 --> Form Validation Class Initialized
INFO - 2023-07-03 11:56:53 --> Controller Class Initialized
INFO - 2023-07-03 11:56:53 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:53 --> Model Class Initialized
DEBUG - 2023-07-03 11:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:56:53 --> Model Class Initialized
INFO - 2023-07-03 11:56:53 --> Final output sent to browser
DEBUG - 2023-07-03 11:56:53 --> Total execution time: 0.0531
ERROR - 2023-07-03 11:57:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:00 --> Config Class Initialized
INFO - 2023-07-03 11:57:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:00 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:00 --> URI Class Initialized
INFO - 2023-07-03 11:57:00 --> Router Class Initialized
INFO - 2023-07-03 11:57:00 --> Output Class Initialized
INFO - 2023-07-03 11:57:00 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:00 --> Input Class Initialized
INFO - 2023-07-03 11:57:00 --> Language Class Initialized
INFO - 2023-07-03 11:57:00 --> Loader Class Initialized
INFO - 2023-07-03 11:57:00 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:00 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:00 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:00 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:00 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:00 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:00 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:00 --> Parser Class Initialized
INFO - 2023-07-03 11:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:00 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:00 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:00 --> Controller Class Initialized
INFO - 2023-07-03 11:57:00 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:00 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:00 --> Model Class Initialized
INFO - 2023-07-03 11:57:00 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:00 --> Total execution time: 0.0621
ERROR - 2023-07-03 11:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:01 --> Config Class Initialized
INFO - 2023-07-03 11:57:01 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:01 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:01 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:01 --> URI Class Initialized
INFO - 2023-07-03 11:57:01 --> Router Class Initialized
INFO - 2023-07-03 11:57:01 --> Output Class Initialized
INFO - 2023-07-03 11:57:01 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:01 --> Input Class Initialized
INFO - 2023-07-03 11:57:01 --> Language Class Initialized
INFO - 2023-07-03 11:57:01 --> Loader Class Initialized
INFO - 2023-07-03 11:57:01 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:01 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:01 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:01 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:01 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:01 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:01 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:01 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:01 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:01 --> Parser Class Initialized
INFO - 2023-07-03 11:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:01 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:01 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:01 --> Controller Class Initialized
INFO - 2023-07-03 11:57:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:01 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:01 --> Model Class Initialized
INFO - 2023-07-03 11:57:01 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:01 --> Total execution time: 0.0674
ERROR - 2023-07-03 11:57:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:02 --> Config Class Initialized
INFO - 2023-07-03 11:57:02 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:02 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:02 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:02 --> URI Class Initialized
INFO - 2023-07-03 11:57:02 --> Router Class Initialized
INFO - 2023-07-03 11:57:02 --> Output Class Initialized
INFO - 2023-07-03 11:57:02 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:02 --> Input Class Initialized
INFO - 2023-07-03 11:57:02 --> Language Class Initialized
INFO - 2023-07-03 11:57:02 --> Loader Class Initialized
INFO - 2023-07-03 11:57:02 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:02 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:02 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:02 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:02 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:02 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:02 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:02 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:02 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:02 --> Parser Class Initialized
INFO - 2023-07-03 11:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:02 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:02 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:02 --> Controller Class Initialized
INFO - 2023-07-03 11:57:02 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:02 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:02 --> Model Class Initialized
INFO - 2023-07-03 11:57:02 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:02 --> Total execution time: 0.0652
ERROR - 2023-07-03 11:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:10 --> Config Class Initialized
INFO - 2023-07-03 11:57:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:10 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:10 --> URI Class Initialized
INFO - 2023-07-03 11:57:10 --> Router Class Initialized
INFO - 2023-07-03 11:57:10 --> Output Class Initialized
INFO - 2023-07-03 11:57:10 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:10 --> Input Class Initialized
INFO - 2023-07-03 11:57:10 --> Language Class Initialized
INFO - 2023-07-03 11:57:10 --> Loader Class Initialized
INFO - 2023-07-03 11:57:10 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:10 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:10 --> Parser Class Initialized
INFO - 2023-07-03 11:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:10 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:10 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:10 --> Controller Class Initialized
INFO - 2023-07-03 11:57:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:10 --> Model Class Initialized
INFO - 2023-07-03 11:57:10 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:10 --> Total execution time: 0.0525
ERROR - 2023-07-03 11:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:10 --> Config Class Initialized
INFO - 2023-07-03 11:57:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:10 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:10 --> URI Class Initialized
INFO - 2023-07-03 11:57:10 --> Router Class Initialized
INFO - 2023-07-03 11:57:10 --> Output Class Initialized
INFO - 2023-07-03 11:57:10 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:10 --> Input Class Initialized
INFO - 2023-07-03 11:57:10 --> Language Class Initialized
INFO - 2023-07-03 11:57:10 --> Loader Class Initialized
INFO - 2023-07-03 11:57:10 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:10 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:10 --> Parser Class Initialized
INFO - 2023-07-03 11:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:10 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:10 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:10 --> Controller Class Initialized
INFO - 2023-07-03 11:57:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:10 --> Model Class Initialized
INFO - 2023-07-03 11:57:10 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:10 --> Total execution time: 0.0673
ERROR - 2023-07-03 11:57:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:12 --> Config Class Initialized
INFO - 2023-07-03 11:57:12 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:12 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:12 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:12 --> URI Class Initialized
INFO - 2023-07-03 11:57:12 --> Router Class Initialized
INFO - 2023-07-03 11:57:12 --> Output Class Initialized
INFO - 2023-07-03 11:57:12 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:12 --> Input Class Initialized
INFO - 2023-07-03 11:57:12 --> Language Class Initialized
INFO - 2023-07-03 11:57:12 --> Loader Class Initialized
INFO - 2023-07-03 11:57:12 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:12 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:12 --> Parser Class Initialized
INFO - 2023-07-03 11:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:12 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:12 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:12 --> Controller Class Initialized
INFO - 2023-07-03 11:57:12 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:12 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:12 --> Model Class Initialized
INFO - 2023-07-03 11:57:12 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:12 --> Total execution time: 0.0549
ERROR - 2023-07-03 11:57:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:12 --> Config Class Initialized
INFO - 2023-07-03 11:57:12 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:12 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:12 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:12 --> URI Class Initialized
INFO - 2023-07-03 11:57:12 --> Router Class Initialized
INFO - 2023-07-03 11:57:12 --> Output Class Initialized
INFO - 2023-07-03 11:57:12 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:12 --> Input Class Initialized
INFO - 2023-07-03 11:57:12 --> Language Class Initialized
INFO - 2023-07-03 11:57:12 --> Loader Class Initialized
INFO - 2023-07-03 11:57:12 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:12 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:12 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:12 --> Parser Class Initialized
INFO - 2023-07-03 11:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:12 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:12 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:12 --> Controller Class Initialized
INFO - 2023-07-03 11:57:12 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:12 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:12 --> Model Class Initialized
INFO - 2023-07-03 11:57:12 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:12 --> Total execution time: 0.0568
ERROR - 2023-07-03 11:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:14 --> Config Class Initialized
INFO - 2023-07-03 11:57:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:14 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:14 --> URI Class Initialized
INFO - 2023-07-03 11:57:14 --> Router Class Initialized
INFO - 2023-07-03 11:57:14 --> Output Class Initialized
INFO - 2023-07-03 11:57:14 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:14 --> Input Class Initialized
INFO - 2023-07-03 11:57:14 --> Language Class Initialized
INFO - 2023-07-03 11:57:14 --> Loader Class Initialized
INFO - 2023-07-03 11:57:14 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:14 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:14 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:14 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:14 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:14 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:14 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:14 --> Parser Class Initialized
INFO - 2023-07-03 11:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:14 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:14 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:14 --> Controller Class Initialized
INFO - 2023-07-03 11:57:14 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:14 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:14 --> Model Class Initialized
INFO - 2023-07-03 11:57:14 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:14 --> Total execution time: 0.0551
ERROR - 2023-07-03 11:57:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:16 --> Config Class Initialized
INFO - 2023-07-03 11:57:16 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:16 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:16 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:16 --> URI Class Initialized
INFO - 2023-07-03 11:57:16 --> Router Class Initialized
INFO - 2023-07-03 11:57:16 --> Output Class Initialized
INFO - 2023-07-03 11:57:16 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:16 --> Input Class Initialized
INFO - 2023-07-03 11:57:16 --> Language Class Initialized
INFO - 2023-07-03 11:57:16 --> Loader Class Initialized
INFO - 2023-07-03 11:57:16 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:16 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:16 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:16 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:16 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:16 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:16 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:16 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:16 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:16 --> Parser Class Initialized
INFO - 2023-07-03 11:57:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:16 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:16 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:16 --> Controller Class Initialized
INFO - 2023-07-03 11:57:16 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:16 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:16 --> Model Class Initialized
INFO - 2023-07-03 11:57:16 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:16 --> Total execution time: 0.0594
ERROR - 2023-07-03 11:57:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:17 --> Config Class Initialized
INFO - 2023-07-03 11:57:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:17 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:17 --> URI Class Initialized
INFO - 2023-07-03 11:57:17 --> Router Class Initialized
INFO - 2023-07-03 11:57:17 --> Output Class Initialized
INFO - 2023-07-03 11:57:17 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:17 --> Input Class Initialized
INFO - 2023-07-03 11:57:17 --> Language Class Initialized
INFO - 2023-07-03 11:57:17 --> Loader Class Initialized
INFO - 2023-07-03 11:57:17 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:17 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:17 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:17 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:17 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:17 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:17 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:17 --> Parser Class Initialized
INFO - 2023-07-03 11:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:17 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:17 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:17 --> Controller Class Initialized
INFO - 2023-07-03 11:57:17 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:17 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:17 --> Model Class Initialized
INFO - 2023-07-03 11:57:17 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:17 --> Total execution time: 0.0575
ERROR - 2023-07-03 11:57:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:25 --> Config Class Initialized
INFO - 2023-07-03 11:57:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:25 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:25 --> URI Class Initialized
INFO - 2023-07-03 11:57:25 --> Router Class Initialized
INFO - 2023-07-03 11:57:25 --> Output Class Initialized
INFO - 2023-07-03 11:57:25 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:25 --> Input Class Initialized
INFO - 2023-07-03 11:57:25 --> Language Class Initialized
INFO - 2023-07-03 11:57:25 --> Loader Class Initialized
INFO - 2023-07-03 11:57:25 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:25 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:25 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:25 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:25 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:25 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:25 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:25 --> Parser Class Initialized
INFO - 2023-07-03 11:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:25 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:25 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:25 --> Controller Class Initialized
INFO - 2023-07-03 11:57:25 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:25 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:25 --> Model Class Initialized
INFO - 2023-07-03 11:57:25 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:25 --> Total execution time: 0.0581
ERROR - 2023-07-03 11:57:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:27 --> Config Class Initialized
INFO - 2023-07-03 11:57:27 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:27 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:27 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:27 --> URI Class Initialized
INFO - 2023-07-03 11:57:27 --> Router Class Initialized
INFO - 2023-07-03 11:57:27 --> Output Class Initialized
INFO - 2023-07-03 11:57:27 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:27 --> Input Class Initialized
INFO - 2023-07-03 11:57:27 --> Language Class Initialized
INFO - 2023-07-03 11:57:27 --> Loader Class Initialized
INFO - 2023-07-03 11:57:27 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:27 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:27 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:27 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:27 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:27 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:27 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:27 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:27 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:27 --> Parser Class Initialized
INFO - 2023-07-03 11:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:27 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:27 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:27 --> Controller Class Initialized
INFO - 2023-07-03 11:57:27 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:27 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:27 --> Model Class Initialized
INFO - 2023-07-03 11:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 11:57:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:57:27 --> Model Class Initialized
INFO - 2023-07-03 11:57:27 --> Model Class Initialized
INFO - 2023-07-03 11:57:27 --> Model Class Initialized
INFO - 2023-07-03 11:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:57:27 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:27 --> Total execution time: 0.0754
ERROR - 2023-07-03 11:57:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:28 --> Config Class Initialized
INFO - 2023-07-03 11:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:28 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:28 --> URI Class Initialized
INFO - 2023-07-03 11:57:28 --> Router Class Initialized
INFO - 2023-07-03 11:57:28 --> Output Class Initialized
INFO - 2023-07-03 11:57:28 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:28 --> Input Class Initialized
INFO - 2023-07-03 11:57:28 --> Language Class Initialized
INFO - 2023-07-03 11:57:28 --> Loader Class Initialized
INFO - 2023-07-03 11:57:28 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:28 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:28 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:28 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:28 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:28 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:28 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:28 --> Parser Class Initialized
INFO - 2023-07-03 11:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:28 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:28 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:28 --> Controller Class Initialized
INFO - 2023-07-03 11:57:28 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:28 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:28 --> Model Class Initialized
INFO - 2023-07-03 11:57:28 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:28 --> Total execution time: 0.0524
ERROR - 2023-07-03 11:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:31 --> Config Class Initialized
INFO - 2023-07-03 11:57:31 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:31 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:31 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:31 --> URI Class Initialized
INFO - 2023-07-03 11:57:31 --> Router Class Initialized
INFO - 2023-07-03 11:57:31 --> Output Class Initialized
INFO - 2023-07-03 11:57:31 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:31 --> Input Class Initialized
INFO - 2023-07-03 11:57:31 --> Language Class Initialized
INFO - 2023-07-03 11:57:31 --> Loader Class Initialized
INFO - 2023-07-03 11:57:31 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:31 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:31 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:31 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:31 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:31 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:31 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:31 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:31 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:31 --> Parser Class Initialized
INFO - 2023-07-03 11:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:31 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:31 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:31 --> Controller Class Initialized
INFO - 2023-07-03 11:57:31 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:31 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:31 --> Model Class Initialized
INFO - 2023-07-03 11:57:31 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:31 --> Total execution time: 0.0396
ERROR - 2023-07-03 11:57:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:32 --> Config Class Initialized
INFO - 2023-07-03 11:57:32 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:32 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:32 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:32 --> URI Class Initialized
INFO - 2023-07-03 11:57:32 --> Router Class Initialized
INFO - 2023-07-03 11:57:32 --> Output Class Initialized
INFO - 2023-07-03 11:57:32 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:32 --> Input Class Initialized
INFO - 2023-07-03 11:57:32 --> Language Class Initialized
INFO - 2023-07-03 11:57:32 --> Loader Class Initialized
INFO - 2023-07-03 11:57:32 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:32 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:32 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:32 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:32 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:32 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:32 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:32 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:32 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:32 --> Parser Class Initialized
INFO - 2023-07-03 11:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:32 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:32 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:32 --> Controller Class Initialized
INFO - 2023-07-03 11:57:32 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:32 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:32 --> Model Class Initialized
INFO - 2023-07-03 11:57:32 --> Final output sent to browser
DEBUG - 2023-07-03 11:57:32 --> Total execution time: 0.0261
ERROR - 2023-07-03 11:57:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:40 --> Config Class Initialized
INFO - 2023-07-03 11:57:40 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:40 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:40 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:40 --> URI Class Initialized
INFO - 2023-07-03 11:57:40 --> Router Class Initialized
INFO - 2023-07-03 11:57:40 --> Output Class Initialized
INFO - 2023-07-03 11:57:40 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:40 --> Input Class Initialized
INFO - 2023-07-03 11:57:40 --> Language Class Initialized
INFO - 2023-07-03 11:57:40 --> Loader Class Initialized
INFO - 2023-07-03 11:57:40 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:40 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:40 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:40 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:40 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:40 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:40 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:40 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:40 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:40 --> Parser Class Initialized
INFO - 2023-07-03 11:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:40 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:40 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:40 --> Controller Class Initialized
INFO - 2023-07-03 11:57:40 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:40 --> Model Class Initialized
INFO - 2023-07-03 17:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/sales_report.php
DEBUG - 2023-07-03 17:57:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:57:40 --> Model Class Initialized
INFO - 2023-07-03 17:57:40 --> Model Class Initialized
INFO - 2023-07-03 17:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:57:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:57:40 --> Final output sent to browser
DEBUG - 2023-07-03 17:57:40 --> Total execution time: 0.1441
ERROR - 2023-07-03 11:57:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:57:52 --> Config Class Initialized
INFO - 2023-07-03 11:57:52 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:57:52 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:57:52 --> Utf8 Class Initialized
INFO - 2023-07-03 11:57:52 --> URI Class Initialized
INFO - 2023-07-03 11:57:52 --> Router Class Initialized
INFO - 2023-07-03 11:57:52 --> Output Class Initialized
INFO - 2023-07-03 11:57:52 --> Security Class Initialized
DEBUG - 2023-07-03 11:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:57:52 --> Input Class Initialized
INFO - 2023-07-03 11:57:52 --> Language Class Initialized
INFO - 2023-07-03 11:57:52 --> Loader Class Initialized
INFO - 2023-07-03 11:57:52 --> Helper loaded: url_helper
INFO - 2023-07-03 11:57:52 --> Helper loaded: file_helper
INFO - 2023-07-03 11:57:52 --> Helper loaded: html_helper
INFO - 2023-07-03 11:57:52 --> Helper loaded: text_helper
INFO - 2023-07-03 11:57:52 --> Helper loaded: form_helper
INFO - 2023-07-03 11:57:52 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:57:52 --> Helper loaded: security_helper
INFO - 2023-07-03 11:57:52 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:57:52 --> Database Driver Class Initialized
INFO - 2023-07-03 11:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:57:52 --> Parser Class Initialized
INFO - 2023-07-03 11:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:57:52 --> Pagination Class Initialized
INFO - 2023-07-03 11:57:52 --> Form Validation Class Initialized
INFO - 2023-07-03 11:57:52 --> Controller Class Initialized
INFO - 2023-07-03 11:57:52 --> Model Class Initialized
DEBUG - 2023-07-03 11:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:57:52 --> Model Class Initialized
INFO - 2023-07-03 17:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/sales_report.php
DEBUG - 2023-07-03 17:57:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:57:52 --> Model Class Initialized
INFO - 2023-07-03 17:57:52 --> Model Class Initialized
INFO - 2023-07-03 17:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:57:52 --> Final output sent to browser
DEBUG - 2023-07-03 17:57:52 --> Total execution time: 0.1523
ERROR - 2023-07-03 11:58:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:05 --> Config Class Initialized
INFO - 2023-07-03 11:58:05 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:05 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:05 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:05 --> URI Class Initialized
INFO - 2023-07-03 11:58:05 --> Router Class Initialized
INFO - 2023-07-03 11:58:05 --> Output Class Initialized
INFO - 2023-07-03 11:58:05 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:05 --> Input Class Initialized
INFO - 2023-07-03 11:58:05 --> Language Class Initialized
INFO - 2023-07-03 11:58:05 --> Loader Class Initialized
INFO - 2023-07-03 11:58:05 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:05 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:05 --> Parser Class Initialized
INFO - 2023-07-03 11:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:05 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:05 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:05 --> Controller Class Initialized
INFO - 2023-07-03 11:58:05 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:05 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:05 --> Model Class Initialized
INFO - 2023-07-03 11:58:05 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:05 --> Total execution time: 0.0403
ERROR - 2023-07-03 11:58:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:05 --> Config Class Initialized
INFO - 2023-07-03 11:58:05 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:05 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:05 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:05 --> URI Class Initialized
INFO - 2023-07-03 11:58:05 --> Router Class Initialized
INFO - 2023-07-03 11:58:05 --> Output Class Initialized
INFO - 2023-07-03 11:58:05 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:05 --> Input Class Initialized
INFO - 2023-07-03 11:58:05 --> Language Class Initialized
INFO - 2023-07-03 11:58:05 --> Loader Class Initialized
INFO - 2023-07-03 11:58:05 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:05 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:05 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:05 --> Parser Class Initialized
INFO - 2023-07-03 11:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:05 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:05 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:05 --> Controller Class Initialized
INFO - 2023-07-03 11:58:05 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:05 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:05 --> Model Class Initialized
INFO - 2023-07-03 11:58:05 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:05 --> Total execution time: 0.0634
ERROR - 2023-07-03 11:58:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:06 --> Config Class Initialized
INFO - 2023-07-03 11:58:06 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:06 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:06 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:06 --> URI Class Initialized
INFO - 2023-07-03 11:58:06 --> Router Class Initialized
INFO - 2023-07-03 11:58:06 --> Output Class Initialized
INFO - 2023-07-03 11:58:06 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:06 --> Input Class Initialized
INFO - 2023-07-03 11:58:06 --> Language Class Initialized
INFO - 2023-07-03 11:58:06 --> Loader Class Initialized
INFO - 2023-07-03 11:58:06 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:06 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:06 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:06 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:06 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:06 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:06 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:06 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:06 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:06 --> Parser Class Initialized
INFO - 2023-07-03 11:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:06 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:06 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:06 --> Controller Class Initialized
INFO - 2023-07-03 11:58:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:06 --> Model Class Initialized
INFO - 2023-07-03 11:58:06 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:06 --> Total execution time: 0.0604
ERROR - 2023-07-03 11:58:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:10 --> Config Class Initialized
INFO - 2023-07-03 11:58:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:10 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:10 --> URI Class Initialized
INFO - 2023-07-03 11:58:10 --> Router Class Initialized
INFO - 2023-07-03 11:58:10 --> Output Class Initialized
INFO - 2023-07-03 11:58:10 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:10 --> Input Class Initialized
INFO - 2023-07-03 11:58:10 --> Language Class Initialized
INFO - 2023-07-03 11:58:10 --> Loader Class Initialized
INFO - 2023-07-03 11:58:10 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:10 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:10 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:10 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:10 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:10 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:10 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:10 --> Parser Class Initialized
INFO - 2023-07-03 11:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:10 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:10 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:10 --> Controller Class Initialized
INFO - 2023-07-03 11:58:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:10 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:10 --> Model Class Initialized
INFO - 2023-07-03 11:58:10 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:10 --> Total execution time: 0.0208
ERROR - 2023-07-03 11:58:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:19 --> Config Class Initialized
INFO - 2023-07-03 11:58:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:19 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:19 --> URI Class Initialized
INFO - 2023-07-03 11:58:19 --> Router Class Initialized
INFO - 2023-07-03 11:58:19 --> Output Class Initialized
INFO - 2023-07-03 11:58:19 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:19 --> Input Class Initialized
INFO - 2023-07-03 11:58:19 --> Language Class Initialized
INFO - 2023-07-03 11:58:19 --> Loader Class Initialized
INFO - 2023-07-03 11:58:19 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:19 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:19 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:19 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:19 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:19 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:19 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:19 --> Parser Class Initialized
INFO - 2023-07-03 11:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:19 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:19 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:19 --> Controller Class Initialized
DEBUG - 2023-07-03 11:58:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:19 --> Model Class Initialized
INFO - 2023-07-03 11:58:19 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:19 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:19 --> Model Class Initialized
INFO - 2023-07-03 11:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-07-03 11:58:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:58:19 --> Model Class Initialized
INFO - 2023-07-03 11:58:19 --> Model Class Initialized
INFO - 2023-07-03 11:58:19 --> Model Class Initialized
INFO - 2023-07-03 11:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:58:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:58:20 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:20 --> Total execution time: 0.1550
ERROR - 2023-07-03 11:58:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:20 --> Config Class Initialized
INFO - 2023-07-03 11:58:20 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:20 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:20 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:20 --> URI Class Initialized
INFO - 2023-07-03 11:58:20 --> Router Class Initialized
INFO - 2023-07-03 11:58:20 --> Output Class Initialized
INFO - 2023-07-03 11:58:20 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:20 --> Input Class Initialized
INFO - 2023-07-03 11:58:20 --> Language Class Initialized
INFO - 2023-07-03 11:58:20 --> Loader Class Initialized
INFO - 2023-07-03 11:58:20 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:20 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:20 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:20 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:20 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:20 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:20 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:20 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:20 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:20 --> Parser Class Initialized
INFO - 2023-07-03 11:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:20 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:20 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:20 --> Controller Class Initialized
DEBUG - 2023-07-03 11:58:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:20 --> Model Class Initialized
INFO - 2023-07-03 11:58:20 --> Model Class Initialized
INFO - 2023-07-03 11:58:20 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:20 --> Total execution time: 0.0230
ERROR - 2023-07-03 11:58:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:25 --> Config Class Initialized
INFO - 2023-07-03 11:58:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:25 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:25 --> URI Class Initialized
INFO - 2023-07-03 11:58:25 --> Router Class Initialized
INFO - 2023-07-03 11:58:25 --> Output Class Initialized
INFO - 2023-07-03 11:58:25 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:25 --> Input Class Initialized
INFO - 2023-07-03 11:58:25 --> Language Class Initialized
INFO - 2023-07-03 11:58:25 --> Loader Class Initialized
INFO - 2023-07-03 11:58:25 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:25 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:25 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:25 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:25 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:25 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:25 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:25 --> Parser Class Initialized
INFO - 2023-07-03 11:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:25 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:25 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:25 --> Controller Class Initialized
DEBUG - 2023-07-03 11:58:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:25 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:25 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:25 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:25 --> Model Class Initialized
INFO - 2023-07-03 11:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 11:58:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:58:25 --> Model Class Initialized
INFO - 2023-07-03 11:58:25 --> Model Class Initialized
INFO - 2023-07-03 11:58:25 --> Model Class Initialized
INFO - 2023-07-03 11:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:58:25 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:25 --> Total execution time: 0.1421
ERROR - 2023-07-03 11:58:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:26 --> Config Class Initialized
INFO - 2023-07-03 11:58:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:26 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:26 --> URI Class Initialized
INFO - 2023-07-03 11:58:26 --> Router Class Initialized
INFO - 2023-07-03 11:58:26 --> Output Class Initialized
INFO - 2023-07-03 11:58:26 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:26 --> Input Class Initialized
INFO - 2023-07-03 11:58:26 --> Language Class Initialized
INFO - 2023-07-03 11:58:26 --> Loader Class Initialized
INFO - 2023-07-03 11:58:26 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:26 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:26 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:26 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:26 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:26 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:26 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:26 --> Parser Class Initialized
INFO - 2023-07-03 11:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:26 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:26 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:26 --> Controller Class Initialized
DEBUG - 2023-07-03 11:58:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:26 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:26 --> Model Class Initialized
INFO - 2023-07-03 11:58:26 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:26 --> Total execution time: 0.0300
ERROR - 2023-07-03 11:58:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:39 --> Config Class Initialized
INFO - 2023-07-03 11:58:39 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:39 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:39 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:39 --> URI Class Initialized
INFO - 2023-07-03 11:58:39 --> Router Class Initialized
INFO - 2023-07-03 11:58:39 --> Output Class Initialized
INFO - 2023-07-03 11:58:39 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:39 --> Input Class Initialized
INFO - 2023-07-03 11:58:39 --> Language Class Initialized
INFO - 2023-07-03 11:58:39 --> Loader Class Initialized
INFO - 2023-07-03 11:58:39 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:39 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:39 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:39 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:39 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:39 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:39 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:39 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:39 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:39 --> Parser Class Initialized
INFO - 2023-07-03 11:58:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:39 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:39 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:39 --> Controller Class Initialized
DEBUG - 2023-07-03 11:58:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:39 --> Lreturn class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:39 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:39 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:39 --> Model Class Initialized
INFO - 2023-07-03 11:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/return/wastage_list.php
DEBUG - 2023-07-03 11:58:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:58:39 --> Model Class Initialized
INFO - 2023-07-03 11:58:39 --> Model Class Initialized
INFO - 2023-07-03 11:58:39 --> Model Class Initialized
INFO - 2023-07-03 11:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:58:39 --> Final output sent to browser
DEBUG - 2023-07-03 11:58:39 --> Total execution time: 0.1490
ERROR - 2023-07-03 11:58:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:48 --> Config Class Initialized
INFO - 2023-07-03 11:58:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:48 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:48 --> URI Class Initialized
INFO - 2023-07-03 11:58:48 --> Router Class Initialized
INFO - 2023-07-03 11:58:48 --> Output Class Initialized
INFO - 2023-07-03 11:58:48 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:48 --> Input Class Initialized
INFO - 2023-07-03 11:58:48 --> Language Class Initialized
INFO - 2023-07-03 11:58:48 --> Loader Class Initialized
INFO - 2023-07-03 11:58:48 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:48 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:48 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:48 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:48 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:48 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:48 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:48 --> Parser Class Initialized
INFO - 2023-07-03 11:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:48 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:48 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:48 --> Controller Class Initialized
INFO - 2023-07-03 11:58:48 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:48 --> Model Class Initialized
INFO - 2023-07-03 11:58:48 --> Model Class Initialized
INFO - 2023-07-03 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/profit_lose_report.php
DEBUG - 2023-07-03 17:58:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:58:48 --> Model Class Initialized
INFO - 2023-07-03 17:58:48 --> Model Class Initialized
INFO - 2023-07-03 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:58:48 --> Final output sent to browser
DEBUG - 2023-07-03 17:58:48 --> Total execution time: 0.1436
ERROR - 2023-07-03 11:58:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:51 --> Config Class Initialized
INFO - 2023-07-03 11:58:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:51 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:51 --> URI Class Initialized
INFO - 2023-07-03 11:58:51 --> Router Class Initialized
INFO - 2023-07-03 11:58:51 --> Output Class Initialized
INFO - 2023-07-03 11:58:51 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:51 --> Input Class Initialized
INFO - 2023-07-03 11:58:51 --> Language Class Initialized
INFO - 2023-07-03 11:58:51 --> Loader Class Initialized
INFO - 2023-07-03 11:58:51 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:51 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:51 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:51 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:51 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:51 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:51 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:51 --> Parser Class Initialized
INFO - 2023-07-03 11:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:51 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:51 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:51 --> Controller Class Initialized
INFO - 2023-07-03 11:58:51 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:51 --> Model Class Initialized
INFO - 2023-07-03 11:58:51 --> Model Class Initialized
INFO - 2023-07-03 17:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/profit_product_report.php
DEBUG - 2023-07-03 17:58:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:58:51 --> Model Class Initialized
INFO - 2023-07-03 17:58:51 --> Model Class Initialized
INFO - 2023-07-03 17:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:58:51 --> Final output sent to browser
DEBUG - 2023-07-03 17:58:51 --> Total execution time: 0.1412
ERROR - 2023-07-03 11:58:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:54 --> Config Class Initialized
INFO - 2023-07-03 11:58:54 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:54 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:54 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:54 --> URI Class Initialized
INFO - 2023-07-03 11:58:54 --> Router Class Initialized
INFO - 2023-07-03 11:58:54 --> Output Class Initialized
INFO - 2023-07-03 11:58:54 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:54 --> Input Class Initialized
INFO - 2023-07-03 11:58:54 --> Language Class Initialized
INFO - 2023-07-03 11:58:54 --> Loader Class Initialized
INFO - 2023-07-03 11:58:54 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:54 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:54 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:54 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:54 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:54 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:54 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:54 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:54 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:54 --> Parser Class Initialized
INFO - 2023-07-03 11:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:54 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:54 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:54 --> Controller Class Initialized
INFO - 2023-07-03 11:58:54 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:54 --> Model Class Initialized
INFO - 2023-07-03 17:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/product_report.php
DEBUG - 2023-07-03 17:58:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:58:55 --> Model Class Initialized
INFO - 2023-07-03 17:58:55 --> Model Class Initialized
INFO - 2023-07-03 17:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:58:55 --> Final output sent to browser
DEBUG - 2023-07-03 17:58:55 --> Total execution time: 0.1987
ERROR - 2023-07-03 11:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:56 --> Config Class Initialized
INFO - 2023-07-03 11:58:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:56 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:56 --> URI Class Initialized
INFO - 2023-07-03 11:58:56 --> Router Class Initialized
INFO - 2023-07-03 11:58:56 --> Output Class Initialized
INFO - 2023-07-03 11:58:56 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:56 --> Input Class Initialized
INFO - 2023-07-03 11:58:56 --> Language Class Initialized
INFO - 2023-07-03 11:58:56 --> Loader Class Initialized
INFO - 2023-07-03 11:58:56 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:56 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:56 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:56 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:56 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:56 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:56 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:56 --> Parser Class Initialized
INFO - 2023-07-03 11:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:56 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:56 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:56 --> Controller Class Initialized
INFO - 2023-07-03 11:58:56 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:56 --> Model Class Initialized
INFO - 2023-07-03 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/purchase_report.php
DEBUG - 2023-07-03 17:58:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:58:56 --> Model Class Initialized
INFO - 2023-07-03 17:58:56 --> Model Class Initialized
INFO - 2023-07-03 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:58:56 --> Final output sent to browser
DEBUG - 2023-07-03 17:58:56 --> Total execution time: 0.1488
ERROR - 2023-07-03 11:58:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:58:58 --> Config Class Initialized
INFO - 2023-07-03 11:58:58 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:58:58 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:58:58 --> Utf8 Class Initialized
INFO - 2023-07-03 11:58:58 --> URI Class Initialized
INFO - 2023-07-03 11:58:58 --> Router Class Initialized
INFO - 2023-07-03 11:58:58 --> Output Class Initialized
INFO - 2023-07-03 11:58:58 --> Security Class Initialized
DEBUG - 2023-07-03 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:58:58 --> Input Class Initialized
INFO - 2023-07-03 11:58:58 --> Language Class Initialized
INFO - 2023-07-03 11:58:58 --> Loader Class Initialized
INFO - 2023-07-03 11:58:58 --> Helper loaded: url_helper
INFO - 2023-07-03 11:58:58 --> Helper loaded: file_helper
INFO - 2023-07-03 11:58:58 --> Helper loaded: html_helper
INFO - 2023-07-03 11:58:58 --> Helper loaded: text_helper
INFO - 2023-07-03 11:58:58 --> Helper loaded: form_helper
INFO - 2023-07-03 11:58:58 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:58:58 --> Helper loaded: security_helper
INFO - 2023-07-03 11:58:58 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:58:58 --> Database Driver Class Initialized
INFO - 2023-07-03 11:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:58:58 --> Parser Class Initialized
INFO - 2023-07-03 11:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:58:58 --> Pagination Class Initialized
INFO - 2023-07-03 11:58:58 --> Form Validation Class Initialized
INFO - 2023-07-03 11:58:58 --> Controller Class Initialized
INFO - 2023-07-03 11:58:58 --> Model Class Initialized
DEBUG - 2023-07-03 11:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:58:58 --> Model Class Initialized
INFO - 2023-07-03 17:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/purchase_report.php
DEBUG - 2023-07-03 17:58:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:58:58 --> Model Class Initialized
INFO - 2023-07-03 17:58:58 --> Model Class Initialized
INFO - 2023-07-03 17:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:58:58 --> Final output sent to browser
DEBUG - 2023-07-03 17:58:58 --> Total execution time: 0.1444
ERROR - 2023-07-03 11:59:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:59:06 --> Config Class Initialized
INFO - 2023-07-03 11:59:06 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:59:06 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:59:06 --> Utf8 Class Initialized
INFO - 2023-07-03 11:59:06 --> URI Class Initialized
INFO - 2023-07-03 11:59:06 --> Router Class Initialized
INFO - 2023-07-03 11:59:06 --> Output Class Initialized
INFO - 2023-07-03 11:59:06 --> Security Class Initialized
DEBUG - 2023-07-03 11:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:59:06 --> Input Class Initialized
INFO - 2023-07-03 11:59:06 --> Language Class Initialized
INFO - 2023-07-03 11:59:06 --> Loader Class Initialized
INFO - 2023-07-03 11:59:06 --> Helper loaded: url_helper
INFO - 2023-07-03 11:59:06 --> Helper loaded: file_helper
INFO - 2023-07-03 11:59:06 --> Helper loaded: html_helper
INFO - 2023-07-03 11:59:06 --> Helper loaded: text_helper
INFO - 2023-07-03 11:59:06 --> Helper loaded: form_helper
INFO - 2023-07-03 11:59:06 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:59:06 --> Helper loaded: security_helper
INFO - 2023-07-03 11:59:06 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:59:06 --> Database Driver Class Initialized
INFO - 2023-07-03 11:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:59:06 --> Parser Class Initialized
INFO - 2023-07-03 11:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:59:06 --> Pagination Class Initialized
INFO - 2023-07-03 11:59:06 --> Form Validation Class Initialized
INFO - 2023-07-03 11:59:06 --> Controller Class Initialized
INFO - 2023-07-03 11:59:06 --> Model Class Initialized
DEBUG - 2023-07-03 11:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:59:06 --> Model Class Initialized
INFO - 2023-07-03 17:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/purchase_report.php
DEBUG - 2023-07-03 17:59:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:59:06 --> Model Class Initialized
INFO - 2023-07-03 17:59:06 --> Model Class Initialized
INFO - 2023-07-03 17:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:59:07 --> Final output sent to browser
DEBUG - 2023-07-03 17:59:07 --> Total execution time: 0.1556
ERROR - 2023-07-03 11:59:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:59:18 --> Config Class Initialized
INFO - 2023-07-03 11:59:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:59:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:59:18 --> Utf8 Class Initialized
INFO - 2023-07-03 11:59:18 --> URI Class Initialized
INFO - 2023-07-03 11:59:18 --> Router Class Initialized
INFO - 2023-07-03 11:59:18 --> Output Class Initialized
INFO - 2023-07-03 11:59:18 --> Security Class Initialized
DEBUG - 2023-07-03 11:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:59:18 --> Input Class Initialized
INFO - 2023-07-03 11:59:18 --> Language Class Initialized
INFO - 2023-07-03 11:59:18 --> Loader Class Initialized
INFO - 2023-07-03 11:59:18 --> Helper loaded: url_helper
INFO - 2023-07-03 11:59:18 --> Helper loaded: file_helper
INFO - 2023-07-03 11:59:18 --> Helper loaded: html_helper
INFO - 2023-07-03 11:59:18 --> Helper loaded: text_helper
INFO - 2023-07-03 11:59:18 --> Helper loaded: form_helper
INFO - 2023-07-03 11:59:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:59:18 --> Helper loaded: security_helper
INFO - 2023-07-03 11:59:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:59:18 --> Database Driver Class Initialized
INFO - 2023-07-03 11:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:59:18 --> Parser Class Initialized
INFO - 2023-07-03 11:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:59:18 --> Pagination Class Initialized
INFO - 2023-07-03 11:59:18 --> Form Validation Class Initialized
INFO - 2023-07-03 11:59:18 --> Controller Class Initialized
INFO - 2023-07-03 11:59:18 --> Model Class Initialized
DEBUG - 2023-07-03 11:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:59:18 --> Model Class Initialized
INFO - 2023-07-03 17:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/purchase_report.php
DEBUG - 2023-07-03 17:59:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 17:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 17:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 17:59:18 --> Model Class Initialized
INFO - 2023-07-03 17:59:18 --> Model Class Initialized
INFO - 2023-07-03 17:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 17:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 17:59:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 17:59:18 --> Final output sent to browser
DEBUG - 2023-07-03 17:59:18 --> Total execution time: 0.1548
ERROR - 2023-07-03 11:59:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:59:42 --> Config Class Initialized
INFO - 2023-07-03 11:59:42 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:59:42 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:59:42 --> Utf8 Class Initialized
INFO - 2023-07-03 11:59:42 --> URI Class Initialized
INFO - 2023-07-03 11:59:42 --> Router Class Initialized
INFO - 2023-07-03 11:59:42 --> Output Class Initialized
INFO - 2023-07-03 11:59:42 --> Security Class Initialized
DEBUG - 2023-07-03 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:59:42 --> Input Class Initialized
INFO - 2023-07-03 11:59:42 --> Language Class Initialized
INFO - 2023-07-03 11:59:42 --> Loader Class Initialized
INFO - 2023-07-03 11:59:42 --> Helper loaded: url_helper
INFO - 2023-07-03 11:59:42 --> Helper loaded: file_helper
INFO - 2023-07-03 11:59:42 --> Helper loaded: html_helper
INFO - 2023-07-03 11:59:42 --> Helper loaded: text_helper
INFO - 2023-07-03 11:59:42 --> Helper loaded: form_helper
INFO - 2023-07-03 11:59:42 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:59:42 --> Helper loaded: security_helper
INFO - 2023-07-03 11:59:42 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:59:42 --> Database Driver Class Initialized
INFO - 2023-07-03 11:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:59:42 --> Parser Class Initialized
INFO - 2023-07-03 11:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:59:42 --> Pagination Class Initialized
INFO - 2023-07-03 11:59:42 --> Form Validation Class Initialized
INFO - 2023-07-03 11:59:42 --> Controller Class Initialized
INFO - 2023-07-03 11:59:42 --> Model Class Initialized
DEBUG - 2023-07-03 11:59:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:59:42 --> Model Class Initialized
DEBUG - 2023-07-03 11:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:59:42 --> Model Class Initialized
INFO - 2023-07-03 11:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 11:59:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 11:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 11:59:42 --> Model Class Initialized
INFO - 2023-07-03 11:59:42 --> Model Class Initialized
INFO - 2023-07-03 11:59:42 --> Model Class Initialized
INFO - 2023-07-03 11:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 11:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 11:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 11:59:42 --> Final output sent to browser
DEBUG - 2023-07-03 11:59:42 --> Total execution time: 0.1523
ERROR - 2023-07-03 11:59:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 11:59:43 --> Config Class Initialized
INFO - 2023-07-03 11:59:43 --> Hooks Class Initialized
DEBUG - 2023-07-03 11:59:43 --> UTF-8 Support Enabled
INFO - 2023-07-03 11:59:43 --> Utf8 Class Initialized
INFO - 2023-07-03 11:59:43 --> URI Class Initialized
INFO - 2023-07-03 11:59:43 --> Router Class Initialized
INFO - 2023-07-03 11:59:43 --> Output Class Initialized
INFO - 2023-07-03 11:59:43 --> Security Class Initialized
DEBUG - 2023-07-03 11:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 11:59:43 --> Input Class Initialized
INFO - 2023-07-03 11:59:43 --> Language Class Initialized
INFO - 2023-07-03 11:59:43 --> Loader Class Initialized
INFO - 2023-07-03 11:59:43 --> Helper loaded: url_helper
INFO - 2023-07-03 11:59:43 --> Helper loaded: file_helper
INFO - 2023-07-03 11:59:43 --> Helper loaded: html_helper
INFO - 2023-07-03 11:59:43 --> Helper loaded: text_helper
INFO - 2023-07-03 11:59:43 --> Helper loaded: form_helper
INFO - 2023-07-03 11:59:43 --> Helper loaded: lang_helper
INFO - 2023-07-03 11:59:43 --> Helper loaded: security_helper
INFO - 2023-07-03 11:59:43 --> Helper loaded: cookie_helper
INFO - 2023-07-03 11:59:43 --> Database Driver Class Initialized
INFO - 2023-07-03 11:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 11:59:43 --> Parser Class Initialized
INFO - 2023-07-03 11:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 11:59:43 --> Pagination Class Initialized
INFO - 2023-07-03 11:59:43 --> Form Validation Class Initialized
INFO - 2023-07-03 11:59:43 --> Controller Class Initialized
INFO - 2023-07-03 11:59:43 --> Model Class Initialized
DEBUG - 2023-07-03 11:59:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 11:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:59:43 --> Model Class Initialized
DEBUG - 2023-07-03 11:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 11:59:43 --> Model Class Initialized
INFO - 2023-07-03 11:59:43 --> Final output sent to browser
DEBUG - 2023-07-03 11:59:43 --> Total execution time: 0.0537
ERROR - 2023-07-03 12:02:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:02:19 --> Config Class Initialized
INFO - 2023-07-03 12:02:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:02:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:02:19 --> Utf8 Class Initialized
INFO - 2023-07-03 12:02:19 --> URI Class Initialized
INFO - 2023-07-03 12:02:19 --> Router Class Initialized
INFO - 2023-07-03 12:02:19 --> Output Class Initialized
INFO - 2023-07-03 12:02:19 --> Security Class Initialized
DEBUG - 2023-07-03 12:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:02:19 --> Input Class Initialized
INFO - 2023-07-03 12:02:19 --> Language Class Initialized
INFO - 2023-07-03 12:02:19 --> Loader Class Initialized
INFO - 2023-07-03 12:02:19 --> Helper loaded: url_helper
INFO - 2023-07-03 12:02:19 --> Helper loaded: file_helper
INFO - 2023-07-03 12:02:19 --> Helper loaded: html_helper
INFO - 2023-07-03 12:02:19 --> Helper loaded: text_helper
INFO - 2023-07-03 12:02:19 --> Helper loaded: form_helper
INFO - 2023-07-03 12:02:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:02:19 --> Helper loaded: security_helper
INFO - 2023-07-03 12:02:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:02:19 --> Database Driver Class Initialized
INFO - 2023-07-03 12:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:02:19 --> Parser Class Initialized
INFO - 2023-07-03 12:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:02:19 --> Pagination Class Initialized
INFO - 2023-07-03 12:02:19 --> Form Validation Class Initialized
INFO - 2023-07-03 12:02:19 --> Controller Class Initialized
INFO - 2023-07-03 12:02:19 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:19 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:19 --> Model Class Initialized
INFO - 2023-07-03 12:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 12:02:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:02:19 --> Model Class Initialized
INFO - 2023-07-03 12:02:19 --> Model Class Initialized
INFO - 2023-07-03 12:02:19 --> Model Class Initialized
INFO - 2023-07-03 12:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:02:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:02:19 --> Final output sent to browser
DEBUG - 2023-07-03 12:02:19 --> Total execution time: 0.1508
ERROR - 2023-07-03 12:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:02:31 --> Config Class Initialized
INFO - 2023-07-03 12:02:31 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:02:31 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:02:31 --> Utf8 Class Initialized
INFO - 2023-07-03 12:02:31 --> URI Class Initialized
INFO - 2023-07-03 12:02:31 --> Router Class Initialized
INFO - 2023-07-03 12:02:31 --> Output Class Initialized
INFO - 2023-07-03 12:02:31 --> Security Class Initialized
DEBUG - 2023-07-03 12:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:02:31 --> Input Class Initialized
INFO - 2023-07-03 12:02:31 --> Language Class Initialized
INFO - 2023-07-03 12:02:31 --> Loader Class Initialized
INFO - 2023-07-03 12:02:31 --> Helper loaded: url_helper
INFO - 2023-07-03 12:02:31 --> Helper loaded: file_helper
INFO - 2023-07-03 12:02:31 --> Helper loaded: html_helper
INFO - 2023-07-03 12:02:31 --> Helper loaded: text_helper
INFO - 2023-07-03 12:02:31 --> Helper loaded: form_helper
INFO - 2023-07-03 12:02:31 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:02:31 --> Helper loaded: security_helper
INFO - 2023-07-03 12:02:31 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:02:31 --> Database Driver Class Initialized
INFO - 2023-07-03 12:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:02:31 --> Parser Class Initialized
INFO - 2023-07-03 12:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:02:31 --> Pagination Class Initialized
INFO - 2023-07-03 12:02:31 --> Form Validation Class Initialized
INFO - 2023-07-03 12:02:31 --> Controller Class Initialized
INFO - 2023-07-03 12:02:31 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:31 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:31 --> Model Class Initialized
INFO - 2023-07-03 12:02:31 --> Final output sent to browser
DEBUG - 2023-07-03 12:02:31 --> Total execution time: 0.0608
ERROR - 2023-07-03 12:02:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:02:38 --> Config Class Initialized
INFO - 2023-07-03 12:02:38 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:02:38 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:02:38 --> Utf8 Class Initialized
INFO - 2023-07-03 12:02:38 --> URI Class Initialized
DEBUG - 2023-07-03 12:02:38 --> No URI present. Default controller set.
INFO - 2023-07-03 12:02:38 --> Router Class Initialized
INFO - 2023-07-03 12:02:38 --> Output Class Initialized
INFO - 2023-07-03 12:02:38 --> Security Class Initialized
DEBUG - 2023-07-03 12:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:02:38 --> Input Class Initialized
INFO - 2023-07-03 12:02:38 --> Language Class Initialized
INFO - 2023-07-03 12:02:38 --> Loader Class Initialized
INFO - 2023-07-03 12:02:38 --> Helper loaded: url_helper
INFO - 2023-07-03 12:02:38 --> Helper loaded: file_helper
INFO - 2023-07-03 12:02:38 --> Helper loaded: html_helper
INFO - 2023-07-03 12:02:38 --> Helper loaded: text_helper
INFO - 2023-07-03 12:02:38 --> Helper loaded: form_helper
INFO - 2023-07-03 12:02:38 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:02:38 --> Helper loaded: security_helper
INFO - 2023-07-03 12:02:38 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:02:38 --> Database Driver Class Initialized
INFO - 2023-07-03 12:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:02:38 --> Parser Class Initialized
INFO - 2023-07-03 12:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:02:38 --> Pagination Class Initialized
INFO - 2023-07-03 12:02:38 --> Form Validation Class Initialized
INFO - 2023-07-03 12:02:38 --> Controller Class Initialized
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
INFO - 2023-07-03 12:02:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 12:02:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:02:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:02:38 --> Model Class Initialized
INFO - 2023-07-03 12:02:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:02:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:02:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:02:38 --> Final output sent to browser
DEBUG - 2023-07-03 12:02:38 --> Total execution time: 0.1838
ERROR - 2023-07-03 12:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:02:48 --> Config Class Initialized
INFO - 2023-07-03 12:02:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:02:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:02:48 --> Utf8 Class Initialized
INFO - 2023-07-03 12:02:48 --> URI Class Initialized
INFO - 2023-07-03 12:02:48 --> Router Class Initialized
INFO - 2023-07-03 12:02:48 --> Output Class Initialized
INFO - 2023-07-03 12:02:48 --> Security Class Initialized
DEBUG - 2023-07-03 12:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:02:48 --> Input Class Initialized
INFO - 2023-07-03 12:02:48 --> Language Class Initialized
INFO - 2023-07-03 12:02:48 --> Loader Class Initialized
INFO - 2023-07-03 12:02:48 --> Helper loaded: url_helper
INFO - 2023-07-03 12:02:48 --> Helper loaded: file_helper
INFO - 2023-07-03 12:02:48 --> Helper loaded: html_helper
INFO - 2023-07-03 12:02:48 --> Helper loaded: text_helper
INFO - 2023-07-03 12:02:48 --> Helper loaded: form_helper
INFO - 2023-07-03 12:02:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:02:48 --> Helper loaded: security_helper
INFO - 2023-07-03 12:02:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:02:48 --> Database Driver Class Initialized
INFO - 2023-07-03 12:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:02:48 --> Parser Class Initialized
INFO - 2023-07-03 12:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:02:48 --> Pagination Class Initialized
INFO - 2023-07-03 12:02:48 --> Form Validation Class Initialized
INFO - 2023-07-03 12:02:48 --> Controller Class Initialized
INFO - 2023-07-03 12:02:48 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:48 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:48 --> Model Class Initialized
INFO - 2023-07-03 12:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 12:02:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:02:48 --> Model Class Initialized
INFO - 2023-07-03 12:02:48 --> Model Class Initialized
INFO - 2023-07-03 12:02:48 --> Model Class Initialized
INFO - 2023-07-03 12:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:02:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:02:48 --> Final output sent to browser
DEBUG - 2023-07-03 12:02:48 --> Total execution time: 0.1474
ERROR - 2023-07-03 12:02:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:02:49 --> Config Class Initialized
INFO - 2023-07-03 12:02:49 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:02:49 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:02:49 --> Utf8 Class Initialized
INFO - 2023-07-03 12:02:49 --> URI Class Initialized
INFO - 2023-07-03 12:02:49 --> Router Class Initialized
INFO - 2023-07-03 12:02:49 --> Output Class Initialized
INFO - 2023-07-03 12:02:49 --> Security Class Initialized
DEBUG - 2023-07-03 12:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:02:49 --> Input Class Initialized
INFO - 2023-07-03 12:02:49 --> Language Class Initialized
INFO - 2023-07-03 12:02:49 --> Loader Class Initialized
INFO - 2023-07-03 12:02:49 --> Helper loaded: url_helper
INFO - 2023-07-03 12:02:49 --> Helper loaded: file_helper
INFO - 2023-07-03 12:02:49 --> Helper loaded: html_helper
INFO - 2023-07-03 12:02:49 --> Helper loaded: text_helper
INFO - 2023-07-03 12:02:49 --> Helper loaded: form_helper
INFO - 2023-07-03 12:02:49 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:02:49 --> Helper loaded: security_helper
INFO - 2023-07-03 12:02:49 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:02:49 --> Database Driver Class Initialized
INFO - 2023-07-03 12:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:02:49 --> Parser Class Initialized
INFO - 2023-07-03 12:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:02:49 --> Pagination Class Initialized
INFO - 2023-07-03 12:02:49 --> Form Validation Class Initialized
INFO - 2023-07-03 12:02:49 --> Controller Class Initialized
INFO - 2023-07-03 12:02:49 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:49 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:49 --> Model Class Initialized
INFO - 2023-07-03 12:02:49 --> Final output sent to browser
DEBUG - 2023-07-03 12:02:49 --> Total execution time: 0.0518
ERROR - 2023-07-03 12:02:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:02:58 --> Config Class Initialized
INFO - 2023-07-03 12:02:58 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:02:58 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:02:58 --> Utf8 Class Initialized
INFO - 2023-07-03 12:02:58 --> URI Class Initialized
INFO - 2023-07-03 12:02:58 --> Router Class Initialized
INFO - 2023-07-03 12:02:58 --> Output Class Initialized
INFO - 2023-07-03 12:02:58 --> Security Class Initialized
DEBUG - 2023-07-03 12:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:02:58 --> Input Class Initialized
INFO - 2023-07-03 12:02:58 --> Language Class Initialized
INFO - 2023-07-03 12:02:58 --> Loader Class Initialized
INFO - 2023-07-03 12:02:58 --> Helper loaded: url_helper
INFO - 2023-07-03 12:02:58 --> Helper loaded: file_helper
INFO - 2023-07-03 12:02:58 --> Helper loaded: html_helper
INFO - 2023-07-03 12:02:58 --> Helper loaded: text_helper
INFO - 2023-07-03 12:02:58 --> Helper loaded: form_helper
INFO - 2023-07-03 12:02:58 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:02:58 --> Helper loaded: security_helper
INFO - 2023-07-03 12:02:58 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:02:58 --> Database Driver Class Initialized
INFO - 2023-07-03 12:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:02:58 --> Parser Class Initialized
INFO - 2023-07-03 12:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:02:58 --> Pagination Class Initialized
INFO - 2023-07-03 12:02:58 --> Form Validation Class Initialized
INFO - 2023-07-03 12:02:58 --> Controller Class Initialized
INFO - 2023-07-03 12:02:58 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:58 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:58 --> Model Class Initialized
INFO - 2023-07-03 12:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 12:02:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:02:58 --> Model Class Initialized
INFO - 2023-07-03 12:02:58 --> Model Class Initialized
INFO - 2023-07-03 12:02:58 --> Model Class Initialized
INFO - 2023-07-03 12:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:02:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:02:58 --> Final output sent to browser
DEBUG - 2023-07-03 12:02:58 --> Total execution time: 0.1500
ERROR - 2023-07-03 12:02:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:02:59 --> Config Class Initialized
INFO - 2023-07-03 12:02:59 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:02:59 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:02:59 --> Utf8 Class Initialized
INFO - 2023-07-03 12:02:59 --> URI Class Initialized
INFO - 2023-07-03 12:02:59 --> Router Class Initialized
INFO - 2023-07-03 12:02:59 --> Output Class Initialized
INFO - 2023-07-03 12:02:59 --> Security Class Initialized
DEBUG - 2023-07-03 12:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:02:59 --> Input Class Initialized
INFO - 2023-07-03 12:02:59 --> Language Class Initialized
INFO - 2023-07-03 12:02:59 --> Loader Class Initialized
INFO - 2023-07-03 12:02:59 --> Helper loaded: url_helper
INFO - 2023-07-03 12:02:59 --> Helper loaded: file_helper
INFO - 2023-07-03 12:02:59 --> Helper loaded: html_helper
INFO - 2023-07-03 12:02:59 --> Helper loaded: text_helper
INFO - 2023-07-03 12:02:59 --> Helper loaded: form_helper
INFO - 2023-07-03 12:02:59 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:02:59 --> Helper loaded: security_helper
INFO - 2023-07-03 12:02:59 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:02:59 --> Database Driver Class Initialized
INFO - 2023-07-03 12:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:02:59 --> Parser Class Initialized
INFO - 2023-07-03 12:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:02:59 --> Pagination Class Initialized
INFO - 2023-07-03 12:02:59 --> Form Validation Class Initialized
INFO - 2023-07-03 12:02:59 --> Controller Class Initialized
INFO - 2023-07-03 12:02:59 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:59 --> Model Class Initialized
DEBUG - 2023-07-03 12:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:02:59 --> Model Class Initialized
INFO - 2023-07-03 12:02:59 --> Final output sent to browser
DEBUG - 2023-07-03 12:02:59 --> Total execution time: 0.0541
ERROR - 2023-07-03 12:03:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:03:04 --> Config Class Initialized
INFO - 2023-07-03 12:03:04 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:03:04 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:03:04 --> Utf8 Class Initialized
INFO - 2023-07-03 12:03:04 --> URI Class Initialized
INFO - 2023-07-03 12:03:04 --> Router Class Initialized
INFO - 2023-07-03 12:03:04 --> Output Class Initialized
INFO - 2023-07-03 12:03:04 --> Security Class Initialized
DEBUG - 2023-07-03 12:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:03:04 --> Input Class Initialized
INFO - 2023-07-03 12:03:04 --> Language Class Initialized
INFO - 2023-07-03 12:03:04 --> Loader Class Initialized
INFO - 2023-07-03 12:03:04 --> Helper loaded: url_helper
INFO - 2023-07-03 12:03:04 --> Helper loaded: file_helper
INFO - 2023-07-03 12:03:04 --> Helper loaded: html_helper
INFO - 2023-07-03 12:03:04 --> Helper loaded: text_helper
INFO - 2023-07-03 12:03:04 --> Helper loaded: form_helper
INFO - 2023-07-03 12:03:04 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:03:04 --> Helper loaded: security_helper
INFO - 2023-07-03 12:03:04 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:03:04 --> Database Driver Class Initialized
INFO - 2023-07-03 12:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:03:04 --> Parser Class Initialized
INFO - 2023-07-03 12:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:03:04 --> Pagination Class Initialized
INFO - 2023-07-03 12:03:04 --> Form Validation Class Initialized
INFO - 2023-07-03 12:03:04 --> Controller Class Initialized
INFO - 2023-07-03 12:03:04 --> Model Class Initialized
DEBUG - 2023-07-03 12:03:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:04 --> Model Class Initialized
DEBUG - 2023-07-03 12:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:04 --> Model Class Initialized
INFO - 2023-07-03 12:03:04 --> Final output sent to browser
DEBUG - 2023-07-03 12:03:04 --> Total execution time: 0.3629
ERROR - 2023-07-03 12:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:03:20 --> Config Class Initialized
INFO - 2023-07-03 12:03:20 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:03:20 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:03:20 --> Utf8 Class Initialized
INFO - 2023-07-03 12:03:20 --> URI Class Initialized
DEBUG - 2023-07-03 12:03:20 --> No URI present. Default controller set.
INFO - 2023-07-03 12:03:20 --> Router Class Initialized
INFO - 2023-07-03 12:03:20 --> Output Class Initialized
INFO - 2023-07-03 12:03:20 --> Security Class Initialized
DEBUG - 2023-07-03 12:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:03:20 --> Input Class Initialized
INFO - 2023-07-03 12:03:20 --> Language Class Initialized
INFO - 2023-07-03 12:03:20 --> Loader Class Initialized
INFO - 2023-07-03 12:03:20 --> Helper loaded: url_helper
INFO - 2023-07-03 12:03:20 --> Helper loaded: file_helper
INFO - 2023-07-03 12:03:20 --> Helper loaded: html_helper
INFO - 2023-07-03 12:03:20 --> Helper loaded: text_helper
INFO - 2023-07-03 12:03:20 --> Helper loaded: form_helper
INFO - 2023-07-03 12:03:20 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:03:20 --> Helper loaded: security_helper
INFO - 2023-07-03 12:03:20 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:03:20 --> Database Driver Class Initialized
INFO - 2023-07-03 12:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:03:20 --> Parser Class Initialized
INFO - 2023-07-03 12:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:03:20 --> Pagination Class Initialized
INFO - 2023-07-03 12:03:20 --> Form Validation Class Initialized
INFO - 2023-07-03 12:03:20 --> Controller Class Initialized
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
DEBUG - 2023-07-03 12:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
DEBUG - 2023-07-03 12:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
DEBUG - 2023-07-03 12:03:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
INFO - 2023-07-03 12:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 12:03:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:03:20 --> Model Class Initialized
INFO - 2023-07-03 12:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:03:20 --> Final output sent to browser
DEBUG - 2023-07-03 12:03:20 --> Total execution time: 0.1891
ERROR - 2023-07-03 12:03:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:03:43 --> Config Class Initialized
INFO - 2023-07-03 12:03:43 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:03:43 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:03:43 --> Utf8 Class Initialized
INFO - 2023-07-03 12:03:43 --> URI Class Initialized
INFO - 2023-07-03 12:03:43 --> Router Class Initialized
INFO - 2023-07-03 12:03:43 --> Output Class Initialized
INFO - 2023-07-03 12:03:43 --> Security Class Initialized
DEBUG - 2023-07-03 12:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:03:43 --> Input Class Initialized
INFO - 2023-07-03 12:03:43 --> Language Class Initialized
INFO - 2023-07-03 12:03:43 --> Loader Class Initialized
INFO - 2023-07-03 12:03:43 --> Helper loaded: url_helper
INFO - 2023-07-03 12:03:43 --> Helper loaded: file_helper
INFO - 2023-07-03 12:03:43 --> Helper loaded: html_helper
INFO - 2023-07-03 12:03:43 --> Helper loaded: text_helper
INFO - 2023-07-03 12:03:43 --> Helper loaded: form_helper
INFO - 2023-07-03 12:03:43 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:03:43 --> Helper loaded: security_helper
INFO - 2023-07-03 12:03:43 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:03:43 --> Database Driver Class Initialized
INFO - 2023-07-03 12:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:03:43 --> Parser Class Initialized
INFO - 2023-07-03 12:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:03:43 --> Pagination Class Initialized
INFO - 2023-07-03 12:03:43 --> Form Validation Class Initialized
INFO - 2023-07-03 12:03:43 --> Controller Class Initialized
DEBUG - 2023-07-03 12:03:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:43 --> Model Class Initialized
INFO - 2023-07-03 12:03:43 --> Model Class Initialized
INFO - 2023-07-03 18:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/customer_search.php
DEBUG - 2023-07-03 18:03:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 18:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 18:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 18:03:43 --> Model Class Initialized
INFO - 2023-07-03 18:03:43 --> Model Class Initialized
INFO - 2023-07-03 18:03:43 --> Model Class Initialized
INFO - 2023-07-03 18:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 18:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 18:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 18:03:43 --> Final output sent to browser
DEBUG - 2023-07-03 18:03:43 --> Total execution time: 0.1448
ERROR - 2023-07-03 12:03:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:03:55 --> Config Class Initialized
INFO - 2023-07-03 12:03:55 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:03:55 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:03:55 --> Utf8 Class Initialized
INFO - 2023-07-03 12:03:55 --> URI Class Initialized
INFO - 2023-07-03 12:03:55 --> Router Class Initialized
INFO - 2023-07-03 12:03:55 --> Output Class Initialized
INFO - 2023-07-03 12:03:55 --> Security Class Initialized
DEBUG - 2023-07-03 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:03:55 --> Input Class Initialized
INFO - 2023-07-03 12:03:55 --> Language Class Initialized
INFO - 2023-07-03 12:03:55 --> Loader Class Initialized
INFO - 2023-07-03 12:03:55 --> Helper loaded: url_helper
INFO - 2023-07-03 12:03:55 --> Helper loaded: file_helper
INFO - 2023-07-03 12:03:55 --> Helper loaded: html_helper
INFO - 2023-07-03 12:03:55 --> Helper loaded: text_helper
INFO - 2023-07-03 12:03:55 --> Helper loaded: form_helper
INFO - 2023-07-03 12:03:55 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:03:55 --> Helper loaded: security_helper
INFO - 2023-07-03 12:03:55 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:03:55 --> Database Driver Class Initialized
INFO - 2023-07-03 12:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:03:55 --> Parser Class Initialized
INFO - 2023-07-03 12:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:03:55 --> Pagination Class Initialized
INFO - 2023-07-03 12:03:55 --> Form Validation Class Initialized
INFO - 2023-07-03 12:03:55 --> Controller Class Initialized
DEBUG - 2023-07-03 12:03:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:03:55 --> Model Class Initialized
INFO - 2023-07-03 12:03:55 --> Model Class Initialized
INFO - 2023-07-03 18:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/customer_search.php
DEBUG - 2023-07-03 18:03:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 18:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 18:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 18:03:55 --> Model Class Initialized
INFO - 2023-07-03 18:03:55 --> Model Class Initialized
INFO - 2023-07-03 18:03:55 --> Model Class Initialized
INFO - 2023-07-03 18:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 18:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 18:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 18:03:56 --> Final output sent to browser
DEBUG - 2023-07-03 18:03:56 --> Total execution time: 0.1573
ERROR - 2023-07-03 12:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:16 --> Config Class Initialized
INFO - 2023-07-03 12:04:16 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:16 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:16 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:16 --> URI Class Initialized
INFO - 2023-07-03 12:04:16 --> Router Class Initialized
INFO - 2023-07-03 12:04:16 --> Output Class Initialized
INFO - 2023-07-03 12:04:16 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:16 --> Input Class Initialized
INFO - 2023-07-03 12:04:16 --> Language Class Initialized
INFO - 2023-07-03 12:04:16 --> Loader Class Initialized
INFO - 2023-07-03 12:04:16 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:16 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:16 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:16 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:16 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:16 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:16 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:16 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:16 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:16 --> Parser Class Initialized
INFO - 2023-07-03 12:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:16 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:16 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:16 --> Controller Class Initialized
DEBUG - 2023-07-03 12:04:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:16 --> Model Class Initialized
INFO - 2023-07-03 12:04:16 --> Model Class Initialized
INFO - 2023-07-03 18:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/customer_search.php
DEBUG - 2023-07-03 18:04:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 18:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 18:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 18:04:16 --> Model Class Initialized
INFO - 2023-07-03 18:04:16 --> Model Class Initialized
INFO - 2023-07-03 18:04:16 --> Model Class Initialized
INFO - 2023-07-03 18:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 18:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 18:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 18:04:16 --> Final output sent to browser
DEBUG - 2023-07-03 18:04:16 --> Total execution time: 0.1499
ERROR - 2023-07-03 12:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:21 --> Config Class Initialized
INFO - 2023-07-03 12:04:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:21 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:21 --> URI Class Initialized
INFO - 2023-07-03 12:04:21 --> Router Class Initialized
INFO - 2023-07-03 12:04:21 --> Output Class Initialized
INFO - 2023-07-03 12:04:21 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:21 --> Input Class Initialized
INFO - 2023-07-03 12:04:21 --> Language Class Initialized
INFO - 2023-07-03 12:04:21 --> Loader Class Initialized
INFO - 2023-07-03 12:04:21 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:21 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:21 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:21 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:21 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:21 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:21 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:21 --> Parser Class Initialized
INFO - 2023-07-03 12:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:21 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:21 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:21 --> Controller Class Initialized
DEBUG - 2023-07-03 12:04:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:21 --> Model Class Initialized
INFO - 2023-07-03 12:04:21 --> Model Class Initialized
INFO - 2023-07-03 18:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/purchase_search.php
DEBUG - 2023-07-03 18:04:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 18:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 18:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 18:04:21 --> Model Class Initialized
INFO - 2023-07-03 18:04:21 --> Model Class Initialized
INFO - 2023-07-03 18:04:21 --> Model Class Initialized
INFO - 2023-07-03 18:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 18:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 18:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 18:04:21 --> Final output sent to browser
DEBUG - 2023-07-03 18:04:21 --> Total execution time: 0.1434
ERROR - 2023-07-03 12:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:28 --> Config Class Initialized
INFO - 2023-07-03 12:04:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:28 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:28 --> URI Class Initialized
INFO - 2023-07-03 12:04:28 --> Router Class Initialized
INFO - 2023-07-03 12:04:28 --> Output Class Initialized
INFO - 2023-07-03 12:04:28 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:28 --> Input Class Initialized
INFO - 2023-07-03 12:04:28 --> Language Class Initialized
INFO - 2023-07-03 12:04:28 --> Loader Class Initialized
INFO - 2023-07-03 12:04:28 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:28 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:28 --> Parser Class Initialized
INFO - 2023-07-03 12:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:28 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:28 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:28 --> Controller Class Initialized
INFO - 2023-07-03 12:04:28 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:28 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:28 --> Model Class Initialized
INFO - 2023-07-03 12:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 12:04:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:04:28 --> Model Class Initialized
INFO - 2023-07-03 12:04:28 --> Model Class Initialized
INFO - 2023-07-03 12:04:28 --> Model Class Initialized
INFO - 2023-07-03 12:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:04:28 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:28 --> Total execution time: 0.1497
ERROR - 2023-07-03 12:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:28 --> Config Class Initialized
INFO - 2023-07-03 12:04:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:28 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:28 --> URI Class Initialized
INFO - 2023-07-03 12:04:28 --> Router Class Initialized
INFO - 2023-07-03 12:04:28 --> Output Class Initialized
INFO - 2023-07-03 12:04:28 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:28 --> Input Class Initialized
INFO - 2023-07-03 12:04:28 --> Language Class Initialized
INFO - 2023-07-03 12:04:28 --> Loader Class Initialized
INFO - 2023-07-03 12:04:28 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:28 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:29 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:29 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:29 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:29 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:29 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:29 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:29 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:29 --> Parser Class Initialized
INFO - 2023-07-03 12:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:29 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:29 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:29 --> Controller Class Initialized
INFO - 2023-07-03 12:04:29 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:29 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:29 --> Model Class Initialized
INFO - 2023-07-03 12:04:29 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:29 --> Total execution time: 0.0541
ERROR - 2023-07-03 12:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:45 --> Config Class Initialized
INFO - 2023-07-03 12:04:45 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:45 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:45 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:45 --> URI Class Initialized
INFO - 2023-07-03 12:04:45 --> Router Class Initialized
INFO - 2023-07-03 12:04:45 --> Output Class Initialized
INFO - 2023-07-03 12:04:45 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:45 --> Input Class Initialized
INFO - 2023-07-03 12:04:45 --> Language Class Initialized
INFO - 2023-07-03 12:04:45 --> Loader Class Initialized
INFO - 2023-07-03 12:04:45 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:45 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:45 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:45 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:45 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:45 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:45 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:45 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:45 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:45 --> Parser Class Initialized
INFO - 2023-07-03 12:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:45 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:45 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:45 --> Controller Class Initialized
INFO - 2023-07-03 12:04:45 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:45 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:45 --> Model Class Initialized
INFO - 2023-07-03 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 12:04:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:04:45 --> Model Class Initialized
INFO - 2023-07-03 12:04:45 --> Model Class Initialized
INFO - 2023-07-03 12:04:45 --> Model Class Initialized
INFO - 2023-07-03 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:04:45 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:45 --> Total execution time: 0.0769
ERROR - 2023-07-03 12:04:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:46 --> Config Class Initialized
INFO - 2023-07-03 12:04:46 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:46 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:46 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:46 --> URI Class Initialized
INFO - 2023-07-03 12:04:46 --> Router Class Initialized
INFO - 2023-07-03 12:04:46 --> Output Class Initialized
INFO - 2023-07-03 12:04:46 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:46 --> Input Class Initialized
INFO - 2023-07-03 12:04:46 --> Language Class Initialized
INFO - 2023-07-03 12:04:46 --> Loader Class Initialized
INFO - 2023-07-03 12:04:46 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:46 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:46 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:46 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:46 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:46 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:46 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:46 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:46 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:46 --> Parser Class Initialized
INFO - 2023-07-03 12:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:46 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:46 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:46 --> Controller Class Initialized
INFO - 2023-07-03 12:04:46 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:46 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:46 --> Model Class Initialized
INFO - 2023-07-03 12:04:46 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:46 --> Total execution time: 0.0431
ERROR - 2023-07-03 12:04:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:52 --> Config Class Initialized
INFO - 2023-07-03 12:04:52 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:52 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:52 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:52 --> URI Class Initialized
INFO - 2023-07-03 12:04:52 --> Router Class Initialized
INFO - 2023-07-03 12:04:52 --> Output Class Initialized
INFO - 2023-07-03 12:04:52 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:52 --> Input Class Initialized
INFO - 2023-07-03 12:04:52 --> Language Class Initialized
INFO - 2023-07-03 12:04:52 --> Loader Class Initialized
INFO - 2023-07-03 12:04:52 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:52 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:52 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:52 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:52 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:52 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:52 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:52 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:52 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:52 --> Parser Class Initialized
INFO - 2023-07-03 12:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:52 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:52 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:52 --> Controller Class Initialized
INFO - 2023-07-03 12:04:52 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:52 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:52 --> Model Class Initialized
INFO - 2023-07-03 12:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 12:04:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:04:52 --> Model Class Initialized
INFO - 2023-07-03 12:04:52 --> Model Class Initialized
INFO - 2023-07-03 12:04:52 --> Model Class Initialized
INFO - 2023-07-03 12:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:04:52 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:52 --> Total execution time: 0.0776
ERROR - 2023-07-03 12:04:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:53 --> Config Class Initialized
INFO - 2023-07-03 12:04:53 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:53 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:53 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:53 --> URI Class Initialized
INFO - 2023-07-03 12:04:53 --> Router Class Initialized
INFO - 2023-07-03 12:04:53 --> Output Class Initialized
INFO - 2023-07-03 12:04:53 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:53 --> Input Class Initialized
INFO - 2023-07-03 12:04:53 --> Language Class Initialized
INFO - 2023-07-03 12:04:53 --> Loader Class Initialized
INFO - 2023-07-03 12:04:53 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:53 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:53 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:53 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:53 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:53 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:53 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:53 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:53 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:53 --> Parser Class Initialized
INFO - 2023-07-03 12:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:53 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:53 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:53 --> Controller Class Initialized
INFO - 2023-07-03 12:04:53 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:53 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:53 --> Model Class Initialized
INFO - 2023-07-03 12:04:53 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:53 --> Total execution time: 0.0510
ERROR - 2023-07-03 12:04:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:57 --> Config Class Initialized
INFO - 2023-07-03 12:04:57 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:57 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:57 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:57 --> URI Class Initialized
INFO - 2023-07-03 12:04:57 --> Router Class Initialized
INFO - 2023-07-03 12:04:57 --> Output Class Initialized
INFO - 2023-07-03 12:04:57 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:57 --> Input Class Initialized
INFO - 2023-07-03 12:04:57 --> Language Class Initialized
INFO - 2023-07-03 12:04:57 --> Loader Class Initialized
INFO - 2023-07-03 12:04:57 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:57 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:57 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:57 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:57 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:57 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:57 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:57 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:57 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:57 --> Parser Class Initialized
INFO - 2023-07-03 12:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:57 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:57 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:57 --> Controller Class Initialized
INFO - 2023-07-03 12:04:57 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:57 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:57 --> Model Class Initialized
INFO - 2023-07-03 12:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 12:04:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:04:57 --> Model Class Initialized
INFO - 2023-07-03 12:04:57 --> Model Class Initialized
INFO - 2023-07-03 12:04:57 --> Model Class Initialized
INFO - 2023-07-03 12:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:04:57 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:57 --> Total execution time: 0.0779
ERROR - 2023-07-03 12:04:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:04:58 --> Config Class Initialized
INFO - 2023-07-03 12:04:58 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:04:58 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:04:58 --> Utf8 Class Initialized
INFO - 2023-07-03 12:04:58 --> URI Class Initialized
INFO - 2023-07-03 12:04:58 --> Router Class Initialized
INFO - 2023-07-03 12:04:58 --> Output Class Initialized
INFO - 2023-07-03 12:04:58 --> Security Class Initialized
DEBUG - 2023-07-03 12:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:04:58 --> Input Class Initialized
INFO - 2023-07-03 12:04:58 --> Language Class Initialized
INFO - 2023-07-03 12:04:58 --> Loader Class Initialized
INFO - 2023-07-03 12:04:58 --> Helper loaded: url_helper
INFO - 2023-07-03 12:04:58 --> Helper loaded: file_helper
INFO - 2023-07-03 12:04:58 --> Helper loaded: html_helper
INFO - 2023-07-03 12:04:58 --> Helper loaded: text_helper
INFO - 2023-07-03 12:04:58 --> Helper loaded: form_helper
INFO - 2023-07-03 12:04:58 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:04:58 --> Helper loaded: security_helper
INFO - 2023-07-03 12:04:58 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:04:58 --> Database Driver Class Initialized
INFO - 2023-07-03 12:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:04:58 --> Parser Class Initialized
INFO - 2023-07-03 12:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:04:58 --> Pagination Class Initialized
INFO - 2023-07-03 12:04:58 --> Form Validation Class Initialized
INFO - 2023-07-03 12:04:58 --> Controller Class Initialized
INFO - 2023-07-03 12:04:58 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:58 --> Model Class Initialized
DEBUG - 2023-07-03 12:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:04:58 --> Model Class Initialized
INFO - 2023-07-03 12:04:58 --> Final output sent to browser
DEBUG - 2023-07-03 12:04:58 --> Total execution time: 0.0431
ERROR - 2023-07-03 12:05:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:00 --> Config Class Initialized
INFO - 2023-07-03 12:05:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:00 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:00 --> URI Class Initialized
INFO - 2023-07-03 12:05:00 --> Router Class Initialized
INFO - 2023-07-03 12:05:00 --> Output Class Initialized
INFO - 2023-07-03 12:05:00 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:00 --> Input Class Initialized
INFO - 2023-07-03 12:05:00 --> Language Class Initialized
INFO - 2023-07-03 12:05:00 --> Loader Class Initialized
INFO - 2023-07-03 12:05:00 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:00 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:00 --> Parser Class Initialized
INFO - 2023-07-03 12:05:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:00 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:00 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:00 --> Controller Class Initialized
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
INFO - 2023-07-03 12:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 12:05:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
INFO - 2023-07-03 12:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:05:00 --> Final output sent to browser
DEBUG - 2023-07-03 12:05:00 --> Total execution time: 0.1527
ERROR - 2023-07-03 12:05:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:00 --> Config Class Initialized
INFO - 2023-07-03 12:05:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:00 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:00 --> URI Class Initialized
INFO - 2023-07-03 12:05:00 --> Router Class Initialized
INFO - 2023-07-03 12:05:00 --> Output Class Initialized
INFO - 2023-07-03 12:05:00 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:00 --> Input Class Initialized
INFO - 2023-07-03 12:05:00 --> Language Class Initialized
INFO - 2023-07-03 12:05:00 --> Loader Class Initialized
INFO - 2023-07-03 12:05:00 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:00 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:00 --> Parser Class Initialized
INFO - 2023-07-03 12:05:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:00 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:00 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:00 --> Controller Class Initialized
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:00 --> Model Class Initialized
INFO - 2023-07-03 12:05:00 --> Final output sent to browser
DEBUG - 2023-07-03 12:05:00 --> Total execution time: 0.0674
ERROR - 2023-07-03 12:05:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:21 --> Config Class Initialized
INFO - 2023-07-03 12:05:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:21 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:21 --> URI Class Initialized
INFO - 2023-07-03 12:05:21 --> Router Class Initialized
INFO - 2023-07-03 12:05:21 --> Output Class Initialized
INFO - 2023-07-03 12:05:21 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:21 --> Input Class Initialized
INFO - 2023-07-03 12:05:21 --> Language Class Initialized
INFO - 2023-07-03 12:05:21 --> Loader Class Initialized
INFO - 2023-07-03 12:05:21 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:21 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:21 --> Parser Class Initialized
INFO - 2023-07-03 12:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:21 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:21 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:21 --> Controller Class Initialized
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
INFO - 2023-07-03 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 12:05:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
INFO - 2023-07-03 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:05:21 --> Final output sent to browser
DEBUG - 2023-07-03 12:05:21 --> Total execution time: 0.0867
ERROR - 2023-07-03 12:05:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:21 --> Config Class Initialized
INFO - 2023-07-03 12:05:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:21 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:21 --> URI Class Initialized
INFO - 2023-07-03 12:05:21 --> Router Class Initialized
INFO - 2023-07-03 12:05:21 --> Output Class Initialized
INFO - 2023-07-03 12:05:21 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:21 --> Input Class Initialized
INFO - 2023-07-03 12:05:21 --> Language Class Initialized
INFO - 2023-07-03 12:05:21 --> Loader Class Initialized
INFO - 2023-07-03 12:05:21 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:21 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:21 --> Parser Class Initialized
INFO - 2023-07-03 12:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:21 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:21 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:21 --> Controller Class Initialized
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:21 --> Model Class Initialized
INFO - 2023-07-03 12:05:21 --> Final output sent to browser
DEBUG - 2023-07-03 12:05:21 --> Total execution time: 0.0400
ERROR - 2023-07-03 12:05:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:24 --> Config Class Initialized
INFO - 2023-07-03 12:05:24 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:24 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:24 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:24 --> URI Class Initialized
DEBUG - 2023-07-03 12:05:24 --> No URI present. Default controller set.
INFO - 2023-07-03 12:05:24 --> Router Class Initialized
INFO - 2023-07-03 12:05:24 --> Output Class Initialized
INFO - 2023-07-03 12:05:24 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:24 --> Input Class Initialized
INFO - 2023-07-03 12:05:24 --> Language Class Initialized
INFO - 2023-07-03 12:05:24 --> Loader Class Initialized
INFO - 2023-07-03 12:05:24 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:24 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:24 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:24 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:24 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:24 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:24 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:24 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:24 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:24 --> Parser Class Initialized
INFO - 2023-07-03 12:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:24 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:24 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:24 --> Controller Class Initialized
INFO - 2023-07-03 12:05:24 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 12:05:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:25 --> Config Class Initialized
INFO - 2023-07-03 12:05:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:25 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:25 --> URI Class Initialized
INFO - 2023-07-03 12:05:25 --> Router Class Initialized
INFO - 2023-07-03 12:05:25 --> Output Class Initialized
INFO - 2023-07-03 12:05:25 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:25 --> Input Class Initialized
INFO - 2023-07-03 12:05:25 --> Language Class Initialized
INFO - 2023-07-03 12:05:25 --> Loader Class Initialized
INFO - 2023-07-03 12:05:25 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:25 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:25 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:25 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:25 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:25 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:25 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:25 --> Parser Class Initialized
INFO - 2023-07-03 12:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:25 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:25 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:25 --> Controller Class Initialized
INFO - 2023-07-03 12:05:25 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 12:05:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:05:25 --> Model Class Initialized
INFO - 2023-07-03 12:05:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:05:25 --> Final output sent to browser
DEBUG - 2023-07-03 12:05:25 --> Total execution time: 0.0284
ERROR - 2023-07-03 12:05:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:53 --> Config Class Initialized
INFO - 2023-07-03 12:05:53 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:53 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:53 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:53 --> URI Class Initialized
INFO - 2023-07-03 12:05:53 --> Router Class Initialized
INFO - 2023-07-03 12:05:53 --> Output Class Initialized
INFO - 2023-07-03 12:05:53 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:53 --> Input Class Initialized
INFO - 2023-07-03 12:05:53 --> Language Class Initialized
INFO - 2023-07-03 12:05:53 --> Loader Class Initialized
INFO - 2023-07-03 12:05:53 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:53 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:53 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:53 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:53 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:53 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:53 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:53 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:53 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:53 --> Parser Class Initialized
INFO - 2023-07-03 12:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:53 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:53 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:53 --> Controller Class Initialized
DEBUG - 2023-07-03 12:05:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:53 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:53 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:53 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:53 --> Model Class Initialized
INFO - 2023-07-03 12:05:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 12:05:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:05:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:05:53 --> Model Class Initialized
INFO - 2023-07-03 12:05:53 --> Model Class Initialized
INFO - 2023-07-03 12:05:53 --> Model Class Initialized
INFO - 2023-07-03 12:05:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:05:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:05:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:05:53 --> Final output sent to browser
DEBUG - 2023-07-03 12:05:53 --> Total execution time: 0.1420
ERROR - 2023-07-03 12:05:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:05:54 --> Config Class Initialized
INFO - 2023-07-03 12:05:54 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:05:54 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:05:54 --> Utf8 Class Initialized
INFO - 2023-07-03 12:05:54 --> URI Class Initialized
INFO - 2023-07-03 12:05:54 --> Router Class Initialized
INFO - 2023-07-03 12:05:54 --> Output Class Initialized
INFO - 2023-07-03 12:05:54 --> Security Class Initialized
DEBUG - 2023-07-03 12:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:05:54 --> Input Class Initialized
INFO - 2023-07-03 12:05:54 --> Language Class Initialized
INFO - 2023-07-03 12:05:54 --> Loader Class Initialized
INFO - 2023-07-03 12:05:54 --> Helper loaded: url_helper
INFO - 2023-07-03 12:05:54 --> Helper loaded: file_helper
INFO - 2023-07-03 12:05:54 --> Helper loaded: html_helper
INFO - 2023-07-03 12:05:54 --> Helper loaded: text_helper
INFO - 2023-07-03 12:05:54 --> Helper loaded: form_helper
INFO - 2023-07-03 12:05:54 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:05:54 --> Helper loaded: security_helper
INFO - 2023-07-03 12:05:54 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:05:54 --> Database Driver Class Initialized
INFO - 2023-07-03 12:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:05:54 --> Parser Class Initialized
INFO - 2023-07-03 12:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:05:54 --> Pagination Class Initialized
INFO - 2023-07-03 12:05:54 --> Form Validation Class Initialized
INFO - 2023-07-03 12:05:54 --> Controller Class Initialized
DEBUG - 2023-07-03 12:05:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:54 --> Model Class Initialized
DEBUG - 2023-07-03 12:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:05:54 --> Model Class Initialized
INFO - 2023-07-03 12:05:54 --> Final output sent to browser
DEBUG - 2023-07-03 12:05:54 --> Total execution time: 0.0310
ERROR - 2023-07-03 12:06:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:06:08 --> Config Class Initialized
INFO - 2023-07-03 12:06:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:06:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:06:08 --> Utf8 Class Initialized
INFO - 2023-07-03 12:06:08 --> URI Class Initialized
INFO - 2023-07-03 12:06:08 --> Router Class Initialized
INFO - 2023-07-03 12:06:08 --> Output Class Initialized
INFO - 2023-07-03 12:06:08 --> Security Class Initialized
DEBUG - 2023-07-03 12:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:06:08 --> Input Class Initialized
INFO - 2023-07-03 12:06:08 --> Language Class Initialized
INFO - 2023-07-03 12:06:08 --> Loader Class Initialized
INFO - 2023-07-03 12:06:08 --> Helper loaded: url_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: file_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: html_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: text_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: form_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: security_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:06:08 --> Database Driver Class Initialized
INFO - 2023-07-03 12:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:06:08 --> Parser Class Initialized
INFO - 2023-07-03 12:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:06:08 --> Pagination Class Initialized
INFO - 2023-07-03 12:06:08 --> Form Validation Class Initialized
INFO - 2023-07-03 12:06:08 --> Controller Class Initialized
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:06:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
INFO - 2023-07-03 12:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 12:06:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
INFO - 2023-07-03 12:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:06:08 --> Final output sent to browser
DEBUG - 2023-07-03 12:06:08 --> Total execution time: 0.1568
ERROR - 2023-07-03 12:06:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:06:08 --> Config Class Initialized
INFO - 2023-07-03 12:06:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:06:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:06:08 --> Utf8 Class Initialized
INFO - 2023-07-03 12:06:08 --> URI Class Initialized
INFO - 2023-07-03 12:06:08 --> Router Class Initialized
INFO - 2023-07-03 12:06:08 --> Output Class Initialized
INFO - 2023-07-03 12:06:08 --> Security Class Initialized
DEBUG - 2023-07-03 12:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:06:08 --> Input Class Initialized
INFO - 2023-07-03 12:06:08 --> Language Class Initialized
INFO - 2023-07-03 12:06:08 --> Loader Class Initialized
INFO - 2023-07-03 12:06:08 --> Helper loaded: url_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: file_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: html_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: text_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: form_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: security_helper
INFO - 2023-07-03 12:06:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:06:08 --> Database Driver Class Initialized
INFO - 2023-07-03 12:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:06:08 --> Parser Class Initialized
INFO - 2023-07-03 12:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:06:08 --> Pagination Class Initialized
INFO - 2023-07-03 12:06:08 --> Form Validation Class Initialized
INFO - 2023-07-03 12:06:08 --> Controller Class Initialized
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:06:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:08 --> Model Class Initialized
INFO - 2023-07-03 12:06:08 --> Final output sent to browser
DEBUG - 2023-07-03 12:06:08 --> Total execution time: 0.0522
ERROR - 2023-07-03 12:06:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:06:12 --> Config Class Initialized
INFO - 2023-07-03 12:06:12 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:06:12 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:06:12 --> Utf8 Class Initialized
INFO - 2023-07-03 12:06:12 --> URI Class Initialized
DEBUG - 2023-07-03 12:06:12 --> No URI present. Default controller set.
INFO - 2023-07-03 12:06:12 --> Router Class Initialized
INFO - 2023-07-03 12:06:13 --> Output Class Initialized
INFO - 2023-07-03 12:06:13 --> Security Class Initialized
DEBUG - 2023-07-03 12:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:06:13 --> Input Class Initialized
INFO - 2023-07-03 12:06:13 --> Language Class Initialized
INFO - 2023-07-03 12:06:13 --> Loader Class Initialized
INFO - 2023-07-03 12:06:13 --> Helper loaded: url_helper
INFO - 2023-07-03 12:06:13 --> Helper loaded: file_helper
INFO - 2023-07-03 12:06:13 --> Helper loaded: html_helper
INFO - 2023-07-03 12:06:13 --> Helper loaded: text_helper
INFO - 2023-07-03 12:06:13 --> Helper loaded: form_helper
INFO - 2023-07-03 12:06:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:06:13 --> Helper loaded: security_helper
INFO - 2023-07-03 12:06:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:06:13 --> Database Driver Class Initialized
INFO - 2023-07-03 12:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:06:13 --> Parser Class Initialized
INFO - 2023-07-03 12:06:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:06:13 --> Pagination Class Initialized
INFO - 2023-07-03 12:06:13 --> Form Validation Class Initialized
INFO - 2023-07-03 12:06:13 --> Controller Class Initialized
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
DEBUG - 2023-07-03 12:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
DEBUG - 2023-07-03 12:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
DEBUG - 2023-07-03 12:06:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
INFO - 2023-07-03 12:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 12:06:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:06:13 --> Model Class Initialized
INFO - 2023-07-03 12:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:06:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:06:13 --> Final output sent to browser
DEBUG - 2023-07-03 12:06:13 --> Total execution time: 0.1903
ERROR - 2023-07-03 12:06:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:06:49 --> Config Class Initialized
INFO - 2023-07-03 12:06:49 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:06:49 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:06:49 --> Utf8 Class Initialized
INFO - 2023-07-03 12:06:49 --> URI Class Initialized
INFO - 2023-07-03 12:06:49 --> Router Class Initialized
INFO - 2023-07-03 12:06:49 --> Output Class Initialized
INFO - 2023-07-03 12:06:49 --> Security Class Initialized
DEBUG - 2023-07-03 12:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:06:49 --> Input Class Initialized
INFO - 2023-07-03 12:06:49 --> Language Class Initialized
INFO - 2023-07-03 12:06:49 --> Loader Class Initialized
INFO - 2023-07-03 12:06:49 --> Helper loaded: url_helper
INFO - 2023-07-03 12:06:49 --> Helper loaded: file_helper
INFO - 2023-07-03 12:06:49 --> Helper loaded: html_helper
INFO - 2023-07-03 12:06:49 --> Helper loaded: text_helper
INFO - 2023-07-03 12:06:49 --> Helper loaded: form_helper
INFO - 2023-07-03 12:06:49 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:06:49 --> Helper loaded: security_helper
INFO - 2023-07-03 12:06:49 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:06:49 --> Database Driver Class Initialized
INFO - 2023-07-03 12:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:06:49 --> Parser Class Initialized
INFO - 2023-07-03 12:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:06:49 --> Pagination Class Initialized
INFO - 2023-07-03 12:06:49 --> Form Validation Class Initialized
INFO - 2023-07-03 12:06:49 --> Controller Class Initialized
DEBUG - 2023-07-03 12:06:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:49 --> Model Class Initialized
INFO - 2023-07-03 12:06:49 --> Model Class Initialized
INFO - 2023-07-03 12:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-07-03 12:06:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:06:49 --> Model Class Initialized
INFO - 2023-07-03 12:06:49 --> Model Class Initialized
INFO - 2023-07-03 12:06:49 --> Model Class Initialized
INFO - 2023-07-03 12:06:49 --> Model Class Initialized
INFO - 2023-07-03 12:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:06:49 --> Final output sent to browser
DEBUG - 2023-07-03 12:06:49 --> Total execution time: 0.1438
ERROR - 2023-07-03 12:08:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:08:17 --> Config Class Initialized
INFO - 2023-07-03 12:08:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:08:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:08:17 --> Utf8 Class Initialized
INFO - 2023-07-03 12:08:17 --> URI Class Initialized
INFO - 2023-07-03 12:08:17 --> Router Class Initialized
INFO - 2023-07-03 12:08:17 --> Output Class Initialized
INFO - 2023-07-03 12:08:17 --> Security Class Initialized
DEBUG - 2023-07-03 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:08:17 --> Input Class Initialized
INFO - 2023-07-03 12:08:17 --> Language Class Initialized
INFO - 2023-07-03 12:08:17 --> Loader Class Initialized
INFO - 2023-07-03 12:08:17 --> Helper loaded: url_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: file_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: html_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: text_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: form_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: security_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:08:17 --> Database Driver Class Initialized
INFO - 2023-07-03 12:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:08:17 --> Parser Class Initialized
INFO - 2023-07-03 12:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:08:17 --> Pagination Class Initialized
INFO - 2023-07-03 12:08:17 --> Form Validation Class Initialized
INFO - 2023-07-03 12:08:17 --> Controller Class Initialized
DEBUG - 2023-07-03 12:08:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:17 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
INFO - 2023-07-03 12:08:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 12:08:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:08:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
INFO - 2023-07-03 12:08:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:08:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:08:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:08:17 --> Final output sent to browser
DEBUG - 2023-07-03 12:08:17 --> Total execution time: 0.1482
ERROR - 2023-07-03 12:08:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:08:17 --> Config Class Initialized
INFO - 2023-07-03 12:08:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:08:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:08:17 --> Utf8 Class Initialized
INFO - 2023-07-03 12:08:17 --> URI Class Initialized
INFO - 2023-07-03 12:08:17 --> Router Class Initialized
INFO - 2023-07-03 12:08:17 --> Output Class Initialized
INFO - 2023-07-03 12:08:17 --> Security Class Initialized
DEBUG - 2023-07-03 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:08:17 --> Input Class Initialized
INFO - 2023-07-03 12:08:17 --> Language Class Initialized
INFO - 2023-07-03 12:08:17 --> Loader Class Initialized
INFO - 2023-07-03 12:08:17 --> Helper loaded: url_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: file_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: html_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: text_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: form_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: security_helper
INFO - 2023-07-03 12:08:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:08:17 --> Database Driver Class Initialized
INFO - 2023-07-03 12:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:08:17 --> Parser Class Initialized
INFO - 2023-07-03 12:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:08:17 --> Pagination Class Initialized
INFO - 2023-07-03 12:08:17 --> Form Validation Class Initialized
INFO - 2023-07-03 12:08:17 --> Controller Class Initialized
DEBUG - 2023-07-03 12:08:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:17 --> Model Class Initialized
INFO - 2023-07-03 12:08:17 --> Final output sent to browser
DEBUG - 2023-07-03 12:08:17 --> Total execution time: 0.0341
ERROR - 2023-07-03 12:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:08:25 --> Config Class Initialized
INFO - 2023-07-03 12:08:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:08:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:08:25 --> Utf8 Class Initialized
INFO - 2023-07-03 12:08:25 --> URI Class Initialized
INFO - 2023-07-03 12:08:25 --> Router Class Initialized
INFO - 2023-07-03 12:08:25 --> Output Class Initialized
INFO - 2023-07-03 12:08:25 --> Security Class Initialized
DEBUG - 2023-07-03 12:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:08:25 --> Input Class Initialized
INFO - 2023-07-03 12:08:25 --> Language Class Initialized
INFO - 2023-07-03 12:08:25 --> Loader Class Initialized
INFO - 2023-07-03 12:08:25 --> Helper loaded: url_helper
INFO - 2023-07-03 12:08:25 --> Helper loaded: file_helper
INFO - 2023-07-03 12:08:25 --> Helper loaded: html_helper
INFO - 2023-07-03 12:08:25 --> Helper loaded: text_helper
INFO - 2023-07-03 12:08:25 --> Helper loaded: form_helper
INFO - 2023-07-03 12:08:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:08:25 --> Helper loaded: security_helper
INFO - 2023-07-03 12:08:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:08:25 --> Database Driver Class Initialized
INFO - 2023-07-03 12:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:08:25 --> Parser Class Initialized
INFO - 2023-07-03 12:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:08:25 --> Pagination Class Initialized
INFO - 2023-07-03 12:08:25 --> Form Validation Class Initialized
INFO - 2023-07-03 12:08:25 --> Controller Class Initialized
DEBUG - 2023-07-03 12:08:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:25 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:25 --> Model Class Initialized
INFO - 2023-07-03 12:08:25 --> Final output sent to browser
DEBUG - 2023-07-03 12:08:25 --> Total execution time: 0.1157
ERROR - 2023-07-03 12:08:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:08:41 --> Config Class Initialized
INFO - 2023-07-03 12:08:41 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:08:41 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:08:41 --> Utf8 Class Initialized
INFO - 2023-07-03 12:08:41 --> URI Class Initialized
DEBUG - 2023-07-03 12:08:41 --> No URI present. Default controller set.
INFO - 2023-07-03 12:08:41 --> Router Class Initialized
INFO - 2023-07-03 12:08:41 --> Output Class Initialized
INFO - 2023-07-03 12:08:41 --> Security Class Initialized
DEBUG - 2023-07-03 12:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:08:41 --> Input Class Initialized
INFO - 2023-07-03 12:08:41 --> Language Class Initialized
INFO - 2023-07-03 12:08:41 --> Loader Class Initialized
INFO - 2023-07-03 12:08:41 --> Helper loaded: url_helper
INFO - 2023-07-03 12:08:41 --> Helper loaded: file_helper
INFO - 2023-07-03 12:08:41 --> Helper loaded: html_helper
INFO - 2023-07-03 12:08:41 --> Helper loaded: text_helper
INFO - 2023-07-03 12:08:41 --> Helper loaded: form_helper
INFO - 2023-07-03 12:08:41 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:08:41 --> Helper loaded: security_helper
INFO - 2023-07-03 12:08:41 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:08:41 --> Database Driver Class Initialized
INFO - 2023-07-03 12:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:08:41 --> Parser Class Initialized
INFO - 2023-07-03 12:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:08:41 --> Pagination Class Initialized
INFO - 2023-07-03 12:08:41 --> Form Validation Class Initialized
INFO - 2023-07-03 12:08:41 --> Controller Class Initialized
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
INFO - 2023-07-03 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 12:08:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:08:41 --> Model Class Initialized
INFO - 2023-07-03 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:08:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:08:41 --> Final output sent to browser
DEBUG - 2023-07-03 12:08:41 --> Total execution time: 0.0953
ERROR - 2023-07-03 12:08:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:08:50 --> Config Class Initialized
INFO - 2023-07-03 12:08:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:08:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:08:50 --> Utf8 Class Initialized
INFO - 2023-07-03 12:08:50 --> URI Class Initialized
INFO - 2023-07-03 12:08:50 --> Router Class Initialized
INFO - 2023-07-03 12:08:50 --> Output Class Initialized
INFO - 2023-07-03 12:08:50 --> Security Class Initialized
DEBUG - 2023-07-03 12:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:08:50 --> Input Class Initialized
INFO - 2023-07-03 12:08:50 --> Language Class Initialized
INFO - 2023-07-03 12:08:50 --> Loader Class Initialized
INFO - 2023-07-03 12:08:50 --> Helper loaded: url_helper
INFO - 2023-07-03 12:08:50 --> Helper loaded: file_helper
INFO - 2023-07-03 12:08:50 --> Helper loaded: html_helper
INFO - 2023-07-03 12:08:50 --> Helper loaded: text_helper
INFO - 2023-07-03 12:08:50 --> Helper loaded: form_helper
INFO - 2023-07-03 12:08:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:08:50 --> Helper loaded: security_helper
INFO - 2023-07-03 12:08:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:08:50 --> Database Driver Class Initialized
INFO - 2023-07-03 12:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:08:50 --> Parser Class Initialized
INFO - 2023-07-03 12:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:08:50 --> Pagination Class Initialized
INFO - 2023-07-03 12:08:50 --> Form Validation Class Initialized
INFO - 2023-07-03 12:08:50 --> Controller Class Initialized
INFO - 2023-07-03 12:08:50 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:50 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:50 --> Model Class Initialized
INFO - 2023-07-03 12:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 12:08:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:08:50 --> Model Class Initialized
INFO - 2023-07-03 12:08:50 --> Model Class Initialized
INFO - 2023-07-03 12:08:50 --> Model Class Initialized
INFO - 2023-07-03 12:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:08:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:08:50 --> Final output sent to browser
DEBUG - 2023-07-03 12:08:50 --> Total execution time: 0.0756
ERROR - 2023-07-03 12:08:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:08:51 --> Config Class Initialized
INFO - 2023-07-03 12:08:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:08:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:08:51 --> Utf8 Class Initialized
INFO - 2023-07-03 12:08:51 --> URI Class Initialized
INFO - 2023-07-03 12:08:51 --> Router Class Initialized
INFO - 2023-07-03 12:08:51 --> Output Class Initialized
INFO - 2023-07-03 12:08:51 --> Security Class Initialized
DEBUG - 2023-07-03 12:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:08:51 --> Input Class Initialized
INFO - 2023-07-03 12:08:51 --> Language Class Initialized
INFO - 2023-07-03 12:08:51 --> Loader Class Initialized
INFO - 2023-07-03 12:08:51 --> Helper loaded: url_helper
INFO - 2023-07-03 12:08:51 --> Helper loaded: file_helper
INFO - 2023-07-03 12:08:51 --> Helper loaded: html_helper
INFO - 2023-07-03 12:08:51 --> Helper loaded: text_helper
INFO - 2023-07-03 12:08:51 --> Helper loaded: form_helper
INFO - 2023-07-03 12:08:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:08:51 --> Helper loaded: security_helper
INFO - 2023-07-03 12:08:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:08:51 --> Database Driver Class Initialized
INFO - 2023-07-03 12:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:08:51 --> Parser Class Initialized
INFO - 2023-07-03 12:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:08:51 --> Pagination Class Initialized
INFO - 2023-07-03 12:08:51 --> Form Validation Class Initialized
INFO - 2023-07-03 12:08:51 --> Controller Class Initialized
INFO - 2023-07-03 12:08:51 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:51 --> Model Class Initialized
DEBUG - 2023-07-03 12:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:08:51 --> Model Class Initialized
INFO - 2023-07-03 12:08:51 --> Final output sent to browser
DEBUG - 2023-07-03 12:08:51 --> Total execution time: 0.0508
ERROR - 2023-07-03 12:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:09:56 --> Config Class Initialized
INFO - 2023-07-03 12:09:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:09:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:09:56 --> Utf8 Class Initialized
INFO - 2023-07-03 12:09:56 --> URI Class Initialized
INFO - 2023-07-03 12:09:56 --> Router Class Initialized
INFO - 2023-07-03 12:09:56 --> Output Class Initialized
INFO - 2023-07-03 12:09:56 --> Security Class Initialized
DEBUG - 2023-07-03 12:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:09:56 --> Input Class Initialized
INFO - 2023-07-03 12:09:56 --> Language Class Initialized
INFO - 2023-07-03 12:09:56 --> Loader Class Initialized
INFO - 2023-07-03 12:09:56 --> Helper loaded: url_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: file_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: html_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: text_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: form_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: security_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:09:56 --> Database Driver Class Initialized
INFO - 2023-07-03 12:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:09:56 --> Parser Class Initialized
INFO - 2023-07-03 12:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:09:56 --> Pagination Class Initialized
INFO - 2023-07-03 12:09:56 --> Form Validation Class Initialized
INFO - 2023-07-03 12:09:56 --> Controller Class Initialized
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
DEBUG - 2023-07-03 12:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
DEBUG - 2023-07-03 12:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
INFO - 2023-07-03 12:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 12:09:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
INFO - 2023-07-03 12:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:09:56 --> Final output sent to browser
DEBUG - 2023-07-03 12:09:56 --> Total execution time: 0.0826
ERROR - 2023-07-03 12:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:09:56 --> Config Class Initialized
INFO - 2023-07-03 12:09:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:09:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:09:56 --> Utf8 Class Initialized
INFO - 2023-07-03 12:09:56 --> URI Class Initialized
INFO - 2023-07-03 12:09:56 --> Router Class Initialized
INFO - 2023-07-03 12:09:56 --> Output Class Initialized
INFO - 2023-07-03 12:09:56 --> Security Class Initialized
DEBUG - 2023-07-03 12:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:09:56 --> Input Class Initialized
INFO - 2023-07-03 12:09:56 --> Language Class Initialized
INFO - 2023-07-03 12:09:56 --> Loader Class Initialized
INFO - 2023-07-03 12:09:56 --> Helper loaded: url_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: file_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: html_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: text_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: form_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: security_helper
INFO - 2023-07-03 12:09:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:09:56 --> Database Driver Class Initialized
INFO - 2023-07-03 12:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:09:56 --> Parser Class Initialized
INFO - 2023-07-03 12:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:09:56 --> Pagination Class Initialized
INFO - 2023-07-03 12:09:56 --> Form Validation Class Initialized
INFO - 2023-07-03 12:09:56 --> Controller Class Initialized
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
DEBUG - 2023-07-03 12:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
DEBUG - 2023-07-03 12:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:09:56 --> Model Class Initialized
INFO - 2023-07-03 12:09:56 --> Final output sent to browser
DEBUG - 2023-07-03 12:09:56 --> Total execution time: 0.0463
ERROR - 2023-07-03 12:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:08 --> Config Class Initialized
INFO - 2023-07-03 12:10:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:08 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:08 --> URI Class Initialized
INFO - 2023-07-03 12:10:08 --> Router Class Initialized
INFO - 2023-07-03 12:10:08 --> Output Class Initialized
INFO - 2023-07-03 12:10:08 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:08 --> Input Class Initialized
INFO - 2023-07-03 12:10:08 --> Language Class Initialized
INFO - 2023-07-03 12:10:08 --> Loader Class Initialized
INFO - 2023-07-03 12:10:08 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:08 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:08 --> Parser Class Initialized
INFO - 2023-07-03 12:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:08 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:08 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:08 --> Controller Class Initialized
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
INFO - 2023-07-03 12:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 12:10:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
INFO - 2023-07-03 12:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:10:08 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:08 --> Total execution time: 0.0729
ERROR - 2023-07-03 12:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:08 --> Config Class Initialized
INFO - 2023-07-03 12:10:08 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:08 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:08 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:08 --> URI Class Initialized
INFO - 2023-07-03 12:10:08 --> Router Class Initialized
INFO - 2023-07-03 12:10:08 --> Output Class Initialized
INFO - 2023-07-03 12:10:08 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:08 --> Input Class Initialized
INFO - 2023-07-03 12:10:08 --> Language Class Initialized
INFO - 2023-07-03 12:10:08 --> Loader Class Initialized
INFO - 2023-07-03 12:10:08 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:08 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:08 --> Parser Class Initialized
INFO - 2023-07-03 12:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:08 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:08 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:08 --> Controller Class Initialized
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:08 --> Model Class Initialized
INFO - 2023-07-03 12:10:09 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:09 --> Total execution time: 0.0375
ERROR - 2023-07-03 12:10:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:12 --> Config Class Initialized
INFO - 2023-07-03 12:10:12 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:12 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:12 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:12 --> URI Class Initialized
INFO - 2023-07-03 12:10:12 --> Router Class Initialized
INFO - 2023-07-03 12:10:12 --> Output Class Initialized
INFO - 2023-07-03 12:10:12 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:12 --> Input Class Initialized
INFO - 2023-07-03 12:10:12 --> Language Class Initialized
INFO - 2023-07-03 12:10:12 --> Loader Class Initialized
INFO - 2023-07-03 12:10:12 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:12 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:12 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:12 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:12 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:12 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:12 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:12 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:12 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:12 --> Parser Class Initialized
INFO - 2023-07-03 12:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:12 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:12 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:12 --> Controller Class Initialized
INFO - 2023-07-03 12:10:12 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:12 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:12 --> Model Class Initialized
INFO - 2023-07-03 12:10:12 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:12 --> Total execution time: 0.0397
ERROR - 2023-07-03 12:10:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:14 --> Config Class Initialized
INFO - 2023-07-03 12:10:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:14 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:14 --> URI Class Initialized
INFO - 2023-07-03 12:10:14 --> Router Class Initialized
INFO - 2023-07-03 12:10:14 --> Output Class Initialized
INFO - 2023-07-03 12:10:14 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:14 --> Input Class Initialized
INFO - 2023-07-03 12:10:14 --> Language Class Initialized
INFO - 2023-07-03 12:10:14 --> Loader Class Initialized
INFO - 2023-07-03 12:10:14 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:14 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:14 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:14 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:14 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:14 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:14 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:14 --> Parser Class Initialized
INFO - 2023-07-03 12:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:14 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:14 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:14 --> Controller Class Initialized
INFO - 2023-07-03 12:10:14 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:14 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:14 --> Model Class Initialized
INFO - 2023-07-03 12:10:14 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:14 --> Total execution time: 0.0395
ERROR - 2023-07-03 12:10:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:15 --> Config Class Initialized
INFO - 2023-07-03 12:10:15 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:15 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:15 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:15 --> URI Class Initialized
INFO - 2023-07-03 12:10:15 --> Router Class Initialized
INFO - 2023-07-03 12:10:15 --> Output Class Initialized
INFO - 2023-07-03 12:10:15 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:15 --> Input Class Initialized
INFO - 2023-07-03 12:10:15 --> Language Class Initialized
INFO - 2023-07-03 12:10:15 --> Loader Class Initialized
INFO - 2023-07-03 12:10:15 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:15 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:15 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:15 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:15 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:15 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:15 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:15 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:15 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:15 --> Parser Class Initialized
INFO - 2023-07-03 12:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:15 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:15 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:15 --> Controller Class Initialized
INFO - 2023-07-03 12:10:15 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:15 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:15 --> Model Class Initialized
INFO - 2023-07-03 12:10:15 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:15 --> Total execution time: 0.0385
ERROR - 2023-07-03 12:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:16 --> Config Class Initialized
INFO - 2023-07-03 12:10:16 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:16 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:16 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:16 --> URI Class Initialized
INFO - 2023-07-03 12:10:16 --> Router Class Initialized
INFO - 2023-07-03 12:10:16 --> Output Class Initialized
INFO - 2023-07-03 12:10:16 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:16 --> Input Class Initialized
INFO - 2023-07-03 12:10:16 --> Language Class Initialized
INFO - 2023-07-03 12:10:16 --> Loader Class Initialized
INFO - 2023-07-03 12:10:16 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:16 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:16 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:16 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:16 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:16 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:16 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:16 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:16 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:16 --> Parser Class Initialized
INFO - 2023-07-03 12:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:16 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:16 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:16 --> Controller Class Initialized
INFO - 2023-07-03 12:10:16 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:16 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:16 --> Model Class Initialized
INFO - 2023-07-03 12:10:16 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:16 --> Total execution time: 0.0383
ERROR - 2023-07-03 12:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:17 --> Config Class Initialized
INFO - 2023-07-03 12:10:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:17 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:17 --> URI Class Initialized
INFO - 2023-07-03 12:10:17 --> Router Class Initialized
INFO - 2023-07-03 12:10:17 --> Output Class Initialized
INFO - 2023-07-03 12:10:17 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:17 --> Input Class Initialized
INFO - 2023-07-03 12:10:17 --> Language Class Initialized
INFO - 2023-07-03 12:10:17 --> Loader Class Initialized
INFO - 2023-07-03 12:10:17 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:17 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:17 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:17 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:17 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:17 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:17 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:17 --> Parser Class Initialized
INFO - 2023-07-03 12:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:17 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:17 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:17 --> Controller Class Initialized
INFO - 2023-07-03 12:10:17 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:17 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:17 --> Model Class Initialized
INFO - 2023-07-03 12:10:17 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:17 --> Total execution time: 0.0368
ERROR - 2023-07-03 12:10:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:18 --> Config Class Initialized
INFO - 2023-07-03 12:10:18 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:18 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:18 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:18 --> URI Class Initialized
INFO - 2023-07-03 12:10:18 --> Router Class Initialized
INFO - 2023-07-03 12:10:18 --> Output Class Initialized
INFO - 2023-07-03 12:10:18 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:18 --> Input Class Initialized
INFO - 2023-07-03 12:10:18 --> Language Class Initialized
INFO - 2023-07-03 12:10:18 --> Loader Class Initialized
INFO - 2023-07-03 12:10:18 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:18 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:18 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:18 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:18 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:18 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:18 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:18 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:18 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:18 --> Parser Class Initialized
INFO - 2023-07-03 12:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:18 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:18 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:18 --> Controller Class Initialized
INFO - 2023-07-03 12:10:18 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:18 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:18 --> Model Class Initialized
INFO - 2023-07-03 12:10:18 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:18 --> Total execution time: 0.0429
ERROR - 2023-07-03 12:10:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:19 --> Config Class Initialized
INFO - 2023-07-03 12:10:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:19 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:19 --> URI Class Initialized
INFO - 2023-07-03 12:10:19 --> Router Class Initialized
INFO - 2023-07-03 12:10:19 --> Output Class Initialized
INFO - 2023-07-03 12:10:19 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:19 --> Input Class Initialized
INFO - 2023-07-03 12:10:19 --> Language Class Initialized
INFO - 2023-07-03 12:10:19 --> Loader Class Initialized
INFO - 2023-07-03 12:10:19 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:19 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:19 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:19 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:19 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:19 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:19 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:19 --> Parser Class Initialized
INFO - 2023-07-03 12:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:19 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:19 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:19 --> Controller Class Initialized
INFO - 2023-07-03 12:10:19 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:19 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:19 --> Model Class Initialized
INFO - 2023-07-03 12:10:19 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:19 --> Total execution time: 0.0385
ERROR - 2023-07-03 12:10:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:21 --> Config Class Initialized
INFO - 2023-07-03 12:10:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:21 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:21 --> URI Class Initialized
INFO - 2023-07-03 12:10:21 --> Router Class Initialized
INFO - 2023-07-03 12:10:21 --> Output Class Initialized
INFO - 2023-07-03 12:10:21 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:21 --> Input Class Initialized
INFO - 2023-07-03 12:10:21 --> Language Class Initialized
INFO - 2023-07-03 12:10:21 --> Loader Class Initialized
INFO - 2023-07-03 12:10:21 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:21 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:21 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:21 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:21 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:21 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:21 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:21 --> Parser Class Initialized
INFO - 2023-07-03 12:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:21 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:21 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:21 --> Controller Class Initialized
INFO - 2023-07-03 12:10:21 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:21 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:21 --> Model Class Initialized
INFO - 2023-07-03 12:10:21 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:21 --> Total execution time: 0.0414
ERROR - 2023-07-03 12:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:22 --> Config Class Initialized
INFO - 2023-07-03 12:10:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:22 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:22 --> URI Class Initialized
INFO - 2023-07-03 12:10:22 --> Router Class Initialized
INFO - 2023-07-03 12:10:22 --> Output Class Initialized
INFO - 2023-07-03 12:10:22 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:22 --> Input Class Initialized
INFO - 2023-07-03 12:10:22 --> Language Class Initialized
INFO - 2023-07-03 12:10:22 --> Loader Class Initialized
INFO - 2023-07-03 12:10:22 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:22 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:22 --> Parser Class Initialized
INFO - 2023-07-03 12:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:22 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:22 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:22 --> Controller Class Initialized
INFO - 2023-07-03 12:10:22 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:22 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:22 --> Model Class Initialized
INFO - 2023-07-03 12:10:22 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:22 --> Total execution time: 0.0568
ERROR - 2023-07-03 12:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:22 --> Config Class Initialized
INFO - 2023-07-03 12:10:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:22 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:22 --> URI Class Initialized
INFO - 2023-07-03 12:10:22 --> Router Class Initialized
INFO - 2023-07-03 12:10:22 --> Output Class Initialized
INFO - 2023-07-03 12:10:22 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:22 --> Input Class Initialized
INFO - 2023-07-03 12:10:22 --> Language Class Initialized
INFO - 2023-07-03 12:10:22 --> Loader Class Initialized
INFO - 2023-07-03 12:10:22 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:22 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:22 --> Parser Class Initialized
INFO - 2023-07-03 12:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:22 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:22 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:22 --> Controller Class Initialized
INFO - 2023-07-03 12:10:22 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:22 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:22 --> Model Class Initialized
INFO - 2023-07-03 12:10:22 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:22 --> Total execution time: 0.0397
ERROR - 2023-07-03 12:10:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:24 --> Config Class Initialized
INFO - 2023-07-03 12:10:24 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:24 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:24 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:24 --> URI Class Initialized
INFO - 2023-07-03 12:10:24 --> Router Class Initialized
INFO - 2023-07-03 12:10:24 --> Output Class Initialized
INFO - 2023-07-03 12:10:24 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:24 --> Input Class Initialized
INFO - 2023-07-03 12:10:24 --> Language Class Initialized
INFO - 2023-07-03 12:10:24 --> Loader Class Initialized
INFO - 2023-07-03 12:10:24 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:24 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:24 --> Parser Class Initialized
INFO - 2023-07-03 12:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:24 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:24 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:24 --> Controller Class Initialized
INFO - 2023-07-03 12:10:24 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:24 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:24 --> Model Class Initialized
INFO - 2023-07-03 12:10:24 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:24 --> Total execution time: 0.0264
ERROR - 2023-07-03 12:10:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:24 --> Config Class Initialized
INFO - 2023-07-03 12:10:24 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:24 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:24 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:24 --> URI Class Initialized
INFO - 2023-07-03 12:10:24 --> Router Class Initialized
INFO - 2023-07-03 12:10:24 --> Output Class Initialized
INFO - 2023-07-03 12:10:24 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:24 --> Input Class Initialized
INFO - 2023-07-03 12:10:24 --> Language Class Initialized
INFO - 2023-07-03 12:10:24 --> Loader Class Initialized
INFO - 2023-07-03 12:10:24 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:24 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:24 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:24 --> Parser Class Initialized
INFO - 2023-07-03 12:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:24 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:24 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:24 --> Controller Class Initialized
INFO - 2023-07-03 12:10:24 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:24 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:24 --> Model Class Initialized
INFO - 2023-07-03 12:10:24 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:24 --> Total execution time: 0.0273
ERROR - 2023-07-03 12:10:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:25 --> Config Class Initialized
INFO - 2023-07-03 12:10:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:25 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:25 --> URI Class Initialized
INFO - 2023-07-03 12:10:25 --> Router Class Initialized
INFO - 2023-07-03 12:10:25 --> Output Class Initialized
INFO - 2023-07-03 12:10:25 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:25 --> Input Class Initialized
INFO - 2023-07-03 12:10:25 --> Language Class Initialized
INFO - 2023-07-03 12:10:25 --> Loader Class Initialized
INFO - 2023-07-03 12:10:25 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:25 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:25 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:25 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:25 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:25 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:25 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:25 --> Parser Class Initialized
INFO - 2023-07-03 12:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:25 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:25 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:25 --> Controller Class Initialized
INFO - 2023-07-03 12:10:25 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:25 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:25 --> Model Class Initialized
INFO - 2023-07-03 12:10:25 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:25 --> Total execution time: 0.0210
ERROR - 2023-07-03 12:10:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:26 --> Config Class Initialized
INFO - 2023-07-03 12:10:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:26 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:26 --> URI Class Initialized
INFO - 2023-07-03 12:10:26 --> Router Class Initialized
INFO - 2023-07-03 12:10:26 --> Output Class Initialized
INFO - 2023-07-03 12:10:26 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:26 --> Input Class Initialized
INFO - 2023-07-03 12:10:26 --> Language Class Initialized
INFO - 2023-07-03 12:10:26 --> Loader Class Initialized
INFO - 2023-07-03 12:10:26 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:26 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:26 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:26 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:26 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:26 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:26 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:26 --> Parser Class Initialized
INFO - 2023-07-03 12:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:26 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:26 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:26 --> Controller Class Initialized
INFO - 2023-07-03 12:10:26 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:26 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:26 --> Model Class Initialized
INFO - 2023-07-03 12:10:26 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:26 --> Total execution time: 0.0204
ERROR - 2023-07-03 12:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:28 --> Config Class Initialized
INFO - 2023-07-03 12:10:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:28 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:28 --> URI Class Initialized
INFO - 2023-07-03 12:10:28 --> Router Class Initialized
INFO - 2023-07-03 12:10:28 --> Output Class Initialized
INFO - 2023-07-03 12:10:28 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:28 --> Input Class Initialized
INFO - 2023-07-03 12:10:28 --> Language Class Initialized
INFO - 2023-07-03 12:10:28 --> Loader Class Initialized
INFO - 2023-07-03 12:10:28 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:28 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:28 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:28 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:28 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:28 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:28 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:28 --> Parser Class Initialized
INFO - 2023-07-03 12:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:28 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:28 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:28 --> Controller Class Initialized
INFO - 2023-07-03 12:10:28 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:28 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:28 --> Model Class Initialized
INFO - 2023-07-03 12:10:28 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:28 --> Total execution time: 0.0200
ERROR - 2023-07-03 12:10:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:10:30 --> Config Class Initialized
INFO - 2023-07-03 12:10:30 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:10:30 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:10:30 --> Utf8 Class Initialized
INFO - 2023-07-03 12:10:30 --> URI Class Initialized
INFO - 2023-07-03 12:10:30 --> Router Class Initialized
INFO - 2023-07-03 12:10:30 --> Output Class Initialized
INFO - 2023-07-03 12:10:30 --> Security Class Initialized
DEBUG - 2023-07-03 12:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:10:30 --> Input Class Initialized
INFO - 2023-07-03 12:10:30 --> Language Class Initialized
INFO - 2023-07-03 12:10:30 --> Loader Class Initialized
INFO - 2023-07-03 12:10:30 --> Helper loaded: url_helper
INFO - 2023-07-03 12:10:30 --> Helper loaded: file_helper
INFO - 2023-07-03 12:10:30 --> Helper loaded: html_helper
INFO - 2023-07-03 12:10:30 --> Helper loaded: text_helper
INFO - 2023-07-03 12:10:30 --> Helper loaded: form_helper
INFO - 2023-07-03 12:10:30 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:10:30 --> Helper loaded: security_helper
INFO - 2023-07-03 12:10:30 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:10:30 --> Database Driver Class Initialized
INFO - 2023-07-03 12:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:10:30 --> Parser Class Initialized
INFO - 2023-07-03 12:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:10:30 --> Pagination Class Initialized
INFO - 2023-07-03 12:10:30 --> Form Validation Class Initialized
INFO - 2023-07-03 12:10:30 --> Controller Class Initialized
INFO - 2023-07-03 12:10:30 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:30 --> Model Class Initialized
DEBUG - 2023-07-03 12:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:10:30 --> Model Class Initialized
INFO - 2023-07-03 12:10:30 --> Final output sent to browser
DEBUG - 2023-07-03 12:10:30 --> Total execution time: 0.0266
ERROR - 2023-07-03 12:12:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:12:13 --> Config Class Initialized
INFO - 2023-07-03 12:12:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:12:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:12:13 --> Utf8 Class Initialized
INFO - 2023-07-03 12:12:13 --> URI Class Initialized
DEBUG - 2023-07-03 12:12:13 --> No URI present. Default controller set.
INFO - 2023-07-03 12:12:13 --> Router Class Initialized
INFO - 2023-07-03 12:12:13 --> Output Class Initialized
INFO - 2023-07-03 12:12:13 --> Security Class Initialized
DEBUG - 2023-07-03 12:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:12:13 --> Input Class Initialized
INFO - 2023-07-03 12:12:13 --> Language Class Initialized
INFO - 2023-07-03 12:12:13 --> Loader Class Initialized
INFO - 2023-07-03 12:12:13 --> Helper loaded: url_helper
INFO - 2023-07-03 12:12:13 --> Helper loaded: file_helper
INFO - 2023-07-03 12:12:13 --> Helper loaded: html_helper
INFO - 2023-07-03 12:12:13 --> Helper loaded: text_helper
INFO - 2023-07-03 12:12:13 --> Helper loaded: form_helper
INFO - 2023-07-03 12:12:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:12:13 --> Helper loaded: security_helper
INFO - 2023-07-03 12:12:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:12:13 --> Database Driver Class Initialized
INFO - 2023-07-03 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:12:13 --> Parser Class Initialized
INFO - 2023-07-03 12:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:12:13 --> Pagination Class Initialized
INFO - 2023-07-03 12:12:13 --> Form Validation Class Initialized
INFO - 2023-07-03 12:12:13 --> Controller Class Initialized
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
DEBUG - 2023-07-03 12:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
DEBUG - 2023-07-03 12:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
DEBUG - 2023-07-03 12:12:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
INFO - 2023-07-03 12:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 12:12:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:12:13 --> Model Class Initialized
INFO - 2023-07-03 12:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:12:13 --> Final output sent to browser
DEBUG - 2023-07-03 12:12:13 --> Total execution time: 0.1915
ERROR - 2023-07-03 12:13:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:13:19 --> Config Class Initialized
INFO - 2023-07-03 12:13:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:13:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:13:19 --> Utf8 Class Initialized
INFO - 2023-07-03 12:13:19 --> URI Class Initialized
DEBUG - 2023-07-03 12:13:19 --> No URI present. Default controller set.
INFO - 2023-07-03 12:13:19 --> Router Class Initialized
INFO - 2023-07-03 12:13:19 --> Output Class Initialized
INFO - 2023-07-03 12:13:19 --> Security Class Initialized
DEBUG - 2023-07-03 12:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:13:19 --> Input Class Initialized
INFO - 2023-07-03 12:13:19 --> Language Class Initialized
INFO - 2023-07-03 12:13:19 --> Loader Class Initialized
INFO - 2023-07-03 12:13:19 --> Helper loaded: url_helper
INFO - 2023-07-03 12:13:19 --> Helper loaded: file_helper
INFO - 2023-07-03 12:13:19 --> Helper loaded: html_helper
INFO - 2023-07-03 12:13:19 --> Helper loaded: text_helper
INFO - 2023-07-03 12:13:19 --> Helper loaded: form_helper
INFO - 2023-07-03 12:13:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:13:19 --> Helper loaded: security_helper
INFO - 2023-07-03 12:13:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:13:19 --> Database Driver Class Initialized
INFO - 2023-07-03 12:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:13:19 --> Parser Class Initialized
INFO - 2023-07-03 12:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:13:19 --> Pagination Class Initialized
INFO - 2023-07-03 12:13:19 --> Form Validation Class Initialized
INFO - 2023-07-03 12:13:19 --> Controller Class Initialized
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
DEBUG - 2023-07-03 12:13:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
DEBUG - 2023-07-03 12:13:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
DEBUG - 2023-07-03 12:13:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:13:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
INFO - 2023-07-03 12:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 12:13:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:13:19 --> Model Class Initialized
INFO - 2023-07-03 12:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:13:19 --> Final output sent to browser
DEBUG - 2023-07-03 12:13:19 --> Total execution time: 0.1923
ERROR - 2023-07-03 12:13:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:13:31 --> Config Class Initialized
INFO - 2023-07-03 12:13:31 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:13:31 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:13:31 --> Utf8 Class Initialized
INFO - 2023-07-03 12:13:31 --> URI Class Initialized
DEBUG - 2023-07-03 12:13:31 --> No URI present. Default controller set.
INFO - 2023-07-03 12:13:31 --> Router Class Initialized
INFO - 2023-07-03 12:13:31 --> Output Class Initialized
INFO - 2023-07-03 12:13:31 --> Security Class Initialized
DEBUG - 2023-07-03 12:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:13:31 --> Input Class Initialized
INFO - 2023-07-03 12:13:31 --> Language Class Initialized
INFO - 2023-07-03 12:13:31 --> Loader Class Initialized
INFO - 2023-07-03 12:13:31 --> Helper loaded: url_helper
INFO - 2023-07-03 12:13:31 --> Helper loaded: file_helper
INFO - 2023-07-03 12:13:31 --> Helper loaded: html_helper
INFO - 2023-07-03 12:13:31 --> Helper loaded: text_helper
INFO - 2023-07-03 12:13:31 --> Helper loaded: form_helper
INFO - 2023-07-03 12:13:31 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:13:31 --> Helper loaded: security_helper
INFO - 2023-07-03 12:13:31 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:13:31 --> Database Driver Class Initialized
INFO - 2023-07-03 12:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:13:31 --> Parser Class Initialized
INFO - 2023-07-03 12:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:13:31 --> Pagination Class Initialized
INFO - 2023-07-03 12:13:31 --> Form Validation Class Initialized
INFO - 2023-07-03 12:13:31 --> Controller Class Initialized
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
DEBUG - 2023-07-03 12:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
DEBUG - 2023-07-03 12:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
DEBUG - 2023-07-03 12:13:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
INFO - 2023-07-03 12:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 12:13:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:13:31 --> Model Class Initialized
INFO - 2023-07-03 12:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:13:31 --> Final output sent to browser
DEBUG - 2023-07-03 12:13:31 --> Total execution time: 0.0829
ERROR - 2023-07-03 12:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:14:26 --> Config Class Initialized
INFO - 2023-07-03 12:14:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:14:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:14:26 --> Utf8 Class Initialized
INFO - 2023-07-03 12:14:26 --> URI Class Initialized
INFO - 2023-07-03 12:14:26 --> Router Class Initialized
INFO - 2023-07-03 12:14:26 --> Output Class Initialized
INFO - 2023-07-03 12:14:26 --> Security Class Initialized
DEBUG - 2023-07-03 12:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:14:26 --> Input Class Initialized
INFO - 2023-07-03 12:14:26 --> Language Class Initialized
INFO - 2023-07-03 12:14:26 --> Loader Class Initialized
INFO - 2023-07-03 12:14:26 --> Helper loaded: url_helper
INFO - 2023-07-03 12:14:26 --> Helper loaded: file_helper
INFO - 2023-07-03 12:14:26 --> Helper loaded: html_helper
INFO - 2023-07-03 12:14:26 --> Helper loaded: text_helper
INFO - 2023-07-03 12:14:26 --> Helper loaded: form_helper
INFO - 2023-07-03 12:14:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:14:26 --> Helper loaded: security_helper
INFO - 2023-07-03 12:14:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:14:26 --> Database Driver Class Initialized
INFO - 2023-07-03 12:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:14:26 --> Parser Class Initialized
INFO - 2023-07-03 12:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:14:26 --> Pagination Class Initialized
INFO - 2023-07-03 12:14:26 --> Form Validation Class Initialized
INFO - 2023-07-03 12:14:26 --> Controller Class Initialized
INFO - 2023-07-03 12:14:26 --> Model Class Initialized
DEBUG - 2023-07-03 12:14:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:14:26 --> Model Class Initialized
DEBUG - 2023-07-03 12:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:14:26 --> Model Class Initialized
INFO - 2023-07-03 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 12:14:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 12:14:27 --> Model Class Initialized
INFO - 2023-07-03 12:14:27 --> Model Class Initialized
INFO - 2023-07-03 12:14:27 --> Model Class Initialized
INFO - 2023-07-03 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 12:14:27 --> Final output sent to browser
DEBUG - 2023-07-03 12:14:27 --> Total execution time: 0.1620
ERROR - 2023-07-03 12:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 12:14:28 --> Config Class Initialized
INFO - 2023-07-03 12:14:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 12:14:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 12:14:28 --> Utf8 Class Initialized
INFO - 2023-07-03 12:14:28 --> URI Class Initialized
INFO - 2023-07-03 12:14:28 --> Router Class Initialized
INFO - 2023-07-03 12:14:28 --> Output Class Initialized
INFO - 2023-07-03 12:14:28 --> Security Class Initialized
DEBUG - 2023-07-03 12:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 12:14:28 --> Input Class Initialized
INFO - 2023-07-03 12:14:28 --> Language Class Initialized
INFO - 2023-07-03 12:14:28 --> Loader Class Initialized
INFO - 2023-07-03 12:14:28 --> Helper loaded: url_helper
INFO - 2023-07-03 12:14:28 --> Helper loaded: file_helper
INFO - 2023-07-03 12:14:28 --> Helper loaded: html_helper
INFO - 2023-07-03 12:14:28 --> Helper loaded: text_helper
INFO - 2023-07-03 12:14:28 --> Helper loaded: form_helper
INFO - 2023-07-03 12:14:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 12:14:28 --> Helper loaded: security_helper
INFO - 2023-07-03 12:14:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 12:14:28 --> Database Driver Class Initialized
INFO - 2023-07-03 12:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 12:14:28 --> Parser Class Initialized
INFO - 2023-07-03 12:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 12:14:28 --> Pagination Class Initialized
INFO - 2023-07-03 12:14:28 --> Form Validation Class Initialized
INFO - 2023-07-03 12:14:28 --> Controller Class Initialized
INFO - 2023-07-03 12:14:28 --> Model Class Initialized
DEBUG - 2023-07-03 12:14:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 12:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:14:28 --> Model Class Initialized
DEBUG - 2023-07-03 12:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 12:14:28 --> Model Class Initialized
INFO - 2023-07-03 12:14:28 --> Final output sent to browser
DEBUG - 2023-07-03 12:14:28 --> Total execution time: 0.0556
ERROR - 2023-07-03 13:00:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 13:00:31 --> Config Class Initialized
INFO - 2023-07-03 13:00:31 --> Hooks Class Initialized
DEBUG - 2023-07-03 13:00:31 --> UTF-8 Support Enabled
INFO - 2023-07-03 13:00:31 --> Utf8 Class Initialized
INFO - 2023-07-03 13:00:31 --> URI Class Initialized
INFO - 2023-07-03 13:00:31 --> Router Class Initialized
INFO - 2023-07-03 13:00:31 --> Output Class Initialized
INFO - 2023-07-03 13:00:31 --> Security Class Initialized
DEBUG - 2023-07-03 13:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 13:00:31 --> Input Class Initialized
INFO - 2023-07-03 13:00:31 --> Language Class Initialized
INFO - 2023-07-03 13:00:31 --> Loader Class Initialized
INFO - 2023-07-03 13:00:31 --> Helper loaded: url_helper
INFO - 2023-07-03 13:00:31 --> Helper loaded: file_helper
INFO - 2023-07-03 13:00:31 --> Helper loaded: html_helper
INFO - 2023-07-03 13:00:31 --> Helper loaded: text_helper
INFO - 2023-07-03 13:00:31 --> Helper loaded: form_helper
INFO - 2023-07-03 13:00:31 --> Helper loaded: lang_helper
INFO - 2023-07-03 13:00:31 --> Helper loaded: security_helper
INFO - 2023-07-03 13:00:31 --> Helper loaded: cookie_helper
INFO - 2023-07-03 13:00:31 --> Database Driver Class Initialized
INFO - 2023-07-03 13:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 13:00:31 --> Parser Class Initialized
INFO - 2023-07-03 13:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 13:00:31 --> Pagination Class Initialized
INFO - 2023-07-03 13:00:31 --> Form Validation Class Initialized
INFO - 2023-07-03 13:00:31 --> Controller Class Initialized
INFO - 2023-07-03 13:00:31 --> Model Class Initialized
DEBUG - 2023-07-03 13:00:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 13:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 13:00:31 --> Model Class Initialized
DEBUG - 2023-07-03 13:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 13:00:31 --> Model Class Initialized
INFO - 2023-07-03 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 13:00:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 13:00:31 --> Model Class Initialized
INFO - 2023-07-03 13:00:31 --> Model Class Initialized
INFO - 2023-07-03 13:00:31 --> Model Class Initialized
INFO - 2023-07-03 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 13:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 13:00:31 --> Final output sent to browser
DEBUG - 2023-07-03 13:00:31 --> Total execution time: 0.1492
ERROR - 2023-07-03 13:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 13:00:33 --> Config Class Initialized
INFO - 2023-07-03 13:00:33 --> Hooks Class Initialized
DEBUG - 2023-07-03 13:00:33 --> UTF-8 Support Enabled
INFO - 2023-07-03 13:00:33 --> Utf8 Class Initialized
INFO - 2023-07-03 13:00:33 --> URI Class Initialized
INFO - 2023-07-03 13:00:33 --> Router Class Initialized
INFO - 2023-07-03 13:00:33 --> Output Class Initialized
INFO - 2023-07-03 13:00:33 --> Security Class Initialized
DEBUG - 2023-07-03 13:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 13:00:33 --> Input Class Initialized
INFO - 2023-07-03 13:00:33 --> Language Class Initialized
INFO - 2023-07-03 13:00:33 --> Loader Class Initialized
INFO - 2023-07-03 13:00:33 --> Helper loaded: url_helper
INFO - 2023-07-03 13:00:33 --> Helper loaded: file_helper
INFO - 2023-07-03 13:00:33 --> Helper loaded: html_helper
INFO - 2023-07-03 13:00:33 --> Helper loaded: text_helper
INFO - 2023-07-03 13:00:33 --> Helper loaded: form_helper
INFO - 2023-07-03 13:00:33 --> Helper loaded: lang_helper
INFO - 2023-07-03 13:00:33 --> Helper loaded: security_helper
INFO - 2023-07-03 13:00:33 --> Helper loaded: cookie_helper
INFO - 2023-07-03 13:00:33 --> Database Driver Class Initialized
INFO - 2023-07-03 13:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 13:00:33 --> Parser Class Initialized
INFO - 2023-07-03 13:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 13:00:33 --> Pagination Class Initialized
INFO - 2023-07-03 13:00:33 --> Form Validation Class Initialized
INFO - 2023-07-03 13:00:33 --> Controller Class Initialized
INFO - 2023-07-03 13:00:33 --> Model Class Initialized
DEBUG - 2023-07-03 13:00:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 13:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 13:00:33 --> Model Class Initialized
DEBUG - 2023-07-03 13:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 13:00:33 --> Model Class Initialized
INFO - 2023-07-03 13:00:33 --> Final output sent to browser
DEBUG - 2023-07-03 13:00:33 --> Total execution time: 0.0491
ERROR - 2023-07-03 13:00:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 13:00:38 --> Config Class Initialized
INFO - 2023-07-03 13:00:38 --> Hooks Class Initialized
DEBUG - 2023-07-03 13:00:38 --> UTF-8 Support Enabled
INFO - 2023-07-03 13:00:38 --> Utf8 Class Initialized
INFO - 2023-07-03 13:00:38 --> URI Class Initialized
INFO - 2023-07-03 13:00:38 --> Router Class Initialized
INFO - 2023-07-03 13:00:38 --> Output Class Initialized
INFO - 2023-07-03 13:00:38 --> Security Class Initialized
DEBUG - 2023-07-03 13:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 13:00:38 --> Input Class Initialized
INFO - 2023-07-03 13:00:38 --> Language Class Initialized
INFO - 2023-07-03 13:00:38 --> Loader Class Initialized
INFO - 2023-07-03 13:00:38 --> Helper loaded: url_helper
INFO - 2023-07-03 13:00:38 --> Helper loaded: file_helper
INFO - 2023-07-03 13:00:38 --> Helper loaded: html_helper
INFO - 2023-07-03 13:00:38 --> Helper loaded: text_helper
INFO - 2023-07-03 13:00:38 --> Helper loaded: form_helper
INFO - 2023-07-03 13:00:38 --> Helper loaded: lang_helper
INFO - 2023-07-03 13:00:38 --> Helper loaded: security_helper
INFO - 2023-07-03 13:00:38 --> Helper loaded: cookie_helper
INFO - 2023-07-03 13:00:38 --> Database Driver Class Initialized
INFO - 2023-07-03 13:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 13:00:38 --> Parser Class Initialized
INFO - 2023-07-03 13:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 13:00:38 --> Pagination Class Initialized
INFO - 2023-07-03 13:00:38 --> Form Validation Class Initialized
INFO - 2023-07-03 13:00:38 --> Controller Class Initialized
INFO - 2023-07-03 13:00:38 --> Model Class Initialized
INFO - 2023-07-03 13:00:38 --> Model Class Initialized
INFO - 2023-07-03 13:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-07-03 13:00:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 13:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 13:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 13:00:38 --> Model Class Initialized
INFO - 2023-07-03 13:00:38 --> Model Class Initialized
INFO - 2023-07-03 13:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 13:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 13:00:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 13:00:38 --> Final output sent to browser
DEBUG - 2023-07-03 13:00:38 --> Total execution time: 0.1484
ERROR - 2023-07-03 13:00:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 13:00:39 --> Config Class Initialized
INFO - 2023-07-03 13:00:39 --> Hooks Class Initialized
DEBUG - 2023-07-03 13:00:39 --> UTF-8 Support Enabled
INFO - 2023-07-03 13:00:39 --> Utf8 Class Initialized
INFO - 2023-07-03 13:00:39 --> URI Class Initialized
INFO - 2023-07-03 13:00:39 --> Router Class Initialized
INFO - 2023-07-03 13:00:39 --> Output Class Initialized
INFO - 2023-07-03 13:00:39 --> Security Class Initialized
DEBUG - 2023-07-03 13:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 13:00:39 --> Input Class Initialized
INFO - 2023-07-03 13:00:39 --> Language Class Initialized
INFO - 2023-07-03 13:00:39 --> Loader Class Initialized
INFO - 2023-07-03 13:00:39 --> Helper loaded: url_helper
INFO - 2023-07-03 13:00:39 --> Helper loaded: file_helper
INFO - 2023-07-03 13:00:39 --> Helper loaded: html_helper
INFO - 2023-07-03 13:00:39 --> Helper loaded: text_helper
INFO - 2023-07-03 13:00:39 --> Helper loaded: form_helper
INFO - 2023-07-03 13:00:39 --> Helper loaded: lang_helper
INFO - 2023-07-03 13:00:39 --> Helper loaded: security_helper
INFO - 2023-07-03 13:00:39 --> Helper loaded: cookie_helper
INFO - 2023-07-03 13:00:39 --> Database Driver Class Initialized
INFO - 2023-07-03 13:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 13:00:39 --> Parser Class Initialized
INFO - 2023-07-03 13:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 13:00:39 --> Pagination Class Initialized
INFO - 2023-07-03 13:00:39 --> Form Validation Class Initialized
INFO - 2023-07-03 13:00:39 --> Controller Class Initialized
INFO - 2023-07-03 13:00:39 --> Model Class Initialized
INFO - 2023-07-03 13:00:39 --> Model Class Initialized
INFO - 2023-07-03 13:00:39 --> Final output sent to browser
DEBUG - 2023-07-03 13:00:39 --> Total execution time: 0.0293
ERROR - 2023-07-03 16:00:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:00:09 --> Config Class Initialized
INFO - 2023-07-03 16:00:09 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:00:09 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:00:09 --> Utf8 Class Initialized
INFO - 2023-07-03 16:00:09 --> URI Class Initialized
DEBUG - 2023-07-03 16:00:09 --> No URI present. Default controller set.
INFO - 2023-07-03 16:00:09 --> Router Class Initialized
INFO - 2023-07-03 16:00:09 --> Output Class Initialized
INFO - 2023-07-03 16:00:09 --> Security Class Initialized
DEBUG - 2023-07-03 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:00:09 --> Input Class Initialized
INFO - 2023-07-03 16:00:09 --> Language Class Initialized
INFO - 2023-07-03 16:00:09 --> Loader Class Initialized
INFO - 2023-07-03 16:00:09 --> Helper loaded: url_helper
INFO - 2023-07-03 16:00:09 --> Helper loaded: file_helper
INFO - 2023-07-03 16:00:09 --> Helper loaded: html_helper
INFO - 2023-07-03 16:00:09 --> Helper loaded: text_helper
INFO - 2023-07-03 16:00:09 --> Helper loaded: form_helper
INFO - 2023-07-03 16:00:09 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:00:09 --> Helper loaded: security_helper
INFO - 2023-07-03 16:00:09 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:00:09 --> Database Driver Class Initialized
INFO - 2023-07-03 16:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:00:09 --> Parser Class Initialized
INFO - 2023-07-03 16:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:00:09 --> Pagination Class Initialized
INFO - 2023-07-03 16:00:09 --> Form Validation Class Initialized
INFO - 2023-07-03 16:00:09 --> Controller Class Initialized
INFO - 2023-07-03 16:00:09 --> Model Class Initialized
DEBUG - 2023-07-03 16:00:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 16:00:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:00:10 --> Config Class Initialized
INFO - 2023-07-03 16:00:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:00:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:00:10 --> Utf8 Class Initialized
INFO - 2023-07-03 16:00:10 --> URI Class Initialized
INFO - 2023-07-03 16:00:10 --> Router Class Initialized
INFO - 2023-07-03 16:00:10 --> Output Class Initialized
INFO - 2023-07-03 16:00:10 --> Security Class Initialized
DEBUG - 2023-07-03 16:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:00:10 --> Input Class Initialized
INFO - 2023-07-03 16:00:10 --> Language Class Initialized
INFO - 2023-07-03 16:00:10 --> Loader Class Initialized
INFO - 2023-07-03 16:00:10 --> Helper loaded: url_helper
INFO - 2023-07-03 16:00:10 --> Helper loaded: file_helper
INFO - 2023-07-03 16:00:10 --> Helper loaded: html_helper
INFO - 2023-07-03 16:00:10 --> Helper loaded: text_helper
INFO - 2023-07-03 16:00:10 --> Helper loaded: form_helper
INFO - 2023-07-03 16:00:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:00:10 --> Helper loaded: security_helper
INFO - 2023-07-03 16:00:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:00:10 --> Database Driver Class Initialized
INFO - 2023-07-03 16:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:00:10 --> Parser Class Initialized
INFO - 2023-07-03 16:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:00:10 --> Pagination Class Initialized
INFO - 2023-07-03 16:00:10 --> Form Validation Class Initialized
INFO - 2023-07-03 16:00:10 --> Controller Class Initialized
INFO - 2023-07-03 16:00:10 --> Model Class Initialized
DEBUG - 2023-07-03 16:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 16:00:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:00:10 --> Model Class Initialized
INFO - 2023-07-03 16:00:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:00:10 --> Final output sent to browser
DEBUG - 2023-07-03 16:00:10 --> Total execution time: 0.0325
ERROR - 2023-07-03 16:00:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:00:15 --> Config Class Initialized
INFO - 2023-07-03 16:00:15 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:00:15 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:00:15 --> Utf8 Class Initialized
INFO - 2023-07-03 16:00:15 --> URI Class Initialized
INFO - 2023-07-03 16:00:15 --> Router Class Initialized
INFO - 2023-07-03 16:00:15 --> Output Class Initialized
INFO - 2023-07-03 16:00:15 --> Security Class Initialized
DEBUG - 2023-07-03 16:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:00:15 --> Input Class Initialized
INFO - 2023-07-03 16:00:15 --> Language Class Initialized
INFO - 2023-07-03 16:00:15 --> Loader Class Initialized
INFO - 2023-07-03 16:00:15 --> Helper loaded: url_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: file_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: html_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: text_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: form_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: security_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:00:15 --> Database Driver Class Initialized
INFO - 2023-07-03 16:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:00:15 --> Parser Class Initialized
INFO - 2023-07-03 16:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:00:15 --> Pagination Class Initialized
INFO - 2023-07-03 16:00:15 --> Form Validation Class Initialized
INFO - 2023-07-03 16:00:15 --> Controller Class Initialized
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
DEBUG - 2023-07-03 16:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
INFO - 2023-07-03 16:00:15 --> Final output sent to browser
DEBUG - 2023-07-03 16:00:15 --> Total execution time: 0.0194
ERROR - 2023-07-03 16:00:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:00:15 --> Config Class Initialized
INFO - 2023-07-03 16:00:15 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:00:15 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:00:15 --> Utf8 Class Initialized
INFO - 2023-07-03 16:00:15 --> URI Class Initialized
DEBUG - 2023-07-03 16:00:15 --> No URI present. Default controller set.
INFO - 2023-07-03 16:00:15 --> Router Class Initialized
INFO - 2023-07-03 16:00:15 --> Output Class Initialized
INFO - 2023-07-03 16:00:15 --> Security Class Initialized
DEBUG - 2023-07-03 16:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:00:15 --> Input Class Initialized
INFO - 2023-07-03 16:00:15 --> Language Class Initialized
INFO - 2023-07-03 16:00:15 --> Loader Class Initialized
INFO - 2023-07-03 16:00:15 --> Helper loaded: url_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: file_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: html_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: text_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: form_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: security_helper
INFO - 2023-07-03 16:00:15 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:00:15 --> Database Driver Class Initialized
INFO - 2023-07-03 16:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:00:15 --> Parser Class Initialized
INFO - 2023-07-03 16:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:00:15 --> Pagination Class Initialized
INFO - 2023-07-03 16:00:15 --> Form Validation Class Initialized
INFO - 2023-07-03 16:00:15 --> Controller Class Initialized
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
DEBUG - 2023-07-03 16:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
DEBUG - 2023-07-03 16:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
DEBUG - 2023-07-03 16:00:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
INFO - 2023-07-03 16:00:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:00:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:00:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:00:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:00:15 --> Model Class Initialized
INFO - 2023-07-03 16:00:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:00:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:00:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:00:15 --> Final output sent to browser
DEBUG - 2023-07-03 16:00:15 --> Total execution time: 0.0773
ERROR - 2023-07-03 16:01:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:01:26 --> Config Class Initialized
INFO - 2023-07-03 16:01:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:01:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:01:26 --> Utf8 Class Initialized
INFO - 2023-07-03 16:01:26 --> URI Class Initialized
INFO - 2023-07-03 16:01:26 --> Router Class Initialized
INFO - 2023-07-03 16:01:26 --> Output Class Initialized
INFO - 2023-07-03 16:01:26 --> Security Class Initialized
DEBUG - 2023-07-03 16:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:01:26 --> Input Class Initialized
INFO - 2023-07-03 16:01:26 --> Language Class Initialized
INFO - 2023-07-03 16:01:26 --> Loader Class Initialized
INFO - 2023-07-03 16:01:26 --> Helper loaded: url_helper
INFO - 2023-07-03 16:01:26 --> Helper loaded: file_helper
INFO - 2023-07-03 16:01:26 --> Helper loaded: html_helper
INFO - 2023-07-03 16:01:26 --> Helper loaded: text_helper
INFO - 2023-07-03 16:01:26 --> Helper loaded: form_helper
INFO - 2023-07-03 16:01:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:01:26 --> Helper loaded: security_helper
INFO - 2023-07-03 16:01:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:01:26 --> Database Driver Class Initialized
INFO - 2023-07-03 16:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:01:26 --> Parser Class Initialized
INFO - 2023-07-03 16:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:01:26 --> Pagination Class Initialized
INFO - 2023-07-03 16:01:26 --> Form Validation Class Initialized
INFO - 2023-07-03 16:01:26 --> Controller Class Initialized
INFO - 2023-07-03 16:01:26 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:26 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:26 --> Model Class Initialized
INFO - 2023-07-03 16:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 16:01:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:01:26 --> Model Class Initialized
INFO - 2023-07-03 16:01:26 --> Model Class Initialized
INFO - 2023-07-03 16:01:26 --> Model Class Initialized
INFO - 2023-07-03 16:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:01:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:01:26 --> Final output sent to browser
DEBUG - 2023-07-03 16:01:26 --> Total execution time: 0.0722
ERROR - 2023-07-03 16:01:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:01:27 --> Config Class Initialized
INFO - 2023-07-03 16:01:27 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:01:27 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:01:27 --> Utf8 Class Initialized
INFO - 2023-07-03 16:01:27 --> URI Class Initialized
INFO - 2023-07-03 16:01:27 --> Router Class Initialized
INFO - 2023-07-03 16:01:27 --> Output Class Initialized
INFO - 2023-07-03 16:01:27 --> Security Class Initialized
DEBUG - 2023-07-03 16:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:01:27 --> Input Class Initialized
INFO - 2023-07-03 16:01:27 --> Language Class Initialized
INFO - 2023-07-03 16:01:27 --> Loader Class Initialized
INFO - 2023-07-03 16:01:27 --> Helper loaded: url_helper
INFO - 2023-07-03 16:01:27 --> Helper loaded: file_helper
INFO - 2023-07-03 16:01:27 --> Helper loaded: html_helper
INFO - 2023-07-03 16:01:27 --> Helper loaded: text_helper
INFO - 2023-07-03 16:01:27 --> Helper loaded: form_helper
INFO - 2023-07-03 16:01:27 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:01:27 --> Helper loaded: security_helper
INFO - 2023-07-03 16:01:27 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:01:27 --> Database Driver Class Initialized
INFO - 2023-07-03 16:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:01:27 --> Parser Class Initialized
INFO - 2023-07-03 16:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:01:27 --> Pagination Class Initialized
INFO - 2023-07-03 16:01:27 --> Form Validation Class Initialized
INFO - 2023-07-03 16:01:27 --> Controller Class Initialized
INFO - 2023-07-03 16:01:27 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:27 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:27 --> Model Class Initialized
INFO - 2023-07-03 16:01:27 --> Final output sent to browser
DEBUG - 2023-07-03 16:01:27 --> Total execution time: 0.0356
ERROR - 2023-07-03 16:01:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:01:35 --> Config Class Initialized
INFO - 2023-07-03 16:01:35 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:01:35 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:01:35 --> Utf8 Class Initialized
INFO - 2023-07-03 16:01:35 --> URI Class Initialized
INFO - 2023-07-03 16:01:35 --> Router Class Initialized
INFO - 2023-07-03 16:01:35 --> Output Class Initialized
INFO - 2023-07-03 16:01:35 --> Security Class Initialized
DEBUG - 2023-07-03 16:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:01:35 --> Input Class Initialized
INFO - 2023-07-03 16:01:35 --> Language Class Initialized
INFO - 2023-07-03 16:01:35 --> Loader Class Initialized
INFO - 2023-07-03 16:01:35 --> Helper loaded: url_helper
INFO - 2023-07-03 16:01:35 --> Helper loaded: file_helper
INFO - 2023-07-03 16:01:35 --> Helper loaded: html_helper
INFO - 2023-07-03 16:01:35 --> Helper loaded: text_helper
INFO - 2023-07-03 16:01:35 --> Helper loaded: form_helper
INFO - 2023-07-03 16:01:35 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:01:35 --> Helper loaded: security_helper
INFO - 2023-07-03 16:01:35 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:01:35 --> Database Driver Class Initialized
INFO - 2023-07-03 16:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:01:35 --> Parser Class Initialized
INFO - 2023-07-03 16:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:01:35 --> Pagination Class Initialized
INFO - 2023-07-03 16:01:35 --> Form Validation Class Initialized
INFO - 2023-07-03 16:01:35 --> Controller Class Initialized
INFO - 2023-07-03 16:01:35 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:35 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:35 --> Model Class Initialized
INFO - 2023-07-03 16:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 16:01:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:01:35 --> Model Class Initialized
INFO - 2023-07-03 16:01:35 --> Model Class Initialized
INFO - 2023-07-03 16:01:35 --> Model Class Initialized
INFO - 2023-07-03 16:01:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:01:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:01:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:01:36 --> Final output sent to browser
DEBUG - 2023-07-03 16:01:36 --> Total execution time: 0.0738
ERROR - 2023-07-03 16:01:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:01:37 --> Config Class Initialized
INFO - 2023-07-03 16:01:37 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:01:37 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:01:37 --> Utf8 Class Initialized
INFO - 2023-07-03 16:01:37 --> URI Class Initialized
INFO - 2023-07-03 16:01:37 --> Router Class Initialized
INFO - 2023-07-03 16:01:37 --> Output Class Initialized
INFO - 2023-07-03 16:01:37 --> Security Class Initialized
DEBUG - 2023-07-03 16:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:01:37 --> Input Class Initialized
INFO - 2023-07-03 16:01:37 --> Language Class Initialized
INFO - 2023-07-03 16:01:37 --> Loader Class Initialized
INFO - 2023-07-03 16:01:37 --> Helper loaded: url_helper
INFO - 2023-07-03 16:01:37 --> Helper loaded: file_helper
INFO - 2023-07-03 16:01:37 --> Helper loaded: html_helper
INFO - 2023-07-03 16:01:37 --> Helper loaded: text_helper
INFO - 2023-07-03 16:01:37 --> Helper loaded: form_helper
INFO - 2023-07-03 16:01:37 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:01:37 --> Helper loaded: security_helper
INFO - 2023-07-03 16:01:37 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:01:37 --> Database Driver Class Initialized
INFO - 2023-07-03 16:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:01:37 --> Parser Class Initialized
INFO - 2023-07-03 16:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:01:37 --> Pagination Class Initialized
INFO - 2023-07-03 16:01:37 --> Form Validation Class Initialized
INFO - 2023-07-03 16:01:37 --> Controller Class Initialized
INFO - 2023-07-03 16:01:37 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:37 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:37 --> Model Class Initialized
INFO - 2023-07-03 16:01:37 --> Final output sent to browser
DEBUG - 2023-07-03 16:01:37 --> Total execution time: 0.0457
ERROR - 2023-07-03 16:01:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:01:44 --> Config Class Initialized
INFO - 2023-07-03 16:01:44 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:01:44 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:01:44 --> Utf8 Class Initialized
INFO - 2023-07-03 16:01:44 --> URI Class Initialized
INFO - 2023-07-03 16:01:44 --> Router Class Initialized
INFO - 2023-07-03 16:01:44 --> Output Class Initialized
INFO - 2023-07-03 16:01:44 --> Security Class Initialized
DEBUG - 2023-07-03 16:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:01:44 --> Input Class Initialized
INFO - 2023-07-03 16:01:44 --> Language Class Initialized
INFO - 2023-07-03 16:01:44 --> Loader Class Initialized
INFO - 2023-07-03 16:01:44 --> Helper loaded: url_helper
INFO - 2023-07-03 16:01:44 --> Helper loaded: file_helper
INFO - 2023-07-03 16:01:44 --> Helper loaded: html_helper
INFO - 2023-07-03 16:01:44 --> Helper loaded: text_helper
INFO - 2023-07-03 16:01:44 --> Helper loaded: form_helper
INFO - 2023-07-03 16:01:44 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:01:44 --> Helper loaded: security_helper
INFO - 2023-07-03 16:01:44 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:01:44 --> Database Driver Class Initialized
INFO - 2023-07-03 16:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:01:44 --> Parser Class Initialized
INFO - 2023-07-03 16:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:01:44 --> Pagination Class Initialized
INFO - 2023-07-03 16:01:44 --> Form Validation Class Initialized
INFO - 2023-07-03 16:01:44 --> Controller Class Initialized
INFO - 2023-07-03 16:01:44 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:44 --> Model Class Initialized
DEBUG - 2023-07-03 16:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:01:44 --> Model Class Initialized
INFO - 2023-07-03 16:01:44 --> Final output sent to browser
DEBUG - 2023-07-03 16:01:44 --> Total execution time: 0.0238
ERROR - 2023-07-03 16:02:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:02:00 --> Config Class Initialized
INFO - 2023-07-03 16:02:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:02:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:02:00 --> Utf8 Class Initialized
INFO - 2023-07-03 16:02:00 --> URI Class Initialized
INFO - 2023-07-03 16:02:00 --> Router Class Initialized
INFO - 2023-07-03 16:02:00 --> Output Class Initialized
INFO - 2023-07-03 16:02:00 --> Security Class Initialized
DEBUG - 2023-07-03 16:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:02:00 --> Input Class Initialized
INFO - 2023-07-03 16:02:00 --> Language Class Initialized
INFO - 2023-07-03 16:02:00 --> Loader Class Initialized
INFO - 2023-07-03 16:02:00 --> Helper loaded: url_helper
INFO - 2023-07-03 16:02:00 --> Helper loaded: file_helper
INFO - 2023-07-03 16:02:00 --> Helper loaded: html_helper
INFO - 2023-07-03 16:02:00 --> Helper loaded: text_helper
INFO - 2023-07-03 16:02:00 --> Helper loaded: form_helper
INFO - 2023-07-03 16:02:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:02:00 --> Helper loaded: security_helper
INFO - 2023-07-03 16:02:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:02:00 --> Database Driver Class Initialized
INFO - 2023-07-03 16:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:02:00 --> Parser Class Initialized
INFO - 2023-07-03 16:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:02:00 --> Pagination Class Initialized
INFO - 2023-07-03 16:02:00 --> Form Validation Class Initialized
INFO - 2023-07-03 16:02:00 --> Controller Class Initialized
INFO - 2023-07-03 16:02:00 --> Model Class Initialized
DEBUG - 2023-07-03 16:02:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:02:00 --> Model Class Initialized
DEBUG - 2023-07-03 16:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:02:00 --> Model Class Initialized
INFO - 2023-07-03 16:02:00 --> Final output sent to browser
DEBUG - 2023-07-03 16:02:00 --> Total execution time: 0.0368
ERROR - 2023-07-03 16:02:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:02:07 --> Config Class Initialized
INFO - 2023-07-03 16:02:07 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:02:07 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:02:07 --> Utf8 Class Initialized
INFO - 2023-07-03 16:02:07 --> URI Class Initialized
INFO - 2023-07-03 16:02:07 --> Router Class Initialized
INFO - 2023-07-03 16:02:07 --> Output Class Initialized
INFO - 2023-07-03 16:02:07 --> Security Class Initialized
DEBUG - 2023-07-03 16:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:02:07 --> Input Class Initialized
INFO - 2023-07-03 16:02:07 --> Language Class Initialized
INFO - 2023-07-03 16:02:07 --> Loader Class Initialized
INFO - 2023-07-03 16:02:07 --> Helper loaded: url_helper
INFO - 2023-07-03 16:02:07 --> Helper loaded: file_helper
INFO - 2023-07-03 16:02:07 --> Helper loaded: html_helper
INFO - 2023-07-03 16:02:07 --> Helper loaded: text_helper
INFO - 2023-07-03 16:02:07 --> Helper loaded: form_helper
INFO - 2023-07-03 16:02:07 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:02:07 --> Helper loaded: security_helper
INFO - 2023-07-03 16:02:07 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:02:07 --> Database Driver Class Initialized
INFO - 2023-07-03 16:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:02:07 --> Parser Class Initialized
INFO - 2023-07-03 16:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:02:07 --> Pagination Class Initialized
INFO - 2023-07-03 16:02:07 --> Form Validation Class Initialized
INFO - 2023-07-03 16:02:07 --> Controller Class Initialized
INFO - 2023-07-03 16:02:07 --> Model Class Initialized
DEBUG - 2023-07-03 16:02:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:02:07 --> Model Class Initialized
DEBUG - 2023-07-03 16:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:02:07 --> Model Class Initialized
INFO - 2023-07-03 16:02:07 --> Final output sent to browser
DEBUG - 2023-07-03 16:02:07 --> Total execution time: 0.0365
ERROR - 2023-07-03 16:15:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:17 --> Config Class Initialized
INFO - 2023-07-03 16:15:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:17 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:17 --> URI Class Initialized
DEBUG - 2023-07-03 16:15:17 --> No URI present. Default controller set.
INFO - 2023-07-03 16:15:17 --> Router Class Initialized
INFO - 2023-07-03 16:15:17 --> Output Class Initialized
INFO - 2023-07-03 16:15:17 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:17 --> Input Class Initialized
INFO - 2023-07-03 16:15:17 --> Language Class Initialized
INFO - 2023-07-03 16:15:17 --> Loader Class Initialized
INFO - 2023-07-03 16:15:17 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:17 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:17 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:17 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:17 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:17 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:17 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:17 --> Parser Class Initialized
INFO - 2023-07-03 16:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:17 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:17 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:17 --> Controller Class Initialized
INFO - 2023-07-03 16:15:17 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 16:15:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:19 --> Config Class Initialized
INFO - 2023-07-03 16:15:19 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:19 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:19 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:19 --> URI Class Initialized
INFO - 2023-07-03 16:15:19 --> Router Class Initialized
INFO - 2023-07-03 16:15:19 --> Output Class Initialized
INFO - 2023-07-03 16:15:19 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:19 --> Input Class Initialized
INFO - 2023-07-03 16:15:19 --> Language Class Initialized
INFO - 2023-07-03 16:15:19 --> Loader Class Initialized
INFO - 2023-07-03 16:15:19 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:19 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:19 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:19 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:19 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:19 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:19 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:19 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:19 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:19 --> Parser Class Initialized
INFO - 2023-07-03 16:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:19 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:19 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:19 --> Controller Class Initialized
INFO - 2023-07-03 16:15:19 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 16:15:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:15:19 --> Model Class Initialized
INFO - 2023-07-03 16:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:15:19 --> Final output sent to browser
DEBUG - 2023-07-03 16:15:19 --> Total execution time: 0.0301
ERROR - 2023-07-03 16:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:25 --> Config Class Initialized
INFO - 2023-07-03 16:15:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:25 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:25 --> URI Class Initialized
DEBUG - 2023-07-03 16:15:25 --> No URI present. Default controller set.
INFO - 2023-07-03 16:15:25 --> Router Class Initialized
INFO - 2023-07-03 16:15:25 --> Output Class Initialized
INFO - 2023-07-03 16:15:25 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:25 --> Input Class Initialized
INFO - 2023-07-03 16:15:25 --> Language Class Initialized
INFO - 2023-07-03 16:15:25 --> Loader Class Initialized
INFO - 2023-07-03 16:15:25 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:25 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:25 --> Parser Class Initialized
INFO - 2023-07-03 16:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:25 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:25 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:25 --> Controller Class Initialized
INFO - 2023-07-03 16:15:25 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 16:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:25 --> Config Class Initialized
INFO - 2023-07-03 16:15:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:25 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:25 --> URI Class Initialized
INFO - 2023-07-03 16:15:25 --> Router Class Initialized
INFO - 2023-07-03 16:15:25 --> Output Class Initialized
INFO - 2023-07-03 16:15:25 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:25 --> Input Class Initialized
INFO - 2023-07-03 16:15:25 --> Language Class Initialized
INFO - 2023-07-03 16:15:25 --> Loader Class Initialized
INFO - 2023-07-03 16:15:25 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:25 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:25 --> Parser Class Initialized
INFO - 2023-07-03 16:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:25 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:25 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:25 --> Controller Class Initialized
INFO - 2023-07-03 16:15:25 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 16:15:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:15:25 --> Model Class Initialized
INFO - 2023-07-03 16:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:15:25 --> Final output sent to browser
DEBUG - 2023-07-03 16:15:25 --> Total execution time: 0.0276
ERROR - 2023-07-03 16:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:28 --> Config Class Initialized
INFO - 2023-07-03 16:15:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:28 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:28 --> URI Class Initialized
INFO - 2023-07-03 16:15:28 --> Router Class Initialized
INFO - 2023-07-03 16:15:28 --> Output Class Initialized
INFO - 2023-07-03 16:15:28 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:28 --> Input Class Initialized
INFO - 2023-07-03 16:15:28 --> Language Class Initialized
INFO - 2023-07-03 16:15:28 --> Loader Class Initialized
INFO - 2023-07-03 16:15:28 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:28 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:28 --> Parser Class Initialized
INFO - 2023-07-03 16:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:28 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:28 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:28 --> Controller Class Initialized
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
INFO - 2023-07-03 16:15:28 --> Final output sent to browser
DEBUG - 2023-07-03 16:15:28 --> Total execution time: 0.0169
ERROR - 2023-07-03 16:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:28 --> Config Class Initialized
INFO - 2023-07-03 16:15:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:28 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:28 --> URI Class Initialized
DEBUG - 2023-07-03 16:15:28 --> No URI present. Default controller set.
INFO - 2023-07-03 16:15:28 --> Router Class Initialized
INFO - 2023-07-03 16:15:28 --> Output Class Initialized
INFO - 2023-07-03 16:15:28 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:28 --> Input Class Initialized
INFO - 2023-07-03 16:15:28 --> Language Class Initialized
INFO - 2023-07-03 16:15:28 --> Loader Class Initialized
INFO - 2023-07-03 16:15:28 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:28 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:28 --> Parser Class Initialized
INFO - 2023-07-03 16:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:28 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:28 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:28 --> Controller Class Initialized
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
INFO - 2023-07-03 16:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:15:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:15:28 --> Model Class Initialized
INFO - 2023-07-03 16:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:15:28 --> Final output sent to browser
DEBUG - 2023-07-03 16:15:28 --> Total execution time: 0.1659
ERROR - 2023-07-03 16:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:30 --> Config Class Initialized
INFO - 2023-07-03 16:15:30 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:30 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:30 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:30 --> URI Class Initialized
INFO - 2023-07-03 16:15:30 --> Router Class Initialized
INFO - 2023-07-03 16:15:30 --> Output Class Initialized
INFO - 2023-07-03 16:15:30 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:30 --> Input Class Initialized
INFO - 2023-07-03 16:15:30 --> Language Class Initialized
INFO - 2023-07-03 16:15:30 --> Loader Class Initialized
INFO - 2023-07-03 16:15:30 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:30 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:30 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:30 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:30 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:30 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:30 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:30 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:30 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:30 --> Parser Class Initialized
INFO - 2023-07-03 16:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:30 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:30 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:30 --> Controller Class Initialized
DEBUG - 2023-07-03 16:15:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:30 --> Model Class Initialized
INFO - 2023-07-03 16:15:30 --> Final output sent to browser
DEBUG - 2023-07-03 16:15:30 --> Total execution time: 0.0141
ERROR - 2023-07-03 16:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:15:36 --> Config Class Initialized
INFO - 2023-07-03 16:15:36 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:15:36 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:15:36 --> Utf8 Class Initialized
INFO - 2023-07-03 16:15:36 --> URI Class Initialized
DEBUG - 2023-07-03 16:15:36 --> No URI present. Default controller set.
INFO - 2023-07-03 16:15:36 --> Router Class Initialized
INFO - 2023-07-03 16:15:36 --> Output Class Initialized
INFO - 2023-07-03 16:15:36 --> Security Class Initialized
DEBUG - 2023-07-03 16:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:15:36 --> Input Class Initialized
INFO - 2023-07-03 16:15:36 --> Language Class Initialized
INFO - 2023-07-03 16:15:36 --> Loader Class Initialized
INFO - 2023-07-03 16:15:36 --> Helper loaded: url_helper
INFO - 2023-07-03 16:15:36 --> Helper loaded: file_helper
INFO - 2023-07-03 16:15:36 --> Helper loaded: html_helper
INFO - 2023-07-03 16:15:36 --> Helper loaded: text_helper
INFO - 2023-07-03 16:15:36 --> Helper loaded: form_helper
INFO - 2023-07-03 16:15:36 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:15:36 --> Helper loaded: security_helper
INFO - 2023-07-03 16:15:36 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:15:36 --> Database Driver Class Initialized
INFO - 2023-07-03 16:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:15:36 --> Parser Class Initialized
INFO - 2023-07-03 16:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:15:36 --> Pagination Class Initialized
INFO - 2023-07-03 16:15:36 --> Form Validation Class Initialized
INFO - 2023-07-03 16:15:36 --> Controller Class Initialized
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
DEBUG - 2023-07-03 16:15:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
INFO - 2023-07-03 16:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:15:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:15:36 --> Model Class Initialized
INFO - 2023-07-03 16:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:15:36 --> Final output sent to browser
DEBUG - 2023-07-03 16:15:36 --> Total execution time: 0.0729
ERROR - 2023-07-03 16:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:16:50 --> Config Class Initialized
INFO - 2023-07-03 16:16:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:16:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:16:50 --> Utf8 Class Initialized
INFO - 2023-07-03 16:16:50 --> URI Class Initialized
DEBUG - 2023-07-03 16:16:50 --> No URI present. Default controller set.
INFO - 2023-07-03 16:16:50 --> Router Class Initialized
INFO - 2023-07-03 16:16:50 --> Output Class Initialized
INFO - 2023-07-03 16:16:50 --> Security Class Initialized
DEBUG - 2023-07-03 16:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:16:50 --> Input Class Initialized
INFO - 2023-07-03 16:16:50 --> Language Class Initialized
INFO - 2023-07-03 16:16:50 --> Loader Class Initialized
INFO - 2023-07-03 16:16:50 --> Helper loaded: url_helper
INFO - 2023-07-03 16:16:50 --> Helper loaded: file_helper
INFO - 2023-07-03 16:16:50 --> Helper loaded: html_helper
INFO - 2023-07-03 16:16:50 --> Helper loaded: text_helper
INFO - 2023-07-03 16:16:50 --> Helper loaded: form_helper
INFO - 2023-07-03 16:16:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:16:50 --> Helper loaded: security_helper
INFO - 2023-07-03 16:16:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:16:50 --> Database Driver Class Initialized
INFO - 2023-07-03 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:16:50 --> Parser Class Initialized
INFO - 2023-07-03 16:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:16:50 --> Pagination Class Initialized
INFO - 2023-07-03 16:16:50 --> Form Validation Class Initialized
INFO - 2023-07-03 16:16:50 --> Controller Class Initialized
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
DEBUG - 2023-07-03 16:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
DEBUG - 2023-07-03 16:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
DEBUG - 2023-07-03 16:16:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
INFO - 2023-07-03 16:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:16:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:16:50 --> Model Class Initialized
INFO - 2023-07-03 16:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:16:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:16:50 --> Final output sent to browser
DEBUG - 2023-07-03 16:16:50 --> Total execution time: 0.0728
ERROR - 2023-07-03 16:17:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:07 --> Config Class Initialized
INFO - 2023-07-03 16:17:07 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:07 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:07 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:07 --> URI Class Initialized
INFO - 2023-07-03 16:17:07 --> Router Class Initialized
INFO - 2023-07-03 16:17:07 --> Output Class Initialized
INFO - 2023-07-03 16:17:07 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:07 --> Input Class Initialized
INFO - 2023-07-03 16:17:07 --> Language Class Initialized
INFO - 2023-07-03 16:17:07 --> Loader Class Initialized
INFO - 2023-07-03 16:17:07 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:07 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:07 --> Parser Class Initialized
INFO - 2023-07-03 16:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:07 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:07 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:07 --> Controller Class Initialized
INFO - 2023-07-03 16:17:07 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:07 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:07 --> Model Class Initialized
INFO - 2023-07-03 16:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 16:17:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:17:07 --> Model Class Initialized
INFO - 2023-07-03 16:17:07 --> Model Class Initialized
INFO - 2023-07-03 16:17:07 --> Model Class Initialized
INFO - 2023-07-03 16:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:17:07 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:07 --> Total execution time: 0.1553
ERROR - 2023-07-03 16:17:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:07 --> Config Class Initialized
INFO - 2023-07-03 16:17:07 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:07 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:07 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:07 --> URI Class Initialized
INFO - 2023-07-03 16:17:07 --> Router Class Initialized
INFO - 2023-07-03 16:17:07 --> Output Class Initialized
INFO - 2023-07-03 16:17:07 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:07 --> Input Class Initialized
INFO - 2023-07-03 16:17:07 --> Language Class Initialized
INFO - 2023-07-03 16:17:07 --> Loader Class Initialized
INFO - 2023-07-03 16:17:07 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:07 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:08 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:08 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:08 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:08 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:08 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:08 --> Parser Class Initialized
INFO - 2023-07-03 16:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:08 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:08 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:08 --> Controller Class Initialized
INFO - 2023-07-03 16:17:08 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:08 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:08 --> Model Class Initialized
INFO - 2023-07-03 16:17:08 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:08 --> Total execution time: 0.0542
ERROR - 2023-07-03 16:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:10 --> Config Class Initialized
INFO - 2023-07-03 16:17:10 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:10 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:10 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:10 --> URI Class Initialized
DEBUG - 2023-07-03 16:17:10 --> No URI present. Default controller set.
INFO - 2023-07-03 16:17:10 --> Router Class Initialized
INFO - 2023-07-03 16:17:10 --> Output Class Initialized
INFO - 2023-07-03 16:17:10 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:10 --> Input Class Initialized
INFO - 2023-07-03 16:17:10 --> Language Class Initialized
INFO - 2023-07-03 16:17:10 --> Loader Class Initialized
INFO - 2023-07-03 16:17:10 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:10 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:10 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:10 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:10 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:10 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:10 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:10 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:10 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:10 --> Parser Class Initialized
INFO - 2023-07-03 16:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:10 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:10 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:10 --> Controller Class Initialized
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
INFO - 2023-07-03 16:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:17:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:17:10 --> Model Class Initialized
INFO - 2023-07-03 16:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:17:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:17:10 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:10 --> Total execution time: 0.1821
ERROR - 2023-07-03 16:17:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:21 --> Config Class Initialized
INFO - 2023-07-03 16:17:21 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:21 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:21 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:21 --> URI Class Initialized
INFO - 2023-07-03 16:17:21 --> Router Class Initialized
INFO - 2023-07-03 16:17:21 --> Output Class Initialized
INFO - 2023-07-03 16:17:21 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:21 --> Input Class Initialized
INFO - 2023-07-03 16:17:21 --> Language Class Initialized
INFO - 2023-07-03 16:17:21 --> Loader Class Initialized
INFO - 2023-07-03 16:17:21 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:21 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:21 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:21 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:21 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:21 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:21 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:21 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:21 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:21 --> Parser Class Initialized
INFO - 2023-07-03 16:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:21 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:21 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:21 --> Controller Class Initialized
INFO - 2023-07-03 16:17:21 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:21 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:21 --> Model Class Initialized
INFO - 2023-07-03 16:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 16:17:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:17:21 --> Model Class Initialized
INFO - 2023-07-03 16:17:21 --> Model Class Initialized
INFO - 2023-07-03 16:17:21 --> Model Class Initialized
INFO - 2023-07-03 16:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:17:21 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:21 --> Total execution time: 0.1472
ERROR - 2023-07-03 16:17:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:22 --> Config Class Initialized
INFO - 2023-07-03 16:17:22 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:22 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:22 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:22 --> URI Class Initialized
INFO - 2023-07-03 16:17:22 --> Router Class Initialized
INFO - 2023-07-03 16:17:22 --> Output Class Initialized
INFO - 2023-07-03 16:17:22 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:22 --> Input Class Initialized
INFO - 2023-07-03 16:17:22 --> Language Class Initialized
INFO - 2023-07-03 16:17:22 --> Loader Class Initialized
INFO - 2023-07-03 16:17:22 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:22 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:22 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:22 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:22 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:22 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:22 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:22 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:22 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:22 --> Parser Class Initialized
INFO - 2023-07-03 16:17:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:22 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:22 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:22 --> Controller Class Initialized
INFO - 2023-07-03 16:17:22 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:22 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:22 --> Model Class Initialized
INFO - 2023-07-03 16:17:22 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:22 --> Total execution time: 0.0539
ERROR - 2023-07-03 16:17:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:28 --> Config Class Initialized
INFO - 2023-07-03 16:17:28 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:28 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:28 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:28 --> URI Class Initialized
INFO - 2023-07-03 16:17:28 --> Router Class Initialized
INFO - 2023-07-03 16:17:28 --> Output Class Initialized
INFO - 2023-07-03 16:17:28 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:28 --> Input Class Initialized
INFO - 2023-07-03 16:17:28 --> Language Class Initialized
INFO - 2023-07-03 16:17:28 --> Loader Class Initialized
INFO - 2023-07-03 16:17:28 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:28 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:28 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:28 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:28 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:28 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:28 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:28 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:28 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:28 --> Parser Class Initialized
INFO - 2023-07-03 16:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:28 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:28 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:28 --> Controller Class Initialized
INFO - 2023-07-03 16:17:28 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:28 --> Model Class Initialized
DEBUG - 2023-07-03 16:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:28 --> Model Class Initialized
INFO - 2023-07-03 16:17:28 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:28 --> Total execution time: 0.3343
ERROR - 2023-07-03 16:17:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:43 --> Config Class Initialized
INFO - 2023-07-03 16:17:43 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:43 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:43 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:43 --> URI Class Initialized
INFO - 2023-07-03 16:17:43 --> Router Class Initialized
INFO - 2023-07-03 16:17:43 --> Output Class Initialized
INFO - 2023-07-03 16:17:43 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:43 --> Input Class Initialized
INFO - 2023-07-03 16:17:43 --> Language Class Initialized
INFO - 2023-07-03 16:17:43 --> Loader Class Initialized
INFO - 2023-07-03 16:17:43 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:43 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:43 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:43 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:43 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:43 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:43 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:43 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:43 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:43 --> Parser Class Initialized
INFO - 2023-07-03 16:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:43 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:43 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:43 --> Controller Class Initialized
INFO - 2023-07-03 16:17:43 --> Model Class Initialized
INFO - 2023-07-03 16:17:43 --> Model Class Initialized
INFO - 2023-07-03 16:17:43 --> Model Class Initialized
INFO - 2023-07-03 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-03 16:17:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:17:43 --> Model Class Initialized
INFO - 2023-07-03 16:17:43 --> Model Class Initialized
INFO - 2023-07-03 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:17:43 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:43 --> Total execution time: 0.1303
ERROR - 2023-07-03 16:17:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:44 --> Config Class Initialized
INFO - 2023-07-03 16:17:44 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:44 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:44 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:44 --> URI Class Initialized
INFO - 2023-07-03 16:17:44 --> Router Class Initialized
INFO - 2023-07-03 16:17:44 --> Output Class Initialized
INFO - 2023-07-03 16:17:44 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:44 --> Input Class Initialized
INFO - 2023-07-03 16:17:44 --> Language Class Initialized
INFO - 2023-07-03 16:17:44 --> Loader Class Initialized
INFO - 2023-07-03 16:17:44 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:44 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:44 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:44 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:44 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:44 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:44 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:44 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:44 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:44 --> Parser Class Initialized
INFO - 2023-07-03 16:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:44 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:44 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:44 --> Controller Class Initialized
INFO - 2023-07-03 16:17:44 --> Model Class Initialized
INFO - 2023-07-03 16:17:44 --> Model Class Initialized
INFO - 2023-07-03 16:17:44 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:44 --> Total execution time: 0.0229
ERROR - 2023-07-03 16:17:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:48 --> Config Class Initialized
INFO - 2023-07-03 16:17:48 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:48 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:48 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:48 --> URI Class Initialized
INFO - 2023-07-03 16:17:48 --> Router Class Initialized
INFO - 2023-07-03 16:17:48 --> Output Class Initialized
INFO - 2023-07-03 16:17:48 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:48 --> Input Class Initialized
INFO - 2023-07-03 16:17:48 --> Language Class Initialized
INFO - 2023-07-03 16:17:48 --> Loader Class Initialized
INFO - 2023-07-03 16:17:48 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:48 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:48 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:48 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:48 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:48 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:48 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:48 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:48 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:48 --> Parser Class Initialized
INFO - 2023-07-03 16:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:48 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:48 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:48 --> Controller Class Initialized
INFO - 2023-07-03 16:17:48 --> Model Class Initialized
INFO - 2023-07-03 16:17:48 --> Model Class Initialized
INFO - 2023-07-03 16:17:48 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:48 --> Total execution time: 0.0348
ERROR - 2023-07-03 16:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:17:51 --> Config Class Initialized
INFO - 2023-07-03 16:17:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:17:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:17:51 --> Utf8 Class Initialized
INFO - 2023-07-03 16:17:51 --> URI Class Initialized
INFO - 2023-07-03 16:17:51 --> Router Class Initialized
INFO - 2023-07-03 16:17:51 --> Output Class Initialized
INFO - 2023-07-03 16:17:51 --> Security Class Initialized
DEBUG - 2023-07-03 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:17:51 --> Input Class Initialized
INFO - 2023-07-03 16:17:51 --> Language Class Initialized
INFO - 2023-07-03 16:17:51 --> Loader Class Initialized
INFO - 2023-07-03 16:17:51 --> Helper loaded: url_helper
INFO - 2023-07-03 16:17:51 --> Helper loaded: file_helper
INFO - 2023-07-03 16:17:51 --> Helper loaded: html_helper
INFO - 2023-07-03 16:17:51 --> Helper loaded: text_helper
INFO - 2023-07-03 16:17:51 --> Helper loaded: form_helper
INFO - 2023-07-03 16:17:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:17:51 --> Helper loaded: security_helper
INFO - 2023-07-03 16:17:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:17:51 --> Database Driver Class Initialized
INFO - 2023-07-03 16:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:17:51 --> Parser Class Initialized
INFO - 2023-07-03 16:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:17:51 --> Pagination Class Initialized
INFO - 2023-07-03 16:17:51 --> Form Validation Class Initialized
INFO - 2023-07-03 16:17:51 --> Controller Class Initialized
DEBUG - 2023-07-03 16:17:51 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:51 --> Model Class Initialized
INFO - 2023-07-03 16:17:51 --> Model Class Initialized
INFO - 2023-07-03 16:17:51 --> Model Class Initialized
INFO - 2023-07-03 16:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-03 16:17:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:17:51 --> Model Class Initialized
INFO - 2023-07-03 16:17:51 --> Model Class Initialized
INFO - 2023-07-03 16:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:17:51 --> Final output sent to browser
DEBUG - 2023-07-03 16:17:51 --> Total execution time: 0.1452
ERROR - 2023-07-03 16:18:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:18:50 --> Config Class Initialized
INFO - 2023-07-03 16:18:50 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:18:50 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:18:50 --> Utf8 Class Initialized
INFO - 2023-07-03 16:18:50 --> URI Class Initialized
INFO - 2023-07-03 16:18:50 --> Router Class Initialized
INFO - 2023-07-03 16:18:50 --> Output Class Initialized
INFO - 2023-07-03 16:18:50 --> Security Class Initialized
DEBUG - 2023-07-03 16:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:18:50 --> Input Class Initialized
INFO - 2023-07-03 16:18:50 --> Language Class Initialized
INFO - 2023-07-03 16:18:50 --> Loader Class Initialized
INFO - 2023-07-03 16:18:50 --> Helper loaded: url_helper
INFO - 2023-07-03 16:18:50 --> Helper loaded: file_helper
INFO - 2023-07-03 16:18:50 --> Helper loaded: html_helper
INFO - 2023-07-03 16:18:50 --> Helper loaded: text_helper
INFO - 2023-07-03 16:18:50 --> Helper loaded: form_helper
INFO - 2023-07-03 16:18:50 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:18:50 --> Helper loaded: security_helper
INFO - 2023-07-03 16:18:50 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:18:50 --> Database Driver Class Initialized
INFO - 2023-07-03 16:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:18:50 --> Parser Class Initialized
INFO - 2023-07-03 16:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:18:50 --> Pagination Class Initialized
INFO - 2023-07-03 16:18:50 --> Form Validation Class Initialized
INFO - 2023-07-03 16:18:50 --> Controller Class Initialized
INFO - 2023-07-03 16:18:50 --> Model Class Initialized
DEBUG - 2023-07-03 16:18:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:18:50 --> Model Class Initialized
DEBUG - 2023-07-03 16:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:18:50 --> Model Class Initialized
INFO - 2023-07-03 16:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 16:18:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:18:50 --> Model Class Initialized
INFO - 2023-07-03 16:18:50 --> Model Class Initialized
INFO - 2023-07-03 16:18:50 --> Model Class Initialized
INFO - 2023-07-03 16:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:18:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:18:50 --> Final output sent to browser
DEBUG - 2023-07-03 16:18:50 --> Total execution time: 0.1287
ERROR - 2023-07-03 16:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:18:51 --> Config Class Initialized
INFO - 2023-07-03 16:18:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:18:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:18:51 --> Utf8 Class Initialized
INFO - 2023-07-03 16:18:51 --> URI Class Initialized
INFO - 2023-07-03 16:18:51 --> Router Class Initialized
INFO - 2023-07-03 16:18:51 --> Output Class Initialized
INFO - 2023-07-03 16:18:51 --> Security Class Initialized
DEBUG - 2023-07-03 16:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:18:51 --> Input Class Initialized
INFO - 2023-07-03 16:18:51 --> Language Class Initialized
INFO - 2023-07-03 16:18:51 --> Loader Class Initialized
INFO - 2023-07-03 16:18:51 --> Helper loaded: url_helper
INFO - 2023-07-03 16:18:51 --> Helper loaded: file_helper
INFO - 2023-07-03 16:18:51 --> Helper loaded: html_helper
INFO - 2023-07-03 16:18:51 --> Helper loaded: text_helper
INFO - 2023-07-03 16:18:51 --> Helper loaded: form_helper
INFO - 2023-07-03 16:18:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:18:51 --> Helper loaded: security_helper
INFO - 2023-07-03 16:18:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:18:51 --> Database Driver Class Initialized
INFO - 2023-07-03 16:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:18:51 --> Parser Class Initialized
INFO - 2023-07-03 16:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:18:51 --> Pagination Class Initialized
INFO - 2023-07-03 16:18:51 --> Form Validation Class Initialized
INFO - 2023-07-03 16:18:51 --> Controller Class Initialized
INFO - 2023-07-03 16:18:51 --> Model Class Initialized
DEBUG - 2023-07-03 16:18:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:18:51 --> Model Class Initialized
DEBUG - 2023-07-03 16:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:18:51 --> Model Class Initialized
INFO - 2023-07-03 16:18:51 --> Final output sent to browser
DEBUG - 2023-07-03 16:18:51 --> Total execution time: 0.0433
ERROR - 2023-07-03 16:18:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:18:56 --> Config Class Initialized
INFO - 2023-07-03 16:18:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:18:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:18:56 --> Utf8 Class Initialized
INFO - 2023-07-03 16:18:56 --> URI Class Initialized
INFO - 2023-07-03 16:18:56 --> Router Class Initialized
INFO - 2023-07-03 16:18:56 --> Output Class Initialized
INFO - 2023-07-03 16:18:56 --> Security Class Initialized
DEBUG - 2023-07-03 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:18:56 --> Input Class Initialized
INFO - 2023-07-03 16:18:56 --> Language Class Initialized
INFO - 2023-07-03 16:18:56 --> Loader Class Initialized
INFO - 2023-07-03 16:18:56 --> Helper loaded: url_helper
INFO - 2023-07-03 16:18:56 --> Helper loaded: file_helper
INFO - 2023-07-03 16:18:56 --> Helper loaded: html_helper
INFO - 2023-07-03 16:18:56 --> Helper loaded: text_helper
INFO - 2023-07-03 16:18:56 --> Helper loaded: form_helper
INFO - 2023-07-03 16:18:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:18:56 --> Helper loaded: security_helper
INFO - 2023-07-03 16:18:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:18:56 --> Database Driver Class Initialized
INFO - 2023-07-03 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:18:56 --> Parser Class Initialized
INFO - 2023-07-03 16:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:18:56 --> Pagination Class Initialized
INFO - 2023-07-03 16:18:56 --> Form Validation Class Initialized
INFO - 2023-07-03 16:18:56 --> Controller Class Initialized
INFO - 2023-07-03 16:18:56 --> Model Class Initialized
DEBUG - 2023-07-03 16:18:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:18:56 --> Model Class Initialized
DEBUG - 2023-07-03 16:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:18:56 --> Model Class Initialized
INFO - 2023-07-03 16:18:56 --> Final output sent to browser
DEBUG - 2023-07-03 16:18:56 --> Total execution time: 0.0493
ERROR - 2023-07-03 16:19:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:19:01 --> Config Class Initialized
INFO - 2023-07-03 16:19:01 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:19:01 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:19:01 --> Utf8 Class Initialized
INFO - 2023-07-03 16:19:01 --> URI Class Initialized
INFO - 2023-07-03 16:19:01 --> Router Class Initialized
INFO - 2023-07-03 16:19:01 --> Output Class Initialized
INFO - 2023-07-03 16:19:01 --> Security Class Initialized
DEBUG - 2023-07-03 16:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:19:01 --> Input Class Initialized
INFO - 2023-07-03 16:19:01 --> Language Class Initialized
INFO - 2023-07-03 16:19:01 --> Loader Class Initialized
INFO - 2023-07-03 16:19:01 --> Helper loaded: url_helper
INFO - 2023-07-03 16:19:01 --> Helper loaded: file_helper
INFO - 2023-07-03 16:19:01 --> Helper loaded: html_helper
INFO - 2023-07-03 16:19:01 --> Helper loaded: text_helper
INFO - 2023-07-03 16:19:01 --> Helper loaded: form_helper
INFO - 2023-07-03 16:19:01 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:19:01 --> Helper loaded: security_helper
INFO - 2023-07-03 16:19:01 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:19:01 --> Database Driver Class Initialized
INFO - 2023-07-03 16:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:19:01 --> Parser Class Initialized
INFO - 2023-07-03 16:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:19:01 --> Pagination Class Initialized
INFO - 2023-07-03 16:19:01 --> Form Validation Class Initialized
INFO - 2023-07-03 16:19:01 --> Controller Class Initialized
INFO - 2023-07-03 16:19:01 --> Model Class Initialized
DEBUG - 2023-07-03 16:19:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:19:01 --> Model Class Initialized
DEBUG - 2023-07-03 16:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:19:01 --> Model Class Initialized
INFO - 2023-07-03 16:19:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 16:19:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:19:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:19:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:19:01 --> Model Class Initialized
INFO - 2023-07-03 16:19:01 --> Model Class Initialized
INFO - 2023-07-03 16:19:01 --> Model Class Initialized
INFO - 2023-07-03 16:19:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:19:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:19:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:19:01 --> Final output sent to browser
DEBUG - 2023-07-03 16:19:01 --> Total execution time: 0.1441
ERROR - 2023-07-03 16:19:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:19:02 --> Config Class Initialized
INFO - 2023-07-03 16:19:02 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:19:02 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:19:02 --> Utf8 Class Initialized
INFO - 2023-07-03 16:19:02 --> URI Class Initialized
INFO - 2023-07-03 16:19:02 --> Router Class Initialized
INFO - 2023-07-03 16:19:02 --> Output Class Initialized
INFO - 2023-07-03 16:19:02 --> Security Class Initialized
DEBUG - 2023-07-03 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:19:02 --> Input Class Initialized
INFO - 2023-07-03 16:19:02 --> Language Class Initialized
INFO - 2023-07-03 16:19:02 --> Loader Class Initialized
INFO - 2023-07-03 16:19:02 --> Helper loaded: url_helper
INFO - 2023-07-03 16:19:02 --> Helper loaded: file_helper
INFO - 2023-07-03 16:19:02 --> Helper loaded: html_helper
INFO - 2023-07-03 16:19:02 --> Helper loaded: text_helper
INFO - 2023-07-03 16:19:02 --> Helper loaded: form_helper
INFO - 2023-07-03 16:19:02 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:19:02 --> Helper loaded: security_helper
INFO - 2023-07-03 16:19:02 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:19:02 --> Database Driver Class Initialized
INFO - 2023-07-03 16:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:19:02 --> Parser Class Initialized
INFO - 2023-07-03 16:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:19:02 --> Pagination Class Initialized
INFO - 2023-07-03 16:19:02 --> Form Validation Class Initialized
INFO - 2023-07-03 16:19:02 --> Controller Class Initialized
INFO - 2023-07-03 16:19:02 --> Model Class Initialized
DEBUG - 2023-07-03 16:19:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:19:02 --> Model Class Initialized
DEBUG - 2023-07-03 16:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:19:02 --> Model Class Initialized
INFO - 2023-07-03 16:19:02 --> Final output sent to browser
DEBUG - 2023-07-03 16:19:02 --> Total execution time: 0.0525
ERROR - 2023-07-03 16:19:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:19:06 --> Config Class Initialized
INFO - 2023-07-03 16:19:06 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:19:06 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:19:06 --> Utf8 Class Initialized
INFO - 2023-07-03 16:19:06 --> URI Class Initialized
INFO - 2023-07-03 16:19:06 --> Router Class Initialized
INFO - 2023-07-03 16:19:06 --> Output Class Initialized
INFO - 2023-07-03 16:19:06 --> Security Class Initialized
DEBUG - 2023-07-03 16:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:19:06 --> Input Class Initialized
INFO - 2023-07-03 16:19:06 --> Language Class Initialized
INFO - 2023-07-03 16:19:06 --> Loader Class Initialized
INFO - 2023-07-03 16:19:06 --> Helper loaded: url_helper
INFO - 2023-07-03 16:19:06 --> Helper loaded: file_helper
INFO - 2023-07-03 16:19:06 --> Helper loaded: html_helper
INFO - 2023-07-03 16:19:06 --> Helper loaded: text_helper
INFO - 2023-07-03 16:19:06 --> Helper loaded: form_helper
INFO - 2023-07-03 16:19:06 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:19:06 --> Helper loaded: security_helper
INFO - 2023-07-03 16:19:06 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:19:06 --> Database Driver Class Initialized
INFO - 2023-07-03 16:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:19:06 --> Parser Class Initialized
INFO - 2023-07-03 16:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:19:06 --> Pagination Class Initialized
INFO - 2023-07-03 16:19:06 --> Form Validation Class Initialized
INFO - 2023-07-03 16:19:06 --> Controller Class Initialized
INFO - 2023-07-03 16:19:06 --> Model Class Initialized
DEBUG - 2023-07-03 16:19:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:19:06 --> Model Class Initialized
DEBUG - 2023-07-03 16:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:19:06 --> Model Class Initialized
INFO - 2023-07-03 16:19:06 --> Final output sent to browser
DEBUG - 2023-07-03 16:19:06 --> Total execution time: 0.3301
ERROR - 2023-07-03 16:20:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:20:13 --> Config Class Initialized
INFO - 2023-07-03 16:20:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:20:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:20:13 --> Utf8 Class Initialized
INFO - 2023-07-03 16:20:13 --> URI Class Initialized
INFO - 2023-07-03 16:20:13 --> Router Class Initialized
INFO - 2023-07-03 16:20:13 --> Output Class Initialized
INFO - 2023-07-03 16:20:13 --> Security Class Initialized
DEBUG - 2023-07-03 16:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:20:13 --> Input Class Initialized
INFO - 2023-07-03 16:20:13 --> Language Class Initialized
INFO - 2023-07-03 16:20:13 --> Loader Class Initialized
INFO - 2023-07-03 16:20:13 --> Helper loaded: url_helper
INFO - 2023-07-03 16:20:13 --> Helper loaded: file_helper
INFO - 2023-07-03 16:20:13 --> Helper loaded: html_helper
INFO - 2023-07-03 16:20:13 --> Helper loaded: text_helper
INFO - 2023-07-03 16:20:13 --> Helper loaded: form_helper
INFO - 2023-07-03 16:20:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:20:13 --> Helper loaded: security_helper
INFO - 2023-07-03 16:20:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:20:13 --> Database Driver Class Initialized
INFO - 2023-07-03 16:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:20:13 --> Parser Class Initialized
INFO - 2023-07-03 16:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:20:13 --> Pagination Class Initialized
INFO - 2023-07-03 16:20:13 --> Form Validation Class Initialized
INFO - 2023-07-03 16:20:13 --> Controller Class Initialized
INFO - 2023-07-03 16:20:13 --> Model Class Initialized
DEBUG - 2023-07-03 16:20:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:20:13 --> Model Class Initialized
DEBUG - 2023-07-03 16:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:20:13 --> Model Class Initialized
INFO - 2023-07-03 16:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 16:20:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:20:13 --> Model Class Initialized
INFO - 2023-07-03 16:20:13 --> Model Class Initialized
INFO - 2023-07-03 16:20:13 --> Model Class Initialized
INFO - 2023-07-03 16:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:20:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:20:13 --> Final output sent to browser
DEBUG - 2023-07-03 16:20:13 --> Total execution time: 0.1442
ERROR - 2023-07-03 16:20:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:20:14 --> Config Class Initialized
INFO - 2023-07-03 16:20:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:20:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:20:14 --> Utf8 Class Initialized
INFO - 2023-07-03 16:20:14 --> URI Class Initialized
INFO - 2023-07-03 16:20:14 --> Router Class Initialized
INFO - 2023-07-03 16:20:14 --> Output Class Initialized
INFO - 2023-07-03 16:20:14 --> Security Class Initialized
DEBUG - 2023-07-03 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:20:14 --> Input Class Initialized
INFO - 2023-07-03 16:20:14 --> Language Class Initialized
INFO - 2023-07-03 16:20:14 --> Loader Class Initialized
INFO - 2023-07-03 16:20:14 --> Helper loaded: url_helper
INFO - 2023-07-03 16:20:14 --> Helper loaded: file_helper
INFO - 2023-07-03 16:20:14 --> Helper loaded: html_helper
INFO - 2023-07-03 16:20:14 --> Helper loaded: text_helper
INFO - 2023-07-03 16:20:14 --> Helper loaded: form_helper
INFO - 2023-07-03 16:20:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:20:14 --> Helper loaded: security_helper
INFO - 2023-07-03 16:20:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:20:14 --> Database Driver Class Initialized
INFO - 2023-07-03 16:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:20:14 --> Parser Class Initialized
INFO - 2023-07-03 16:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:20:14 --> Pagination Class Initialized
INFO - 2023-07-03 16:20:14 --> Form Validation Class Initialized
INFO - 2023-07-03 16:20:14 --> Controller Class Initialized
INFO - 2023-07-03 16:20:14 --> Model Class Initialized
DEBUG - 2023-07-03 16:20:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:20:14 --> Model Class Initialized
DEBUG - 2023-07-03 16:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:20:14 --> Model Class Initialized
INFO - 2023-07-03 16:20:14 --> Final output sent to browser
DEBUG - 2023-07-03 16:20:14 --> Total execution time: 0.0554
ERROR - 2023-07-03 16:21:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:02 --> Config Class Initialized
INFO - 2023-07-03 16:21:02 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:02 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:02 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:02 --> URI Class Initialized
DEBUG - 2023-07-03 16:21:02 --> No URI present. Default controller set.
INFO - 2023-07-03 16:21:02 --> Router Class Initialized
INFO - 2023-07-03 16:21:02 --> Output Class Initialized
INFO - 2023-07-03 16:21:02 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:02 --> Input Class Initialized
INFO - 2023-07-03 16:21:02 --> Language Class Initialized
INFO - 2023-07-03 16:21:02 --> Loader Class Initialized
INFO - 2023-07-03 16:21:02 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:02 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:02 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:02 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:02 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:02 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:02 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:02 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:02 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:02 --> Parser Class Initialized
INFO - 2023-07-03 16:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:02 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:02 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:02 --> Controller Class Initialized
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
INFO - 2023-07-03 16:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:21:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:21:02 --> Model Class Initialized
INFO - 2023-07-03 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:21:03 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:03 --> Total execution time: 0.1951
ERROR - 2023-07-03 16:21:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:05 --> Config Class Initialized
INFO - 2023-07-03 16:21:05 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:05 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:05 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:05 --> URI Class Initialized
DEBUG - 2023-07-03 16:21:05 --> No URI present. Default controller set.
INFO - 2023-07-03 16:21:05 --> Router Class Initialized
INFO - 2023-07-03 16:21:05 --> Output Class Initialized
INFO - 2023-07-03 16:21:05 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:05 --> Input Class Initialized
INFO - 2023-07-03 16:21:05 --> Language Class Initialized
INFO - 2023-07-03 16:21:05 --> Loader Class Initialized
INFO - 2023-07-03 16:21:05 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:05 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:05 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:05 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:05 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:05 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:05 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:05 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:05 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:05 --> Parser Class Initialized
INFO - 2023-07-03 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:05 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:05 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:05 --> Controller Class Initialized
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
INFO - 2023-07-03 16:21:05 --> Model Class Initialized
INFO - 2023-07-03 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:21:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:21:06 --> Model Class Initialized
INFO - 2023-07-03 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:21:06 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:06 --> Total execution time: 0.2026
ERROR - 2023-07-03 16:21:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:31 --> Config Class Initialized
INFO - 2023-07-03 16:21:31 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:31 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:31 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:31 --> URI Class Initialized
INFO - 2023-07-03 16:21:31 --> Router Class Initialized
INFO - 2023-07-03 16:21:31 --> Output Class Initialized
INFO - 2023-07-03 16:21:31 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:31 --> Input Class Initialized
INFO - 2023-07-03 16:21:31 --> Language Class Initialized
INFO - 2023-07-03 16:21:31 --> Loader Class Initialized
INFO - 2023-07-03 16:21:31 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:31 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:31 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:31 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:31 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:31 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:31 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:31 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:31 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:31 --> Parser Class Initialized
INFO - 2023-07-03 16:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:31 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:31 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:31 --> Controller Class Initialized
INFO - 2023-07-03 16:21:31 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:31 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:31 --> Model Class Initialized
INFO - 2023-07-03 16:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-03 16:21:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:21:31 --> Model Class Initialized
INFO - 2023-07-03 16:21:31 --> Model Class Initialized
INFO - 2023-07-03 16:21:31 --> Model Class Initialized
INFO - 2023-07-03 16:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:21:31 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:31 --> Total execution time: 0.1418
ERROR - 2023-07-03 16:21:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:32 --> Config Class Initialized
INFO - 2023-07-03 16:21:32 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:32 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:32 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:32 --> URI Class Initialized
INFO - 2023-07-03 16:21:32 --> Router Class Initialized
INFO - 2023-07-03 16:21:32 --> Output Class Initialized
INFO - 2023-07-03 16:21:32 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:32 --> Input Class Initialized
INFO - 2023-07-03 16:21:32 --> Language Class Initialized
INFO - 2023-07-03 16:21:32 --> Loader Class Initialized
INFO - 2023-07-03 16:21:32 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:32 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:32 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:32 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:32 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:32 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:32 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:32 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:32 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:32 --> Parser Class Initialized
INFO - 2023-07-03 16:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:32 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:32 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:32 --> Controller Class Initialized
INFO - 2023-07-03 16:21:32 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:32 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:32 --> Model Class Initialized
INFO - 2023-07-03 16:21:32 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:32 --> Total execution time: 0.0485
ERROR - 2023-07-03 16:21:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:36 --> Config Class Initialized
INFO - 2023-07-03 16:21:36 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:36 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:36 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:36 --> URI Class Initialized
INFO - 2023-07-03 16:21:36 --> Router Class Initialized
INFO - 2023-07-03 16:21:36 --> Output Class Initialized
INFO - 2023-07-03 16:21:36 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:36 --> Input Class Initialized
INFO - 2023-07-03 16:21:36 --> Language Class Initialized
INFO - 2023-07-03 16:21:36 --> Loader Class Initialized
INFO - 2023-07-03 16:21:36 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:36 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:36 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:36 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:36 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:36 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:36 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:36 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:36 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:36 --> Parser Class Initialized
INFO - 2023-07-03 16:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:36 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:36 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:36 --> Controller Class Initialized
INFO - 2023-07-03 16:21:36 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:36 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:36 --> Model Class Initialized
INFO - 2023-07-03 16:21:36 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:36 --> Total execution time: 0.0598
ERROR - 2023-07-03 16:21:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:41 --> Config Class Initialized
INFO - 2023-07-03 16:21:41 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:41 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:41 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:41 --> URI Class Initialized
INFO - 2023-07-03 16:21:41 --> Router Class Initialized
INFO - 2023-07-03 16:21:41 --> Output Class Initialized
INFO - 2023-07-03 16:21:41 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:41 --> Input Class Initialized
INFO - 2023-07-03 16:21:41 --> Language Class Initialized
INFO - 2023-07-03 16:21:41 --> Loader Class Initialized
INFO - 2023-07-03 16:21:41 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:41 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:41 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:41 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:41 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:41 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:41 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:41 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:41 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:41 --> Parser Class Initialized
INFO - 2023-07-03 16:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:41 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:41 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:41 --> Controller Class Initialized
INFO - 2023-07-03 16:21:41 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:41 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:41 --> Model Class Initialized
INFO - 2023-07-03 16:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 16:21:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:21:41 --> Model Class Initialized
INFO - 2023-07-03 16:21:41 --> Model Class Initialized
INFO - 2023-07-03 16:21:41 --> Model Class Initialized
INFO - 2023-07-03 16:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:21:41 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:41 --> Total execution time: 0.1499
ERROR - 2023-07-03 16:21:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:42 --> Config Class Initialized
INFO - 2023-07-03 16:21:42 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:42 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:42 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:42 --> URI Class Initialized
INFO - 2023-07-03 16:21:42 --> Router Class Initialized
INFO - 2023-07-03 16:21:42 --> Output Class Initialized
INFO - 2023-07-03 16:21:42 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:42 --> Input Class Initialized
INFO - 2023-07-03 16:21:42 --> Language Class Initialized
INFO - 2023-07-03 16:21:42 --> Loader Class Initialized
INFO - 2023-07-03 16:21:42 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:42 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:42 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:42 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:42 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:42 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:42 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:42 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:42 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:42 --> Parser Class Initialized
INFO - 2023-07-03 16:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:42 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:42 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:42 --> Controller Class Initialized
INFO - 2023-07-03 16:21:42 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:42 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:42 --> Model Class Initialized
INFO - 2023-07-03 16:21:42 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:42 --> Total execution time: 0.0587
ERROR - 2023-07-03 16:21:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:45 --> Config Class Initialized
INFO - 2023-07-03 16:21:45 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:45 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:45 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:45 --> URI Class Initialized
INFO - 2023-07-03 16:21:45 --> Router Class Initialized
INFO - 2023-07-03 16:21:45 --> Output Class Initialized
INFO - 2023-07-03 16:21:45 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:45 --> Input Class Initialized
INFO - 2023-07-03 16:21:45 --> Language Class Initialized
INFO - 2023-07-03 16:21:45 --> Loader Class Initialized
INFO - 2023-07-03 16:21:45 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:45 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:45 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:45 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:45 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:45 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:45 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:45 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:45 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:45 --> Parser Class Initialized
INFO - 2023-07-03 16:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:45 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:45 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:45 --> Controller Class Initialized
INFO - 2023-07-03 16:21:45 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:45 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:45 --> Model Class Initialized
INFO - 2023-07-03 16:21:45 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:45 --> Total execution time: 0.3314
ERROR - 2023-07-03 16:21:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:55 --> Config Class Initialized
INFO - 2023-07-03 16:21:55 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:55 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:55 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:55 --> URI Class Initialized
INFO - 2023-07-03 16:21:55 --> Router Class Initialized
INFO - 2023-07-03 16:21:55 --> Output Class Initialized
INFO - 2023-07-03 16:21:55 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:55 --> Input Class Initialized
INFO - 2023-07-03 16:21:55 --> Language Class Initialized
INFO - 2023-07-03 16:21:55 --> Loader Class Initialized
INFO - 2023-07-03 16:21:55 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:55 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:55 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:55 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:55 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:55 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:55 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:55 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:55 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:55 --> Parser Class Initialized
INFO - 2023-07-03 16:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:55 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:55 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:55 --> Controller Class Initialized
INFO - 2023-07-03 16:21:55 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:55 --> Model Class Initialized
INFO - 2023-07-03 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-03 16:21:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:21:55 --> Model Class Initialized
INFO - 2023-07-03 16:21:55 --> Model Class Initialized
INFO - 2023-07-03 16:21:55 --> Model Class Initialized
INFO - 2023-07-03 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:21:55 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:55 --> Total execution time: 0.1502
ERROR - 2023-07-03 16:21:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:21:56 --> Config Class Initialized
INFO - 2023-07-03 16:21:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:21:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:21:56 --> Utf8 Class Initialized
INFO - 2023-07-03 16:21:56 --> URI Class Initialized
INFO - 2023-07-03 16:21:56 --> Router Class Initialized
INFO - 2023-07-03 16:21:56 --> Output Class Initialized
INFO - 2023-07-03 16:21:56 --> Security Class Initialized
DEBUG - 2023-07-03 16:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:21:56 --> Input Class Initialized
INFO - 2023-07-03 16:21:56 --> Language Class Initialized
INFO - 2023-07-03 16:21:56 --> Loader Class Initialized
INFO - 2023-07-03 16:21:56 --> Helper loaded: url_helper
INFO - 2023-07-03 16:21:56 --> Helper loaded: file_helper
INFO - 2023-07-03 16:21:56 --> Helper loaded: html_helper
INFO - 2023-07-03 16:21:56 --> Helper loaded: text_helper
INFO - 2023-07-03 16:21:56 --> Helper loaded: form_helper
INFO - 2023-07-03 16:21:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:21:56 --> Helper loaded: security_helper
INFO - 2023-07-03 16:21:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:21:56 --> Database Driver Class Initialized
INFO - 2023-07-03 16:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:21:56 --> Parser Class Initialized
INFO - 2023-07-03 16:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:21:56 --> Pagination Class Initialized
INFO - 2023-07-03 16:21:56 --> Form Validation Class Initialized
INFO - 2023-07-03 16:21:56 --> Controller Class Initialized
INFO - 2023-07-03 16:21:56 --> Model Class Initialized
DEBUG - 2023-07-03 16:21:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:21:56 --> Model Class Initialized
INFO - 2023-07-03 16:21:56 --> Final output sent to browser
DEBUG - 2023-07-03 16:21:56 --> Total execution time: 0.0274
ERROR - 2023-07-03 16:22:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:22:00 --> Config Class Initialized
INFO - 2023-07-03 16:22:00 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:22:00 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:22:00 --> Utf8 Class Initialized
INFO - 2023-07-03 16:22:00 --> URI Class Initialized
INFO - 2023-07-03 16:22:00 --> Router Class Initialized
INFO - 2023-07-03 16:22:00 --> Output Class Initialized
INFO - 2023-07-03 16:22:00 --> Security Class Initialized
DEBUG - 2023-07-03 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:22:00 --> Input Class Initialized
INFO - 2023-07-03 16:22:00 --> Language Class Initialized
INFO - 2023-07-03 16:22:00 --> Loader Class Initialized
INFO - 2023-07-03 16:22:00 --> Helper loaded: url_helper
INFO - 2023-07-03 16:22:00 --> Helper loaded: file_helper
INFO - 2023-07-03 16:22:00 --> Helper loaded: html_helper
INFO - 2023-07-03 16:22:00 --> Helper loaded: text_helper
INFO - 2023-07-03 16:22:00 --> Helper loaded: form_helper
INFO - 2023-07-03 16:22:00 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:22:00 --> Helper loaded: security_helper
INFO - 2023-07-03 16:22:00 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:22:00 --> Database Driver Class Initialized
INFO - 2023-07-03 16:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:22:00 --> Parser Class Initialized
INFO - 2023-07-03 16:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:22:00 --> Pagination Class Initialized
INFO - 2023-07-03 16:22:00 --> Form Validation Class Initialized
INFO - 2023-07-03 16:22:00 --> Controller Class Initialized
INFO - 2023-07-03 16:22:00 --> Model Class Initialized
DEBUG - 2023-07-03 16:22:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:00 --> Model Class Initialized
INFO - 2023-07-03 16:22:00 --> Final output sent to browser
DEBUG - 2023-07-03 16:22:00 --> Total execution time: 0.0766
ERROR - 2023-07-03 16:22:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:22:26 --> Config Class Initialized
INFO - 2023-07-03 16:22:26 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:22:26 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:22:26 --> Utf8 Class Initialized
INFO - 2023-07-03 16:22:26 --> URI Class Initialized
INFO - 2023-07-03 16:22:26 --> Router Class Initialized
INFO - 2023-07-03 16:22:26 --> Output Class Initialized
INFO - 2023-07-03 16:22:26 --> Security Class Initialized
DEBUG - 2023-07-03 16:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:22:26 --> Input Class Initialized
INFO - 2023-07-03 16:22:26 --> Language Class Initialized
INFO - 2023-07-03 16:22:26 --> Loader Class Initialized
INFO - 2023-07-03 16:22:26 --> Helper loaded: url_helper
INFO - 2023-07-03 16:22:26 --> Helper loaded: file_helper
INFO - 2023-07-03 16:22:26 --> Helper loaded: html_helper
INFO - 2023-07-03 16:22:26 --> Helper loaded: text_helper
INFO - 2023-07-03 16:22:26 --> Helper loaded: form_helper
INFO - 2023-07-03 16:22:26 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:22:26 --> Helper loaded: security_helper
INFO - 2023-07-03 16:22:26 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:22:26 --> Database Driver Class Initialized
INFO - 2023-07-03 16:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:22:26 --> Parser Class Initialized
INFO - 2023-07-03 16:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:22:26 --> Pagination Class Initialized
INFO - 2023-07-03 16:22:26 --> Form Validation Class Initialized
INFO - 2023-07-03 16:22:26 --> Controller Class Initialized
DEBUG - 2023-07-03 16:22:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:26 --> Model Class Initialized
DEBUG - 2023-07-03 16:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:26 --> Model Class Initialized
DEBUG - 2023-07-03 16:22:26 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:26 --> Model Class Initialized
INFO - 2023-07-03 16:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-03 16:22:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:22:26 --> Model Class Initialized
INFO - 2023-07-03 16:22:26 --> Model Class Initialized
INFO - 2023-07-03 16:22:26 --> Model Class Initialized
INFO - 2023-07-03 16:22:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:22:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:22:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:22:27 --> Final output sent to browser
DEBUG - 2023-07-03 16:22:27 --> Total execution time: 0.1499
ERROR - 2023-07-03 16:22:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:22:27 --> Config Class Initialized
INFO - 2023-07-03 16:22:27 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:22:27 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:22:27 --> Utf8 Class Initialized
INFO - 2023-07-03 16:22:27 --> URI Class Initialized
INFO - 2023-07-03 16:22:27 --> Router Class Initialized
INFO - 2023-07-03 16:22:27 --> Output Class Initialized
INFO - 2023-07-03 16:22:27 --> Security Class Initialized
DEBUG - 2023-07-03 16:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:22:27 --> Input Class Initialized
INFO - 2023-07-03 16:22:27 --> Language Class Initialized
INFO - 2023-07-03 16:22:27 --> Loader Class Initialized
INFO - 2023-07-03 16:22:27 --> Helper loaded: url_helper
INFO - 2023-07-03 16:22:27 --> Helper loaded: file_helper
INFO - 2023-07-03 16:22:27 --> Helper loaded: html_helper
INFO - 2023-07-03 16:22:27 --> Helper loaded: text_helper
INFO - 2023-07-03 16:22:27 --> Helper loaded: form_helper
INFO - 2023-07-03 16:22:27 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:22:27 --> Helper loaded: security_helper
INFO - 2023-07-03 16:22:27 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:22:27 --> Database Driver Class Initialized
INFO - 2023-07-03 16:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:22:27 --> Parser Class Initialized
INFO - 2023-07-03 16:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:22:27 --> Pagination Class Initialized
INFO - 2023-07-03 16:22:27 --> Form Validation Class Initialized
INFO - 2023-07-03 16:22:27 --> Controller Class Initialized
DEBUG - 2023-07-03 16:22:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:27 --> Model Class Initialized
DEBUG - 2023-07-03 16:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:27 --> Model Class Initialized
INFO - 2023-07-03 16:22:27 --> Final output sent to browser
DEBUG - 2023-07-03 16:22:27 --> Total execution time: 0.0319
ERROR - 2023-07-03 16:22:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:22:30 --> Config Class Initialized
INFO - 2023-07-03 16:22:30 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:22:30 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:22:30 --> Utf8 Class Initialized
INFO - 2023-07-03 16:22:30 --> URI Class Initialized
INFO - 2023-07-03 16:22:30 --> Router Class Initialized
INFO - 2023-07-03 16:22:30 --> Output Class Initialized
INFO - 2023-07-03 16:22:30 --> Security Class Initialized
DEBUG - 2023-07-03 16:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:22:30 --> Input Class Initialized
INFO - 2023-07-03 16:22:30 --> Language Class Initialized
INFO - 2023-07-03 16:22:30 --> Loader Class Initialized
INFO - 2023-07-03 16:22:30 --> Helper loaded: url_helper
INFO - 2023-07-03 16:22:30 --> Helper loaded: file_helper
INFO - 2023-07-03 16:22:30 --> Helper loaded: html_helper
INFO - 2023-07-03 16:22:30 --> Helper loaded: text_helper
INFO - 2023-07-03 16:22:30 --> Helper loaded: form_helper
INFO - 2023-07-03 16:22:30 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:22:30 --> Helper loaded: security_helper
INFO - 2023-07-03 16:22:30 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:22:30 --> Database Driver Class Initialized
INFO - 2023-07-03 16:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:22:30 --> Parser Class Initialized
INFO - 2023-07-03 16:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:22:30 --> Pagination Class Initialized
INFO - 2023-07-03 16:22:30 --> Form Validation Class Initialized
INFO - 2023-07-03 16:22:30 --> Controller Class Initialized
DEBUG - 2023-07-03 16:22:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:30 --> Model Class Initialized
DEBUG - 2023-07-03 16:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:22:30 --> Model Class Initialized
INFO - 2023-07-03 16:22:31 --> Final output sent to browser
DEBUG - 2023-07-03 16:22:31 --> Total execution time: 0.1347
ERROR - 2023-07-03 16:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:24:13 --> Config Class Initialized
INFO - 2023-07-03 16:24:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:24:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:24:13 --> Utf8 Class Initialized
INFO - 2023-07-03 16:24:13 --> URI Class Initialized
INFO - 2023-07-03 16:24:13 --> Router Class Initialized
INFO - 2023-07-03 16:24:13 --> Output Class Initialized
INFO - 2023-07-03 16:24:13 --> Security Class Initialized
DEBUG - 2023-07-03 16:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:24:13 --> Input Class Initialized
INFO - 2023-07-03 16:24:13 --> Language Class Initialized
INFO - 2023-07-03 16:24:13 --> Loader Class Initialized
INFO - 2023-07-03 16:24:13 --> Helper loaded: url_helper
INFO - 2023-07-03 16:24:13 --> Helper loaded: file_helper
INFO - 2023-07-03 16:24:13 --> Helper loaded: html_helper
INFO - 2023-07-03 16:24:13 --> Helper loaded: text_helper
INFO - 2023-07-03 16:24:13 --> Helper loaded: form_helper
INFO - 2023-07-03 16:24:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:24:13 --> Helper loaded: security_helper
INFO - 2023-07-03 16:24:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:24:13 --> Database Driver Class Initialized
INFO - 2023-07-03 16:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:24:13 --> Parser Class Initialized
INFO - 2023-07-03 16:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:24:13 --> Pagination Class Initialized
INFO - 2023-07-03 16:24:13 --> Form Validation Class Initialized
INFO - 2023-07-03 16:24:13 --> Controller Class Initialized
DEBUG - 2023-07-03 16:24:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:13 --> Model Class Initialized
DEBUG - 2023-07-03 16:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:13 --> Model Class Initialized
INFO - 2023-07-03 16:24:13 --> Final output sent to browser
DEBUG - 2023-07-03 16:24:13 --> Total execution time: 0.0991
ERROR - 2023-07-03 16:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:24:14 --> Config Class Initialized
INFO - 2023-07-03 16:24:14 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:24:14 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:24:14 --> Utf8 Class Initialized
INFO - 2023-07-03 16:24:14 --> URI Class Initialized
INFO - 2023-07-03 16:24:14 --> Router Class Initialized
INFO - 2023-07-03 16:24:14 --> Output Class Initialized
INFO - 2023-07-03 16:24:14 --> Security Class Initialized
DEBUG - 2023-07-03 16:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:24:14 --> Input Class Initialized
INFO - 2023-07-03 16:24:14 --> Language Class Initialized
INFO - 2023-07-03 16:24:14 --> Loader Class Initialized
INFO - 2023-07-03 16:24:14 --> Helper loaded: url_helper
INFO - 2023-07-03 16:24:14 --> Helper loaded: file_helper
INFO - 2023-07-03 16:24:14 --> Helper loaded: html_helper
INFO - 2023-07-03 16:24:14 --> Helper loaded: text_helper
INFO - 2023-07-03 16:24:14 --> Helper loaded: form_helper
INFO - 2023-07-03 16:24:14 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:24:14 --> Helper loaded: security_helper
INFO - 2023-07-03 16:24:14 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:24:14 --> Database Driver Class Initialized
INFO - 2023-07-03 16:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:24:14 --> Parser Class Initialized
INFO - 2023-07-03 16:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:24:14 --> Pagination Class Initialized
INFO - 2023-07-03 16:24:14 --> Form Validation Class Initialized
INFO - 2023-07-03 16:24:14 --> Controller Class Initialized
DEBUG - 2023-07-03 16:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:14 --> Model Class Initialized
DEBUG - 2023-07-03 16:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:14 --> Model Class Initialized
INFO - 2023-07-03 16:24:15 --> Final output sent to browser
DEBUG - 2023-07-03 16:24:15 --> Total execution time: 0.0898
ERROR - 2023-07-03 16:24:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:24:17 --> Config Class Initialized
INFO - 2023-07-03 16:24:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:24:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:24:17 --> Utf8 Class Initialized
INFO - 2023-07-03 16:24:17 --> URI Class Initialized
INFO - 2023-07-03 16:24:17 --> Router Class Initialized
INFO - 2023-07-03 16:24:17 --> Output Class Initialized
INFO - 2023-07-03 16:24:17 --> Security Class Initialized
DEBUG - 2023-07-03 16:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:24:17 --> Input Class Initialized
INFO - 2023-07-03 16:24:17 --> Language Class Initialized
INFO - 2023-07-03 16:24:17 --> Loader Class Initialized
INFO - 2023-07-03 16:24:17 --> Helper loaded: url_helper
INFO - 2023-07-03 16:24:17 --> Helper loaded: file_helper
INFO - 2023-07-03 16:24:17 --> Helper loaded: html_helper
INFO - 2023-07-03 16:24:17 --> Helper loaded: text_helper
INFO - 2023-07-03 16:24:17 --> Helper loaded: form_helper
INFO - 2023-07-03 16:24:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:24:17 --> Helper loaded: security_helper
INFO - 2023-07-03 16:24:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:24:17 --> Database Driver Class Initialized
INFO - 2023-07-03 16:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:24:17 --> Parser Class Initialized
INFO - 2023-07-03 16:24:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:24:17 --> Pagination Class Initialized
INFO - 2023-07-03 16:24:17 --> Form Validation Class Initialized
INFO - 2023-07-03 16:24:17 --> Controller Class Initialized
DEBUG - 2023-07-03 16:24:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:17 --> Model Class Initialized
DEBUG - 2023-07-03 16:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:17 --> Model Class Initialized
INFO - 2023-07-03 16:24:17 --> Final output sent to browser
DEBUG - 2023-07-03 16:24:17 --> Total execution time: 0.1007
ERROR - 2023-07-03 16:24:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:24:25 --> Config Class Initialized
INFO - 2023-07-03 16:24:25 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:24:25 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:24:25 --> Utf8 Class Initialized
INFO - 2023-07-03 16:24:25 --> URI Class Initialized
INFO - 2023-07-03 16:24:25 --> Router Class Initialized
INFO - 2023-07-03 16:24:25 --> Output Class Initialized
INFO - 2023-07-03 16:24:25 --> Security Class Initialized
DEBUG - 2023-07-03 16:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:24:25 --> Input Class Initialized
INFO - 2023-07-03 16:24:25 --> Language Class Initialized
INFO - 2023-07-03 16:24:25 --> Loader Class Initialized
INFO - 2023-07-03 16:24:25 --> Helper loaded: url_helper
INFO - 2023-07-03 16:24:25 --> Helper loaded: file_helper
INFO - 2023-07-03 16:24:25 --> Helper loaded: html_helper
INFO - 2023-07-03 16:24:25 --> Helper loaded: text_helper
INFO - 2023-07-03 16:24:25 --> Helper loaded: form_helper
INFO - 2023-07-03 16:24:25 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:24:25 --> Helper loaded: security_helper
INFO - 2023-07-03 16:24:25 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:24:25 --> Database Driver Class Initialized
INFO - 2023-07-03 16:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:24:25 --> Parser Class Initialized
INFO - 2023-07-03 16:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:24:25 --> Pagination Class Initialized
INFO - 2023-07-03 16:24:25 --> Form Validation Class Initialized
INFO - 2023-07-03 16:24:25 --> Controller Class Initialized
DEBUG - 2023-07-03 16:24:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:25 --> Model Class Initialized
DEBUG - 2023-07-03 16:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:24:25 --> Model Class Initialized
INFO - 2023-07-03 16:24:25 --> Final output sent to browser
DEBUG - 2023-07-03 16:24:25 --> Total execution time: 0.1029
ERROR - 2023-07-03 16:29:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:29:40 --> Config Class Initialized
INFO - 2023-07-03 16:29:40 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:29:40 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:29:40 --> Utf8 Class Initialized
INFO - 2023-07-03 16:29:40 --> URI Class Initialized
DEBUG - 2023-07-03 16:29:40 --> No URI present. Default controller set.
INFO - 2023-07-03 16:29:40 --> Router Class Initialized
INFO - 2023-07-03 16:29:40 --> Output Class Initialized
INFO - 2023-07-03 16:29:40 --> Security Class Initialized
DEBUG - 2023-07-03 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:29:40 --> Input Class Initialized
INFO - 2023-07-03 16:29:40 --> Language Class Initialized
INFO - 2023-07-03 16:29:40 --> Loader Class Initialized
INFO - 2023-07-03 16:29:40 --> Helper loaded: url_helper
INFO - 2023-07-03 16:29:40 --> Helper loaded: file_helper
INFO - 2023-07-03 16:29:40 --> Helper loaded: html_helper
INFO - 2023-07-03 16:29:40 --> Helper loaded: text_helper
INFO - 2023-07-03 16:29:40 --> Helper loaded: form_helper
INFO - 2023-07-03 16:29:40 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:29:40 --> Helper loaded: security_helper
INFO - 2023-07-03 16:29:40 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:29:40 --> Database Driver Class Initialized
INFO - 2023-07-03 16:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:29:40 --> Parser Class Initialized
INFO - 2023-07-03 16:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:29:40 --> Pagination Class Initialized
INFO - 2023-07-03 16:29:40 --> Form Validation Class Initialized
INFO - 2023-07-03 16:29:40 --> Controller Class Initialized
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
INFO - 2023-07-03 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:29:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:29:40 --> Model Class Initialized
INFO - 2023-07-03 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:29:40 --> Final output sent to browser
DEBUG - 2023-07-03 16:29:40 --> Total execution time: 0.1681
ERROR - 2023-07-03 16:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:29:51 --> Config Class Initialized
INFO - 2023-07-03 16:29:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:29:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:29:51 --> Utf8 Class Initialized
INFO - 2023-07-03 16:29:51 --> URI Class Initialized
INFO - 2023-07-03 16:29:51 --> Router Class Initialized
INFO - 2023-07-03 16:29:51 --> Output Class Initialized
INFO - 2023-07-03 16:29:51 --> Security Class Initialized
DEBUG - 2023-07-03 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:29:51 --> Input Class Initialized
INFO - 2023-07-03 16:29:51 --> Language Class Initialized
INFO - 2023-07-03 16:29:51 --> Loader Class Initialized
INFO - 2023-07-03 16:29:51 --> Helper loaded: url_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: file_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: html_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: text_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: form_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: security_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:29:51 --> Database Driver Class Initialized
INFO - 2023-07-03 16:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:29:51 --> Parser Class Initialized
INFO - 2023-07-03 16:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:29:51 --> Pagination Class Initialized
INFO - 2023-07-03 16:29:51 --> Form Validation Class Initialized
INFO - 2023-07-03 16:29:51 --> Controller Class Initialized
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
INFO - 2023-07-03 16:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-03 16:29:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
INFO - 2023-07-03 16:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:29:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:29:51 --> Final output sent to browser
DEBUG - 2023-07-03 16:29:51 --> Total execution time: 0.1335
ERROR - 2023-07-03 16:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:29:51 --> Config Class Initialized
INFO - 2023-07-03 16:29:51 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:29:51 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:29:51 --> Utf8 Class Initialized
INFO - 2023-07-03 16:29:51 --> URI Class Initialized
INFO - 2023-07-03 16:29:51 --> Router Class Initialized
INFO - 2023-07-03 16:29:51 --> Output Class Initialized
INFO - 2023-07-03 16:29:51 --> Security Class Initialized
DEBUG - 2023-07-03 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:29:51 --> Input Class Initialized
INFO - 2023-07-03 16:29:51 --> Language Class Initialized
INFO - 2023-07-03 16:29:51 --> Loader Class Initialized
INFO - 2023-07-03 16:29:51 --> Helper loaded: url_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: file_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: html_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: text_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: form_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: security_helper
INFO - 2023-07-03 16:29:51 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:29:51 --> Database Driver Class Initialized
INFO - 2023-07-03 16:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:29:51 --> Parser Class Initialized
INFO - 2023-07-03 16:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:29:51 --> Pagination Class Initialized
INFO - 2023-07-03 16:29:51 --> Form Validation Class Initialized
INFO - 2023-07-03 16:29:51 --> Controller Class Initialized
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:51 --> Model Class Initialized
INFO - 2023-07-03 16:29:51 --> Final output sent to browser
DEBUG - 2023-07-03 16:29:51 --> Total execution time: 0.0499
ERROR - 2023-07-03 16:29:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:29:56 --> Config Class Initialized
INFO - 2023-07-03 16:29:56 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:29:56 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:29:56 --> Utf8 Class Initialized
INFO - 2023-07-03 16:29:56 --> URI Class Initialized
INFO - 2023-07-03 16:29:56 --> Router Class Initialized
INFO - 2023-07-03 16:29:56 --> Output Class Initialized
INFO - 2023-07-03 16:29:56 --> Security Class Initialized
DEBUG - 2023-07-03 16:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:29:56 --> Input Class Initialized
INFO - 2023-07-03 16:29:56 --> Language Class Initialized
INFO - 2023-07-03 16:29:56 --> Loader Class Initialized
INFO - 2023-07-03 16:29:56 --> Helper loaded: url_helper
INFO - 2023-07-03 16:29:56 --> Helper loaded: file_helper
INFO - 2023-07-03 16:29:56 --> Helper loaded: html_helper
INFO - 2023-07-03 16:29:56 --> Helper loaded: text_helper
INFO - 2023-07-03 16:29:56 --> Helper loaded: form_helper
INFO - 2023-07-03 16:29:56 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:29:56 --> Helper loaded: security_helper
INFO - 2023-07-03 16:29:56 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:29:56 --> Database Driver Class Initialized
INFO - 2023-07-03 16:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:29:56 --> Parser Class Initialized
INFO - 2023-07-03 16:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:29:56 --> Pagination Class Initialized
INFO - 2023-07-03 16:29:56 --> Form Validation Class Initialized
INFO - 2023-07-03 16:29:56 --> Controller Class Initialized
INFO - 2023-07-03 16:29:56 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:56 --> Model Class Initialized
DEBUG - 2023-07-03 16:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:29:56 --> Model Class Initialized
INFO - 2023-07-03 16:29:57 --> Final output sent to browser
DEBUG - 2023-07-03 16:29:57 --> Total execution time: 0.2726
ERROR - 2023-07-03 16:45:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 16:45:45 --> Config Class Initialized
INFO - 2023-07-03 16:45:45 --> Hooks Class Initialized
DEBUG - 2023-07-03 16:45:45 --> UTF-8 Support Enabled
INFO - 2023-07-03 16:45:45 --> Utf8 Class Initialized
INFO - 2023-07-03 16:45:45 --> URI Class Initialized
DEBUG - 2023-07-03 16:45:45 --> No URI present. Default controller set.
INFO - 2023-07-03 16:45:45 --> Router Class Initialized
INFO - 2023-07-03 16:45:45 --> Output Class Initialized
INFO - 2023-07-03 16:45:45 --> Security Class Initialized
DEBUG - 2023-07-03 16:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 16:45:45 --> Input Class Initialized
INFO - 2023-07-03 16:45:45 --> Language Class Initialized
INFO - 2023-07-03 16:45:45 --> Loader Class Initialized
INFO - 2023-07-03 16:45:45 --> Helper loaded: url_helper
INFO - 2023-07-03 16:45:45 --> Helper loaded: file_helper
INFO - 2023-07-03 16:45:45 --> Helper loaded: html_helper
INFO - 2023-07-03 16:45:45 --> Helper loaded: text_helper
INFO - 2023-07-03 16:45:45 --> Helper loaded: form_helper
INFO - 2023-07-03 16:45:45 --> Helper loaded: lang_helper
INFO - 2023-07-03 16:45:45 --> Helper loaded: security_helper
INFO - 2023-07-03 16:45:45 --> Helper loaded: cookie_helper
INFO - 2023-07-03 16:45:45 --> Database Driver Class Initialized
INFO - 2023-07-03 16:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 16:45:45 --> Parser Class Initialized
INFO - 2023-07-03 16:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 16:45:45 --> Pagination Class Initialized
INFO - 2023-07-03 16:45:45 --> Form Validation Class Initialized
INFO - 2023-07-03 16:45:45 --> Controller Class Initialized
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
DEBUG - 2023-07-03 16:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
DEBUG - 2023-07-03 16:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
DEBUG - 2023-07-03 16:45:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-03 16:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
INFO - 2023-07-03 16:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-03 16:45:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 16:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 16:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 16:45:45 --> Model Class Initialized
INFO - 2023-07-03 16:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-03 16:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-03 16:45:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 16:45:45 --> Final output sent to browser
DEBUG - 2023-07-03 16:45:45 --> Total execution time: 0.0882
ERROR - 2023-07-03 20:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 20:03:13 --> Config Class Initialized
INFO - 2023-07-03 20:03:13 --> Hooks Class Initialized
DEBUG - 2023-07-03 20:03:13 --> UTF-8 Support Enabled
INFO - 2023-07-03 20:03:13 --> Utf8 Class Initialized
INFO - 2023-07-03 20:03:13 --> URI Class Initialized
DEBUG - 2023-07-03 20:03:13 --> No URI present. Default controller set.
INFO - 2023-07-03 20:03:13 --> Router Class Initialized
INFO - 2023-07-03 20:03:13 --> Output Class Initialized
INFO - 2023-07-03 20:03:13 --> Security Class Initialized
DEBUG - 2023-07-03 20:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 20:03:13 --> Input Class Initialized
INFO - 2023-07-03 20:03:13 --> Language Class Initialized
INFO - 2023-07-03 20:03:13 --> Loader Class Initialized
INFO - 2023-07-03 20:03:13 --> Helper loaded: url_helper
INFO - 2023-07-03 20:03:13 --> Helper loaded: file_helper
INFO - 2023-07-03 20:03:13 --> Helper loaded: html_helper
INFO - 2023-07-03 20:03:13 --> Helper loaded: text_helper
INFO - 2023-07-03 20:03:13 --> Helper loaded: form_helper
INFO - 2023-07-03 20:03:13 --> Helper loaded: lang_helper
INFO - 2023-07-03 20:03:13 --> Helper loaded: security_helper
INFO - 2023-07-03 20:03:13 --> Helper loaded: cookie_helper
INFO - 2023-07-03 20:03:13 --> Database Driver Class Initialized
INFO - 2023-07-03 20:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 20:03:13 --> Parser Class Initialized
INFO - 2023-07-03 20:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 20:03:13 --> Pagination Class Initialized
INFO - 2023-07-03 20:03:13 --> Form Validation Class Initialized
INFO - 2023-07-03 20:03:13 --> Controller Class Initialized
INFO - 2023-07-03 20:03:13 --> Model Class Initialized
DEBUG - 2023-07-03 20:03:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-03 20:03:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-03 20:03:17 --> Config Class Initialized
INFO - 2023-07-03 20:03:17 --> Hooks Class Initialized
DEBUG - 2023-07-03 20:03:17 --> UTF-8 Support Enabled
INFO - 2023-07-03 20:03:17 --> Utf8 Class Initialized
INFO - 2023-07-03 20:03:17 --> URI Class Initialized
INFO - 2023-07-03 20:03:17 --> Router Class Initialized
INFO - 2023-07-03 20:03:17 --> Output Class Initialized
INFO - 2023-07-03 20:03:17 --> Security Class Initialized
DEBUG - 2023-07-03 20:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-03 20:03:17 --> Input Class Initialized
INFO - 2023-07-03 20:03:17 --> Language Class Initialized
INFO - 2023-07-03 20:03:17 --> Loader Class Initialized
INFO - 2023-07-03 20:03:17 --> Helper loaded: url_helper
INFO - 2023-07-03 20:03:17 --> Helper loaded: file_helper
INFO - 2023-07-03 20:03:17 --> Helper loaded: html_helper
INFO - 2023-07-03 20:03:17 --> Helper loaded: text_helper
INFO - 2023-07-03 20:03:17 --> Helper loaded: form_helper
INFO - 2023-07-03 20:03:17 --> Helper loaded: lang_helper
INFO - 2023-07-03 20:03:17 --> Helper loaded: security_helper
INFO - 2023-07-03 20:03:17 --> Helper loaded: cookie_helper
INFO - 2023-07-03 20:03:17 --> Database Driver Class Initialized
INFO - 2023-07-03 20:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-03 20:03:17 --> Parser Class Initialized
INFO - 2023-07-03 20:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-03 20:03:17 --> Pagination Class Initialized
INFO - 2023-07-03 20:03:17 --> Form Validation Class Initialized
INFO - 2023-07-03 20:03:17 --> Controller Class Initialized
INFO - 2023-07-03 20:03:17 --> Model Class Initialized
DEBUG - 2023-07-03 20:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-03 20:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-03 20:03:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-03 20:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-03 20:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-03 20:03:17 --> Model Class Initialized
INFO - 2023-07-03 20:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-03 20:03:17 --> Final output sent to browser
DEBUG - 2023-07-03 20:03:17 --> Total execution time: 0.0269
