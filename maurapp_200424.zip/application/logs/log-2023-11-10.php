<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-10 05:37:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-10 05:37:42 --> Config Class Initialized
INFO - 2023-11-10 05:37:42 --> Hooks Class Initialized
DEBUG - 2023-11-10 05:37:42 --> UTF-8 Support Enabled
INFO - 2023-11-10 05:37:42 --> Utf8 Class Initialized
INFO - 2023-11-10 05:37:42 --> URI Class Initialized
INFO - 2023-11-10 05:37:42 --> Router Class Initialized
INFO - 2023-11-10 05:37:42 --> Output Class Initialized
INFO - 2023-11-10 05:37:42 --> Security Class Initialized
DEBUG - 2023-11-10 05:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 05:37:42 --> Input Class Initialized
INFO - 2023-11-10 05:37:42 --> Language Class Initialized
ERROR - 2023-11-10 05:37:42 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-10 15:06:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-10 15:06:28 --> Config Class Initialized
INFO - 2023-11-10 15:06:28 --> Hooks Class Initialized
DEBUG - 2023-11-10 15:06:28 --> UTF-8 Support Enabled
INFO - 2023-11-10 15:06:28 --> Utf8 Class Initialized
INFO - 2023-11-10 15:06:28 --> URI Class Initialized
DEBUG - 2023-11-10 15:06:28 --> No URI present. Default controller set.
INFO - 2023-11-10 15:06:28 --> Router Class Initialized
INFO - 2023-11-10 15:06:28 --> Output Class Initialized
INFO - 2023-11-10 15:06:28 --> Security Class Initialized
DEBUG - 2023-11-10 15:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 15:06:28 --> Input Class Initialized
INFO - 2023-11-10 15:06:28 --> Language Class Initialized
INFO - 2023-11-10 15:06:28 --> Loader Class Initialized
INFO - 2023-11-10 15:06:28 --> Helper loaded: url_helper
INFO - 2023-11-10 15:06:28 --> Helper loaded: file_helper
INFO - 2023-11-10 15:06:28 --> Helper loaded: html_helper
INFO - 2023-11-10 15:06:28 --> Helper loaded: text_helper
INFO - 2023-11-10 15:06:28 --> Helper loaded: form_helper
INFO - 2023-11-10 15:06:28 --> Helper loaded: lang_helper
INFO - 2023-11-10 15:06:28 --> Helper loaded: security_helper
INFO - 2023-11-10 15:06:28 --> Helper loaded: cookie_helper
INFO - 2023-11-10 15:06:28 --> Database Driver Class Initialized
INFO - 2023-11-10 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 15:06:28 --> Parser Class Initialized
INFO - 2023-11-10 15:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-10 15:06:28 --> Pagination Class Initialized
INFO - 2023-11-10 15:06:28 --> Form Validation Class Initialized
INFO - 2023-11-10 15:06:28 --> Controller Class Initialized
INFO - 2023-11-10 15:06:28 --> Model Class Initialized
DEBUG - 2023-11-10 15:06:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-10 16:35:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:35:03 --> Config Class Initialized
INFO - 2023-11-10 16:35:03 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:35:03 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:35:03 --> Utf8 Class Initialized
INFO - 2023-11-10 16:35:03 --> URI Class Initialized
INFO - 2023-11-10 16:35:03 --> Router Class Initialized
INFO - 2023-11-10 16:35:03 --> Output Class Initialized
INFO - 2023-11-10 16:35:03 --> Security Class Initialized
DEBUG - 2023-11-10 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:35:03 --> Input Class Initialized
INFO - 2023-11-10 16:35:03 --> Language Class Initialized
ERROR - 2023-11-10 16:35:03 --> 404 Page Not Found: Well-known/assetlinks.json
