<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-19 01:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:39:50 --> Config Class Initialized
INFO - 2023-08-19 01:39:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:39:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:39:50 --> Utf8 Class Initialized
INFO - 2023-08-19 01:39:50 --> URI Class Initialized
DEBUG - 2023-08-19 01:39:50 --> No URI present. Default controller set.
INFO - 2023-08-19 01:39:50 --> Router Class Initialized
INFO - 2023-08-19 01:39:50 --> Output Class Initialized
INFO - 2023-08-19 01:39:50 --> Security Class Initialized
DEBUG - 2023-08-19 01:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:39:50 --> Input Class Initialized
INFO - 2023-08-19 01:39:50 --> Language Class Initialized
INFO - 2023-08-19 01:39:50 --> Loader Class Initialized
INFO - 2023-08-19 01:39:50 --> Helper loaded: url_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: file_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: html_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: text_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: form_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: security_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:39:50 --> Database Driver Class Initialized
INFO - 2023-08-19 01:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:39:50 --> Parser Class Initialized
INFO - 2023-08-19 01:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:39:50 --> Pagination Class Initialized
INFO - 2023-08-19 01:39:50 --> Form Validation Class Initialized
INFO - 2023-08-19 01:39:50 --> Controller Class Initialized
INFO - 2023-08-19 01:39:50 --> Model Class Initialized
DEBUG - 2023-08-19 01:39:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 01:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:39:50 --> Config Class Initialized
INFO - 2023-08-19 01:39:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:39:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:39:50 --> Utf8 Class Initialized
INFO - 2023-08-19 01:39:50 --> URI Class Initialized
INFO - 2023-08-19 01:39:50 --> Router Class Initialized
INFO - 2023-08-19 01:39:50 --> Output Class Initialized
INFO - 2023-08-19 01:39:50 --> Security Class Initialized
DEBUG - 2023-08-19 01:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:39:50 --> Input Class Initialized
INFO - 2023-08-19 01:39:50 --> Language Class Initialized
INFO - 2023-08-19 01:39:50 --> Loader Class Initialized
INFO - 2023-08-19 01:39:50 --> Helper loaded: url_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: file_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: html_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: text_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: form_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: security_helper
INFO - 2023-08-19 01:39:50 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:39:50 --> Database Driver Class Initialized
INFO - 2023-08-19 01:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:39:50 --> Parser Class Initialized
INFO - 2023-08-19 01:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:39:50 --> Pagination Class Initialized
INFO - 2023-08-19 01:39:50 --> Form Validation Class Initialized
INFO - 2023-08-19 01:39:50 --> Controller Class Initialized
INFO - 2023-08-19 01:39:50 --> Model Class Initialized
DEBUG - 2023-08-19 01:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 01:39:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:39:50 --> Model Class Initialized
INFO - 2023-08-19 01:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:39:50 --> Final output sent to browser
DEBUG - 2023-08-19 01:39:50 --> Total execution time: 0.0318
ERROR - 2023-08-19 01:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:40:09 --> Config Class Initialized
INFO - 2023-08-19 01:40:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:40:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:40:09 --> Utf8 Class Initialized
INFO - 2023-08-19 01:40:09 --> URI Class Initialized
INFO - 2023-08-19 01:40:09 --> Router Class Initialized
INFO - 2023-08-19 01:40:09 --> Output Class Initialized
INFO - 2023-08-19 01:40:09 --> Security Class Initialized
DEBUG - 2023-08-19 01:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:40:09 --> Input Class Initialized
INFO - 2023-08-19 01:40:09 --> Language Class Initialized
INFO - 2023-08-19 01:40:09 --> Loader Class Initialized
INFO - 2023-08-19 01:40:09 --> Helper loaded: url_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: file_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: html_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: text_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: form_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: security_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:40:09 --> Database Driver Class Initialized
INFO - 2023-08-19 01:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:40:09 --> Parser Class Initialized
INFO - 2023-08-19 01:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:40:09 --> Pagination Class Initialized
INFO - 2023-08-19 01:40:09 --> Form Validation Class Initialized
INFO - 2023-08-19 01:40:09 --> Controller Class Initialized
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
DEBUG - 2023-08-19 01:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
INFO - 2023-08-19 01:40:09 --> Final output sent to browser
DEBUG - 2023-08-19 01:40:09 --> Total execution time: 0.0218
ERROR - 2023-08-19 01:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:40:09 --> Config Class Initialized
INFO - 2023-08-19 01:40:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:40:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:40:09 --> Utf8 Class Initialized
INFO - 2023-08-19 01:40:09 --> URI Class Initialized
DEBUG - 2023-08-19 01:40:09 --> No URI present. Default controller set.
INFO - 2023-08-19 01:40:09 --> Router Class Initialized
INFO - 2023-08-19 01:40:09 --> Output Class Initialized
INFO - 2023-08-19 01:40:09 --> Security Class Initialized
DEBUG - 2023-08-19 01:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:40:09 --> Input Class Initialized
INFO - 2023-08-19 01:40:09 --> Language Class Initialized
INFO - 2023-08-19 01:40:09 --> Loader Class Initialized
INFO - 2023-08-19 01:40:09 --> Helper loaded: url_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: file_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: html_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: text_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: form_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: security_helper
INFO - 2023-08-19 01:40:09 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:40:09 --> Database Driver Class Initialized
INFO - 2023-08-19 01:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:40:09 --> Parser Class Initialized
INFO - 2023-08-19 01:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:40:09 --> Pagination Class Initialized
INFO - 2023-08-19 01:40:09 --> Form Validation Class Initialized
INFO - 2023-08-19 01:40:09 --> Controller Class Initialized
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
DEBUG - 2023-08-19 01:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
DEBUG - 2023-08-19 01:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
DEBUG - 2023-08-19 01:40:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
INFO - 2023-08-19 01:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 01:40:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:40:09 --> Model Class Initialized
INFO - 2023-08-19 01:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:40:09 --> Final output sent to browser
DEBUG - 2023-08-19 01:40:09 --> Total execution time: 0.0854
ERROR - 2023-08-19 01:56:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:56:26 --> Config Class Initialized
INFO - 2023-08-19 01:56:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:56:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:56:26 --> Utf8 Class Initialized
INFO - 2023-08-19 01:56:26 --> URI Class Initialized
DEBUG - 2023-08-19 01:56:26 --> No URI present. Default controller set.
INFO - 2023-08-19 01:56:26 --> Router Class Initialized
INFO - 2023-08-19 01:56:26 --> Output Class Initialized
INFO - 2023-08-19 01:56:26 --> Security Class Initialized
DEBUG - 2023-08-19 01:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:56:26 --> Input Class Initialized
INFO - 2023-08-19 01:56:26 --> Language Class Initialized
INFO - 2023-08-19 01:56:26 --> Loader Class Initialized
INFO - 2023-08-19 01:56:26 --> Helper loaded: url_helper
INFO - 2023-08-19 01:56:26 --> Helper loaded: file_helper
INFO - 2023-08-19 01:56:26 --> Helper loaded: html_helper
INFO - 2023-08-19 01:56:26 --> Helper loaded: text_helper
INFO - 2023-08-19 01:56:26 --> Helper loaded: form_helper
INFO - 2023-08-19 01:56:26 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:56:26 --> Helper loaded: security_helper
INFO - 2023-08-19 01:56:26 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:56:26 --> Database Driver Class Initialized
INFO - 2023-08-19 01:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:56:26 --> Parser Class Initialized
INFO - 2023-08-19 01:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:56:26 --> Pagination Class Initialized
INFO - 2023-08-19 01:56:26 --> Form Validation Class Initialized
INFO - 2023-08-19 01:56:26 --> Controller Class Initialized
INFO - 2023-08-19 01:56:26 --> Model Class Initialized
DEBUG - 2023-08-19 01:56:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 01:56:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:56:27 --> Config Class Initialized
INFO - 2023-08-19 01:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:56:27 --> Utf8 Class Initialized
INFO - 2023-08-19 01:56:27 --> URI Class Initialized
INFO - 2023-08-19 01:56:27 --> Router Class Initialized
INFO - 2023-08-19 01:56:27 --> Output Class Initialized
INFO - 2023-08-19 01:56:27 --> Security Class Initialized
DEBUG - 2023-08-19 01:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:56:27 --> Input Class Initialized
INFO - 2023-08-19 01:56:27 --> Language Class Initialized
INFO - 2023-08-19 01:56:27 --> Loader Class Initialized
INFO - 2023-08-19 01:56:27 --> Helper loaded: url_helper
INFO - 2023-08-19 01:56:27 --> Helper loaded: file_helper
INFO - 2023-08-19 01:56:27 --> Helper loaded: html_helper
INFO - 2023-08-19 01:56:27 --> Helper loaded: text_helper
INFO - 2023-08-19 01:56:27 --> Helper loaded: form_helper
INFO - 2023-08-19 01:56:27 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:56:27 --> Helper loaded: security_helper
INFO - 2023-08-19 01:56:27 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:56:27 --> Database Driver Class Initialized
INFO - 2023-08-19 01:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:56:27 --> Parser Class Initialized
INFO - 2023-08-19 01:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:56:27 --> Pagination Class Initialized
INFO - 2023-08-19 01:56:27 --> Form Validation Class Initialized
INFO - 2023-08-19 01:56:27 --> Controller Class Initialized
INFO - 2023-08-19 01:56:27 --> Model Class Initialized
DEBUG - 2023-08-19 01:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 01:56:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:56:27 --> Model Class Initialized
INFO - 2023-08-19 01:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:56:27 --> Final output sent to browser
DEBUG - 2023-08-19 01:56:27 --> Total execution time: 0.1242
ERROR - 2023-08-19 01:56:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:56:59 --> Config Class Initialized
INFO - 2023-08-19 01:56:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:56:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:56:59 --> Utf8 Class Initialized
INFO - 2023-08-19 01:56:59 --> URI Class Initialized
INFO - 2023-08-19 01:56:59 --> Router Class Initialized
INFO - 2023-08-19 01:56:59 --> Output Class Initialized
INFO - 2023-08-19 01:56:59 --> Security Class Initialized
DEBUG - 2023-08-19 01:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:56:59 --> Input Class Initialized
INFO - 2023-08-19 01:56:59 --> Language Class Initialized
INFO - 2023-08-19 01:56:59 --> Loader Class Initialized
INFO - 2023-08-19 01:56:59 --> Helper loaded: url_helper
INFO - 2023-08-19 01:56:59 --> Helper loaded: file_helper
INFO - 2023-08-19 01:56:59 --> Helper loaded: html_helper
INFO - 2023-08-19 01:56:59 --> Helper loaded: text_helper
INFO - 2023-08-19 01:56:59 --> Helper loaded: form_helper
INFO - 2023-08-19 01:56:59 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:56:59 --> Helper loaded: security_helper
INFO - 2023-08-19 01:56:59 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:56:59 --> Database Driver Class Initialized
INFO - 2023-08-19 01:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:56:59 --> Parser Class Initialized
INFO - 2023-08-19 01:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:56:59 --> Pagination Class Initialized
INFO - 2023-08-19 01:56:59 --> Form Validation Class Initialized
INFO - 2023-08-19 01:56:59 --> Controller Class Initialized
INFO - 2023-08-19 01:56:59 --> Model Class Initialized
DEBUG - 2023-08-19 01:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:56:59 --> Model Class Initialized
INFO - 2023-08-19 01:56:59 --> Final output sent to browser
DEBUG - 2023-08-19 01:56:59 --> Total execution time: 0.0194
ERROR - 2023-08-19 01:57:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:00 --> Config Class Initialized
INFO - 2023-08-19 01:57:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:00 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:00 --> URI Class Initialized
DEBUG - 2023-08-19 01:57:00 --> No URI present. Default controller set.
INFO - 2023-08-19 01:57:00 --> Router Class Initialized
INFO - 2023-08-19 01:57:00 --> Output Class Initialized
INFO - 2023-08-19 01:57:00 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:00 --> Input Class Initialized
INFO - 2023-08-19 01:57:00 --> Language Class Initialized
INFO - 2023-08-19 01:57:00 --> Loader Class Initialized
INFO - 2023-08-19 01:57:00 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:00 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:00 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:00 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:00 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:00 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:00 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:00 --> Parser Class Initialized
INFO - 2023-08-19 01:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:00 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:00 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:00 --> Controller Class Initialized
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
INFO - 2023-08-19 01:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 01:57:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:57:00 --> Model Class Initialized
INFO - 2023-08-19 01:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:57:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:57:00 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:00 --> Total execution time: 0.0974
ERROR - 2023-08-19 01:57:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:11 --> Config Class Initialized
INFO - 2023-08-19 01:57:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:11 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:11 --> URI Class Initialized
INFO - 2023-08-19 01:57:11 --> Router Class Initialized
INFO - 2023-08-19 01:57:11 --> Output Class Initialized
INFO - 2023-08-19 01:57:11 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:11 --> Input Class Initialized
INFO - 2023-08-19 01:57:11 --> Language Class Initialized
INFO - 2023-08-19 01:57:11 --> Loader Class Initialized
INFO - 2023-08-19 01:57:11 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:11 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:11 --> Parser Class Initialized
INFO - 2023-08-19 01:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:11 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:11 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:11 --> Controller Class Initialized
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
INFO - 2023-08-19 01:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 01:57:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
INFO - 2023-08-19 01:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:57:11 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:11 --> Total execution time: 0.0724
ERROR - 2023-08-19 01:57:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:11 --> Config Class Initialized
INFO - 2023-08-19 01:57:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:11 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:11 --> URI Class Initialized
INFO - 2023-08-19 01:57:11 --> Router Class Initialized
INFO - 2023-08-19 01:57:11 --> Output Class Initialized
INFO - 2023-08-19 01:57:11 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:11 --> Input Class Initialized
INFO - 2023-08-19 01:57:11 --> Language Class Initialized
INFO - 2023-08-19 01:57:11 --> Loader Class Initialized
INFO - 2023-08-19 01:57:11 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:11 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:11 --> Parser Class Initialized
INFO - 2023-08-19 01:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:11 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:11 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:11 --> Controller Class Initialized
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:11 --> Model Class Initialized
INFO - 2023-08-19 01:57:11 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:11 --> Total execution time: 0.0366
ERROR - 2023-08-19 01:57:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:33 --> Config Class Initialized
INFO - 2023-08-19 01:57:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:33 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:33 --> URI Class Initialized
INFO - 2023-08-19 01:57:33 --> Router Class Initialized
INFO - 2023-08-19 01:57:33 --> Output Class Initialized
INFO - 2023-08-19 01:57:33 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:33 --> Input Class Initialized
INFO - 2023-08-19 01:57:33 --> Language Class Initialized
INFO - 2023-08-19 01:57:33 --> Loader Class Initialized
INFO - 2023-08-19 01:57:33 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:33 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:33 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:33 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:33 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:33 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:33 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:33 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:33 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:33 --> Parser Class Initialized
INFO - 2023-08-19 01:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:33 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:33 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:33 --> Controller Class Initialized
INFO - 2023-08-19 01:57:33 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:33 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:33 --> Model Class Initialized
INFO - 2023-08-19 01:57:33 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:33 --> Total execution time: 0.0387
ERROR - 2023-08-19 01:57:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:35 --> Config Class Initialized
INFO - 2023-08-19 01:57:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:35 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:35 --> URI Class Initialized
INFO - 2023-08-19 01:57:35 --> Router Class Initialized
INFO - 2023-08-19 01:57:35 --> Output Class Initialized
INFO - 2023-08-19 01:57:35 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:35 --> Input Class Initialized
INFO - 2023-08-19 01:57:35 --> Language Class Initialized
INFO - 2023-08-19 01:57:35 --> Loader Class Initialized
INFO - 2023-08-19 01:57:35 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:35 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:35 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:35 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:35 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:35 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:35 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:35 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:35 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:35 --> Parser Class Initialized
INFO - 2023-08-19 01:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:35 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:35 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:35 --> Controller Class Initialized
INFO - 2023-08-19 01:57:35 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:35 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:35 --> Model Class Initialized
INFO - 2023-08-19 01:57:35 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:35 --> Total execution time: 0.0367
ERROR - 2023-08-19 01:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:42 --> Config Class Initialized
INFO - 2023-08-19 01:57:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:42 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:42 --> URI Class Initialized
INFO - 2023-08-19 01:57:42 --> Router Class Initialized
INFO - 2023-08-19 01:57:42 --> Output Class Initialized
INFO - 2023-08-19 01:57:42 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:42 --> Input Class Initialized
INFO - 2023-08-19 01:57:42 --> Language Class Initialized
INFO - 2023-08-19 01:57:42 --> Loader Class Initialized
INFO - 2023-08-19 01:57:42 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:42 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:42 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:42 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:42 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:42 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:42 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:42 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:42 --> Parser Class Initialized
INFO - 2023-08-19 01:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:42 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:42 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:42 --> Controller Class Initialized
INFO - 2023-08-19 01:57:42 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:42 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:42 --> Model Class Initialized
INFO - 2023-08-19 01:57:42 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:42 --> Total execution time: 0.0657
ERROR - 2023-08-19 01:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:48 --> Config Class Initialized
INFO - 2023-08-19 01:57:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:48 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:48 --> URI Class Initialized
DEBUG - 2023-08-19 01:57:48 --> No URI present. Default controller set.
INFO - 2023-08-19 01:57:48 --> Router Class Initialized
INFO - 2023-08-19 01:57:48 --> Output Class Initialized
INFO - 2023-08-19 01:57:48 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:48 --> Input Class Initialized
INFO - 2023-08-19 01:57:48 --> Language Class Initialized
INFO - 2023-08-19 01:57:48 --> Loader Class Initialized
INFO - 2023-08-19 01:57:48 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:48 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:48 --> Parser Class Initialized
INFO - 2023-08-19 01:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:48 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:48 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:48 --> Controller Class Initialized
INFO - 2023-08-19 01:57:48 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 01:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:48 --> Config Class Initialized
INFO - 2023-08-19 01:57:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:48 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:48 --> URI Class Initialized
INFO - 2023-08-19 01:57:48 --> Router Class Initialized
INFO - 2023-08-19 01:57:48 --> Output Class Initialized
INFO - 2023-08-19 01:57:48 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:48 --> Input Class Initialized
INFO - 2023-08-19 01:57:48 --> Language Class Initialized
INFO - 2023-08-19 01:57:48 --> Loader Class Initialized
INFO - 2023-08-19 01:57:48 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:48 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:48 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:48 --> Parser Class Initialized
INFO - 2023-08-19 01:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:48 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:48 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:48 --> Controller Class Initialized
INFO - 2023-08-19 01:57:48 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 01:57:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:57:48 --> Model Class Initialized
INFO - 2023-08-19 01:57:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:57:48 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:48 --> Total execution time: 0.0263
ERROR - 2023-08-19 01:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:57:54 --> Config Class Initialized
INFO - 2023-08-19 01:57:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:57:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:57:54 --> Utf8 Class Initialized
INFO - 2023-08-19 01:57:54 --> URI Class Initialized
INFO - 2023-08-19 01:57:54 --> Router Class Initialized
INFO - 2023-08-19 01:57:54 --> Output Class Initialized
INFO - 2023-08-19 01:57:54 --> Security Class Initialized
DEBUG - 2023-08-19 01:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:57:54 --> Input Class Initialized
INFO - 2023-08-19 01:57:54 --> Language Class Initialized
INFO - 2023-08-19 01:57:54 --> Loader Class Initialized
INFO - 2023-08-19 01:57:54 --> Helper loaded: url_helper
INFO - 2023-08-19 01:57:54 --> Helper loaded: file_helper
INFO - 2023-08-19 01:57:54 --> Helper loaded: html_helper
INFO - 2023-08-19 01:57:54 --> Helper loaded: text_helper
INFO - 2023-08-19 01:57:54 --> Helper loaded: form_helper
INFO - 2023-08-19 01:57:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:57:54 --> Helper loaded: security_helper
INFO - 2023-08-19 01:57:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:57:54 --> Database Driver Class Initialized
INFO - 2023-08-19 01:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:57:54 --> Parser Class Initialized
INFO - 2023-08-19 01:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:57:54 --> Pagination Class Initialized
INFO - 2023-08-19 01:57:54 --> Form Validation Class Initialized
INFO - 2023-08-19 01:57:54 --> Controller Class Initialized
INFO - 2023-08-19 01:57:54 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:54 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:54 --> Model Class Initialized
DEBUG - 2023-08-19 01:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-19 01:57:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:57:54 --> Model Class Initialized
INFO - 2023-08-19 01:57:54 --> Model Class Initialized
INFO - 2023-08-19 01:57:54 --> Model Class Initialized
INFO - 2023-08-19 01:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:57:54 --> Final output sent to browser
DEBUG - 2023-08-19 01:57:54 --> Total execution time: 0.0791
ERROR - 2023-08-19 01:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:11 --> Config Class Initialized
INFO - 2023-08-19 01:58:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:11 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:11 --> URI Class Initialized
INFO - 2023-08-19 01:58:11 --> Router Class Initialized
INFO - 2023-08-19 01:58:11 --> Output Class Initialized
INFO - 2023-08-19 01:58:11 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:11 --> Input Class Initialized
INFO - 2023-08-19 01:58:11 --> Language Class Initialized
INFO - 2023-08-19 01:58:11 --> Loader Class Initialized
INFO - 2023-08-19 01:58:11 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:11 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:11 --> Parser Class Initialized
INFO - 2023-08-19 01:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:11 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:11 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:11 --> Controller Class Initialized
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
INFO - 2023-08-19 01:58:11 --> Final output sent to browser
DEBUG - 2023-08-19 01:58:11 --> Total execution time: 0.0182
ERROR - 2023-08-19 01:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:11 --> Config Class Initialized
INFO - 2023-08-19 01:58:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:11 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:11 --> URI Class Initialized
DEBUG - 2023-08-19 01:58:11 --> No URI present. Default controller set.
INFO - 2023-08-19 01:58:11 --> Router Class Initialized
INFO - 2023-08-19 01:58:11 --> Output Class Initialized
INFO - 2023-08-19 01:58:11 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:11 --> Input Class Initialized
INFO - 2023-08-19 01:58:11 --> Language Class Initialized
INFO - 2023-08-19 01:58:11 --> Loader Class Initialized
INFO - 2023-08-19 01:58:11 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:11 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:11 --> Parser Class Initialized
INFO - 2023-08-19 01:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:11 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:11 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:11 --> Controller Class Initialized
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
INFO - 2023-08-19 01:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 01:58:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:58:11 --> Model Class Initialized
INFO - 2023-08-19 01:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:58:11 --> Final output sent to browser
DEBUG - 2023-08-19 01:58:11 --> Total execution time: 0.0794
ERROR - 2023-08-19 01:58:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:31 --> Config Class Initialized
INFO - 2023-08-19 01:58:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:31 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:31 --> URI Class Initialized
INFO - 2023-08-19 01:58:31 --> Router Class Initialized
INFO - 2023-08-19 01:58:31 --> Output Class Initialized
INFO - 2023-08-19 01:58:31 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:31 --> Input Class Initialized
INFO - 2023-08-19 01:58:31 --> Language Class Initialized
INFO - 2023-08-19 01:58:31 --> Loader Class Initialized
INFO - 2023-08-19 01:58:31 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:31 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:31 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:31 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:31 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:31 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:31 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:31 --> Parser Class Initialized
INFO - 2023-08-19 01:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:31 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:31 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:31 --> Controller Class Initialized
INFO - 2023-08-19 01:58:31 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:31 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:31 --> Model Class Initialized
INFO - 2023-08-19 01:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 01:58:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:58:31 --> Model Class Initialized
INFO - 2023-08-19 01:58:31 --> Model Class Initialized
INFO - 2023-08-19 01:58:31 --> Model Class Initialized
INFO - 2023-08-19 01:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:58:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:58:31 --> Final output sent to browser
DEBUG - 2023-08-19 01:58:31 --> Total execution time: 0.1010
ERROR - 2023-08-19 01:58:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:32 --> Config Class Initialized
INFO - 2023-08-19 01:58:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:32 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:32 --> URI Class Initialized
INFO - 2023-08-19 01:58:32 --> Router Class Initialized
INFO - 2023-08-19 01:58:32 --> Output Class Initialized
INFO - 2023-08-19 01:58:32 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:32 --> Input Class Initialized
INFO - 2023-08-19 01:58:32 --> Language Class Initialized
INFO - 2023-08-19 01:58:32 --> Loader Class Initialized
INFO - 2023-08-19 01:58:32 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:32 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:32 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:32 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:32 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:32 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:32 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:32 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:32 --> Parser Class Initialized
INFO - 2023-08-19 01:58:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:32 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:32 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:32 --> Controller Class Initialized
INFO - 2023-08-19 01:58:32 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:32 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:32 --> Model Class Initialized
INFO - 2023-08-19 01:58:32 --> Final output sent to browser
DEBUG - 2023-08-19 01:58:32 --> Total execution time: 0.0248
ERROR - 2023-08-19 01:58:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:55 --> Config Class Initialized
INFO - 2023-08-19 01:58:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:55 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:55 --> URI Class Initialized
DEBUG - 2023-08-19 01:58:55 --> No URI present. Default controller set.
INFO - 2023-08-19 01:58:55 --> Router Class Initialized
INFO - 2023-08-19 01:58:55 --> Output Class Initialized
INFO - 2023-08-19 01:58:55 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:55 --> Input Class Initialized
INFO - 2023-08-19 01:58:55 --> Language Class Initialized
INFO - 2023-08-19 01:58:55 --> Loader Class Initialized
INFO - 2023-08-19 01:58:55 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:55 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:55 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:55 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:55 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:55 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:55 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:55 --> Parser Class Initialized
INFO - 2023-08-19 01:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:55 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:55 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:55 --> Controller Class Initialized
INFO - 2023-08-19 01:58:55 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 01:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:56 --> Config Class Initialized
INFO - 2023-08-19 01:58:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:56 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:56 --> URI Class Initialized
INFO - 2023-08-19 01:58:56 --> Router Class Initialized
INFO - 2023-08-19 01:58:56 --> Output Class Initialized
INFO - 2023-08-19 01:58:56 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:56 --> Input Class Initialized
INFO - 2023-08-19 01:58:56 --> Language Class Initialized
INFO - 2023-08-19 01:58:56 --> Loader Class Initialized
INFO - 2023-08-19 01:58:56 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:56 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:56 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:56 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:56 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:56 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:56 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:56 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:56 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:56 --> Parser Class Initialized
INFO - 2023-08-19 01:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:56 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:56 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:56 --> Controller Class Initialized
INFO - 2023-08-19 01:58:56 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 01:58:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:58:56 --> Model Class Initialized
INFO - 2023-08-19 01:58:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:58:56 --> Final output sent to browser
DEBUG - 2023-08-19 01:58:56 --> Total execution time: 0.0276
ERROR - 2023-08-19 01:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:59 --> Config Class Initialized
INFO - 2023-08-19 01:58:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:59 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:59 --> URI Class Initialized
INFO - 2023-08-19 01:58:59 --> Router Class Initialized
INFO - 2023-08-19 01:58:59 --> Output Class Initialized
INFO - 2023-08-19 01:58:59 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:59 --> Input Class Initialized
INFO - 2023-08-19 01:58:59 --> Language Class Initialized
INFO - 2023-08-19 01:58:59 --> Loader Class Initialized
INFO - 2023-08-19 01:58:59 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:59 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:59 --> Parser Class Initialized
INFO - 2023-08-19 01:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:59 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:59 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:59 --> Controller Class Initialized
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
INFO - 2023-08-19 01:58:59 --> Final output sent to browser
DEBUG - 2023-08-19 01:58:59 --> Total execution time: 0.0169
ERROR - 2023-08-19 01:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:58:59 --> Config Class Initialized
INFO - 2023-08-19 01:58:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:58:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:58:59 --> Utf8 Class Initialized
INFO - 2023-08-19 01:58:59 --> URI Class Initialized
DEBUG - 2023-08-19 01:58:59 --> No URI present. Default controller set.
INFO - 2023-08-19 01:58:59 --> Router Class Initialized
INFO - 2023-08-19 01:58:59 --> Output Class Initialized
INFO - 2023-08-19 01:58:59 --> Security Class Initialized
DEBUG - 2023-08-19 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:58:59 --> Input Class Initialized
INFO - 2023-08-19 01:58:59 --> Language Class Initialized
INFO - 2023-08-19 01:58:59 --> Loader Class Initialized
INFO - 2023-08-19 01:58:59 --> Helper loaded: url_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: file_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: html_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: text_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: form_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: security_helper
INFO - 2023-08-19 01:58:59 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:58:59 --> Database Driver Class Initialized
INFO - 2023-08-19 01:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:58:59 --> Parser Class Initialized
INFO - 2023-08-19 01:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:58:59 --> Pagination Class Initialized
INFO - 2023-08-19 01:58:59 --> Form Validation Class Initialized
INFO - 2023-08-19 01:58:59 --> Controller Class Initialized
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
DEBUG - 2023-08-19 01:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
INFO - 2023-08-19 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 01:58:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:58:59 --> Model Class Initialized
INFO - 2023-08-19 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:58:59 --> Final output sent to browser
DEBUG - 2023-08-19 01:58:59 --> Total execution time: 0.1795
ERROR - 2023-08-19 01:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:00 --> Config Class Initialized
INFO - 2023-08-19 01:59:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:00 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:00 --> URI Class Initialized
INFO - 2023-08-19 01:59:00 --> Router Class Initialized
INFO - 2023-08-19 01:59:00 --> Output Class Initialized
INFO - 2023-08-19 01:59:00 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:00 --> Input Class Initialized
INFO - 2023-08-19 01:59:00 --> Language Class Initialized
INFO - 2023-08-19 01:59:00 --> Loader Class Initialized
INFO - 2023-08-19 01:59:00 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:00 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:00 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:00 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:00 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:00 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:00 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:00 --> Parser Class Initialized
INFO - 2023-08-19 01:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:00 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:00 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:00 --> Controller Class Initialized
DEBUG - 2023-08-19 01:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:00 --> Model Class Initialized
INFO - 2023-08-19 01:59:00 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:00 --> Total execution time: 0.0130
ERROR - 2023-08-19 01:59:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:02 --> Config Class Initialized
INFO - 2023-08-19 01:59:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:02 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:02 --> URI Class Initialized
DEBUG - 2023-08-19 01:59:02 --> No URI present. Default controller set.
INFO - 2023-08-19 01:59:02 --> Router Class Initialized
INFO - 2023-08-19 01:59:02 --> Output Class Initialized
INFO - 2023-08-19 01:59:02 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:02 --> Input Class Initialized
INFO - 2023-08-19 01:59:02 --> Language Class Initialized
INFO - 2023-08-19 01:59:02 --> Loader Class Initialized
INFO - 2023-08-19 01:59:02 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:02 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:02 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:02 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:02 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:02 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:02 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:02 --> Parser Class Initialized
INFO - 2023-08-19 01:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:02 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:02 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:02 --> Controller Class Initialized
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
INFO - 2023-08-19 01:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 01:59:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:02 --> Model Class Initialized
INFO - 2023-08-19 01:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:02 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:02 --> Total execution time: 0.1402
ERROR - 2023-08-19 01:59:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:07 --> Config Class Initialized
INFO - 2023-08-19 01:59:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:07 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:07 --> URI Class Initialized
INFO - 2023-08-19 01:59:07 --> Router Class Initialized
INFO - 2023-08-19 01:59:07 --> Output Class Initialized
INFO - 2023-08-19 01:59:07 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:07 --> Input Class Initialized
INFO - 2023-08-19 01:59:07 --> Language Class Initialized
INFO - 2023-08-19 01:59:07 --> Loader Class Initialized
INFO - 2023-08-19 01:59:07 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:07 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:07 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:07 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:07 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:07 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:07 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:07 --> Parser Class Initialized
INFO - 2023-08-19 01:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:07 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:07 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:07 --> Controller Class Initialized
INFO - 2023-08-19 01:59:07 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:07 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:07 --> Model Class Initialized
INFO - 2023-08-19 01:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 01:59:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:07 --> Model Class Initialized
INFO - 2023-08-19 01:59:07 --> Model Class Initialized
INFO - 2023-08-19 01:59:07 --> Model Class Initialized
INFO - 2023-08-19 01:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:07 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:07 --> Total execution time: 0.0668
ERROR - 2023-08-19 01:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:08 --> Config Class Initialized
INFO - 2023-08-19 01:59:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:08 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:08 --> URI Class Initialized
INFO - 2023-08-19 01:59:08 --> Router Class Initialized
INFO - 2023-08-19 01:59:08 --> Output Class Initialized
INFO - 2023-08-19 01:59:08 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:08 --> Input Class Initialized
INFO - 2023-08-19 01:59:08 --> Language Class Initialized
INFO - 2023-08-19 01:59:08 --> Loader Class Initialized
INFO - 2023-08-19 01:59:08 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:08 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:08 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:08 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:08 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:08 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:08 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:08 --> Parser Class Initialized
INFO - 2023-08-19 01:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:08 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:08 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:08 --> Controller Class Initialized
INFO - 2023-08-19 01:59:08 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:08 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:08 --> Model Class Initialized
INFO - 2023-08-19 01:59:08 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:08 --> Total execution time: 0.0230
ERROR - 2023-08-19 01:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:11 --> Config Class Initialized
INFO - 2023-08-19 01:59:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:11 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:11 --> URI Class Initialized
INFO - 2023-08-19 01:59:11 --> Router Class Initialized
INFO - 2023-08-19 01:59:11 --> Output Class Initialized
INFO - 2023-08-19 01:59:11 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:11 --> Input Class Initialized
INFO - 2023-08-19 01:59:11 --> Language Class Initialized
INFO - 2023-08-19 01:59:11 --> Loader Class Initialized
INFO - 2023-08-19 01:59:11 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:11 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:11 --> Parser Class Initialized
INFO - 2023-08-19 01:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:11 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:11 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:11 --> Controller Class Initialized
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
INFO - 2023-08-19 01:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 01:59:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
INFO - 2023-08-19 01:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:11 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:11 --> Total execution time: 0.1266
ERROR - 2023-08-19 01:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:11 --> Config Class Initialized
INFO - 2023-08-19 01:59:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:11 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:11 --> URI Class Initialized
INFO - 2023-08-19 01:59:11 --> Router Class Initialized
INFO - 2023-08-19 01:59:11 --> Output Class Initialized
INFO - 2023-08-19 01:59:11 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:11 --> Input Class Initialized
INFO - 2023-08-19 01:59:11 --> Language Class Initialized
INFO - 2023-08-19 01:59:11 --> Loader Class Initialized
INFO - 2023-08-19 01:59:11 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:11 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:11 --> Parser Class Initialized
INFO - 2023-08-19 01:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:11 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:11 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:11 --> Controller Class Initialized
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:11 --> Model Class Initialized
INFO - 2023-08-19 01:59:12 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:12 --> Total execution time: 0.0527
ERROR - 2023-08-19 01:59:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:14 --> Config Class Initialized
INFO - 2023-08-19 01:59:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:14 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:14 --> URI Class Initialized
INFO - 2023-08-19 01:59:14 --> Router Class Initialized
INFO - 2023-08-19 01:59:14 --> Output Class Initialized
INFO - 2023-08-19 01:59:14 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:14 --> Input Class Initialized
INFO - 2023-08-19 01:59:14 --> Language Class Initialized
INFO - 2023-08-19 01:59:14 --> Loader Class Initialized
INFO - 2023-08-19 01:59:14 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:14 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:14 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:14 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:14 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:14 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:14 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:14 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:14 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:14 --> Parser Class Initialized
INFO - 2023-08-19 01:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:14 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:14 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:14 --> Controller Class Initialized
INFO - 2023-08-19 01:59:14 --> Model Class Initialized
INFO - 2023-08-19 01:59:14 --> Model Class Initialized
INFO - 2023-08-19 01:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-19 01:59:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:14 --> Model Class Initialized
INFO - 2023-08-19 01:59:14 --> Model Class Initialized
INFO - 2023-08-19 01:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:14 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:14 --> Total execution time: 0.0590
ERROR - 2023-08-19 01:59:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:15 --> Config Class Initialized
INFO - 2023-08-19 01:59:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:15 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:15 --> URI Class Initialized
INFO - 2023-08-19 01:59:15 --> Router Class Initialized
INFO - 2023-08-19 01:59:15 --> Output Class Initialized
INFO - 2023-08-19 01:59:15 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:15 --> Input Class Initialized
INFO - 2023-08-19 01:59:15 --> Language Class Initialized
INFO - 2023-08-19 01:59:15 --> Loader Class Initialized
INFO - 2023-08-19 01:59:15 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:15 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:15 --> Parser Class Initialized
INFO - 2023-08-19 01:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:15 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:15 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:15 --> Controller Class Initialized
INFO - 2023-08-19 01:59:15 --> Model Class Initialized
INFO - 2023-08-19 01:59:15 --> Model Class Initialized
INFO - 2023-08-19 01:59:15 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:15 --> Total execution time: 0.0231
ERROR - 2023-08-19 01:59:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:15 --> Config Class Initialized
INFO - 2023-08-19 01:59:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:15 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:15 --> URI Class Initialized
INFO - 2023-08-19 01:59:15 --> Router Class Initialized
INFO - 2023-08-19 01:59:15 --> Output Class Initialized
INFO - 2023-08-19 01:59:15 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:15 --> Input Class Initialized
INFO - 2023-08-19 01:59:15 --> Language Class Initialized
INFO - 2023-08-19 01:59:15 --> Loader Class Initialized
INFO - 2023-08-19 01:59:15 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:15 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:15 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:15 --> Parser Class Initialized
INFO - 2023-08-19 01:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:15 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:15 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:15 --> Controller Class Initialized
INFO - 2023-08-19 01:59:15 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:15 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:15 --> Model Class Initialized
INFO - 2023-08-19 01:59:16 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:16 --> Total execution time: 0.5078
ERROR - 2023-08-19 01:59:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:23 --> Config Class Initialized
INFO - 2023-08-19 01:59:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:23 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:23 --> URI Class Initialized
INFO - 2023-08-19 01:59:23 --> Router Class Initialized
INFO - 2023-08-19 01:59:23 --> Output Class Initialized
INFO - 2023-08-19 01:59:23 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:23 --> Input Class Initialized
INFO - 2023-08-19 01:59:23 --> Language Class Initialized
INFO - 2023-08-19 01:59:23 --> Loader Class Initialized
INFO - 2023-08-19 01:59:23 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:23 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:23 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:23 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:23 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:23 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:23 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:23 --> Parser Class Initialized
INFO - 2023-08-19 01:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:23 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:23 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:23 --> Controller Class Initialized
DEBUG - 2023-08-19 01:59:23 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:23 --> Model Class Initialized
INFO - 2023-08-19 01:59:23 --> Model Class Initialized
INFO - 2023-08-19 01:59:23 --> Model Class Initialized
INFO - 2023-08-19 01:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-08-19 01:59:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:23 --> Model Class Initialized
INFO - 2023-08-19 01:59:23 --> Model Class Initialized
INFO - 2023-08-19 01:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:23 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:23 --> Total execution time: 0.0606
ERROR - 2023-08-19 01:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:27 --> Config Class Initialized
INFO - 2023-08-19 01:59:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:27 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:27 --> URI Class Initialized
INFO - 2023-08-19 01:59:27 --> Router Class Initialized
INFO - 2023-08-19 01:59:27 --> Output Class Initialized
INFO - 2023-08-19 01:59:27 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:27 --> Input Class Initialized
INFO - 2023-08-19 01:59:27 --> Language Class Initialized
INFO - 2023-08-19 01:59:27 --> Loader Class Initialized
INFO - 2023-08-19 01:59:27 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:27 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:27 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:27 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:27 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:27 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:27 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:27 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:27 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:27 --> Parser Class Initialized
INFO - 2023-08-19 01:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:27 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:27 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:27 --> Controller Class Initialized
INFO - 2023-08-19 01:59:27 --> Model Class Initialized
INFO - 2023-08-19 01:59:27 --> Model Class Initialized
INFO - 2023-08-19 01:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-19 01:59:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:27 --> Model Class Initialized
INFO - 2023-08-19 01:59:27 --> Model Class Initialized
INFO - 2023-08-19 01:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:27 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:27 --> Total execution time: 0.0554
ERROR - 2023-08-19 01:59:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:28 --> Config Class Initialized
INFO - 2023-08-19 01:59:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:28 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:28 --> URI Class Initialized
INFO - 2023-08-19 01:59:28 --> Router Class Initialized
INFO - 2023-08-19 01:59:28 --> Output Class Initialized
INFO - 2023-08-19 01:59:28 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:28 --> Input Class Initialized
INFO - 2023-08-19 01:59:28 --> Language Class Initialized
INFO - 2023-08-19 01:59:28 --> Loader Class Initialized
INFO - 2023-08-19 01:59:28 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:28 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:28 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:28 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:28 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:28 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:28 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:28 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:28 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:28 --> Parser Class Initialized
INFO - 2023-08-19 01:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:28 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:28 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:28 --> Controller Class Initialized
INFO - 2023-08-19 01:59:28 --> Model Class Initialized
INFO - 2023-08-19 01:59:28 --> Model Class Initialized
INFO - 2023-08-19 01:59:28 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:28 --> Total execution time: 0.0230
ERROR - 2023-08-19 01:59:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:35 --> Config Class Initialized
INFO - 2023-08-19 01:59:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:35 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:35 --> URI Class Initialized
INFO - 2023-08-19 01:59:35 --> Router Class Initialized
INFO - 2023-08-19 01:59:35 --> Output Class Initialized
INFO - 2023-08-19 01:59:35 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:35 --> Input Class Initialized
INFO - 2023-08-19 01:59:35 --> Language Class Initialized
INFO - 2023-08-19 01:59:35 --> Loader Class Initialized
INFO - 2023-08-19 01:59:35 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:35 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:35 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:35 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:35 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:35 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:35 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:35 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:35 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:35 --> Parser Class Initialized
INFO - 2023-08-19 01:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:35 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:35 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:35 --> Controller Class Initialized
DEBUG - 2023-08-19 01:59:35 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:35 --> Model Class Initialized
INFO - 2023-08-19 01:59:35 --> Model Class Initialized
INFO - 2023-08-19 01:59:35 --> Model Class Initialized
INFO - 2023-08-19 01:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-08-19 01:59:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:35 --> Model Class Initialized
INFO - 2023-08-19 01:59:35 --> Model Class Initialized
INFO - 2023-08-19 01:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:35 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:35 --> Total execution time: 0.0586
ERROR - 2023-08-19 01:59:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:41 --> Config Class Initialized
INFO - 2023-08-19 01:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:41 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:41 --> URI Class Initialized
INFO - 2023-08-19 01:59:41 --> Router Class Initialized
INFO - 2023-08-19 01:59:41 --> Output Class Initialized
INFO - 2023-08-19 01:59:41 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:41 --> Input Class Initialized
INFO - 2023-08-19 01:59:41 --> Language Class Initialized
INFO - 2023-08-19 01:59:41 --> Loader Class Initialized
INFO - 2023-08-19 01:59:41 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:41 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:41 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:41 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:41 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:41 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:41 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:41 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:41 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:41 --> Parser Class Initialized
INFO - 2023-08-19 01:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:41 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:41 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:41 --> Controller Class Initialized
INFO - 2023-08-19 01:59:41 --> Model Class Initialized
INFO - 2023-08-19 01:59:41 --> Model Class Initialized
INFO - 2023-08-19 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-19 01:59:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:41 --> Model Class Initialized
INFO - 2023-08-19 01:59:41 --> Model Class Initialized
INFO - 2023-08-19 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:41 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:41 --> Total execution time: 0.0562
ERROR - 2023-08-19 01:59:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:42 --> Config Class Initialized
INFO - 2023-08-19 01:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:42 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:42 --> URI Class Initialized
INFO - 2023-08-19 01:59:42 --> Router Class Initialized
INFO - 2023-08-19 01:59:42 --> Output Class Initialized
INFO - 2023-08-19 01:59:42 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:42 --> Input Class Initialized
INFO - 2023-08-19 01:59:42 --> Language Class Initialized
INFO - 2023-08-19 01:59:42 --> Loader Class Initialized
INFO - 2023-08-19 01:59:42 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:42 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:42 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:42 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:42 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:42 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:42 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:42 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:42 --> Parser Class Initialized
INFO - 2023-08-19 01:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:42 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:42 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:42 --> Controller Class Initialized
INFO - 2023-08-19 01:59:42 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:42 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:42 --> Model Class Initialized
INFO - 2023-08-19 01:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 01:59:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:42 --> Model Class Initialized
INFO - 2023-08-19 01:59:42 --> Model Class Initialized
INFO - 2023-08-19 01:59:42 --> Model Class Initialized
INFO - 2023-08-19 01:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:42 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:42 --> Total execution time: 0.0651
ERROR - 2023-08-19 01:59:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:43 --> Config Class Initialized
INFO - 2023-08-19 01:59:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:43 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:43 --> URI Class Initialized
INFO - 2023-08-19 01:59:43 --> Router Class Initialized
INFO - 2023-08-19 01:59:43 --> Output Class Initialized
INFO - 2023-08-19 01:59:43 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:43 --> Input Class Initialized
INFO - 2023-08-19 01:59:43 --> Language Class Initialized
INFO - 2023-08-19 01:59:43 --> Loader Class Initialized
INFO - 2023-08-19 01:59:43 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:43 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:43 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:43 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:43 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:43 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:43 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:43 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:43 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:43 --> Parser Class Initialized
INFO - 2023-08-19 01:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:43 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:43 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:43 --> Controller Class Initialized
INFO - 2023-08-19 01:59:43 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 01:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:43 --> Model Class Initialized
DEBUG - 2023-08-19 01:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:43 --> Model Class Initialized
INFO - 2023-08-19 01:59:43 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:43 --> Total execution time: 0.0241
ERROR - 2023-08-19 01:59:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:45 --> Config Class Initialized
INFO - 2023-08-19 01:59:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:45 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:45 --> URI Class Initialized
INFO - 2023-08-19 01:59:45 --> Router Class Initialized
INFO - 2023-08-19 01:59:45 --> Output Class Initialized
INFO - 2023-08-19 01:59:45 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:45 --> Input Class Initialized
INFO - 2023-08-19 01:59:45 --> Language Class Initialized
INFO - 2023-08-19 01:59:45 --> Loader Class Initialized
INFO - 2023-08-19 01:59:45 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:45 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:45 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:45 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:45 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:45 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:45 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:45 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:45 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:45 --> Parser Class Initialized
INFO - 2023-08-19 01:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:45 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:45 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:45 --> Controller Class Initialized
INFO - 2023-08-19 01:59:45 --> Model Class Initialized
INFO - 2023-08-19 01:59:45 --> Model Class Initialized
INFO - 2023-08-19 01:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-19 01:59:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 01:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 01:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 01:59:45 --> Model Class Initialized
INFO - 2023-08-19 01:59:45 --> Model Class Initialized
INFO - 2023-08-19 01:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 01:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 01:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 01:59:45 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:45 --> Total execution time: 0.0620
ERROR - 2023-08-19 01:59:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 01:59:51 --> Config Class Initialized
INFO - 2023-08-19 01:59:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 01:59:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 01:59:51 --> Utf8 Class Initialized
INFO - 2023-08-19 01:59:51 --> URI Class Initialized
INFO - 2023-08-19 01:59:51 --> Router Class Initialized
INFO - 2023-08-19 01:59:51 --> Output Class Initialized
INFO - 2023-08-19 01:59:51 --> Security Class Initialized
DEBUG - 2023-08-19 01:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 01:59:51 --> Input Class Initialized
INFO - 2023-08-19 01:59:51 --> Language Class Initialized
INFO - 2023-08-19 01:59:51 --> Loader Class Initialized
INFO - 2023-08-19 01:59:51 --> Helper loaded: url_helper
INFO - 2023-08-19 01:59:51 --> Helper loaded: file_helper
INFO - 2023-08-19 01:59:51 --> Helper loaded: html_helper
INFO - 2023-08-19 01:59:51 --> Helper loaded: text_helper
INFO - 2023-08-19 01:59:51 --> Helper loaded: form_helper
INFO - 2023-08-19 01:59:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 01:59:51 --> Helper loaded: security_helper
INFO - 2023-08-19 01:59:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 01:59:51 --> Database Driver Class Initialized
INFO - 2023-08-19 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 01:59:51 --> Parser Class Initialized
INFO - 2023-08-19 01:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 01:59:51 --> Pagination Class Initialized
INFO - 2023-08-19 01:59:51 --> Form Validation Class Initialized
INFO - 2023-08-19 01:59:51 --> Controller Class Initialized
INFO - 2023-08-19 01:59:51 --> Model Class Initialized
INFO - 2023-08-19 01:59:51 --> Model Class Initialized
INFO - 2023-08-19 01:59:51 --> Final output sent to browser
DEBUG - 2023-08-19 01:59:51 --> Total execution time: 0.2420
ERROR - 2023-08-19 02:00:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:00:12 --> Config Class Initialized
INFO - 2023-08-19 02:00:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:00:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:00:12 --> Utf8 Class Initialized
INFO - 2023-08-19 02:00:12 --> URI Class Initialized
INFO - 2023-08-19 02:00:12 --> Router Class Initialized
INFO - 2023-08-19 02:00:12 --> Output Class Initialized
INFO - 2023-08-19 02:00:12 --> Security Class Initialized
DEBUG - 2023-08-19 02:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:00:12 --> Input Class Initialized
INFO - 2023-08-19 02:00:12 --> Language Class Initialized
INFO - 2023-08-19 02:00:12 --> Loader Class Initialized
INFO - 2023-08-19 02:00:12 --> Helper loaded: url_helper
INFO - 2023-08-19 02:00:12 --> Helper loaded: file_helper
INFO - 2023-08-19 02:00:12 --> Helper loaded: html_helper
INFO - 2023-08-19 02:00:12 --> Helper loaded: text_helper
INFO - 2023-08-19 02:00:12 --> Helper loaded: form_helper
INFO - 2023-08-19 02:00:12 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:00:12 --> Helper loaded: security_helper
INFO - 2023-08-19 02:00:12 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:00:12 --> Database Driver Class Initialized
INFO - 2023-08-19 02:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:00:12 --> Parser Class Initialized
INFO - 2023-08-19 02:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:00:12 --> Pagination Class Initialized
INFO - 2023-08-19 02:00:12 --> Form Validation Class Initialized
INFO - 2023-08-19 02:00:12 --> Controller Class Initialized
INFO - 2023-08-19 02:00:12 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:12 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:12 --> Model Class Initialized
INFO - 2023-08-19 02:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 02:00:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:00:12 --> Model Class Initialized
INFO - 2023-08-19 02:00:12 --> Model Class Initialized
INFO - 2023-08-19 02:00:12 --> Model Class Initialized
INFO - 2023-08-19 02:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:00:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:00:12 --> Final output sent to browser
DEBUG - 2023-08-19 02:00:12 --> Total execution time: 0.0692
ERROR - 2023-08-19 02:00:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:00:13 --> Config Class Initialized
INFO - 2023-08-19 02:00:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:00:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:00:13 --> Utf8 Class Initialized
INFO - 2023-08-19 02:00:13 --> URI Class Initialized
INFO - 2023-08-19 02:00:13 --> Router Class Initialized
INFO - 2023-08-19 02:00:13 --> Output Class Initialized
INFO - 2023-08-19 02:00:13 --> Security Class Initialized
DEBUG - 2023-08-19 02:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:00:13 --> Input Class Initialized
INFO - 2023-08-19 02:00:13 --> Language Class Initialized
INFO - 2023-08-19 02:00:13 --> Loader Class Initialized
INFO - 2023-08-19 02:00:13 --> Helper loaded: url_helper
INFO - 2023-08-19 02:00:13 --> Helper loaded: file_helper
INFO - 2023-08-19 02:00:13 --> Helper loaded: html_helper
INFO - 2023-08-19 02:00:13 --> Helper loaded: text_helper
INFO - 2023-08-19 02:00:13 --> Helper loaded: form_helper
INFO - 2023-08-19 02:00:13 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:00:13 --> Helper loaded: security_helper
INFO - 2023-08-19 02:00:13 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:00:13 --> Database Driver Class Initialized
INFO - 2023-08-19 02:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:00:13 --> Parser Class Initialized
INFO - 2023-08-19 02:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:00:13 --> Pagination Class Initialized
INFO - 2023-08-19 02:00:13 --> Form Validation Class Initialized
INFO - 2023-08-19 02:00:13 --> Controller Class Initialized
INFO - 2023-08-19 02:00:13 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:13 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:13 --> Model Class Initialized
INFO - 2023-08-19 02:00:13 --> Final output sent to browser
DEBUG - 2023-08-19 02:00:13 --> Total execution time: 0.0247
ERROR - 2023-08-19 02:00:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:00:14 --> Config Class Initialized
INFO - 2023-08-19 02:00:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:00:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:00:14 --> Utf8 Class Initialized
INFO - 2023-08-19 02:00:14 --> URI Class Initialized
DEBUG - 2023-08-19 02:00:14 --> No URI present. Default controller set.
INFO - 2023-08-19 02:00:14 --> Router Class Initialized
INFO - 2023-08-19 02:00:14 --> Output Class Initialized
INFO - 2023-08-19 02:00:14 --> Security Class Initialized
DEBUG - 2023-08-19 02:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:00:14 --> Input Class Initialized
INFO - 2023-08-19 02:00:14 --> Language Class Initialized
INFO - 2023-08-19 02:00:14 --> Loader Class Initialized
INFO - 2023-08-19 02:00:14 --> Helper loaded: url_helper
INFO - 2023-08-19 02:00:14 --> Helper loaded: file_helper
INFO - 2023-08-19 02:00:14 --> Helper loaded: html_helper
INFO - 2023-08-19 02:00:14 --> Helper loaded: text_helper
INFO - 2023-08-19 02:00:14 --> Helper loaded: form_helper
INFO - 2023-08-19 02:00:14 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:00:14 --> Helper loaded: security_helper
INFO - 2023-08-19 02:00:14 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:00:14 --> Database Driver Class Initialized
INFO - 2023-08-19 02:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:00:14 --> Parser Class Initialized
INFO - 2023-08-19 02:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:00:14 --> Pagination Class Initialized
INFO - 2023-08-19 02:00:14 --> Form Validation Class Initialized
INFO - 2023-08-19 02:00:14 --> Controller Class Initialized
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
INFO - 2023-08-19 02:00:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 02:00:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:00:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:00:14 --> Model Class Initialized
INFO - 2023-08-19 02:00:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:00:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:00:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:00:14 --> Final output sent to browser
DEBUG - 2023-08-19 02:00:14 --> Total execution time: 0.0795
ERROR - 2023-08-19 02:00:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:00:17 --> Config Class Initialized
INFO - 2023-08-19 02:00:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:00:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:00:17 --> Utf8 Class Initialized
INFO - 2023-08-19 02:00:17 --> URI Class Initialized
INFO - 2023-08-19 02:00:17 --> Router Class Initialized
INFO - 2023-08-19 02:00:17 --> Output Class Initialized
INFO - 2023-08-19 02:00:17 --> Security Class Initialized
DEBUG - 2023-08-19 02:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:00:17 --> Input Class Initialized
INFO - 2023-08-19 02:00:17 --> Language Class Initialized
INFO - 2023-08-19 02:00:17 --> Loader Class Initialized
INFO - 2023-08-19 02:00:17 --> Helper loaded: url_helper
INFO - 2023-08-19 02:00:17 --> Helper loaded: file_helper
INFO - 2023-08-19 02:00:17 --> Helper loaded: html_helper
INFO - 2023-08-19 02:00:17 --> Helper loaded: text_helper
INFO - 2023-08-19 02:00:17 --> Helper loaded: form_helper
INFO - 2023-08-19 02:00:17 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:00:17 --> Helper loaded: security_helper
INFO - 2023-08-19 02:00:17 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:00:17 --> Database Driver Class Initialized
INFO - 2023-08-19 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:00:17 --> Parser Class Initialized
INFO - 2023-08-19 02:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:00:17 --> Pagination Class Initialized
INFO - 2023-08-19 02:00:17 --> Form Validation Class Initialized
INFO - 2023-08-19 02:00:17 --> Controller Class Initialized
INFO - 2023-08-19 02:00:17 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:17 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:17 --> Model Class Initialized
INFO - 2023-08-19 02:00:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 02:00:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:00:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:00:17 --> Model Class Initialized
INFO - 2023-08-19 02:00:17 --> Model Class Initialized
INFO - 2023-08-19 02:00:17 --> Model Class Initialized
INFO - 2023-08-19 02:00:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:00:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:00:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:00:17 --> Final output sent to browser
DEBUG - 2023-08-19 02:00:17 --> Total execution time: 0.1542
ERROR - 2023-08-19 02:00:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:00:18 --> Config Class Initialized
INFO - 2023-08-19 02:00:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:00:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:00:18 --> Utf8 Class Initialized
INFO - 2023-08-19 02:00:18 --> URI Class Initialized
INFO - 2023-08-19 02:00:18 --> Router Class Initialized
INFO - 2023-08-19 02:00:18 --> Output Class Initialized
INFO - 2023-08-19 02:00:18 --> Security Class Initialized
DEBUG - 2023-08-19 02:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:00:18 --> Input Class Initialized
INFO - 2023-08-19 02:00:18 --> Language Class Initialized
INFO - 2023-08-19 02:00:18 --> Loader Class Initialized
INFO - 2023-08-19 02:00:18 --> Helper loaded: url_helper
INFO - 2023-08-19 02:00:18 --> Helper loaded: file_helper
INFO - 2023-08-19 02:00:18 --> Helper loaded: html_helper
INFO - 2023-08-19 02:00:18 --> Helper loaded: text_helper
INFO - 2023-08-19 02:00:18 --> Helper loaded: form_helper
INFO - 2023-08-19 02:00:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:00:18 --> Helper loaded: security_helper
INFO - 2023-08-19 02:00:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:00:18 --> Database Driver Class Initialized
INFO - 2023-08-19 02:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:00:18 --> Parser Class Initialized
INFO - 2023-08-19 02:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:00:18 --> Pagination Class Initialized
INFO - 2023-08-19 02:00:18 --> Form Validation Class Initialized
INFO - 2023-08-19 02:00:18 --> Controller Class Initialized
INFO - 2023-08-19 02:00:18 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:18 --> Model Class Initialized
DEBUG - 2023-08-19 02:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:00:18 --> Model Class Initialized
INFO - 2023-08-19 02:00:18 --> Final output sent to browser
DEBUG - 2023-08-19 02:00:18 --> Total execution time: 0.0248
ERROR - 2023-08-19 02:02:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:07 --> Config Class Initialized
INFO - 2023-08-19 02:02:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:07 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:07 --> URI Class Initialized
DEBUG - 2023-08-19 02:02:07 --> No URI present. Default controller set.
INFO - 2023-08-19 02:02:07 --> Router Class Initialized
INFO - 2023-08-19 02:02:07 --> Output Class Initialized
INFO - 2023-08-19 02:02:07 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:07 --> Input Class Initialized
INFO - 2023-08-19 02:02:07 --> Language Class Initialized
INFO - 2023-08-19 02:02:07 --> Loader Class Initialized
INFO - 2023-08-19 02:02:07 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:07 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:07 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:07 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:07 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:07 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:07 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:07 --> Parser Class Initialized
INFO - 2023-08-19 02:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:07 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:07 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:07 --> Controller Class Initialized
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
INFO - 2023-08-19 02:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 02:02:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:02:07 --> Model Class Initialized
INFO - 2023-08-19 02:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:02:07 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:07 --> Total execution time: 0.2061
ERROR - 2023-08-19 02:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:31 --> Config Class Initialized
INFO - 2023-08-19 02:02:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:31 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:31 --> URI Class Initialized
INFO - 2023-08-19 02:02:31 --> Router Class Initialized
INFO - 2023-08-19 02:02:31 --> Output Class Initialized
INFO - 2023-08-19 02:02:31 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:31 --> Input Class Initialized
INFO - 2023-08-19 02:02:31 --> Language Class Initialized
INFO - 2023-08-19 02:02:31 --> Loader Class Initialized
INFO - 2023-08-19 02:02:31 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:31 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:31 --> Parser Class Initialized
INFO - 2023-08-19 02:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:31 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:31 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:31 --> Controller Class Initialized
INFO - 2023-08-19 02:02:31 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:31 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:31 --> Total execution time: 0.0156
ERROR - 2023-08-19 02:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:31 --> Config Class Initialized
INFO - 2023-08-19 02:02:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:31 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:31 --> URI Class Initialized
INFO - 2023-08-19 02:02:31 --> Router Class Initialized
INFO - 2023-08-19 02:02:31 --> Output Class Initialized
INFO - 2023-08-19 02:02:31 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:31 --> Input Class Initialized
INFO - 2023-08-19 02:02:31 --> Language Class Initialized
INFO - 2023-08-19 02:02:31 --> Loader Class Initialized
INFO - 2023-08-19 02:02:31 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:31 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:31 --> Parser Class Initialized
INFO - 2023-08-19 02:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:31 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:31 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:31 --> Controller Class Initialized
INFO - 2023-08-19 02:02:31 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 02:02:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:02:31 --> Model Class Initialized
INFO - 2023-08-19 02:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:02:31 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:31 --> Total execution time: 0.0296
ERROR - 2023-08-19 02:02:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:39 --> Config Class Initialized
INFO - 2023-08-19 02:02:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:39 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:39 --> URI Class Initialized
INFO - 2023-08-19 02:02:39 --> Router Class Initialized
INFO - 2023-08-19 02:02:39 --> Output Class Initialized
INFO - 2023-08-19 02:02:39 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:39 --> Input Class Initialized
INFO - 2023-08-19 02:02:39 --> Language Class Initialized
INFO - 2023-08-19 02:02:39 --> Loader Class Initialized
INFO - 2023-08-19 02:02:39 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:39 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:39 --> Parser Class Initialized
INFO - 2023-08-19 02:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:39 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:39 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:39 --> Controller Class Initialized
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
INFO - 2023-08-19 02:02:39 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:39 --> Total execution time: 0.0174
ERROR - 2023-08-19 02:02:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:39 --> Config Class Initialized
INFO - 2023-08-19 02:02:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:39 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:39 --> URI Class Initialized
DEBUG - 2023-08-19 02:02:39 --> No URI present. Default controller set.
INFO - 2023-08-19 02:02:39 --> Router Class Initialized
INFO - 2023-08-19 02:02:39 --> Output Class Initialized
INFO - 2023-08-19 02:02:39 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:39 --> Input Class Initialized
INFO - 2023-08-19 02:02:39 --> Language Class Initialized
INFO - 2023-08-19 02:02:39 --> Loader Class Initialized
INFO - 2023-08-19 02:02:39 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:39 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:39 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:39 --> Parser Class Initialized
INFO - 2023-08-19 02:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:39 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:39 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:39 --> Controller Class Initialized
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
INFO - 2023-08-19 02:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 02:02:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:02:39 --> Model Class Initialized
INFO - 2023-08-19 02:02:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:02:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:02:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:02:40 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:40 --> Total execution time: 0.1027
ERROR - 2023-08-19 02:02:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:50 --> Config Class Initialized
INFO - 2023-08-19 02:02:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:50 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:50 --> URI Class Initialized
DEBUG - 2023-08-19 02:02:50 --> No URI present. Default controller set.
INFO - 2023-08-19 02:02:50 --> Router Class Initialized
INFO - 2023-08-19 02:02:50 --> Output Class Initialized
INFO - 2023-08-19 02:02:50 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:50 --> Input Class Initialized
INFO - 2023-08-19 02:02:50 --> Language Class Initialized
INFO - 2023-08-19 02:02:50 --> Loader Class Initialized
INFO - 2023-08-19 02:02:50 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:50 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:50 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:50 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:50 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:50 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:50 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:50 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:50 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:50 --> Parser Class Initialized
INFO - 2023-08-19 02:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:50 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:50 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:50 --> Controller Class Initialized
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
INFO - 2023-08-19 02:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 02:02:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:02:50 --> Model Class Initialized
INFO - 2023-08-19 02:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:02:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:02:50 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:50 --> Total execution time: 0.0867
ERROR - 2023-08-19 02:02:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:54 --> Config Class Initialized
INFO - 2023-08-19 02:02:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:54 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:54 --> URI Class Initialized
INFO - 2023-08-19 02:02:54 --> Router Class Initialized
INFO - 2023-08-19 02:02:54 --> Output Class Initialized
INFO - 2023-08-19 02:02:54 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:54 --> Input Class Initialized
INFO - 2023-08-19 02:02:54 --> Language Class Initialized
INFO - 2023-08-19 02:02:54 --> Loader Class Initialized
INFO - 2023-08-19 02:02:54 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:54 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:54 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:54 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:54 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:54 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:54 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:54 --> Parser Class Initialized
INFO - 2023-08-19 02:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:54 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:54 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:54 --> Controller Class Initialized
INFO - 2023-08-19 02:02:54 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:54 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:54 --> Model Class Initialized
INFO - 2023-08-19 02:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 02:02:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:02:54 --> Model Class Initialized
INFO - 2023-08-19 02:02:54 --> Model Class Initialized
INFO - 2023-08-19 02:02:54 --> Model Class Initialized
INFO - 2023-08-19 02:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:02:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:02:54 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:54 --> Total execution time: 0.0719
ERROR - 2023-08-19 02:02:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:02:55 --> Config Class Initialized
INFO - 2023-08-19 02:02:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:02:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:02:55 --> Utf8 Class Initialized
INFO - 2023-08-19 02:02:55 --> URI Class Initialized
INFO - 2023-08-19 02:02:55 --> Router Class Initialized
INFO - 2023-08-19 02:02:55 --> Output Class Initialized
INFO - 2023-08-19 02:02:55 --> Security Class Initialized
DEBUG - 2023-08-19 02:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:02:55 --> Input Class Initialized
INFO - 2023-08-19 02:02:55 --> Language Class Initialized
INFO - 2023-08-19 02:02:55 --> Loader Class Initialized
INFO - 2023-08-19 02:02:55 --> Helper loaded: url_helper
INFO - 2023-08-19 02:02:55 --> Helper loaded: file_helper
INFO - 2023-08-19 02:02:55 --> Helper loaded: html_helper
INFO - 2023-08-19 02:02:55 --> Helper loaded: text_helper
INFO - 2023-08-19 02:02:55 --> Helper loaded: form_helper
INFO - 2023-08-19 02:02:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:02:55 --> Helper loaded: security_helper
INFO - 2023-08-19 02:02:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:02:55 --> Database Driver Class Initialized
INFO - 2023-08-19 02:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:02:55 --> Parser Class Initialized
INFO - 2023-08-19 02:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:02:55 --> Pagination Class Initialized
INFO - 2023-08-19 02:02:55 --> Form Validation Class Initialized
INFO - 2023-08-19 02:02:55 --> Controller Class Initialized
INFO - 2023-08-19 02:02:55 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:55 --> Model Class Initialized
DEBUG - 2023-08-19 02:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:02:55 --> Model Class Initialized
INFO - 2023-08-19 02:02:55 --> Final output sent to browser
DEBUG - 2023-08-19 02:02:55 --> Total execution time: 0.0360
ERROR - 2023-08-19 02:03:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:03:04 --> Config Class Initialized
INFO - 2023-08-19 02:03:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:03:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:03:04 --> Utf8 Class Initialized
INFO - 2023-08-19 02:03:04 --> URI Class Initialized
INFO - 2023-08-19 02:03:04 --> Router Class Initialized
INFO - 2023-08-19 02:03:04 --> Output Class Initialized
INFO - 2023-08-19 02:03:04 --> Security Class Initialized
DEBUG - 2023-08-19 02:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:03:04 --> Input Class Initialized
INFO - 2023-08-19 02:03:04 --> Language Class Initialized
INFO - 2023-08-19 02:03:04 --> Loader Class Initialized
INFO - 2023-08-19 02:03:04 --> Helper loaded: url_helper
INFO - 2023-08-19 02:03:04 --> Helper loaded: file_helper
INFO - 2023-08-19 02:03:04 --> Helper loaded: html_helper
INFO - 2023-08-19 02:03:04 --> Helper loaded: text_helper
INFO - 2023-08-19 02:03:04 --> Helper loaded: form_helper
INFO - 2023-08-19 02:03:04 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:03:04 --> Helper loaded: security_helper
INFO - 2023-08-19 02:03:04 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:03:04 --> Database Driver Class Initialized
INFO - 2023-08-19 02:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:03:04 --> Parser Class Initialized
INFO - 2023-08-19 02:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:03:04 --> Pagination Class Initialized
INFO - 2023-08-19 02:03:04 --> Form Validation Class Initialized
INFO - 2023-08-19 02:03:04 --> Controller Class Initialized
INFO - 2023-08-19 02:03:04 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:04 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:04 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-19 02:03:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:03:04 --> Model Class Initialized
INFO - 2023-08-19 02:03:04 --> Model Class Initialized
INFO - 2023-08-19 02:03:04 --> Model Class Initialized
INFO - 2023-08-19 02:03:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:03:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:03:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:03:05 --> Final output sent to browser
DEBUG - 2023-08-19 02:03:05 --> Total execution time: 0.1607
ERROR - 2023-08-19 02:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:03:45 --> Config Class Initialized
INFO - 2023-08-19 02:03:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:03:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:03:45 --> Utf8 Class Initialized
INFO - 2023-08-19 02:03:45 --> URI Class Initialized
DEBUG - 2023-08-19 02:03:45 --> No URI present. Default controller set.
INFO - 2023-08-19 02:03:45 --> Router Class Initialized
INFO - 2023-08-19 02:03:45 --> Output Class Initialized
INFO - 2023-08-19 02:03:45 --> Security Class Initialized
DEBUG - 2023-08-19 02:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:03:45 --> Input Class Initialized
INFO - 2023-08-19 02:03:45 --> Language Class Initialized
INFO - 2023-08-19 02:03:45 --> Loader Class Initialized
INFO - 2023-08-19 02:03:45 --> Helper loaded: url_helper
INFO - 2023-08-19 02:03:45 --> Helper loaded: file_helper
INFO - 2023-08-19 02:03:45 --> Helper loaded: html_helper
INFO - 2023-08-19 02:03:45 --> Helper loaded: text_helper
INFO - 2023-08-19 02:03:45 --> Helper loaded: form_helper
INFO - 2023-08-19 02:03:45 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:03:45 --> Helper loaded: security_helper
INFO - 2023-08-19 02:03:45 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:03:45 --> Database Driver Class Initialized
INFO - 2023-08-19 02:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:03:45 --> Parser Class Initialized
INFO - 2023-08-19 02:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:03:45 --> Pagination Class Initialized
INFO - 2023-08-19 02:03:45 --> Form Validation Class Initialized
INFO - 2023-08-19 02:03:45 --> Controller Class Initialized
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
INFO - 2023-08-19 02:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 02:03:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:03:45 --> Model Class Initialized
INFO - 2023-08-19 02:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:03:45 --> Final output sent to browser
DEBUG - 2023-08-19 02:03:45 --> Total execution time: 0.0897
ERROR - 2023-08-19 02:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 02:03:49 --> Config Class Initialized
INFO - 2023-08-19 02:03:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 02:03:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 02:03:49 --> Utf8 Class Initialized
INFO - 2023-08-19 02:03:49 --> URI Class Initialized
INFO - 2023-08-19 02:03:49 --> Router Class Initialized
INFO - 2023-08-19 02:03:49 --> Output Class Initialized
INFO - 2023-08-19 02:03:49 --> Security Class Initialized
DEBUG - 2023-08-19 02:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 02:03:49 --> Input Class Initialized
INFO - 2023-08-19 02:03:49 --> Language Class Initialized
INFO - 2023-08-19 02:03:49 --> Loader Class Initialized
INFO - 2023-08-19 02:03:49 --> Helper loaded: url_helper
INFO - 2023-08-19 02:03:49 --> Helper loaded: file_helper
INFO - 2023-08-19 02:03:49 --> Helper loaded: html_helper
INFO - 2023-08-19 02:03:49 --> Helper loaded: text_helper
INFO - 2023-08-19 02:03:49 --> Helper loaded: form_helper
INFO - 2023-08-19 02:03:49 --> Helper loaded: lang_helper
INFO - 2023-08-19 02:03:49 --> Helper loaded: security_helper
INFO - 2023-08-19 02:03:49 --> Helper loaded: cookie_helper
INFO - 2023-08-19 02:03:49 --> Database Driver Class Initialized
INFO - 2023-08-19 02:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 02:03:49 --> Parser Class Initialized
INFO - 2023-08-19 02:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 02:03:49 --> Pagination Class Initialized
INFO - 2023-08-19 02:03:49 --> Form Validation Class Initialized
INFO - 2023-08-19 02:03:49 --> Controller Class Initialized
INFO - 2023-08-19 02:03:49 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 02:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:49 --> Model Class Initialized
DEBUG - 2023-08-19 02:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:49 --> Model Class Initialized
INFO - 2023-08-19 02:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-19 02:03:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 02:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 02:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 02:03:49 --> Model Class Initialized
INFO - 2023-08-19 02:03:49 --> Model Class Initialized
INFO - 2023-08-19 02:03:49 --> Model Class Initialized
INFO - 2023-08-19 02:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 02:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 02:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 02:03:49 --> Final output sent to browser
DEBUG - 2023-08-19 02:03:49 --> Total execution time: 0.0905
ERROR - 2023-08-19 04:50:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:50:41 --> Config Class Initialized
INFO - 2023-08-19 04:50:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:41 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:41 --> URI Class Initialized
DEBUG - 2023-08-19 04:50:41 --> No URI present. Default controller set.
INFO - 2023-08-19 04:50:41 --> Router Class Initialized
INFO - 2023-08-19 04:50:41 --> Output Class Initialized
INFO - 2023-08-19 04:50:41 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:41 --> Input Class Initialized
INFO - 2023-08-19 04:50:41 --> Language Class Initialized
INFO - 2023-08-19 04:50:41 --> Loader Class Initialized
INFO - 2023-08-19 04:50:41 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: html_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: text_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: security_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:50:41 --> Database Driver Class Initialized
INFO - 2023-08-19 04:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:41 --> Parser Class Initialized
INFO - 2023-08-19 04:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:50:41 --> Pagination Class Initialized
INFO - 2023-08-19 04:50:41 --> Form Validation Class Initialized
INFO - 2023-08-19 04:50:41 --> Controller Class Initialized
INFO - 2023-08-19 04:50:41 --> Model Class Initialized
DEBUG - 2023-08-19 04:50:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 04:50:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:50:41 --> Config Class Initialized
INFO - 2023-08-19 04:50:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:41 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:41 --> URI Class Initialized
INFO - 2023-08-19 04:50:41 --> Router Class Initialized
INFO - 2023-08-19 04:50:41 --> Output Class Initialized
INFO - 2023-08-19 04:50:41 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:41 --> Input Class Initialized
INFO - 2023-08-19 04:50:41 --> Language Class Initialized
INFO - 2023-08-19 04:50:41 --> Loader Class Initialized
INFO - 2023-08-19 04:50:41 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: html_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: text_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: security_helper
INFO - 2023-08-19 04:50:41 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:50:41 --> Database Driver Class Initialized
INFO - 2023-08-19 04:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:41 --> Parser Class Initialized
INFO - 2023-08-19 04:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:50:41 --> Pagination Class Initialized
INFO - 2023-08-19 04:50:41 --> Form Validation Class Initialized
INFO - 2023-08-19 04:50:41 --> Controller Class Initialized
INFO - 2023-08-19 04:50:41 --> Model Class Initialized
DEBUG - 2023-08-19 04:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 04:50:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:50:41 --> Model Class Initialized
INFO - 2023-08-19 04:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:50:41 --> Final output sent to browser
DEBUG - 2023-08-19 04:50:41 --> Total execution time: 0.0307
ERROR - 2023-08-19 04:50:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:50:53 --> Config Class Initialized
INFO - 2023-08-19 04:50:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:53 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:53 --> URI Class Initialized
INFO - 2023-08-19 04:50:53 --> Router Class Initialized
INFO - 2023-08-19 04:50:53 --> Output Class Initialized
INFO - 2023-08-19 04:50:53 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:53 --> Input Class Initialized
INFO - 2023-08-19 04:50:53 --> Language Class Initialized
INFO - 2023-08-19 04:50:53 --> Loader Class Initialized
INFO - 2023-08-19 04:50:53 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: html_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: text_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: security_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:50:53 --> Database Driver Class Initialized
INFO - 2023-08-19 04:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:53 --> Parser Class Initialized
INFO - 2023-08-19 04:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:50:53 --> Pagination Class Initialized
INFO - 2023-08-19 04:50:53 --> Form Validation Class Initialized
INFO - 2023-08-19 04:50:53 --> Controller Class Initialized
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
DEBUG - 2023-08-19 04:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
INFO - 2023-08-19 04:50:53 --> Final output sent to browser
DEBUG - 2023-08-19 04:50:53 --> Total execution time: 0.0225
ERROR - 2023-08-19 04:50:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:50:53 --> Config Class Initialized
INFO - 2023-08-19 04:50:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:50:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:50:53 --> Utf8 Class Initialized
INFO - 2023-08-19 04:50:53 --> URI Class Initialized
DEBUG - 2023-08-19 04:50:53 --> No URI present. Default controller set.
INFO - 2023-08-19 04:50:53 --> Router Class Initialized
INFO - 2023-08-19 04:50:53 --> Output Class Initialized
INFO - 2023-08-19 04:50:53 --> Security Class Initialized
DEBUG - 2023-08-19 04:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:50:53 --> Input Class Initialized
INFO - 2023-08-19 04:50:53 --> Language Class Initialized
INFO - 2023-08-19 04:50:53 --> Loader Class Initialized
INFO - 2023-08-19 04:50:53 --> Helper loaded: url_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: file_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: html_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: text_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: form_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: security_helper
INFO - 2023-08-19 04:50:53 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:50:53 --> Database Driver Class Initialized
INFO - 2023-08-19 04:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:50:53 --> Parser Class Initialized
INFO - 2023-08-19 04:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:50:53 --> Pagination Class Initialized
INFO - 2023-08-19 04:50:53 --> Form Validation Class Initialized
INFO - 2023-08-19 04:50:53 --> Controller Class Initialized
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
DEBUG - 2023-08-19 04:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
DEBUG - 2023-08-19 04:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
DEBUG - 2023-08-19 04:50:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
INFO - 2023-08-19 04:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 04:50:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:50:53 --> Model Class Initialized
INFO - 2023-08-19 04:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:50:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:50:53 --> Final output sent to browser
DEBUG - 2023-08-19 04:50:53 --> Total execution time: 0.0868
ERROR - 2023-08-19 04:51:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:51:18 --> Config Class Initialized
INFO - 2023-08-19 04:51:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:51:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:51:18 --> Utf8 Class Initialized
INFO - 2023-08-19 04:51:18 --> URI Class Initialized
INFO - 2023-08-19 04:51:18 --> Router Class Initialized
INFO - 2023-08-19 04:51:18 --> Output Class Initialized
INFO - 2023-08-19 04:51:18 --> Security Class Initialized
DEBUG - 2023-08-19 04:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:51:18 --> Input Class Initialized
INFO - 2023-08-19 04:51:18 --> Language Class Initialized
INFO - 2023-08-19 04:51:18 --> Loader Class Initialized
INFO - 2023-08-19 04:51:18 --> Helper loaded: url_helper
INFO - 2023-08-19 04:51:18 --> Helper loaded: file_helper
INFO - 2023-08-19 04:51:18 --> Helper loaded: html_helper
INFO - 2023-08-19 04:51:18 --> Helper loaded: text_helper
INFO - 2023-08-19 04:51:18 --> Helper loaded: form_helper
INFO - 2023-08-19 04:51:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:51:18 --> Helper loaded: security_helper
INFO - 2023-08-19 04:51:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:51:18 --> Database Driver Class Initialized
INFO - 2023-08-19 04:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:51:18 --> Parser Class Initialized
INFO - 2023-08-19 04:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:51:18 --> Pagination Class Initialized
INFO - 2023-08-19 04:51:18 --> Form Validation Class Initialized
INFO - 2023-08-19 04:51:18 --> Controller Class Initialized
DEBUG - 2023-08-19 04:51:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:18 --> Model Class Initialized
DEBUG - 2023-08-19 04:51:18 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:18 --> Model Class Initialized
DEBUG - 2023-08-19 04:51:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:18 --> Model Class Initialized
DEBUG - 2023-08-19 04:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:18 --> Model Class Initialized
INFO - 2023-08-19 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-08-19 04:51:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:51:18 --> Model Class Initialized
INFO - 2023-08-19 04:51:18 --> Model Class Initialized
INFO - 2023-08-19 04:51:18 --> Model Class Initialized
INFO - 2023-08-19 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:51:18 --> Final output sent to browser
DEBUG - 2023-08-19 04:51:18 --> Total execution time: 0.0639
ERROR - 2023-08-19 04:51:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:51:19 --> Config Class Initialized
INFO - 2023-08-19 04:51:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:51:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:51:19 --> Utf8 Class Initialized
INFO - 2023-08-19 04:51:19 --> URI Class Initialized
INFO - 2023-08-19 04:51:19 --> Router Class Initialized
INFO - 2023-08-19 04:51:19 --> Output Class Initialized
INFO - 2023-08-19 04:51:19 --> Security Class Initialized
DEBUG - 2023-08-19 04:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:51:19 --> Input Class Initialized
INFO - 2023-08-19 04:51:19 --> Language Class Initialized
INFO - 2023-08-19 04:51:19 --> Loader Class Initialized
INFO - 2023-08-19 04:51:19 --> Helper loaded: url_helper
INFO - 2023-08-19 04:51:19 --> Helper loaded: file_helper
INFO - 2023-08-19 04:51:19 --> Helper loaded: html_helper
INFO - 2023-08-19 04:51:19 --> Helper loaded: text_helper
INFO - 2023-08-19 04:51:19 --> Helper loaded: form_helper
INFO - 2023-08-19 04:51:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:51:19 --> Helper loaded: security_helper
INFO - 2023-08-19 04:51:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:51:19 --> Database Driver Class Initialized
INFO - 2023-08-19 04:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:51:19 --> Parser Class Initialized
INFO - 2023-08-19 04:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:51:19 --> Pagination Class Initialized
INFO - 2023-08-19 04:51:19 --> Form Validation Class Initialized
INFO - 2023-08-19 04:51:19 --> Controller Class Initialized
DEBUG - 2023-08-19 04:51:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:19 --> Model Class Initialized
INFO - 2023-08-19 04:51:19 --> Final output sent to browser
DEBUG - 2023-08-19 04:51:19 --> Total execution time: 0.0174
ERROR - 2023-08-19 04:51:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:51:46 --> Config Class Initialized
INFO - 2023-08-19 04:51:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:51:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:51:46 --> Utf8 Class Initialized
INFO - 2023-08-19 04:51:46 --> URI Class Initialized
DEBUG - 2023-08-19 04:51:46 --> No URI present. Default controller set.
INFO - 2023-08-19 04:51:46 --> Router Class Initialized
INFO - 2023-08-19 04:51:46 --> Output Class Initialized
INFO - 2023-08-19 04:51:46 --> Security Class Initialized
DEBUG - 2023-08-19 04:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:51:46 --> Input Class Initialized
INFO - 2023-08-19 04:51:46 --> Language Class Initialized
INFO - 2023-08-19 04:51:46 --> Loader Class Initialized
INFO - 2023-08-19 04:51:46 --> Helper loaded: url_helper
INFO - 2023-08-19 04:51:46 --> Helper loaded: file_helper
INFO - 2023-08-19 04:51:46 --> Helper loaded: html_helper
INFO - 2023-08-19 04:51:46 --> Helper loaded: text_helper
INFO - 2023-08-19 04:51:46 --> Helper loaded: form_helper
INFO - 2023-08-19 04:51:46 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:51:46 --> Helper loaded: security_helper
INFO - 2023-08-19 04:51:46 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:51:46 --> Database Driver Class Initialized
INFO - 2023-08-19 04:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:51:46 --> Parser Class Initialized
INFO - 2023-08-19 04:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:51:46 --> Pagination Class Initialized
INFO - 2023-08-19 04:51:46 --> Form Validation Class Initialized
INFO - 2023-08-19 04:51:46 --> Controller Class Initialized
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
DEBUG - 2023-08-19 04:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
DEBUG - 2023-08-19 04:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
DEBUG - 2023-08-19 04:51:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
INFO - 2023-08-19 04:51:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 04:51:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:51:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:51:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:51:46 --> Model Class Initialized
INFO - 2023-08-19 04:51:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:51:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:51:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:51:46 --> Final output sent to browser
DEBUG - 2023-08-19 04:51:46 --> Total execution time: 0.0815
ERROR - 2023-08-19 04:52:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:52:15 --> Config Class Initialized
INFO - 2023-08-19 04:52:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:52:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:52:15 --> Utf8 Class Initialized
INFO - 2023-08-19 04:52:15 --> URI Class Initialized
INFO - 2023-08-19 04:52:15 --> Router Class Initialized
INFO - 2023-08-19 04:52:15 --> Output Class Initialized
INFO - 2023-08-19 04:52:15 --> Security Class Initialized
DEBUG - 2023-08-19 04:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:52:15 --> Input Class Initialized
INFO - 2023-08-19 04:52:15 --> Language Class Initialized
INFO - 2023-08-19 04:52:15 --> Loader Class Initialized
INFO - 2023-08-19 04:52:15 --> Helper loaded: url_helper
INFO - 2023-08-19 04:52:15 --> Helper loaded: file_helper
INFO - 2023-08-19 04:52:15 --> Helper loaded: html_helper
INFO - 2023-08-19 04:52:15 --> Helper loaded: text_helper
INFO - 2023-08-19 04:52:15 --> Helper loaded: form_helper
INFO - 2023-08-19 04:52:15 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:52:15 --> Helper loaded: security_helper
INFO - 2023-08-19 04:52:15 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:52:15 --> Database Driver Class Initialized
INFO - 2023-08-19 04:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:52:15 --> Parser Class Initialized
INFO - 2023-08-19 04:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:52:15 --> Pagination Class Initialized
INFO - 2023-08-19 04:52:15 --> Form Validation Class Initialized
INFO - 2023-08-19 04:52:15 --> Controller Class Initialized
INFO - 2023-08-19 04:52:15 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:15 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:15 --> Model Class Initialized
INFO - 2023-08-19 04:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-19 04:52:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:52:15 --> Model Class Initialized
INFO - 2023-08-19 04:52:15 --> Model Class Initialized
INFO - 2023-08-19 04:52:15 --> Model Class Initialized
INFO - 2023-08-19 04:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:52:15 --> Final output sent to browser
DEBUG - 2023-08-19 04:52:15 --> Total execution time: 0.0666
ERROR - 2023-08-19 04:52:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:52:16 --> Config Class Initialized
INFO - 2023-08-19 04:52:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:52:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:52:16 --> Utf8 Class Initialized
INFO - 2023-08-19 04:52:16 --> URI Class Initialized
INFO - 2023-08-19 04:52:16 --> Router Class Initialized
INFO - 2023-08-19 04:52:16 --> Output Class Initialized
INFO - 2023-08-19 04:52:16 --> Security Class Initialized
DEBUG - 2023-08-19 04:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:52:16 --> Input Class Initialized
INFO - 2023-08-19 04:52:16 --> Language Class Initialized
INFO - 2023-08-19 04:52:16 --> Loader Class Initialized
INFO - 2023-08-19 04:52:16 --> Helper loaded: url_helper
INFO - 2023-08-19 04:52:16 --> Helper loaded: file_helper
INFO - 2023-08-19 04:52:16 --> Helper loaded: html_helper
INFO - 2023-08-19 04:52:16 --> Helper loaded: text_helper
INFO - 2023-08-19 04:52:16 --> Helper loaded: form_helper
INFO - 2023-08-19 04:52:16 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:52:16 --> Helper loaded: security_helper
INFO - 2023-08-19 04:52:16 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:52:16 --> Database Driver Class Initialized
INFO - 2023-08-19 04:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:52:16 --> Parser Class Initialized
INFO - 2023-08-19 04:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:52:16 --> Pagination Class Initialized
INFO - 2023-08-19 04:52:16 --> Form Validation Class Initialized
INFO - 2023-08-19 04:52:16 --> Controller Class Initialized
INFO - 2023-08-19 04:52:16 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:16 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:16 --> Model Class Initialized
INFO - 2023-08-19 04:52:16 --> Final output sent to browser
DEBUG - 2023-08-19 04:52:16 --> Total execution time: 0.0206
ERROR - 2023-08-19 04:52:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:52:20 --> Config Class Initialized
INFO - 2023-08-19 04:52:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:52:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:52:20 --> Utf8 Class Initialized
INFO - 2023-08-19 04:52:20 --> URI Class Initialized
DEBUG - 2023-08-19 04:52:20 --> No URI present. Default controller set.
INFO - 2023-08-19 04:52:20 --> Router Class Initialized
INFO - 2023-08-19 04:52:20 --> Output Class Initialized
INFO - 2023-08-19 04:52:20 --> Security Class Initialized
DEBUG - 2023-08-19 04:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:52:20 --> Input Class Initialized
INFO - 2023-08-19 04:52:20 --> Language Class Initialized
INFO - 2023-08-19 04:52:20 --> Loader Class Initialized
INFO - 2023-08-19 04:52:20 --> Helper loaded: url_helper
INFO - 2023-08-19 04:52:20 --> Helper loaded: file_helper
INFO - 2023-08-19 04:52:20 --> Helper loaded: html_helper
INFO - 2023-08-19 04:52:20 --> Helper loaded: text_helper
INFO - 2023-08-19 04:52:20 --> Helper loaded: form_helper
INFO - 2023-08-19 04:52:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:52:20 --> Helper loaded: security_helper
INFO - 2023-08-19 04:52:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:52:20 --> Database Driver Class Initialized
INFO - 2023-08-19 04:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:52:20 --> Parser Class Initialized
INFO - 2023-08-19 04:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:52:20 --> Pagination Class Initialized
INFO - 2023-08-19 04:52:20 --> Form Validation Class Initialized
INFO - 2023-08-19 04:52:20 --> Controller Class Initialized
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
INFO - 2023-08-19 04:52:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 04:52:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:52:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:52:20 --> Model Class Initialized
INFO - 2023-08-19 04:52:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:52:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:52:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:52:20 --> Final output sent to browser
DEBUG - 2023-08-19 04:52:20 --> Total execution time: 0.0739
ERROR - 2023-08-19 04:52:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:52:32 --> Config Class Initialized
INFO - 2023-08-19 04:52:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:52:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:52:32 --> Utf8 Class Initialized
INFO - 2023-08-19 04:52:32 --> URI Class Initialized
INFO - 2023-08-19 04:52:32 --> Router Class Initialized
INFO - 2023-08-19 04:52:32 --> Output Class Initialized
INFO - 2023-08-19 04:52:32 --> Security Class Initialized
DEBUG - 2023-08-19 04:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:52:32 --> Input Class Initialized
INFO - 2023-08-19 04:52:32 --> Language Class Initialized
INFO - 2023-08-19 04:52:32 --> Loader Class Initialized
INFO - 2023-08-19 04:52:32 --> Helper loaded: url_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: file_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: html_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: text_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: form_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: security_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:52:32 --> Database Driver Class Initialized
INFO - 2023-08-19 04:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:52:32 --> Parser Class Initialized
INFO - 2023-08-19 04:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:52:32 --> Pagination Class Initialized
INFO - 2023-08-19 04:52:32 --> Form Validation Class Initialized
INFO - 2023-08-19 04:52:32 --> Controller Class Initialized
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 04:52:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:52:32 --> Final output sent to browser
DEBUG - 2023-08-19 04:52:32 --> Total execution time: 0.0290
ERROR - 2023-08-19 04:52:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:52:32 --> Config Class Initialized
INFO - 2023-08-19 04:52:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:52:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:52:32 --> Utf8 Class Initialized
INFO - 2023-08-19 04:52:32 --> URI Class Initialized
INFO - 2023-08-19 04:52:32 --> Router Class Initialized
INFO - 2023-08-19 04:52:32 --> Output Class Initialized
INFO - 2023-08-19 04:52:32 --> Security Class Initialized
DEBUG - 2023-08-19 04:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:52:32 --> Input Class Initialized
INFO - 2023-08-19 04:52:32 --> Language Class Initialized
INFO - 2023-08-19 04:52:32 --> Loader Class Initialized
INFO - 2023-08-19 04:52:32 --> Helper loaded: url_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: file_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: html_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: text_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: form_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: security_helper
INFO - 2023-08-19 04:52:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:52:32 --> Database Driver Class Initialized
INFO - 2023-08-19 04:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:52:32 --> Parser Class Initialized
INFO - 2023-08-19 04:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:52:32 --> Pagination Class Initialized
INFO - 2023-08-19 04:52:32 --> Form Validation Class Initialized
INFO - 2023-08-19 04:52:32 --> Controller Class Initialized
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 04:52:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:52:32 --> Model Class Initialized
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:52:32 --> Final output sent to browser
DEBUG - 2023-08-19 04:52:32 --> Total execution time: 0.0773
ERROR - 2023-08-19 04:52:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:52:41 --> Config Class Initialized
INFO - 2023-08-19 04:52:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:52:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:52:41 --> Utf8 Class Initialized
INFO - 2023-08-19 04:52:41 --> URI Class Initialized
DEBUG - 2023-08-19 04:52:41 --> No URI present. Default controller set.
INFO - 2023-08-19 04:52:41 --> Router Class Initialized
INFO - 2023-08-19 04:52:41 --> Output Class Initialized
INFO - 2023-08-19 04:52:41 --> Security Class Initialized
DEBUG - 2023-08-19 04:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:52:41 --> Input Class Initialized
INFO - 2023-08-19 04:52:41 --> Language Class Initialized
INFO - 2023-08-19 04:52:41 --> Loader Class Initialized
INFO - 2023-08-19 04:52:41 --> Helper loaded: url_helper
INFO - 2023-08-19 04:52:41 --> Helper loaded: file_helper
INFO - 2023-08-19 04:52:41 --> Helper loaded: html_helper
INFO - 2023-08-19 04:52:41 --> Helper loaded: text_helper
INFO - 2023-08-19 04:52:41 --> Helper loaded: form_helper
INFO - 2023-08-19 04:52:41 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:52:41 --> Helper loaded: security_helper
INFO - 2023-08-19 04:52:41 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:52:41 --> Database Driver Class Initialized
INFO - 2023-08-19 04:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:52:41 --> Parser Class Initialized
INFO - 2023-08-19 04:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:52:41 --> Pagination Class Initialized
INFO - 2023-08-19 04:52:41 --> Form Validation Class Initialized
INFO - 2023-08-19 04:52:41 --> Controller Class Initialized
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
DEBUG - 2023-08-19 04:52:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
INFO - 2023-08-19 04:52:41 --> Model Class Initialized
INFO - 2023-08-19 04:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 04:52:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:52:42 --> Model Class Initialized
INFO - 2023-08-19 04:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:52:42 --> Final output sent to browser
DEBUG - 2023-08-19 04:52:42 --> Total execution time: 0.0832
ERROR - 2023-08-19 04:55:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:55:46 --> Config Class Initialized
INFO - 2023-08-19 04:55:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:55:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:55:46 --> Utf8 Class Initialized
INFO - 2023-08-19 04:55:46 --> URI Class Initialized
DEBUG - 2023-08-19 04:55:46 --> No URI present. Default controller set.
INFO - 2023-08-19 04:55:46 --> Router Class Initialized
INFO - 2023-08-19 04:55:46 --> Output Class Initialized
INFO - 2023-08-19 04:55:46 --> Security Class Initialized
DEBUG - 2023-08-19 04:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:55:46 --> Input Class Initialized
INFO - 2023-08-19 04:55:46 --> Language Class Initialized
INFO - 2023-08-19 04:55:46 --> Loader Class Initialized
INFO - 2023-08-19 04:55:46 --> Helper loaded: url_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: file_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: html_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: text_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: form_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: security_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:55:46 --> Database Driver Class Initialized
INFO - 2023-08-19 04:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:55:46 --> Parser Class Initialized
INFO - 2023-08-19 04:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:55:46 --> Pagination Class Initialized
INFO - 2023-08-19 04:55:46 --> Form Validation Class Initialized
INFO - 2023-08-19 04:55:46 --> Controller Class Initialized
INFO - 2023-08-19 04:55:46 --> Model Class Initialized
DEBUG - 2023-08-19 04:55:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 04:55:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:55:46 --> Config Class Initialized
INFO - 2023-08-19 04:55:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:55:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:55:46 --> Utf8 Class Initialized
INFO - 2023-08-19 04:55:46 --> URI Class Initialized
INFO - 2023-08-19 04:55:46 --> Router Class Initialized
INFO - 2023-08-19 04:55:46 --> Output Class Initialized
INFO - 2023-08-19 04:55:46 --> Security Class Initialized
DEBUG - 2023-08-19 04:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:55:46 --> Input Class Initialized
INFO - 2023-08-19 04:55:46 --> Language Class Initialized
INFO - 2023-08-19 04:55:46 --> Loader Class Initialized
INFO - 2023-08-19 04:55:46 --> Helper loaded: url_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: file_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: html_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: text_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: form_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: security_helper
INFO - 2023-08-19 04:55:46 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:55:46 --> Database Driver Class Initialized
INFO - 2023-08-19 04:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:55:46 --> Parser Class Initialized
INFO - 2023-08-19 04:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:55:46 --> Pagination Class Initialized
INFO - 2023-08-19 04:55:46 --> Form Validation Class Initialized
INFO - 2023-08-19 04:55:46 --> Controller Class Initialized
INFO - 2023-08-19 04:55:46 --> Model Class Initialized
DEBUG - 2023-08-19 04:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 04:55:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:55:46 --> Model Class Initialized
INFO - 2023-08-19 04:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:55:46 --> Final output sent to browser
DEBUG - 2023-08-19 04:55:46 --> Total execution time: 0.0288
ERROR - 2023-08-19 04:56:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:56:02 --> Config Class Initialized
INFO - 2023-08-19 04:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:02 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:02 --> URI Class Initialized
INFO - 2023-08-19 04:56:02 --> Router Class Initialized
INFO - 2023-08-19 04:56:02 --> Output Class Initialized
INFO - 2023-08-19 04:56:02 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:02 --> Input Class Initialized
INFO - 2023-08-19 04:56:02 --> Language Class Initialized
INFO - 2023-08-19 04:56:02 --> Loader Class Initialized
INFO - 2023-08-19 04:56:02 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:02 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:02 --> Helper loaded: html_helper
INFO - 2023-08-19 04:56:02 --> Helper loaded: text_helper
INFO - 2023-08-19 04:56:02 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:56:02 --> Helper loaded: security_helper
INFO - 2023-08-19 04:56:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:56:02 --> Database Driver Class Initialized
INFO - 2023-08-19 04:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:02 --> Parser Class Initialized
INFO - 2023-08-19 04:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:56:02 --> Pagination Class Initialized
INFO - 2023-08-19 04:56:02 --> Form Validation Class Initialized
INFO - 2023-08-19 04:56:02 --> Controller Class Initialized
INFO - 2023-08-19 04:56:02 --> Model Class Initialized
DEBUG - 2023-08-19 04:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:56:02 --> Model Class Initialized
INFO - 2023-08-19 04:56:02 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:02 --> Total execution time: 0.0191
ERROR - 2023-08-19 04:56:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 04:56:03 --> Config Class Initialized
INFO - 2023-08-19 04:56:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 04:56:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 04:56:03 --> Utf8 Class Initialized
INFO - 2023-08-19 04:56:03 --> URI Class Initialized
DEBUG - 2023-08-19 04:56:03 --> No URI present. Default controller set.
INFO - 2023-08-19 04:56:03 --> Router Class Initialized
INFO - 2023-08-19 04:56:03 --> Output Class Initialized
INFO - 2023-08-19 04:56:03 --> Security Class Initialized
DEBUG - 2023-08-19 04:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 04:56:03 --> Input Class Initialized
INFO - 2023-08-19 04:56:03 --> Language Class Initialized
INFO - 2023-08-19 04:56:03 --> Loader Class Initialized
INFO - 2023-08-19 04:56:03 --> Helper loaded: url_helper
INFO - 2023-08-19 04:56:03 --> Helper loaded: file_helper
INFO - 2023-08-19 04:56:03 --> Helper loaded: html_helper
INFO - 2023-08-19 04:56:03 --> Helper loaded: text_helper
INFO - 2023-08-19 04:56:03 --> Helper loaded: form_helper
INFO - 2023-08-19 04:56:03 --> Helper loaded: lang_helper
INFO - 2023-08-19 04:56:03 --> Helper loaded: security_helper
INFO - 2023-08-19 04:56:03 --> Helper loaded: cookie_helper
INFO - 2023-08-19 04:56:03 --> Database Driver Class Initialized
INFO - 2023-08-19 04:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 04:56:03 --> Parser Class Initialized
INFO - 2023-08-19 04:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 04:56:03 --> Pagination Class Initialized
INFO - 2023-08-19 04:56:03 --> Form Validation Class Initialized
INFO - 2023-08-19 04:56:03 --> Controller Class Initialized
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
DEBUG - 2023-08-19 04:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
DEBUG - 2023-08-19 04:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
DEBUG - 2023-08-19 04:56:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 04:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
INFO - 2023-08-19 04:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 04:56:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 04:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 04:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 04:56:03 --> Model Class Initialized
INFO - 2023-08-19 04:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 04:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 04:56:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 04:56:03 --> Final output sent to browser
DEBUG - 2023-08-19 04:56:03 --> Total execution time: 0.0773
ERROR - 2023-08-19 05:29:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:29:35 --> Config Class Initialized
INFO - 2023-08-19 05:29:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:29:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:29:35 --> Utf8 Class Initialized
INFO - 2023-08-19 05:29:35 --> URI Class Initialized
DEBUG - 2023-08-19 05:29:35 --> No URI present. Default controller set.
INFO - 2023-08-19 05:29:35 --> Router Class Initialized
INFO - 2023-08-19 05:29:35 --> Output Class Initialized
INFO - 2023-08-19 05:29:35 --> Security Class Initialized
DEBUG - 2023-08-19 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:29:35 --> Input Class Initialized
INFO - 2023-08-19 05:29:35 --> Language Class Initialized
INFO - 2023-08-19 05:29:35 --> Loader Class Initialized
INFO - 2023-08-19 05:29:35 --> Helper loaded: url_helper
INFO - 2023-08-19 05:29:35 --> Helper loaded: file_helper
INFO - 2023-08-19 05:29:35 --> Helper loaded: html_helper
INFO - 2023-08-19 05:29:35 --> Helper loaded: text_helper
INFO - 2023-08-19 05:29:35 --> Helper loaded: form_helper
INFO - 2023-08-19 05:29:35 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:29:35 --> Helper loaded: security_helper
INFO - 2023-08-19 05:29:35 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:29:35 --> Database Driver Class Initialized
INFO - 2023-08-19 05:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:29:35 --> Parser Class Initialized
INFO - 2023-08-19 05:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:29:35 --> Pagination Class Initialized
INFO - 2023-08-19 05:29:35 --> Form Validation Class Initialized
INFO - 2023-08-19 05:29:35 --> Controller Class Initialized
INFO - 2023-08-19 05:29:35 --> Model Class Initialized
DEBUG - 2023-08-19 05:29:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 05:29:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:29:38 --> Config Class Initialized
INFO - 2023-08-19 05:29:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:29:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:29:38 --> Utf8 Class Initialized
INFO - 2023-08-19 05:29:38 --> URI Class Initialized
INFO - 2023-08-19 05:29:38 --> Router Class Initialized
INFO - 2023-08-19 05:29:38 --> Output Class Initialized
INFO - 2023-08-19 05:29:38 --> Security Class Initialized
DEBUG - 2023-08-19 05:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:29:38 --> Input Class Initialized
INFO - 2023-08-19 05:29:38 --> Language Class Initialized
INFO - 2023-08-19 05:29:38 --> Loader Class Initialized
INFO - 2023-08-19 05:29:38 --> Helper loaded: url_helper
INFO - 2023-08-19 05:29:38 --> Helper loaded: file_helper
INFO - 2023-08-19 05:29:38 --> Helper loaded: html_helper
INFO - 2023-08-19 05:29:38 --> Helper loaded: text_helper
INFO - 2023-08-19 05:29:38 --> Helper loaded: form_helper
INFO - 2023-08-19 05:29:38 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:29:38 --> Helper loaded: security_helper
INFO - 2023-08-19 05:29:38 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:29:38 --> Database Driver Class Initialized
INFO - 2023-08-19 05:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:29:38 --> Parser Class Initialized
INFO - 2023-08-19 05:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:29:38 --> Pagination Class Initialized
INFO - 2023-08-19 05:29:38 --> Form Validation Class Initialized
INFO - 2023-08-19 05:29:38 --> Controller Class Initialized
INFO - 2023-08-19 05:29:38 --> Model Class Initialized
DEBUG - 2023-08-19 05:29:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:29:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 05:29:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:29:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:29:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:29:38 --> Model Class Initialized
INFO - 2023-08-19 05:29:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:29:38 --> Final output sent to browser
DEBUG - 2023-08-19 05:29:38 --> Total execution time: 0.0289
ERROR - 2023-08-19 05:38:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:38:56 --> Config Class Initialized
INFO - 2023-08-19 05:38:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:38:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:38:56 --> Utf8 Class Initialized
INFO - 2023-08-19 05:38:56 --> URI Class Initialized
INFO - 2023-08-19 05:38:56 --> Router Class Initialized
INFO - 2023-08-19 05:38:56 --> Output Class Initialized
INFO - 2023-08-19 05:38:56 --> Security Class Initialized
DEBUG - 2023-08-19 05:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:38:56 --> Input Class Initialized
INFO - 2023-08-19 05:38:56 --> Language Class Initialized
INFO - 2023-08-19 05:38:56 --> Loader Class Initialized
INFO - 2023-08-19 05:38:56 --> Helper loaded: url_helper
INFO - 2023-08-19 05:38:56 --> Helper loaded: file_helper
INFO - 2023-08-19 05:38:56 --> Helper loaded: html_helper
INFO - 2023-08-19 05:38:56 --> Helper loaded: text_helper
INFO - 2023-08-19 05:38:56 --> Helper loaded: form_helper
INFO - 2023-08-19 05:38:56 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:38:56 --> Helper loaded: security_helper
INFO - 2023-08-19 05:38:56 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:38:56 --> Database Driver Class Initialized
INFO - 2023-08-19 05:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:38:56 --> Parser Class Initialized
INFO - 2023-08-19 05:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:38:56 --> Pagination Class Initialized
INFO - 2023-08-19 05:38:56 --> Form Validation Class Initialized
INFO - 2023-08-19 05:38:56 --> Controller Class Initialized
INFO - 2023-08-19 05:38:56 --> Model Class Initialized
DEBUG - 2023-08-19 05:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 05:38:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:38:56 --> Model Class Initialized
INFO - 2023-08-19 05:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:38:56 --> Final output sent to browser
DEBUG - 2023-08-19 05:38:56 --> Total execution time: 0.0305
ERROR - 2023-08-19 05:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:39:17 --> Config Class Initialized
INFO - 2023-08-19 05:39:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:39:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:39:17 --> Utf8 Class Initialized
INFO - 2023-08-19 05:39:17 --> URI Class Initialized
DEBUG - 2023-08-19 05:39:17 --> No URI present. Default controller set.
INFO - 2023-08-19 05:39:17 --> Router Class Initialized
INFO - 2023-08-19 05:39:17 --> Output Class Initialized
INFO - 2023-08-19 05:39:17 --> Security Class Initialized
DEBUG - 2023-08-19 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:39:17 --> Input Class Initialized
INFO - 2023-08-19 05:39:17 --> Language Class Initialized
INFO - 2023-08-19 05:39:17 --> Loader Class Initialized
INFO - 2023-08-19 05:39:17 --> Helper loaded: url_helper
INFO - 2023-08-19 05:39:17 --> Helper loaded: file_helper
INFO - 2023-08-19 05:39:17 --> Helper loaded: html_helper
INFO - 2023-08-19 05:39:17 --> Helper loaded: text_helper
INFO - 2023-08-19 05:39:17 --> Helper loaded: form_helper
INFO - 2023-08-19 05:39:17 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:39:17 --> Helper loaded: security_helper
INFO - 2023-08-19 05:39:17 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:39:17 --> Database Driver Class Initialized
INFO - 2023-08-19 05:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:39:17 --> Parser Class Initialized
INFO - 2023-08-19 05:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:39:17 --> Pagination Class Initialized
INFO - 2023-08-19 05:39:17 --> Form Validation Class Initialized
INFO - 2023-08-19 05:39:17 --> Controller Class Initialized
INFO - 2023-08-19 05:39:17 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 05:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:39:19 --> Config Class Initialized
INFO - 2023-08-19 05:39:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:39:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:39:19 --> Utf8 Class Initialized
INFO - 2023-08-19 05:39:19 --> URI Class Initialized
INFO - 2023-08-19 05:39:19 --> Router Class Initialized
INFO - 2023-08-19 05:39:19 --> Output Class Initialized
INFO - 2023-08-19 05:39:19 --> Security Class Initialized
DEBUG - 2023-08-19 05:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:39:19 --> Input Class Initialized
INFO - 2023-08-19 05:39:19 --> Language Class Initialized
INFO - 2023-08-19 05:39:19 --> Loader Class Initialized
INFO - 2023-08-19 05:39:19 --> Helper loaded: url_helper
INFO - 2023-08-19 05:39:19 --> Helper loaded: file_helper
INFO - 2023-08-19 05:39:19 --> Helper loaded: html_helper
INFO - 2023-08-19 05:39:19 --> Helper loaded: text_helper
INFO - 2023-08-19 05:39:19 --> Helper loaded: form_helper
INFO - 2023-08-19 05:39:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:39:19 --> Helper loaded: security_helper
INFO - 2023-08-19 05:39:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:39:19 --> Database Driver Class Initialized
INFO - 2023-08-19 05:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:39:19 --> Parser Class Initialized
INFO - 2023-08-19 05:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:39:19 --> Pagination Class Initialized
INFO - 2023-08-19 05:39:19 --> Form Validation Class Initialized
INFO - 2023-08-19 05:39:19 --> Controller Class Initialized
INFO - 2023-08-19 05:39:19 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 05:39:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:39:19 --> Model Class Initialized
INFO - 2023-08-19 05:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:39:19 --> Final output sent to browser
DEBUG - 2023-08-19 05:39:19 --> Total execution time: 0.0328
ERROR - 2023-08-19 05:39:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:39:44 --> Config Class Initialized
INFO - 2023-08-19 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:39:44 --> Utf8 Class Initialized
INFO - 2023-08-19 05:39:44 --> URI Class Initialized
INFO - 2023-08-19 05:39:44 --> Router Class Initialized
INFO - 2023-08-19 05:39:44 --> Output Class Initialized
INFO - 2023-08-19 05:39:44 --> Security Class Initialized
DEBUG - 2023-08-19 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:39:44 --> Input Class Initialized
INFO - 2023-08-19 05:39:44 --> Language Class Initialized
INFO - 2023-08-19 05:39:44 --> Loader Class Initialized
INFO - 2023-08-19 05:39:44 --> Helper loaded: url_helper
INFO - 2023-08-19 05:39:44 --> Helper loaded: file_helper
INFO - 2023-08-19 05:39:44 --> Helper loaded: html_helper
INFO - 2023-08-19 05:39:44 --> Helper loaded: text_helper
INFO - 2023-08-19 05:39:44 --> Helper loaded: form_helper
INFO - 2023-08-19 05:39:44 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:39:44 --> Helper loaded: security_helper
INFO - 2023-08-19 05:39:44 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:39:44 --> Database Driver Class Initialized
INFO - 2023-08-19 05:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:39:44 --> Parser Class Initialized
INFO - 2023-08-19 05:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:39:44 --> Pagination Class Initialized
INFO - 2023-08-19 05:39:44 --> Form Validation Class Initialized
INFO - 2023-08-19 05:39:44 --> Controller Class Initialized
INFO - 2023-08-19 05:39:44 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:44 --> Model Class Initialized
INFO - 2023-08-19 05:39:44 --> Final output sent to browser
DEBUG - 2023-08-19 05:39:44 --> Total execution time: 0.0198
ERROR - 2023-08-19 05:39:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:39:46 --> Config Class Initialized
INFO - 2023-08-19 05:39:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:39:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:39:46 --> Utf8 Class Initialized
INFO - 2023-08-19 05:39:46 --> URI Class Initialized
DEBUG - 2023-08-19 05:39:46 --> No URI present. Default controller set.
INFO - 2023-08-19 05:39:46 --> Router Class Initialized
INFO - 2023-08-19 05:39:46 --> Output Class Initialized
INFO - 2023-08-19 05:39:46 --> Security Class Initialized
DEBUG - 2023-08-19 05:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:39:46 --> Input Class Initialized
INFO - 2023-08-19 05:39:46 --> Language Class Initialized
INFO - 2023-08-19 05:39:46 --> Loader Class Initialized
INFO - 2023-08-19 05:39:46 --> Helper loaded: url_helper
INFO - 2023-08-19 05:39:46 --> Helper loaded: file_helper
INFO - 2023-08-19 05:39:46 --> Helper loaded: html_helper
INFO - 2023-08-19 05:39:46 --> Helper loaded: text_helper
INFO - 2023-08-19 05:39:46 --> Helper loaded: form_helper
INFO - 2023-08-19 05:39:46 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:39:46 --> Helper loaded: security_helper
INFO - 2023-08-19 05:39:46 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:39:46 --> Database Driver Class Initialized
INFO - 2023-08-19 05:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:39:46 --> Parser Class Initialized
INFO - 2023-08-19 05:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:39:46 --> Pagination Class Initialized
INFO - 2023-08-19 05:39:46 --> Form Validation Class Initialized
INFO - 2023-08-19 05:39:46 --> Controller Class Initialized
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
INFO - 2023-08-19 05:39:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 05:39:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:39:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:39:46 --> Model Class Initialized
INFO - 2023-08-19 05:39:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:39:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:39:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:39:46 --> Final output sent to browser
DEBUG - 2023-08-19 05:39:46 --> Total execution time: 0.0928
ERROR - 2023-08-19 05:39:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:39:55 --> Config Class Initialized
INFO - 2023-08-19 05:39:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:39:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:39:55 --> Utf8 Class Initialized
INFO - 2023-08-19 05:39:55 --> URI Class Initialized
INFO - 2023-08-19 05:39:55 --> Router Class Initialized
INFO - 2023-08-19 05:39:55 --> Output Class Initialized
INFO - 2023-08-19 05:39:55 --> Security Class Initialized
DEBUG - 2023-08-19 05:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:39:55 --> Input Class Initialized
INFO - 2023-08-19 05:39:55 --> Language Class Initialized
INFO - 2023-08-19 05:39:55 --> Loader Class Initialized
INFO - 2023-08-19 05:39:55 --> Helper loaded: url_helper
INFO - 2023-08-19 05:39:55 --> Helper loaded: file_helper
INFO - 2023-08-19 05:39:55 --> Helper loaded: html_helper
INFO - 2023-08-19 05:39:55 --> Helper loaded: text_helper
INFO - 2023-08-19 05:39:55 --> Helper loaded: form_helper
INFO - 2023-08-19 05:39:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:39:55 --> Helper loaded: security_helper
INFO - 2023-08-19 05:39:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:39:55 --> Database Driver Class Initialized
INFO - 2023-08-19 05:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:39:55 --> Parser Class Initialized
INFO - 2023-08-19 05:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:39:55 --> Pagination Class Initialized
INFO - 2023-08-19 05:39:55 --> Form Validation Class Initialized
INFO - 2023-08-19 05:39:55 --> Controller Class Initialized
INFO - 2023-08-19 05:39:55 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:55 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:55 --> Model Class Initialized
INFO - 2023-08-19 05:39:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 05:39:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:39:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:39:55 --> Model Class Initialized
INFO - 2023-08-19 05:39:55 --> Model Class Initialized
INFO - 2023-08-19 05:39:55 --> Model Class Initialized
INFO - 2023-08-19 05:39:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:39:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:39:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:39:55 --> Final output sent to browser
DEBUG - 2023-08-19 05:39:55 --> Total execution time: 0.0772
ERROR - 2023-08-19 05:39:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:39:58 --> Config Class Initialized
INFO - 2023-08-19 05:39:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:39:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:39:58 --> Utf8 Class Initialized
INFO - 2023-08-19 05:39:58 --> URI Class Initialized
INFO - 2023-08-19 05:39:58 --> Router Class Initialized
INFO - 2023-08-19 05:39:58 --> Output Class Initialized
INFO - 2023-08-19 05:39:58 --> Security Class Initialized
DEBUG - 2023-08-19 05:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:39:58 --> Input Class Initialized
INFO - 2023-08-19 05:39:58 --> Language Class Initialized
INFO - 2023-08-19 05:39:58 --> Loader Class Initialized
INFO - 2023-08-19 05:39:58 --> Helper loaded: url_helper
INFO - 2023-08-19 05:39:58 --> Helper loaded: file_helper
INFO - 2023-08-19 05:39:58 --> Helper loaded: html_helper
INFO - 2023-08-19 05:39:58 --> Helper loaded: text_helper
INFO - 2023-08-19 05:39:58 --> Helper loaded: form_helper
INFO - 2023-08-19 05:39:58 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:39:58 --> Helper loaded: security_helper
INFO - 2023-08-19 05:39:58 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:39:58 --> Database Driver Class Initialized
INFO - 2023-08-19 05:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:39:58 --> Parser Class Initialized
INFO - 2023-08-19 05:39:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:39:58 --> Pagination Class Initialized
INFO - 2023-08-19 05:39:58 --> Form Validation Class Initialized
INFO - 2023-08-19 05:39:58 --> Controller Class Initialized
INFO - 2023-08-19 05:39:58 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:58 --> Model Class Initialized
DEBUG - 2023-08-19 05:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:39:58 --> Model Class Initialized
INFO - 2023-08-19 05:39:58 --> Final output sent to browser
DEBUG - 2023-08-19 05:39:58 --> Total execution time: 0.0404
ERROR - 2023-08-19 05:40:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:01 --> Config Class Initialized
INFO - 2023-08-19 05:40:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:01 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:01 --> URI Class Initialized
INFO - 2023-08-19 05:40:01 --> Router Class Initialized
INFO - 2023-08-19 05:40:01 --> Output Class Initialized
INFO - 2023-08-19 05:40:01 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:01 --> Input Class Initialized
INFO - 2023-08-19 05:40:01 --> Language Class Initialized
INFO - 2023-08-19 05:40:01 --> Loader Class Initialized
INFO - 2023-08-19 05:40:01 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:01 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:01 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:01 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:01 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:01 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:01 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:01 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:01 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:01 --> Parser Class Initialized
INFO - 2023-08-19 05:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:01 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:01 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:01 --> Controller Class Initialized
INFO - 2023-08-19 05:40:01 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:01 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:01 --> Model Class Initialized
INFO - 2023-08-19 05:40:01 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:01 --> Total execution time: 0.0392
ERROR - 2023-08-19 05:40:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:02 --> Config Class Initialized
INFO - 2023-08-19 05:40:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:02 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:02 --> URI Class Initialized
INFO - 2023-08-19 05:40:02 --> Router Class Initialized
INFO - 2023-08-19 05:40:02 --> Output Class Initialized
INFO - 2023-08-19 05:40:02 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:02 --> Input Class Initialized
INFO - 2023-08-19 05:40:02 --> Language Class Initialized
INFO - 2023-08-19 05:40:02 --> Loader Class Initialized
INFO - 2023-08-19 05:40:02 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:02 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:02 --> Parser Class Initialized
INFO - 2023-08-19 05:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:02 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:02 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:02 --> Controller Class Initialized
INFO - 2023-08-19 05:40:02 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:02 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:02 --> Model Class Initialized
INFO - 2023-08-19 05:40:02 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:02 --> Total execution time: 0.0444
ERROR - 2023-08-19 05:40:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:02 --> Config Class Initialized
INFO - 2023-08-19 05:40:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:02 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:02 --> URI Class Initialized
INFO - 2023-08-19 05:40:02 --> Router Class Initialized
INFO - 2023-08-19 05:40:02 --> Output Class Initialized
INFO - 2023-08-19 05:40:02 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:02 --> Input Class Initialized
INFO - 2023-08-19 05:40:02 --> Language Class Initialized
INFO - 2023-08-19 05:40:02 --> Loader Class Initialized
INFO - 2023-08-19 05:40:02 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:02 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:02 --> Parser Class Initialized
INFO - 2023-08-19 05:40:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:02 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:02 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:02 --> Controller Class Initialized
INFO - 2023-08-19 05:40:02 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:02 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:02 --> Model Class Initialized
INFO - 2023-08-19 05:40:02 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:02 --> Total execution time: 0.0297
ERROR - 2023-08-19 05:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:03 --> Config Class Initialized
INFO - 2023-08-19 05:40:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:03 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:03 --> URI Class Initialized
INFO - 2023-08-19 05:40:03 --> Router Class Initialized
INFO - 2023-08-19 05:40:03 --> Output Class Initialized
INFO - 2023-08-19 05:40:03 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:03 --> Input Class Initialized
INFO - 2023-08-19 05:40:03 --> Language Class Initialized
INFO - 2023-08-19 05:40:03 --> Loader Class Initialized
INFO - 2023-08-19 05:40:03 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:03 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:03 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:03 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:03 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:03 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:03 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:03 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:03 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:03 --> Parser Class Initialized
INFO - 2023-08-19 05:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:03 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:03 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:03 --> Controller Class Initialized
INFO - 2023-08-19 05:40:03 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:03 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:03 --> Model Class Initialized
INFO - 2023-08-19 05:40:03 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:03 --> Total execution time: 0.0253
ERROR - 2023-08-19 05:40:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:06 --> Config Class Initialized
INFO - 2023-08-19 05:40:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:06 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:06 --> URI Class Initialized
INFO - 2023-08-19 05:40:06 --> Router Class Initialized
INFO - 2023-08-19 05:40:06 --> Output Class Initialized
INFO - 2023-08-19 05:40:06 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:06 --> Input Class Initialized
INFO - 2023-08-19 05:40:06 --> Language Class Initialized
INFO - 2023-08-19 05:40:06 --> Loader Class Initialized
INFO - 2023-08-19 05:40:06 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:06 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:06 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:06 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:06 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:06 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:06 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:06 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:06 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:06 --> Parser Class Initialized
INFO - 2023-08-19 05:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:06 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:06 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:06 --> Controller Class Initialized
INFO - 2023-08-19 05:40:06 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:06 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:06 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-19 05:40:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:40:06 --> Model Class Initialized
INFO - 2023-08-19 05:40:06 --> Model Class Initialized
INFO - 2023-08-19 05:40:06 --> Model Class Initialized
INFO - 2023-08-19 05:40:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:40:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:40:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:40:07 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:07 --> Total execution time: 0.0877
ERROR - 2023-08-19 05:40:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:15 --> Config Class Initialized
INFO - 2023-08-19 05:40:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:15 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:15 --> URI Class Initialized
INFO - 2023-08-19 05:40:15 --> Router Class Initialized
INFO - 2023-08-19 05:40:15 --> Output Class Initialized
INFO - 2023-08-19 05:40:15 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:15 --> Input Class Initialized
INFO - 2023-08-19 05:40:15 --> Language Class Initialized
INFO - 2023-08-19 05:40:15 --> Loader Class Initialized
INFO - 2023-08-19 05:40:15 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:15 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:15 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:15 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:15 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:15 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:15 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:15 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:15 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:15 --> Parser Class Initialized
INFO - 2023-08-19 05:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:15 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:15 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:15 --> Controller Class Initialized
INFO - 2023-08-19 05:40:15 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:15 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:15 --> Model Class Initialized
INFO - 2023-08-19 05:40:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 05:40:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:40:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:40:15 --> Model Class Initialized
INFO - 2023-08-19 05:40:15 --> Model Class Initialized
INFO - 2023-08-19 05:40:15 --> Model Class Initialized
INFO - 2023-08-19 05:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:40:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:40:16 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:16 --> Total execution time: 0.0802
ERROR - 2023-08-19 05:40:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:18 --> Config Class Initialized
INFO - 2023-08-19 05:40:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:18 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:18 --> URI Class Initialized
DEBUG - 2023-08-19 05:40:18 --> No URI present. Default controller set.
INFO - 2023-08-19 05:40:18 --> Router Class Initialized
INFO - 2023-08-19 05:40:18 --> Output Class Initialized
INFO - 2023-08-19 05:40:18 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:18 --> Input Class Initialized
INFO - 2023-08-19 05:40:18 --> Language Class Initialized
INFO - 2023-08-19 05:40:18 --> Loader Class Initialized
INFO - 2023-08-19 05:40:18 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:18 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:18 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:18 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:18 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:18 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:18 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:18 --> Parser Class Initialized
INFO - 2023-08-19 05:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:18 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:18 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:18 --> Controller Class Initialized
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
INFO - 2023-08-19 05:40:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 05:40:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:40:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:40:18 --> Model Class Initialized
INFO - 2023-08-19 05:40:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:40:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:40:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:40:18 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:18 --> Total execution time: 0.0875
ERROR - 2023-08-19 05:40:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:21 --> Config Class Initialized
INFO - 2023-08-19 05:40:21 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:21 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:21 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:21 --> URI Class Initialized
INFO - 2023-08-19 05:40:21 --> Router Class Initialized
INFO - 2023-08-19 05:40:21 --> Output Class Initialized
INFO - 2023-08-19 05:40:21 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:21 --> Input Class Initialized
INFO - 2023-08-19 05:40:21 --> Language Class Initialized
INFO - 2023-08-19 05:40:21 --> Loader Class Initialized
INFO - 2023-08-19 05:40:21 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:21 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:21 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:21 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:21 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:21 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:21 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:21 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:21 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:21 --> Parser Class Initialized
INFO - 2023-08-19 05:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:21 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:21 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:21 --> Controller Class Initialized
INFO - 2023-08-19 05:40:21 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:21 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:21 --> Model Class Initialized
INFO - 2023-08-19 05:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 05:40:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:40:21 --> Model Class Initialized
INFO - 2023-08-19 05:40:21 --> Model Class Initialized
INFO - 2023-08-19 05:40:21 --> Model Class Initialized
INFO - 2023-08-19 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:40:22 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:22 --> Total execution time: 0.0858
ERROR - 2023-08-19 05:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:23 --> Config Class Initialized
INFO - 2023-08-19 05:40:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:23 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:23 --> URI Class Initialized
INFO - 2023-08-19 05:40:23 --> Router Class Initialized
INFO - 2023-08-19 05:40:23 --> Output Class Initialized
INFO - 2023-08-19 05:40:23 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:23 --> Input Class Initialized
INFO - 2023-08-19 05:40:23 --> Language Class Initialized
INFO - 2023-08-19 05:40:23 --> Loader Class Initialized
INFO - 2023-08-19 05:40:23 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:23 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:23 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:23 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:23 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:23 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:23 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:23 --> Parser Class Initialized
INFO - 2023-08-19 05:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:23 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:23 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:23 --> Controller Class Initialized
INFO - 2023-08-19 05:40:23 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:23 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:23 --> Model Class Initialized
INFO - 2023-08-19 05:40:23 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:23 --> Total execution time: 0.0405
ERROR - 2023-08-19 05:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:51 --> Config Class Initialized
INFO - 2023-08-19 05:40:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:51 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:51 --> URI Class Initialized
INFO - 2023-08-19 05:40:51 --> Router Class Initialized
INFO - 2023-08-19 05:40:51 --> Output Class Initialized
INFO - 2023-08-19 05:40:51 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:51 --> Input Class Initialized
INFO - 2023-08-19 05:40:51 --> Language Class Initialized
INFO - 2023-08-19 05:40:51 --> Loader Class Initialized
INFO - 2023-08-19 05:40:51 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:51 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:51 --> Parser Class Initialized
INFO - 2023-08-19 05:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:51 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:51 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:51 --> Controller Class Initialized
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
INFO - 2023-08-19 05:40:51 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:51 --> Total execution time: 0.0449
ERROR - 2023-08-19 05:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:51 --> Config Class Initialized
INFO - 2023-08-19 05:40:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:51 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:51 --> URI Class Initialized
INFO - 2023-08-19 05:40:51 --> Router Class Initialized
INFO - 2023-08-19 05:40:51 --> Output Class Initialized
INFO - 2023-08-19 05:40:51 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:51 --> Input Class Initialized
INFO - 2023-08-19 05:40:51 --> Language Class Initialized
INFO - 2023-08-19 05:40:51 --> Loader Class Initialized
INFO - 2023-08-19 05:40:51 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:51 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:51 --> Parser Class Initialized
INFO - 2023-08-19 05:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:51 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:51 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:51 --> Controller Class Initialized
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
INFO - 2023-08-19 05:40:51 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:51 --> Total execution time: 0.0306
ERROR - 2023-08-19 05:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:51 --> Config Class Initialized
INFO - 2023-08-19 05:40:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:51 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:51 --> URI Class Initialized
INFO - 2023-08-19 05:40:51 --> Router Class Initialized
INFO - 2023-08-19 05:40:51 --> Output Class Initialized
INFO - 2023-08-19 05:40:51 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:51 --> Input Class Initialized
INFO - 2023-08-19 05:40:51 --> Language Class Initialized
INFO - 2023-08-19 05:40:51 --> Loader Class Initialized
INFO - 2023-08-19 05:40:51 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:51 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:51 --> Parser Class Initialized
INFO - 2023-08-19 05:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:51 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:51 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:51 --> Controller Class Initialized
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
INFO - 2023-08-19 05:40:51 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:51 --> Total execution time: 0.0309
ERROR - 2023-08-19 05:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:40:51 --> Config Class Initialized
INFO - 2023-08-19 05:40:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:40:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:40:51 --> Utf8 Class Initialized
INFO - 2023-08-19 05:40:51 --> URI Class Initialized
INFO - 2023-08-19 05:40:51 --> Router Class Initialized
INFO - 2023-08-19 05:40:51 --> Output Class Initialized
INFO - 2023-08-19 05:40:51 --> Security Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:40:51 --> Input Class Initialized
INFO - 2023-08-19 05:40:51 --> Language Class Initialized
INFO - 2023-08-19 05:40:51 --> Loader Class Initialized
INFO - 2023-08-19 05:40:51 --> Helper loaded: url_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: file_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: html_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: text_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: form_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: security_helper
INFO - 2023-08-19 05:40:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:40:51 --> Database Driver Class Initialized
INFO - 2023-08-19 05:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:40:51 --> Parser Class Initialized
INFO - 2023-08-19 05:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:40:51 --> Pagination Class Initialized
INFO - 2023-08-19 05:40:51 --> Form Validation Class Initialized
INFO - 2023-08-19 05:40:51 --> Controller Class Initialized
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
DEBUG - 2023-08-19 05:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:40:51 --> Model Class Initialized
INFO - 2023-08-19 05:40:51 --> Final output sent to browser
DEBUG - 2023-08-19 05:40:51 --> Total execution time: 0.0248
ERROR - 2023-08-19 05:41:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:41:31 --> Config Class Initialized
INFO - 2023-08-19 05:41:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:41:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:41:31 --> Utf8 Class Initialized
INFO - 2023-08-19 05:41:31 --> URI Class Initialized
DEBUG - 2023-08-19 05:41:31 --> No URI present. Default controller set.
INFO - 2023-08-19 05:41:31 --> Router Class Initialized
INFO - 2023-08-19 05:41:31 --> Output Class Initialized
INFO - 2023-08-19 05:41:31 --> Security Class Initialized
DEBUG - 2023-08-19 05:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:41:31 --> Input Class Initialized
INFO - 2023-08-19 05:41:31 --> Language Class Initialized
INFO - 2023-08-19 05:41:31 --> Loader Class Initialized
INFO - 2023-08-19 05:41:31 --> Helper loaded: url_helper
INFO - 2023-08-19 05:41:31 --> Helper loaded: file_helper
INFO - 2023-08-19 05:41:31 --> Helper loaded: html_helper
INFO - 2023-08-19 05:41:31 --> Helper loaded: text_helper
INFO - 2023-08-19 05:41:31 --> Helper loaded: form_helper
INFO - 2023-08-19 05:41:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:41:31 --> Helper loaded: security_helper
INFO - 2023-08-19 05:41:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:41:31 --> Database Driver Class Initialized
INFO - 2023-08-19 05:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:41:31 --> Parser Class Initialized
INFO - 2023-08-19 05:41:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:41:31 --> Pagination Class Initialized
INFO - 2023-08-19 05:41:31 --> Form Validation Class Initialized
INFO - 2023-08-19 05:41:31 --> Controller Class Initialized
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
DEBUG - 2023-08-19 05:41:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
DEBUG - 2023-08-19 05:41:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
DEBUG - 2023-08-19 05:41:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:41:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
INFO - 2023-08-19 05:41:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 05:41:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:41:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:41:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:41:31 --> Model Class Initialized
INFO - 2023-08-19 05:41:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:41:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:41:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:41:31 --> Final output sent to browser
DEBUG - 2023-08-19 05:41:31 --> Total execution time: 0.0898
ERROR - 2023-08-19 05:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:42:18 --> Config Class Initialized
INFO - 2023-08-19 05:42:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:42:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:42:18 --> Utf8 Class Initialized
INFO - 2023-08-19 05:42:18 --> URI Class Initialized
INFO - 2023-08-19 05:42:18 --> Router Class Initialized
INFO - 2023-08-19 05:42:18 --> Output Class Initialized
INFO - 2023-08-19 05:42:18 --> Security Class Initialized
DEBUG - 2023-08-19 05:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:42:18 --> Input Class Initialized
INFO - 2023-08-19 05:42:18 --> Language Class Initialized
INFO - 2023-08-19 05:42:18 --> Loader Class Initialized
INFO - 2023-08-19 05:42:18 --> Helper loaded: url_helper
INFO - 2023-08-19 05:42:18 --> Helper loaded: file_helper
INFO - 2023-08-19 05:42:18 --> Helper loaded: html_helper
INFO - 2023-08-19 05:42:18 --> Helper loaded: text_helper
INFO - 2023-08-19 05:42:18 --> Helper loaded: form_helper
INFO - 2023-08-19 05:42:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:42:18 --> Helper loaded: security_helper
INFO - 2023-08-19 05:42:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:42:18 --> Database Driver Class Initialized
INFO - 2023-08-19 05:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:42:18 --> Parser Class Initialized
INFO - 2023-08-19 05:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:42:18 --> Pagination Class Initialized
INFO - 2023-08-19 05:42:18 --> Form Validation Class Initialized
INFO - 2023-08-19 05:42:18 --> Controller Class Initialized
DEBUG - 2023-08-19 05:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:18 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:18 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:18 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:18 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:18 --> Model Class Initialized
INFO - 2023-08-19 05:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-08-19 05:42:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:42:18 --> Model Class Initialized
INFO - 2023-08-19 05:42:18 --> Model Class Initialized
INFO - 2023-08-19 05:42:18 --> Model Class Initialized
INFO - 2023-08-19 05:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:42:18 --> Final output sent to browser
DEBUG - 2023-08-19 05:42:18 --> Total execution time: 0.0744
ERROR - 2023-08-19 05:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:42:20 --> Config Class Initialized
INFO - 2023-08-19 05:42:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:42:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:42:20 --> Utf8 Class Initialized
INFO - 2023-08-19 05:42:20 --> URI Class Initialized
INFO - 2023-08-19 05:42:20 --> Router Class Initialized
INFO - 2023-08-19 05:42:20 --> Output Class Initialized
INFO - 2023-08-19 05:42:20 --> Security Class Initialized
DEBUG - 2023-08-19 05:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:42:20 --> Input Class Initialized
INFO - 2023-08-19 05:42:20 --> Language Class Initialized
INFO - 2023-08-19 05:42:20 --> Loader Class Initialized
INFO - 2023-08-19 05:42:20 --> Helper loaded: url_helper
INFO - 2023-08-19 05:42:20 --> Helper loaded: file_helper
INFO - 2023-08-19 05:42:20 --> Helper loaded: html_helper
INFO - 2023-08-19 05:42:20 --> Helper loaded: text_helper
INFO - 2023-08-19 05:42:20 --> Helper loaded: form_helper
INFO - 2023-08-19 05:42:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:42:20 --> Helper loaded: security_helper
INFO - 2023-08-19 05:42:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:42:20 --> Database Driver Class Initialized
INFO - 2023-08-19 05:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:42:20 --> Parser Class Initialized
INFO - 2023-08-19 05:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:42:20 --> Pagination Class Initialized
INFO - 2023-08-19 05:42:20 --> Form Validation Class Initialized
INFO - 2023-08-19 05:42:20 --> Controller Class Initialized
DEBUG - 2023-08-19 05:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:20 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:20 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:20 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:20 --> Model Class Initialized
INFO - 2023-08-19 05:42:20 --> Final output sent to browser
DEBUG - 2023-08-19 05:42:20 --> Total execution time: 0.0204
ERROR - 2023-08-19 05:42:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:42:43 --> Config Class Initialized
INFO - 2023-08-19 05:42:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:42:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:42:43 --> Utf8 Class Initialized
INFO - 2023-08-19 05:42:43 --> URI Class Initialized
DEBUG - 2023-08-19 05:42:43 --> No URI present. Default controller set.
INFO - 2023-08-19 05:42:43 --> Router Class Initialized
INFO - 2023-08-19 05:42:43 --> Output Class Initialized
INFO - 2023-08-19 05:42:43 --> Security Class Initialized
DEBUG - 2023-08-19 05:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:42:43 --> Input Class Initialized
INFO - 2023-08-19 05:42:43 --> Language Class Initialized
INFO - 2023-08-19 05:42:43 --> Loader Class Initialized
INFO - 2023-08-19 05:42:43 --> Helper loaded: url_helper
INFO - 2023-08-19 05:42:43 --> Helper loaded: file_helper
INFO - 2023-08-19 05:42:43 --> Helper loaded: html_helper
INFO - 2023-08-19 05:42:43 --> Helper loaded: text_helper
INFO - 2023-08-19 05:42:43 --> Helper loaded: form_helper
INFO - 2023-08-19 05:42:43 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:42:43 --> Helper loaded: security_helper
INFO - 2023-08-19 05:42:43 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:42:43 --> Database Driver Class Initialized
INFO - 2023-08-19 05:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:42:43 --> Parser Class Initialized
INFO - 2023-08-19 05:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:42:43 --> Pagination Class Initialized
INFO - 2023-08-19 05:42:43 --> Form Validation Class Initialized
INFO - 2023-08-19 05:42:43 --> Controller Class Initialized
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
INFO - 2023-08-19 05:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 05:42:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:42:43 --> Model Class Initialized
INFO - 2023-08-19 05:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:42:43 --> Final output sent to browser
DEBUG - 2023-08-19 05:42:43 --> Total execution time: 0.0906
ERROR - 2023-08-19 05:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:42:58 --> Config Class Initialized
INFO - 2023-08-19 05:42:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:42:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:42:58 --> Utf8 Class Initialized
INFO - 2023-08-19 05:42:58 --> URI Class Initialized
INFO - 2023-08-19 05:42:58 --> Router Class Initialized
INFO - 2023-08-19 05:42:58 --> Output Class Initialized
INFO - 2023-08-19 05:42:58 --> Security Class Initialized
DEBUG - 2023-08-19 05:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:42:58 --> Input Class Initialized
INFO - 2023-08-19 05:42:58 --> Language Class Initialized
INFO - 2023-08-19 05:42:58 --> Loader Class Initialized
INFO - 2023-08-19 05:42:58 --> Helper loaded: url_helper
INFO - 2023-08-19 05:42:58 --> Helper loaded: file_helper
INFO - 2023-08-19 05:42:58 --> Helper loaded: html_helper
INFO - 2023-08-19 05:42:58 --> Helper loaded: text_helper
INFO - 2023-08-19 05:42:58 --> Helper loaded: form_helper
INFO - 2023-08-19 05:42:58 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:42:58 --> Helper loaded: security_helper
INFO - 2023-08-19 05:42:58 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:42:58 --> Database Driver Class Initialized
INFO - 2023-08-19 05:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:42:58 --> Parser Class Initialized
INFO - 2023-08-19 05:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:42:58 --> Pagination Class Initialized
INFO - 2023-08-19 05:42:58 --> Form Validation Class Initialized
INFO - 2023-08-19 05:42:58 --> Controller Class Initialized
INFO - 2023-08-19 05:42:58 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:58 --> Model Class Initialized
DEBUG - 2023-08-19 05:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:58 --> Model Class Initialized
INFO - 2023-08-19 05:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-19 05:42:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 05:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 05:42:58 --> Model Class Initialized
INFO - 2023-08-19 05:42:58 --> Model Class Initialized
INFO - 2023-08-19 05:42:58 --> Model Class Initialized
INFO - 2023-08-19 05:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 05:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 05:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 05:42:58 --> Final output sent to browser
DEBUG - 2023-08-19 05:42:58 --> Total execution time: 0.0743
ERROR - 2023-08-19 05:43:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 05:43:00 --> Config Class Initialized
INFO - 2023-08-19 05:43:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 05:43:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 05:43:00 --> Utf8 Class Initialized
INFO - 2023-08-19 05:43:00 --> URI Class Initialized
INFO - 2023-08-19 05:43:00 --> Router Class Initialized
INFO - 2023-08-19 05:43:00 --> Output Class Initialized
INFO - 2023-08-19 05:43:00 --> Security Class Initialized
DEBUG - 2023-08-19 05:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 05:43:00 --> Input Class Initialized
INFO - 2023-08-19 05:43:00 --> Language Class Initialized
INFO - 2023-08-19 05:43:00 --> Loader Class Initialized
INFO - 2023-08-19 05:43:00 --> Helper loaded: url_helper
INFO - 2023-08-19 05:43:00 --> Helper loaded: file_helper
INFO - 2023-08-19 05:43:00 --> Helper loaded: html_helper
INFO - 2023-08-19 05:43:00 --> Helper loaded: text_helper
INFO - 2023-08-19 05:43:00 --> Helper loaded: form_helper
INFO - 2023-08-19 05:43:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 05:43:00 --> Helper loaded: security_helper
INFO - 2023-08-19 05:43:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 05:43:00 --> Database Driver Class Initialized
INFO - 2023-08-19 05:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 05:43:00 --> Parser Class Initialized
INFO - 2023-08-19 05:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 05:43:00 --> Pagination Class Initialized
INFO - 2023-08-19 05:43:00 --> Form Validation Class Initialized
INFO - 2023-08-19 05:43:00 --> Controller Class Initialized
INFO - 2023-08-19 05:43:00 --> Model Class Initialized
DEBUG - 2023-08-19 05:43:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 05:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:43:00 --> Model Class Initialized
DEBUG - 2023-08-19 05:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 05:43:00 --> Model Class Initialized
INFO - 2023-08-19 05:43:00 --> Final output sent to browser
DEBUG - 2023-08-19 05:43:00 --> Total execution time: 0.0233
ERROR - 2023-08-19 06:02:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:02:17 --> Config Class Initialized
INFO - 2023-08-19 06:02:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:02:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:02:17 --> Utf8 Class Initialized
INFO - 2023-08-19 06:02:17 --> URI Class Initialized
INFO - 2023-08-19 06:02:17 --> Router Class Initialized
INFO - 2023-08-19 06:02:17 --> Output Class Initialized
INFO - 2023-08-19 06:02:17 --> Security Class Initialized
DEBUG - 2023-08-19 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:02:17 --> Input Class Initialized
INFO - 2023-08-19 06:02:17 --> Language Class Initialized
INFO - 2023-08-19 06:02:17 --> Loader Class Initialized
INFO - 2023-08-19 06:02:17 --> Helper loaded: url_helper
INFO - 2023-08-19 06:02:17 --> Helper loaded: file_helper
INFO - 2023-08-19 06:02:17 --> Helper loaded: html_helper
INFO - 2023-08-19 06:02:17 --> Helper loaded: text_helper
INFO - 2023-08-19 06:02:17 --> Helper loaded: form_helper
INFO - 2023-08-19 06:02:17 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:02:17 --> Helper loaded: security_helper
INFO - 2023-08-19 06:02:17 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:02:17 --> Database Driver Class Initialized
INFO - 2023-08-19 06:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:02:17 --> Parser Class Initialized
INFO - 2023-08-19 06:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:02:17 --> Pagination Class Initialized
INFO - 2023-08-19 06:02:17 --> Form Validation Class Initialized
INFO - 2023-08-19 06:02:17 --> Controller Class Initialized
DEBUG - 2023-08-19 06:02:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:17 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:17 --> Model Class Initialized
ERROR - 2023-08-19 06:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:02:18 --> Config Class Initialized
INFO - 2023-08-19 06:02:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:02:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:02:18 --> Utf8 Class Initialized
INFO - 2023-08-19 06:02:18 --> URI Class Initialized
INFO - 2023-08-19 06:02:18 --> Router Class Initialized
INFO - 2023-08-19 06:02:18 --> Output Class Initialized
INFO - 2023-08-19 06:02:18 --> Security Class Initialized
DEBUG - 2023-08-19 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:02:18 --> Input Class Initialized
INFO - 2023-08-19 06:02:18 --> Language Class Initialized
INFO - 2023-08-19 06:02:18 --> Loader Class Initialized
INFO - 2023-08-19 06:02:18 --> Helper loaded: url_helper
INFO - 2023-08-19 06:02:18 --> Helper loaded: file_helper
INFO - 2023-08-19 06:02:18 --> Helper loaded: html_helper
INFO - 2023-08-19 06:02:18 --> Helper loaded: text_helper
INFO - 2023-08-19 06:02:18 --> Helper loaded: form_helper
INFO - 2023-08-19 06:02:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:02:18 --> Helper loaded: security_helper
INFO - 2023-08-19 06:02:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:02:18 --> Database Driver Class Initialized
INFO - 2023-08-19 06:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:02:18 --> Parser Class Initialized
INFO - 2023-08-19 06:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:02:18 --> Pagination Class Initialized
INFO - 2023-08-19 06:02:18 --> Form Validation Class Initialized
INFO - 2023-08-19 06:02:18 --> Controller Class Initialized
INFO - 2023-08-19 06:02:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 06:02:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:02:18 --> Model Class Initialized
INFO - 2023-08-19 06:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:02:18 --> Final output sent to browser
DEBUG - 2023-08-19 06:02:18 --> Total execution time: 0.0288
ERROR - 2023-08-19 06:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:02:25 --> Config Class Initialized
INFO - 2023-08-19 06:02:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:02:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:02:25 --> Utf8 Class Initialized
INFO - 2023-08-19 06:02:25 --> URI Class Initialized
INFO - 2023-08-19 06:02:25 --> Router Class Initialized
INFO - 2023-08-19 06:02:25 --> Output Class Initialized
INFO - 2023-08-19 06:02:25 --> Security Class Initialized
DEBUG - 2023-08-19 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:02:25 --> Input Class Initialized
INFO - 2023-08-19 06:02:25 --> Language Class Initialized
INFO - 2023-08-19 06:02:25 --> Loader Class Initialized
INFO - 2023-08-19 06:02:25 --> Helper loaded: url_helper
INFO - 2023-08-19 06:02:25 --> Helper loaded: file_helper
INFO - 2023-08-19 06:02:25 --> Helper loaded: html_helper
INFO - 2023-08-19 06:02:25 --> Helper loaded: text_helper
INFO - 2023-08-19 06:02:25 --> Helper loaded: form_helper
INFO - 2023-08-19 06:02:25 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:02:25 --> Helper loaded: security_helper
INFO - 2023-08-19 06:02:25 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:02:25 --> Database Driver Class Initialized
INFO - 2023-08-19 06:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:02:25 --> Parser Class Initialized
INFO - 2023-08-19 06:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:02:25 --> Pagination Class Initialized
INFO - 2023-08-19 06:02:25 --> Form Validation Class Initialized
INFO - 2023-08-19 06:02:25 --> Controller Class Initialized
INFO - 2023-08-19 06:02:25 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:25 --> Model Class Initialized
INFO - 2023-08-19 06:02:25 --> Final output sent to browser
DEBUG - 2023-08-19 06:02:25 --> Total execution time: 0.0196
ERROR - 2023-08-19 06:02:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:02:26 --> Config Class Initialized
INFO - 2023-08-19 06:02:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:02:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:02:26 --> Utf8 Class Initialized
INFO - 2023-08-19 06:02:26 --> URI Class Initialized
DEBUG - 2023-08-19 06:02:26 --> No URI present. Default controller set.
INFO - 2023-08-19 06:02:26 --> Router Class Initialized
INFO - 2023-08-19 06:02:26 --> Output Class Initialized
INFO - 2023-08-19 06:02:26 --> Security Class Initialized
DEBUG - 2023-08-19 06:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:02:26 --> Input Class Initialized
INFO - 2023-08-19 06:02:26 --> Language Class Initialized
INFO - 2023-08-19 06:02:26 --> Loader Class Initialized
INFO - 2023-08-19 06:02:26 --> Helper loaded: url_helper
INFO - 2023-08-19 06:02:26 --> Helper loaded: file_helper
INFO - 2023-08-19 06:02:26 --> Helper loaded: html_helper
INFO - 2023-08-19 06:02:26 --> Helper loaded: text_helper
INFO - 2023-08-19 06:02:26 --> Helper loaded: form_helper
INFO - 2023-08-19 06:02:26 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:02:26 --> Helper loaded: security_helper
INFO - 2023-08-19 06:02:26 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:02:26 --> Database Driver Class Initialized
INFO - 2023-08-19 06:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:02:26 --> Parser Class Initialized
INFO - 2023-08-19 06:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:02:26 --> Pagination Class Initialized
INFO - 2023-08-19 06:02:26 --> Form Validation Class Initialized
INFO - 2023-08-19 06:02:26 --> Controller Class Initialized
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
INFO - 2023-08-19 06:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:02:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:02:26 --> Model Class Initialized
INFO - 2023-08-19 06:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:02:26 --> Final output sent to browser
DEBUG - 2023-08-19 06:02:26 --> Total execution time: 0.0879
ERROR - 2023-08-19 06:02:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:02:37 --> Config Class Initialized
INFO - 2023-08-19 06:02:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:02:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:02:37 --> Utf8 Class Initialized
INFO - 2023-08-19 06:02:37 --> URI Class Initialized
INFO - 2023-08-19 06:02:37 --> Router Class Initialized
INFO - 2023-08-19 06:02:37 --> Output Class Initialized
INFO - 2023-08-19 06:02:37 --> Security Class Initialized
DEBUG - 2023-08-19 06:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:02:37 --> Input Class Initialized
INFO - 2023-08-19 06:02:37 --> Language Class Initialized
INFO - 2023-08-19 06:02:37 --> Loader Class Initialized
INFO - 2023-08-19 06:02:37 --> Helper loaded: url_helper
INFO - 2023-08-19 06:02:37 --> Helper loaded: file_helper
INFO - 2023-08-19 06:02:37 --> Helper loaded: html_helper
INFO - 2023-08-19 06:02:37 --> Helper loaded: text_helper
INFO - 2023-08-19 06:02:37 --> Helper loaded: form_helper
INFO - 2023-08-19 06:02:37 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:02:37 --> Helper loaded: security_helper
INFO - 2023-08-19 06:02:37 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:02:37 --> Database Driver Class Initialized
INFO - 2023-08-19 06:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:02:37 --> Parser Class Initialized
INFO - 2023-08-19 06:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:02:37 --> Pagination Class Initialized
INFO - 2023-08-19 06:02:37 --> Form Validation Class Initialized
INFO - 2023-08-19 06:02:37 --> Controller Class Initialized
DEBUG - 2023-08-19 06:02:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:37 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:37 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:37 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:37 --> Model Class Initialized
INFO - 2023-08-19 06:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 06:02:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:02:37 --> Model Class Initialized
INFO - 2023-08-19 06:02:37 --> Model Class Initialized
INFO - 2023-08-19 06:02:37 --> Model Class Initialized
INFO - 2023-08-19 06:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:02:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:02:37 --> Final output sent to browser
DEBUG - 2023-08-19 06:02:37 --> Total execution time: 0.0739
ERROR - 2023-08-19 06:02:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:02:38 --> Config Class Initialized
INFO - 2023-08-19 06:02:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:02:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:02:38 --> Utf8 Class Initialized
INFO - 2023-08-19 06:02:38 --> URI Class Initialized
INFO - 2023-08-19 06:02:38 --> Router Class Initialized
INFO - 2023-08-19 06:02:38 --> Output Class Initialized
INFO - 2023-08-19 06:02:38 --> Security Class Initialized
DEBUG - 2023-08-19 06:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:02:38 --> Input Class Initialized
INFO - 2023-08-19 06:02:38 --> Language Class Initialized
INFO - 2023-08-19 06:02:38 --> Loader Class Initialized
INFO - 2023-08-19 06:02:38 --> Helper loaded: url_helper
INFO - 2023-08-19 06:02:38 --> Helper loaded: file_helper
INFO - 2023-08-19 06:02:38 --> Helper loaded: html_helper
INFO - 2023-08-19 06:02:38 --> Helper loaded: text_helper
INFO - 2023-08-19 06:02:38 --> Helper loaded: form_helper
INFO - 2023-08-19 06:02:38 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:02:38 --> Helper loaded: security_helper
INFO - 2023-08-19 06:02:38 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:02:38 --> Database Driver Class Initialized
INFO - 2023-08-19 06:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:02:38 --> Parser Class Initialized
INFO - 2023-08-19 06:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:02:38 --> Pagination Class Initialized
INFO - 2023-08-19 06:02:38 --> Form Validation Class Initialized
INFO - 2023-08-19 06:02:38 --> Controller Class Initialized
DEBUG - 2023-08-19 06:02:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:38 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:38 --> Model Class Initialized
INFO - 2023-08-19 06:02:38 --> Final output sent to browser
DEBUG - 2023-08-19 06:02:38 --> Total execution time: 0.0245
ERROR - 2023-08-19 06:02:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:02:43 --> Config Class Initialized
INFO - 2023-08-19 06:02:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:02:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:02:43 --> Utf8 Class Initialized
INFO - 2023-08-19 06:02:43 --> URI Class Initialized
INFO - 2023-08-19 06:02:43 --> Router Class Initialized
INFO - 2023-08-19 06:02:43 --> Output Class Initialized
INFO - 2023-08-19 06:02:43 --> Security Class Initialized
DEBUG - 2023-08-19 06:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:02:43 --> Input Class Initialized
INFO - 2023-08-19 06:02:43 --> Language Class Initialized
INFO - 2023-08-19 06:02:43 --> Loader Class Initialized
INFO - 2023-08-19 06:02:43 --> Helper loaded: url_helper
INFO - 2023-08-19 06:02:43 --> Helper loaded: file_helper
INFO - 2023-08-19 06:02:43 --> Helper loaded: html_helper
INFO - 2023-08-19 06:02:43 --> Helper loaded: text_helper
INFO - 2023-08-19 06:02:43 --> Helper loaded: form_helper
INFO - 2023-08-19 06:02:43 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:02:43 --> Helper loaded: security_helper
INFO - 2023-08-19 06:02:43 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:02:43 --> Database Driver Class Initialized
INFO - 2023-08-19 06:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:02:43 --> Parser Class Initialized
INFO - 2023-08-19 06:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:02:43 --> Pagination Class Initialized
INFO - 2023-08-19 06:02:43 --> Form Validation Class Initialized
INFO - 2023-08-19 06:02:43 --> Controller Class Initialized
DEBUG - 2023-08-19 06:02:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:43 --> Model Class Initialized
DEBUG - 2023-08-19 06:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:02:43 --> Model Class Initialized
INFO - 2023-08-19 06:02:43 --> Final output sent to browser
DEBUG - 2023-08-19 06:02:43 --> Total execution time: 0.0261
ERROR - 2023-08-19 06:05:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:00 --> Config Class Initialized
INFO - 2023-08-19 06:05:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:00 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:00 --> URI Class Initialized
DEBUG - 2023-08-19 06:05:00 --> No URI present. Default controller set.
INFO - 2023-08-19 06:05:00 --> Router Class Initialized
INFO - 2023-08-19 06:05:00 --> Output Class Initialized
INFO - 2023-08-19 06:05:00 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:00 --> Input Class Initialized
INFO - 2023-08-19 06:05:00 --> Language Class Initialized
INFO - 2023-08-19 06:05:00 --> Loader Class Initialized
INFO - 2023-08-19 06:05:00 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:00 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:00 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:00 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:00 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:00 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:00 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:00 --> Parser Class Initialized
INFO - 2023-08-19 06:05:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:00 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:00 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:00 --> Controller Class Initialized
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
INFO - 2023-08-19 06:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:05:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:05:00 --> Model Class Initialized
INFO - 2023-08-19 06:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:05:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:05:00 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:00 --> Total execution time: 0.0914
ERROR - 2023-08-19 06:05:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:08 --> Config Class Initialized
INFO - 2023-08-19 06:05:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:08 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:08 --> URI Class Initialized
DEBUG - 2023-08-19 06:05:08 --> No URI present. Default controller set.
INFO - 2023-08-19 06:05:08 --> Router Class Initialized
INFO - 2023-08-19 06:05:08 --> Output Class Initialized
INFO - 2023-08-19 06:05:08 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:08 --> Input Class Initialized
INFO - 2023-08-19 06:05:08 --> Language Class Initialized
INFO - 2023-08-19 06:05:08 --> Loader Class Initialized
INFO - 2023-08-19 06:05:08 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:08 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:08 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:08 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:08 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:08 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:08 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:08 --> Parser Class Initialized
INFO - 2023-08-19 06:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:08 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:08 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:08 --> Controller Class Initialized
INFO - 2023-08-19 06:05:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 06:05:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:09 --> Config Class Initialized
INFO - 2023-08-19 06:05:09 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:09 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:09 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:09 --> URI Class Initialized
INFO - 2023-08-19 06:05:09 --> Router Class Initialized
INFO - 2023-08-19 06:05:09 --> Output Class Initialized
INFO - 2023-08-19 06:05:09 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:09 --> Input Class Initialized
INFO - 2023-08-19 06:05:09 --> Language Class Initialized
INFO - 2023-08-19 06:05:09 --> Loader Class Initialized
INFO - 2023-08-19 06:05:09 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:09 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:09 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:09 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:09 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:09 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:09 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:09 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:09 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:09 --> Parser Class Initialized
INFO - 2023-08-19 06:05:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:09 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:09 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:09 --> Controller Class Initialized
INFO - 2023-08-19 06:05:09 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 06:05:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:05:09 --> Model Class Initialized
INFO - 2023-08-19 06:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:05:09 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:09 --> Total execution time: 0.0293
ERROR - 2023-08-19 06:05:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:18 --> Config Class Initialized
INFO - 2023-08-19 06:05:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:18 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:18 --> URI Class Initialized
INFO - 2023-08-19 06:05:18 --> Router Class Initialized
INFO - 2023-08-19 06:05:18 --> Output Class Initialized
INFO - 2023-08-19 06:05:18 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:18 --> Input Class Initialized
INFO - 2023-08-19 06:05:18 --> Language Class Initialized
INFO - 2023-08-19 06:05:18 --> Loader Class Initialized
INFO - 2023-08-19 06:05:18 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:18 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:18 --> Parser Class Initialized
INFO - 2023-08-19 06:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:18 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:18 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:18 --> Controller Class Initialized
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
INFO - 2023-08-19 06:05:18 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:18 --> Total execution time: 0.0168
ERROR - 2023-08-19 06:05:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:18 --> Config Class Initialized
INFO - 2023-08-19 06:05:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:18 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:18 --> URI Class Initialized
DEBUG - 2023-08-19 06:05:18 --> No URI present. Default controller set.
INFO - 2023-08-19 06:05:18 --> Router Class Initialized
INFO - 2023-08-19 06:05:18 --> Output Class Initialized
INFO - 2023-08-19 06:05:18 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:18 --> Input Class Initialized
INFO - 2023-08-19 06:05:18 --> Language Class Initialized
INFO - 2023-08-19 06:05:18 --> Loader Class Initialized
INFO - 2023-08-19 06:05:18 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:18 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:18 --> Parser Class Initialized
INFO - 2023-08-19 06:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:18 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:18 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:18 --> Controller Class Initialized
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
INFO - 2023-08-19 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:05:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:05:18 --> Model Class Initialized
INFO - 2023-08-19 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:05:18 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:18 --> Total execution time: 0.1750
ERROR - 2023-08-19 06:05:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:19 --> Config Class Initialized
INFO - 2023-08-19 06:05:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:19 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:19 --> URI Class Initialized
INFO - 2023-08-19 06:05:19 --> Router Class Initialized
INFO - 2023-08-19 06:05:19 --> Output Class Initialized
INFO - 2023-08-19 06:05:19 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:19 --> Input Class Initialized
INFO - 2023-08-19 06:05:19 --> Language Class Initialized
INFO - 2023-08-19 06:05:19 --> Loader Class Initialized
INFO - 2023-08-19 06:05:19 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:19 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:19 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:19 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:19 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:19 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:19 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:19 --> Parser Class Initialized
INFO - 2023-08-19 06:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:19 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:19 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:19 --> Controller Class Initialized
DEBUG - 2023-08-19 06:05:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:19 --> Model Class Initialized
INFO - 2023-08-19 06:05:19 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:19 --> Total execution time: 0.0129
ERROR - 2023-08-19 06:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:28 --> Config Class Initialized
INFO - 2023-08-19 06:05:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:28 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:28 --> URI Class Initialized
INFO - 2023-08-19 06:05:28 --> Router Class Initialized
INFO - 2023-08-19 06:05:28 --> Output Class Initialized
INFO - 2023-08-19 06:05:28 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:28 --> Input Class Initialized
INFO - 2023-08-19 06:05:28 --> Language Class Initialized
INFO - 2023-08-19 06:05:28 --> Loader Class Initialized
INFO - 2023-08-19 06:05:28 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:28 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:28 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:28 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:28 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:28 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:28 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:28 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:28 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:28 --> Parser Class Initialized
INFO - 2023-08-19 06:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:28 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:28 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:28 --> Controller Class Initialized
INFO - 2023-08-19 06:05:28 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:28 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:28 --> Model Class Initialized
INFO - 2023-08-19 06:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:05:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:05:28 --> Model Class Initialized
INFO - 2023-08-19 06:05:28 --> Model Class Initialized
INFO - 2023-08-19 06:05:28 --> Model Class Initialized
INFO - 2023-08-19 06:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:05:28 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:28 --> Total execution time: 0.1429
ERROR - 2023-08-19 06:05:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:29 --> Config Class Initialized
INFO - 2023-08-19 06:05:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:29 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:29 --> URI Class Initialized
INFO - 2023-08-19 06:05:29 --> Router Class Initialized
INFO - 2023-08-19 06:05:29 --> Output Class Initialized
INFO - 2023-08-19 06:05:29 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:29 --> Input Class Initialized
INFO - 2023-08-19 06:05:29 --> Language Class Initialized
INFO - 2023-08-19 06:05:29 --> Loader Class Initialized
INFO - 2023-08-19 06:05:29 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:29 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:29 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:29 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:29 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:29 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:29 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:29 --> Parser Class Initialized
INFO - 2023-08-19 06:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:29 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:29 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:29 --> Controller Class Initialized
INFO - 2023-08-19 06:05:29 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:29 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:29 --> Model Class Initialized
INFO - 2023-08-19 06:05:29 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:29 --> Total execution time: 0.0541
ERROR - 2023-08-19 06:05:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:35 --> Config Class Initialized
INFO - 2023-08-19 06:05:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:35 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:35 --> URI Class Initialized
INFO - 2023-08-19 06:05:35 --> Router Class Initialized
INFO - 2023-08-19 06:05:35 --> Output Class Initialized
INFO - 2023-08-19 06:05:35 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:35 --> Input Class Initialized
INFO - 2023-08-19 06:05:35 --> Language Class Initialized
INFO - 2023-08-19 06:05:35 --> Loader Class Initialized
INFO - 2023-08-19 06:05:35 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:35 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:35 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:35 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:35 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:35 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:35 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:35 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:35 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:35 --> Parser Class Initialized
INFO - 2023-08-19 06:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:35 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:35 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:35 --> Controller Class Initialized
INFO - 2023-08-19 06:05:35 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:35 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:35 --> Model Class Initialized
INFO - 2023-08-19 06:05:36 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:36 --> Total execution time: 0.5399
ERROR - 2023-08-19 06:05:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:05:55 --> Config Class Initialized
INFO - 2023-08-19 06:05:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:05:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:05:55 --> Utf8 Class Initialized
INFO - 2023-08-19 06:05:55 --> URI Class Initialized
DEBUG - 2023-08-19 06:05:55 --> No URI present. Default controller set.
INFO - 2023-08-19 06:05:55 --> Router Class Initialized
INFO - 2023-08-19 06:05:55 --> Output Class Initialized
INFO - 2023-08-19 06:05:55 --> Security Class Initialized
DEBUG - 2023-08-19 06:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:05:55 --> Input Class Initialized
INFO - 2023-08-19 06:05:55 --> Language Class Initialized
INFO - 2023-08-19 06:05:55 --> Loader Class Initialized
INFO - 2023-08-19 06:05:55 --> Helper loaded: url_helper
INFO - 2023-08-19 06:05:55 --> Helper loaded: file_helper
INFO - 2023-08-19 06:05:55 --> Helper loaded: html_helper
INFO - 2023-08-19 06:05:55 --> Helper loaded: text_helper
INFO - 2023-08-19 06:05:55 --> Helper loaded: form_helper
INFO - 2023-08-19 06:05:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:05:55 --> Helper loaded: security_helper
INFO - 2023-08-19 06:05:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:05:55 --> Database Driver Class Initialized
INFO - 2023-08-19 06:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:05:55 --> Parser Class Initialized
INFO - 2023-08-19 06:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:05:55 --> Pagination Class Initialized
INFO - 2023-08-19 06:05:55 --> Form Validation Class Initialized
INFO - 2023-08-19 06:05:55 --> Controller Class Initialized
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
DEBUG - 2023-08-19 06:05:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
INFO - 2023-08-19 06:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:05:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:05:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:05:55 --> Model Class Initialized
INFO - 2023-08-19 06:05:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:05:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:05:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:05:56 --> Final output sent to browser
DEBUG - 2023-08-19 06:05:56 --> Total execution time: 0.1907
ERROR - 2023-08-19 06:06:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:06:01 --> Config Class Initialized
INFO - 2023-08-19 06:06:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:06:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:06:01 --> Utf8 Class Initialized
INFO - 2023-08-19 06:06:01 --> URI Class Initialized
DEBUG - 2023-08-19 06:06:01 --> No URI present. Default controller set.
INFO - 2023-08-19 06:06:01 --> Router Class Initialized
INFO - 2023-08-19 06:06:01 --> Output Class Initialized
INFO - 2023-08-19 06:06:01 --> Security Class Initialized
DEBUG - 2023-08-19 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:06:01 --> Input Class Initialized
INFO - 2023-08-19 06:06:01 --> Language Class Initialized
INFO - 2023-08-19 06:06:01 --> Loader Class Initialized
INFO - 2023-08-19 06:06:01 --> Helper loaded: url_helper
INFO - 2023-08-19 06:06:01 --> Helper loaded: file_helper
INFO - 2023-08-19 06:06:01 --> Helper loaded: html_helper
INFO - 2023-08-19 06:06:01 --> Helper loaded: text_helper
INFO - 2023-08-19 06:06:01 --> Helper loaded: form_helper
INFO - 2023-08-19 06:06:01 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:06:01 --> Helper loaded: security_helper
INFO - 2023-08-19 06:06:01 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:06:01 --> Database Driver Class Initialized
INFO - 2023-08-19 06:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:06:01 --> Parser Class Initialized
INFO - 2023-08-19 06:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:06:01 --> Pagination Class Initialized
INFO - 2023-08-19 06:06:01 --> Form Validation Class Initialized
INFO - 2023-08-19 06:06:01 --> Controller Class Initialized
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
DEBUG - 2023-08-19 06:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
DEBUG - 2023-08-19 06:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
DEBUG - 2023-08-19 06:06:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
INFO - 2023-08-19 06:06:01 --> Model Class Initialized
INFO - 2023-08-19 06:06:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:06:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:06:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:06:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:06:02 --> Model Class Initialized
INFO - 2023-08-19 06:06:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:06:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:06:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:06:02 --> Final output sent to browser
DEBUG - 2023-08-19 06:06:02 --> Total execution time: 0.1760
ERROR - 2023-08-19 06:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:11:42 --> Config Class Initialized
INFO - 2023-08-19 06:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:11:42 --> Utf8 Class Initialized
INFO - 2023-08-19 06:11:42 --> URI Class Initialized
DEBUG - 2023-08-19 06:11:42 --> No URI present. Default controller set.
INFO - 2023-08-19 06:11:42 --> Router Class Initialized
INFO - 2023-08-19 06:11:42 --> Output Class Initialized
INFO - 2023-08-19 06:11:42 --> Security Class Initialized
DEBUG - 2023-08-19 06:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:11:42 --> Input Class Initialized
INFO - 2023-08-19 06:11:42 --> Language Class Initialized
INFO - 2023-08-19 06:11:42 --> Loader Class Initialized
INFO - 2023-08-19 06:11:42 --> Helper loaded: url_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: file_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: html_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: text_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: form_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: security_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:11:42 --> Database Driver Class Initialized
INFO - 2023-08-19 06:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:11:42 --> Parser Class Initialized
INFO - 2023-08-19 06:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:11:42 --> Pagination Class Initialized
INFO - 2023-08-19 06:11:42 --> Form Validation Class Initialized
INFO - 2023-08-19 06:11:42 --> Controller Class Initialized
INFO - 2023-08-19 06:11:42 --> Model Class Initialized
DEBUG - 2023-08-19 06:11:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 06:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:11:42 --> Config Class Initialized
INFO - 2023-08-19 06:11:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:11:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:11:42 --> Utf8 Class Initialized
INFO - 2023-08-19 06:11:42 --> URI Class Initialized
INFO - 2023-08-19 06:11:42 --> Router Class Initialized
INFO - 2023-08-19 06:11:42 --> Output Class Initialized
INFO - 2023-08-19 06:11:42 --> Security Class Initialized
DEBUG - 2023-08-19 06:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:11:42 --> Input Class Initialized
INFO - 2023-08-19 06:11:42 --> Language Class Initialized
INFO - 2023-08-19 06:11:42 --> Loader Class Initialized
INFO - 2023-08-19 06:11:42 --> Helper loaded: url_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: file_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: html_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: text_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: form_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: security_helper
INFO - 2023-08-19 06:11:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:11:42 --> Database Driver Class Initialized
INFO - 2023-08-19 06:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:11:42 --> Parser Class Initialized
INFO - 2023-08-19 06:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:11:42 --> Pagination Class Initialized
INFO - 2023-08-19 06:11:42 --> Form Validation Class Initialized
INFO - 2023-08-19 06:11:42 --> Controller Class Initialized
INFO - 2023-08-19 06:11:42 --> Model Class Initialized
DEBUG - 2023-08-19 06:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 06:11:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:11:42 --> Model Class Initialized
INFO - 2023-08-19 06:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:11:42 --> Final output sent to browser
DEBUG - 2023-08-19 06:11:42 --> Total execution time: 0.0288
ERROR - 2023-08-19 06:12:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:12:05 --> Config Class Initialized
INFO - 2023-08-19 06:12:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:12:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:12:05 --> Utf8 Class Initialized
INFO - 2023-08-19 06:12:05 --> URI Class Initialized
INFO - 2023-08-19 06:12:05 --> Router Class Initialized
INFO - 2023-08-19 06:12:05 --> Output Class Initialized
INFO - 2023-08-19 06:12:05 --> Security Class Initialized
DEBUG - 2023-08-19 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:12:05 --> Input Class Initialized
INFO - 2023-08-19 06:12:05 --> Language Class Initialized
INFO - 2023-08-19 06:12:05 --> Loader Class Initialized
INFO - 2023-08-19 06:12:05 --> Helper loaded: url_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: file_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: html_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: text_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: form_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: security_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:12:05 --> Database Driver Class Initialized
INFO - 2023-08-19 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:12:05 --> Parser Class Initialized
INFO - 2023-08-19 06:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:12:05 --> Pagination Class Initialized
INFO - 2023-08-19 06:12:05 --> Form Validation Class Initialized
INFO - 2023-08-19 06:12:05 --> Controller Class Initialized
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
INFO - 2023-08-19 06:12:05 --> Final output sent to browser
DEBUG - 2023-08-19 06:12:05 --> Total execution time: 0.0193
ERROR - 2023-08-19 06:12:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:12:05 --> Config Class Initialized
INFO - 2023-08-19 06:12:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:12:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:12:05 --> Utf8 Class Initialized
INFO - 2023-08-19 06:12:05 --> URI Class Initialized
DEBUG - 2023-08-19 06:12:05 --> No URI present. Default controller set.
INFO - 2023-08-19 06:12:05 --> Router Class Initialized
INFO - 2023-08-19 06:12:05 --> Output Class Initialized
INFO - 2023-08-19 06:12:05 --> Security Class Initialized
DEBUG - 2023-08-19 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:12:05 --> Input Class Initialized
INFO - 2023-08-19 06:12:05 --> Language Class Initialized
INFO - 2023-08-19 06:12:05 --> Loader Class Initialized
INFO - 2023-08-19 06:12:05 --> Helper loaded: url_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: file_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: html_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: text_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: form_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: security_helper
INFO - 2023-08-19 06:12:05 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:12:05 --> Database Driver Class Initialized
INFO - 2023-08-19 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:12:05 --> Parser Class Initialized
INFO - 2023-08-19 06:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:12:05 --> Pagination Class Initialized
INFO - 2023-08-19 06:12:05 --> Form Validation Class Initialized
INFO - 2023-08-19 06:12:05 --> Controller Class Initialized
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
INFO - 2023-08-19 06:12:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:12:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:12:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:12:05 --> Model Class Initialized
INFO - 2023-08-19 06:12:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:12:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:12:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:12:05 --> Final output sent to browser
DEBUG - 2023-08-19 06:12:05 --> Total execution time: 0.0890
ERROR - 2023-08-19 06:12:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:12:25 --> Config Class Initialized
INFO - 2023-08-19 06:12:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:12:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:12:25 --> Utf8 Class Initialized
INFO - 2023-08-19 06:12:25 --> URI Class Initialized
DEBUG - 2023-08-19 06:12:25 --> No URI present. Default controller set.
INFO - 2023-08-19 06:12:25 --> Router Class Initialized
INFO - 2023-08-19 06:12:25 --> Output Class Initialized
INFO - 2023-08-19 06:12:25 --> Security Class Initialized
DEBUG - 2023-08-19 06:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:12:25 --> Input Class Initialized
INFO - 2023-08-19 06:12:25 --> Language Class Initialized
INFO - 2023-08-19 06:12:25 --> Loader Class Initialized
INFO - 2023-08-19 06:12:25 --> Helper loaded: url_helper
INFO - 2023-08-19 06:12:25 --> Helper loaded: file_helper
INFO - 2023-08-19 06:12:25 --> Helper loaded: html_helper
INFO - 2023-08-19 06:12:25 --> Helper loaded: text_helper
INFO - 2023-08-19 06:12:25 --> Helper loaded: form_helper
INFO - 2023-08-19 06:12:25 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:12:25 --> Helper loaded: security_helper
INFO - 2023-08-19 06:12:25 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:12:25 --> Database Driver Class Initialized
INFO - 2023-08-19 06:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:12:25 --> Parser Class Initialized
INFO - 2023-08-19 06:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:12:25 --> Pagination Class Initialized
INFO - 2023-08-19 06:12:25 --> Form Validation Class Initialized
INFO - 2023-08-19 06:12:25 --> Controller Class Initialized
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
INFO - 2023-08-19 06:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:12:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:12:25 --> Model Class Initialized
INFO - 2023-08-19 06:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:12:25 --> Final output sent to browser
DEBUG - 2023-08-19 06:12:25 --> Total execution time: 0.0880
ERROR - 2023-08-19 06:12:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:12:32 --> Config Class Initialized
INFO - 2023-08-19 06:12:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:12:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:12:32 --> Utf8 Class Initialized
INFO - 2023-08-19 06:12:32 --> URI Class Initialized
INFO - 2023-08-19 06:12:32 --> Router Class Initialized
INFO - 2023-08-19 06:12:32 --> Output Class Initialized
INFO - 2023-08-19 06:12:32 --> Security Class Initialized
DEBUG - 2023-08-19 06:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:12:32 --> Input Class Initialized
INFO - 2023-08-19 06:12:32 --> Language Class Initialized
INFO - 2023-08-19 06:12:32 --> Loader Class Initialized
INFO - 2023-08-19 06:12:32 --> Helper loaded: url_helper
INFO - 2023-08-19 06:12:32 --> Helper loaded: file_helper
INFO - 2023-08-19 06:12:32 --> Helper loaded: html_helper
INFO - 2023-08-19 06:12:32 --> Helper loaded: text_helper
INFO - 2023-08-19 06:12:32 --> Helper loaded: form_helper
INFO - 2023-08-19 06:12:32 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:12:32 --> Helper loaded: security_helper
INFO - 2023-08-19 06:12:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:12:32 --> Database Driver Class Initialized
INFO - 2023-08-19 06:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:12:32 --> Parser Class Initialized
INFO - 2023-08-19 06:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:12:32 --> Pagination Class Initialized
INFO - 2023-08-19 06:12:32 --> Form Validation Class Initialized
INFO - 2023-08-19 06:12:32 --> Controller Class Initialized
INFO - 2023-08-19 06:12:32 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:32 --> Model Class Initialized
INFO - 2023-08-19 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-19 06:12:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:12:32 --> Model Class Initialized
INFO - 2023-08-19 06:12:32 --> Model Class Initialized
INFO - 2023-08-19 06:12:32 --> Model Class Initialized
INFO - 2023-08-19 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:12:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:12:32 --> Final output sent to browser
DEBUG - 2023-08-19 06:12:32 --> Total execution time: 0.0731
ERROR - 2023-08-19 06:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:12:33 --> Config Class Initialized
INFO - 2023-08-19 06:12:33 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:12:33 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:12:33 --> Utf8 Class Initialized
INFO - 2023-08-19 06:12:33 --> URI Class Initialized
INFO - 2023-08-19 06:12:33 --> Router Class Initialized
INFO - 2023-08-19 06:12:33 --> Output Class Initialized
INFO - 2023-08-19 06:12:33 --> Security Class Initialized
DEBUG - 2023-08-19 06:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:12:33 --> Input Class Initialized
INFO - 2023-08-19 06:12:33 --> Language Class Initialized
INFO - 2023-08-19 06:12:33 --> Loader Class Initialized
INFO - 2023-08-19 06:12:33 --> Helper loaded: url_helper
INFO - 2023-08-19 06:12:33 --> Helper loaded: file_helper
INFO - 2023-08-19 06:12:33 --> Helper loaded: html_helper
INFO - 2023-08-19 06:12:33 --> Helper loaded: text_helper
INFO - 2023-08-19 06:12:33 --> Helper loaded: form_helper
INFO - 2023-08-19 06:12:33 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:12:33 --> Helper loaded: security_helper
INFO - 2023-08-19 06:12:33 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:12:33 --> Database Driver Class Initialized
INFO - 2023-08-19 06:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:12:33 --> Parser Class Initialized
INFO - 2023-08-19 06:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:12:33 --> Pagination Class Initialized
INFO - 2023-08-19 06:12:33 --> Form Validation Class Initialized
INFO - 2023-08-19 06:12:33 --> Controller Class Initialized
INFO - 2023-08-19 06:12:33 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:33 --> Model Class Initialized
INFO - 2023-08-19 06:12:33 --> Final output sent to browser
DEBUG - 2023-08-19 06:12:33 --> Total execution time: 0.0173
ERROR - 2023-08-19 06:12:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:12:52 --> Config Class Initialized
INFO - 2023-08-19 06:12:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:12:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:12:52 --> Utf8 Class Initialized
INFO - 2023-08-19 06:12:52 --> URI Class Initialized
INFO - 2023-08-19 06:12:52 --> Router Class Initialized
INFO - 2023-08-19 06:12:52 --> Output Class Initialized
INFO - 2023-08-19 06:12:52 --> Security Class Initialized
DEBUG - 2023-08-19 06:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:12:52 --> Input Class Initialized
INFO - 2023-08-19 06:12:52 --> Language Class Initialized
INFO - 2023-08-19 06:12:52 --> Loader Class Initialized
INFO - 2023-08-19 06:12:52 --> Helper loaded: url_helper
INFO - 2023-08-19 06:12:52 --> Helper loaded: file_helper
INFO - 2023-08-19 06:12:52 --> Helper loaded: html_helper
INFO - 2023-08-19 06:12:52 --> Helper loaded: text_helper
INFO - 2023-08-19 06:12:52 --> Helper loaded: form_helper
INFO - 2023-08-19 06:12:52 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:12:52 --> Helper loaded: security_helper
INFO - 2023-08-19 06:12:52 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:12:52 --> Database Driver Class Initialized
INFO - 2023-08-19 06:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:12:52 --> Parser Class Initialized
INFO - 2023-08-19 06:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:12:52 --> Pagination Class Initialized
INFO - 2023-08-19 06:12:52 --> Form Validation Class Initialized
INFO - 2023-08-19 06:12:52 --> Controller Class Initialized
INFO - 2023-08-19 06:12:52 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:52 --> Model Class Initialized
INFO - 2023-08-19 06:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-08-19 06:12:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:12:52 --> Model Class Initialized
INFO - 2023-08-19 06:12:52 --> Model Class Initialized
INFO - 2023-08-19 06:12:52 --> Model Class Initialized
INFO - 2023-08-19 06:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:12:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:12:52 --> Final output sent to browser
DEBUG - 2023-08-19 06:12:52 --> Total execution time: 0.0758
ERROR - 2023-08-19 06:12:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:12:54 --> Config Class Initialized
INFO - 2023-08-19 06:12:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:12:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:12:54 --> Utf8 Class Initialized
INFO - 2023-08-19 06:12:54 --> URI Class Initialized
INFO - 2023-08-19 06:12:54 --> Router Class Initialized
INFO - 2023-08-19 06:12:54 --> Output Class Initialized
INFO - 2023-08-19 06:12:54 --> Security Class Initialized
DEBUG - 2023-08-19 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:12:54 --> Input Class Initialized
INFO - 2023-08-19 06:12:54 --> Language Class Initialized
INFO - 2023-08-19 06:12:54 --> Loader Class Initialized
INFO - 2023-08-19 06:12:54 --> Helper loaded: url_helper
INFO - 2023-08-19 06:12:54 --> Helper loaded: file_helper
INFO - 2023-08-19 06:12:54 --> Helper loaded: html_helper
INFO - 2023-08-19 06:12:54 --> Helper loaded: text_helper
INFO - 2023-08-19 06:12:54 --> Helper loaded: form_helper
INFO - 2023-08-19 06:12:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:12:54 --> Helper loaded: security_helper
INFO - 2023-08-19 06:12:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:12:54 --> Database Driver Class Initialized
INFO - 2023-08-19 06:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:12:54 --> Parser Class Initialized
INFO - 2023-08-19 06:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:12:54 --> Pagination Class Initialized
INFO - 2023-08-19 06:12:54 --> Form Validation Class Initialized
INFO - 2023-08-19 06:12:54 --> Controller Class Initialized
INFO - 2023-08-19 06:12:54 --> Model Class Initialized
DEBUG - 2023-08-19 06:12:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:12:54 --> Model Class Initialized
INFO - 2023-08-19 06:12:54 --> Final output sent to browser
DEBUG - 2023-08-19 06:12:54 --> Total execution time: 0.0163
ERROR - 2023-08-19 06:13:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:01 --> Config Class Initialized
INFO - 2023-08-19 06:13:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:01 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:01 --> URI Class Initialized
INFO - 2023-08-19 06:13:01 --> Router Class Initialized
INFO - 2023-08-19 06:13:01 --> Output Class Initialized
INFO - 2023-08-19 06:13:01 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:01 --> Input Class Initialized
INFO - 2023-08-19 06:13:01 --> Language Class Initialized
INFO - 2023-08-19 06:13:01 --> Loader Class Initialized
INFO - 2023-08-19 06:13:01 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:01 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:01 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:01 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:01 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:01 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:01 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:01 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:01 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:01 --> Parser Class Initialized
INFO - 2023-08-19 06:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:01 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:01 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:01 --> Controller Class Initialized
INFO - 2023-08-19 06:13:01 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:01 --> Model Class Initialized
INFO - 2023-08-19 06:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-19 06:13:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:01 --> Model Class Initialized
INFO - 2023-08-19 06:13:01 --> Model Class Initialized
INFO - 2023-08-19 06:13:01 --> Model Class Initialized
INFO - 2023-08-19 06:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:01 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:01 --> Total execution time: 0.0820
ERROR - 2023-08-19 06:13:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:02 --> Config Class Initialized
INFO - 2023-08-19 06:13:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:02 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:02 --> URI Class Initialized
INFO - 2023-08-19 06:13:02 --> Router Class Initialized
INFO - 2023-08-19 06:13:02 --> Output Class Initialized
INFO - 2023-08-19 06:13:02 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:02 --> Input Class Initialized
INFO - 2023-08-19 06:13:02 --> Language Class Initialized
INFO - 2023-08-19 06:13:02 --> Loader Class Initialized
INFO - 2023-08-19 06:13:02 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:02 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:02 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:02 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:02 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:02 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:02 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:02 --> Parser Class Initialized
INFO - 2023-08-19 06:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:02 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:02 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:02 --> Controller Class Initialized
INFO - 2023-08-19 06:13:02 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:02 --> Model Class Initialized
INFO - 2023-08-19 06:13:02 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:02 --> Total execution time: 0.0165
ERROR - 2023-08-19 06:13:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:03 --> Config Class Initialized
INFO - 2023-08-19 06:13:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:03 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:03 --> URI Class Initialized
INFO - 2023-08-19 06:13:03 --> Router Class Initialized
INFO - 2023-08-19 06:13:03 --> Output Class Initialized
INFO - 2023-08-19 06:13:03 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:03 --> Input Class Initialized
INFO - 2023-08-19 06:13:03 --> Language Class Initialized
INFO - 2023-08-19 06:13:03 --> Loader Class Initialized
INFO - 2023-08-19 06:13:03 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:03 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:03 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:03 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:03 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:03 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:03 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:03 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:03 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:03 --> Parser Class Initialized
INFO - 2023-08-19 06:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:03 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:03 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:03 --> Controller Class Initialized
INFO - 2023-08-19 06:13:03 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:03 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:03 --> Model Class Initialized
INFO - 2023-08-19 06:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:13:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:03 --> Model Class Initialized
INFO - 2023-08-19 06:13:03 --> Model Class Initialized
INFO - 2023-08-19 06:13:03 --> Model Class Initialized
INFO - 2023-08-19 06:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:03 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:03 --> Total execution time: 0.0785
ERROR - 2023-08-19 06:13:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:04 --> Config Class Initialized
INFO - 2023-08-19 06:13:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:04 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:04 --> URI Class Initialized
INFO - 2023-08-19 06:13:04 --> Router Class Initialized
INFO - 2023-08-19 06:13:04 --> Output Class Initialized
INFO - 2023-08-19 06:13:04 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:04 --> Input Class Initialized
INFO - 2023-08-19 06:13:04 --> Language Class Initialized
INFO - 2023-08-19 06:13:04 --> Loader Class Initialized
INFO - 2023-08-19 06:13:04 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:04 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:04 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:04 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:04 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:04 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:04 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:04 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:04 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:04 --> Parser Class Initialized
INFO - 2023-08-19 06:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:04 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:04 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:04 --> Controller Class Initialized
INFO - 2023-08-19 06:13:04 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:04 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:04 --> Model Class Initialized
INFO - 2023-08-19 06:13:04 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:04 --> Total execution time: 0.0404
ERROR - 2023-08-19 06:13:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:08 --> Config Class Initialized
INFO - 2023-08-19 06:13:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:08 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:08 --> URI Class Initialized
DEBUG - 2023-08-19 06:13:08 --> No URI present. Default controller set.
INFO - 2023-08-19 06:13:08 --> Router Class Initialized
INFO - 2023-08-19 06:13:08 --> Output Class Initialized
INFO - 2023-08-19 06:13:08 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:08 --> Input Class Initialized
INFO - 2023-08-19 06:13:08 --> Language Class Initialized
INFO - 2023-08-19 06:13:08 --> Loader Class Initialized
INFO - 2023-08-19 06:13:08 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:08 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:08 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:08 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:08 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:08 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:08 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:08 --> Parser Class Initialized
INFO - 2023-08-19 06:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:08 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:08 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:08 --> Controller Class Initialized
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
INFO - 2023-08-19 06:13:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:13:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:08 --> Model Class Initialized
INFO - 2023-08-19 06:13:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:08 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:08 --> Total execution time: 0.0936
ERROR - 2023-08-19 06:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:18 --> Config Class Initialized
INFO - 2023-08-19 06:13:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:18 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:18 --> URI Class Initialized
INFO - 2023-08-19 06:13:18 --> Router Class Initialized
INFO - 2023-08-19 06:13:18 --> Output Class Initialized
INFO - 2023-08-19 06:13:18 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:18 --> Input Class Initialized
INFO - 2023-08-19 06:13:18 --> Language Class Initialized
INFO - 2023-08-19 06:13:18 --> Loader Class Initialized
INFO - 2023-08-19 06:13:18 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:18 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:18 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:18 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:18 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:18 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:18 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:18 --> Parser Class Initialized
INFO - 2023-08-19 06:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:18 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:18 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:18 --> Controller Class Initialized
INFO - 2023-08-19 06:13:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:18 --> Model Class Initialized
INFO - 2023-08-19 06:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-08-19 06:13:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:18 --> Model Class Initialized
INFO - 2023-08-19 06:13:18 --> Model Class Initialized
INFO - 2023-08-19 06:13:18 --> Model Class Initialized
INFO - 2023-08-19 06:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:18 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:18 --> Total execution time: 0.0710
ERROR - 2023-08-19 06:13:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:19 --> Config Class Initialized
INFO - 2023-08-19 06:13:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:19 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:19 --> URI Class Initialized
INFO - 2023-08-19 06:13:19 --> Router Class Initialized
INFO - 2023-08-19 06:13:19 --> Output Class Initialized
INFO - 2023-08-19 06:13:19 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:19 --> Input Class Initialized
INFO - 2023-08-19 06:13:19 --> Language Class Initialized
INFO - 2023-08-19 06:13:19 --> Loader Class Initialized
INFO - 2023-08-19 06:13:19 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:19 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:19 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:19 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:19 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:19 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:19 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:19 --> Parser Class Initialized
INFO - 2023-08-19 06:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:19 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:19 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:19 --> Controller Class Initialized
INFO - 2023-08-19 06:13:19 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:19 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:19 --> Model Class Initialized
INFO - 2023-08-19 06:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-19 06:13:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:19 --> Model Class Initialized
INFO - 2023-08-19 06:13:19 --> Model Class Initialized
INFO - 2023-08-19 06:13:19 --> Model Class Initialized
INFO - 2023-08-19 06:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:19 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:19 --> Total execution time: 0.0768
ERROR - 2023-08-19 06:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:20 --> Config Class Initialized
INFO - 2023-08-19 06:13:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:20 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:20 --> URI Class Initialized
INFO - 2023-08-19 06:13:20 --> Router Class Initialized
INFO - 2023-08-19 06:13:20 --> Output Class Initialized
INFO - 2023-08-19 06:13:20 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:20 --> Input Class Initialized
INFO - 2023-08-19 06:13:20 --> Language Class Initialized
INFO - 2023-08-19 06:13:20 --> Loader Class Initialized
INFO - 2023-08-19 06:13:20 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:20 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:20 --> Parser Class Initialized
INFO - 2023-08-19 06:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:20 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:20 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:20 --> Controller Class Initialized
INFO - 2023-08-19 06:13:20 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:20 --> Model Class Initialized
INFO - 2023-08-19 06:13:20 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:20 --> Total execution time: 0.0160
ERROR - 2023-08-19 06:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:20 --> Config Class Initialized
INFO - 2023-08-19 06:13:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:20 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:20 --> URI Class Initialized
INFO - 2023-08-19 06:13:20 --> Router Class Initialized
INFO - 2023-08-19 06:13:20 --> Output Class Initialized
INFO - 2023-08-19 06:13:20 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:20 --> Input Class Initialized
INFO - 2023-08-19 06:13:20 --> Language Class Initialized
INFO - 2023-08-19 06:13:20 --> Loader Class Initialized
INFO - 2023-08-19 06:13:20 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:20 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:20 --> Parser Class Initialized
INFO - 2023-08-19 06:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:20 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:20 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:20 --> Controller Class Initialized
INFO - 2023-08-19 06:13:20 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:20 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:20 --> Model Class Initialized
INFO - 2023-08-19 06:13:20 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:20 --> Total execution time: 0.0228
ERROR - 2023-08-19 06:13:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:23 --> Config Class Initialized
INFO - 2023-08-19 06:13:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:23 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:23 --> URI Class Initialized
INFO - 2023-08-19 06:13:23 --> Router Class Initialized
INFO - 2023-08-19 06:13:23 --> Output Class Initialized
INFO - 2023-08-19 06:13:23 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:23 --> Input Class Initialized
INFO - 2023-08-19 06:13:23 --> Language Class Initialized
INFO - 2023-08-19 06:13:23 --> Loader Class Initialized
INFO - 2023-08-19 06:13:23 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:23 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:23 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:23 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:23 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:23 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:23 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:23 --> Parser Class Initialized
INFO - 2023-08-19 06:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:23 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:23 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:23 --> Controller Class Initialized
INFO - 2023-08-19 06:13:23 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:23 --> Model Class Initialized
INFO - 2023-08-19 06:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-19 06:13:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:23 --> Model Class Initialized
INFO - 2023-08-19 06:13:23 --> Model Class Initialized
INFO - 2023-08-19 06:13:23 --> Model Class Initialized
INFO - 2023-08-19 06:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:23 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:23 --> Total execution time: 0.0673
ERROR - 2023-08-19 06:13:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:24 --> Config Class Initialized
INFO - 2023-08-19 06:13:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:24 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:24 --> URI Class Initialized
INFO - 2023-08-19 06:13:24 --> Router Class Initialized
INFO - 2023-08-19 06:13:24 --> Output Class Initialized
INFO - 2023-08-19 06:13:24 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:24 --> Input Class Initialized
INFO - 2023-08-19 06:13:24 --> Language Class Initialized
INFO - 2023-08-19 06:13:24 --> Loader Class Initialized
INFO - 2023-08-19 06:13:24 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:24 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:24 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:24 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:24 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:24 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:24 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:24 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:24 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:24 --> Parser Class Initialized
INFO - 2023-08-19 06:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:24 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:24 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:24 --> Controller Class Initialized
INFO - 2023-08-19 06:13:24 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 06:13:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:24 --> Model Class Initialized
INFO - 2023-08-19 06:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:24 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:24 --> Total execution time: 0.0266
ERROR - 2023-08-19 06:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:25 --> Config Class Initialized
INFO - 2023-08-19 06:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:25 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:25 --> URI Class Initialized
INFO - 2023-08-19 06:13:25 --> Router Class Initialized
INFO - 2023-08-19 06:13:25 --> Output Class Initialized
INFO - 2023-08-19 06:13:25 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:25 --> Input Class Initialized
INFO - 2023-08-19 06:13:25 --> Language Class Initialized
INFO - 2023-08-19 06:13:25 --> Loader Class Initialized
INFO - 2023-08-19 06:13:25 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:25 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:25 --> Parser Class Initialized
INFO - 2023-08-19 06:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:25 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:25 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:25 --> Controller Class Initialized
INFO - 2023-08-19 06:13:25 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:25 --> Model Class Initialized
INFO - 2023-08-19 06:13:25 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:25 --> Total execution time: 0.0162
ERROR - 2023-08-19 06:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:25 --> Config Class Initialized
INFO - 2023-08-19 06:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:25 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:25 --> URI Class Initialized
INFO - 2023-08-19 06:13:25 --> Router Class Initialized
INFO - 2023-08-19 06:13:25 --> Output Class Initialized
INFO - 2023-08-19 06:13:25 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:25 --> Input Class Initialized
INFO - 2023-08-19 06:13:25 --> Language Class Initialized
INFO - 2023-08-19 06:13:25 --> Loader Class Initialized
INFO - 2023-08-19 06:13:25 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:25 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:25 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:25 --> Parser Class Initialized
INFO - 2023-08-19 06:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:25 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:26 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:26 --> Controller Class Initialized
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
INFO - 2023-08-19 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:13:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:26 --> Model Class Initialized
INFO - 2023-08-19 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:26 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:26 --> Total execution time: 0.0874
ERROR - 2023-08-19 06:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:34 --> Config Class Initialized
INFO - 2023-08-19 06:13:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:34 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:34 --> URI Class Initialized
INFO - 2023-08-19 06:13:34 --> Router Class Initialized
INFO - 2023-08-19 06:13:34 --> Output Class Initialized
INFO - 2023-08-19 06:13:34 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:34 --> Input Class Initialized
INFO - 2023-08-19 06:13:34 --> Language Class Initialized
INFO - 2023-08-19 06:13:34 --> Loader Class Initialized
INFO - 2023-08-19 06:13:34 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:34 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:34 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:34 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:34 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:34 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:34 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:34 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:34 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:34 --> Parser Class Initialized
INFO - 2023-08-19 06:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:34 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:34 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:34 --> Controller Class Initialized
INFO - 2023-08-19 06:13:34 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:34 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:34 --> Model Class Initialized
INFO - 2023-08-19 06:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:13:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:34 --> Model Class Initialized
INFO - 2023-08-19 06:13:34 --> Model Class Initialized
INFO - 2023-08-19 06:13:34 --> Model Class Initialized
INFO - 2023-08-19 06:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:34 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:34 --> Total execution time: 0.0828
ERROR - 2023-08-19 06:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:35 --> Config Class Initialized
INFO - 2023-08-19 06:13:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:35 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:35 --> URI Class Initialized
INFO - 2023-08-19 06:13:35 --> Router Class Initialized
INFO - 2023-08-19 06:13:35 --> Output Class Initialized
INFO - 2023-08-19 06:13:35 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:35 --> Input Class Initialized
INFO - 2023-08-19 06:13:35 --> Language Class Initialized
INFO - 2023-08-19 06:13:35 --> Loader Class Initialized
INFO - 2023-08-19 06:13:35 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:35 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:35 --> Parser Class Initialized
INFO - 2023-08-19 06:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:35 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:35 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:35 --> Controller Class Initialized
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
INFO - 2023-08-19 06:13:35 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:35 --> Total execution time: 0.0410
ERROR - 2023-08-19 06:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:35 --> Config Class Initialized
INFO - 2023-08-19 06:13:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:35 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:35 --> URI Class Initialized
INFO - 2023-08-19 06:13:35 --> Router Class Initialized
INFO - 2023-08-19 06:13:35 --> Output Class Initialized
INFO - 2023-08-19 06:13:35 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:35 --> Input Class Initialized
INFO - 2023-08-19 06:13:35 --> Language Class Initialized
INFO - 2023-08-19 06:13:35 --> Loader Class Initialized
INFO - 2023-08-19 06:13:35 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:35 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:35 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:35 --> Parser Class Initialized
INFO - 2023-08-19 06:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:35 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:35 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:35 --> Controller Class Initialized
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
INFO - 2023-08-19 06:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-19 06:13:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
INFO - 2023-08-19 06:13:35 --> Model Class Initialized
INFO - 2023-08-19 06:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:13:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:13:35 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:35 --> Total execution time: 0.0744
ERROR - 2023-08-19 06:13:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:36 --> Config Class Initialized
INFO - 2023-08-19 06:13:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:36 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:36 --> URI Class Initialized
INFO - 2023-08-19 06:13:36 --> Router Class Initialized
INFO - 2023-08-19 06:13:36 --> Output Class Initialized
INFO - 2023-08-19 06:13:36 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:36 --> Input Class Initialized
INFO - 2023-08-19 06:13:36 --> Language Class Initialized
INFO - 2023-08-19 06:13:36 --> Loader Class Initialized
INFO - 2023-08-19 06:13:36 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:36 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:36 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:36 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:36 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:36 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:36 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:36 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:36 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:36 --> Parser Class Initialized
INFO - 2023-08-19 06:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:36 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:36 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:36 --> Controller Class Initialized
INFO - 2023-08-19 06:13:36 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:36 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:36 --> Model Class Initialized
INFO - 2023-08-19 06:13:36 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:36 --> Total execution time: 0.0239
ERROR - 2023-08-19 06:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:13:37 --> Config Class Initialized
INFO - 2023-08-19 06:13:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:13:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:13:37 --> Utf8 Class Initialized
INFO - 2023-08-19 06:13:37 --> URI Class Initialized
INFO - 2023-08-19 06:13:37 --> Router Class Initialized
INFO - 2023-08-19 06:13:37 --> Output Class Initialized
INFO - 2023-08-19 06:13:37 --> Security Class Initialized
DEBUG - 2023-08-19 06:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:13:37 --> Input Class Initialized
INFO - 2023-08-19 06:13:37 --> Language Class Initialized
INFO - 2023-08-19 06:13:37 --> Loader Class Initialized
INFO - 2023-08-19 06:13:37 --> Helper loaded: url_helper
INFO - 2023-08-19 06:13:37 --> Helper loaded: file_helper
INFO - 2023-08-19 06:13:37 --> Helper loaded: html_helper
INFO - 2023-08-19 06:13:37 --> Helper loaded: text_helper
INFO - 2023-08-19 06:13:37 --> Helper loaded: form_helper
INFO - 2023-08-19 06:13:37 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:13:37 --> Helper loaded: security_helper
INFO - 2023-08-19 06:13:37 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:13:37 --> Database Driver Class Initialized
INFO - 2023-08-19 06:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:13:37 --> Parser Class Initialized
INFO - 2023-08-19 06:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:13:37 --> Pagination Class Initialized
INFO - 2023-08-19 06:13:37 --> Form Validation Class Initialized
INFO - 2023-08-19 06:13:37 --> Controller Class Initialized
INFO - 2023-08-19 06:13:37 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:37 --> Model Class Initialized
DEBUG - 2023-08-19 06:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:13:37 --> Model Class Initialized
INFO - 2023-08-19 06:13:38 --> Final output sent to browser
DEBUG - 2023-08-19 06:13:38 --> Total execution time: 0.0908
ERROR - 2023-08-19 06:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:14:07 --> Config Class Initialized
INFO - 2023-08-19 06:14:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:14:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:14:07 --> Utf8 Class Initialized
INFO - 2023-08-19 06:14:07 --> URI Class Initialized
INFO - 2023-08-19 06:14:07 --> Router Class Initialized
INFO - 2023-08-19 06:14:07 --> Output Class Initialized
INFO - 2023-08-19 06:14:07 --> Security Class Initialized
DEBUG - 2023-08-19 06:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:14:07 --> Input Class Initialized
INFO - 2023-08-19 06:14:07 --> Language Class Initialized
INFO - 2023-08-19 06:14:07 --> Loader Class Initialized
INFO - 2023-08-19 06:14:07 --> Helper loaded: url_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: file_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: html_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: text_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: form_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: security_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:14:07 --> Database Driver Class Initialized
INFO - 2023-08-19 06:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:14:07 --> Parser Class Initialized
INFO - 2023-08-19 06:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:14:07 --> Pagination Class Initialized
INFO - 2023-08-19 06:14:07 --> Form Validation Class Initialized
INFO - 2023-08-19 06:14:07 --> Controller Class Initialized
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
INFO - 2023-08-19 06:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:14:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
INFO - 2023-08-19 06:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:14:07 --> Final output sent to browser
DEBUG - 2023-08-19 06:14:07 --> Total execution time: 0.0757
ERROR - 2023-08-19 06:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:14:07 --> Config Class Initialized
INFO - 2023-08-19 06:14:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:14:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:14:07 --> Utf8 Class Initialized
INFO - 2023-08-19 06:14:07 --> URI Class Initialized
INFO - 2023-08-19 06:14:07 --> Router Class Initialized
INFO - 2023-08-19 06:14:07 --> Output Class Initialized
INFO - 2023-08-19 06:14:07 --> Security Class Initialized
DEBUG - 2023-08-19 06:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:14:07 --> Input Class Initialized
INFO - 2023-08-19 06:14:07 --> Language Class Initialized
INFO - 2023-08-19 06:14:07 --> Loader Class Initialized
INFO - 2023-08-19 06:14:07 --> Helper loaded: url_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: file_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: html_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: text_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: form_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: security_helper
INFO - 2023-08-19 06:14:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:14:07 --> Database Driver Class Initialized
INFO - 2023-08-19 06:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:14:07 --> Parser Class Initialized
INFO - 2023-08-19 06:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:14:07 --> Pagination Class Initialized
INFO - 2023-08-19 06:14:07 --> Form Validation Class Initialized
INFO - 2023-08-19 06:14:07 --> Controller Class Initialized
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:07 --> Model Class Initialized
INFO - 2023-08-19 06:14:07 --> Final output sent to browser
DEBUG - 2023-08-19 06:14:07 --> Total execution time: 0.0365
ERROR - 2023-08-19 06:14:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:14:39 --> Config Class Initialized
INFO - 2023-08-19 06:14:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:14:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:14:39 --> Utf8 Class Initialized
INFO - 2023-08-19 06:14:39 --> URI Class Initialized
INFO - 2023-08-19 06:14:39 --> Router Class Initialized
INFO - 2023-08-19 06:14:39 --> Output Class Initialized
INFO - 2023-08-19 06:14:39 --> Security Class Initialized
DEBUG - 2023-08-19 06:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:14:39 --> Input Class Initialized
INFO - 2023-08-19 06:14:39 --> Language Class Initialized
INFO - 2023-08-19 06:14:39 --> Loader Class Initialized
INFO - 2023-08-19 06:14:39 --> Helper loaded: url_helper
INFO - 2023-08-19 06:14:39 --> Helper loaded: file_helper
INFO - 2023-08-19 06:14:39 --> Helper loaded: html_helper
INFO - 2023-08-19 06:14:39 --> Helper loaded: text_helper
INFO - 2023-08-19 06:14:39 --> Helper loaded: form_helper
INFO - 2023-08-19 06:14:39 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:14:39 --> Helper loaded: security_helper
INFO - 2023-08-19 06:14:39 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:14:39 --> Database Driver Class Initialized
INFO - 2023-08-19 06:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:14:39 --> Parser Class Initialized
INFO - 2023-08-19 06:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:14:39 --> Pagination Class Initialized
INFO - 2023-08-19 06:14:39 --> Form Validation Class Initialized
INFO - 2023-08-19 06:14:39 --> Controller Class Initialized
INFO - 2023-08-19 06:14:39 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:39 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:39 --> Model Class Initialized
INFO - 2023-08-19 06:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:14:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:14:39 --> Model Class Initialized
INFO - 2023-08-19 06:14:39 --> Model Class Initialized
INFO - 2023-08-19 06:14:39 --> Model Class Initialized
INFO - 2023-08-19 06:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:14:39 --> Final output sent to browser
DEBUG - 2023-08-19 06:14:39 --> Total execution time: 0.0771
ERROR - 2023-08-19 06:14:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:14:40 --> Config Class Initialized
INFO - 2023-08-19 06:14:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:14:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:14:40 --> Utf8 Class Initialized
INFO - 2023-08-19 06:14:40 --> URI Class Initialized
INFO - 2023-08-19 06:14:40 --> Router Class Initialized
INFO - 2023-08-19 06:14:40 --> Output Class Initialized
INFO - 2023-08-19 06:14:40 --> Security Class Initialized
DEBUG - 2023-08-19 06:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:14:40 --> Input Class Initialized
INFO - 2023-08-19 06:14:40 --> Language Class Initialized
INFO - 2023-08-19 06:14:40 --> Loader Class Initialized
INFO - 2023-08-19 06:14:40 --> Helper loaded: url_helper
INFO - 2023-08-19 06:14:40 --> Helper loaded: file_helper
INFO - 2023-08-19 06:14:40 --> Helper loaded: html_helper
INFO - 2023-08-19 06:14:40 --> Helper loaded: text_helper
INFO - 2023-08-19 06:14:40 --> Helper loaded: form_helper
INFO - 2023-08-19 06:14:40 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:14:40 --> Helper loaded: security_helper
INFO - 2023-08-19 06:14:40 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:14:40 --> Database Driver Class Initialized
INFO - 2023-08-19 06:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:14:40 --> Parser Class Initialized
INFO - 2023-08-19 06:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:14:40 --> Pagination Class Initialized
INFO - 2023-08-19 06:14:40 --> Form Validation Class Initialized
INFO - 2023-08-19 06:14:40 --> Controller Class Initialized
INFO - 2023-08-19 06:14:40 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:40 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:40 --> Model Class Initialized
INFO - 2023-08-19 06:14:40 --> Final output sent to browser
DEBUG - 2023-08-19 06:14:40 --> Total execution time: 0.0379
ERROR - 2023-08-19 06:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:14:55 --> Config Class Initialized
INFO - 2023-08-19 06:14:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:14:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:14:55 --> Utf8 Class Initialized
INFO - 2023-08-19 06:14:55 --> URI Class Initialized
INFO - 2023-08-19 06:14:55 --> Router Class Initialized
INFO - 2023-08-19 06:14:55 --> Output Class Initialized
INFO - 2023-08-19 06:14:55 --> Security Class Initialized
DEBUG - 2023-08-19 06:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:14:55 --> Input Class Initialized
INFO - 2023-08-19 06:14:55 --> Language Class Initialized
INFO - 2023-08-19 06:14:55 --> Loader Class Initialized
INFO - 2023-08-19 06:14:55 --> Helper loaded: url_helper
INFO - 2023-08-19 06:14:55 --> Helper loaded: file_helper
INFO - 2023-08-19 06:14:55 --> Helper loaded: html_helper
INFO - 2023-08-19 06:14:55 --> Helper loaded: text_helper
INFO - 2023-08-19 06:14:55 --> Helper loaded: form_helper
INFO - 2023-08-19 06:14:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:14:55 --> Helper loaded: security_helper
INFO - 2023-08-19 06:14:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:14:55 --> Database Driver Class Initialized
INFO - 2023-08-19 06:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:14:55 --> Parser Class Initialized
INFO - 2023-08-19 06:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:14:55 --> Pagination Class Initialized
INFO - 2023-08-19 06:14:55 --> Form Validation Class Initialized
INFO - 2023-08-19 06:14:55 --> Controller Class Initialized
INFO - 2023-08-19 06:14:55 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:55 --> Model Class Initialized
DEBUG - 2023-08-19 06:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:14:55 --> Model Class Initialized
INFO - 2023-08-19 06:14:55 --> Final output sent to browser
DEBUG - 2023-08-19 06:14:55 --> Total execution time: 0.0988
ERROR - 2023-08-19 06:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:13 --> Config Class Initialized
INFO - 2023-08-19 06:15:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:13 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:13 --> URI Class Initialized
INFO - 2023-08-19 06:15:13 --> Router Class Initialized
INFO - 2023-08-19 06:15:13 --> Output Class Initialized
INFO - 2023-08-19 06:15:13 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:13 --> Input Class Initialized
INFO - 2023-08-19 06:15:13 --> Language Class Initialized
INFO - 2023-08-19 06:15:13 --> Loader Class Initialized
INFO - 2023-08-19 06:15:13 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:13 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:13 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:13 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:13 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:13 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:13 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:13 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:13 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:13 --> Parser Class Initialized
INFO - 2023-08-19 06:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:13 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:13 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:13 --> Controller Class Initialized
INFO - 2023-08-19 06:15:13 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:13 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:13 --> Model Class Initialized
INFO - 2023-08-19 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:15:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:15:13 --> Model Class Initialized
INFO - 2023-08-19 06:15:13 --> Model Class Initialized
INFO - 2023-08-19 06:15:13 --> Model Class Initialized
INFO - 2023-08-19 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:15:13 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:13 --> Total execution time: 0.1482
ERROR - 2023-08-19 06:15:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:14 --> Config Class Initialized
INFO - 2023-08-19 06:15:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:14 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:14 --> URI Class Initialized
INFO - 2023-08-19 06:15:14 --> Router Class Initialized
INFO - 2023-08-19 06:15:14 --> Output Class Initialized
INFO - 2023-08-19 06:15:14 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:14 --> Input Class Initialized
INFO - 2023-08-19 06:15:14 --> Language Class Initialized
INFO - 2023-08-19 06:15:14 --> Loader Class Initialized
INFO - 2023-08-19 06:15:14 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:14 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:14 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:14 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:14 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:14 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:14 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:14 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:14 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:14 --> Parser Class Initialized
INFO - 2023-08-19 06:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:14 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:14 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:14 --> Controller Class Initialized
INFO - 2023-08-19 06:15:14 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:14 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:14 --> Model Class Initialized
INFO - 2023-08-19 06:15:14 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:14 --> Total execution time: 0.0614
ERROR - 2023-08-19 06:15:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:18 --> Config Class Initialized
INFO - 2023-08-19 06:15:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:18 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:18 --> URI Class Initialized
INFO - 2023-08-19 06:15:18 --> Router Class Initialized
INFO - 2023-08-19 06:15:18 --> Output Class Initialized
INFO - 2023-08-19 06:15:18 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:18 --> Input Class Initialized
INFO - 2023-08-19 06:15:18 --> Language Class Initialized
INFO - 2023-08-19 06:15:18 --> Loader Class Initialized
INFO - 2023-08-19 06:15:18 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:18 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:18 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:18 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:18 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:18 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:18 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:18 --> Parser Class Initialized
INFO - 2023-08-19 06:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:18 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:18 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:18 --> Controller Class Initialized
INFO - 2023-08-19 06:15:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:18 --> Model Class Initialized
INFO - 2023-08-19 06:15:19 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:19 --> Total execution time: 0.5711
ERROR - 2023-08-19 06:15:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:27 --> Config Class Initialized
INFO - 2023-08-19 06:15:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:27 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:27 --> URI Class Initialized
DEBUG - 2023-08-19 06:15:27 --> No URI present. Default controller set.
INFO - 2023-08-19 06:15:27 --> Router Class Initialized
INFO - 2023-08-19 06:15:27 --> Output Class Initialized
INFO - 2023-08-19 06:15:27 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:27 --> Input Class Initialized
INFO - 2023-08-19 06:15:27 --> Language Class Initialized
INFO - 2023-08-19 06:15:27 --> Loader Class Initialized
INFO - 2023-08-19 06:15:27 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:27 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:27 --> Parser Class Initialized
INFO - 2023-08-19 06:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:27 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:27 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:27 --> Controller Class Initialized
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:15:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:15:27 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:27 --> Total execution time: 0.0922
ERROR - 2023-08-19 06:15:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:27 --> Config Class Initialized
INFO - 2023-08-19 06:15:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:27 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:27 --> URI Class Initialized
INFO - 2023-08-19 06:15:27 --> Router Class Initialized
INFO - 2023-08-19 06:15:27 --> Output Class Initialized
INFO - 2023-08-19 06:15:27 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:27 --> Input Class Initialized
INFO - 2023-08-19 06:15:27 --> Language Class Initialized
INFO - 2023-08-19 06:15:27 --> Loader Class Initialized
INFO - 2023-08-19 06:15:27 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:27 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:27 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:27 --> Parser Class Initialized
INFO - 2023-08-19 06:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:27 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:27 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:27 --> Controller Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:27 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 06:15:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> Model Class Initialized
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:15:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:15:27 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:27 --> Total execution time: 0.1315
ERROR - 2023-08-19 06:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:28 --> Config Class Initialized
INFO - 2023-08-19 06:15:28 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:28 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:28 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:28 --> URI Class Initialized
INFO - 2023-08-19 06:15:28 --> Router Class Initialized
INFO - 2023-08-19 06:15:28 --> Output Class Initialized
INFO - 2023-08-19 06:15:28 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:28 --> Input Class Initialized
INFO - 2023-08-19 06:15:28 --> Language Class Initialized
INFO - 2023-08-19 06:15:28 --> Loader Class Initialized
INFO - 2023-08-19 06:15:28 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:28 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:28 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:28 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:28 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:28 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:28 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:28 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:28 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:28 --> Parser Class Initialized
INFO - 2023-08-19 06:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:28 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:28 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:28 --> Controller Class Initialized
DEBUG - 2023-08-19 06:15:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:28 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:28 --> Model Class Initialized
INFO - 2023-08-19 06:15:28 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:28 --> Total execution time: 0.0291
ERROR - 2023-08-19 06:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:30 --> Config Class Initialized
INFO - 2023-08-19 06:15:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:30 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:30 --> URI Class Initialized
INFO - 2023-08-19 06:15:30 --> Router Class Initialized
INFO - 2023-08-19 06:15:30 --> Output Class Initialized
INFO - 2023-08-19 06:15:30 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:30 --> Input Class Initialized
INFO - 2023-08-19 06:15:30 --> Language Class Initialized
INFO - 2023-08-19 06:15:30 --> Loader Class Initialized
INFO - 2023-08-19 06:15:30 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:30 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:30 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:30 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:30 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:30 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:30 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:30 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:30 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:30 --> Parser Class Initialized
INFO - 2023-08-19 06:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:30 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:30 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:30 --> Controller Class Initialized
DEBUG - 2023-08-19 06:15:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:30 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:30 --> Model Class Initialized
INFO - 2023-08-19 06:15:30 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:30 --> Total execution time: 0.1249
ERROR - 2023-08-19 06:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:30 --> Config Class Initialized
INFO - 2023-08-19 06:15:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:31 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:31 --> URI Class Initialized
INFO - 2023-08-19 06:15:31 --> Router Class Initialized
INFO - 2023-08-19 06:15:31 --> Output Class Initialized
INFO - 2023-08-19 06:15:31 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:31 --> Input Class Initialized
INFO - 2023-08-19 06:15:31 --> Language Class Initialized
INFO - 2023-08-19 06:15:31 --> Loader Class Initialized
INFO - 2023-08-19 06:15:31 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:31 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:31 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:31 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:31 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:31 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:31 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:31 --> Parser Class Initialized
INFO - 2023-08-19 06:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:31 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:31 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:31 --> Controller Class Initialized
DEBUG - 2023-08-19 06:15:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:31 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:31 --> Model Class Initialized
INFO - 2023-08-19 06:15:31 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:31 --> Total execution time: 0.1282
ERROR - 2023-08-19 06:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:49 --> Config Class Initialized
INFO - 2023-08-19 06:15:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:49 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:49 --> URI Class Initialized
INFO - 2023-08-19 06:15:49 --> Router Class Initialized
INFO - 2023-08-19 06:15:49 --> Output Class Initialized
INFO - 2023-08-19 06:15:49 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:49 --> Input Class Initialized
INFO - 2023-08-19 06:15:49 --> Language Class Initialized
INFO - 2023-08-19 06:15:49 --> Loader Class Initialized
INFO - 2023-08-19 06:15:49 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:49 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:49 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:49 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:49 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:49 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:49 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:49 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:49 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:49 --> Parser Class Initialized
INFO - 2023-08-19 06:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:49 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:49 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:49 --> Controller Class Initialized
DEBUG - 2023-08-19 06:15:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:49 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:49 --> Model Class Initialized
INFO - 2023-08-19 06:15:49 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:49 --> Total execution time: 0.0195
ERROR - 2023-08-19 06:15:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:54 --> Config Class Initialized
INFO - 2023-08-19 06:15:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:54 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:54 --> URI Class Initialized
INFO - 2023-08-19 06:15:54 --> Router Class Initialized
INFO - 2023-08-19 06:15:54 --> Output Class Initialized
INFO - 2023-08-19 06:15:54 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:54 --> Input Class Initialized
INFO - 2023-08-19 06:15:54 --> Language Class Initialized
INFO - 2023-08-19 06:15:54 --> Loader Class Initialized
INFO - 2023-08-19 06:15:54 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:54 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:54 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:54 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:54 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:54 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:54 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:54 --> Parser Class Initialized
INFO - 2023-08-19 06:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:54 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:54 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:54 --> Controller Class Initialized
DEBUG - 2023-08-19 06:15:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:54 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:54 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:54 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:54 --> Model Class Initialized
INFO - 2023-08-19 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 06:15:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:15:54 --> Model Class Initialized
INFO - 2023-08-19 06:15:54 --> Model Class Initialized
INFO - 2023-08-19 06:15:54 --> Model Class Initialized
INFO - 2023-08-19 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:15:54 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:54 --> Total execution time: 0.1401
ERROR - 2023-08-19 06:15:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:15:55 --> Config Class Initialized
INFO - 2023-08-19 06:15:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:15:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:15:55 --> Utf8 Class Initialized
INFO - 2023-08-19 06:15:55 --> URI Class Initialized
INFO - 2023-08-19 06:15:55 --> Router Class Initialized
INFO - 2023-08-19 06:15:55 --> Output Class Initialized
INFO - 2023-08-19 06:15:55 --> Security Class Initialized
DEBUG - 2023-08-19 06:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:15:55 --> Input Class Initialized
INFO - 2023-08-19 06:15:55 --> Language Class Initialized
INFO - 2023-08-19 06:15:55 --> Loader Class Initialized
INFO - 2023-08-19 06:15:55 --> Helper loaded: url_helper
INFO - 2023-08-19 06:15:55 --> Helper loaded: file_helper
INFO - 2023-08-19 06:15:55 --> Helper loaded: html_helper
INFO - 2023-08-19 06:15:55 --> Helper loaded: text_helper
INFO - 2023-08-19 06:15:55 --> Helper loaded: form_helper
INFO - 2023-08-19 06:15:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:15:55 --> Helper loaded: security_helper
INFO - 2023-08-19 06:15:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:15:55 --> Database Driver Class Initialized
INFO - 2023-08-19 06:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:15:55 --> Parser Class Initialized
INFO - 2023-08-19 06:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:15:55 --> Pagination Class Initialized
INFO - 2023-08-19 06:15:55 --> Form Validation Class Initialized
INFO - 2023-08-19 06:15:55 --> Controller Class Initialized
DEBUG - 2023-08-19 06:15:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:55 --> Model Class Initialized
DEBUG - 2023-08-19 06:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:15:55 --> Model Class Initialized
INFO - 2023-08-19 06:15:55 --> Final output sent to browser
DEBUG - 2023-08-19 06:15:55 --> Total execution time: 0.0308
ERROR - 2023-08-19 06:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:16:07 --> Config Class Initialized
INFO - 2023-08-19 06:16:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:16:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:16:07 --> Utf8 Class Initialized
INFO - 2023-08-19 06:16:07 --> URI Class Initialized
INFO - 2023-08-19 06:16:07 --> Router Class Initialized
INFO - 2023-08-19 06:16:07 --> Output Class Initialized
INFO - 2023-08-19 06:16:07 --> Security Class Initialized
DEBUG - 2023-08-19 06:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:16:07 --> Input Class Initialized
INFO - 2023-08-19 06:16:07 --> Language Class Initialized
INFO - 2023-08-19 06:16:07 --> Loader Class Initialized
INFO - 2023-08-19 06:16:07 --> Helper loaded: url_helper
INFO - 2023-08-19 06:16:07 --> Helper loaded: file_helper
INFO - 2023-08-19 06:16:07 --> Helper loaded: html_helper
INFO - 2023-08-19 06:16:07 --> Helper loaded: text_helper
INFO - 2023-08-19 06:16:07 --> Helper loaded: form_helper
INFO - 2023-08-19 06:16:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:16:07 --> Helper loaded: security_helper
INFO - 2023-08-19 06:16:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:16:07 --> Database Driver Class Initialized
INFO - 2023-08-19 06:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:16:07 --> Parser Class Initialized
INFO - 2023-08-19 06:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:16:07 --> Pagination Class Initialized
INFO - 2023-08-19 06:16:07 --> Form Validation Class Initialized
INFO - 2023-08-19 06:16:07 --> Controller Class Initialized
INFO - 2023-08-19 06:16:07 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:07 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:07 --> Model Class Initialized
INFO - 2023-08-19 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:16:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:16:07 --> Model Class Initialized
INFO - 2023-08-19 06:16:07 --> Model Class Initialized
INFO - 2023-08-19 06:16:07 --> Model Class Initialized
INFO - 2023-08-19 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:16:07 --> Final output sent to browser
DEBUG - 2023-08-19 06:16:07 --> Total execution time: 0.1378
ERROR - 2023-08-19 06:16:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:16:08 --> Config Class Initialized
INFO - 2023-08-19 06:16:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:16:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:16:08 --> Utf8 Class Initialized
INFO - 2023-08-19 06:16:08 --> URI Class Initialized
INFO - 2023-08-19 06:16:08 --> Router Class Initialized
INFO - 2023-08-19 06:16:08 --> Output Class Initialized
INFO - 2023-08-19 06:16:08 --> Security Class Initialized
DEBUG - 2023-08-19 06:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:16:08 --> Input Class Initialized
INFO - 2023-08-19 06:16:08 --> Language Class Initialized
INFO - 2023-08-19 06:16:08 --> Loader Class Initialized
INFO - 2023-08-19 06:16:08 --> Helper loaded: url_helper
INFO - 2023-08-19 06:16:08 --> Helper loaded: file_helper
INFO - 2023-08-19 06:16:08 --> Helper loaded: html_helper
INFO - 2023-08-19 06:16:08 --> Helper loaded: text_helper
INFO - 2023-08-19 06:16:08 --> Helper loaded: form_helper
INFO - 2023-08-19 06:16:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:16:08 --> Helper loaded: security_helper
INFO - 2023-08-19 06:16:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:16:08 --> Database Driver Class Initialized
INFO - 2023-08-19 06:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:16:08 --> Parser Class Initialized
INFO - 2023-08-19 06:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:16:08 --> Pagination Class Initialized
INFO - 2023-08-19 06:16:08 --> Form Validation Class Initialized
INFO - 2023-08-19 06:16:08 --> Controller Class Initialized
INFO - 2023-08-19 06:16:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:08 --> Model Class Initialized
INFO - 2023-08-19 06:16:08 --> Final output sent to browser
DEBUG - 2023-08-19 06:16:08 --> Total execution time: 0.0645
ERROR - 2023-08-19 06:16:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:16:12 --> Config Class Initialized
INFO - 2023-08-19 06:16:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:16:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:16:12 --> Utf8 Class Initialized
INFO - 2023-08-19 06:16:12 --> URI Class Initialized
INFO - 2023-08-19 06:16:12 --> Router Class Initialized
INFO - 2023-08-19 06:16:12 --> Output Class Initialized
INFO - 2023-08-19 06:16:12 --> Security Class Initialized
DEBUG - 2023-08-19 06:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:16:12 --> Input Class Initialized
INFO - 2023-08-19 06:16:12 --> Language Class Initialized
INFO - 2023-08-19 06:16:12 --> Loader Class Initialized
INFO - 2023-08-19 06:16:12 --> Helper loaded: url_helper
INFO - 2023-08-19 06:16:12 --> Helper loaded: file_helper
INFO - 2023-08-19 06:16:12 --> Helper loaded: html_helper
INFO - 2023-08-19 06:16:12 --> Helper loaded: text_helper
INFO - 2023-08-19 06:16:12 --> Helper loaded: form_helper
INFO - 2023-08-19 06:16:12 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:16:12 --> Helper loaded: security_helper
INFO - 2023-08-19 06:16:12 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:16:12 --> Database Driver Class Initialized
INFO - 2023-08-19 06:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:16:12 --> Parser Class Initialized
INFO - 2023-08-19 06:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:16:12 --> Pagination Class Initialized
INFO - 2023-08-19 06:16:12 --> Form Validation Class Initialized
INFO - 2023-08-19 06:16:12 --> Controller Class Initialized
INFO - 2023-08-19 06:16:12 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:12 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:12 --> Model Class Initialized
INFO - 2023-08-19 06:16:13 --> Final output sent to browser
DEBUG - 2023-08-19 06:16:13 --> Total execution time: 0.5103
ERROR - 2023-08-19 06:16:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:16:20 --> Config Class Initialized
INFO - 2023-08-19 06:16:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:16:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:16:20 --> Utf8 Class Initialized
INFO - 2023-08-19 06:16:20 --> URI Class Initialized
INFO - 2023-08-19 06:16:20 --> Router Class Initialized
INFO - 2023-08-19 06:16:20 --> Output Class Initialized
INFO - 2023-08-19 06:16:20 --> Security Class Initialized
DEBUG - 2023-08-19 06:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:16:20 --> Input Class Initialized
INFO - 2023-08-19 06:16:20 --> Language Class Initialized
INFO - 2023-08-19 06:16:20 --> Loader Class Initialized
INFO - 2023-08-19 06:16:20 --> Helper loaded: url_helper
INFO - 2023-08-19 06:16:20 --> Helper loaded: file_helper
INFO - 2023-08-19 06:16:20 --> Helper loaded: html_helper
INFO - 2023-08-19 06:16:20 --> Helper loaded: text_helper
INFO - 2023-08-19 06:16:20 --> Helper loaded: form_helper
INFO - 2023-08-19 06:16:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:16:20 --> Helper loaded: security_helper
INFO - 2023-08-19 06:16:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:16:20 --> Database Driver Class Initialized
INFO - 2023-08-19 06:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:16:20 --> Parser Class Initialized
INFO - 2023-08-19 06:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:16:20 --> Pagination Class Initialized
INFO - 2023-08-19 06:16:20 --> Form Validation Class Initialized
INFO - 2023-08-19 06:16:20 --> Controller Class Initialized
INFO - 2023-08-19 06:16:20 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:20 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:20 --> Model Class Initialized
DEBUG - 2023-08-19 06:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-19 06:16:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:16:20 --> Model Class Initialized
INFO - 2023-08-19 06:16:20 --> Model Class Initialized
INFO - 2023-08-19 06:16:20 --> Model Class Initialized
INFO - 2023-08-19 06:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:16:20 --> Final output sent to browser
DEBUG - 2023-08-19 06:16:20 --> Total execution time: 0.0858
ERROR - 2023-08-19 06:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:17:18 --> Config Class Initialized
INFO - 2023-08-19 06:17:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:17:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:17:18 --> Utf8 Class Initialized
INFO - 2023-08-19 06:17:18 --> URI Class Initialized
INFO - 2023-08-19 06:17:18 --> Router Class Initialized
INFO - 2023-08-19 06:17:18 --> Output Class Initialized
INFO - 2023-08-19 06:17:18 --> Security Class Initialized
DEBUG - 2023-08-19 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:17:18 --> Input Class Initialized
INFO - 2023-08-19 06:17:18 --> Language Class Initialized
INFO - 2023-08-19 06:17:18 --> Loader Class Initialized
INFO - 2023-08-19 06:17:18 --> Helper loaded: url_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: file_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: html_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: text_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: form_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: security_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:17:18 --> Database Driver Class Initialized
INFO - 2023-08-19 06:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:17:18 --> Parser Class Initialized
INFO - 2023-08-19 06:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:17:18 --> Pagination Class Initialized
INFO - 2023-08-19 06:17:18 --> Form Validation Class Initialized
INFO - 2023-08-19 06:17:18 --> Controller Class Initialized
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
INFO - 2023-08-19 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-19 06:17:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
INFO - 2023-08-19 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:17:18 --> Final output sent to browser
DEBUG - 2023-08-19 06:17:18 --> Total execution time: 0.0801
ERROR - 2023-08-19 06:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:17:18 --> Config Class Initialized
INFO - 2023-08-19 06:17:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:17:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:17:18 --> Utf8 Class Initialized
INFO - 2023-08-19 06:17:18 --> URI Class Initialized
INFO - 2023-08-19 06:17:18 --> Router Class Initialized
INFO - 2023-08-19 06:17:18 --> Output Class Initialized
INFO - 2023-08-19 06:17:18 --> Security Class Initialized
DEBUG - 2023-08-19 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:17:18 --> Input Class Initialized
INFO - 2023-08-19 06:17:18 --> Language Class Initialized
INFO - 2023-08-19 06:17:18 --> Loader Class Initialized
INFO - 2023-08-19 06:17:18 --> Helper loaded: url_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: file_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: html_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: text_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: form_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: security_helper
INFO - 2023-08-19 06:17:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:17:18 --> Database Driver Class Initialized
INFO - 2023-08-19 06:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:17:18 --> Parser Class Initialized
INFO - 2023-08-19 06:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:17:18 --> Pagination Class Initialized
INFO - 2023-08-19 06:17:18 --> Form Validation Class Initialized
INFO - 2023-08-19 06:17:18 --> Controller Class Initialized
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:18 --> Model Class Initialized
INFO - 2023-08-19 06:17:18 --> Final output sent to browser
DEBUG - 2023-08-19 06:17:18 --> Total execution time: 0.0276
ERROR - 2023-08-19 06:17:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:17:23 --> Config Class Initialized
INFO - 2023-08-19 06:17:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:17:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:17:23 --> Utf8 Class Initialized
INFO - 2023-08-19 06:17:23 --> URI Class Initialized
DEBUG - 2023-08-19 06:17:23 --> No URI present. Default controller set.
INFO - 2023-08-19 06:17:23 --> Router Class Initialized
INFO - 2023-08-19 06:17:23 --> Output Class Initialized
INFO - 2023-08-19 06:17:23 --> Security Class Initialized
DEBUG - 2023-08-19 06:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:17:23 --> Input Class Initialized
INFO - 2023-08-19 06:17:23 --> Language Class Initialized
INFO - 2023-08-19 06:17:23 --> Loader Class Initialized
INFO - 2023-08-19 06:17:23 --> Helper loaded: url_helper
INFO - 2023-08-19 06:17:23 --> Helper loaded: file_helper
INFO - 2023-08-19 06:17:23 --> Helper loaded: html_helper
INFO - 2023-08-19 06:17:23 --> Helper loaded: text_helper
INFO - 2023-08-19 06:17:23 --> Helper loaded: form_helper
INFO - 2023-08-19 06:17:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:17:23 --> Helper loaded: security_helper
INFO - 2023-08-19 06:17:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:17:23 --> Database Driver Class Initialized
INFO - 2023-08-19 06:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:17:23 --> Parser Class Initialized
INFO - 2023-08-19 06:17:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:17:23 --> Pagination Class Initialized
INFO - 2023-08-19 06:17:23 --> Form Validation Class Initialized
INFO - 2023-08-19 06:17:23 --> Controller Class Initialized
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
INFO - 2023-08-19 06:17:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:17:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:17:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:17:23 --> Model Class Initialized
INFO - 2023-08-19 06:17:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:17:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:17:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:17:23 --> Final output sent to browser
DEBUG - 2023-08-19 06:17:23 --> Total execution time: 0.0902
ERROR - 2023-08-19 06:17:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:17:31 --> Config Class Initialized
INFO - 2023-08-19 06:17:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:17:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:17:31 --> Utf8 Class Initialized
INFO - 2023-08-19 06:17:31 --> URI Class Initialized
INFO - 2023-08-19 06:17:31 --> Router Class Initialized
INFO - 2023-08-19 06:17:31 --> Output Class Initialized
INFO - 2023-08-19 06:17:31 --> Security Class Initialized
DEBUG - 2023-08-19 06:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:17:31 --> Input Class Initialized
INFO - 2023-08-19 06:17:31 --> Language Class Initialized
INFO - 2023-08-19 06:17:31 --> Loader Class Initialized
INFO - 2023-08-19 06:17:31 --> Helper loaded: url_helper
INFO - 2023-08-19 06:17:31 --> Helper loaded: file_helper
INFO - 2023-08-19 06:17:31 --> Helper loaded: html_helper
INFO - 2023-08-19 06:17:31 --> Helper loaded: text_helper
INFO - 2023-08-19 06:17:31 --> Helper loaded: form_helper
INFO - 2023-08-19 06:17:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:17:31 --> Helper loaded: security_helper
INFO - 2023-08-19 06:17:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:17:31 --> Database Driver Class Initialized
INFO - 2023-08-19 06:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:17:31 --> Parser Class Initialized
INFO - 2023-08-19 06:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:17:31 --> Pagination Class Initialized
INFO - 2023-08-19 06:17:31 --> Form Validation Class Initialized
INFO - 2023-08-19 06:17:31 --> Controller Class Initialized
INFO - 2023-08-19 06:17:31 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:31 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:31 --> Model Class Initialized
INFO - 2023-08-19 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:17:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:17:31 --> Model Class Initialized
INFO - 2023-08-19 06:17:31 --> Model Class Initialized
INFO - 2023-08-19 06:17:31 --> Model Class Initialized
INFO - 2023-08-19 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:17:31 --> Final output sent to browser
DEBUG - 2023-08-19 06:17:31 --> Total execution time: 0.0756
ERROR - 2023-08-19 06:17:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:17:32 --> Config Class Initialized
INFO - 2023-08-19 06:17:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:17:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:17:32 --> Utf8 Class Initialized
INFO - 2023-08-19 06:17:32 --> URI Class Initialized
INFO - 2023-08-19 06:17:32 --> Router Class Initialized
INFO - 2023-08-19 06:17:32 --> Output Class Initialized
INFO - 2023-08-19 06:17:32 --> Security Class Initialized
DEBUG - 2023-08-19 06:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:17:32 --> Input Class Initialized
INFO - 2023-08-19 06:17:32 --> Language Class Initialized
INFO - 2023-08-19 06:17:32 --> Loader Class Initialized
INFO - 2023-08-19 06:17:32 --> Helper loaded: url_helper
INFO - 2023-08-19 06:17:32 --> Helper loaded: file_helper
INFO - 2023-08-19 06:17:32 --> Helper loaded: html_helper
INFO - 2023-08-19 06:17:32 --> Helper loaded: text_helper
INFO - 2023-08-19 06:17:32 --> Helper loaded: form_helper
INFO - 2023-08-19 06:17:32 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:17:32 --> Helper loaded: security_helper
INFO - 2023-08-19 06:17:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:17:32 --> Database Driver Class Initialized
INFO - 2023-08-19 06:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:17:32 --> Parser Class Initialized
INFO - 2023-08-19 06:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:17:32 --> Pagination Class Initialized
INFO - 2023-08-19 06:17:32 --> Form Validation Class Initialized
INFO - 2023-08-19 06:17:32 --> Controller Class Initialized
INFO - 2023-08-19 06:17:32 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:32 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:32 --> Model Class Initialized
INFO - 2023-08-19 06:17:32 --> Final output sent to browser
DEBUG - 2023-08-19 06:17:32 --> Total execution time: 0.0399
ERROR - 2023-08-19 06:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:17:51 --> Config Class Initialized
INFO - 2023-08-19 06:17:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:17:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:17:51 --> Utf8 Class Initialized
INFO - 2023-08-19 06:17:51 --> URI Class Initialized
INFO - 2023-08-19 06:17:51 --> Router Class Initialized
INFO - 2023-08-19 06:17:51 --> Output Class Initialized
INFO - 2023-08-19 06:17:51 --> Security Class Initialized
DEBUG - 2023-08-19 06:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:17:51 --> Input Class Initialized
INFO - 2023-08-19 06:17:51 --> Language Class Initialized
INFO - 2023-08-19 06:17:51 --> Loader Class Initialized
INFO - 2023-08-19 06:17:51 --> Helper loaded: url_helper
INFO - 2023-08-19 06:17:51 --> Helper loaded: file_helper
INFO - 2023-08-19 06:17:51 --> Helper loaded: html_helper
INFO - 2023-08-19 06:17:51 --> Helper loaded: text_helper
INFO - 2023-08-19 06:17:51 --> Helper loaded: form_helper
INFO - 2023-08-19 06:17:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:17:51 --> Helper loaded: security_helper
INFO - 2023-08-19 06:17:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:17:51 --> Database Driver Class Initialized
INFO - 2023-08-19 06:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:17:51 --> Parser Class Initialized
INFO - 2023-08-19 06:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:17:51 --> Pagination Class Initialized
INFO - 2023-08-19 06:17:51 --> Form Validation Class Initialized
INFO - 2023-08-19 06:17:51 --> Controller Class Initialized
INFO - 2023-08-19 06:17:51 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:51 --> Model Class Initialized
DEBUG - 2023-08-19 06:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:17:51 --> Model Class Initialized
INFO - 2023-08-19 06:17:51 --> Final output sent to browser
DEBUG - 2023-08-19 06:17:51 --> Total execution time: 0.0963
ERROR - 2023-08-19 06:18:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:18:03 --> Config Class Initialized
INFO - 2023-08-19 06:18:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:18:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:18:03 --> Utf8 Class Initialized
INFO - 2023-08-19 06:18:03 --> URI Class Initialized
DEBUG - 2023-08-19 06:18:03 --> No URI present. Default controller set.
INFO - 2023-08-19 06:18:03 --> Router Class Initialized
INFO - 2023-08-19 06:18:03 --> Output Class Initialized
INFO - 2023-08-19 06:18:03 --> Security Class Initialized
DEBUG - 2023-08-19 06:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:18:03 --> Input Class Initialized
INFO - 2023-08-19 06:18:03 --> Language Class Initialized
INFO - 2023-08-19 06:18:03 --> Loader Class Initialized
INFO - 2023-08-19 06:18:03 --> Helper loaded: url_helper
INFO - 2023-08-19 06:18:03 --> Helper loaded: file_helper
INFO - 2023-08-19 06:18:03 --> Helper loaded: html_helper
INFO - 2023-08-19 06:18:03 --> Helper loaded: text_helper
INFO - 2023-08-19 06:18:03 --> Helper loaded: form_helper
INFO - 2023-08-19 06:18:03 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:18:03 --> Helper loaded: security_helper
INFO - 2023-08-19 06:18:03 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:18:03 --> Database Driver Class Initialized
INFO - 2023-08-19 06:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:18:03 --> Parser Class Initialized
INFO - 2023-08-19 06:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:18:03 --> Pagination Class Initialized
INFO - 2023-08-19 06:18:03 --> Form Validation Class Initialized
INFO - 2023-08-19 06:18:03 --> Controller Class Initialized
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
INFO - 2023-08-19 06:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:18:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:18:03 --> Model Class Initialized
INFO - 2023-08-19 06:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:18:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:18:03 --> Final output sent to browser
DEBUG - 2023-08-19 06:18:03 --> Total execution time: 0.0868
ERROR - 2023-08-19 06:18:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:18:14 --> Config Class Initialized
INFO - 2023-08-19 06:18:14 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:18:14 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:18:14 --> Utf8 Class Initialized
INFO - 2023-08-19 06:18:14 --> URI Class Initialized
INFO - 2023-08-19 06:18:14 --> Router Class Initialized
INFO - 2023-08-19 06:18:14 --> Output Class Initialized
INFO - 2023-08-19 06:18:14 --> Security Class Initialized
DEBUG - 2023-08-19 06:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:18:14 --> Input Class Initialized
INFO - 2023-08-19 06:18:14 --> Language Class Initialized
INFO - 2023-08-19 06:18:14 --> Loader Class Initialized
INFO - 2023-08-19 06:18:14 --> Helper loaded: url_helper
INFO - 2023-08-19 06:18:14 --> Helper loaded: file_helper
INFO - 2023-08-19 06:18:14 --> Helper loaded: html_helper
INFO - 2023-08-19 06:18:14 --> Helper loaded: text_helper
INFO - 2023-08-19 06:18:14 --> Helper loaded: form_helper
INFO - 2023-08-19 06:18:14 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:18:14 --> Helper loaded: security_helper
INFO - 2023-08-19 06:18:14 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:18:14 --> Database Driver Class Initialized
INFO - 2023-08-19 06:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:18:14 --> Parser Class Initialized
INFO - 2023-08-19 06:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:18:14 --> Pagination Class Initialized
INFO - 2023-08-19 06:18:14 --> Form Validation Class Initialized
INFO - 2023-08-19 06:18:14 --> Controller Class Initialized
INFO - 2023-08-19 06:18:14 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:14 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:14 --> Model Class Initialized
INFO - 2023-08-19 06:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:18:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:18:14 --> Model Class Initialized
INFO - 2023-08-19 06:18:14 --> Model Class Initialized
INFO - 2023-08-19 06:18:14 --> Model Class Initialized
INFO - 2023-08-19 06:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:18:14 --> Final output sent to browser
DEBUG - 2023-08-19 06:18:14 --> Total execution time: 0.0750
ERROR - 2023-08-19 06:18:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:18:15 --> Config Class Initialized
INFO - 2023-08-19 06:18:15 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:18:15 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:18:15 --> Utf8 Class Initialized
INFO - 2023-08-19 06:18:15 --> URI Class Initialized
INFO - 2023-08-19 06:18:15 --> Router Class Initialized
INFO - 2023-08-19 06:18:15 --> Output Class Initialized
INFO - 2023-08-19 06:18:15 --> Security Class Initialized
DEBUG - 2023-08-19 06:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:18:15 --> Input Class Initialized
INFO - 2023-08-19 06:18:15 --> Language Class Initialized
INFO - 2023-08-19 06:18:15 --> Loader Class Initialized
INFO - 2023-08-19 06:18:15 --> Helper loaded: url_helper
INFO - 2023-08-19 06:18:15 --> Helper loaded: file_helper
INFO - 2023-08-19 06:18:15 --> Helper loaded: html_helper
INFO - 2023-08-19 06:18:15 --> Helper loaded: text_helper
INFO - 2023-08-19 06:18:15 --> Helper loaded: form_helper
INFO - 2023-08-19 06:18:15 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:18:15 --> Helper loaded: security_helper
INFO - 2023-08-19 06:18:15 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:18:15 --> Database Driver Class Initialized
INFO - 2023-08-19 06:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:18:15 --> Parser Class Initialized
INFO - 2023-08-19 06:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:18:15 --> Pagination Class Initialized
INFO - 2023-08-19 06:18:15 --> Form Validation Class Initialized
INFO - 2023-08-19 06:18:15 --> Controller Class Initialized
INFO - 2023-08-19 06:18:15 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:15 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:15 --> Model Class Initialized
INFO - 2023-08-19 06:18:15 --> Final output sent to browser
DEBUG - 2023-08-19 06:18:15 --> Total execution time: 0.0364
ERROR - 2023-08-19 06:18:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:18:19 --> Config Class Initialized
INFO - 2023-08-19 06:18:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:18:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:18:19 --> Utf8 Class Initialized
INFO - 2023-08-19 06:18:19 --> URI Class Initialized
INFO - 2023-08-19 06:18:19 --> Router Class Initialized
INFO - 2023-08-19 06:18:19 --> Output Class Initialized
INFO - 2023-08-19 06:18:19 --> Security Class Initialized
DEBUG - 2023-08-19 06:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:18:19 --> Input Class Initialized
INFO - 2023-08-19 06:18:19 --> Language Class Initialized
INFO - 2023-08-19 06:18:19 --> Loader Class Initialized
INFO - 2023-08-19 06:18:19 --> Helper loaded: url_helper
INFO - 2023-08-19 06:18:19 --> Helper loaded: file_helper
INFO - 2023-08-19 06:18:19 --> Helper loaded: html_helper
INFO - 2023-08-19 06:18:19 --> Helper loaded: text_helper
INFO - 2023-08-19 06:18:19 --> Helper loaded: form_helper
INFO - 2023-08-19 06:18:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:18:19 --> Helper loaded: security_helper
INFO - 2023-08-19 06:18:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:18:19 --> Database Driver Class Initialized
INFO - 2023-08-19 06:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:18:19 --> Parser Class Initialized
INFO - 2023-08-19 06:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:18:19 --> Pagination Class Initialized
INFO - 2023-08-19 06:18:19 --> Form Validation Class Initialized
INFO - 2023-08-19 06:18:19 --> Controller Class Initialized
INFO - 2023-08-19 06:18:19 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:19 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:19 --> Model Class Initialized
INFO - 2023-08-19 06:18:19 --> Final output sent to browser
DEBUG - 2023-08-19 06:18:19 --> Total execution time: 0.0945
ERROR - 2023-08-19 06:18:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:18:26 --> Config Class Initialized
INFO - 2023-08-19 06:18:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:18:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:18:26 --> Utf8 Class Initialized
INFO - 2023-08-19 06:18:26 --> URI Class Initialized
DEBUG - 2023-08-19 06:18:26 --> No URI present. Default controller set.
INFO - 2023-08-19 06:18:26 --> Router Class Initialized
INFO - 2023-08-19 06:18:26 --> Output Class Initialized
INFO - 2023-08-19 06:18:26 --> Security Class Initialized
DEBUG - 2023-08-19 06:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:18:26 --> Input Class Initialized
INFO - 2023-08-19 06:18:26 --> Language Class Initialized
INFO - 2023-08-19 06:18:26 --> Loader Class Initialized
INFO - 2023-08-19 06:18:26 --> Helper loaded: url_helper
INFO - 2023-08-19 06:18:26 --> Helper loaded: file_helper
INFO - 2023-08-19 06:18:26 --> Helper loaded: html_helper
INFO - 2023-08-19 06:18:26 --> Helper loaded: text_helper
INFO - 2023-08-19 06:18:26 --> Helper loaded: form_helper
INFO - 2023-08-19 06:18:26 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:18:26 --> Helper loaded: security_helper
INFO - 2023-08-19 06:18:26 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:18:26 --> Database Driver Class Initialized
INFO - 2023-08-19 06:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:18:26 --> Parser Class Initialized
INFO - 2023-08-19 06:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:18:26 --> Pagination Class Initialized
INFO - 2023-08-19 06:18:26 --> Form Validation Class Initialized
INFO - 2023-08-19 06:18:26 --> Controller Class Initialized
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
INFO - 2023-08-19 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:18:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:18:26 --> Model Class Initialized
INFO - 2023-08-19 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:18:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:18:26 --> Final output sent to browser
DEBUG - 2023-08-19 06:18:26 --> Total execution time: 0.0893
ERROR - 2023-08-19 06:18:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:18:43 --> Config Class Initialized
INFO - 2023-08-19 06:18:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:18:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:18:43 --> Utf8 Class Initialized
INFO - 2023-08-19 06:18:43 --> URI Class Initialized
DEBUG - 2023-08-19 06:18:43 --> No URI present. Default controller set.
INFO - 2023-08-19 06:18:43 --> Router Class Initialized
INFO - 2023-08-19 06:18:43 --> Output Class Initialized
INFO - 2023-08-19 06:18:43 --> Security Class Initialized
DEBUG - 2023-08-19 06:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:18:43 --> Input Class Initialized
INFO - 2023-08-19 06:18:43 --> Language Class Initialized
INFO - 2023-08-19 06:18:43 --> Loader Class Initialized
INFO - 2023-08-19 06:18:43 --> Helper loaded: url_helper
INFO - 2023-08-19 06:18:43 --> Helper loaded: file_helper
INFO - 2023-08-19 06:18:43 --> Helper loaded: html_helper
INFO - 2023-08-19 06:18:43 --> Helper loaded: text_helper
INFO - 2023-08-19 06:18:43 --> Helper loaded: form_helper
INFO - 2023-08-19 06:18:43 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:18:43 --> Helper loaded: security_helper
INFO - 2023-08-19 06:18:43 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:18:43 --> Database Driver Class Initialized
INFO - 2023-08-19 06:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:18:43 --> Parser Class Initialized
INFO - 2023-08-19 06:18:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:18:43 --> Pagination Class Initialized
INFO - 2023-08-19 06:18:43 --> Form Validation Class Initialized
INFO - 2023-08-19 06:18:43 --> Controller Class Initialized
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
DEBUG - 2023-08-19 06:18:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
INFO - 2023-08-19 06:18:43 --> Model Class Initialized
INFO - 2023-08-19 06:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:18:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:18:44 --> Model Class Initialized
INFO - 2023-08-19 06:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:18:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:18:44 --> Final output sent to browser
DEBUG - 2023-08-19 06:18:44 --> Total execution time: 0.1843
ERROR - 2023-08-19 06:19:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:19:02 --> Config Class Initialized
INFO - 2023-08-19 06:19:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:19:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:19:02 --> Utf8 Class Initialized
INFO - 2023-08-19 06:19:02 --> URI Class Initialized
DEBUG - 2023-08-19 06:19:02 --> No URI present. Default controller set.
INFO - 2023-08-19 06:19:02 --> Router Class Initialized
INFO - 2023-08-19 06:19:02 --> Output Class Initialized
INFO - 2023-08-19 06:19:02 --> Security Class Initialized
DEBUG - 2023-08-19 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:19:02 --> Input Class Initialized
INFO - 2023-08-19 06:19:02 --> Language Class Initialized
INFO - 2023-08-19 06:19:02 --> Loader Class Initialized
INFO - 2023-08-19 06:19:02 --> Helper loaded: url_helper
INFO - 2023-08-19 06:19:02 --> Helper loaded: file_helper
INFO - 2023-08-19 06:19:02 --> Helper loaded: html_helper
INFO - 2023-08-19 06:19:02 --> Helper loaded: text_helper
INFO - 2023-08-19 06:19:02 --> Helper loaded: form_helper
INFO - 2023-08-19 06:19:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:19:02 --> Helper loaded: security_helper
INFO - 2023-08-19 06:19:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:19:02 --> Database Driver Class Initialized
INFO - 2023-08-19 06:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:19:02 --> Parser Class Initialized
INFO - 2023-08-19 06:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:19:02 --> Pagination Class Initialized
INFO - 2023-08-19 06:19:02 --> Form Validation Class Initialized
INFO - 2023-08-19 06:19:02 --> Controller Class Initialized
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
DEBUG - 2023-08-19 06:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
DEBUG - 2023-08-19 06:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
DEBUG - 2023-08-19 06:19:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
INFO - 2023-08-19 06:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:19:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:19:02 --> Model Class Initialized
INFO - 2023-08-19 06:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:19:02 --> Final output sent to browser
DEBUG - 2023-08-19 06:19:02 --> Total execution time: 0.1972
ERROR - 2023-08-19 06:19:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:19:58 --> Config Class Initialized
INFO - 2023-08-19 06:19:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:19:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:19:58 --> Utf8 Class Initialized
INFO - 2023-08-19 06:19:58 --> URI Class Initialized
INFO - 2023-08-19 06:19:58 --> Router Class Initialized
INFO - 2023-08-19 06:19:58 --> Output Class Initialized
INFO - 2023-08-19 06:19:58 --> Security Class Initialized
DEBUG - 2023-08-19 06:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:19:58 --> Input Class Initialized
INFO - 2023-08-19 06:19:58 --> Language Class Initialized
INFO - 2023-08-19 06:19:58 --> Loader Class Initialized
INFO - 2023-08-19 06:19:58 --> Helper loaded: url_helper
INFO - 2023-08-19 06:19:58 --> Helper loaded: file_helper
INFO - 2023-08-19 06:19:58 --> Helper loaded: html_helper
INFO - 2023-08-19 06:19:58 --> Helper loaded: text_helper
INFO - 2023-08-19 06:19:58 --> Helper loaded: form_helper
INFO - 2023-08-19 06:19:58 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:19:58 --> Helper loaded: security_helper
INFO - 2023-08-19 06:19:58 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:19:58 --> Database Driver Class Initialized
INFO - 2023-08-19 06:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:19:58 --> Parser Class Initialized
INFO - 2023-08-19 06:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:19:58 --> Pagination Class Initialized
INFO - 2023-08-19 06:19:58 --> Form Validation Class Initialized
INFO - 2023-08-19 06:19:58 --> Controller Class Initialized
INFO - 2023-08-19 06:19:58 --> Model Class Initialized
DEBUG - 2023-08-19 06:19:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:19:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:58 --> Model Class Initialized
DEBUG - 2023-08-19 06:19:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:58 --> Model Class Initialized
INFO - 2023-08-19 06:19:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 06:19:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:19:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:19:58 --> Model Class Initialized
INFO - 2023-08-19 06:19:58 --> Model Class Initialized
INFO - 2023-08-19 06:19:58 --> Model Class Initialized
INFO - 2023-08-19 06:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:19:59 --> Final output sent to browser
DEBUG - 2023-08-19 06:19:59 --> Total execution time: 0.1343
ERROR - 2023-08-19 06:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:19:59 --> Config Class Initialized
INFO - 2023-08-19 06:19:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:19:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:19:59 --> Utf8 Class Initialized
INFO - 2023-08-19 06:19:59 --> URI Class Initialized
INFO - 2023-08-19 06:19:59 --> Router Class Initialized
INFO - 2023-08-19 06:19:59 --> Output Class Initialized
INFO - 2023-08-19 06:19:59 --> Security Class Initialized
DEBUG - 2023-08-19 06:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:19:59 --> Input Class Initialized
INFO - 2023-08-19 06:19:59 --> Language Class Initialized
INFO - 2023-08-19 06:19:59 --> Loader Class Initialized
INFO - 2023-08-19 06:19:59 --> Helper loaded: url_helper
INFO - 2023-08-19 06:19:59 --> Helper loaded: file_helper
INFO - 2023-08-19 06:19:59 --> Helper loaded: html_helper
INFO - 2023-08-19 06:19:59 --> Helper loaded: text_helper
INFO - 2023-08-19 06:19:59 --> Helper loaded: form_helper
INFO - 2023-08-19 06:19:59 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:19:59 --> Helper loaded: security_helper
INFO - 2023-08-19 06:19:59 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:19:59 --> Database Driver Class Initialized
INFO - 2023-08-19 06:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:19:59 --> Parser Class Initialized
INFO - 2023-08-19 06:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:19:59 --> Pagination Class Initialized
INFO - 2023-08-19 06:19:59 --> Form Validation Class Initialized
INFO - 2023-08-19 06:19:59 --> Controller Class Initialized
INFO - 2023-08-19 06:19:59 --> Model Class Initialized
DEBUG - 2023-08-19 06:19:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:59 --> Model Class Initialized
DEBUG - 2023-08-19 06:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:19:59 --> Model Class Initialized
INFO - 2023-08-19 06:19:59 --> Final output sent to browser
DEBUG - 2023-08-19 06:19:59 --> Total execution time: 0.0517
ERROR - 2023-08-19 06:20:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:20:08 --> Config Class Initialized
INFO - 2023-08-19 06:20:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:20:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:20:08 --> Utf8 Class Initialized
INFO - 2023-08-19 06:20:08 --> URI Class Initialized
INFO - 2023-08-19 06:20:08 --> Router Class Initialized
INFO - 2023-08-19 06:20:08 --> Output Class Initialized
INFO - 2023-08-19 06:20:08 --> Security Class Initialized
DEBUG - 2023-08-19 06:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:20:08 --> Input Class Initialized
INFO - 2023-08-19 06:20:08 --> Language Class Initialized
INFO - 2023-08-19 06:20:08 --> Loader Class Initialized
INFO - 2023-08-19 06:20:08 --> Helper loaded: url_helper
INFO - 2023-08-19 06:20:08 --> Helper loaded: file_helper
INFO - 2023-08-19 06:20:08 --> Helper loaded: html_helper
INFO - 2023-08-19 06:20:08 --> Helper loaded: text_helper
INFO - 2023-08-19 06:20:08 --> Helper loaded: form_helper
INFO - 2023-08-19 06:20:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:20:08 --> Helper loaded: security_helper
INFO - 2023-08-19 06:20:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:20:08 --> Database Driver Class Initialized
INFO - 2023-08-19 06:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:20:08 --> Parser Class Initialized
INFO - 2023-08-19 06:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:20:08 --> Pagination Class Initialized
INFO - 2023-08-19 06:20:08 --> Form Validation Class Initialized
INFO - 2023-08-19 06:20:08 --> Controller Class Initialized
INFO - 2023-08-19 06:20:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:20:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:20:08 --> Model Class Initialized
DEBUG - 2023-08-19 06:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:20:08 --> Model Class Initialized
INFO - 2023-08-19 06:20:08 --> Final output sent to browser
DEBUG - 2023-08-19 06:20:08 --> Total execution time: 0.5407
ERROR - 2023-08-19 06:20:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 06:20:30 --> Config Class Initialized
INFO - 2023-08-19 06:20:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 06:20:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 06:20:30 --> Utf8 Class Initialized
INFO - 2023-08-19 06:20:30 --> URI Class Initialized
DEBUG - 2023-08-19 06:20:30 --> No URI present. Default controller set.
INFO - 2023-08-19 06:20:30 --> Router Class Initialized
INFO - 2023-08-19 06:20:30 --> Output Class Initialized
INFO - 2023-08-19 06:20:30 --> Security Class Initialized
DEBUG - 2023-08-19 06:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 06:20:30 --> Input Class Initialized
INFO - 2023-08-19 06:20:30 --> Language Class Initialized
INFO - 2023-08-19 06:20:30 --> Loader Class Initialized
INFO - 2023-08-19 06:20:30 --> Helper loaded: url_helper
INFO - 2023-08-19 06:20:30 --> Helper loaded: file_helper
INFO - 2023-08-19 06:20:30 --> Helper loaded: html_helper
INFO - 2023-08-19 06:20:30 --> Helper loaded: text_helper
INFO - 2023-08-19 06:20:30 --> Helper loaded: form_helper
INFO - 2023-08-19 06:20:30 --> Helper loaded: lang_helper
INFO - 2023-08-19 06:20:30 --> Helper loaded: security_helper
INFO - 2023-08-19 06:20:30 --> Helper loaded: cookie_helper
INFO - 2023-08-19 06:20:30 --> Database Driver Class Initialized
INFO - 2023-08-19 06:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 06:20:30 --> Parser Class Initialized
INFO - 2023-08-19 06:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 06:20:30 --> Pagination Class Initialized
INFO - 2023-08-19 06:20:30 --> Form Validation Class Initialized
INFO - 2023-08-19 06:20:30 --> Controller Class Initialized
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
DEBUG - 2023-08-19 06:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
DEBUG - 2023-08-19 06:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
DEBUG - 2023-08-19 06:20:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 06:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
INFO - 2023-08-19 06:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 06:20:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 06:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 06:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 06:20:30 --> Model Class Initialized
INFO - 2023-08-19 06:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 06:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 06:20:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 06:20:30 --> Final output sent to browser
DEBUG - 2023-08-19 06:20:30 --> Total execution time: 0.0895
ERROR - 2023-08-19 10:37:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 10:37:30 --> Config Class Initialized
INFO - 2023-08-19 10:37:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 10:37:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 10:37:30 --> Utf8 Class Initialized
INFO - 2023-08-19 10:37:30 --> URI Class Initialized
DEBUG - 2023-08-19 10:37:30 --> No URI present. Default controller set.
INFO - 2023-08-19 10:37:30 --> Router Class Initialized
INFO - 2023-08-19 10:37:30 --> Output Class Initialized
INFO - 2023-08-19 10:37:30 --> Security Class Initialized
DEBUG - 2023-08-19 10:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 10:37:30 --> Input Class Initialized
INFO - 2023-08-19 10:37:30 --> Language Class Initialized
INFO - 2023-08-19 10:37:30 --> Loader Class Initialized
INFO - 2023-08-19 10:37:30 --> Helper loaded: url_helper
INFO - 2023-08-19 10:37:30 --> Helper loaded: file_helper
INFO - 2023-08-19 10:37:30 --> Helper loaded: html_helper
INFO - 2023-08-19 10:37:30 --> Helper loaded: text_helper
INFO - 2023-08-19 10:37:30 --> Helper loaded: form_helper
INFO - 2023-08-19 10:37:30 --> Helper loaded: lang_helper
INFO - 2023-08-19 10:37:30 --> Helper loaded: security_helper
INFO - 2023-08-19 10:37:30 --> Helper loaded: cookie_helper
INFO - 2023-08-19 10:37:30 --> Database Driver Class Initialized
INFO - 2023-08-19 10:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 10:37:30 --> Parser Class Initialized
INFO - 2023-08-19 10:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 10:37:30 --> Pagination Class Initialized
INFO - 2023-08-19 10:37:30 --> Form Validation Class Initialized
INFO - 2023-08-19 10:37:30 --> Controller Class Initialized
INFO - 2023-08-19 10:37:30 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 10:37:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 10:37:31 --> Config Class Initialized
INFO - 2023-08-19 10:37:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 10:37:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 10:37:31 --> Utf8 Class Initialized
INFO - 2023-08-19 10:37:31 --> URI Class Initialized
INFO - 2023-08-19 10:37:31 --> Router Class Initialized
INFO - 2023-08-19 10:37:31 --> Output Class Initialized
INFO - 2023-08-19 10:37:31 --> Security Class Initialized
DEBUG - 2023-08-19 10:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 10:37:31 --> Input Class Initialized
INFO - 2023-08-19 10:37:31 --> Language Class Initialized
INFO - 2023-08-19 10:37:31 --> Loader Class Initialized
INFO - 2023-08-19 10:37:31 --> Helper loaded: url_helper
INFO - 2023-08-19 10:37:31 --> Helper loaded: file_helper
INFO - 2023-08-19 10:37:31 --> Helper loaded: html_helper
INFO - 2023-08-19 10:37:31 --> Helper loaded: text_helper
INFO - 2023-08-19 10:37:31 --> Helper loaded: form_helper
INFO - 2023-08-19 10:37:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 10:37:31 --> Helper loaded: security_helper
INFO - 2023-08-19 10:37:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 10:37:31 --> Database Driver Class Initialized
INFO - 2023-08-19 10:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 10:37:31 --> Parser Class Initialized
INFO - 2023-08-19 10:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 10:37:31 --> Pagination Class Initialized
INFO - 2023-08-19 10:37:31 --> Form Validation Class Initialized
INFO - 2023-08-19 10:37:31 --> Controller Class Initialized
INFO - 2023-08-19 10:37:31 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 10:37:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 10:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 10:37:31 --> Model Class Initialized
INFO - 2023-08-19 10:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 10:37:31 --> Final output sent to browser
DEBUG - 2023-08-19 10:37:31 --> Total execution time: 0.0340
ERROR - 2023-08-19 10:37:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 10:37:42 --> Config Class Initialized
INFO - 2023-08-19 10:37:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 10:37:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 10:37:42 --> Utf8 Class Initialized
INFO - 2023-08-19 10:37:42 --> URI Class Initialized
INFO - 2023-08-19 10:37:42 --> Router Class Initialized
INFO - 2023-08-19 10:37:42 --> Output Class Initialized
INFO - 2023-08-19 10:37:42 --> Security Class Initialized
DEBUG - 2023-08-19 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 10:37:42 --> Input Class Initialized
INFO - 2023-08-19 10:37:42 --> Language Class Initialized
INFO - 2023-08-19 10:37:42 --> Loader Class Initialized
INFO - 2023-08-19 10:37:42 --> Helper loaded: url_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: file_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: html_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: text_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: form_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: lang_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: security_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 10:37:42 --> Database Driver Class Initialized
INFO - 2023-08-19 10:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 10:37:42 --> Parser Class Initialized
INFO - 2023-08-19 10:37:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 10:37:42 --> Pagination Class Initialized
INFO - 2023-08-19 10:37:42 --> Form Validation Class Initialized
INFO - 2023-08-19 10:37:42 --> Controller Class Initialized
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
INFO - 2023-08-19 10:37:42 --> Final output sent to browser
DEBUG - 2023-08-19 10:37:42 --> Total execution time: 0.0197
ERROR - 2023-08-19 10:37:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 10:37:42 --> Config Class Initialized
INFO - 2023-08-19 10:37:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 10:37:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 10:37:42 --> Utf8 Class Initialized
INFO - 2023-08-19 10:37:42 --> URI Class Initialized
DEBUG - 2023-08-19 10:37:42 --> No URI present. Default controller set.
INFO - 2023-08-19 10:37:42 --> Router Class Initialized
INFO - 2023-08-19 10:37:42 --> Output Class Initialized
INFO - 2023-08-19 10:37:42 --> Security Class Initialized
DEBUG - 2023-08-19 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 10:37:42 --> Input Class Initialized
INFO - 2023-08-19 10:37:42 --> Language Class Initialized
INFO - 2023-08-19 10:37:42 --> Loader Class Initialized
INFO - 2023-08-19 10:37:42 --> Helper loaded: url_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: file_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: html_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: text_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: form_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: lang_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: security_helper
INFO - 2023-08-19 10:37:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 10:37:42 --> Database Driver Class Initialized
INFO - 2023-08-19 10:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 10:37:42 --> Parser Class Initialized
INFO - 2023-08-19 10:37:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 10:37:42 --> Pagination Class Initialized
INFO - 2023-08-19 10:37:42 --> Form Validation Class Initialized
INFO - 2023-08-19 10:37:42 --> Controller Class Initialized
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
INFO - 2023-08-19 10:37:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 10:37:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 10:37:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 10:37:42 --> Model Class Initialized
INFO - 2023-08-19 10:37:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 10:37:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 10:37:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 10:37:42 --> Final output sent to browser
DEBUG - 2023-08-19 10:37:42 --> Total execution time: 0.0963
ERROR - 2023-08-19 10:37:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 10:37:54 --> Config Class Initialized
INFO - 2023-08-19 10:37:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 10:37:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 10:37:54 --> Utf8 Class Initialized
INFO - 2023-08-19 10:37:54 --> URI Class Initialized
INFO - 2023-08-19 10:37:54 --> Router Class Initialized
INFO - 2023-08-19 10:37:54 --> Output Class Initialized
INFO - 2023-08-19 10:37:54 --> Security Class Initialized
DEBUG - 2023-08-19 10:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 10:37:54 --> Input Class Initialized
INFO - 2023-08-19 10:37:54 --> Language Class Initialized
INFO - 2023-08-19 10:37:54 --> Loader Class Initialized
INFO - 2023-08-19 10:37:54 --> Helper loaded: url_helper
INFO - 2023-08-19 10:37:54 --> Helper loaded: file_helper
INFO - 2023-08-19 10:37:54 --> Helper loaded: html_helper
INFO - 2023-08-19 10:37:54 --> Helper loaded: text_helper
INFO - 2023-08-19 10:37:54 --> Helper loaded: form_helper
INFO - 2023-08-19 10:37:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 10:37:54 --> Helper loaded: security_helper
INFO - 2023-08-19 10:37:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 10:37:54 --> Database Driver Class Initialized
INFO - 2023-08-19 10:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 10:37:54 --> Parser Class Initialized
INFO - 2023-08-19 10:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 10:37:54 --> Pagination Class Initialized
INFO - 2023-08-19 10:37:54 --> Form Validation Class Initialized
INFO - 2023-08-19 10:37:54 --> Controller Class Initialized
INFO - 2023-08-19 10:37:54 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:54 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:54 --> Model Class Initialized
INFO - 2023-08-19 10:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 10:37:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 10:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 10:37:54 --> Model Class Initialized
INFO - 2023-08-19 10:37:54 --> Model Class Initialized
INFO - 2023-08-19 10:37:54 --> Model Class Initialized
INFO - 2023-08-19 10:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 10:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 10:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 10:37:54 --> Final output sent to browser
DEBUG - 2023-08-19 10:37:54 --> Total execution time: 0.0758
ERROR - 2023-08-19 10:37:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 10:37:55 --> Config Class Initialized
INFO - 2023-08-19 10:37:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 10:37:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 10:37:55 --> Utf8 Class Initialized
INFO - 2023-08-19 10:37:55 --> URI Class Initialized
INFO - 2023-08-19 10:37:55 --> Router Class Initialized
INFO - 2023-08-19 10:37:55 --> Output Class Initialized
INFO - 2023-08-19 10:37:55 --> Security Class Initialized
DEBUG - 2023-08-19 10:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 10:37:55 --> Input Class Initialized
INFO - 2023-08-19 10:37:55 --> Language Class Initialized
INFO - 2023-08-19 10:37:55 --> Loader Class Initialized
INFO - 2023-08-19 10:37:55 --> Helper loaded: url_helper
INFO - 2023-08-19 10:37:55 --> Helper loaded: file_helper
INFO - 2023-08-19 10:37:55 --> Helper loaded: html_helper
INFO - 2023-08-19 10:37:55 --> Helper loaded: text_helper
INFO - 2023-08-19 10:37:55 --> Helper loaded: form_helper
INFO - 2023-08-19 10:37:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 10:37:55 --> Helper loaded: security_helper
INFO - 2023-08-19 10:37:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 10:37:55 --> Database Driver Class Initialized
INFO - 2023-08-19 10:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 10:37:55 --> Parser Class Initialized
INFO - 2023-08-19 10:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 10:37:55 --> Pagination Class Initialized
INFO - 2023-08-19 10:37:55 --> Form Validation Class Initialized
INFO - 2023-08-19 10:37:55 --> Controller Class Initialized
INFO - 2023-08-19 10:37:55 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:55 --> Model Class Initialized
DEBUG - 2023-08-19 10:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:37:55 --> Model Class Initialized
INFO - 2023-08-19 10:37:55 --> Final output sent to browser
DEBUG - 2023-08-19 10:37:55 --> Total execution time: 0.0255
ERROR - 2023-08-19 10:38:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 10:38:08 --> Config Class Initialized
INFO - 2023-08-19 10:38:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 10:38:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 10:38:08 --> Utf8 Class Initialized
INFO - 2023-08-19 10:38:08 --> URI Class Initialized
DEBUG - 2023-08-19 10:38:08 --> No URI present. Default controller set.
INFO - 2023-08-19 10:38:08 --> Router Class Initialized
INFO - 2023-08-19 10:38:08 --> Output Class Initialized
INFO - 2023-08-19 10:38:08 --> Security Class Initialized
DEBUG - 2023-08-19 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 10:38:08 --> Input Class Initialized
INFO - 2023-08-19 10:38:08 --> Language Class Initialized
INFO - 2023-08-19 10:38:08 --> Loader Class Initialized
INFO - 2023-08-19 10:38:08 --> Helper loaded: url_helper
INFO - 2023-08-19 10:38:08 --> Helper loaded: file_helper
INFO - 2023-08-19 10:38:08 --> Helper loaded: html_helper
INFO - 2023-08-19 10:38:08 --> Helper loaded: text_helper
INFO - 2023-08-19 10:38:08 --> Helper loaded: form_helper
INFO - 2023-08-19 10:38:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 10:38:08 --> Helper loaded: security_helper
INFO - 2023-08-19 10:38:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 10:38:08 --> Database Driver Class Initialized
INFO - 2023-08-19 10:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 10:38:08 --> Parser Class Initialized
INFO - 2023-08-19 10:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 10:38:08 --> Pagination Class Initialized
INFO - 2023-08-19 10:38:08 --> Form Validation Class Initialized
INFO - 2023-08-19 10:38:08 --> Controller Class Initialized
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
DEBUG - 2023-08-19 10:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
DEBUG - 2023-08-19 10:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
DEBUG - 2023-08-19 10:38:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 10:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
INFO - 2023-08-19 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 10:38:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 10:38:08 --> Model Class Initialized
INFO - 2023-08-19 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 10:38:08 --> Final output sent to browser
DEBUG - 2023-08-19 10:38:08 --> Total execution time: 0.1028
ERROR - 2023-08-19 14:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:54:45 --> Config Class Initialized
INFO - 2023-08-19 14:54:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:54:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:54:45 --> Utf8 Class Initialized
INFO - 2023-08-19 14:54:45 --> URI Class Initialized
DEBUG - 2023-08-19 14:54:45 --> No URI present. Default controller set.
INFO - 2023-08-19 14:54:45 --> Router Class Initialized
INFO - 2023-08-19 14:54:45 --> Output Class Initialized
INFO - 2023-08-19 14:54:45 --> Security Class Initialized
DEBUG - 2023-08-19 14:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:54:45 --> Input Class Initialized
INFO - 2023-08-19 14:54:45 --> Language Class Initialized
INFO - 2023-08-19 14:54:45 --> Loader Class Initialized
INFO - 2023-08-19 14:54:45 --> Helper loaded: url_helper
INFO - 2023-08-19 14:54:45 --> Helper loaded: file_helper
INFO - 2023-08-19 14:54:45 --> Helper loaded: html_helper
INFO - 2023-08-19 14:54:45 --> Helper loaded: text_helper
INFO - 2023-08-19 14:54:45 --> Helper loaded: form_helper
INFO - 2023-08-19 14:54:45 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:54:45 --> Helper loaded: security_helper
INFO - 2023-08-19 14:54:45 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:54:45 --> Database Driver Class Initialized
INFO - 2023-08-19 14:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:54:45 --> Parser Class Initialized
INFO - 2023-08-19 14:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:54:45 --> Pagination Class Initialized
INFO - 2023-08-19 14:54:45 --> Form Validation Class Initialized
INFO - 2023-08-19 14:54:45 --> Controller Class Initialized
INFO - 2023-08-19 14:54:45 --> Model Class Initialized
DEBUG - 2023-08-19 14:54:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 14:54:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:54:46 --> Config Class Initialized
INFO - 2023-08-19 14:54:46 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:54:46 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:54:46 --> Utf8 Class Initialized
INFO - 2023-08-19 14:54:46 --> URI Class Initialized
INFO - 2023-08-19 14:54:46 --> Router Class Initialized
INFO - 2023-08-19 14:54:46 --> Output Class Initialized
INFO - 2023-08-19 14:54:46 --> Security Class Initialized
DEBUG - 2023-08-19 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:54:46 --> Input Class Initialized
INFO - 2023-08-19 14:54:46 --> Language Class Initialized
INFO - 2023-08-19 14:54:46 --> Loader Class Initialized
INFO - 2023-08-19 14:54:46 --> Helper loaded: url_helper
INFO - 2023-08-19 14:54:46 --> Helper loaded: file_helper
INFO - 2023-08-19 14:54:46 --> Helper loaded: html_helper
INFO - 2023-08-19 14:54:46 --> Helper loaded: text_helper
INFO - 2023-08-19 14:54:46 --> Helper loaded: form_helper
INFO - 2023-08-19 14:54:46 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:54:46 --> Helper loaded: security_helper
INFO - 2023-08-19 14:54:46 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:54:46 --> Database Driver Class Initialized
INFO - 2023-08-19 14:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:54:46 --> Parser Class Initialized
INFO - 2023-08-19 14:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:54:46 --> Pagination Class Initialized
INFO - 2023-08-19 14:54:46 --> Form Validation Class Initialized
INFO - 2023-08-19 14:54:46 --> Controller Class Initialized
INFO - 2023-08-19 14:54:46 --> Model Class Initialized
DEBUG - 2023-08-19 14:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 14:54:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:54:46 --> Model Class Initialized
INFO - 2023-08-19 14:54:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:54:46 --> Final output sent to browser
DEBUG - 2023-08-19 14:54:46 --> Total execution time: 0.0307
ERROR - 2023-08-19 14:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:54:49 --> Config Class Initialized
INFO - 2023-08-19 14:54:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:54:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:54:49 --> Utf8 Class Initialized
INFO - 2023-08-19 14:54:49 --> URI Class Initialized
INFO - 2023-08-19 14:54:49 --> Router Class Initialized
INFO - 2023-08-19 14:54:49 --> Output Class Initialized
INFO - 2023-08-19 14:54:49 --> Security Class Initialized
DEBUG - 2023-08-19 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:54:49 --> Input Class Initialized
INFO - 2023-08-19 14:54:49 --> Language Class Initialized
INFO - 2023-08-19 14:54:49 --> Loader Class Initialized
INFO - 2023-08-19 14:54:49 --> Helper loaded: url_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: file_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: html_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: text_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: form_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: security_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:54:49 --> Database Driver Class Initialized
INFO - 2023-08-19 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:54:49 --> Parser Class Initialized
INFO - 2023-08-19 14:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:54:49 --> Pagination Class Initialized
INFO - 2023-08-19 14:54:49 --> Form Validation Class Initialized
INFO - 2023-08-19 14:54:49 --> Controller Class Initialized
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
DEBUG - 2023-08-19 14:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
INFO - 2023-08-19 14:54:49 --> Final output sent to browser
DEBUG - 2023-08-19 14:54:49 --> Total execution time: 0.0189
ERROR - 2023-08-19 14:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:54:49 --> Config Class Initialized
INFO - 2023-08-19 14:54:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:54:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:54:49 --> Utf8 Class Initialized
INFO - 2023-08-19 14:54:49 --> URI Class Initialized
DEBUG - 2023-08-19 14:54:49 --> No URI present. Default controller set.
INFO - 2023-08-19 14:54:49 --> Router Class Initialized
INFO - 2023-08-19 14:54:49 --> Output Class Initialized
INFO - 2023-08-19 14:54:49 --> Security Class Initialized
DEBUG - 2023-08-19 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:54:49 --> Input Class Initialized
INFO - 2023-08-19 14:54:49 --> Language Class Initialized
INFO - 2023-08-19 14:54:49 --> Loader Class Initialized
INFO - 2023-08-19 14:54:49 --> Helper loaded: url_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: file_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: html_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: text_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: form_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: security_helper
INFO - 2023-08-19 14:54:49 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:54:49 --> Database Driver Class Initialized
INFO - 2023-08-19 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:54:49 --> Parser Class Initialized
INFO - 2023-08-19 14:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:54:49 --> Pagination Class Initialized
INFO - 2023-08-19 14:54:49 --> Form Validation Class Initialized
INFO - 2023-08-19 14:54:49 --> Controller Class Initialized
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
DEBUG - 2023-08-19 14:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
DEBUG - 2023-08-19 14:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
DEBUG - 2023-08-19 14:54:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
INFO - 2023-08-19 14:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 14:54:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:54:49 --> Model Class Initialized
INFO - 2023-08-19 14:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:54:49 --> Final output sent to browser
DEBUG - 2023-08-19 14:54:49 --> Total execution time: 0.1797
ERROR - 2023-08-19 14:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:54:50 --> Config Class Initialized
INFO - 2023-08-19 14:54:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:54:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:54:50 --> Utf8 Class Initialized
INFO - 2023-08-19 14:54:50 --> URI Class Initialized
INFO - 2023-08-19 14:54:50 --> Router Class Initialized
INFO - 2023-08-19 14:54:50 --> Output Class Initialized
INFO - 2023-08-19 14:54:50 --> Security Class Initialized
DEBUG - 2023-08-19 14:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:54:50 --> Input Class Initialized
INFO - 2023-08-19 14:54:50 --> Language Class Initialized
INFO - 2023-08-19 14:54:50 --> Loader Class Initialized
INFO - 2023-08-19 14:54:50 --> Helper loaded: url_helper
INFO - 2023-08-19 14:54:50 --> Helper loaded: file_helper
INFO - 2023-08-19 14:54:50 --> Helper loaded: html_helper
INFO - 2023-08-19 14:54:50 --> Helper loaded: text_helper
INFO - 2023-08-19 14:54:50 --> Helper loaded: form_helper
INFO - 2023-08-19 14:54:50 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:54:50 --> Helper loaded: security_helper
INFO - 2023-08-19 14:54:50 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:54:50 --> Database Driver Class Initialized
INFO - 2023-08-19 14:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:54:50 --> Parser Class Initialized
INFO - 2023-08-19 14:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:54:50 --> Pagination Class Initialized
INFO - 2023-08-19 14:54:50 --> Form Validation Class Initialized
INFO - 2023-08-19 14:54:50 --> Controller Class Initialized
DEBUG - 2023-08-19 14:54:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:54:50 --> Model Class Initialized
INFO - 2023-08-19 14:54:50 --> Final output sent to browser
DEBUG - 2023-08-19 14:54:50 --> Total execution time: 0.0137
ERROR - 2023-08-19 14:55:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:11 --> Config Class Initialized
INFO - 2023-08-19 14:55:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:11 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:11 --> URI Class Initialized
INFO - 2023-08-19 14:55:11 --> Router Class Initialized
INFO - 2023-08-19 14:55:11 --> Output Class Initialized
INFO - 2023-08-19 14:55:11 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:11 --> Input Class Initialized
INFO - 2023-08-19 14:55:11 --> Language Class Initialized
INFO - 2023-08-19 14:55:11 --> Loader Class Initialized
INFO - 2023-08-19 14:55:11 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:11 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:11 --> Parser Class Initialized
INFO - 2023-08-19 14:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:11 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:11 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:11 --> Controller Class Initialized
ERROR - 2023-08-19 14:55:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:11 --> Config Class Initialized
INFO - 2023-08-19 14:55:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:11 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:11 --> URI Class Initialized
INFO - 2023-08-19 14:55:11 --> Router Class Initialized
INFO - 2023-08-19 14:55:11 --> Output Class Initialized
INFO - 2023-08-19 14:55:11 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:11 --> Input Class Initialized
INFO - 2023-08-19 14:55:11 --> Language Class Initialized
INFO - 2023-08-19 14:55:11 --> Loader Class Initialized
INFO - 2023-08-19 14:55:11 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:11 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:11 --> Parser Class Initialized
INFO - 2023-08-19 14:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:11 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:11 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:11 --> Controller Class Initialized
INFO - 2023-08-19 14:55:11 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 14:55:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:55:11 --> Model Class Initialized
INFO - 2023-08-19 14:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:55:11 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:11 --> Total execution time: 0.0307
ERROR - 2023-08-19 14:55:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:19 --> Config Class Initialized
INFO - 2023-08-19 14:55:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:19 --> URI Class Initialized
INFO - 2023-08-19 14:55:19 --> Router Class Initialized
INFO - 2023-08-19 14:55:19 --> Output Class Initialized
INFO - 2023-08-19 14:55:19 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:19 --> Input Class Initialized
INFO - 2023-08-19 14:55:19 --> Language Class Initialized
INFO - 2023-08-19 14:55:19 --> Loader Class Initialized
INFO - 2023-08-19 14:55:19 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:19 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:19 --> Parser Class Initialized
INFO - 2023-08-19 14:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:19 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:19 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:19 --> Controller Class Initialized
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
INFO - 2023-08-19 14:55:19 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:19 --> Total execution time: 0.0183
ERROR - 2023-08-19 14:55:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:19 --> Config Class Initialized
INFO - 2023-08-19 14:55:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:19 --> URI Class Initialized
DEBUG - 2023-08-19 14:55:19 --> No URI present. Default controller set.
INFO - 2023-08-19 14:55:19 --> Router Class Initialized
INFO - 2023-08-19 14:55:19 --> Output Class Initialized
INFO - 2023-08-19 14:55:19 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:19 --> Input Class Initialized
INFO - 2023-08-19 14:55:19 --> Language Class Initialized
INFO - 2023-08-19 14:55:19 --> Loader Class Initialized
INFO - 2023-08-19 14:55:19 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:19 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:19 --> Parser Class Initialized
INFO - 2023-08-19 14:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:19 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:19 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:19 --> Controller Class Initialized
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
INFO - 2023-08-19 14:55:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 14:55:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:55:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:55:19 --> Model Class Initialized
INFO - 2023-08-19 14:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:55:20 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:20 --> Total execution time: 0.0916
ERROR - 2023-08-19 14:55:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:29 --> Config Class Initialized
INFO - 2023-08-19 14:55:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:29 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:29 --> URI Class Initialized
INFO - 2023-08-19 14:55:29 --> Router Class Initialized
INFO - 2023-08-19 14:55:29 --> Output Class Initialized
INFO - 2023-08-19 14:55:29 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:29 --> Input Class Initialized
INFO - 2023-08-19 14:55:29 --> Language Class Initialized
INFO - 2023-08-19 14:55:29 --> Loader Class Initialized
INFO - 2023-08-19 14:55:29 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:29 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:29 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:29 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:29 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:29 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:29 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:29 --> Parser Class Initialized
INFO - 2023-08-19 14:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:29 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:29 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:29 --> Controller Class Initialized
INFO - 2023-08-19 14:55:29 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:29 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-08-19 14:55:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:55:29 --> Model Class Initialized
INFO - 2023-08-19 14:55:29 --> Model Class Initialized
INFO - 2023-08-19 14:55:29 --> Model Class Initialized
INFO - 2023-08-19 14:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:55:29 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:29 --> Total execution time: 0.1514
ERROR - 2023-08-19 14:55:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:38 --> Config Class Initialized
INFO - 2023-08-19 14:55:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:38 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:38 --> URI Class Initialized
INFO - 2023-08-19 14:55:38 --> Router Class Initialized
INFO - 2023-08-19 14:55:38 --> Output Class Initialized
INFO - 2023-08-19 14:55:38 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:38 --> Input Class Initialized
INFO - 2023-08-19 14:55:38 --> Language Class Initialized
INFO - 2023-08-19 14:55:38 --> Loader Class Initialized
INFO - 2023-08-19 14:55:38 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:38 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:38 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:38 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:38 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:38 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:38 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:38 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:38 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:38 --> Parser Class Initialized
INFO - 2023-08-19 14:55:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:38 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:38 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:38 --> Controller Class Initialized
INFO - 2023-08-19 14:55:38 --> Model Class Initialized
INFO - 2023-08-19 14:55:38 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:38 --> Total execution time: 0.0146
ERROR - 2023-08-19 14:55:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:43 --> Config Class Initialized
INFO - 2023-08-19 14:55:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:43 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:43 --> URI Class Initialized
INFO - 2023-08-19 14:55:43 --> Router Class Initialized
INFO - 2023-08-19 14:55:43 --> Output Class Initialized
INFO - 2023-08-19 14:55:43 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:43 --> Input Class Initialized
INFO - 2023-08-19 14:55:43 --> Language Class Initialized
INFO - 2023-08-19 14:55:43 --> Loader Class Initialized
INFO - 2023-08-19 14:55:43 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:43 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:43 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:43 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:43 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:43 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:43 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:43 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:43 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:43 --> Parser Class Initialized
INFO - 2023-08-19 14:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:43 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:43 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:43 --> Controller Class Initialized
INFO - 2023-08-19 14:55:43 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:43 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:43 --> Model Class Initialized
INFO - 2023-08-19 14:55:43 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:43 --> Total execution time: 0.0194
ERROR - 2023-08-19 14:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:44 --> Config Class Initialized
INFO - 2023-08-19 14:55:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:44 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:44 --> URI Class Initialized
INFO - 2023-08-19 14:55:44 --> Router Class Initialized
INFO - 2023-08-19 14:55:44 --> Output Class Initialized
INFO - 2023-08-19 14:55:44 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:44 --> Input Class Initialized
INFO - 2023-08-19 14:55:44 --> Language Class Initialized
INFO - 2023-08-19 14:55:44 --> Loader Class Initialized
INFO - 2023-08-19 14:55:44 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:44 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:44 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:44 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:44 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:44 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:44 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:44 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:44 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:44 --> Parser Class Initialized
INFO - 2023-08-19 14:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:44 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:44 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:44 --> Controller Class Initialized
INFO - 2023-08-19 14:55:44 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:44 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:44 --> Model Class Initialized
INFO - 2023-08-19 14:55:44 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:44 --> Total execution time: 0.0206
ERROR - 2023-08-19 14:55:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:52 --> Config Class Initialized
INFO - 2023-08-19 14:55:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:52 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:52 --> URI Class Initialized
INFO - 2023-08-19 14:55:52 --> Router Class Initialized
INFO - 2023-08-19 14:55:52 --> Output Class Initialized
INFO - 2023-08-19 14:55:52 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:52 --> Input Class Initialized
INFO - 2023-08-19 14:55:52 --> Language Class Initialized
INFO - 2023-08-19 14:55:52 --> Loader Class Initialized
INFO - 2023-08-19 14:55:52 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:52 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:52 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:52 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:52 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:52 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:52 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:52 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:52 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:52 --> Parser Class Initialized
INFO - 2023-08-19 14:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:52 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:52 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:52 --> Controller Class Initialized
INFO - 2023-08-19 14:55:52 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:52 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:52 --> Model Class Initialized
INFO - 2023-08-19 14:55:52 --> Model Class Initialized
INFO - 2023-08-19 14:55:52 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:52 --> Total execution time: 0.0256
ERROR - 2023-08-19 14:55:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:55:54 --> Config Class Initialized
INFO - 2023-08-19 14:55:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:55:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:55:54 --> Utf8 Class Initialized
INFO - 2023-08-19 14:55:54 --> URI Class Initialized
INFO - 2023-08-19 14:55:54 --> Router Class Initialized
INFO - 2023-08-19 14:55:54 --> Output Class Initialized
INFO - 2023-08-19 14:55:54 --> Security Class Initialized
DEBUG - 2023-08-19 14:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:55:54 --> Input Class Initialized
INFO - 2023-08-19 14:55:54 --> Language Class Initialized
INFO - 2023-08-19 14:55:54 --> Loader Class Initialized
INFO - 2023-08-19 14:55:54 --> Helper loaded: url_helper
INFO - 2023-08-19 14:55:54 --> Helper loaded: file_helper
INFO - 2023-08-19 14:55:54 --> Helper loaded: html_helper
INFO - 2023-08-19 14:55:54 --> Helper loaded: text_helper
INFO - 2023-08-19 14:55:54 --> Helper loaded: form_helper
INFO - 2023-08-19 14:55:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:55:54 --> Helper loaded: security_helper
INFO - 2023-08-19 14:55:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:55:54 --> Database Driver Class Initialized
INFO - 2023-08-19 14:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:55:54 --> Parser Class Initialized
INFO - 2023-08-19 14:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:55:54 --> Pagination Class Initialized
INFO - 2023-08-19 14:55:54 --> Form Validation Class Initialized
INFO - 2023-08-19 14:55:54 --> Controller Class Initialized
INFO - 2023-08-19 14:55:54 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:54 --> Model Class Initialized
DEBUG - 2023-08-19 14:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:55:54 --> Model Class Initialized
INFO - 2023-08-19 14:55:54 --> Final output sent to browser
DEBUG - 2023-08-19 14:55:54 --> Total execution time: 0.0210
ERROR - 2023-08-19 14:56:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:07 --> Config Class Initialized
INFO - 2023-08-19 14:56:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:07 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:07 --> URI Class Initialized
INFO - 2023-08-19 14:56:07 --> Router Class Initialized
INFO - 2023-08-19 14:56:07 --> Output Class Initialized
INFO - 2023-08-19 14:56:07 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:07 --> Input Class Initialized
INFO - 2023-08-19 14:56:07 --> Language Class Initialized
INFO - 2023-08-19 14:56:07 --> Loader Class Initialized
INFO - 2023-08-19 14:56:07 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:07 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:07 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:07 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:07 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:07 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:07 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:07 --> Parser Class Initialized
INFO - 2023-08-19 14:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:07 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:07 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:07 --> Controller Class Initialized
INFO - 2023-08-19 14:56:07 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:07 --> Model Class Initialized
INFO - 2023-08-19 14:56:07 --> Email Class Initialized
INFO - 2023-08-19 14:56:07 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-08-19 14:56:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:08 --> Config Class Initialized
INFO - 2023-08-19 14:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:08 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:08 --> URI Class Initialized
INFO - 2023-08-19 14:56:08 --> Router Class Initialized
INFO - 2023-08-19 14:56:08 --> Output Class Initialized
INFO - 2023-08-19 14:56:08 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:08 --> Input Class Initialized
INFO - 2023-08-19 14:56:08 --> Language Class Initialized
INFO - 2023-08-19 14:56:08 --> Loader Class Initialized
INFO - 2023-08-19 14:56:08 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:08 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:08 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:08 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:08 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:08 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:08 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:08 --> Parser Class Initialized
INFO - 2023-08-19 14:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:08 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:08 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:08 --> Controller Class Initialized
INFO - 2023-08-19 14:56:08 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:08 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-08-19 14:56:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:56:08 --> Model Class Initialized
INFO - 2023-08-19 14:56:08 --> Model Class Initialized
INFO - 2023-08-19 14:56:08 --> Model Class Initialized
INFO - 2023-08-19 14:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:56:08 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:08 --> Total execution time: 0.1329
ERROR - 2023-08-19 14:56:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:12 --> Config Class Initialized
INFO - 2023-08-19 14:56:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:12 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:12 --> URI Class Initialized
INFO - 2023-08-19 14:56:12 --> Router Class Initialized
INFO - 2023-08-19 14:56:12 --> Output Class Initialized
INFO - 2023-08-19 14:56:12 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:12 --> Input Class Initialized
INFO - 2023-08-19 14:56:12 --> Language Class Initialized
INFO - 2023-08-19 14:56:12 --> Loader Class Initialized
INFO - 2023-08-19 14:56:12 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:12 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:12 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:12 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:12 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:12 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:12 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:12 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:12 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:12 --> Parser Class Initialized
INFO - 2023-08-19 14:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:12 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:12 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:12 --> Controller Class Initialized
INFO - 2023-08-19 14:56:12 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:12 --> Model Class Initialized
INFO - 2023-08-19 14:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-19 14:56:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:56:12 --> Model Class Initialized
INFO - 2023-08-19 14:56:12 --> Model Class Initialized
INFO - 2023-08-19 14:56:12 --> Model Class Initialized
INFO - 2023-08-19 14:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:56:12 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:12 --> Total execution time: 0.0686
ERROR - 2023-08-19 14:56:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:13 --> Config Class Initialized
INFO - 2023-08-19 14:56:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:13 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:13 --> URI Class Initialized
INFO - 2023-08-19 14:56:13 --> Router Class Initialized
INFO - 2023-08-19 14:56:13 --> Output Class Initialized
INFO - 2023-08-19 14:56:13 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:13 --> Input Class Initialized
INFO - 2023-08-19 14:56:13 --> Language Class Initialized
INFO - 2023-08-19 14:56:13 --> Loader Class Initialized
INFO - 2023-08-19 14:56:13 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:13 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:13 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:13 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:13 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:13 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:13 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:13 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:13 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:13 --> Parser Class Initialized
INFO - 2023-08-19 14:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:13 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:13 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:13 --> Controller Class Initialized
INFO - 2023-08-19 14:56:13 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:13 --> Model Class Initialized
INFO - 2023-08-19 14:56:13 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:13 --> Total execution time: 0.0252
ERROR - 2023-08-19 14:56:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:16 --> Config Class Initialized
INFO - 2023-08-19 14:56:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:16 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:16 --> URI Class Initialized
INFO - 2023-08-19 14:56:16 --> Router Class Initialized
INFO - 2023-08-19 14:56:16 --> Output Class Initialized
INFO - 2023-08-19 14:56:16 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:16 --> Input Class Initialized
INFO - 2023-08-19 14:56:16 --> Language Class Initialized
INFO - 2023-08-19 14:56:16 --> Loader Class Initialized
INFO - 2023-08-19 14:56:16 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:16 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:16 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:16 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:16 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:16 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:16 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:16 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:16 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:16 --> Parser Class Initialized
INFO - 2023-08-19 14:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:16 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:16 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:16 --> Controller Class Initialized
INFO - 2023-08-19 14:56:16 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:16 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-08-19 14:56:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:56:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:56:16 --> Model Class Initialized
INFO - 2023-08-19 14:56:16 --> Model Class Initialized
INFO - 2023-08-19 14:56:16 --> Model Class Initialized
INFO - 2023-08-19 14:56:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:56:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:56:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:56:16 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:16 --> Total execution time: 0.0742
ERROR - 2023-08-19 14:56:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:29 --> Config Class Initialized
INFO - 2023-08-19 14:56:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:29 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:29 --> URI Class Initialized
INFO - 2023-08-19 14:56:29 --> Router Class Initialized
INFO - 2023-08-19 14:56:29 --> Output Class Initialized
INFO - 2023-08-19 14:56:29 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:29 --> Input Class Initialized
INFO - 2023-08-19 14:56:29 --> Language Class Initialized
INFO - 2023-08-19 14:56:29 --> Loader Class Initialized
INFO - 2023-08-19 14:56:29 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:29 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:29 --> Parser Class Initialized
INFO - 2023-08-19 14:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:29 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:29 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:29 --> Controller Class Initialized
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
INFO - 2023-08-19 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 14:56:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
INFO - 2023-08-19 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:56:29 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:29 --> Total execution time: 0.0858
ERROR - 2023-08-19 14:56:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:29 --> Config Class Initialized
INFO - 2023-08-19 14:56:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:29 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:29 --> URI Class Initialized
INFO - 2023-08-19 14:56:29 --> Router Class Initialized
INFO - 2023-08-19 14:56:29 --> Output Class Initialized
INFO - 2023-08-19 14:56:29 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:29 --> Input Class Initialized
INFO - 2023-08-19 14:56:29 --> Language Class Initialized
INFO - 2023-08-19 14:56:29 --> Loader Class Initialized
INFO - 2023-08-19 14:56:29 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:29 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:29 --> Parser Class Initialized
INFO - 2023-08-19 14:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:29 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:29 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:29 --> Controller Class Initialized
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:29 --> Model Class Initialized
INFO - 2023-08-19 14:56:29 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:29 --> Total execution time: 0.0383
ERROR - 2023-08-19 14:56:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:56:34 --> Config Class Initialized
INFO - 2023-08-19 14:56:34 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:56:34 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:56:34 --> Utf8 Class Initialized
INFO - 2023-08-19 14:56:34 --> URI Class Initialized
INFO - 2023-08-19 14:56:34 --> Router Class Initialized
INFO - 2023-08-19 14:56:34 --> Output Class Initialized
INFO - 2023-08-19 14:56:34 --> Security Class Initialized
DEBUG - 2023-08-19 14:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:56:34 --> Input Class Initialized
INFO - 2023-08-19 14:56:34 --> Language Class Initialized
INFO - 2023-08-19 14:56:34 --> Loader Class Initialized
INFO - 2023-08-19 14:56:34 --> Helper loaded: url_helper
INFO - 2023-08-19 14:56:34 --> Helper loaded: file_helper
INFO - 2023-08-19 14:56:34 --> Helper loaded: html_helper
INFO - 2023-08-19 14:56:34 --> Helper loaded: text_helper
INFO - 2023-08-19 14:56:34 --> Helper loaded: form_helper
INFO - 2023-08-19 14:56:34 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:56:34 --> Helper loaded: security_helper
INFO - 2023-08-19 14:56:34 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:56:34 --> Database Driver Class Initialized
INFO - 2023-08-19 14:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:56:34 --> Parser Class Initialized
INFO - 2023-08-19 14:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:56:34 --> Pagination Class Initialized
INFO - 2023-08-19 14:56:34 --> Form Validation Class Initialized
INFO - 2023-08-19 14:56:34 --> Controller Class Initialized
INFO - 2023-08-19 14:56:34 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:34 --> Model Class Initialized
DEBUG - 2023-08-19 14:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:56:34 --> Model Class Initialized
INFO - 2023-08-19 14:56:34 --> Final output sent to browser
DEBUG - 2023-08-19 14:56:34 --> Total execution time: 0.1179
ERROR - 2023-08-19 14:57:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:57:08 --> Config Class Initialized
INFO - 2023-08-19 14:57:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:57:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:57:08 --> Utf8 Class Initialized
INFO - 2023-08-19 14:57:08 --> URI Class Initialized
INFO - 2023-08-19 14:57:08 --> Router Class Initialized
INFO - 2023-08-19 14:57:08 --> Output Class Initialized
INFO - 2023-08-19 14:57:08 --> Security Class Initialized
DEBUG - 2023-08-19 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:57:08 --> Input Class Initialized
INFO - 2023-08-19 14:57:08 --> Language Class Initialized
INFO - 2023-08-19 14:57:08 --> Loader Class Initialized
INFO - 2023-08-19 14:57:08 --> Helper loaded: url_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: file_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: html_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: text_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: form_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: security_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:57:08 --> Database Driver Class Initialized
INFO - 2023-08-19 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:57:08 --> Parser Class Initialized
INFO - 2023-08-19 14:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:57:08 --> Pagination Class Initialized
INFO - 2023-08-19 14:57:08 --> Form Validation Class Initialized
INFO - 2023-08-19 14:57:08 --> Controller Class Initialized
INFO - 2023-08-19 14:57:08 --> Model Class Initialized
DEBUG - 2023-08-19 14:57:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:57:08 --> Model Class Initialized
INFO - 2023-08-19 14:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-08-19 14:57:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:57:08 --> Model Class Initialized
INFO - 2023-08-19 14:57:08 --> Model Class Initialized
INFO - 2023-08-19 14:57:08 --> Model Class Initialized
INFO - 2023-08-19 14:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:57:08 --> Final output sent to browser
DEBUG - 2023-08-19 14:57:08 --> Total execution time: 0.0672
ERROR - 2023-08-19 14:57:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:57:08 --> Config Class Initialized
INFO - 2023-08-19 14:57:08 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:57:08 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:57:08 --> Utf8 Class Initialized
INFO - 2023-08-19 14:57:08 --> URI Class Initialized
INFO - 2023-08-19 14:57:08 --> Router Class Initialized
INFO - 2023-08-19 14:57:08 --> Output Class Initialized
INFO - 2023-08-19 14:57:08 --> Security Class Initialized
DEBUG - 2023-08-19 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:57:08 --> Input Class Initialized
INFO - 2023-08-19 14:57:08 --> Language Class Initialized
INFO - 2023-08-19 14:57:08 --> Loader Class Initialized
INFO - 2023-08-19 14:57:08 --> Helper loaded: url_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: file_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: html_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: text_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: form_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: security_helper
INFO - 2023-08-19 14:57:08 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:57:08 --> Database Driver Class Initialized
INFO - 2023-08-19 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:57:08 --> Parser Class Initialized
INFO - 2023-08-19 14:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:57:08 --> Pagination Class Initialized
INFO - 2023-08-19 14:57:08 --> Form Validation Class Initialized
INFO - 2023-08-19 14:57:08 --> Controller Class Initialized
INFO - 2023-08-19 14:57:08 --> Model Class Initialized
DEBUG - 2023-08-19 14:57:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:57:08 --> Model Class Initialized
INFO - 2023-08-19 14:57:08 --> Final output sent to browser
DEBUG - 2023-08-19 14:57:08 --> Total execution time: 0.0276
ERROR - 2023-08-19 14:57:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:57:11 --> Config Class Initialized
INFO - 2023-08-19 14:57:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:57:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:57:11 --> Utf8 Class Initialized
INFO - 2023-08-19 14:57:11 --> URI Class Initialized
INFO - 2023-08-19 14:57:11 --> Router Class Initialized
INFO - 2023-08-19 14:57:11 --> Output Class Initialized
INFO - 2023-08-19 14:57:11 --> Security Class Initialized
DEBUG - 2023-08-19 14:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:57:11 --> Input Class Initialized
INFO - 2023-08-19 14:57:11 --> Language Class Initialized
INFO - 2023-08-19 14:57:11 --> Loader Class Initialized
INFO - 2023-08-19 14:57:11 --> Helper loaded: url_helper
INFO - 2023-08-19 14:57:11 --> Helper loaded: file_helper
INFO - 2023-08-19 14:57:11 --> Helper loaded: html_helper
INFO - 2023-08-19 14:57:11 --> Helper loaded: text_helper
INFO - 2023-08-19 14:57:11 --> Helper loaded: form_helper
INFO - 2023-08-19 14:57:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:57:11 --> Helper loaded: security_helper
INFO - 2023-08-19 14:57:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:57:11 --> Database Driver Class Initialized
INFO - 2023-08-19 14:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:57:11 --> Parser Class Initialized
INFO - 2023-08-19 14:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:57:11 --> Pagination Class Initialized
INFO - 2023-08-19 14:57:11 --> Form Validation Class Initialized
INFO - 2023-08-19 14:57:11 --> Controller Class Initialized
INFO - 2023-08-19 14:57:11 --> Model Class Initialized
DEBUG - 2023-08-19 14:57:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:57:11 --> Model Class Initialized
INFO - 2023-08-19 14:57:11 --> Final output sent to browser
DEBUG - 2023-08-19 14:57:11 --> Total execution time: 0.0267
ERROR - 2023-08-19 14:57:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:57:19 --> Config Class Initialized
INFO - 2023-08-19 14:57:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:57:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:57:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:57:19 --> URI Class Initialized
INFO - 2023-08-19 14:57:19 --> Router Class Initialized
INFO - 2023-08-19 14:57:19 --> Output Class Initialized
INFO - 2023-08-19 14:57:19 --> Security Class Initialized
DEBUG - 2023-08-19 14:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:57:19 --> Input Class Initialized
INFO - 2023-08-19 14:57:19 --> Language Class Initialized
INFO - 2023-08-19 14:57:19 --> Loader Class Initialized
INFO - 2023-08-19 14:57:19 --> Helper loaded: url_helper
INFO - 2023-08-19 14:57:19 --> Helper loaded: file_helper
INFO - 2023-08-19 14:57:19 --> Helper loaded: html_helper
INFO - 2023-08-19 14:57:19 --> Helper loaded: text_helper
INFO - 2023-08-19 14:57:19 --> Helper loaded: form_helper
INFO - 2023-08-19 14:57:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:57:19 --> Helper loaded: security_helper
INFO - 2023-08-19 14:57:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:57:19 --> Database Driver Class Initialized
INFO - 2023-08-19 14:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:57:19 --> Parser Class Initialized
INFO - 2023-08-19 14:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:57:19 --> Pagination Class Initialized
INFO - 2023-08-19 14:57:19 --> Form Validation Class Initialized
INFO - 2023-08-19 14:57:19 --> Controller Class Initialized
INFO - 2023-08-19 14:57:19 --> Model Class Initialized
INFO - 2023-08-19 14:57:19 --> Model Class Initialized
INFO - 2023-08-19 14:57:19 --> Model Class Initialized
INFO - 2023-08-19 14:57:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-08-19 14:57:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:57:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:57:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:57:19 --> Model Class Initialized
INFO - 2023-08-19 14:57:19 --> Model Class Initialized
INFO - 2023-08-19 14:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:57:20 --> Final output sent to browser
DEBUG - 2023-08-19 14:57:20 --> Total execution time: 0.1358
ERROR - 2023-08-19 14:57:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:57:20 --> Config Class Initialized
INFO - 2023-08-19 14:57:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:57:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:57:20 --> Utf8 Class Initialized
INFO - 2023-08-19 14:57:20 --> URI Class Initialized
INFO - 2023-08-19 14:57:20 --> Router Class Initialized
INFO - 2023-08-19 14:57:20 --> Output Class Initialized
INFO - 2023-08-19 14:57:20 --> Security Class Initialized
DEBUG - 2023-08-19 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:57:20 --> Input Class Initialized
INFO - 2023-08-19 14:57:20 --> Language Class Initialized
INFO - 2023-08-19 14:57:20 --> Loader Class Initialized
INFO - 2023-08-19 14:57:20 --> Helper loaded: url_helper
INFO - 2023-08-19 14:57:20 --> Helper loaded: file_helper
INFO - 2023-08-19 14:57:20 --> Helper loaded: html_helper
INFO - 2023-08-19 14:57:20 --> Helper loaded: text_helper
INFO - 2023-08-19 14:57:20 --> Helper loaded: form_helper
INFO - 2023-08-19 14:57:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:57:20 --> Helper loaded: security_helper
INFO - 2023-08-19 14:57:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:57:20 --> Database Driver Class Initialized
INFO - 2023-08-19 14:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:57:20 --> Parser Class Initialized
INFO - 2023-08-19 14:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:57:20 --> Pagination Class Initialized
INFO - 2023-08-19 14:57:20 --> Form Validation Class Initialized
INFO - 2023-08-19 14:57:20 --> Controller Class Initialized
INFO - 2023-08-19 14:57:20 --> Model Class Initialized
INFO - 2023-08-19 14:57:21 --> Model Class Initialized
INFO - 2023-08-19 14:57:21 --> Final output sent to browser
DEBUG - 2023-08-19 14:57:21 --> Total execution time: 0.0275
ERROR - 2023-08-19 14:57:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:57:22 --> Config Class Initialized
INFO - 2023-08-19 14:57:22 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:57:22 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:57:22 --> Utf8 Class Initialized
INFO - 2023-08-19 14:57:22 --> URI Class Initialized
INFO - 2023-08-19 14:57:22 --> Router Class Initialized
INFO - 2023-08-19 14:57:22 --> Output Class Initialized
INFO - 2023-08-19 14:57:22 --> Security Class Initialized
DEBUG - 2023-08-19 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:57:22 --> Input Class Initialized
INFO - 2023-08-19 14:57:22 --> Language Class Initialized
INFO - 2023-08-19 14:57:22 --> Loader Class Initialized
INFO - 2023-08-19 14:57:22 --> Helper loaded: url_helper
INFO - 2023-08-19 14:57:22 --> Helper loaded: file_helper
INFO - 2023-08-19 14:57:22 --> Helper loaded: html_helper
INFO - 2023-08-19 14:57:22 --> Helper loaded: text_helper
INFO - 2023-08-19 14:57:22 --> Helper loaded: form_helper
INFO - 2023-08-19 14:57:22 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:57:22 --> Helper loaded: security_helper
INFO - 2023-08-19 14:57:22 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:57:22 --> Database Driver Class Initialized
INFO - 2023-08-19 14:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:57:22 --> Parser Class Initialized
INFO - 2023-08-19 14:57:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:57:22 --> Pagination Class Initialized
INFO - 2023-08-19 14:57:22 --> Form Validation Class Initialized
INFO - 2023-08-19 14:57:22 --> Controller Class Initialized
DEBUG - 2023-08-19 14:57:22 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:57:22 --> Model Class Initialized
INFO - 2023-08-19 14:57:22 --> Model Class Initialized
INFO - 2023-08-19 14:57:22 --> Model Class Initialized
INFO - 2023-08-19 14:57:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-08-19 14:57:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:57:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:57:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:57:22 --> Model Class Initialized
INFO - 2023-08-19 14:57:22 --> Model Class Initialized
INFO - 2023-08-19 14:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:57:23 --> Final output sent to browser
DEBUG - 2023-08-19 14:57:23 --> Total execution time: 0.1844
ERROR - 2023-08-19 14:58:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:58:58 --> Config Class Initialized
INFO - 2023-08-19 14:58:58 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:58:58 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:58:58 --> Utf8 Class Initialized
INFO - 2023-08-19 14:58:58 --> URI Class Initialized
INFO - 2023-08-19 14:58:58 --> Router Class Initialized
INFO - 2023-08-19 14:58:58 --> Output Class Initialized
INFO - 2023-08-19 14:58:58 --> Security Class Initialized
DEBUG - 2023-08-19 14:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:58:58 --> Input Class Initialized
INFO - 2023-08-19 14:58:58 --> Language Class Initialized
INFO - 2023-08-19 14:58:58 --> Loader Class Initialized
INFO - 2023-08-19 14:58:58 --> Helper loaded: url_helper
INFO - 2023-08-19 14:58:58 --> Helper loaded: file_helper
INFO - 2023-08-19 14:58:58 --> Helper loaded: html_helper
INFO - 2023-08-19 14:58:58 --> Helper loaded: text_helper
INFO - 2023-08-19 14:58:58 --> Helper loaded: form_helper
INFO - 2023-08-19 14:58:58 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:58:58 --> Helper loaded: security_helper
INFO - 2023-08-19 14:58:58 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:58:58 --> Database Driver Class Initialized
INFO - 2023-08-19 14:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:58:58 --> Parser Class Initialized
INFO - 2023-08-19 14:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:58:58 --> Pagination Class Initialized
INFO - 2023-08-19 14:58:58 --> Form Validation Class Initialized
INFO - 2023-08-19 14:58:58 --> Controller Class Initialized
INFO - 2023-08-19 14:58:58 --> Model Class Initialized
DEBUG - 2023-08-19 14:58:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:58:58 --> Model Class Initialized
DEBUG - 2023-08-19 14:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:58:58 --> Model Class Initialized
INFO - 2023-08-19 14:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-19 14:58:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:58:58 --> Model Class Initialized
INFO - 2023-08-19 14:58:58 --> Model Class Initialized
INFO - 2023-08-19 14:58:58 --> Model Class Initialized
INFO - 2023-08-19 14:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:58:58 --> Final output sent to browser
DEBUG - 2023-08-19 14:58:58 --> Total execution time: 0.1550
ERROR - 2023-08-19 14:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:59:00 --> Config Class Initialized
INFO - 2023-08-19 14:59:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:59:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:59:00 --> Utf8 Class Initialized
INFO - 2023-08-19 14:59:00 --> URI Class Initialized
DEBUG - 2023-08-19 14:59:00 --> No URI present. Default controller set.
INFO - 2023-08-19 14:59:00 --> Router Class Initialized
INFO - 2023-08-19 14:59:00 --> Output Class Initialized
INFO - 2023-08-19 14:59:00 --> Security Class Initialized
DEBUG - 2023-08-19 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:59:00 --> Input Class Initialized
INFO - 2023-08-19 14:59:00 --> Language Class Initialized
INFO - 2023-08-19 14:59:00 --> Loader Class Initialized
INFO - 2023-08-19 14:59:00 --> Helper loaded: url_helper
INFO - 2023-08-19 14:59:00 --> Helper loaded: file_helper
INFO - 2023-08-19 14:59:00 --> Helper loaded: html_helper
INFO - 2023-08-19 14:59:00 --> Helper loaded: text_helper
INFO - 2023-08-19 14:59:00 --> Helper loaded: form_helper
INFO - 2023-08-19 14:59:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:59:00 --> Helper loaded: security_helper
INFO - 2023-08-19 14:59:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:59:00 --> Database Driver Class Initialized
INFO - 2023-08-19 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:59:00 --> Parser Class Initialized
INFO - 2023-08-19 14:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:59:00 --> Pagination Class Initialized
INFO - 2023-08-19 14:59:00 --> Form Validation Class Initialized
INFO - 2023-08-19 14:59:00 --> Controller Class Initialized
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
INFO - 2023-08-19 14:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 14:59:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:59:00 --> Model Class Initialized
INFO - 2023-08-19 14:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:59:00 --> Final output sent to browser
DEBUG - 2023-08-19 14:59:00 --> Total execution time: 0.1802
ERROR - 2023-08-19 14:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:59:10 --> Config Class Initialized
INFO - 2023-08-19 14:59:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:59:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:59:10 --> Utf8 Class Initialized
INFO - 2023-08-19 14:59:10 --> URI Class Initialized
INFO - 2023-08-19 14:59:10 --> Router Class Initialized
INFO - 2023-08-19 14:59:10 --> Output Class Initialized
INFO - 2023-08-19 14:59:10 --> Security Class Initialized
DEBUG - 2023-08-19 14:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:59:10 --> Input Class Initialized
INFO - 2023-08-19 14:59:10 --> Language Class Initialized
INFO - 2023-08-19 14:59:10 --> Loader Class Initialized
INFO - 2023-08-19 14:59:10 --> Helper loaded: url_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: file_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: html_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: text_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: form_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: security_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:59:10 --> Database Driver Class Initialized
INFO - 2023-08-19 14:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:59:10 --> Parser Class Initialized
INFO - 2023-08-19 14:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:59:10 --> Pagination Class Initialized
INFO - 2023-08-19 14:59:10 --> Form Validation Class Initialized
INFO - 2023-08-19 14:59:10 --> Controller Class Initialized
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
INFO - 2023-08-19 14:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 14:59:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
INFO - 2023-08-19 14:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:59:10 --> Final output sent to browser
DEBUG - 2023-08-19 14:59:10 --> Total execution time: 0.1337
ERROR - 2023-08-19 14:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:59:10 --> Config Class Initialized
INFO - 2023-08-19 14:59:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:59:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:59:10 --> Utf8 Class Initialized
INFO - 2023-08-19 14:59:10 --> URI Class Initialized
INFO - 2023-08-19 14:59:10 --> Router Class Initialized
INFO - 2023-08-19 14:59:10 --> Output Class Initialized
INFO - 2023-08-19 14:59:10 --> Security Class Initialized
DEBUG - 2023-08-19 14:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:59:10 --> Input Class Initialized
INFO - 2023-08-19 14:59:10 --> Language Class Initialized
INFO - 2023-08-19 14:59:10 --> Loader Class Initialized
INFO - 2023-08-19 14:59:10 --> Helper loaded: url_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: file_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: html_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: text_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: form_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: security_helper
INFO - 2023-08-19 14:59:10 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:59:10 --> Database Driver Class Initialized
INFO - 2023-08-19 14:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:59:10 --> Parser Class Initialized
INFO - 2023-08-19 14:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:59:10 --> Pagination Class Initialized
INFO - 2023-08-19 14:59:10 --> Form Validation Class Initialized
INFO - 2023-08-19 14:59:10 --> Controller Class Initialized
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:10 --> Model Class Initialized
INFO - 2023-08-19 14:59:10 --> Final output sent to browser
DEBUG - 2023-08-19 14:59:10 --> Total execution time: 0.0528
ERROR - 2023-08-19 14:59:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:59:19 --> Config Class Initialized
INFO - 2023-08-19 14:59:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:59:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:59:19 --> Utf8 Class Initialized
INFO - 2023-08-19 14:59:19 --> URI Class Initialized
INFO - 2023-08-19 14:59:19 --> Router Class Initialized
INFO - 2023-08-19 14:59:19 --> Output Class Initialized
INFO - 2023-08-19 14:59:19 --> Security Class Initialized
DEBUG - 2023-08-19 14:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:59:19 --> Input Class Initialized
INFO - 2023-08-19 14:59:19 --> Language Class Initialized
INFO - 2023-08-19 14:59:19 --> Loader Class Initialized
INFO - 2023-08-19 14:59:19 --> Helper loaded: url_helper
INFO - 2023-08-19 14:59:19 --> Helper loaded: file_helper
INFO - 2023-08-19 14:59:19 --> Helper loaded: html_helper
INFO - 2023-08-19 14:59:19 --> Helper loaded: text_helper
INFO - 2023-08-19 14:59:19 --> Helper loaded: form_helper
INFO - 2023-08-19 14:59:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:59:19 --> Helper loaded: security_helper
INFO - 2023-08-19 14:59:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:59:19 --> Database Driver Class Initialized
INFO - 2023-08-19 14:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:59:19 --> Parser Class Initialized
INFO - 2023-08-19 14:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:59:19 --> Pagination Class Initialized
INFO - 2023-08-19 14:59:19 --> Form Validation Class Initialized
INFO - 2023-08-19 14:59:19 --> Controller Class Initialized
INFO - 2023-08-19 14:59:19 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:19 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:19 --> Model Class Initialized
INFO - 2023-08-19 14:59:19 --> Final output sent to browser
DEBUG - 2023-08-19 14:59:19 --> Total execution time: 0.5326
ERROR - 2023-08-19 14:59:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 14:59:27 --> Config Class Initialized
INFO - 2023-08-19 14:59:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 14:59:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 14:59:27 --> Utf8 Class Initialized
INFO - 2023-08-19 14:59:27 --> URI Class Initialized
DEBUG - 2023-08-19 14:59:27 --> No URI present. Default controller set.
INFO - 2023-08-19 14:59:27 --> Router Class Initialized
INFO - 2023-08-19 14:59:27 --> Output Class Initialized
INFO - 2023-08-19 14:59:27 --> Security Class Initialized
DEBUG - 2023-08-19 14:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 14:59:27 --> Input Class Initialized
INFO - 2023-08-19 14:59:27 --> Language Class Initialized
INFO - 2023-08-19 14:59:27 --> Loader Class Initialized
INFO - 2023-08-19 14:59:27 --> Helper loaded: url_helper
INFO - 2023-08-19 14:59:27 --> Helper loaded: file_helper
INFO - 2023-08-19 14:59:27 --> Helper loaded: html_helper
INFO - 2023-08-19 14:59:27 --> Helper loaded: text_helper
INFO - 2023-08-19 14:59:27 --> Helper loaded: form_helper
INFO - 2023-08-19 14:59:27 --> Helper loaded: lang_helper
INFO - 2023-08-19 14:59:27 --> Helper loaded: security_helper
INFO - 2023-08-19 14:59:27 --> Helper loaded: cookie_helper
INFO - 2023-08-19 14:59:27 --> Database Driver Class Initialized
INFO - 2023-08-19 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 14:59:27 --> Parser Class Initialized
INFO - 2023-08-19 14:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 14:59:27 --> Pagination Class Initialized
INFO - 2023-08-19 14:59:27 --> Form Validation Class Initialized
INFO - 2023-08-19 14:59:27 --> Controller Class Initialized
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
DEBUG - 2023-08-19 14:59:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 14:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
INFO - 2023-08-19 14:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 14:59:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 14:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 14:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 14:59:27 --> Model Class Initialized
INFO - 2023-08-19 14:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 14:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 14:59:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 14:59:27 --> Final output sent to browser
DEBUG - 2023-08-19 14:59:27 --> Total execution time: 0.1846
ERROR - 2023-08-19 15:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:00:02 --> Config Class Initialized
INFO - 2023-08-19 15:00:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:00:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:00:02 --> Utf8 Class Initialized
INFO - 2023-08-19 15:00:02 --> URI Class Initialized
INFO - 2023-08-19 15:00:02 --> Router Class Initialized
INFO - 2023-08-19 15:00:02 --> Output Class Initialized
INFO - 2023-08-19 15:00:02 --> Security Class Initialized
DEBUG - 2023-08-19 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:00:02 --> Input Class Initialized
INFO - 2023-08-19 15:00:02 --> Language Class Initialized
INFO - 2023-08-19 15:00:02 --> Loader Class Initialized
INFO - 2023-08-19 15:00:02 --> Helper loaded: url_helper
INFO - 2023-08-19 15:00:02 --> Helper loaded: file_helper
INFO - 2023-08-19 15:00:02 --> Helper loaded: html_helper
INFO - 2023-08-19 15:00:02 --> Helper loaded: text_helper
INFO - 2023-08-19 15:00:02 --> Helper loaded: form_helper
INFO - 2023-08-19 15:00:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:00:02 --> Helper loaded: security_helper
INFO - 2023-08-19 15:00:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:00:02 --> Database Driver Class Initialized
INFO - 2023-08-19 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:00:02 --> Parser Class Initialized
INFO - 2023-08-19 15:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:00:02 --> Pagination Class Initialized
INFO - 2023-08-19 15:00:02 --> Form Validation Class Initialized
INFO - 2023-08-19 15:00:02 --> Controller Class Initialized
DEBUG - 2023-08-19 15:00:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:02 --> Model Class Initialized
DEBUG - 2023-08-19 15:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:02 --> Model Class Initialized
DEBUG - 2023-08-19 15:00:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:02 --> Model Class Initialized
INFO - 2023-08-19 15:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 15:00:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:00:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:00:02 --> Model Class Initialized
INFO - 2023-08-19 15:00:02 --> Model Class Initialized
INFO - 2023-08-19 15:00:02 --> Model Class Initialized
INFO - 2023-08-19 15:00:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:00:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:00:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:00:03 --> Final output sent to browser
DEBUG - 2023-08-19 15:00:03 --> Total execution time: 0.1641
ERROR - 2023-08-19 15:00:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:00:03 --> Config Class Initialized
INFO - 2023-08-19 15:00:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:00:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:00:03 --> Utf8 Class Initialized
INFO - 2023-08-19 15:00:03 --> URI Class Initialized
INFO - 2023-08-19 15:00:03 --> Router Class Initialized
INFO - 2023-08-19 15:00:03 --> Output Class Initialized
INFO - 2023-08-19 15:00:03 --> Security Class Initialized
DEBUG - 2023-08-19 15:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:00:03 --> Input Class Initialized
INFO - 2023-08-19 15:00:03 --> Language Class Initialized
INFO - 2023-08-19 15:00:03 --> Loader Class Initialized
INFO - 2023-08-19 15:00:03 --> Helper loaded: url_helper
INFO - 2023-08-19 15:00:03 --> Helper loaded: file_helper
INFO - 2023-08-19 15:00:03 --> Helper loaded: html_helper
INFO - 2023-08-19 15:00:03 --> Helper loaded: text_helper
INFO - 2023-08-19 15:00:03 --> Helper loaded: form_helper
INFO - 2023-08-19 15:00:03 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:00:03 --> Helper loaded: security_helper
INFO - 2023-08-19 15:00:03 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:00:03 --> Database Driver Class Initialized
INFO - 2023-08-19 15:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:00:03 --> Parser Class Initialized
INFO - 2023-08-19 15:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:00:03 --> Pagination Class Initialized
INFO - 2023-08-19 15:00:03 --> Form Validation Class Initialized
INFO - 2023-08-19 15:00:03 --> Controller Class Initialized
DEBUG - 2023-08-19 15:00:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:03 --> Model Class Initialized
DEBUG - 2023-08-19 15:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:03 --> Model Class Initialized
INFO - 2023-08-19 15:00:03 --> Final output sent to browser
DEBUG - 2023-08-19 15:00:03 --> Total execution time: 0.0334
ERROR - 2023-08-19 15:00:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:00:07 --> Config Class Initialized
INFO - 2023-08-19 15:00:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:00:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:00:07 --> Utf8 Class Initialized
INFO - 2023-08-19 15:00:07 --> URI Class Initialized
INFO - 2023-08-19 15:00:07 --> Router Class Initialized
INFO - 2023-08-19 15:00:07 --> Output Class Initialized
INFO - 2023-08-19 15:00:07 --> Security Class Initialized
DEBUG - 2023-08-19 15:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:00:07 --> Input Class Initialized
INFO - 2023-08-19 15:00:07 --> Language Class Initialized
INFO - 2023-08-19 15:00:07 --> Loader Class Initialized
INFO - 2023-08-19 15:00:07 --> Helper loaded: url_helper
INFO - 2023-08-19 15:00:07 --> Helper loaded: file_helper
INFO - 2023-08-19 15:00:07 --> Helper loaded: html_helper
INFO - 2023-08-19 15:00:07 --> Helper loaded: text_helper
INFO - 2023-08-19 15:00:07 --> Helper loaded: form_helper
INFO - 2023-08-19 15:00:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:00:07 --> Helper loaded: security_helper
INFO - 2023-08-19 15:00:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:00:07 --> Database Driver Class Initialized
INFO - 2023-08-19 15:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:00:07 --> Parser Class Initialized
INFO - 2023-08-19 15:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:00:07 --> Pagination Class Initialized
INFO - 2023-08-19 15:00:07 --> Form Validation Class Initialized
INFO - 2023-08-19 15:00:07 --> Controller Class Initialized
DEBUG - 2023-08-19 15:00:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:07 --> Model Class Initialized
DEBUG - 2023-08-19 15:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:07 --> Model Class Initialized
INFO - 2023-08-19 15:00:07 --> Final output sent to browser
DEBUG - 2023-08-19 15:00:07 --> Total execution time: 0.1474
ERROR - 2023-08-19 15:00:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:00:18 --> Config Class Initialized
INFO - 2023-08-19 15:00:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:00:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:00:18 --> Utf8 Class Initialized
INFO - 2023-08-19 15:00:18 --> URI Class Initialized
INFO - 2023-08-19 15:00:18 --> Router Class Initialized
INFO - 2023-08-19 15:00:18 --> Output Class Initialized
INFO - 2023-08-19 15:00:18 --> Security Class Initialized
DEBUG - 2023-08-19 15:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:00:18 --> Input Class Initialized
INFO - 2023-08-19 15:00:18 --> Language Class Initialized
INFO - 2023-08-19 15:00:18 --> Loader Class Initialized
INFO - 2023-08-19 15:00:18 --> Helper loaded: url_helper
INFO - 2023-08-19 15:00:18 --> Helper loaded: file_helper
INFO - 2023-08-19 15:00:18 --> Helper loaded: html_helper
INFO - 2023-08-19 15:00:18 --> Helper loaded: text_helper
INFO - 2023-08-19 15:00:18 --> Helper loaded: form_helper
INFO - 2023-08-19 15:00:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:00:18 --> Helper loaded: security_helper
INFO - 2023-08-19 15:00:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:00:18 --> Database Driver Class Initialized
INFO - 2023-08-19 15:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:00:18 --> Parser Class Initialized
INFO - 2023-08-19 15:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:00:18 --> Pagination Class Initialized
INFO - 2023-08-19 15:00:18 --> Form Validation Class Initialized
INFO - 2023-08-19 15:00:18 --> Controller Class Initialized
DEBUG - 2023-08-19 15:00:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:18 --> Model Class Initialized
DEBUG - 2023-08-19 15:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:18 --> Model Class Initialized
INFO - 2023-08-19 15:00:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-19 15:00:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:00:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:00:18 --> Model Class Initialized
INFO - 2023-08-19 15:00:18 --> Model Class Initialized
INFO - 2023-08-19 15:00:18 --> Model Class Initialized
INFO - 2023-08-19 15:00:18 --> Model Class Initialized
INFO - 2023-08-19 15:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:00:19 --> Final output sent to browser
DEBUG - 2023-08-19 15:00:19 --> Total execution time: 0.1033
ERROR - 2023-08-19 15:00:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:00:44 --> Config Class Initialized
INFO - 2023-08-19 15:00:44 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:00:44 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:00:44 --> Utf8 Class Initialized
INFO - 2023-08-19 15:00:44 --> URI Class Initialized
INFO - 2023-08-19 15:00:44 --> Router Class Initialized
INFO - 2023-08-19 15:00:44 --> Output Class Initialized
INFO - 2023-08-19 15:00:44 --> Security Class Initialized
DEBUG - 2023-08-19 15:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:00:44 --> Input Class Initialized
INFO - 2023-08-19 15:00:44 --> Language Class Initialized
INFO - 2023-08-19 15:00:44 --> Loader Class Initialized
INFO - 2023-08-19 15:00:44 --> Helper loaded: url_helper
INFO - 2023-08-19 15:00:44 --> Helper loaded: file_helper
INFO - 2023-08-19 15:00:44 --> Helper loaded: html_helper
INFO - 2023-08-19 15:00:44 --> Helper loaded: text_helper
INFO - 2023-08-19 15:00:44 --> Helper loaded: form_helper
INFO - 2023-08-19 15:00:44 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:00:44 --> Helper loaded: security_helper
INFO - 2023-08-19 15:00:44 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:00:44 --> Database Driver Class Initialized
INFO - 2023-08-19 15:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:00:44 --> Parser Class Initialized
INFO - 2023-08-19 15:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:00:44 --> Pagination Class Initialized
INFO - 2023-08-19 15:00:44 --> Form Validation Class Initialized
INFO - 2023-08-19 15:00:44 --> Controller Class Initialized
DEBUG - 2023-08-19 15:00:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:44 --> Model Class Initialized
INFO - 2023-08-19 15:00:44 --> Model Class Initialized
DEBUG - 2023-08-19 15:00:44 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:44 --> Model Class Initialized
INFO - 2023-08-19 15:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-08-19 15:00:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:00:44 --> Model Class Initialized
INFO - 2023-08-19 15:00:44 --> Model Class Initialized
INFO - 2023-08-19 15:00:44 --> Model Class Initialized
INFO - 2023-08-19 15:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:00:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:00:44 --> Final output sent to browser
DEBUG - 2023-08-19 15:00:44 --> Total execution time: 0.1337
ERROR - 2023-08-19 15:00:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:00:45 --> Config Class Initialized
INFO - 2023-08-19 15:00:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:00:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:00:45 --> Utf8 Class Initialized
INFO - 2023-08-19 15:00:45 --> URI Class Initialized
INFO - 2023-08-19 15:00:45 --> Router Class Initialized
INFO - 2023-08-19 15:00:45 --> Output Class Initialized
INFO - 2023-08-19 15:00:45 --> Security Class Initialized
DEBUG - 2023-08-19 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:00:45 --> Input Class Initialized
INFO - 2023-08-19 15:00:45 --> Language Class Initialized
INFO - 2023-08-19 15:00:45 --> Loader Class Initialized
INFO - 2023-08-19 15:00:45 --> Helper loaded: url_helper
INFO - 2023-08-19 15:00:45 --> Helper loaded: file_helper
INFO - 2023-08-19 15:00:45 --> Helper loaded: html_helper
INFO - 2023-08-19 15:00:45 --> Helper loaded: text_helper
INFO - 2023-08-19 15:00:45 --> Helper loaded: form_helper
INFO - 2023-08-19 15:00:45 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:00:45 --> Helper loaded: security_helper
INFO - 2023-08-19 15:00:45 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:00:45 --> Database Driver Class Initialized
INFO - 2023-08-19 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:00:45 --> Parser Class Initialized
INFO - 2023-08-19 15:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:00:45 --> Pagination Class Initialized
INFO - 2023-08-19 15:00:45 --> Form Validation Class Initialized
INFO - 2023-08-19 15:00:45 --> Controller Class Initialized
DEBUG - 2023-08-19 15:00:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:00:45 --> Model Class Initialized
INFO - 2023-08-19 15:00:45 --> Model Class Initialized
INFO - 2023-08-19 15:00:45 --> Final output sent to browser
DEBUG - 2023-08-19 15:00:45 --> Total execution time: 0.0243
ERROR - 2023-08-19 15:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:04:02 --> Config Class Initialized
INFO - 2023-08-19 15:04:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:04:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:04:02 --> Utf8 Class Initialized
INFO - 2023-08-19 15:04:02 --> URI Class Initialized
INFO - 2023-08-19 15:04:02 --> Router Class Initialized
INFO - 2023-08-19 15:04:02 --> Output Class Initialized
INFO - 2023-08-19 15:04:02 --> Security Class Initialized
DEBUG - 2023-08-19 15:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:04:02 --> Input Class Initialized
INFO - 2023-08-19 15:04:02 --> Language Class Initialized
INFO - 2023-08-19 15:04:02 --> Loader Class Initialized
INFO - 2023-08-19 15:04:02 --> Helper loaded: url_helper
INFO - 2023-08-19 15:04:02 --> Helper loaded: file_helper
INFO - 2023-08-19 15:04:02 --> Helper loaded: html_helper
INFO - 2023-08-19 15:04:02 --> Helper loaded: text_helper
INFO - 2023-08-19 15:04:02 --> Helper loaded: form_helper
INFO - 2023-08-19 15:04:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:04:02 --> Helper loaded: security_helper
INFO - 2023-08-19 15:04:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:04:02 --> Database Driver Class Initialized
INFO - 2023-08-19 15:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:04:02 --> Parser Class Initialized
INFO - 2023-08-19 15:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:04:02 --> Pagination Class Initialized
INFO - 2023-08-19 15:04:02 --> Form Validation Class Initialized
INFO - 2023-08-19 15:04:02 --> Controller Class Initialized
DEBUG - 2023-08-19 15:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:02 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:02 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:02 --> Model Class Initialized
INFO - 2023-08-19 15:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 15:04:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:04:02 --> Model Class Initialized
INFO - 2023-08-19 15:04:02 --> Model Class Initialized
INFO - 2023-08-19 15:04:02 --> Model Class Initialized
INFO - 2023-08-19 15:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:04:02 --> Final output sent to browser
DEBUG - 2023-08-19 15:04:02 --> Total execution time: 0.1673
ERROR - 2023-08-19 15:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:04:03 --> Config Class Initialized
INFO - 2023-08-19 15:04:03 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:04:03 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:04:03 --> Utf8 Class Initialized
INFO - 2023-08-19 15:04:03 --> URI Class Initialized
INFO - 2023-08-19 15:04:03 --> Router Class Initialized
INFO - 2023-08-19 15:04:03 --> Output Class Initialized
INFO - 2023-08-19 15:04:03 --> Security Class Initialized
DEBUG - 2023-08-19 15:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:04:03 --> Input Class Initialized
INFO - 2023-08-19 15:04:03 --> Language Class Initialized
INFO - 2023-08-19 15:04:03 --> Loader Class Initialized
INFO - 2023-08-19 15:04:03 --> Helper loaded: url_helper
INFO - 2023-08-19 15:04:03 --> Helper loaded: file_helper
INFO - 2023-08-19 15:04:03 --> Helper loaded: html_helper
INFO - 2023-08-19 15:04:03 --> Helper loaded: text_helper
INFO - 2023-08-19 15:04:03 --> Helper loaded: form_helper
INFO - 2023-08-19 15:04:03 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:04:03 --> Helper loaded: security_helper
INFO - 2023-08-19 15:04:03 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:04:03 --> Database Driver Class Initialized
INFO - 2023-08-19 15:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:04:03 --> Parser Class Initialized
INFO - 2023-08-19 15:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:04:03 --> Pagination Class Initialized
INFO - 2023-08-19 15:04:03 --> Form Validation Class Initialized
INFO - 2023-08-19 15:04:03 --> Controller Class Initialized
DEBUG - 2023-08-19 15:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:03 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:03 --> Model Class Initialized
INFO - 2023-08-19 15:04:03 --> Final output sent to browser
DEBUG - 2023-08-19 15:04:03 --> Total execution time: 0.0333
ERROR - 2023-08-19 15:04:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:04:10 --> Config Class Initialized
INFO - 2023-08-19 15:04:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:04:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:04:10 --> Utf8 Class Initialized
INFO - 2023-08-19 15:04:10 --> URI Class Initialized
INFO - 2023-08-19 15:04:10 --> Router Class Initialized
INFO - 2023-08-19 15:04:10 --> Output Class Initialized
INFO - 2023-08-19 15:04:10 --> Security Class Initialized
DEBUG - 2023-08-19 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:04:10 --> Input Class Initialized
INFO - 2023-08-19 15:04:10 --> Language Class Initialized
INFO - 2023-08-19 15:04:10 --> Loader Class Initialized
INFO - 2023-08-19 15:04:10 --> Helper loaded: url_helper
INFO - 2023-08-19 15:04:10 --> Helper loaded: file_helper
INFO - 2023-08-19 15:04:10 --> Helper loaded: html_helper
INFO - 2023-08-19 15:04:10 --> Helper loaded: text_helper
INFO - 2023-08-19 15:04:10 --> Helper loaded: form_helper
INFO - 2023-08-19 15:04:10 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:04:10 --> Helper loaded: security_helper
INFO - 2023-08-19 15:04:10 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:04:10 --> Database Driver Class Initialized
INFO - 2023-08-19 15:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:04:10 --> Parser Class Initialized
INFO - 2023-08-19 15:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:04:10 --> Pagination Class Initialized
INFO - 2023-08-19 15:04:10 --> Form Validation Class Initialized
INFO - 2023-08-19 15:04:10 --> Controller Class Initialized
INFO - 2023-08-19 15:04:10 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:10 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:10 --> Model Class Initialized
INFO - 2023-08-19 15:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 15:04:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:04:10 --> Model Class Initialized
INFO - 2023-08-19 15:04:10 --> Model Class Initialized
INFO - 2023-08-19 15:04:10 --> Model Class Initialized
INFO - 2023-08-19 15:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:04:10 --> Final output sent to browser
DEBUG - 2023-08-19 15:04:10 --> Total execution time: 0.1422
ERROR - 2023-08-19 15:04:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:04:11 --> Config Class Initialized
INFO - 2023-08-19 15:04:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:04:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:04:11 --> Utf8 Class Initialized
INFO - 2023-08-19 15:04:11 --> URI Class Initialized
INFO - 2023-08-19 15:04:11 --> Router Class Initialized
INFO - 2023-08-19 15:04:11 --> Output Class Initialized
INFO - 2023-08-19 15:04:11 --> Security Class Initialized
DEBUG - 2023-08-19 15:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:04:11 --> Input Class Initialized
INFO - 2023-08-19 15:04:11 --> Language Class Initialized
INFO - 2023-08-19 15:04:11 --> Loader Class Initialized
INFO - 2023-08-19 15:04:11 --> Helper loaded: url_helper
INFO - 2023-08-19 15:04:11 --> Helper loaded: file_helper
INFO - 2023-08-19 15:04:11 --> Helper loaded: html_helper
INFO - 2023-08-19 15:04:11 --> Helper loaded: text_helper
INFO - 2023-08-19 15:04:11 --> Helper loaded: form_helper
INFO - 2023-08-19 15:04:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:04:11 --> Helper loaded: security_helper
INFO - 2023-08-19 15:04:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:04:11 --> Database Driver Class Initialized
INFO - 2023-08-19 15:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:04:11 --> Parser Class Initialized
INFO - 2023-08-19 15:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:04:11 --> Pagination Class Initialized
INFO - 2023-08-19 15:04:11 --> Form Validation Class Initialized
INFO - 2023-08-19 15:04:11 --> Controller Class Initialized
INFO - 2023-08-19 15:04:11 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:11 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:11 --> Model Class Initialized
INFO - 2023-08-19 15:04:11 --> Final output sent to browser
DEBUG - 2023-08-19 15:04:11 --> Total execution time: 0.0638
ERROR - 2023-08-19 15:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:04:19 --> Config Class Initialized
INFO - 2023-08-19 15:04:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:04:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:04:19 --> Utf8 Class Initialized
INFO - 2023-08-19 15:04:19 --> URI Class Initialized
INFO - 2023-08-19 15:04:19 --> Router Class Initialized
INFO - 2023-08-19 15:04:19 --> Output Class Initialized
INFO - 2023-08-19 15:04:19 --> Security Class Initialized
DEBUG - 2023-08-19 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:04:19 --> Input Class Initialized
INFO - 2023-08-19 15:04:19 --> Language Class Initialized
INFO - 2023-08-19 15:04:19 --> Loader Class Initialized
INFO - 2023-08-19 15:04:19 --> Helper loaded: url_helper
INFO - 2023-08-19 15:04:19 --> Helper loaded: file_helper
INFO - 2023-08-19 15:04:19 --> Helper loaded: html_helper
INFO - 2023-08-19 15:04:19 --> Helper loaded: text_helper
INFO - 2023-08-19 15:04:19 --> Helper loaded: form_helper
INFO - 2023-08-19 15:04:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:04:19 --> Helper loaded: security_helper
INFO - 2023-08-19 15:04:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:04:19 --> Database Driver Class Initialized
INFO - 2023-08-19 15:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:04:19 --> Parser Class Initialized
INFO - 2023-08-19 15:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:04:19 --> Pagination Class Initialized
INFO - 2023-08-19 15:04:19 --> Form Validation Class Initialized
INFO - 2023-08-19 15:04:19 --> Controller Class Initialized
INFO - 2023-08-19 15:04:19 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:19 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:19 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-19 15:04:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:04:19 --> Model Class Initialized
INFO - 2023-08-19 15:04:19 --> Model Class Initialized
INFO - 2023-08-19 15:04:19 --> Model Class Initialized
INFO - 2023-08-19 15:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:04:19 --> Final output sent to browser
DEBUG - 2023-08-19 15:04:19 --> Total execution time: 0.1493
ERROR - 2023-08-19 15:04:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:04:48 --> Config Class Initialized
INFO - 2023-08-19 15:04:48 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:04:48 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:04:48 --> Utf8 Class Initialized
INFO - 2023-08-19 15:04:48 --> URI Class Initialized
DEBUG - 2023-08-19 15:04:48 --> No URI present. Default controller set.
INFO - 2023-08-19 15:04:48 --> Router Class Initialized
INFO - 2023-08-19 15:04:48 --> Output Class Initialized
INFO - 2023-08-19 15:04:48 --> Security Class Initialized
DEBUG - 2023-08-19 15:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:04:48 --> Input Class Initialized
INFO - 2023-08-19 15:04:48 --> Language Class Initialized
INFO - 2023-08-19 15:04:48 --> Loader Class Initialized
INFO - 2023-08-19 15:04:48 --> Helper loaded: url_helper
INFO - 2023-08-19 15:04:48 --> Helper loaded: file_helper
INFO - 2023-08-19 15:04:48 --> Helper loaded: html_helper
INFO - 2023-08-19 15:04:48 --> Helper loaded: text_helper
INFO - 2023-08-19 15:04:48 --> Helper loaded: form_helper
INFO - 2023-08-19 15:04:48 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:04:48 --> Helper loaded: security_helper
INFO - 2023-08-19 15:04:48 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:04:48 --> Database Driver Class Initialized
INFO - 2023-08-19 15:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:04:48 --> Parser Class Initialized
INFO - 2023-08-19 15:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:04:48 --> Pagination Class Initialized
INFO - 2023-08-19 15:04:48 --> Form Validation Class Initialized
INFO - 2023-08-19 15:04:48 --> Controller Class Initialized
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
DEBUG - 2023-08-19 15:04:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
INFO - 2023-08-19 15:04:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 15:04:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:04:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:04:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:04:48 --> Model Class Initialized
INFO - 2023-08-19 15:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:04:49 --> Final output sent to browser
DEBUG - 2023-08-19 15:04:49 --> Total execution time: 0.1945
ERROR - 2023-08-19 15:05:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:05:13 --> Config Class Initialized
INFO - 2023-08-19 15:05:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:05:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:05:13 --> Utf8 Class Initialized
INFO - 2023-08-19 15:05:13 --> URI Class Initialized
DEBUG - 2023-08-19 15:05:13 --> No URI present. Default controller set.
INFO - 2023-08-19 15:05:13 --> Router Class Initialized
INFO - 2023-08-19 15:05:13 --> Output Class Initialized
INFO - 2023-08-19 15:05:13 --> Security Class Initialized
DEBUG - 2023-08-19 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:05:13 --> Input Class Initialized
INFO - 2023-08-19 15:05:13 --> Language Class Initialized
INFO - 2023-08-19 15:05:13 --> Loader Class Initialized
INFO - 2023-08-19 15:05:13 --> Helper loaded: url_helper
INFO - 2023-08-19 15:05:13 --> Helper loaded: file_helper
INFO - 2023-08-19 15:05:13 --> Helper loaded: html_helper
INFO - 2023-08-19 15:05:13 --> Helper loaded: text_helper
INFO - 2023-08-19 15:05:13 --> Helper loaded: form_helper
INFO - 2023-08-19 15:05:13 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:05:13 --> Helper loaded: security_helper
INFO - 2023-08-19 15:05:13 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:05:13 --> Database Driver Class Initialized
INFO - 2023-08-19 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:05:13 --> Parser Class Initialized
INFO - 2023-08-19 15:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:05:13 --> Pagination Class Initialized
INFO - 2023-08-19 15:05:13 --> Form Validation Class Initialized
INFO - 2023-08-19 15:05:13 --> Controller Class Initialized
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
DEBUG - 2023-08-19 15:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
DEBUG - 2023-08-19 15:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
DEBUG - 2023-08-19 15:05:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
INFO - 2023-08-19 15:05:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 15:05:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:05:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:05:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:05:13 --> Model Class Initialized
INFO - 2023-08-19 15:05:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:05:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:05:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:05:13 --> Final output sent to browser
DEBUG - 2023-08-19 15:05:13 --> Total execution time: 0.1946
ERROR - 2023-08-19 15:06:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:06:53 --> Config Class Initialized
INFO - 2023-08-19 15:06:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:06:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:06:53 --> Utf8 Class Initialized
INFO - 2023-08-19 15:06:53 --> URI Class Initialized
DEBUG - 2023-08-19 15:06:53 --> No URI present. Default controller set.
INFO - 2023-08-19 15:06:53 --> Router Class Initialized
INFO - 2023-08-19 15:06:53 --> Output Class Initialized
INFO - 2023-08-19 15:06:53 --> Security Class Initialized
DEBUG - 2023-08-19 15:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:06:53 --> Input Class Initialized
INFO - 2023-08-19 15:06:53 --> Language Class Initialized
INFO - 2023-08-19 15:06:53 --> Loader Class Initialized
INFO - 2023-08-19 15:06:53 --> Helper loaded: url_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: file_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: html_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: text_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: form_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: security_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:06:53 --> Database Driver Class Initialized
INFO - 2023-08-19 15:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:06:53 --> Parser Class Initialized
INFO - 2023-08-19 15:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:06:53 --> Pagination Class Initialized
INFO - 2023-08-19 15:06:53 --> Form Validation Class Initialized
INFO - 2023-08-19 15:06:53 --> Controller Class Initialized
INFO - 2023-08-19 15:06:53 --> Model Class Initialized
DEBUG - 2023-08-19 15:06:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 15:06:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:06:53 --> Config Class Initialized
INFO - 2023-08-19 15:06:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:06:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:06:53 --> Utf8 Class Initialized
INFO - 2023-08-19 15:06:53 --> URI Class Initialized
INFO - 2023-08-19 15:06:53 --> Router Class Initialized
INFO - 2023-08-19 15:06:53 --> Output Class Initialized
INFO - 2023-08-19 15:06:53 --> Security Class Initialized
DEBUG - 2023-08-19 15:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:06:53 --> Input Class Initialized
INFO - 2023-08-19 15:06:53 --> Language Class Initialized
INFO - 2023-08-19 15:06:53 --> Loader Class Initialized
INFO - 2023-08-19 15:06:53 --> Helper loaded: url_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: file_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: html_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: text_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: form_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: security_helper
INFO - 2023-08-19 15:06:53 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:06:53 --> Database Driver Class Initialized
INFO - 2023-08-19 15:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:06:53 --> Parser Class Initialized
INFO - 2023-08-19 15:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:06:53 --> Pagination Class Initialized
INFO - 2023-08-19 15:06:53 --> Form Validation Class Initialized
INFO - 2023-08-19 15:06:53 --> Controller Class Initialized
INFO - 2023-08-19 15:06:53 --> Model Class Initialized
DEBUG - 2023-08-19 15:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 15:06:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:06:53 --> Model Class Initialized
INFO - 2023-08-19 15:06:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:06:53 --> Final output sent to browser
DEBUG - 2023-08-19 15:06:53 --> Total execution time: 0.0295
ERROR - 2023-08-19 15:09:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:09:29 --> Config Class Initialized
INFO - 2023-08-19 15:09:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:09:29 --> Utf8 Class Initialized
INFO - 2023-08-19 15:09:29 --> URI Class Initialized
DEBUG - 2023-08-19 15:09:29 --> No URI present. Default controller set.
INFO - 2023-08-19 15:09:29 --> Router Class Initialized
INFO - 2023-08-19 15:09:29 --> Output Class Initialized
INFO - 2023-08-19 15:09:29 --> Security Class Initialized
DEBUG - 2023-08-19 15:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:09:29 --> Input Class Initialized
INFO - 2023-08-19 15:09:29 --> Language Class Initialized
INFO - 2023-08-19 15:09:29 --> Loader Class Initialized
INFO - 2023-08-19 15:09:29 --> Helper loaded: url_helper
INFO - 2023-08-19 15:09:29 --> Helper loaded: file_helper
INFO - 2023-08-19 15:09:29 --> Helper loaded: html_helper
INFO - 2023-08-19 15:09:29 --> Helper loaded: text_helper
INFO - 2023-08-19 15:09:29 --> Helper loaded: form_helper
INFO - 2023-08-19 15:09:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:09:29 --> Helper loaded: security_helper
INFO - 2023-08-19 15:09:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:09:29 --> Database Driver Class Initialized
INFO - 2023-08-19 15:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:09:29 --> Parser Class Initialized
INFO - 2023-08-19 15:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:09:29 --> Pagination Class Initialized
INFO - 2023-08-19 15:09:29 --> Form Validation Class Initialized
INFO - 2023-08-19 15:09:29 --> Controller Class Initialized
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
DEBUG - 2023-08-19 15:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
DEBUG - 2023-08-19 15:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
DEBUG - 2023-08-19 15:09:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
INFO - 2023-08-19 15:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 15:09:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:09:29 --> Model Class Initialized
INFO - 2023-08-19 15:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:09:29 --> Final output sent to browser
DEBUG - 2023-08-19 15:09:29 --> Total execution time: 0.1947
ERROR - 2023-08-19 15:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:13:47 --> Config Class Initialized
INFO - 2023-08-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:13:47 --> Utf8 Class Initialized
INFO - 2023-08-19 15:13:47 --> URI Class Initialized
INFO - 2023-08-19 15:13:47 --> Router Class Initialized
INFO - 2023-08-19 15:13:47 --> Output Class Initialized
INFO - 2023-08-19 15:13:47 --> Security Class Initialized
DEBUG - 2023-08-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:13:47 --> Input Class Initialized
INFO - 2023-08-19 15:13:47 --> Language Class Initialized
INFO - 2023-08-19 15:13:47 --> Loader Class Initialized
INFO - 2023-08-19 15:13:47 --> Helper loaded: url_helper
INFO - 2023-08-19 15:13:47 --> Helper loaded: file_helper
INFO - 2023-08-19 15:13:47 --> Helper loaded: html_helper
INFO - 2023-08-19 15:13:47 --> Helper loaded: text_helper
INFO - 2023-08-19 15:13:47 --> Helper loaded: form_helper
INFO - 2023-08-19 15:13:47 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:13:47 --> Helper loaded: security_helper
INFO - 2023-08-19 15:13:47 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:13:47 --> Database Driver Class Initialized
INFO - 2023-08-19 15:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:13:47 --> Parser Class Initialized
INFO - 2023-08-19 15:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:13:47 --> Pagination Class Initialized
INFO - 2023-08-19 15:13:47 --> Form Validation Class Initialized
INFO - 2023-08-19 15:13:47 --> Controller Class Initialized
INFO - 2023-08-19 15:13:47 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:47 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:47 --> Model Class Initialized
INFO - 2023-08-19 15:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-19 15:13:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:13:47 --> Model Class Initialized
INFO - 2023-08-19 15:13:47 --> Model Class Initialized
INFO - 2023-08-19 15:13:47 --> Model Class Initialized
INFO - 2023-08-19 15:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:13:47 --> Final output sent to browser
DEBUG - 2023-08-19 15:13:47 --> Total execution time: 0.1564
ERROR - 2023-08-19 15:13:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:13:53 --> Config Class Initialized
INFO - 2023-08-19 15:13:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:13:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:13:53 --> Utf8 Class Initialized
INFO - 2023-08-19 15:13:53 --> URI Class Initialized
INFO - 2023-08-19 15:13:53 --> Router Class Initialized
INFO - 2023-08-19 15:13:53 --> Output Class Initialized
INFO - 2023-08-19 15:13:53 --> Security Class Initialized
DEBUG - 2023-08-19 15:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:13:53 --> Input Class Initialized
INFO - 2023-08-19 15:13:53 --> Language Class Initialized
INFO - 2023-08-19 15:13:53 --> Loader Class Initialized
INFO - 2023-08-19 15:13:53 --> Helper loaded: url_helper
INFO - 2023-08-19 15:13:53 --> Helper loaded: file_helper
INFO - 2023-08-19 15:13:53 --> Helper loaded: html_helper
INFO - 2023-08-19 15:13:53 --> Helper loaded: text_helper
INFO - 2023-08-19 15:13:53 --> Helper loaded: form_helper
INFO - 2023-08-19 15:13:53 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:13:53 --> Helper loaded: security_helper
INFO - 2023-08-19 15:13:53 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:13:53 --> Database Driver Class Initialized
INFO - 2023-08-19 15:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:13:53 --> Parser Class Initialized
INFO - 2023-08-19 15:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:13:53 --> Pagination Class Initialized
INFO - 2023-08-19 15:13:53 --> Form Validation Class Initialized
INFO - 2023-08-19 15:13:53 --> Controller Class Initialized
INFO - 2023-08-19 15:13:53 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:53 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:53 --> Model Class Initialized
INFO - 2023-08-19 15:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 15:13:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:13:53 --> Model Class Initialized
INFO - 2023-08-19 15:13:53 --> Model Class Initialized
INFO - 2023-08-19 15:13:53 --> Model Class Initialized
INFO - 2023-08-19 15:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:13:53 --> Final output sent to browser
DEBUG - 2023-08-19 15:13:53 --> Total execution time: 0.0763
ERROR - 2023-08-19 15:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:13:54 --> Config Class Initialized
INFO - 2023-08-19 15:13:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:13:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:13:54 --> Utf8 Class Initialized
INFO - 2023-08-19 15:13:54 --> URI Class Initialized
INFO - 2023-08-19 15:13:54 --> Router Class Initialized
INFO - 2023-08-19 15:13:54 --> Output Class Initialized
INFO - 2023-08-19 15:13:54 --> Security Class Initialized
DEBUG - 2023-08-19 15:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:13:54 --> Input Class Initialized
INFO - 2023-08-19 15:13:54 --> Language Class Initialized
INFO - 2023-08-19 15:13:54 --> Loader Class Initialized
INFO - 2023-08-19 15:13:54 --> Helper loaded: url_helper
INFO - 2023-08-19 15:13:54 --> Helper loaded: file_helper
INFO - 2023-08-19 15:13:54 --> Helper loaded: html_helper
INFO - 2023-08-19 15:13:54 --> Helper loaded: text_helper
INFO - 2023-08-19 15:13:54 --> Helper loaded: form_helper
INFO - 2023-08-19 15:13:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:13:54 --> Helper loaded: security_helper
INFO - 2023-08-19 15:13:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:13:54 --> Database Driver Class Initialized
INFO - 2023-08-19 15:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:13:54 --> Parser Class Initialized
INFO - 2023-08-19 15:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:13:54 --> Pagination Class Initialized
INFO - 2023-08-19 15:13:54 --> Form Validation Class Initialized
INFO - 2023-08-19 15:13:54 --> Controller Class Initialized
INFO - 2023-08-19 15:13:54 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:54 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:54 --> Model Class Initialized
INFO - 2023-08-19 15:13:54 --> Final output sent to browser
DEBUG - 2023-08-19 15:13:54 --> Total execution time: 0.0362
ERROR - 2023-08-19 15:13:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:13:56 --> Config Class Initialized
INFO - 2023-08-19 15:13:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:13:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:13:56 --> Utf8 Class Initialized
INFO - 2023-08-19 15:13:56 --> URI Class Initialized
INFO - 2023-08-19 15:13:56 --> Router Class Initialized
INFO - 2023-08-19 15:13:56 --> Output Class Initialized
INFO - 2023-08-19 15:13:56 --> Security Class Initialized
DEBUG - 2023-08-19 15:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:13:56 --> Input Class Initialized
INFO - 2023-08-19 15:13:56 --> Language Class Initialized
INFO - 2023-08-19 15:13:56 --> Loader Class Initialized
INFO - 2023-08-19 15:13:56 --> Helper loaded: url_helper
INFO - 2023-08-19 15:13:56 --> Helper loaded: file_helper
INFO - 2023-08-19 15:13:56 --> Helper loaded: html_helper
INFO - 2023-08-19 15:13:56 --> Helper loaded: text_helper
INFO - 2023-08-19 15:13:56 --> Helper loaded: form_helper
INFO - 2023-08-19 15:13:56 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:13:56 --> Helper loaded: security_helper
INFO - 2023-08-19 15:13:56 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:13:56 --> Database Driver Class Initialized
INFO - 2023-08-19 15:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:13:56 --> Parser Class Initialized
INFO - 2023-08-19 15:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:13:56 --> Pagination Class Initialized
INFO - 2023-08-19 15:13:56 --> Form Validation Class Initialized
INFO - 2023-08-19 15:13:56 --> Controller Class Initialized
INFO - 2023-08-19 15:13:56 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:13:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:56 --> Model Class Initialized
DEBUG - 2023-08-19 15:13:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:56 --> Model Class Initialized
INFO - 2023-08-19 15:13:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-19 15:13:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:13:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:13:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:13:56 --> Model Class Initialized
INFO - 2023-08-19 15:13:56 --> Model Class Initialized
INFO - 2023-08-19 15:13:56 --> Model Class Initialized
INFO - 2023-08-19 15:13:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:13:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:13:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:13:56 --> Final output sent to browser
DEBUG - 2023-08-19 15:13:56 --> Total execution time: 0.0875
ERROR - 2023-08-19 15:14:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:14:04 --> Config Class Initialized
INFO - 2023-08-19 15:14:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:14:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:14:04 --> Utf8 Class Initialized
INFO - 2023-08-19 15:14:04 --> URI Class Initialized
INFO - 2023-08-19 15:14:04 --> Router Class Initialized
INFO - 2023-08-19 15:14:04 --> Output Class Initialized
INFO - 2023-08-19 15:14:04 --> Security Class Initialized
DEBUG - 2023-08-19 15:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:14:04 --> Input Class Initialized
INFO - 2023-08-19 15:14:04 --> Language Class Initialized
INFO - 2023-08-19 15:14:04 --> Loader Class Initialized
INFO - 2023-08-19 15:14:04 --> Helper loaded: url_helper
INFO - 2023-08-19 15:14:04 --> Helper loaded: file_helper
INFO - 2023-08-19 15:14:04 --> Helper loaded: html_helper
INFO - 2023-08-19 15:14:04 --> Helper loaded: text_helper
INFO - 2023-08-19 15:14:04 --> Helper loaded: form_helper
INFO - 2023-08-19 15:14:04 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:14:04 --> Helper loaded: security_helper
INFO - 2023-08-19 15:14:04 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:14:04 --> Database Driver Class Initialized
INFO - 2023-08-19 15:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:14:04 --> Parser Class Initialized
INFO - 2023-08-19 15:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:14:04 --> Pagination Class Initialized
INFO - 2023-08-19 15:14:04 --> Form Validation Class Initialized
INFO - 2023-08-19 15:14:04 --> Controller Class Initialized
DEBUG - 2023-08-19 15:14:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:04 --> Model Class Initialized
DEBUG - 2023-08-19 15:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:04 --> Model Class Initialized
DEBUG - 2023-08-19 15:14:04 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:04 --> Model Class Initialized
INFO - 2023-08-19 15:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 15:14:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:14:04 --> Model Class Initialized
INFO - 2023-08-19 15:14:04 --> Model Class Initialized
INFO - 2023-08-19 15:14:04 --> Model Class Initialized
INFO - 2023-08-19 15:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:14:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:14:04 --> Final output sent to browser
DEBUG - 2023-08-19 15:14:04 --> Total execution time: 0.1427
ERROR - 2023-08-19 15:14:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:14:05 --> Config Class Initialized
INFO - 2023-08-19 15:14:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:14:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:14:05 --> Utf8 Class Initialized
INFO - 2023-08-19 15:14:05 --> URI Class Initialized
INFO - 2023-08-19 15:14:05 --> Router Class Initialized
INFO - 2023-08-19 15:14:05 --> Output Class Initialized
INFO - 2023-08-19 15:14:05 --> Security Class Initialized
DEBUG - 2023-08-19 15:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:14:05 --> Input Class Initialized
INFO - 2023-08-19 15:14:05 --> Language Class Initialized
INFO - 2023-08-19 15:14:05 --> Loader Class Initialized
INFO - 2023-08-19 15:14:05 --> Helper loaded: url_helper
INFO - 2023-08-19 15:14:05 --> Helper loaded: file_helper
INFO - 2023-08-19 15:14:05 --> Helper loaded: html_helper
INFO - 2023-08-19 15:14:05 --> Helper loaded: text_helper
INFO - 2023-08-19 15:14:05 --> Helper loaded: form_helper
INFO - 2023-08-19 15:14:05 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:14:05 --> Helper loaded: security_helper
INFO - 2023-08-19 15:14:05 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:14:05 --> Database Driver Class Initialized
INFO - 2023-08-19 15:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:14:05 --> Parser Class Initialized
INFO - 2023-08-19 15:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:14:05 --> Pagination Class Initialized
INFO - 2023-08-19 15:14:05 --> Form Validation Class Initialized
INFO - 2023-08-19 15:14:05 --> Controller Class Initialized
DEBUG - 2023-08-19 15:14:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:05 --> Model Class Initialized
DEBUG - 2023-08-19 15:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:05 --> Model Class Initialized
INFO - 2023-08-19 15:14:05 --> Final output sent to browser
DEBUG - 2023-08-19 15:14:05 --> Total execution time: 0.0310
ERROR - 2023-08-19 15:14:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:14:10 --> Config Class Initialized
INFO - 2023-08-19 15:14:10 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:14:10 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:14:10 --> Utf8 Class Initialized
INFO - 2023-08-19 15:14:10 --> URI Class Initialized
INFO - 2023-08-19 15:14:10 --> Router Class Initialized
INFO - 2023-08-19 15:14:10 --> Output Class Initialized
INFO - 2023-08-19 15:14:10 --> Security Class Initialized
DEBUG - 2023-08-19 15:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:14:10 --> Input Class Initialized
INFO - 2023-08-19 15:14:10 --> Language Class Initialized
INFO - 2023-08-19 15:14:10 --> Loader Class Initialized
INFO - 2023-08-19 15:14:10 --> Helper loaded: url_helper
INFO - 2023-08-19 15:14:10 --> Helper loaded: file_helper
INFO - 2023-08-19 15:14:10 --> Helper loaded: html_helper
INFO - 2023-08-19 15:14:10 --> Helper loaded: text_helper
INFO - 2023-08-19 15:14:10 --> Helper loaded: form_helper
INFO - 2023-08-19 15:14:10 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:14:10 --> Helper loaded: security_helper
INFO - 2023-08-19 15:14:10 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:14:10 --> Database Driver Class Initialized
INFO - 2023-08-19 15:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:14:10 --> Parser Class Initialized
INFO - 2023-08-19 15:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:14:10 --> Pagination Class Initialized
INFO - 2023-08-19 15:14:10 --> Form Validation Class Initialized
INFO - 2023-08-19 15:14:10 --> Controller Class Initialized
DEBUG - 2023-08-19 15:14:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:10 --> Model Class Initialized
DEBUG - 2023-08-19 15:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:10 --> Model Class Initialized
INFO - 2023-08-19 15:14:10 --> Final output sent to browser
DEBUG - 2023-08-19 15:14:10 --> Total execution time: 0.0294
ERROR - 2023-08-19 15:14:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:14:17 --> Config Class Initialized
INFO - 2023-08-19 15:14:17 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:14:17 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:14:17 --> Utf8 Class Initialized
INFO - 2023-08-19 15:14:17 --> URI Class Initialized
INFO - 2023-08-19 15:14:17 --> Router Class Initialized
INFO - 2023-08-19 15:14:17 --> Output Class Initialized
INFO - 2023-08-19 15:14:17 --> Security Class Initialized
DEBUG - 2023-08-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:14:17 --> Input Class Initialized
INFO - 2023-08-19 15:14:17 --> Language Class Initialized
INFO - 2023-08-19 15:14:17 --> Loader Class Initialized
INFO - 2023-08-19 15:14:17 --> Helper loaded: url_helper
INFO - 2023-08-19 15:14:17 --> Helper loaded: file_helper
INFO - 2023-08-19 15:14:17 --> Helper loaded: html_helper
INFO - 2023-08-19 15:14:17 --> Helper loaded: text_helper
INFO - 2023-08-19 15:14:17 --> Helper loaded: form_helper
INFO - 2023-08-19 15:14:17 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:14:17 --> Helper loaded: security_helper
INFO - 2023-08-19 15:14:17 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:14:17 --> Database Driver Class Initialized
INFO - 2023-08-19 15:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:14:17 --> Parser Class Initialized
INFO - 2023-08-19 15:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:14:17 --> Pagination Class Initialized
INFO - 2023-08-19 15:14:17 --> Form Validation Class Initialized
INFO - 2023-08-19 15:14:17 --> Controller Class Initialized
DEBUG - 2023-08-19 15:14:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:17 --> Model Class Initialized
DEBUG - 2023-08-19 15:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:17 --> Model Class Initialized
INFO - 2023-08-19 15:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-08-19 15:14:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:14:17 --> Model Class Initialized
INFO - 2023-08-19 15:14:17 --> Model Class Initialized
INFO - 2023-08-19 15:14:17 --> Model Class Initialized
INFO - 2023-08-19 15:14:17 --> Model Class Initialized
INFO - 2023-08-19 15:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:14:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:14:17 --> Final output sent to browser
DEBUG - 2023-08-19 15:14:17 --> Total execution time: 0.1256
ERROR - 2023-08-19 15:17:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:17:27 --> Config Class Initialized
INFO - 2023-08-19 15:17:27 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:17:27 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:17:27 --> Utf8 Class Initialized
INFO - 2023-08-19 15:17:27 --> URI Class Initialized
DEBUG - 2023-08-19 15:17:27 --> No URI present. Default controller set.
INFO - 2023-08-19 15:17:27 --> Router Class Initialized
INFO - 2023-08-19 15:17:27 --> Output Class Initialized
INFO - 2023-08-19 15:17:27 --> Security Class Initialized
DEBUG - 2023-08-19 15:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:17:27 --> Input Class Initialized
INFO - 2023-08-19 15:17:27 --> Language Class Initialized
INFO - 2023-08-19 15:17:27 --> Loader Class Initialized
INFO - 2023-08-19 15:17:27 --> Helper loaded: url_helper
INFO - 2023-08-19 15:17:27 --> Helper loaded: file_helper
INFO - 2023-08-19 15:17:27 --> Helper loaded: html_helper
INFO - 2023-08-19 15:17:27 --> Helper loaded: text_helper
INFO - 2023-08-19 15:17:27 --> Helper loaded: form_helper
INFO - 2023-08-19 15:17:27 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:17:27 --> Helper loaded: security_helper
INFO - 2023-08-19 15:17:27 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:17:27 --> Database Driver Class Initialized
INFO - 2023-08-19 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:17:27 --> Parser Class Initialized
INFO - 2023-08-19 15:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:17:27 --> Pagination Class Initialized
INFO - 2023-08-19 15:17:27 --> Form Validation Class Initialized
INFO - 2023-08-19 15:17:27 --> Controller Class Initialized
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
DEBUG - 2023-08-19 15:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
DEBUG - 2023-08-19 15:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
DEBUG - 2023-08-19 15:17:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
INFO - 2023-08-19 15:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 15:17:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:17:27 --> Model Class Initialized
INFO - 2023-08-19 15:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:17:27 --> Final output sent to browser
DEBUG - 2023-08-19 15:17:27 --> Total execution time: 0.1910
ERROR - 2023-08-19 15:17:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:17:37 --> Config Class Initialized
INFO - 2023-08-19 15:17:37 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:17:37 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:17:37 --> Utf8 Class Initialized
INFO - 2023-08-19 15:17:37 --> URI Class Initialized
INFO - 2023-08-19 15:17:37 --> Router Class Initialized
INFO - 2023-08-19 15:17:37 --> Output Class Initialized
INFO - 2023-08-19 15:17:37 --> Security Class Initialized
DEBUG - 2023-08-19 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:17:37 --> Input Class Initialized
INFO - 2023-08-19 15:17:37 --> Language Class Initialized
INFO - 2023-08-19 15:17:37 --> Loader Class Initialized
INFO - 2023-08-19 15:17:37 --> Helper loaded: url_helper
INFO - 2023-08-19 15:17:37 --> Helper loaded: file_helper
INFO - 2023-08-19 15:17:37 --> Helper loaded: html_helper
INFO - 2023-08-19 15:17:37 --> Helper loaded: text_helper
INFO - 2023-08-19 15:17:37 --> Helper loaded: form_helper
INFO - 2023-08-19 15:17:37 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:17:37 --> Helper loaded: security_helper
INFO - 2023-08-19 15:17:37 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:17:37 --> Database Driver Class Initialized
INFO - 2023-08-19 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:17:37 --> Parser Class Initialized
INFO - 2023-08-19 15:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:17:37 --> Pagination Class Initialized
INFO - 2023-08-19 15:17:37 --> Form Validation Class Initialized
INFO - 2023-08-19 15:17:37 --> Controller Class Initialized
INFO - 2023-08-19 15:17:37 --> Model Class Initialized
INFO - 2023-08-19 15:17:37 --> Model Class Initialized
INFO - 2023-08-19 15:17:37 --> Model Class Initialized
INFO - 2023-08-19 15:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-08-19 15:17:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:17:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:17:37 --> Model Class Initialized
INFO - 2023-08-19 15:17:37 --> Model Class Initialized
INFO - 2023-08-19 15:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:17:38 --> Final output sent to browser
DEBUG - 2023-08-19 15:17:38 --> Total execution time: 0.1333
ERROR - 2023-08-19 15:17:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:17:39 --> Config Class Initialized
INFO - 2023-08-19 15:17:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:17:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:17:39 --> Utf8 Class Initialized
INFO - 2023-08-19 15:17:39 --> URI Class Initialized
INFO - 2023-08-19 15:17:39 --> Router Class Initialized
INFO - 2023-08-19 15:17:39 --> Output Class Initialized
INFO - 2023-08-19 15:17:39 --> Security Class Initialized
DEBUG - 2023-08-19 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:17:39 --> Input Class Initialized
INFO - 2023-08-19 15:17:39 --> Language Class Initialized
INFO - 2023-08-19 15:17:39 --> Loader Class Initialized
INFO - 2023-08-19 15:17:39 --> Helper loaded: url_helper
INFO - 2023-08-19 15:17:39 --> Helper loaded: file_helper
INFO - 2023-08-19 15:17:39 --> Helper loaded: html_helper
INFO - 2023-08-19 15:17:39 --> Helper loaded: text_helper
INFO - 2023-08-19 15:17:39 --> Helper loaded: form_helper
INFO - 2023-08-19 15:17:39 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:17:39 --> Helper loaded: security_helper
INFO - 2023-08-19 15:17:39 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:17:39 --> Database Driver Class Initialized
INFO - 2023-08-19 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:17:39 --> Parser Class Initialized
INFO - 2023-08-19 15:17:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:17:39 --> Pagination Class Initialized
INFO - 2023-08-19 15:17:39 --> Form Validation Class Initialized
INFO - 2023-08-19 15:17:39 --> Controller Class Initialized
INFO - 2023-08-19 15:17:39 --> Model Class Initialized
INFO - 2023-08-19 15:17:39 --> Model Class Initialized
INFO - 2023-08-19 15:17:39 --> Final output sent to browser
DEBUG - 2023-08-19 15:17:39 --> Total execution time: 0.0251
ERROR - 2023-08-19 15:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:17:52 --> Config Class Initialized
INFO - 2023-08-19 15:17:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:17:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:17:52 --> Utf8 Class Initialized
INFO - 2023-08-19 15:17:52 --> URI Class Initialized
INFO - 2023-08-19 15:17:52 --> Router Class Initialized
INFO - 2023-08-19 15:17:52 --> Output Class Initialized
INFO - 2023-08-19 15:17:52 --> Security Class Initialized
DEBUG - 2023-08-19 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:17:52 --> Input Class Initialized
INFO - 2023-08-19 15:17:52 --> Language Class Initialized
INFO - 2023-08-19 15:17:52 --> Loader Class Initialized
INFO - 2023-08-19 15:17:52 --> Helper loaded: url_helper
INFO - 2023-08-19 15:17:52 --> Helper loaded: file_helper
INFO - 2023-08-19 15:17:52 --> Helper loaded: html_helper
INFO - 2023-08-19 15:17:52 --> Helper loaded: text_helper
INFO - 2023-08-19 15:17:52 --> Helper loaded: form_helper
INFO - 2023-08-19 15:17:52 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:17:52 --> Helper loaded: security_helper
INFO - 2023-08-19 15:17:52 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:17:52 --> Database Driver Class Initialized
INFO - 2023-08-19 15:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:17:52 --> Parser Class Initialized
INFO - 2023-08-19 15:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:17:52 --> Pagination Class Initialized
INFO - 2023-08-19 15:17:52 --> Form Validation Class Initialized
INFO - 2023-08-19 15:17:52 --> Controller Class Initialized
DEBUG - 2023-08-19 15:17:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:17:52 --> Model Class Initialized
INFO - 2023-08-19 15:17:52 --> Model Class Initialized
INFO - 2023-08-19 15:17:52 --> Model Class Initialized
INFO - 2023-08-19 15:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-08-19 15:17:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:17:52 --> Model Class Initialized
INFO - 2023-08-19 15:17:52 --> Model Class Initialized
INFO - 2023-08-19 15:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:17:52 --> Final output sent to browser
DEBUG - 2023-08-19 15:17:52 --> Total execution time: 0.1700
ERROR - 2023-08-19 15:20:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:20:29 --> Config Class Initialized
INFO - 2023-08-19 15:20:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:20:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:20:29 --> Utf8 Class Initialized
INFO - 2023-08-19 15:20:29 --> URI Class Initialized
INFO - 2023-08-19 15:20:29 --> Router Class Initialized
INFO - 2023-08-19 15:20:29 --> Output Class Initialized
INFO - 2023-08-19 15:20:29 --> Security Class Initialized
DEBUG - 2023-08-19 15:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:20:29 --> Input Class Initialized
INFO - 2023-08-19 15:20:29 --> Language Class Initialized
INFO - 2023-08-19 15:20:29 --> Loader Class Initialized
INFO - 2023-08-19 15:20:29 --> Helper loaded: url_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: file_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: html_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: text_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: form_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: security_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:20:29 --> Database Driver Class Initialized
INFO - 2023-08-19 15:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:20:29 --> Parser Class Initialized
INFO - 2023-08-19 15:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:20:29 --> Pagination Class Initialized
INFO - 2023-08-19 15:20:29 --> Form Validation Class Initialized
INFO - 2023-08-19 15:20:29 --> Controller Class Initialized
INFO - 2023-08-19 15:20:29 --> Model Class Initialized
DEBUG - 2023-08-19 15:20:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:20:29 --> Model Class Initialized
INFO - 2023-08-19 15:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-08-19 15:20:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:20:29 --> Model Class Initialized
INFO - 2023-08-19 15:20:29 --> Model Class Initialized
INFO - 2023-08-19 15:20:29 --> Model Class Initialized
INFO - 2023-08-19 15:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:20:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:20:29 --> Final output sent to browser
DEBUG - 2023-08-19 15:20:29 --> Total execution time: 0.0714
ERROR - 2023-08-19 15:20:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:20:29 --> Config Class Initialized
INFO - 2023-08-19 15:20:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:20:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:20:29 --> Utf8 Class Initialized
INFO - 2023-08-19 15:20:29 --> URI Class Initialized
INFO - 2023-08-19 15:20:29 --> Router Class Initialized
INFO - 2023-08-19 15:20:29 --> Output Class Initialized
INFO - 2023-08-19 15:20:29 --> Security Class Initialized
DEBUG - 2023-08-19 15:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:20:29 --> Input Class Initialized
INFO - 2023-08-19 15:20:29 --> Language Class Initialized
INFO - 2023-08-19 15:20:29 --> Loader Class Initialized
INFO - 2023-08-19 15:20:29 --> Helper loaded: url_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: file_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: html_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: text_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: form_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: security_helper
INFO - 2023-08-19 15:20:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:20:29 --> Database Driver Class Initialized
INFO - 2023-08-19 15:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:20:29 --> Parser Class Initialized
INFO - 2023-08-19 15:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:20:29 --> Pagination Class Initialized
INFO - 2023-08-19 15:20:29 --> Form Validation Class Initialized
INFO - 2023-08-19 15:20:29 --> Controller Class Initialized
INFO - 2023-08-19 15:20:29 --> Model Class Initialized
DEBUG - 2023-08-19 15:20:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:20:29 --> Model Class Initialized
INFO - 2023-08-19 15:20:29 --> Final output sent to browser
DEBUG - 2023-08-19 15:20:29 --> Total execution time: 0.0288
ERROR - 2023-08-19 15:20:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:20:32 --> Config Class Initialized
INFO - 2023-08-19 15:20:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:20:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:20:32 --> Utf8 Class Initialized
INFO - 2023-08-19 15:20:32 --> URI Class Initialized
INFO - 2023-08-19 15:20:32 --> Router Class Initialized
INFO - 2023-08-19 15:20:32 --> Output Class Initialized
INFO - 2023-08-19 15:20:32 --> Security Class Initialized
DEBUG - 2023-08-19 15:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:20:32 --> Input Class Initialized
INFO - 2023-08-19 15:20:32 --> Language Class Initialized
INFO - 2023-08-19 15:20:32 --> Loader Class Initialized
INFO - 2023-08-19 15:20:32 --> Helper loaded: url_helper
INFO - 2023-08-19 15:20:32 --> Helper loaded: file_helper
INFO - 2023-08-19 15:20:32 --> Helper loaded: html_helper
INFO - 2023-08-19 15:20:32 --> Helper loaded: text_helper
INFO - 2023-08-19 15:20:32 --> Helper loaded: form_helper
INFO - 2023-08-19 15:20:32 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:20:32 --> Helper loaded: security_helper
INFO - 2023-08-19 15:20:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:20:32 --> Database Driver Class Initialized
INFO - 2023-08-19 15:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:20:32 --> Parser Class Initialized
INFO - 2023-08-19 15:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:20:32 --> Pagination Class Initialized
INFO - 2023-08-19 15:20:32 --> Form Validation Class Initialized
INFO - 2023-08-19 15:20:32 --> Controller Class Initialized
INFO - 2023-08-19 15:20:32 --> Model Class Initialized
DEBUG - 2023-08-19 15:20:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:20:32 --> Model Class Initialized
INFO - 2023-08-19 15:20:32 --> Final output sent to browser
DEBUG - 2023-08-19 15:20:32 --> Total execution time: 0.0269
ERROR - 2023-08-19 15:21:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:21:05 --> Config Class Initialized
INFO - 2023-08-19 15:21:05 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:21:05 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:21:05 --> Utf8 Class Initialized
INFO - 2023-08-19 15:21:05 --> URI Class Initialized
INFO - 2023-08-19 15:21:05 --> Router Class Initialized
INFO - 2023-08-19 15:21:05 --> Output Class Initialized
INFO - 2023-08-19 15:21:05 --> Security Class Initialized
DEBUG - 2023-08-19 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:21:05 --> Input Class Initialized
INFO - 2023-08-19 15:21:05 --> Language Class Initialized
INFO - 2023-08-19 15:21:05 --> Loader Class Initialized
INFO - 2023-08-19 15:21:05 --> Helper loaded: url_helper
INFO - 2023-08-19 15:21:05 --> Helper loaded: file_helper
INFO - 2023-08-19 15:21:05 --> Helper loaded: html_helper
INFO - 2023-08-19 15:21:05 --> Helper loaded: text_helper
INFO - 2023-08-19 15:21:05 --> Helper loaded: form_helper
INFO - 2023-08-19 15:21:05 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:21:05 --> Helper loaded: security_helper
INFO - 2023-08-19 15:21:05 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:21:05 --> Database Driver Class Initialized
INFO - 2023-08-19 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:21:05 --> Parser Class Initialized
INFO - 2023-08-19 15:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:21:05 --> Pagination Class Initialized
INFO - 2023-08-19 15:21:05 --> Form Validation Class Initialized
INFO - 2023-08-19 15:21:05 --> Controller Class Initialized
INFO - 2023-08-19 15:21:05 --> Model Class Initialized
DEBUG - 2023-08-19 15:21:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:05 --> Model Class Initialized
INFO - 2023-08-19 15:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-19 15:21:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:21:05 --> Model Class Initialized
INFO - 2023-08-19 15:21:05 --> Model Class Initialized
INFO - 2023-08-19 15:21:05 --> Model Class Initialized
INFO - 2023-08-19 15:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:21:05 --> Final output sent to browser
DEBUG - 2023-08-19 15:21:05 --> Total execution time: 0.1534
ERROR - 2023-08-19 15:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:21:06 --> Config Class Initialized
INFO - 2023-08-19 15:21:06 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:21:06 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:21:06 --> Utf8 Class Initialized
INFO - 2023-08-19 15:21:06 --> URI Class Initialized
INFO - 2023-08-19 15:21:06 --> Router Class Initialized
INFO - 2023-08-19 15:21:06 --> Output Class Initialized
INFO - 2023-08-19 15:21:06 --> Security Class Initialized
DEBUG - 2023-08-19 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:21:06 --> Input Class Initialized
INFO - 2023-08-19 15:21:06 --> Language Class Initialized
INFO - 2023-08-19 15:21:06 --> Loader Class Initialized
INFO - 2023-08-19 15:21:06 --> Helper loaded: url_helper
INFO - 2023-08-19 15:21:06 --> Helper loaded: file_helper
INFO - 2023-08-19 15:21:06 --> Helper loaded: html_helper
INFO - 2023-08-19 15:21:06 --> Helper loaded: text_helper
INFO - 2023-08-19 15:21:06 --> Helper loaded: form_helper
INFO - 2023-08-19 15:21:06 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:21:06 --> Helper loaded: security_helper
INFO - 2023-08-19 15:21:06 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:21:06 --> Database Driver Class Initialized
INFO - 2023-08-19 15:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:21:06 --> Parser Class Initialized
INFO - 2023-08-19 15:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:21:06 --> Pagination Class Initialized
INFO - 2023-08-19 15:21:06 --> Form Validation Class Initialized
INFO - 2023-08-19 15:21:06 --> Controller Class Initialized
INFO - 2023-08-19 15:21:06 --> Model Class Initialized
DEBUG - 2023-08-19 15:21:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:06 --> Model Class Initialized
INFO - 2023-08-19 15:21:06 --> Final output sent to browser
DEBUG - 2023-08-19 15:21:06 --> Total execution time: 0.0249
ERROR - 2023-08-19 15:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:21:11 --> Config Class Initialized
INFO - 2023-08-19 15:21:11 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:21:11 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:21:11 --> Utf8 Class Initialized
INFO - 2023-08-19 15:21:11 --> URI Class Initialized
INFO - 2023-08-19 15:21:11 --> Router Class Initialized
INFO - 2023-08-19 15:21:11 --> Output Class Initialized
INFO - 2023-08-19 15:21:11 --> Security Class Initialized
DEBUG - 2023-08-19 15:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:21:11 --> Input Class Initialized
INFO - 2023-08-19 15:21:11 --> Language Class Initialized
INFO - 2023-08-19 15:21:11 --> Loader Class Initialized
INFO - 2023-08-19 15:21:11 --> Helper loaded: url_helper
INFO - 2023-08-19 15:21:11 --> Helper loaded: file_helper
INFO - 2023-08-19 15:21:11 --> Helper loaded: html_helper
INFO - 2023-08-19 15:21:11 --> Helper loaded: text_helper
INFO - 2023-08-19 15:21:11 --> Helper loaded: form_helper
INFO - 2023-08-19 15:21:11 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:21:11 --> Helper loaded: security_helper
INFO - 2023-08-19 15:21:11 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:21:11 --> Database Driver Class Initialized
INFO - 2023-08-19 15:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:21:11 --> Parser Class Initialized
INFO - 2023-08-19 15:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:21:11 --> Pagination Class Initialized
INFO - 2023-08-19 15:21:11 --> Form Validation Class Initialized
INFO - 2023-08-19 15:21:11 --> Controller Class Initialized
INFO - 2023-08-19 15:21:11 --> Model Class Initialized
DEBUG - 2023-08-19 15:21:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:11 --> Model Class Initialized
DEBUG - 2023-08-19 15:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-19 15:21:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:21:11 --> Model Class Initialized
INFO - 2023-08-19 15:21:11 --> Model Class Initialized
INFO - 2023-08-19 15:21:11 --> Model Class Initialized
INFO - 2023-08-19 15:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:21:11 --> Final output sent to browser
DEBUG - 2023-08-19 15:21:11 --> Total execution time: 0.1420
ERROR - 2023-08-19 15:21:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:21:23 --> Config Class Initialized
INFO - 2023-08-19 15:21:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:21:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:21:23 --> Utf8 Class Initialized
INFO - 2023-08-19 15:21:23 --> URI Class Initialized
DEBUG - 2023-08-19 15:21:23 --> No URI present. Default controller set.
INFO - 2023-08-19 15:21:23 --> Router Class Initialized
INFO - 2023-08-19 15:21:23 --> Output Class Initialized
INFO - 2023-08-19 15:21:23 --> Security Class Initialized
DEBUG - 2023-08-19 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:21:23 --> Input Class Initialized
INFO - 2023-08-19 15:21:23 --> Language Class Initialized
INFO - 2023-08-19 15:21:23 --> Loader Class Initialized
INFO - 2023-08-19 15:21:23 --> Helper loaded: url_helper
INFO - 2023-08-19 15:21:23 --> Helper loaded: file_helper
INFO - 2023-08-19 15:21:23 --> Helper loaded: html_helper
INFO - 2023-08-19 15:21:23 --> Helper loaded: text_helper
INFO - 2023-08-19 15:21:23 --> Helper loaded: form_helper
INFO - 2023-08-19 15:21:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:21:23 --> Helper loaded: security_helper
INFO - 2023-08-19 15:21:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:21:23 --> Database Driver Class Initialized
INFO - 2023-08-19 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:21:23 --> Parser Class Initialized
INFO - 2023-08-19 15:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:21:23 --> Pagination Class Initialized
INFO - 2023-08-19 15:21:23 --> Form Validation Class Initialized
INFO - 2023-08-19 15:21:23 --> Controller Class Initialized
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
DEBUG - 2023-08-19 15:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
DEBUG - 2023-08-19 15:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
DEBUG - 2023-08-19 15:21:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
INFO - 2023-08-19 15:21:23 --> Model Class Initialized
INFO - 2023-08-19 15:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 15:21:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:21:24 --> Model Class Initialized
INFO - 2023-08-19 15:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:21:24 --> Final output sent to browser
DEBUG - 2023-08-19 15:21:24 --> Total execution time: 0.1825
ERROR - 2023-08-19 15:22:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:22:45 --> Config Class Initialized
INFO - 2023-08-19 15:22:45 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:22:45 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:22:45 --> Utf8 Class Initialized
INFO - 2023-08-19 15:22:45 --> URI Class Initialized
DEBUG - 2023-08-19 15:22:45 --> No URI present. Default controller set.
INFO - 2023-08-19 15:22:45 --> Router Class Initialized
INFO - 2023-08-19 15:22:45 --> Output Class Initialized
INFO - 2023-08-19 15:22:45 --> Security Class Initialized
DEBUG - 2023-08-19 15:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:22:45 --> Input Class Initialized
INFO - 2023-08-19 15:22:45 --> Language Class Initialized
INFO - 2023-08-19 15:22:45 --> Loader Class Initialized
INFO - 2023-08-19 15:22:45 --> Helper loaded: url_helper
INFO - 2023-08-19 15:22:45 --> Helper loaded: file_helper
INFO - 2023-08-19 15:22:45 --> Helper loaded: html_helper
INFO - 2023-08-19 15:22:45 --> Helper loaded: text_helper
INFO - 2023-08-19 15:22:45 --> Helper loaded: form_helper
INFO - 2023-08-19 15:22:45 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:22:45 --> Helper loaded: security_helper
INFO - 2023-08-19 15:22:45 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:22:45 --> Database Driver Class Initialized
INFO - 2023-08-19 15:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:22:45 --> Parser Class Initialized
INFO - 2023-08-19 15:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:22:45 --> Pagination Class Initialized
INFO - 2023-08-19 15:22:45 --> Form Validation Class Initialized
INFO - 2023-08-19 15:22:45 --> Controller Class Initialized
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
DEBUG - 2023-08-19 15:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
DEBUG - 2023-08-19 15:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
DEBUG - 2023-08-19 15:22:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
INFO - 2023-08-19 15:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 15:22:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:22:45 --> Model Class Initialized
INFO - 2023-08-19 15:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:22:45 --> Final output sent to browser
DEBUG - 2023-08-19 15:22:45 --> Total execution time: 0.2001
ERROR - 2023-08-19 15:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 15:23:00 --> Config Class Initialized
INFO - 2023-08-19 15:23:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 15:23:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 15:23:00 --> Utf8 Class Initialized
INFO - 2023-08-19 15:23:00 --> URI Class Initialized
DEBUG - 2023-08-19 15:23:00 --> No URI present. Default controller set.
INFO - 2023-08-19 15:23:00 --> Router Class Initialized
INFO - 2023-08-19 15:23:00 --> Output Class Initialized
INFO - 2023-08-19 15:23:00 --> Security Class Initialized
DEBUG - 2023-08-19 15:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 15:23:00 --> Input Class Initialized
INFO - 2023-08-19 15:23:00 --> Language Class Initialized
INFO - 2023-08-19 15:23:00 --> Loader Class Initialized
INFO - 2023-08-19 15:23:00 --> Helper loaded: url_helper
INFO - 2023-08-19 15:23:00 --> Helper loaded: file_helper
INFO - 2023-08-19 15:23:00 --> Helper loaded: html_helper
INFO - 2023-08-19 15:23:00 --> Helper loaded: text_helper
INFO - 2023-08-19 15:23:00 --> Helper loaded: form_helper
INFO - 2023-08-19 15:23:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 15:23:00 --> Helper loaded: security_helper
INFO - 2023-08-19 15:23:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 15:23:00 --> Database Driver Class Initialized
INFO - 2023-08-19 15:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 15:23:00 --> Parser Class Initialized
INFO - 2023-08-19 15:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 15:23:00 --> Pagination Class Initialized
INFO - 2023-08-19 15:23:00 --> Form Validation Class Initialized
INFO - 2023-08-19 15:23:00 --> Controller Class Initialized
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
DEBUG - 2023-08-19 15:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
DEBUG - 2023-08-19 15:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
DEBUG - 2023-08-19 15:23:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 15:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
INFO - 2023-08-19 15:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 15:23:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 15:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 15:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 15:23:00 --> Model Class Initialized
INFO - 2023-08-19 15:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 15:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 15:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 15:23:00 --> Final output sent to browser
DEBUG - 2023-08-19 15:23:00 --> Total execution time: 0.2055
ERROR - 2023-08-19 16:11:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:11:49 --> Config Class Initialized
INFO - 2023-08-19 16:11:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:11:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:11:49 --> Utf8 Class Initialized
INFO - 2023-08-19 16:11:49 --> URI Class Initialized
DEBUG - 2023-08-19 16:11:49 --> No URI present. Default controller set.
INFO - 2023-08-19 16:11:49 --> Router Class Initialized
INFO - 2023-08-19 16:11:49 --> Output Class Initialized
INFO - 2023-08-19 16:11:49 --> Security Class Initialized
DEBUG - 2023-08-19 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:11:49 --> Input Class Initialized
INFO - 2023-08-19 16:11:49 --> Language Class Initialized
INFO - 2023-08-19 16:11:49 --> Loader Class Initialized
INFO - 2023-08-19 16:11:49 --> Helper loaded: url_helper
INFO - 2023-08-19 16:11:49 --> Helper loaded: file_helper
INFO - 2023-08-19 16:11:49 --> Helper loaded: html_helper
INFO - 2023-08-19 16:11:49 --> Helper loaded: text_helper
INFO - 2023-08-19 16:11:49 --> Helper loaded: form_helper
INFO - 2023-08-19 16:11:49 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:11:49 --> Helper loaded: security_helper
INFO - 2023-08-19 16:11:49 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:11:49 --> Database Driver Class Initialized
INFO - 2023-08-19 16:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:11:49 --> Parser Class Initialized
INFO - 2023-08-19 16:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:11:49 --> Pagination Class Initialized
INFO - 2023-08-19 16:11:49 --> Form Validation Class Initialized
INFO - 2023-08-19 16:11:49 --> Controller Class Initialized
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
DEBUG - 2023-08-19 16:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
DEBUG - 2023-08-19 16:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
DEBUG - 2023-08-19 16:11:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
INFO - 2023-08-19 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 16:11:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:11:49 --> Model Class Initialized
INFO - 2023-08-19 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:11:49 --> Final output sent to browser
DEBUG - 2023-08-19 16:11:49 --> Total execution time: 0.1883
ERROR - 2023-08-19 16:11:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:11:55 --> Config Class Initialized
INFO - 2023-08-19 16:11:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:11:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:11:55 --> Utf8 Class Initialized
INFO - 2023-08-19 16:11:55 --> URI Class Initialized
INFO - 2023-08-19 16:11:55 --> Router Class Initialized
INFO - 2023-08-19 16:11:55 --> Output Class Initialized
INFO - 2023-08-19 16:11:55 --> Security Class Initialized
DEBUG - 2023-08-19 16:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:11:55 --> Input Class Initialized
INFO - 2023-08-19 16:11:55 --> Language Class Initialized
INFO - 2023-08-19 16:11:55 --> Loader Class Initialized
INFO - 2023-08-19 16:11:55 --> Helper loaded: url_helper
INFO - 2023-08-19 16:11:55 --> Helper loaded: file_helper
INFO - 2023-08-19 16:11:55 --> Helper loaded: html_helper
INFO - 2023-08-19 16:11:55 --> Helper loaded: text_helper
INFO - 2023-08-19 16:11:55 --> Helper loaded: form_helper
INFO - 2023-08-19 16:11:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:11:55 --> Helper loaded: security_helper
INFO - 2023-08-19 16:11:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:11:55 --> Database Driver Class Initialized
INFO - 2023-08-19 16:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:11:55 --> Parser Class Initialized
INFO - 2023-08-19 16:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:11:55 --> Pagination Class Initialized
INFO - 2023-08-19 16:11:55 --> Form Validation Class Initialized
INFO - 2023-08-19 16:11:55 --> Controller Class Initialized
INFO - 2023-08-19 16:11:55 --> Model Class Initialized
DEBUG - 2023-08-19 16:11:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:55 --> Model Class Initialized
DEBUG - 2023-08-19 16:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:55 --> Model Class Initialized
INFO - 2023-08-19 16:11:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-19 16:11:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:11:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:11:55 --> Model Class Initialized
INFO - 2023-08-19 16:11:55 --> Model Class Initialized
INFO - 2023-08-19 16:11:55 --> Model Class Initialized
INFO - 2023-08-19 16:11:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:11:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:11:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:11:55 --> Final output sent to browser
DEBUG - 2023-08-19 16:11:55 --> Total execution time: 0.1503
ERROR - 2023-08-19 16:11:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:11:56 --> Config Class Initialized
INFO - 2023-08-19 16:11:56 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:11:56 --> Utf8 Class Initialized
INFO - 2023-08-19 16:11:56 --> URI Class Initialized
INFO - 2023-08-19 16:11:56 --> Router Class Initialized
INFO - 2023-08-19 16:11:56 --> Output Class Initialized
INFO - 2023-08-19 16:11:56 --> Security Class Initialized
DEBUG - 2023-08-19 16:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:11:56 --> Input Class Initialized
INFO - 2023-08-19 16:11:56 --> Language Class Initialized
INFO - 2023-08-19 16:11:56 --> Loader Class Initialized
INFO - 2023-08-19 16:11:56 --> Helper loaded: url_helper
INFO - 2023-08-19 16:11:56 --> Helper loaded: file_helper
INFO - 2023-08-19 16:11:56 --> Helper loaded: html_helper
INFO - 2023-08-19 16:11:56 --> Helper loaded: text_helper
INFO - 2023-08-19 16:11:56 --> Helper loaded: form_helper
INFO - 2023-08-19 16:11:56 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:11:56 --> Helper loaded: security_helper
INFO - 2023-08-19 16:11:56 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:11:56 --> Database Driver Class Initialized
INFO - 2023-08-19 16:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:11:56 --> Parser Class Initialized
INFO - 2023-08-19 16:11:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:11:56 --> Pagination Class Initialized
INFO - 2023-08-19 16:11:56 --> Form Validation Class Initialized
INFO - 2023-08-19 16:11:56 --> Controller Class Initialized
INFO - 2023-08-19 16:11:56 --> Model Class Initialized
DEBUG - 2023-08-19 16:11:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:11:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:56 --> Model Class Initialized
DEBUG - 2023-08-19 16:11:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:11:56 --> Model Class Initialized
INFO - 2023-08-19 16:11:56 --> Final output sent to browser
DEBUG - 2023-08-19 16:11:56 --> Total execution time: 0.0485
ERROR - 2023-08-19 16:12:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:01 --> Config Class Initialized
INFO - 2023-08-19 16:12:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:01 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:01 --> URI Class Initialized
INFO - 2023-08-19 16:12:01 --> Router Class Initialized
INFO - 2023-08-19 16:12:01 --> Output Class Initialized
INFO - 2023-08-19 16:12:01 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:01 --> Input Class Initialized
INFO - 2023-08-19 16:12:01 --> Language Class Initialized
INFO - 2023-08-19 16:12:01 --> Loader Class Initialized
INFO - 2023-08-19 16:12:01 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:01 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:01 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:01 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:01 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:01 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:01 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:01 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:01 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:01 --> Parser Class Initialized
INFO - 2023-08-19 16:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:01 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:01 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:01 --> Controller Class Initialized
INFO - 2023-08-19 16:12:01 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:01 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:01 --> Model Class Initialized
INFO - 2023-08-19 16:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 16:12:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:12:01 --> Model Class Initialized
INFO - 2023-08-19 16:12:01 --> Model Class Initialized
INFO - 2023-08-19 16:12:01 --> Model Class Initialized
INFO - 2023-08-19 16:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:12:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:12:01 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:01 --> Total execution time: 0.1566
ERROR - 2023-08-19 16:12:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:02 --> Config Class Initialized
INFO - 2023-08-19 16:12:02 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:02 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:02 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:02 --> URI Class Initialized
INFO - 2023-08-19 16:12:02 --> Router Class Initialized
INFO - 2023-08-19 16:12:02 --> Output Class Initialized
INFO - 2023-08-19 16:12:02 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:02 --> Input Class Initialized
INFO - 2023-08-19 16:12:02 --> Language Class Initialized
INFO - 2023-08-19 16:12:02 --> Loader Class Initialized
INFO - 2023-08-19 16:12:02 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:02 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:02 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:02 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:02 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:02 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:02 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:02 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:02 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:02 --> Parser Class Initialized
INFO - 2023-08-19 16:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:02 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:02 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:02 --> Controller Class Initialized
INFO - 2023-08-19 16:12:02 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:02 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:02 --> Model Class Initialized
INFO - 2023-08-19 16:12:02 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:02 --> Total execution time: 0.0705
ERROR - 2023-08-19 16:12:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:07 --> Config Class Initialized
INFO - 2023-08-19 16:12:07 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:07 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:07 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:07 --> URI Class Initialized
INFO - 2023-08-19 16:12:07 --> Router Class Initialized
INFO - 2023-08-19 16:12:07 --> Output Class Initialized
INFO - 2023-08-19 16:12:07 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:07 --> Input Class Initialized
INFO - 2023-08-19 16:12:07 --> Language Class Initialized
INFO - 2023-08-19 16:12:07 --> Loader Class Initialized
INFO - 2023-08-19 16:12:07 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:07 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:07 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:07 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:07 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:07 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:07 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:07 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:07 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:07 --> Parser Class Initialized
INFO - 2023-08-19 16:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:07 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:07 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:07 --> Controller Class Initialized
INFO - 2023-08-19 16:12:07 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:07 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:07 --> Model Class Initialized
INFO - 2023-08-19 16:12:07 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:07 --> Total execution time: 0.6395
ERROR - 2023-08-19 16:12:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:20 --> Config Class Initialized
INFO - 2023-08-19 16:12:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:20 --> URI Class Initialized
INFO - 2023-08-19 16:12:20 --> Router Class Initialized
INFO - 2023-08-19 16:12:20 --> Output Class Initialized
INFO - 2023-08-19 16:12:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:20 --> Input Class Initialized
INFO - 2023-08-19 16:12:20 --> Language Class Initialized
INFO - 2023-08-19 16:12:20 --> Loader Class Initialized
INFO - 2023-08-19 16:12:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:20 --> Parser Class Initialized
INFO - 2023-08-19 16:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:20 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:20 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:20 --> Controller Class Initialized
INFO - 2023-08-19 16:12:20 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:20 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-08-19 16:12:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:12:20 --> Model Class Initialized
INFO - 2023-08-19 16:12:20 --> Model Class Initialized
INFO - 2023-08-19 16:12:20 --> Model Class Initialized
INFO - 2023-08-19 16:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:12:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:20 --> Total execution time: 0.1387
ERROR - 2023-08-19 16:12:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:23 --> Config Class Initialized
INFO - 2023-08-19 16:12:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:23 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:23 --> URI Class Initialized
INFO - 2023-08-19 16:12:23 --> Router Class Initialized
INFO - 2023-08-19 16:12:23 --> Output Class Initialized
INFO - 2023-08-19 16:12:23 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:23 --> Input Class Initialized
INFO - 2023-08-19 16:12:23 --> Language Class Initialized
INFO - 2023-08-19 16:12:23 --> Loader Class Initialized
INFO - 2023-08-19 16:12:23 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:23 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:23 --> Parser Class Initialized
INFO - 2023-08-19 16:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:23 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:23 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:23 --> Controller Class Initialized
INFO - 2023-08-19 16:12:23 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:23 --> Model Class Initialized
INFO - 2023-08-19 16:12:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-08-19 16:12:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:12:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:12:23 --> Model Class Initialized
INFO - 2023-08-19 16:12:23 --> Model Class Initialized
INFO - 2023-08-19 16:12:23 --> Model Class Initialized
INFO - 2023-08-19 16:12:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:12:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:12:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:12:23 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:23 --> Total execution time: 0.1294
ERROR - 2023-08-19 16:12:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:24 --> Config Class Initialized
INFO - 2023-08-19 16:12:24 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:24 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:24 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:24 --> URI Class Initialized
INFO - 2023-08-19 16:12:24 --> Router Class Initialized
INFO - 2023-08-19 16:12:24 --> Output Class Initialized
INFO - 2023-08-19 16:12:24 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:24 --> Input Class Initialized
INFO - 2023-08-19 16:12:24 --> Language Class Initialized
INFO - 2023-08-19 16:12:24 --> Loader Class Initialized
INFO - 2023-08-19 16:12:24 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:24 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:24 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:24 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:24 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:24 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:24 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:24 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:24 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:24 --> Parser Class Initialized
INFO - 2023-08-19 16:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:24 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:24 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:24 --> Controller Class Initialized
INFO - 2023-08-19 16:12:24 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:24 --> Model Class Initialized
INFO - 2023-08-19 16:12:24 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:24 --> Total execution time: 0.0205
ERROR - 2023-08-19 16:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:26 --> Config Class Initialized
INFO - 2023-08-19 16:12:26 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:26 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:26 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:26 --> URI Class Initialized
INFO - 2023-08-19 16:12:26 --> Router Class Initialized
INFO - 2023-08-19 16:12:26 --> Output Class Initialized
INFO - 2023-08-19 16:12:26 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:26 --> Input Class Initialized
INFO - 2023-08-19 16:12:26 --> Language Class Initialized
INFO - 2023-08-19 16:12:26 --> Loader Class Initialized
INFO - 2023-08-19 16:12:26 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:26 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:26 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:26 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:26 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:26 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:26 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:26 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:26 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:26 --> Parser Class Initialized
INFO - 2023-08-19 16:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:26 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:26 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:26 --> Controller Class Initialized
INFO - 2023-08-19 16:12:26 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:26 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-08-19 16:12:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:12:26 --> Model Class Initialized
INFO - 2023-08-19 16:12:26 --> Model Class Initialized
INFO - 2023-08-19 16:12:26 --> Model Class Initialized
INFO - 2023-08-19 16:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:12:27 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:27 --> Total execution time: 0.1531
ERROR - 2023-08-19 16:12:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:30 --> Config Class Initialized
INFO - 2023-08-19 16:12:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:30 --> URI Class Initialized
INFO - 2023-08-19 16:12:30 --> Router Class Initialized
INFO - 2023-08-19 16:12:30 --> Output Class Initialized
INFO - 2023-08-19 16:12:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:30 --> Input Class Initialized
INFO - 2023-08-19 16:12:30 --> Language Class Initialized
INFO - 2023-08-19 16:12:30 --> Loader Class Initialized
INFO - 2023-08-19 16:12:30 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:30 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:30 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:30 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:30 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:30 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:30 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:30 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:30 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:30 --> Parser Class Initialized
INFO - 2023-08-19 16:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:30 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:30 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:30 --> Controller Class Initialized
INFO - 2023-08-19 16:12:30 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:30 --> Model Class Initialized
INFO - 2023-08-19 16:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-08-19 16:12:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:12:30 --> Model Class Initialized
INFO - 2023-08-19 16:12:30 --> Model Class Initialized
INFO - 2023-08-19 16:12:30 --> Model Class Initialized
INFO - 2023-08-19 16:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:12:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:12:30 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:30 --> Total execution time: 0.1323
ERROR - 2023-08-19 16:12:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:31 --> Config Class Initialized
INFO - 2023-08-19 16:12:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:31 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:31 --> URI Class Initialized
INFO - 2023-08-19 16:12:31 --> Router Class Initialized
INFO - 2023-08-19 16:12:31 --> Output Class Initialized
INFO - 2023-08-19 16:12:31 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:31 --> Input Class Initialized
INFO - 2023-08-19 16:12:31 --> Language Class Initialized
INFO - 2023-08-19 16:12:31 --> Loader Class Initialized
INFO - 2023-08-19 16:12:31 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:31 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:31 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:31 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:31 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:31 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:31 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:31 --> Parser Class Initialized
INFO - 2023-08-19 16:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:31 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:31 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:31 --> Controller Class Initialized
INFO - 2023-08-19 16:12:31 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:31 --> Model Class Initialized
INFO - 2023-08-19 16:12:31 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:31 --> Total execution time: 0.0220
ERROR - 2023-08-19 16:12:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:38 --> Config Class Initialized
INFO - 2023-08-19 16:12:38 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:38 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:38 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:38 --> URI Class Initialized
INFO - 2023-08-19 16:12:38 --> Router Class Initialized
INFO - 2023-08-19 16:12:38 --> Output Class Initialized
INFO - 2023-08-19 16:12:38 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:38 --> Input Class Initialized
INFO - 2023-08-19 16:12:38 --> Language Class Initialized
INFO - 2023-08-19 16:12:38 --> Loader Class Initialized
INFO - 2023-08-19 16:12:38 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:38 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:38 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:38 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:38 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:38 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:38 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:38 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:38 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:38 --> Parser Class Initialized
INFO - 2023-08-19 16:12:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:38 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:38 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:38 --> Controller Class Initialized
INFO - 2023-08-19 16:12:38 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:38 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-08-19 16:12:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:12:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:12:38 --> Model Class Initialized
INFO - 2023-08-19 16:12:38 --> Model Class Initialized
INFO - 2023-08-19 16:12:38 --> Model Class Initialized
INFO - 2023-08-19 16:12:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:12:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:12:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:12:38 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:38 --> Total execution time: 0.1575
ERROR - 2023-08-19 16:12:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:42 --> Config Class Initialized
INFO - 2023-08-19 16:12:42 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:42 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:42 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:42 --> URI Class Initialized
INFO - 2023-08-19 16:12:42 --> Router Class Initialized
INFO - 2023-08-19 16:12:42 --> Output Class Initialized
INFO - 2023-08-19 16:12:42 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:42 --> Input Class Initialized
INFO - 2023-08-19 16:12:42 --> Language Class Initialized
INFO - 2023-08-19 16:12:42 --> Loader Class Initialized
INFO - 2023-08-19 16:12:42 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:42 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:42 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:42 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:42 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:42 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:42 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:42 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:42 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:42 --> Parser Class Initialized
INFO - 2023-08-19 16:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:42 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:42 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:42 --> Controller Class Initialized
INFO - 2023-08-19 16:12:42 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:42 --> Model Class Initialized
INFO - 2023-08-19 16:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-19 16:12:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:12:42 --> Model Class Initialized
INFO - 2023-08-19 16:12:42 --> Model Class Initialized
INFO - 2023-08-19 16:12:42 --> Model Class Initialized
INFO - 2023-08-19 16:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:12:42 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:42 --> Total execution time: 0.1353
ERROR - 2023-08-19 16:12:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:43 --> Config Class Initialized
INFO - 2023-08-19 16:12:43 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:43 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:43 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:43 --> URI Class Initialized
INFO - 2023-08-19 16:12:43 --> Router Class Initialized
INFO - 2023-08-19 16:12:43 --> Output Class Initialized
INFO - 2023-08-19 16:12:43 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:43 --> Input Class Initialized
INFO - 2023-08-19 16:12:43 --> Language Class Initialized
INFO - 2023-08-19 16:12:43 --> Loader Class Initialized
INFO - 2023-08-19 16:12:43 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:43 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:43 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:43 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:43 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:43 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:43 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:43 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:43 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:43 --> Parser Class Initialized
INFO - 2023-08-19 16:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:43 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:43 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:43 --> Controller Class Initialized
INFO - 2023-08-19 16:12:43 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:43 --> Model Class Initialized
INFO - 2023-08-19 16:12:43 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:43 --> Total execution time: 0.0264
ERROR - 2023-08-19 16:12:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:12:47 --> Config Class Initialized
INFO - 2023-08-19 16:12:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:12:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:12:47 --> Utf8 Class Initialized
INFO - 2023-08-19 16:12:47 --> URI Class Initialized
INFO - 2023-08-19 16:12:47 --> Router Class Initialized
INFO - 2023-08-19 16:12:47 --> Output Class Initialized
INFO - 2023-08-19 16:12:47 --> Security Class Initialized
DEBUG - 2023-08-19 16:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:12:47 --> Input Class Initialized
INFO - 2023-08-19 16:12:47 --> Language Class Initialized
INFO - 2023-08-19 16:12:47 --> Loader Class Initialized
INFO - 2023-08-19 16:12:47 --> Helper loaded: url_helper
INFO - 2023-08-19 16:12:47 --> Helper loaded: file_helper
INFO - 2023-08-19 16:12:47 --> Helper loaded: html_helper
INFO - 2023-08-19 16:12:47 --> Helper loaded: text_helper
INFO - 2023-08-19 16:12:47 --> Helper loaded: form_helper
INFO - 2023-08-19 16:12:47 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:12:47 --> Helper loaded: security_helper
INFO - 2023-08-19 16:12:47 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:12:47 --> Database Driver Class Initialized
INFO - 2023-08-19 16:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:12:47 --> Parser Class Initialized
INFO - 2023-08-19 16:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:12:47 --> Pagination Class Initialized
INFO - 2023-08-19 16:12:47 --> Form Validation Class Initialized
INFO - 2023-08-19 16:12:47 --> Controller Class Initialized
INFO - 2023-08-19 16:12:47 --> Model Class Initialized
DEBUG - 2023-08-19 16:12:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:12:47 --> Model Class Initialized
INFO - 2023-08-19 16:12:47 --> Final output sent to browser
DEBUG - 2023-08-19 16:12:47 --> Total execution time: 0.0867
ERROR - 2023-08-19 16:13:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:13:12 --> Config Class Initialized
INFO - 2023-08-19 16:13:12 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:12 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:12 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:12 --> URI Class Initialized
INFO - 2023-08-19 16:13:12 --> Router Class Initialized
INFO - 2023-08-19 16:13:12 --> Output Class Initialized
INFO - 2023-08-19 16:13:12 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:12 --> Input Class Initialized
INFO - 2023-08-19 16:13:12 --> Language Class Initialized
INFO - 2023-08-19 16:13:12 --> Loader Class Initialized
INFO - 2023-08-19 16:13:12 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:12 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:12 --> Helper loaded: html_helper
INFO - 2023-08-19 16:13:12 --> Helper loaded: text_helper
INFO - 2023-08-19 16:13:12 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:12 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:13:12 --> Helper loaded: security_helper
INFO - 2023-08-19 16:13:12 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:13:12 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:12 --> Parser Class Initialized
INFO - 2023-08-19 16:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:13:12 --> Pagination Class Initialized
INFO - 2023-08-19 16:13:12 --> Form Validation Class Initialized
INFO - 2023-08-19 16:13:12 --> Controller Class Initialized
INFO - 2023-08-19 16:13:12 --> Model Class Initialized
DEBUG - 2023-08-19 16:13:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:12 --> Model Class Initialized
INFO - 2023-08-19 16:13:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-08-19 16:13:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:13:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:13:12 --> Model Class Initialized
INFO - 2023-08-19 16:13:12 --> Model Class Initialized
INFO - 2023-08-19 16:13:12 --> Model Class Initialized
INFO - 2023-08-19 16:13:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:13:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:13:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:13:12 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:12 --> Total execution time: 0.1530
ERROR - 2023-08-19 16:13:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:13:13 --> Config Class Initialized
INFO - 2023-08-19 16:13:13 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:13 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:13 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:13 --> URI Class Initialized
INFO - 2023-08-19 16:13:13 --> Router Class Initialized
INFO - 2023-08-19 16:13:13 --> Output Class Initialized
INFO - 2023-08-19 16:13:13 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:13 --> Input Class Initialized
INFO - 2023-08-19 16:13:13 --> Language Class Initialized
INFO - 2023-08-19 16:13:13 --> Loader Class Initialized
INFO - 2023-08-19 16:13:13 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:13 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:13 --> Helper loaded: html_helper
INFO - 2023-08-19 16:13:13 --> Helper loaded: text_helper
INFO - 2023-08-19 16:13:13 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:13 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:13:13 --> Helper loaded: security_helper
INFO - 2023-08-19 16:13:13 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:13:13 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:13 --> Parser Class Initialized
INFO - 2023-08-19 16:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:13:13 --> Pagination Class Initialized
INFO - 2023-08-19 16:13:13 --> Form Validation Class Initialized
INFO - 2023-08-19 16:13:13 --> Controller Class Initialized
INFO - 2023-08-19 16:13:13 --> Model Class Initialized
DEBUG - 2023-08-19 16:13:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:13 --> Model Class Initialized
INFO - 2023-08-19 16:13:13 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:13 --> Total execution time: 0.0301
ERROR - 2023-08-19 16:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:13:18 --> Config Class Initialized
INFO - 2023-08-19 16:13:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:18 --> URI Class Initialized
INFO - 2023-08-19 16:13:18 --> Router Class Initialized
INFO - 2023-08-19 16:13:18 --> Output Class Initialized
INFO - 2023-08-19 16:13:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:18 --> Input Class Initialized
INFO - 2023-08-19 16:13:18 --> Language Class Initialized
INFO - 2023-08-19 16:13:18 --> Loader Class Initialized
INFO - 2023-08-19 16:13:18 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: html_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: text_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: security_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:13:18 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:18 --> Parser Class Initialized
INFO - 2023-08-19 16:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:13:18 --> Pagination Class Initialized
INFO - 2023-08-19 16:13:18 --> Form Validation Class Initialized
INFO - 2023-08-19 16:13:18 --> Controller Class Initialized
DEBUG - 2023-08-19 16:13:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
DEBUG - 2023-08-19 16:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
DEBUG - 2023-08-19 16:13:18 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
INFO - 2023-08-19 16:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 16:13:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
INFO - 2023-08-19 16:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:13:18 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:18 --> Total execution time: 0.1504
ERROR - 2023-08-19 16:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:13:18 --> Config Class Initialized
INFO - 2023-08-19 16:13:18 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:18 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:18 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:18 --> URI Class Initialized
INFO - 2023-08-19 16:13:18 --> Router Class Initialized
INFO - 2023-08-19 16:13:18 --> Output Class Initialized
INFO - 2023-08-19 16:13:18 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:18 --> Input Class Initialized
INFO - 2023-08-19 16:13:18 --> Language Class Initialized
INFO - 2023-08-19 16:13:18 --> Loader Class Initialized
INFO - 2023-08-19 16:13:18 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: html_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: text_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: security_helper
INFO - 2023-08-19 16:13:18 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:13:18 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:18 --> Parser Class Initialized
INFO - 2023-08-19 16:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:13:18 --> Pagination Class Initialized
INFO - 2023-08-19 16:13:18 --> Form Validation Class Initialized
INFO - 2023-08-19 16:13:18 --> Controller Class Initialized
DEBUG - 2023-08-19 16:13:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
DEBUG - 2023-08-19 16:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:18 --> Model Class Initialized
INFO - 2023-08-19 16:13:18 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:18 --> Total execution time: 0.0347
ERROR - 2023-08-19 16:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:13:25 --> Config Class Initialized
INFO - 2023-08-19 16:13:25 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:25 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:25 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:25 --> URI Class Initialized
INFO - 2023-08-19 16:13:25 --> Router Class Initialized
INFO - 2023-08-19 16:13:25 --> Output Class Initialized
INFO - 2023-08-19 16:13:25 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:25 --> Input Class Initialized
INFO - 2023-08-19 16:13:25 --> Language Class Initialized
INFO - 2023-08-19 16:13:25 --> Loader Class Initialized
INFO - 2023-08-19 16:13:25 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:25 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:25 --> Helper loaded: html_helper
INFO - 2023-08-19 16:13:25 --> Helper loaded: text_helper
INFO - 2023-08-19 16:13:25 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:25 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:13:25 --> Helper loaded: security_helper
INFO - 2023-08-19 16:13:25 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:13:25 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:25 --> Parser Class Initialized
INFO - 2023-08-19 16:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:13:25 --> Pagination Class Initialized
INFO - 2023-08-19 16:13:25 --> Form Validation Class Initialized
INFO - 2023-08-19 16:13:25 --> Controller Class Initialized
DEBUG - 2023-08-19 16:13:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:25 --> Model Class Initialized
DEBUG - 2023-08-19 16:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:25 --> Model Class Initialized
INFO - 2023-08-19 16:13:25 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:25 --> Total execution time: 0.1478
ERROR - 2023-08-19 16:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:13:47 --> Config Class Initialized
INFO - 2023-08-19 16:13:47 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:13:47 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:13:47 --> Utf8 Class Initialized
INFO - 2023-08-19 16:13:47 --> URI Class Initialized
INFO - 2023-08-19 16:13:47 --> Router Class Initialized
INFO - 2023-08-19 16:13:47 --> Output Class Initialized
INFO - 2023-08-19 16:13:47 --> Security Class Initialized
DEBUG - 2023-08-19 16:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:13:47 --> Input Class Initialized
INFO - 2023-08-19 16:13:47 --> Language Class Initialized
INFO - 2023-08-19 16:13:47 --> Loader Class Initialized
INFO - 2023-08-19 16:13:47 --> Helper loaded: url_helper
INFO - 2023-08-19 16:13:47 --> Helper loaded: file_helper
INFO - 2023-08-19 16:13:47 --> Helper loaded: html_helper
INFO - 2023-08-19 16:13:47 --> Helper loaded: text_helper
INFO - 2023-08-19 16:13:47 --> Helper loaded: form_helper
INFO - 2023-08-19 16:13:47 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:13:47 --> Helper loaded: security_helper
INFO - 2023-08-19 16:13:47 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:13:47 --> Database Driver Class Initialized
INFO - 2023-08-19 16:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:13:47 --> Parser Class Initialized
INFO - 2023-08-19 16:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:13:47 --> Pagination Class Initialized
INFO - 2023-08-19 16:13:47 --> Form Validation Class Initialized
INFO - 2023-08-19 16:13:47 --> Controller Class Initialized
DEBUG - 2023-08-19 16:13:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:47 --> Model Class Initialized
DEBUG - 2023-08-19 16:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:47 --> Model Class Initialized
INFO - 2023-08-19 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-08-19 16:13:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:13:47 --> Model Class Initialized
INFO - 2023-08-19 16:13:47 --> Model Class Initialized
INFO - 2023-08-19 16:13:47 --> Model Class Initialized
INFO - 2023-08-19 16:13:47 --> Model Class Initialized
INFO - 2023-08-19 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:13:47 --> Final output sent to browser
DEBUG - 2023-08-19 16:13:47 --> Total execution time: 0.1515
ERROR - 2023-08-19 16:15:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:15:00 --> Config Class Initialized
INFO - 2023-08-19 16:15:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:15:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:15:00 --> Utf8 Class Initialized
INFO - 2023-08-19 16:15:00 --> URI Class Initialized
INFO - 2023-08-19 16:15:00 --> Router Class Initialized
INFO - 2023-08-19 16:15:00 --> Output Class Initialized
INFO - 2023-08-19 16:15:00 --> Security Class Initialized
DEBUG - 2023-08-19 16:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:15:00 --> Input Class Initialized
INFO - 2023-08-19 16:15:00 --> Language Class Initialized
INFO - 2023-08-19 16:15:00 --> Loader Class Initialized
INFO - 2023-08-19 16:15:00 --> Helper loaded: url_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: file_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: html_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: text_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: form_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: security_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:15:00 --> Database Driver Class Initialized
INFO - 2023-08-19 16:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:15:00 --> Parser Class Initialized
INFO - 2023-08-19 16:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:15:00 --> Pagination Class Initialized
INFO - 2023-08-19 16:15:00 --> Form Validation Class Initialized
INFO - 2023-08-19 16:15:00 --> Controller Class Initialized
DEBUG - 2023-08-19 16:15:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
DEBUG - 2023-08-19 16:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
ERROR - 2023-08-19 16:15:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:15:00 --> Config Class Initialized
INFO - 2023-08-19 16:15:00 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:15:00 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:15:00 --> Utf8 Class Initialized
INFO - 2023-08-19 16:15:00 --> URI Class Initialized
INFO - 2023-08-19 16:15:00 --> Router Class Initialized
INFO - 2023-08-19 16:15:00 --> Output Class Initialized
INFO - 2023-08-19 16:15:00 --> Security Class Initialized
DEBUG - 2023-08-19 16:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:15:00 --> Input Class Initialized
INFO - 2023-08-19 16:15:00 --> Language Class Initialized
INFO - 2023-08-19 16:15:00 --> Loader Class Initialized
INFO - 2023-08-19 16:15:00 --> Helper loaded: url_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: file_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: html_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: text_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: form_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: security_helper
INFO - 2023-08-19 16:15:00 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:15:00 --> Database Driver Class Initialized
INFO - 2023-08-19 16:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:15:00 --> Parser Class Initialized
INFO - 2023-08-19 16:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:15:00 --> Pagination Class Initialized
INFO - 2023-08-19 16:15:00 --> Form Validation Class Initialized
INFO - 2023-08-19 16:15:00 --> Controller Class Initialized
DEBUG - 2023-08-19 16:15:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
DEBUG - 2023-08-19 16:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
DEBUG - 2023-08-19 16:15:00 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
INFO - 2023-08-19 16:15:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-19 16:15:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:15:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
INFO - 2023-08-19 16:15:00 --> Model Class Initialized
INFO - 2023-08-19 16:15:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:15:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:15:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:15:00 --> Final output sent to browser
DEBUG - 2023-08-19 16:15:00 --> Total execution time: 0.1505
ERROR - 2023-08-19 16:15:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:15:01 --> Config Class Initialized
INFO - 2023-08-19 16:15:01 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:15:01 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:15:01 --> Utf8 Class Initialized
INFO - 2023-08-19 16:15:01 --> URI Class Initialized
INFO - 2023-08-19 16:15:01 --> Router Class Initialized
INFO - 2023-08-19 16:15:01 --> Output Class Initialized
INFO - 2023-08-19 16:15:01 --> Security Class Initialized
DEBUG - 2023-08-19 16:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:15:01 --> Input Class Initialized
INFO - 2023-08-19 16:15:01 --> Language Class Initialized
INFO - 2023-08-19 16:15:01 --> Loader Class Initialized
INFO - 2023-08-19 16:15:01 --> Helper loaded: url_helper
INFO - 2023-08-19 16:15:01 --> Helper loaded: file_helper
INFO - 2023-08-19 16:15:01 --> Helper loaded: html_helper
INFO - 2023-08-19 16:15:01 --> Helper loaded: text_helper
INFO - 2023-08-19 16:15:01 --> Helper loaded: form_helper
INFO - 2023-08-19 16:15:01 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:15:01 --> Helper loaded: security_helper
INFO - 2023-08-19 16:15:01 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:15:01 --> Database Driver Class Initialized
INFO - 2023-08-19 16:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:15:01 --> Parser Class Initialized
INFO - 2023-08-19 16:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:15:01 --> Pagination Class Initialized
INFO - 2023-08-19 16:15:01 --> Form Validation Class Initialized
INFO - 2023-08-19 16:15:01 --> Controller Class Initialized
DEBUG - 2023-08-19 16:15:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:01 --> Model Class Initialized
DEBUG - 2023-08-19 16:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:15:01 --> Model Class Initialized
INFO - 2023-08-19 16:15:01 --> Final output sent to browser
DEBUG - 2023-08-19 16:15:01 --> Total execution time: 0.0312
ERROR - 2023-08-19 16:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:19:59 --> Config Class Initialized
INFO - 2023-08-19 16:19:59 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:19:59 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:19:59 --> Utf8 Class Initialized
INFO - 2023-08-19 16:19:59 --> URI Class Initialized
INFO - 2023-08-19 16:19:59 --> Router Class Initialized
INFO - 2023-08-19 16:19:59 --> Output Class Initialized
INFO - 2023-08-19 16:19:59 --> Security Class Initialized
DEBUG - 2023-08-19 16:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:19:59 --> Input Class Initialized
INFO - 2023-08-19 16:19:59 --> Language Class Initialized
INFO - 2023-08-19 16:19:59 --> Loader Class Initialized
INFO - 2023-08-19 16:19:59 --> Helper loaded: url_helper
INFO - 2023-08-19 16:19:59 --> Helper loaded: file_helper
INFO - 2023-08-19 16:19:59 --> Helper loaded: html_helper
INFO - 2023-08-19 16:19:59 --> Helper loaded: text_helper
INFO - 2023-08-19 16:19:59 --> Helper loaded: form_helper
INFO - 2023-08-19 16:19:59 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:19:59 --> Helper loaded: security_helper
INFO - 2023-08-19 16:19:59 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:19:59 --> Database Driver Class Initialized
INFO - 2023-08-19 16:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:19:59 --> Parser Class Initialized
INFO - 2023-08-19 16:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:19:59 --> Pagination Class Initialized
INFO - 2023-08-19 16:19:59 --> Form Validation Class Initialized
INFO - 2023-08-19 16:19:59 --> Controller Class Initialized
DEBUG - 2023-08-19 16:19:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:19:59 --> Model Class Initialized
DEBUG - 2023-08-19 16:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:19:59 --> Model Class Initialized
INFO - 2023-08-19 16:20:00 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:00 --> Total execution time: 0.1532
ERROR - 2023-08-19 16:20:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:19 --> Config Class Initialized
INFO - 2023-08-19 16:20:19 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:19 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:19 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:19 --> URI Class Initialized
INFO - 2023-08-19 16:20:19 --> Router Class Initialized
INFO - 2023-08-19 16:20:19 --> Output Class Initialized
INFO - 2023-08-19 16:20:19 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:19 --> Input Class Initialized
INFO - 2023-08-19 16:20:19 --> Language Class Initialized
INFO - 2023-08-19 16:20:19 --> Loader Class Initialized
INFO - 2023-08-19 16:20:19 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:19 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:19 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:19 --> Parser Class Initialized
INFO - 2023-08-19 16:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:19 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:19 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:19 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:19 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:19 --> Model Class Initialized
INFO - 2023-08-19 16:20:19 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:19 --> Total execution time: 0.1166
ERROR - 2023-08-19 16:20:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:20 --> Config Class Initialized
INFO - 2023-08-19 16:20:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:20 --> URI Class Initialized
INFO - 2023-08-19 16:20:20 --> Router Class Initialized
INFO - 2023-08-19 16:20:20 --> Output Class Initialized
INFO - 2023-08-19 16:20:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:20 --> Input Class Initialized
INFO - 2023-08-19 16:20:20 --> Language Class Initialized
INFO - 2023-08-19 16:20:20 --> Loader Class Initialized
INFO - 2023-08-19 16:20:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:20 --> Parser Class Initialized
INFO - 2023-08-19 16:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:20 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:20 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:20 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:20 --> Model Class Initialized
INFO - 2023-08-19 16:20:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:20 --> Total execution time: 0.0331
ERROR - 2023-08-19 16:20:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:20 --> Config Class Initialized
INFO - 2023-08-19 16:20:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:20 --> URI Class Initialized
INFO - 2023-08-19 16:20:20 --> Router Class Initialized
INFO - 2023-08-19 16:20:20 --> Output Class Initialized
INFO - 2023-08-19 16:20:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:20 --> Input Class Initialized
INFO - 2023-08-19 16:20:20 --> Language Class Initialized
INFO - 2023-08-19 16:20:20 --> Loader Class Initialized
INFO - 2023-08-19 16:20:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:20 --> Parser Class Initialized
INFO - 2023-08-19 16:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:20 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:20 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:20 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:20 --> Model Class Initialized
INFO - 2023-08-19 16:20:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:20 --> Total execution time: 0.0210
ERROR - 2023-08-19 16:20:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:20 --> Config Class Initialized
INFO - 2023-08-19 16:20:20 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:20 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:20 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:20 --> URI Class Initialized
INFO - 2023-08-19 16:20:20 --> Router Class Initialized
INFO - 2023-08-19 16:20:20 --> Output Class Initialized
INFO - 2023-08-19 16:20:20 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:20 --> Input Class Initialized
INFO - 2023-08-19 16:20:20 --> Language Class Initialized
INFO - 2023-08-19 16:20:20 --> Loader Class Initialized
INFO - 2023-08-19 16:20:20 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:20 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:20 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:20 --> Parser Class Initialized
INFO - 2023-08-19 16:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:20 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:20 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:20 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:20 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:20 --> Model Class Initialized
INFO - 2023-08-19 16:20:20 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:20 --> Total execution time: 0.0184
ERROR - 2023-08-19 16:20:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:23 --> Config Class Initialized
INFO - 2023-08-19 16:20:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:23 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:23 --> URI Class Initialized
INFO - 2023-08-19 16:20:23 --> Router Class Initialized
INFO - 2023-08-19 16:20:23 --> Output Class Initialized
INFO - 2023-08-19 16:20:23 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:23 --> Input Class Initialized
INFO - 2023-08-19 16:20:23 --> Language Class Initialized
INFO - 2023-08-19 16:20:23 --> Loader Class Initialized
INFO - 2023-08-19 16:20:23 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:23 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:23 --> Parser Class Initialized
INFO - 2023-08-19 16:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:23 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:23 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:23 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:23 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:23 --> Model Class Initialized
INFO - 2023-08-19 16:20:23 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:23 --> Total execution time: 0.0201
ERROR - 2023-08-19 16:20:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:23 --> Config Class Initialized
INFO - 2023-08-19 16:20:23 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:23 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:23 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:23 --> URI Class Initialized
INFO - 2023-08-19 16:20:23 --> Router Class Initialized
INFO - 2023-08-19 16:20:23 --> Output Class Initialized
INFO - 2023-08-19 16:20:23 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:23 --> Input Class Initialized
INFO - 2023-08-19 16:20:23 --> Language Class Initialized
INFO - 2023-08-19 16:20:23 --> Loader Class Initialized
INFO - 2023-08-19 16:20:23 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:23 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:23 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:23 --> Parser Class Initialized
INFO - 2023-08-19 16:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:23 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:23 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:23 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:23 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:23 --> Model Class Initialized
INFO - 2023-08-19 16:20:23 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:23 --> Total execution time: 0.0228
ERROR - 2023-08-19 16:20:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:30 --> Config Class Initialized
INFO - 2023-08-19 16:20:30 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:30 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:30 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:30 --> URI Class Initialized
INFO - 2023-08-19 16:20:30 --> Router Class Initialized
INFO - 2023-08-19 16:20:30 --> Output Class Initialized
INFO - 2023-08-19 16:20:30 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:30 --> Input Class Initialized
INFO - 2023-08-19 16:20:30 --> Language Class Initialized
INFO - 2023-08-19 16:20:30 --> Loader Class Initialized
INFO - 2023-08-19 16:20:30 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:30 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:30 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:30 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:30 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:30 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:30 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:30 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:30 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:30 --> Parser Class Initialized
INFO - 2023-08-19 16:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:30 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:30 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:30 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:30 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:30 --> Model Class Initialized
INFO - 2023-08-19 16:20:30 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:30 --> Total execution time: 0.0434
ERROR - 2023-08-19 16:20:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:31 --> Config Class Initialized
INFO - 2023-08-19 16:20:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:31 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:31 --> URI Class Initialized
INFO - 2023-08-19 16:20:31 --> Router Class Initialized
INFO - 2023-08-19 16:20:31 --> Output Class Initialized
INFO - 2023-08-19 16:20:31 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:31 --> Input Class Initialized
INFO - 2023-08-19 16:20:31 --> Language Class Initialized
INFO - 2023-08-19 16:20:31 --> Loader Class Initialized
INFO - 2023-08-19 16:20:31 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:31 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:31 --> Parser Class Initialized
INFO - 2023-08-19 16:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:31 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:31 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:31 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:31 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:31 --> Model Class Initialized
INFO - 2023-08-19 16:20:31 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:31 --> Total execution time: 0.0499
ERROR - 2023-08-19 16:20:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:31 --> Config Class Initialized
INFO - 2023-08-19 16:20:31 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:31 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:31 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:31 --> URI Class Initialized
INFO - 2023-08-19 16:20:31 --> Router Class Initialized
INFO - 2023-08-19 16:20:31 --> Output Class Initialized
INFO - 2023-08-19 16:20:31 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:31 --> Input Class Initialized
INFO - 2023-08-19 16:20:31 --> Language Class Initialized
INFO - 2023-08-19 16:20:31 --> Loader Class Initialized
INFO - 2023-08-19 16:20:31 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:31 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:31 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:31 --> Parser Class Initialized
INFO - 2023-08-19 16:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:31 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:31 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:31 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:31 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:31 --> Model Class Initialized
INFO - 2023-08-19 16:20:31 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:31 --> Total execution time: 0.1445
ERROR - 2023-08-19 16:20:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:32 --> Config Class Initialized
INFO - 2023-08-19 16:20:32 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:32 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:32 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:32 --> URI Class Initialized
INFO - 2023-08-19 16:20:32 --> Router Class Initialized
INFO - 2023-08-19 16:20:32 --> Output Class Initialized
INFO - 2023-08-19 16:20:32 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:32 --> Input Class Initialized
INFO - 2023-08-19 16:20:32 --> Language Class Initialized
INFO - 2023-08-19 16:20:32 --> Loader Class Initialized
INFO - 2023-08-19 16:20:32 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:32 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:32 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:32 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:32 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:32 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:32 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:32 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:32 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:32 --> Parser Class Initialized
INFO - 2023-08-19 16:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:32 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:32 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:32 --> Controller Class Initialized
DEBUG - 2023-08-19 16:20:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:32 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:32 --> Model Class Initialized
INFO - 2023-08-19 16:20:32 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:32 --> Total execution time: 0.1561
ERROR - 2023-08-19 16:20:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:35 --> Config Class Initialized
INFO - 2023-08-19 16:20:35 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:35 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:35 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:35 --> URI Class Initialized
INFO - 2023-08-19 16:20:35 --> Router Class Initialized
INFO - 2023-08-19 16:20:35 --> Output Class Initialized
INFO - 2023-08-19 16:20:35 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:35 --> Input Class Initialized
INFO - 2023-08-19 16:20:35 --> Language Class Initialized
INFO - 2023-08-19 16:20:35 --> Loader Class Initialized
INFO - 2023-08-19 16:20:35 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:35 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:35 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:35 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:35 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:35 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:35 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:35 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:35 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:35 --> Parser Class Initialized
INFO - 2023-08-19 16:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:35 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:35 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:35 --> Controller Class Initialized
INFO - 2023-08-19 16:20:35 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:35 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:35 --> Model Class Initialized
INFO - 2023-08-19 16:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-19 16:20:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:20:35 --> Model Class Initialized
INFO - 2023-08-19 16:20:35 --> Model Class Initialized
INFO - 2023-08-19 16:20:35 --> Model Class Initialized
INFO - 2023-08-19 16:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:20:35 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:35 --> Total execution time: 0.1556
ERROR - 2023-08-19 16:20:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:36 --> Config Class Initialized
INFO - 2023-08-19 16:20:36 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:36 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:36 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:36 --> URI Class Initialized
INFO - 2023-08-19 16:20:36 --> Router Class Initialized
INFO - 2023-08-19 16:20:36 --> Output Class Initialized
INFO - 2023-08-19 16:20:36 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:36 --> Input Class Initialized
INFO - 2023-08-19 16:20:36 --> Language Class Initialized
INFO - 2023-08-19 16:20:36 --> Loader Class Initialized
INFO - 2023-08-19 16:20:36 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:36 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:36 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:36 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:36 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:36 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:36 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:36 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:36 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:36 --> Parser Class Initialized
INFO - 2023-08-19 16:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:36 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:36 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:36 --> Controller Class Initialized
INFO - 2023-08-19 16:20:36 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:36 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:36 --> Model Class Initialized
INFO - 2023-08-19 16:20:36 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:36 --> Total execution time: 0.0604
ERROR - 2023-08-19 16:20:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:39 --> Config Class Initialized
INFO - 2023-08-19 16:20:39 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:39 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:39 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:39 --> URI Class Initialized
INFO - 2023-08-19 16:20:39 --> Router Class Initialized
INFO - 2023-08-19 16:20:39 --> Output Class Initialized
INFO - 2023-08-19 16:20:39 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:39 --> Input Class Initialized
INFO - 2023-08-19 16:20:39 --> Language Class Initialized
INFO - 2023-08-19 16:20:39 --> Loader Class Initialized
INFO - 2023-08-19 16:20:39 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:39 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:39 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:39 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:39 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:39 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:39 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:39 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:39 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:39 --> Parser Class Initialized
INFO - 2023-08-19 16:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:39 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:39 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:39 --> Controller Class Initialized
INFO - 2023-08-19 16:20:39 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:39 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:39 --> Model Class Initialized
INFO - 2023-08-19 16:20:40 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:40 --> Total execution time: 0.0551
ERROR - 2023-08-19 16:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:40 --> Config Class Initialized
INFO - 2023-08-19 16:20:40 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:40 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:40 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:40 --> URI Class Initialized
INFO - 2023-08-19 16:20:40 --> Router Class Initialized
INFO - 2023-08-19 16:20:40 --> Output Class Initialized
INFO - 2023-08-19 16:20:40 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:40 --> Input Class Initialized
INFO - 2023-08-19 16:20:40 --> Language Class Initialized
INFO - 2023-08-19 16:20:40 --> Loader Class Initialized
INFO - 2023-08-19 16:20:40 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:40 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:40 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:40 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:40 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:40 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:40 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:40 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:40 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:40 --> Parser Class Initialized
INFO - 2023-08-19 16:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:40 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:40 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:40 --> Controller Class Initialized
INFO - 2023-08-19 16:20:40 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:40 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:40 --> Model Class Initialized
INFO - 2023-08-19 16:20:40 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:40 --> Total execution time: 0.0323
ERROR - 2023-08-19 16:20:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:41 --> Config Class Initialized
INFO - 2023-08-19 16:20:41 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:41 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:41 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:41 --> URI Class Initialized
INFO - 2023-08-19 16:20:41 --> Router Class Initialized
INFO - 2023-08-19 16:20:41 --> Output Class Initialized
INFO - 2023-08-19 16:20:41 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:41 --> Input Class Initialized
INFO - 2023-08-19 16:20:41 --> Language Class Initialized
INFO - 2023-08-19 16:20:41 --> Loader Class Initialized
INFO - 2023-08-19 16:20:41 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:41 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:41 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:41 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:41 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:41 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:41 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:41 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:41 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:41 --> Parser Class Initialized
INFO - 2023-08-19 16:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:41 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:41 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:41 --> Controller Class Initialized
INFO - 2023-08-19 16:20:41 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:41 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:41 --> Model Class Initialized
INFO - 2023-08-19 16:20:41 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:41 --> Total execution time: 0.0319
ERROR - 2023-08-19 16:20:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:49 --> Config Class Initialized
INFO - 2023-08-19 16:20:49 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:49 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:49 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:49 --> URI Class Initialized
INFO - 2023-08-19 16:20:49 --> Router Class Initialized
INFO - 2023-08-19 16:20:49 --> Output Class Initialized
INFO - 2023-08-19 16:20:49 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:49 --> Input Class Initialized
INFO - 2023-08-19 16:20:49 --> Language Class Initialized
INFO - 2023-08-19 16:20:49 --> Loader Class Initialized
INFO - 2023-08-19 16:20:49 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:49 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:49 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:49 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:49 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:49 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:49 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:49 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:49 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:49 --> Parser Class Initialized
INFO - 2023-08-19 16:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:49 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:49 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:49 --> Controller Class Initialized
INFO - 2023-08-19 16:20:49 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:49 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:49 --> Model Class Initialized
INFO - 2023-08-19 16:20:49 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:49 --> Total execution time: 0.0329
ERROR - 2023-08-19 16:20:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:50 --> Config Class Initialized
INFO - 2023-08-19 16:20:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:50 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:50 --> URI Class Initialized
INFO - 2023-08-19 16:20:50 --> Router Class Initialized
INFO - 2023-08-19 16:20:50 --> Output Class Initialized
INFO - 2023-08-19 16:20:50 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:50 --> Input Class Initialized
INFO - 2023-08-19 16:20:50 --> Language Class Initialized
INFO - 2023-08-19 16:20:50 --> Loader Class Initialized
INFO - 2023-08-19 16:20:50 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:50 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:50 --> Parser Class Initialized
INFO - 2023-08-19 16:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:50 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:50 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:50 --> Controller Class Initialized
INFO - 2023-08-19 16:20:50 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:50 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:50 --> Model Class Initialized
INFO - 2023-08-19 16:20:50 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:50 --> Total execution time: 0.0615
ERROR - 2023-08-19 16:20:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:50 --> Config Class Initialized
INFO - 2023-08-19 16:20:50 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:50 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:50 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:50 --> URI Class Initialized
INFO - 2023-08-19 16:20:50 --> Router Class Initialized
INFO - 2023-08-19 16:20:50 --> Output Class Initialized
INFO - 2023-08-19 16:20:50 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:50 --> Input Class Initialized
INFO - 2023-08-19 16:20:50 --> Language Class Initialized
INFO - 2023-08-19 16:20:50 --> Loader Class Initialized
INFO - 2023-08-19 16:20:50 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:50 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:50 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:50 --> Parser Class Initialized
INFO - 2023-08-19 16:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:50 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:50 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:50 --> Controller Class Initialized
INFO - 2023-08-19 16:20:50 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:50 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:50 --> Model Class Initialized
INFO - 2023-08-19 16:20:50 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:50 --> Total execution time: 0.0591
ERROR - 2023-08-19 16:20:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:51 --> Config Class Initialized
INFO - 2023-08-19 16:20:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:51 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:51 --> URI Class Initialized
INFO - 2023-08-19 16:20:51 --> Router Class Initialized
INFO - 2023-08-19 16:20:51 --> Output Class Initialized
INFO - 2023-08-19 16:20:51 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:51 --> Input Class Initialized
INFO - 2023-08-19 16:20:51 --> Language Class Initialized
INFO - 2023-08-19 16:20:51 --> Loader Class Initialized
INFO - 2023-08-19 16:20:51 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:51 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:51 --> Parser Class Initialized
INFO - 2023-08-19 16:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:51 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:51 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:51 --> Controller Class Initialized
INFO - 2023-08-19 16:20:51 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:51 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:51 --> Model Class Initialized
INFO - 2023-08-19 16:20:51 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:51 --> Total execution time: 0.0520
ERROR - 2023-08-19 16:20:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:51 --> Config Class Initialized
INFO - 2023-08-19 16:20:51 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:51 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:51 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:51 --> URI Class Initialized
INFO - 2023-08-19 16:20:51 --> Router Class Initialized
INFO - 2023-08-19 16:20:51 --> Output Class Initialized
INFO - 2023-08-19 16:20:51 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:51 --> Input Class Initialized
INFO - 2023-08-19 16:20:51 --> Language Class Initialized
INFO - 2023-08-19 16:20:51 --> Loader Class Initialized
INFO - 2023-08-19 16:20:51 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:51 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:51 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:51 --> Parser Class Initialized
INFO - 2023-08-19 16:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:51 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:51 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:51 --> Controller Class Initialized
INFO - 2023-08-19 16:20:51 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:51 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:51 --> Model Class Initialized
INFO - 2023-08-19 16:20:51 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:51 --> Total execution time: 0.0510
ERROR - 2023-08-19 16:20:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:52 --> Config Class Initialized
INFO - 2023-08-19 16:20:52 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:52 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:52 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:52 --> URI Class Initialized
INFO - 2023-08-19 16:20:52 --> Router Class Initialized
INFO - 2023-08-19 16:20:52 --> Output Class Initialized
INFO - 2023-08-19 16:20:52 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:52 --> Input Class Initialized
INFO - 2023-08-19 16:20:52 --> Language Class Initialized
INFO - 2023-08-19 16:20:52 --> Loader Class Initialized
INFO - 2023-08-19 16:20:52 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:52 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:52 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:52 --> Parser Class Initialized
INFO - 2023-08-19 16:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:52 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:52 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:52 --> Controller Class Initialized
INFO - 2023-08-19 16:20:52 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:52 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:52 --> Model Class Initialized
INFO - 2023-08-19 16:20:52 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:52 --> Total execution time: 0.0214
ERROR - 2023-08-19 16:20:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:53 --> Config Class Initialized
INFO - 2023-08-19 16:20:53 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:53 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:53 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:53 --> URI Class Initialized
INFO - 2023-08-19 16:20:53 --> Router Class Initialized
INFO - 2023-08-19 16:20:53 --> Output Class Initialized
INFO - 2023-08-19 16:20:53 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:53 --> Input Class Initialized
INFO - 2023-08-19 16:20:53 --> Language Class Initialized
INFO - 2023-08-19 16:20:53 --> Loader Class Initialized
INFO - 2023-08-19 16:20:53 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:53 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:53 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:53 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:53 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:53 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:53 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:53 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:53 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:53 --> Parser Class Initialized
INFO - 2023-08-19 16:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:53 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:53 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:53 --> Controller Class Initialized
INFO - 2023-08-19 16:20:53 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:53 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:53 --> Model Class Initialized
INFO - 2023-08-19 16:20:53 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:53 --> Total execution time: 0.0221
ERROR - 2023-08-19 16:20:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:54 --> Config Class Initialized
INFO - 2023-08-19 16:20:54 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:54 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:54 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:54 --> URI Class Initialized
INFO - 2023-08-19 16:20:54 --> Router Class Initialized
INFO - 2023-08-19 16:20:54 --> Output Class Initialized
INFO - 2023-08-19 16:20:54 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:54 --> Input Class Initialized
INFO - 2023-08-19 16:20:54 --> Language Class Initialized
INFO - 2023-08-19 16:20:54 --> Loader Class Initialized
INFO - 2023-08-19 16:20:54 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:54 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:54 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:54 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:54 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:54 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:54 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:54 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:54 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:54 --> Parser Class Initialized
INFO - 2023-08-19 16:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:54 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:54 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:54 --> Controller Class Initialized
INFO - 2023-08-19 16:20:54 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:54 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:54 --> Model Class Initialized
INFO - 2023-08-19 16:20:54 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:54 --> Total execution time: 0.0218
ERROR - 2023-08-19 16:20:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:20:55 --> Config Class Initialized
INFO - 2023-08-19 16:20:55 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:20:55 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:20:55 --> Utf8 Class Initialized
INFO - 2023-08-19 16:20:55 --> URI Class Initialized
INFO - 2023-08-19 16:20:55 --> Router Class Initialized
INFO - 2023-08-19 16:20:55 --> Output Class Initialized
INFO - 2023-08-19 16:20:55 --> Security Class Initialized
DEBUG - 2023-08-19 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:20:55 --> Input Class Initialized
INFO - 2023-08-19 16:20:55 --> Language Class Initialized
INFO - 2023-08-19 16:20:55 --> Loader Class Initialized
INFO - 2023-08-19 16:20:55 --> Helper loaded: url_helper
INFO - 2023-08-19 16:20:55 --> Helper loaded: file_helper
INFO - 2023-08-19 16:20:55 --> Helper loaded: html_helper
INFO - 2023-08-19 16:20:55 --> Helper loaded: text_helper
INFO - 2023-08-19 16:20:55 --> Helper loaded: form_helper
INFO - 2023-08-19 16:20:55 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:20:55 --> Helper loaded: security_helper
INFO - 2023-08-19 16:20:55 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:20:55 --> Database Driver Class Initialized
INFO - 2023-08-19 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:20:55 --> Parser Class Initialized
INFO - 2023-08-19 16:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:20:55 --> Pagination Class Initialized
INFO - 2023-08-19 16:20:55 --> Form Validation Class Initialized
INFO - 2023-08-19 16:20:55 --> Controller Class Initialized
INFO - 2023-08-19 16:20:55 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:55 --> Model Class Initialized
DEBUG - 2023-08-19 16:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:20:55 --> Model Class Initialized
INFO - 2023-08-19 16:20:55 --> Final output sent to browser
DEBUG - 2023-08-19 16:20:55 --> Total execution time: 0.0545
ERROR - 2023-08-19 16:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:21:04 --> Config Class Initialized
INFO - 2023-08-19 16:21:04 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:21:04 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:21:04 --> Utf8 Class Initialized
INFO - 2023-08-19 16:21:04 --> URI Class Initialized
INFO - 2023-08-19 16:21:04 --> Router Class Initialized
INFO - 2023-08-19 16:21:04 --> Output Class Initialized
INFO - 2023-08-19 16:21:04 --> Security Class Initialized
DEBUG - 2023-08-19 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:21:04 --> Input Class Initialized
INFO - 2023-08-19 16:21:04 --> Language Class Initialized
INFO - 2023-08-19 16:21:04 --> Loader Class Initialized
INFO - 2023-08-19 16:21:04 --> Helper loaded: url_helper
INFO - 2023-08-19 16:21:04 --> Helper loaded: file_helper
INFO - 2023-08-19 16:21:04 --> Helper loaded: html_helper
INFO - 2023-08-19 16:21:04 --> Helper loaded: text_helper
INFO - 2023-08-19 16:21:04 --> Helper loaded: form_helper
INFO - 2023-08-19 16:21:04 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:21:04 --> Helper loaded: security_helper
INFO - 2023-08-19 16:21:04 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:21:04 --> Database Driver Class Initialized
INFO - 2023-08-19 16:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:21:04 --> Parser Class Initialized
INFO - 2023-08-19 16:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:21:04 --> Pagination Class Initialized
INFO - 2023-08-19 16:21:04 --> Form Validation Class Initialized
INFO - 2023-08-19 16:21:04 --> Controller Class Initialized
INFO - 2023-08-19 16:21:04 --> Model Class Initialized
DEBUG - 2023-08-19 16:21:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:21:04 --> Model Class Initialized
DEBUG - 2023-08-19 16:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:21:04 --> Model Class Initialized
INFO - 2023-08-19 16:21:04 --> Final output sent to browser
DEBUG - 2023-08-19 16:21:04 --> Total execution time: 0.0942
ERROR - 2023-08-19 16:21:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 16:21:29 --> Config Class Initialized
INFO - 2023-08-19 16:21:29 --> Hooks Class Initialized
DEBUG - 2023-08-19 16:21:29 --> UTF-8 Support Enabled
INFO - 2023-08-19 16:21:29 --> Utf8 Class Initialized
INFO - 2023-08-19 16:21:29 --> URI Class Initialized
DEBUG - 2023-08-19 16:21:29 --> No URI present. Default controller set.
INFO - 2023-08-19 16:21:29 --> Router Class Initialized
INFO - 2023-08-19 16:21:29 --> Output Class Initialized
INFO - 2023-08-19 16:21:29 --> Security Class Initialized
DEBUG - 2023-08-19 16:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 16:21:29 --> Input Class Initialized
INFO - 2023-08-19 16:21:29 --> Language Class Initialized
INFO - 2023-08-19 16:21:29 --> Loader Class Initialized
INFO - 2023-08-19 16:21:29 --> Helper loaded: url_helper
INFO - 2023-08-19 16:21:29 --> Helper loaded: file_helper
INFO - 2023-08-19 16:21:29 --> Helper loaded: html_helper
INFO - 2023-08-19 16:21:29 --> Helper loaded: text_helper
INFO - 2023-08-19 16:21:29 --> Helper loaded: form_helper
INFO - 2023-08-19 16:21:29 --> Helper loaded: lang_helper
INFO - 2023-08-19 16:21:29 --> Helper loaded: security_helper
INFO - 2023-08-19 16:21:29 --> Helper loaded: cookie_helper
INFO - 2023-08-19 16:21:29 --> Database Driver Class Initialized
INFO - 2023-08-19 16:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 16:21:29 --> Parser Class Initialized
INFO - 2023-08-19 16:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 16:21:29 --> Pagination Class Initialized
INFO - 2023-08-19 16:21:29 --> Form Validation Class Initialized
INFO - 2023-08-19 16:21:29 --> Controller Class Initialized
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
DEBUG - 2023-08-19 16:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
DEBUG - 2023-08-19 16:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
DEBUG - 2023-08-19 16:21:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-19 16:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
INFO - 2023-08-19 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-19 16:21:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 16:21:29 --> Model Class Initialized
INFO - 2023-08-19 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-19 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-19 16:21:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 16:21:29 --> Final output sent to browser
DEBUG - 2023-08-19 16:21:29 --> Total execution time: 0.2062
ERROR - 2023-08-19 19:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 19:36:16 --> Config Class Initialized
INFO - 2023-08-19 19:36:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 19:36:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 19:36:16 --> Utf8 Class Initialized
INFO - 2023-08-19 19:36:16 --> URI Class Initialized
DEBUG - 2023-08-19 19:36:16 --> No URI present. Default controller set.
INFO - 2023-08-19 19:36:16 --> Router Class Initialized
INFO - 2023-08-19 19:36:16 --> Output Class Initialized
INFO - 2023-08-19 19:36:16 --> Security Class Initialized
DEBUG - 2023-08-19 19:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 19:36:16 --> Input Class Initialized
INFO - 2023-08-19 19:36:16 --> Language Class Initialized
INFO - 2023-08-19 19:36:16 --> Loader Class Initialized
INFO - 2023-08-19 19:36:16 --> Helper loaded: url_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: file_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: html_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: text_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: form_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: lang_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: security_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: cookie_helper
INFO - 2023-08-19 19:36:16 --> Database Driver Class Initialized
INFO - 2023-08-19 19:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 19:36:16 --> Parser Class Initialized
INFO - 2023-08-19 19:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 19:36:16 --> Pagination Class Initialized
INFO - 2023-08-19 19:36:16 --> Form Validation Class Initialized
INFO - 2023-08-19 19:36:16 --> Controller Class Initialized
INFO - 2023-08-19 19:36:16 --> Model Class Initialized
DEBUG - 2023-08-19 19:36:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-19 19:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-19 19:36:16 --> Config Class Initialized
INFO - 2023-08-19 19:36:16 --> Hooks Class Initialized
DEBUG - 2023-08-19 19:36:16 --> UTF-8 Support Enabled
INFO - 2023-08-19 19:36:16 --> Utf8 Class Initialized
INFO - 2023-08-19 19:36:16 --> URI Class Initialized
INFO - 2023-08-19 19:36:16 --> Router Class Initialized
INFO - 2023-08-19 19:36:16 --> Output Class Initialized
INFO - 2023-08-19 19:36:16 --> Security Class Initialized
DEBUG - 2023-08-19 19:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-19 19:36:16 --> Input Class Initialized
INFO - 2023-08-19 19:36:16 --> Language Class Initialized
INFO - 2023-08-19 19:36:16 --> Loader Class Initialized
INFO - 2023-08-19 19:36:16 --> Helper loaded: url_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: file_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: html_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: text_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: form_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: lang_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: security_helper
INFO - 2023-08-19 19:36:16 --> Helper loaded: cookie_helper
INFO - 2023-08-19 19:36:16 --> Database Driver Class Initialized
INFO - 2023-08-19 19:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-19 19:36:16 --> Parser Class Initialized
INFO - 2023-08-19 19:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-19 19:36:16 --> Pagination Class Initialized
INFO - 2023-08-19 19:36:16 --> Form Validation Class Initialized
INFO - 2023-08-19 19:36:16 --> Controller Class Initialized
INFO - 2023-08-19 19:36:16 --> Model Class Initialized
DEBUG - 2023-08-19 19:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-19 19:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-19 19:36:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-19 19:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-19 19:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-19 19:36:16 --> Model Class Initialized
INFO - 2023-08-19 19:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-19 19:36:16 --> Final output sent to browser
DEBUG - 2023-08-19 19:36:16 --> Total execution time: 0.0302
