<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-06 00:24:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 00:24:08 --> Config Class Initialized
INFO - 2023-06-06 00:24:08 --> Hooks Class Initialized
DEBUG - 2023-06-06 00:24:08 --> UTF-8 Support Enabled
INFO - 2023-06-06 00:24:08 --> Utf8 Class Initialized
INFO - 2023-06-06 00:24:08 --> URI Class Initialized
DEBUG - 2023-06-06 00:24:08 --> No URI present. Default controller set.
INFO - 2023-06-06 00:24:08 --> Router Class Initialized
INFO - 2023-06-06 00:24:08 --> Output Class Initialized
INFO - 2023-06-06 00:24:08 --> Security Class Initialized
DEBUG - 2023-06-06 00:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 00:24:08 --> Input Class Initialized
INFO - 2023-06-06 00:24:08 --> Language Class Initialized
INFO - 2023-06-06 00:24:08 --> Loader Class Initialized
INFO - 2023-06-06 00:24:08 --> Helper loaded: url_helper
INFO - 2023-06-06 00:24:08 --> Helper loaded: file_helper
INFO - 2023-06-06 00:24:08 --> Helper loaded: html_helper
INFO - 2023-06-06 00:24:08 --> Helper loaded: text_helper
INFO - 2023-06-06 00:24:08 --> Helper loaded: form_helper
INFO - 2023-06-06 00:24:08 --> Helper loaded: lang_helper
INFO - 2023-06-06 00:24:08 --> Helper loaded: security_helper
INFO - 2023-06-06 00:24:08 --> Helper loaded: cookie_helper
INFO - 2023-06-06 00:24:08 --> Database Driver Class Initialized
INFO - 2023-06-06 00:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 00:24:08 --> Parser Class Initialized
INFO - 2023-06-06 00:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 00:24:08 --> Pagination Class Initialized
INFO - 2023-06-06 00:24:08 --> Form Validation Class Initialized
INFO - 2023-06-06 00:24:08 --> Controller Class Initialized
INFO - 2023-06-06 00:24:08 --> Model Class Initialized
DEBUG - 2023-06-06 00:24:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 00:33:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 00:33:01 --> Config Class Initialized
INFO - 2023-06-06 00:33:01 --> Hooks Class Initialized
DEBUG - 2023-06-06 00:33:01 --> UTF-8 Support Enabled
INFO - 2023-06-06 00:33:01 --> Utf8 Class Initialized
INFO - 2023-06-06 00:33:01 --> URI Class Initialized
INFO - 2023-06-06 00:33:01 --> Router Class Initialized
INFO - 2023-06-06 00:33:01 --> Output Class Initialized
INFO - 2023-06-06 00:33:01 --> Security Class Initialized
DEBUG - 2023-06-06 00:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 00:33:01 --> Input Class Initialized
INFO - 2023-06-06 00:33:01 --> Language Class Initialized
INFO - 2023-06-06 00:33:01 --> Loader Class Initialized
INFO - 2023-06-06 00:33:01 --> Helper loaded: url_helper
INFO - 2023-06-06 00:33:01 --> Helper loaded: file_helper
INFO - 2023-06-06 00:33:01 --> Helper loaded: html_helper
INFO - 2023-06-06 00:33:01 --> Helper loaded: text_helper
INFO - 2023-06-06 00:33:01 --> Helper loaded: form_helper
INFO - 2023-06-06 00:33:01 --> Helper loaded: lang_helper
INFO - 2023-06-06 00:33:01 --> Helper loaded: security_helper
INFO - 2023-06-06 00:33:01 --> Helper loaded: cookie_helper
INFO - 2023-06-06 00:33:01 --> Database Driver Class Initialized
INFO - 2023-06-06 00:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 00:33:01 --> Parser Class Initialized
INFO - 2023-06-06 00:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 00:33:01 --> Pagination Class Initialized
INFO - 2023-06-06 00:33:01 --> Form Validation Class Initialized
INFO - 2023-06-06 00:33:01 --> Controller Class Initialized
ERROR - 2023-06-06 00:46:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 00:46:33 --> Config Class Initialized
INFO - 2023-06-06 00:46:33 --> Hooks Class Initialized
DEBUG - 2023-06-06 00:46:33 --> UTF-8 Support Enabled
INFO - 2023-06-06 00:46:33 --> Utf8 Class Initialized
INFO - 2023-06-06 00:46:33 --> URI Class Initialized
INFO - 2023-06-06 00:46:33 --> Router Class Initialized
INFO - 2023-06-06 00:46:33 --> Output Class Initialized
INFO - 2023-06-06 00:46:33 --> Security Class Initialized
DEBUG - 2023-06-06 00:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 00:46:33 --> Input Class Initialized
INFO - 2023-06-06 00:46:33 --> Language Class Initialized
INFO - 2023-06-06 00:46:33 --> Loader Class Initialized
INFO - 2023-06-06 00:46:33 --> Helper loaded: url_helper
INFO - 2023-06-06 00:46:33 --> Helper loaded: file_helper
INFO - 2023-06-06 00:46:33 --> Helper loaded: html_helper
INFO - 2023-06-06 00:46:33 --> Helper loaded: text_helper
INFO - 2023-06-06 00:46:33 --> Helper loaded: form_helper
INFO - 2023-06-06 00:46:33 --> Helper loaded: lang_helper
INFO - 2023-06-06 00:46:33 --> Helper loaded: security_helper
INFO - 2023-06-06 00:46:33 --> Helper loaded: cookie_helper
INFO - 2023-06-06 00:46:33 --> Database Driver Class Initialized
INFO - 2023-06-06 00:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 00:46:33 --> Parser Class Initialized
INFO - 2023-06-06 00:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 00:46:33 --> Pagination Class Initialized
INFO - 2023-06-06 00:46:33 --> Form Validation Class Initialized
INFO - 2023-06-06 00:46:33 --> Controller Class Initialized
ERROR - 2023-06-06 01:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 01:58:59 --> Config Class Initialized
INFO - 2023-06-06 01:58:59 --> Hooks Class Initialized
DEBUG - 2023-06-06 01:58:59 --> UTF-8 Support Enabled
INFO - 2023-06-06 01:58:59 --> Utf8 Class Initialized
INFO - 2023-06-06 01:58:59 --> URI Class Initialized
DEBUG - 2023-06-06 01:58:59 --> No URI present. Default controller set.
INFO - 2023-06-06 01:58:59 --> Router Class Initialized
INFO - 2023-06-06 01:58:59 --> Output Class Initialized
INFO - 2023-06-06 01:58:59 --> Security Class Initialized
DEBUG - 2023-06-06 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 01:58:59 --> Input Class Initialized
INFO - 2023-06-06 01:58:59 --> Language Class Initialized
INFO - 2023-06-06 01:58:59 --> Loader Class Initialized
INFO - 2023-06-06 01:58:59 --> Helper loaded: url_helper
INFO - 2023-06-06 01:58:59 --> Helper loaded: file_helper
INFO - 2023-06-06 01:58:59 --> Helper loaded: html_helper
INFO - 2023-06-06 01:58:59 --> Helper loaded: text_helper
INFO - 2023-06-06 01:58:59 --> Helper loaded: form_helper
INFO - 2023-06-06 01:58:59 --> Helper loaded: lang_helper
INFO - 2023-06-06 01:58:59 --> Helper loaded: security_helper
INFO - 2023-06-06 01:58:59 --> Helper loaded: cookie_helper
INFO - 2023-06-06 01:58:59 --> Database Driver Class Initialized
INFO - 2023-06-06 01:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 01:58:59 --> Parser Class Initialized
INFO - 2023-06-06 01:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 01:58:59 --> Pagination Class Initialized
INFO - 2023-06-06 01:58:59 --> Form Validation Class Initialized
INFO - 2023-06-06 01:58:59 --> Controller Class Initialized
INFO - 2023-06-06 01:58:59 --> Model Class Initialized
DEBUG - 2023-06-06 01:58:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 02:19:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:19:06 --> Config Class Initialized
INFO - 2023-06-06 02:19:06 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:19:06 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:19:06 --> Utf8 Class Initialized
INFO - 2023-06-06 02:19:06 --> URI Class Initialized
DEBUG - 2023-06-06 02:19:06 --> No URI present. Default controller set.
INFO - 2023-06-06 02:19:06 --> Router Class Initialized
INFO - 2023-06-06 02:19:06 --> Output Class Initialized
INFO - 2023-06-06 02:19:06 --> Security Class Initialized
DEBUG - 2023-06-06 02:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:19:06 --> Input Class Initialized
INFO - 2023-06-06 02:19:06 --> Language Class Initialized
INFO - 2023-06-06 02:19:06 --> Loader Class Initialized
INFO - 2023-06-06 02:19:06 --> Helper loaded: url_helper
INFO - 2023-06-06 02:19:06 --> Helper loaded: file_helper
INFO - 2023-06-06 02:19:06 --> Helper loaded: html_helper
INFO - 2023-06-06 02:19:06 --> Helper loaded: text_helper
INFO - 2023-06-06 02:19:06 --> Helper loaded: form_helper
INFO - 2023-06-06 02:19:06 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:19:06 --> Helper loaded: security_helper
INFO - 2023-06-06 02:19:06 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:19:06 --> Database Driver Class Initialized
INFO - 2023-06-06 02:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:19:06 --> Parser Class Initialized
INFO - 2023-06-06 02:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:19:06 --> Pagination Class Initialized
INFO - 2023-06-06 02:19:06 --> Form Validation Class Initialized
INFO - 2023-06-06 02:19:06 --> Controller Class Initialized
INFO - 2023-06-06 02:19:06 --> Model Class Initialized
DEBUG - 2023-06-06 02:19:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 02:19:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:19:07 --> Config Class Initialized
INFO - 2023-06-06 02:19:07 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:19:07 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:19:07 --> Utf8 Class Initialized
INFO - 2023-06-06 02:19:07 --> URI Class Initialized
INFO - 2023-06-06 02:19:07 --> Router Class Initialized
INFO - 2023-06-06 02:19:07 --> Output Class Initialized
INFO - 2023-06-06 02:19:07 --> Security Class Initialized
DEBUG - 2023-06-06 02:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:19:07 --> Input Class Initialized
INFO - 2023-06-06 02:19:07 --> Language Class Initialized
INFO - 2023-06-06 02:19:07 --> Loader Class Initialized
INFO - 2023-06-06 02:19:07 --> Helper loaded: url_helper
INFO - 2023-06-06 02:19:07 --> Helper loaded: file_helper
INFO - 2023-06-06 02:19:07 --> Helper loaded: html_helper
INFO - 2023-06-06 02:19:07 --> Helper loaded: text_helper
INFO - 2023-06-06 02:19:07 --> Helper loaded: form_helper
INFO - 2023-06-06 02:19:07 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:19:07 --> Helper loaded: security_helper
INFO - 2023-06-06 02:19:07 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:19:07 --> Database Driver Class Initialized
INFO - 2023-06-06 02:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:19:07 --> Parser Class Initialized
INFO - 2023-06-06 02:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:19:07 --> Pagination Class Initialized
INFO - 2023-06-06 02:19:07 --> Form Validation Class Initialized
INFO - 2023-06-06 02:19:07 --> Controller Class Initialized
INFO - 2023-06-06 02:19:07 --> Model Class Initialized
DEBUG - 2023-06-06 02:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 02:19:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:19:07 --> Model Class Initialized
INFO - 2023-06-06 02:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:19:07 --> Final output sent to browser
DEBUG - 2023-06-06 02:19:07 --> Total execution time: 0.0341
ERROR - 2023-06-06 02:19:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:19:11 --> Config Class Initialized
INFO - 2023-06-06 02:19:11 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:19:11 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:19:11 --> Utf8 Class Initialized
INFO - 2023-06-06 02:19:11 --> URI Class Initialized
INFO - 2023-06-06 02:19:11 --> Router Class Initialized
INFO - 2023-06-06 02:19:11 --> Output Class Initialized
INFO - 2023-06-06 02:19:11 --> Security Class Initialized
DEBUG - 2023-06-06 02:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:19:11 --> Input Class Initialized
INFO - 2023-06-06 02:19:11 --> Language Class Initialized
INFO - 2023-06-06 02:19:11 --> Loader Class Initialized
INFO - 2023-06-06 02:19:11 --> Helper loaded: url_helper
INFO - 2023-06-06 02:19:11 --> Helper loaded: file_helper
INFO - 2023-06-06 02:19:11 --> Helper loaded: html_helper
INFO - 2023-06-06 02:19:11 --> Helper loaded: text_helper
INFO - 2023-06-06 02:19:11 --> Helper loaded: form_helper
INFO - 2023-06-06 02:19:11 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:19:11 --> Helper loaded: security_helper
INFO - 2023-06-06 02:19:11 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:19:11 --> Database Driver Class Initialized
INFO - 2023-06-06 02:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:19:11 --> Parser Class Initialized
INFO - 2023-06-06 02:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:19:11 --> Pagination Class Initialized
INFO - 2023-06-06 02:19:11 --> Form Validation Class Initialized
INFO - 2023-06-06 02:19:11 --> Controller Class Initialized
INFO - 2023-06-06 02:19:11 --> Model Class Initialized
DEBUG - 2023-06-06 02:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:11 --> Model Class Initialized
INFO - 2023-06-06 02:19:11 --> Final output sent to browser
DEBUG - 2023-06-06 02:19:11 --> Total execution time: 0.0182
ERROR - 2023-06-06 02:19:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:19:12 --> Config Class Initialized
INFO - 2023-06-06 02:19:12 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:19:12 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:19:12 --> Utf8 Class Initialized
INFO - 2023-06-06 02:19:12 --> URI Class Initialized
DEBUG - 2023-06-06 02:19:12 --> No URI present. Default controller set.
INFO - 2023-06-06 02:19:12 --> Router Class Initialized
INFO - 2023-06-06 02:19:12 --> Output Class Initialized
INFO - 2023-06-06 02:19:12 --> Security Class Initialized
DEBUG - 2023-06-06 02:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:19:12 --> Input Class Initialized
INFO - 2023-06-06 02:19:12 --> Language Class Initialized
INFO - 2023-06-06 02:19:12 --> Loader Class Initialized
INFO - 2023-06-06 02:19:12 --> Helper loaded: url_helper
INFO - 2023-06-06 02:19:12 --> Helper loaded: file_helper
INFO - 2023-06-06 02:19:12 --> Helper loaded: html_helper
INFO - 2023-06-06 02:19:12 --> Helper loaded: text_helper
INFO - 2023-06-06 02:19:12 --> Helper loaded: form_helper
INFO - 2023-06-06 02:19:12 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:19:12 --> Helper loaded: security_helper
INFO - 2023-06-06 02:19:12 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:19:12 --> Database Driver Class Initialized
INFO - 2023-06-06 02:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:19:12 --> Parser Class Initialized
INFO - 2023-06-06 02:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:19:12 --> Pagination Class Initialized
INFO - 2023-06-06 02:19:12 --> Form Validation Class Initialized
INFO - 2023-06-06 02:19:12 --> Controller Class Initialized
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
DEBUG - 2023-06-06 02:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
DEBUG - 2023-06-06 02:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
DEBUG - 2023-06-06 02:19:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
INFO - 2023-06-06 02:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 02:19:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:19:12 --> Model Class Initialized
INFO - 2023-06-06 02:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:19:12 --> Final output sent to browser
DEBUG - 2023-06-06 02:19:12 --> Total execution time: 0.1804
ERROR - 2023-06-06 02:19:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:19:13 --> Config Class Initialized
INFO - 2023-06-06 02:19:13 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:19:13 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:19:13 --> Utf8 Class Initialized
INFO - 2023-06-06 02:19:13 --> URI Class Initialized
INFO - 2023-06-06 02:19:13 --> Router Class Initialized
INFO - 2023-06-06 02:19:13 --> Output Class Initialized
INFO - 2023-06-06 02:19:13 --> Security Class Initialized
DEBUG - 2023-06-06 02:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:19:13 --> Input Class Initialized
INFO - 2023-06-06 02:19:13 --> Language Class Initialized
INFO - 2023-06-06 02:19:13 --> Loader Class Initialized
INFO - 2023-06-06 02:19:13 --> Helper loaded: url_helper
INFO - 2023-06-06 02:19:13 --> Helper loaded: file_helper
INFO - 2023-06-06 02:19:13 --> Helper loaded: html_helper
INFO - 2023-06-06 02:19:13 --> Helper loaded: text_helper
INFO - 2023-06-06 02:19:13 --> Helper loaded: form_helper
INFO - 2023-06-06 02:19:13 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:19:13 --> Helper loaded: security_helper
INFO - 2023-06-06 02:19:13 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:19:13 --> Database Driver Class Initialized
INFO - 2023-06-06 02:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:19:13 --> Parser Class Initialized
INFO - 2023-06-06 02:19:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:19:13 --> Pagination Class Initialized
INFO - 2023-06-06 02:19:13 --> Form Validation Class Initialized
INFO - 2023-06-06 02:19:13 --> Controller Class Initialized
DEBUG - 2023-06-06 02:19:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:19:13 --> Model Class Initialized
INFO - 2023-06-06 02:19:13 --> Final output sent to browser
DEBUG - 2023-06-06 02:19:13 --> Total execution time: 0.0130
ERROR - 2023-06-06 02:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:28:27 --> Config Class Initialized
INFO - 2023-06-06 02:28:27 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:28:27 --> Utf8 Class Initialized
INFO - 2023-06-06 02:28:27 --> URI Class Initialized
DEBUG - 2023-06-06 02:28:27 --> No URI present. Default controller set.
INFO - 2023-06-06 02:28:27 --> Router Class Initialized
INFO - 2023-06-06 02:28:27 --> Output Class Initialized
INFO - 2023-06-06 02:28:27 --> Security Class Initialized
DEBUG - 2023-06-06 02:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:28:27 --> Input Class Initialized
INFO - 2023-06-06 02:28:27 --> Language Class Initialized
INFO - 2023-06-06 02:28:27 --> Loader Class Initialized
INFO - 2023-06-06 02:28:27 --> Helper loaded: url_helper
INFO - 2023-06-06 02:28:27 --> Helper loaded: file_helper
INFO - 2023-06-06 02:28:27 --> Helper loaded: html_helper
INFO - 2023-06-06 02:28:27 --> Helper loaded: text_helper
INFO - 2023-06-06 02:28:27 --> Helper loaded: form_helper
INFO - 2023-06-06 02:28:27 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:28:27 --> Helper loaded: security_helper
INFO - 2023-06-06 02:28:27 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:28:27 --> Database Driver Class Initialized
INFO - 2023-06-06 02:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:28:27 --> Parser Class Initialized
INFO - 2023-06-06 02:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:28:27 --> Pagination Class Initialized
INFO - 2023-06-06 02:28:27 --> Form Validation Class Initialized
INFO - 2023-06-06 02:28:27 --> Controller Class Initialized
INFO - 2023-06-06 02:28:27 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 02:28:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:28:28 --> Config Class Initialized
INFO - 2023-06-06 02:28:28 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:28:28 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:28:28 --> Utf8 Class Initialized
INFO - 2023-06-06 02:28:28 --> URI Class Initialized
INFO - 2023-06-06 02:28:28 --> Router Class Initialized
INFO - 2023-06-06 02:28:28 --> Output Class Initialized
INFO - 2023-06-06 02:28:28 --> Security Class Initialized
DEBUG - 2023-06-06 02:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:28:28 --> Input Class Initialized
INFO - 2023-06-06 02:28:28 --> Language Class Initialized
INFO - 2023-06-06 02:28:28 --> Loader Class Initialized
INFO - 2023-06-06 02:28:28 --> Helper loaded: url_helper
INFO - 2023-06-06 02:28:28 --> Helper loaded: file_helper
INFO - 2023-06-06 02:28:28 --> Helper loaded: html_helper
INFO - 2023-06-06 02:28:28 --> Helper loaded: text_helper
INFO - 2023-06-06 02:28:28 --> Helper loaded: form_helper
INFO - 2023-06-06 02:28:28 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:28:28 --> Helper loaded: security_helper
INFO - 2023-06-06 02:28:28 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:28:28 --> Database Driver Class Initialized
INFO - 2023-06-06 02:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:28:28 --> Parser Class Initialized
INFO - 2023-06-06 02:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:28:28 --> Pagination Class Initialized
INFO - 2023-06-06 02:28:28 --> Form Validation Class Initialized
INFO - 2023-06-06 02:28:28 --> Controller Class Initialized
INFO - 2023-06-06 02:28:28 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 02:28:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:28:28 --> Model Class Initialized
INFO - 2023-06-06 02:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:28:28 --> Final output sent to browser
DEBUG - 2023-06-06 02:28:28 --> Total execution time: 0.0311
ERROR - 2023-06-06 02:28:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:28:34 --> Config Class Initialized
INFO - 2023-06-06 02:28:34 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:28:34 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:28:34 --> Utf8 Class Initialized
INFO - 2023-06-06 02:28:34 --> URI Class Initialized
INFO - 2023-06-06 02:28:34 --> Router Class Initialized
INFO - 2023-06-06 02:28:34 --> Output Class Initialized
INFO - 2023-06-06 02:28:34 --> Security Class Initialized
DEBUG - 2023-06-06 02:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:28:34 --> Input Class Initialized
INFO - 2023-06-06 02:28:34 --> Language Class Initialized
INFO - 2023-06-06 02:28:34 --> Loader Class Initialized
INFO - 2023-06-06 02:28:34 --> Helper loaded: url_helper
INFO - 2023-06-06 02:28:34 --> Helper loaded: file_helper
INFO - 2023-06-06 02:28:34 --> Helper loaded: html_helper
INFO - 2023-06-06 02:28:34 --> Helper loaded: text_helper
INFO - 2023-06-06 02:28:34 --> Helper loaded: form_helper
INFO - 2023-06-06 02:28:34 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:28:34 --> Helper loaded: security_helper
INFO - 2023-06-06 02:28:34 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:28:34 --> Database Driver Class Initialized
INFO - 2023-06-06 02:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:28:34 --> Parser Class Initialized
INFO - 2023-06-06 02:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:28:34 --> Pagination Class Initialized
INFO - 2023-06-06 02:28:34 --> Form Validation Class Initialized
INFO - 2023-06-06 02:28:34 --> Controller Class Initialized
INFO - 2023-06-06 02:28:34 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:34 --> Model Class Initialized
INFO - 2023-06-06 02:28:34 --> Final output sent to browser
DEBUG - 2023-06-06 02:28:34 --> Total execution time: 0.0174
ERROR - 2023-06-06 02:28:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:28:35 --> Config Class Initialized
INFO - 2023-06-06 02:28:35 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:28:35 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:28:35 --> Utf8 Class Initialized
INFO - 2023-06-06 02:28:35 --> URI Class Initialized
DEBUG - 2023-06-06 02:28:35 --> No URI present. Default controller set.
INFO - 2023-06-06 02:28:35 --> Router Class Initialized
INFO - 2023-06-06 02:28:35 --> Output Class Initialized
INFO - 2023-06-06 02:28:35 --> Security Class Initialized
DEBUG - 2023-06-06 02:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:28:35 --> Input Class Initialized
INFO - 2023-06-06 02:28:35 --> Language Class Initialized
INFO - 2023-06-06 02:28:35 --> Loader Class Initialized
INFO - 2023-06-06 02:28:35 --> Helper loaded: url_helper
INFO - 2023-06-06 02:28:35 --> Helper loaded: file_helper
INFO - 2023-06-06 02:28:35 --> Helper loaded: html_helper
INFO - 2023-06-06 02:28:35 --> Helper loaded: text_helper
INFO - 2023-06-06 02:28:35 --> Helper loaded: form_helper
INFO - 2023-06-06 02:28:35 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:28:35 --> Helper loaded: security_helper
INFO - 2023-06-06 02:28:35 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:28:35 --> Database Driver Class Initialized
INFO - 2023-06-06 02:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:28:35 --> Parser Class Initialized
INFO - 2023-06-06 02:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:28:35 --> Pagination Class Initialized
INFO - 2023-06-06 02:28:35 --> Form Validation Class Initialized
INFO - 2023-06-06 02:28:35 --> Controller Class Initialized
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
INFO - 2023-06-06 02:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 02:28:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:28:35 --> Model Class Initialized
INFO - 2023-06-06 02:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:28:35 --> Final output sent to browser
DEBUG - 2023-06-06 02:28:35 --> Total execution time: 0.0745
ERROR - 2023-06-06 02:28:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:28:57 --> Config Class Initialized
INFO - 2023-06-06 02:28:57 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:28:57 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:28:57 --> Utf8 Class Initialized
INFO - 2023-06-06 02:28:58 --> URI Class Initialized
INFO - 2023-06-06 02:28:58 --> Router Class Initialized
INFO - 2023-06-06 02:28:58 --> Output Class Initialized
INFO - 2023-06-06 02:28:58 --> Security Class Initialized
DEBUG - 2023-06-06 02:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:28:58 --> Input Class Initialized
INFO - 2023-06-06 02:28:58 --> Language Class Initialized
INFO - 2023-06-06 02:28:58 --> Loader Class Initialized
INFO - 2023-06-06 02:28:58 --> Helper loaded: url_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: file_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: html_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: text_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: form_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: security_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:28:58 --> Database Driver Class Initialized
INFO - 2023-06-06 02:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:28:58 --> Parser Class Initialized
INFO - 2023-06-06 02:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:28:58 --> Pagination Class Initialized
INFO - 2023-06-06 02:28:58 --> Form Validation Class Initialized
INFO - 2023-06-06 02:28:58 --> Controller Class Initialized
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
INFO - 2023-06-06 02:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-06 02:28:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
INFO - 2023-06-06 02:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:28:58 --> Final output sent to browser
DEBUG - 2023-06-06 02:28:58 --> Total execution time: 0.0754
ERROR - 2023-06-06 02:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:28:58 --> Config Class Initialized
INFO - 2023-06-06 02:28:58 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:28:58 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:28:58 --> Utf8 Class Initialized
INFO - 2023-06-06 02:28:58 --> URI Class Initialized
INFO - 2023-06-06 02:28:58 --> Router Class Initialized
INFO - 2023-06-06 02:28:58 --> Output Class Initialized
INFO - 2023-06-06 02:28:58 --> Security Class Initialized
DEBUG - 2023-06-06 02:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:28:58 --> Input Class Initialized
INFO - 2023-06-06 02:28:58 --> Language Class Initialized
INFO - 2023-06-06 02:28:58 --> Loader Class Initialized
INFO - 2023-06-06 02:28:58 --> Helper loaded: url_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: file_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: html_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: text_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: form_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: security_helper
INFO - 2023-06-06 02:28:58 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:28:58 --> Database Driver Class Initialized
INFO - 2023-06-06 02:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:28:58 --> Parser Class Initialized
INFO - 2023-06-06 02:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:28:58 --> Pagination Class Initialized
INFO - 2023-06-06 02:28:58 --> Form Validation Class Initialized
INFO - 2023-06-06 02:28:58 --> Controller Class Initialized
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
DEBUG - 2023-06-06 02:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:28:58 --> Model Class Initialized
INFO - 2023-06-06 02:28:59 --> Final output sent to browser
DEBUG - 2023-06-06 02:28:59 --> Total execution time: 0.0420
ERROR - 2023-06-06 02:29:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:29:17 --> Config Class Initialized
INFO - 2023-06-06 02:29:17 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:29:17 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:29:17 --> Utf8 Class Initialized
INFO - 2023-06-06 02:29:17 --> URI Class Initialized
INFO - 2023-06-06 02:29:17 --> Router Class Initialized
INFO - 2023-06-06 02:29:17 --> Output Class Initialized
INFO - 2023-06-06 02:29:17 --> Security Class Initialized
DEBUG - 2023-06-06 02:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:29:17 --> Input Class Initialized
INFO - 2023-06-06 02:29:17 --> Language Class Initialized
INFO - 2023-06-06 02:29:17 --> Loader Class Initialized
INFO - 2023-06-06 02:29:17 --> Helper loaded: url_helper
INFO - 2023-06-06 02:29:17 --> Helper loaded: file_helper
INFO - 2023-06-06 02:29:17 --> Helper loaded: html_helper
INFO - 2023-06-06 02:29:17 --> Helper loaded: text_helper
INFO - 2023-06-06 02:29:17 --> Helper loaded: form_helper
INFO - 2023-06-06 02:29:17 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:29:17 --> Helper loaded: security_helper
INFO - 2023-06-06 02:29:17 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:29:17 --> Database Driver Class Initialized
INFO - 2023-06-06 02:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:29:17 --> Parser Class Initialized
INFO - 2023-06-06 02:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:29:17 --> Pagination Class Initialized
INFO - 2023-06-06 02:29:17 --> Form Validation Class Initialized
INFO - 2023-06-06 02:29:17 --> Controller Class Initialized
INFO - 2023-06-06 02:29:17 --> Model Class Initialized
DEBUG - 2023-06-06 02:29:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:17 --> Model Class Initialized
DEBUG - 2023-06-06 02:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:17 --> Model Class Initialized
INFO - 2023-06-06 02:29:17 --> Final output sent to browser
DEBUG - 2023-06-06 02:29:17 --> Total execution time: 0.0701
ERROR - 2023-06-06 02:29:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:29:21 --> Config Class Initialized
INFO - 2023-06-06 02:29:21 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:29:21 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:29:21 --> Utf8 Class Initialized
INFO - 2023-06-06 02:29:21 --> URI Class Initialized
INFO - 2023-06-06 02:29:21 --> Router Class Initialized
INFO - 2023-06-06 02:29:21 --> Output Class Initialized
INFO - 2023-06-06 02:29:21 --> Security Class Initialized
DEBUG - 2023-06-06 02:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:29:21 --> Input Class Initialized
INFO - 2023-06-06 02:29:21 --> Language Class Initialized
INFO - 2023-06-06 02:29:21 --> Loader Class Initialized
INFO - 2023-06-06 02:29:21 --> Helper loaded: url_helper
INFO - 2023-06-06 02:29:21 --> Helper loaded: file_helper
INFO - 2023-06-06 02:29:21 --> Helper loaded: html_helper
INFO - 2023-06-06 02:29:21 --> Helper loaded: text_helper
INFO - 2023-06-06 02:29:21 --> Helper loaded: form_helper
INFO - 2023-06-06 02:29:21 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:29:21 --> Helper loaded: security_helper
INFO - 2023-06-06 02:29:21 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:29:21 --> Database Driver Class Initialized
INFO - 2023-06-06 02:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:29:21 --> Parser Class Initialized
INFO - 2023-06-06 02:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:29:21 --> Pagination Class Initialized
INFO - 2023-06-06 02:29:21 --> Form Validation Class Initialized
INFO - 2023-06-06 02:29:21 --> Controller Class Initialized
INFO - 2023-06-06 02:29:21 --> Model Class Initialized
DEBUG - 2023-06-06 02:29:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:21 --> Model Class Initialized
DEBUG - 2023-06-06 02:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:21 --> Model Class Initialized
INFO - 2023-06-06 02:29:21 --> Final output sent to browser
DEBUG - 2023-06-06 02:29:21 --> Total execution time: 0.0653
ERROR - 2023-06-06 02:29:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:29:33 --> Config Class Initialized
INFO - 2023-06-06 02:29:33 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:29:33 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:29:33 --> Utf8 Class Initialized
INFO - 2023-06-06 02:29:33 --> URI Class Initialized
INFO - 2023-06-06 02:29:33 --> Router Class Initialized
INFO - 2023-06-06 02:29:33 --> Output Class Initialized
INFO - 2023-06-06 02:29:33 --> Security Class Initialized
DEBUG - 2023-06-06 02:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:29:33 --> Input Class Initialized
INFO - 2023-06-06 02:29:33 --> Language Class Initialized
INFO - 2023-06-06 02:29:33 --> Loader Class Initialized
INFO - 2023-06-06 02:29:33 --> Helper loaded: url_helper
INFO - 2023-06-06 02:29:33 --> Helper loaded: file_helper
INFO - 2023-06-06 02:29:33 --> Helper loaded: html_helper
INFO - 2023-06-06 02:29:33 --> Helper loaded: text_helper
INFO - 2023-06-06 02:29:33 --> Helper loaded: form_helper
INFO - 2023-06-06 02:29:33 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:29:33 --> Helper loaded: security_helper
INFO - 2023-06-06 02:29:33 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:29:33 --> Database Driver Class Initialized
INFO - 2023-06-06 02:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:29:33 --> Parser Class Initialized
INFO - 2023-06-06 02:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:29:33 --> Pagination Class Initialized
INFO - 2023-06-06 02:29:33 --> Form Validation Class Initialized
INFO - 2023-06-06 02:29:33 --> Controller Class Initialized
INFO - 2023-06-06 02:29:33 --> Model Class Initialized
DEBUG - 2023-06-06 02:29:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:33 --> Model Class Initialized
DEBUG - 2023-06-06 02:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:33 --> Model Class Initialized
DEBUG - 2023-06-06 02:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-06 02:29:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:29:33 --> Model Class Initialized
INFO - 2023-06-06 02:29:33 --> Model Class Initialized
INFO - 2023-06-06 02:29:33 --> Model Class Initialized
INFO - 2023-06-06 02:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:29:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:29:33 --> Final output sent to browser
DEBUG - 2023-06-06 02:29:33 --> Total execution time: 0.0824
ERROR - 2023-06-06 02:30:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:30:37 --> Config Class Initialized
INFO - 2023-06-06 02:30:37 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:30:37 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:30:37 --> Utf8 Class Initialized
INFO - 2023-06-06 02:30:37 --> URI Class Initialized
DEBUG - 2023-06-06 02:30:37 --> No URI present. Default controller set.
INFO - 2023-06-06 02:30:37 --> Router Class Initialized
INFO - 2023-06-06 02:30:37 --> Output Class Initialized
INFO - 2023-06-06 02:30:37 --> Security Class Initialized
DEBUG - 2023-06-06 02:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:30:37 --> Input Class Initialized
INFO - 2023-06-06 02:30:37 --> Language Class Initialized
INFO - 2023-06-06 02:30:37 --> Loader Class Initialized
INFO - 2023-06-06 02:30:37 --> Helper loaded: url_helper
INFO - 2023-06-06 02:30:37 --> Helper loaded: file_helper
INFO - 2023-06-06 02:30:37 --> Helper loaded: html_helper
INFO - 2023-06-06 02:30:37 --> Helper loaded: text_helper
INFO - 2023-06-06 02:30:37 --> Helper loaded: form_helper
INFO - 2023-06-06 02:30:37 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:30:37 --> Helper loaded: security_helper
INFO - 2023-06-06 02:30:37 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:30:37 --> Database Driver Class Initialized
INFO - 2023-06-06 02:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:30:37 --> Parser Class Initialized
INFO - 2023-06-06 02:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:30:37 --> Pagination Class Initialized
INFO - 2023-06-06 02:30:37 --> Form Validation Class Initialized
INFO - 2023-06-06 02:30:37 --> Controller Class Initialized
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
DEBUG - 2023-06-06 02:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
DEBUG - 2023-06-06 02:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
DEBUG - 2023-06-06 02:30:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
INFO - 2023-06-06 02:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 02:30:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:30:37 --> Model Class Initialized
INFO - 2023-06-06 02:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:30:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:30:37 --> Final output sent to browser
DEBUG - 2023-06-06 02:30:37 --> Total execution time: 0.0778
ERROR - 2023-06-06 02:30:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:30:50 --> Config Class Initialized
INFO - 2023-06-06 02:30:50 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:30:50 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:30:50 --> Utf8 Class Initialized
INFO - 2023-06-06 02:30:50 --> URI Class Initialized
INFO - 2023-06-06 02:30:50 --> Router Class Initialized
INFO - 2023-06-06 02:30:50 --> Output Class Initialized
INFO - 2023-06-06 02:30:50 --> Security Class Initialized
DEBUG - 2023-06-06 02:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:30:50 --> Input Class Initialized
INFO - 2023-06-06 02:30:50 --> Language Class Initialized
INFO - 2023-06-06 02:30:50 --> Loader Class Initialized
INFO - 2023-06-06 02:30:50 --> Helper loaded: url_helper
INFO - 2023-06-06 02:30:50 --> Helper loaded: file_helper
INFO - 2023-06-06 02:30:50 --> Helper loaded: html_helper
INFO - 2023-06-06 02:30:50 --> Helper loaded: text_helper
INFO - 2023-06-06 02:30:50 --> Helper loaded: form_helper
INFO - 2023-06-06 02:30:50 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:30:50 --> Helper loaded: security_helper
INFO - 2023-06-06 02:30:50 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:30:51 --> Database Driver Class Initialized
INFO - 2023-06-06 02:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:30:51 --> Parser Class Initialized
INFO - 2023-06-06 02:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:30:51 --> Pagination Class Initialized
INFO - 2023-06-06 02:30:51 --> Form Validation Class Initialized
INFO - 2023-06-06 02:30:51 --> Controller Class Initialized
DEBUG - 2023-06-06 02:30:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:51 --> Model Class Initialized
DEBUG - 2023-06-06 02:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:51 --> Model Class Initialized
DEBUG - 2023-06-06 02:30:51 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:51 --> Model Class Initialized
INFO - 2023-06-06 02:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-06 02:30:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:30:51 --> Model Class Initialized
INFO - 2023-06-06 02:30:51 --> Model Class Initialized
INFO - 2023-06-06 02:30:51 --> Model Class Initialized
INFO - 2023-06-06 02:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:30:51 --> Final output sent to browser
DEBUG - 2023-06-06 02:30:51 --> Total execution time: 0.0696
ERROR - 2023-06-06 02:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:30:52 --> Config Class Initialized
INFO - 2023-06-06 02:30:52 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:30:52 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:30:52 --> Utf8 Class Initialized
INFO - 2023-06-06 02:30:52 --> URI Class Initialized
INFO - 2023-06-06 02:30:52 --> Router Class Initialized
INFO - 2023-06-06 02:30:52 --> Output Class Initialized
INFO - 2023-06-06 02:30:52 --> Security Class Initialized
DEBUG - 2023-06-06 02:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:30:52 --> Input Class Initialized
INFO - 2023-06-06 02:30:52 --> Language Class Initialized
INFO - 2023-06-06 02:30:52 --> Loader Class Initialized
INFO - 2023-06-06 02:30:52 --> Helper loaded: url_helper
INFO - 2023-06-06 02:30:52 --> Helper loaded: file_helper
INFO - 2023-06-06 02:30:52 --> Helper loaded: html_helper
INFO - 2023-06-06 02:30:52 --> Helper loaded: text_helper
INFO - 2023-06-06 02:30:52 --> Helper loaded: form_helper
INFO - 2023-06-06 02:30:52 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:30:52 --> Helper loaded: security_helper
INFO - 2023-06-06 02:30:52 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:30:52 --> Database Driver Class Initialized
INFO - 2023-06-06 02:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:30:52 --> Parser Class Initialized
INFO - 2023-06-06 02:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:30:52 --> Pagination Class Initialized
INFO - 2023-06-06 02:30:52 --> Form Validation Class Initialized
INFO - 2023-06-06 02:30:52 --> Controller Class Initialized
DEBUG - 2023-06-06 02:30:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:52 --> Model Class Initialized
DEBUG - 2023-06-06 02:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:52 --> Model Class Initialized
INFO - 2023-06-06 02:30:52 --> Final output sent to browser
DEBUG - 2023-06-06 02:30:52 --> Total execution time: 0.0211
ERROR - 2023-06-06 02:30:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:30:55 --> Config Class Initialized
INFO - 2023-06-06 02:30:55 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:30:55 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:30:55 --> Utf8 Class Initialized
INFO - 2023-06-06 02:30:55 --> URI Class Initialized
INFO - 2023-06-06 02:30:55 --> Router Class Initialized
INFO - 2023-06-06 02:30:55 --> Output Class Initialized
INFO - 2023-06-06 02:30:55 --> Security Class Initialized
DEBUG - 2023-06-06 02:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:30:55 --> Input Class Initialized
INFO - 2023-06-06 02:30:55 --> Language Class Initialized
INFO - 2023-06-06 02:30:55 --> Loader Class Initialized
INFO - 2023-06-06 02:30:55 --> Helper loaded: url_helper
INFO - 2023-06-06 02:30:55 --> Helper loaded: file_helper
INFO - 2023-06-06 02:30:55 --> Helper loaded: html_helper
INFO - 2023-06-06 02:30:55 --> Helper loaded: text_helper
INFO - 2023-06-06 02:30:55 --> Helper loaded: form_helper
INFO - 2023-06-06 02:30:55 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:30:55 --> Helper loaded: security_helper
INFO - 2023-06-06 02:30:55 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:30:55 --> Database Driver Class Initialized
INFO - 2023-06-06 02:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:30:55 --> Parser Class Initialized
INFO - 2023-06-06 02:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:30:55 --> Pagination Class Initialized
INFO - 2023-06-06 02:30:55 --> Form Validation Class Initialized
INFO - 2023-06-06 02:30:55 --> Controller Class Initialized
DEBUG - 2023-06-06 02:30:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:55 --> Model Class Initialized
DEBUG - 2023-06-06 02:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:30:55 --> Model Class Initialized
INFO - 2023-06-06 02:30:55 --> Final output sent to browser
DEBUG - 2023-06-06 02:30:55 --> Total execution time: 0.0300
ERROR - 2023-06-06 02:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:31:05 --> Config Class Initialized
INFO - 2023-06-06 02:31:05 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:31:05 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:31:05 --> Utf8 Class Initialized
INFO - 2023-06-06 02:31:05 --> URI Class Initialized
INFO - 2023-06-06 02:31:05 --> Router Class Initialized
INFO - 2023-06-06 02:31:05 --> Output Class Initialized
INFO - 2023-06-06 02:31:05 --> Security Class Initialized
DEBUG - 2023-06-06 02:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:31:05 --> Input Class Initialized
INFO - 2023-06-06 02:31:05 --> Language Class Initialized
INFO - 2023-06-06 02:31:05 --> Loader Class Initialized
INFO - 2023-06-06 02:31:05 --> Helper loaded: url_helper
INFO - 2023-06-06 02:31:05 --> Helper loaded: file_helper
INFO - 2023-06-06 02:31:05 --> Helper loaded: html_helper
INFO - 2023-06-06 02:31:05 --> Helper loaded: text_helper
INFO - 2023-06-06 02:31:05 --> Helper loaded: form_helper
INFO - 2023-06-06 02:31:05 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:31:05 --> Helper loaded: security_helper
INFO - 2023-06-06 02:31:05 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:31:05 --> Database Driver Class Initialized
INFO - 2023-06-06 02:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:31:05 --> Parser Class Initialized
INFO - 2023-06-06 02:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:31:05 --> Pagination Class Initialized
INFO - 2023-06-06 02:31:05 --> Form Validation Class Initialized
INFO - 2023-06-06 02:31:05 --> Controller Class Initialized
INFO - 2023-06-06 02:31:05 --> Model Class Initialized
DEBUG - 2023-06-06 02:31:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:31:05 --> Model Class Initialized
INFO - 2023-06-06 02:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-06 02:31:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:31:05 --> Model Class Initialized
INFO - 2023-06-06 02:31:05 --> Model Class Initialized
INFO - 2023-06-06 02:31:05 --> Model Class Initialized
INFO - 2023-06-06 02:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:31:05 --> Final output sent to browser
DEBUG - 2023-06-06 02:31:05 --> Total execution time: 0.0727
ERROR - 2023-06-06 02:31:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:31:06 --> Config Class Initialized
INFO - 2023-06-06 02:31:06 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:31:06 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:31:06 --> Utf8 Class Initialized
INFO - 2023-06-06 02:31:06 --> URI Class Initialized
INFO - 2023-06-06 02:31:06 --> Router Class Initialized
INFO - 2023-06-06 02:31:06 --> Output Class Initialized
INFO - 2023-06-06 02:31:06 --> Security Class Initialized
DEBUG - 2023-06-06 02:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:31:06 --> Input Class Initialized
INFO - 2023-06-06 02:31:06 --> Language Class Initialized
INFO - 2023-06-06 02:31:06 --> Loader Class Initialized
INFO - 2023-06-06 02:31:06 --> Helper loaded: url_helper
INFO - 2023-06-06 02:31:06 --> Helper loaded: file_helper
INFO - 2023-06-06 02:31:06 --> Helper loaded: html_helper
INFO - 2023-06-06 02:31:06 --> Helper loaded: text_helper
INFO - 2023-06-06 02:31:06 --> Helper loaded: form_helper
INFO - 2023-06-06 02:31:06 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:31:06 --> Helper loaded: security_helper
INFO - 2023-06-06 02:31:06 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:31:06 --> Database Driver Class Initialized
INFO - 2023-06-06 02:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:31:06 --> Parser Class Initialized
INFO - 2023-06-06 02:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:31:06 --> Pagination Class Initialized
INFO - 2023-06-06 02:31:06 --> Form Validation Class Initialized
INFO - 2023-06-06 02:31:06 --> Controller Class Initialized
INFO - 2023-06-06 02:31:06 --> Model Class Initialized
DEBUG - 2023-06-06 02:31:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:31:06 --> Model Class Initialized
INFO - 2023-06-06 02:31:06 --> Final output sent to browser
DEBUG - 2023-06-06 02:31:06 --> Total execution time: 0.0325
ERROR - 2023-06-06 02:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:31:13 --> Config Class Initialized
INFO - 2023-06-06 02:31:13 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:31:13 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:31:13 --> Utf8 Class Initialized
INFO - 2023-06-06 02:31:13 --> URI Class Initialized
INFO - 2023-06-06 02:31:13 --> Router Class Initialized
INFO - 2023-06-06 02:31:13 --> Output Class Initialized
INFO - 2023-06-06 02:31:13 --> Security Class Initialized
DEBUG - 2023-06-06 02:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:31:13 --> Input Class Initialized
INFO - 2023-06-06 02:31:13 --> Language Class Initialized
INFO - 2023-06-06 02:31:13 --> Loader Class Initialized
INFO - 2023-06-06 02:31:13 --> Helper loaded: url_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: file_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: html_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: text_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: form_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: security_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:31:13 --> Database Driver Class Initialized
INFO - 2023-06-06 02:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:31:13 --> Parser Class Initialized
INFO - 2023-06-06 02:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:31:13 --> Pagination Class Initialized
INFO - 2023-06-06 02:31:13 --> Form Validation Class Initialized
INFO - 2023-06-06 02:31:13 --> Controller Class Initialized
INFO - 2023-06-06 02:31:13 --> Model Class Initialized
DEBUG - 2023-06-06 02:31:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:31:13 --> Model Class Initialized
INFO - 2023-06-06 02:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-06 02:31:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 02:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 02:31:13 --> Model Class Initialized
INFO - 2023-06-06 02:31:13 --> Model Class Initialized
INFO - 2023-06-06 02:31:13 --> Model Class Initialized
INFO - 2023-06-06 02:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 02:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 02:31:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 02:31:13 --> Final output sent to browser
DEBUG - 2023-06-06 02:31:13 --> Total execution time: 0.0622
ERROR - 2023-06-06 02:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:31:13 --> Config Class Initialized
INFO - 2023-06-06 02:31:13 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:31:13 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:31:13 --> Utf8 Class Initialized
INFO - 2023-06-06 02:31:13 --> URI Class Initialized
INFO - 2023-06-06 02:31:13 --> Router Class Initialized
INFO - 2023-06-06 02:31:13 --> Output Class Initialized
INFO - 2023-06-06 02:31:13 --> Security Class Initialized
DEBUG - 2023-06-06 02:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:31:13 --> Input Class Initialized
INFO - 2023-06-06 02:31:13 --> Language Class Initialized
INFO - 2023-06-06 02:31:13 --> Loader Class Initialized
INFO - 2023-06-06 02:31:13 --> Helper loaded: url_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: file_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: html_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: text_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: form_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: security_helper
INFO - 2023-06-06 02:31:13 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:31:13 --> Database Driver Class Initialized
INFO - 2023-06-06 02:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:31:13 --> Parser Class Initialized
INFO - 2023-06-06 02:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:31:13 --> Pagination Class Initialized
INFO - 2023-06-06 02:31:13 --> Form Validation Class Initialized
INFO - 2023-06-06 02:31:13 --> Controller Class Initialized
INFO - 2023-06-06 02:31:13 --> Model Class Initialized
DEBUG - 2023-06-06 02:31:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:31:13 --> Model Class Initialized
INFO - 2023-06-06 02:31:13 --> Final output sent to browser
DEBUG - 2023-06-06 02:31:13 --> Total execution time: 0.0259
ERROR - 2023-06-06 02:31:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 02:31:18 --> Config Class Initialized
INFO - 2023-06-06 02:31:18 --> Hooks Class Initialized
DEBUG - 2023-06-06 02:31:18 --> UTF-8 Support Enabled
INFO - 2023-06-06 02:31:18 --> Utf8 Class Initialized
INFO - 2023-06-06 02:31:18 --> URI Class Initialized
INFO - 2023-06-06 02:31:18 --> Router Class Initialized
INFO - 2023-06-06 02:31:18 --> Output Class Initialized
INFO - 2023-06-06 02:31:18 --> Security Class Initialized
DEBUG - 2023-06-06 02:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 02:31:18 --> Input Class Initialized
INFO - 2023-06-06 02:31:18 --> Language Class Initialized
INFO - 2023-06-06 02:31:18 --> Loader Class Initialized
INFO - 2023-06-06 02:31:18 --> Helper loaded: url_helper
INFO - 2023-06-06 02:31:18 --> Helper loaded: file_helper
INFO - 2023-06-06 02:31:18 --> Helper loaded: html_helper
INFO - 2023-06-06 02:31:18 --> Helper loaded: text_helper
INFO - 2023-06-06 02:31:18 --> Helper loaded: form_helper
INFO - 2023-06-06 02:31:18 --> Helper loaded: lang_helper
INFO - 2023-06-06 02:31:18 --> Helper loaded: security_helper
INFO - 2023-06-06 02:31:18 --> Helper loaded: cookie_helper
INFO - 2023-06-06 02:31:18 --> Database Driver Class Initialized
INFO - 2023-06-06 02:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 02:31:18 --> Parser Class Initialized
INFO - 2023-06-06 02:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 02:31:18 --> Pagination Class Initialized
INFO - 2023-06-06 02:31:18 --> Form Validation Class Initialized
INFO - 2023-06-06 02:31:18 --> Controller Class Initialized
INFO - 2023-06-06 02:31:18 --> Model Class Initialized
DEBUG - 2023-06-06 02:31:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 02:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 02:31:18 --> Model Class Initialized
INFO - 2023-06-06 02:31:18 --> Final output sent to browser
DEBUG - 2023-06-06 02:31:18 --> Total execution time: 0.0296
ERROR - 2023-06-06 05:00:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:00:49 --> Config Class Initialized
INFO - 2023-06-06 05:00:49 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:00:49 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:00:49 --> Utf8 Class Initialized
INFO - 2023-06-06 05:00:49 --> URI Class Initialized
DEBUG - 2023-06-06 05:00:49 --> No URI present. Default controller set.
INFO - 2023-06-06 05:00:49 --> Router Class Initialized
INFO - 2023-06-06 05:00:49 --> Output Class Initialized
INFO - 2023-06-06 05:00:49 --> Security Class Initialized
DEBUG - 2023-06-06 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:00:49 --> Input Class Initialized
INFO - 2023-06-06 05:00:49 --> Language Class Initialized
INFO - 2023-06-06 05:00:49 --> Loader Class Initialized
INFO - 2023-06-06 05:00:49 --> Helper loaded: url_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: file_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: html_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: text_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: form_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: security_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:00:49 --> Database Driver Class Initialized
INFO - 2023-06-06 05:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:00:49 --> Parser Class Initialized
INFO - 2023-06-06 05:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:00:49 --> Pagination Class Initialized
INFO - 2023-06-06 05:00:49 --> Form Validation Class Initialized
INFO - 2023-06-06 05:00:49 --> Controller Class Initialized
INFO - 2023-06-06 05:00:49 --> Model Class Initialized
DEBUG - 2023-06-06 05:00:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:00:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:00:49 --> Config Class Initialized
INFO - 2023-06-06 05:00:49 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:00:49 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:00:49 --> Utf8 Class Initialized
INFO - 2023-06-06 05:00:49 --> URI Class Initialized
INFO - 2023-06-06 05:00:49 --> Router Class Initialized
INFO - 2023-06-06 05:00:49 --> Output Class Initialized
INFO - 2023-06-06 05:00:49 --> Security Class Initialized
DEBUG - 2023-06-06 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:00:49 --> Input Class Initialized
INFO - 2023-06-06 05:00:49 --> Language Class Initialized
INFO - 2023-06-06 05:00:49 --> Loader Class Initialized
INFO - 2023-06-06 05:00:49 --> Helper loaded: url_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: file_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: html_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: text_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: form_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: security_helper
INFO - 2023-06-06 05:00:49 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:00:49 --> Database Driver Class Initialized
INFO - 2023-06-06 05:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:00:49 --> Parser Class Initialized
INFO - 2023-06-06 05:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:00:49 --> Pagination Class Initialized
INFO - 2023-06-06 05:00:49 --> Form Validation Class Initialized
INFO - 2023-06-06 05:00:49 --> Controller Class Initialized
INFO - 2023-06-06 05:00:49 --> Model Class Initialized
DEBUG - 2023-06-06 05:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:00:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:00:49 --> Model Class Initialized
INFO - 2023-06-06 05:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:00:49 --> Final output sent to browser
DEBUG - 2023-06-06 05:00:49 --> Total execution time: 0.0325
ERROR - 2023-06-06 05:01:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:01:15 --> Config Class Initialized
INFO - 2023-06-06 05:01:15 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:01:15 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:01:15 --> Utf8 Class Initialized
INFO - 2023-06-06 05:01:15 --> URI Class Initialized
INFO - 2023-06-06 05:01:15 --> Router Class Initialized
INFO - 2023-06-06 05:01:15 --> Output Class Initialized
INFO - 2023-06-06 05:01:15 --> Security Class Initialized
DEBUG - 2023-06-06 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:01:15 --> Input Class Initialized
INFO - 2023-06-06 05:01:15 --> Language Class Initialized
INFO - 2023-06-06 05:01:15 --> Loader Class Initialized
INFO - 2023-06-06 05:01:15 --> Helper loaded: url_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: file_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: html_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: text_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: form_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: security_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:01:15 --> Database Driver Class Initialized
INFO - 2023-06-06 05:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:01:15 --> Parser Class Initialized
INFO - 2023-06-06 05:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:01:15 --> Pagination Class Initialized
INFO - 2023-06-06 05:01:15 --> Form Validation Class Initialized
INFO - 2023-06-06 05:01:15 --> Controller Class Initialized
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
DEBUG - 2023-06-06 05:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
INFO - 2023-06-06 05:01:15 --> Final output sent to browser
DEBUG - 2023-06-06 05:01:15 --> Total execution time: 0.0219
ERROR - 2023-06-06 05:01:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:01:15 --> Config Class Initialized
INFO - 2023-06-06 05:01:15 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:01:15 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:01:15 --> Utf8 Class Initialized
INFO - 2023-06-06 05:01:15 --> URI Class Initialized
DEBUG - 2023-06-06 05:01:15 --> No URI present. Default controller set.
INFO - 2023-06-06 05:01:15 --> Router Class Initialized
INFO - 2023-06-06 05:01:15 --> Output Class Initialized
INFO - 2023-06-06 05:01:15 --> Security Class Initialized
DEBUG - 2023-06-06 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:01:15 --> Input Class Initialized
INFO - 2023-06-06 05:01:15 --> Language Class Initialized
INFO - 2023-06-06 05:01:15 --> Loader Class Initialized
INFO - 2023-06-06 05:01:15 --> Helper loaded: url_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: file_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: html_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: text_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: form_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: security_helper
INFO - 2023-06-06 05:01:15 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:01:15 --> Database Driver Class Initialized
INFO - 2023-06-06 05:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:01:15 --> Parser Class Initialized
INFO - 2023-06-06 05:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:01:15 --> Pagination Class Initialized
INFO - 2023-06-06 05:01:15 --> Form Validation Class Initialized
INFO - 2023-06-06 05:01:15 --> Controller Class Initialized
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
DEBUG - 2023-06-06 05:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
DEBUG - 2023-06-06 05:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
DEBUG - 2023-06-06 05:01:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
INFO - 2023-06-06 05:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:01:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:01:15 --> Model Class Initialized
INFO - 2023-06-06 05:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:01:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:01:15 --> Final output sent to browser
DEBUG - 2023-06-06 05:01:15 --> Total execution time: 0.0715
ERROR - 2023-06-06 05:02:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:17 --> Config Class Initialized
INFO - 2023-06-06 05:02:17 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:17 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:17 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:17 --> URI Class Initialized
DEBUG - 2023-06-06 05:02:17 --> No URI present. Default controller set.
INFO - 2023-06-06 05:02:17 --> Router Class Initialized
INFO - 2023-06-06 05:02:17 --> Output Class Initialized
INFO - 2023-06-06 05:02:17 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:17 --> Input Class Initialized
INFO - 2023-06-06 05:02:17 --> Language Class Initialized
INFO - 2023-06-06 05:02:17 --> Loader Class Initialized
INFO - 2023-06-06 05:02:17 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:17 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:17 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:17 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:17 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:17 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:17 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:17 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:17 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:17 --> Parser Class Initialized
INFO - 2023-06-06 05:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:17 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:17 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:17 --> Controller Class Initialized
INFO - 2023-06-06 05:02:17 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:18 --> Config Class Initialized
INFO - 2023-06-06 05:02:18 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:18 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:18 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:18 --> URI Class Initialized
INFO - 2023-06-06 05:02:18 --> Router Class Initialized
INFO - 2023-06-06 05:02:18 --> Output Class Initialized
INFO - 2023-06-06 05:02:18 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:18 --> Input Class Initialized
INFO - 2023-06-06 05:02:18 --> Language Class Initialized
INFO - 2023-06-06 05:02:18 --> Loader Class Initialized
INFO - 2023-06-06 05:02:18 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:18 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:18 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:18 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:18 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:18 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:18 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:18 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:18 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:18 --> Parser Class Initialized
INFO - 2023-06-06 05:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:18 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:18 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:18 --> Controller Class Initialized
INFO - 2023-06-06 05:02:18 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:02:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:02:18 --> Model Class Initialized
INFO - 2023-06-06 05:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:02:18 --> Final output sent to browser
DEBUG - 2023-06-06 05:02:18 --> Total execution time: 0.0283
ERROR - 2023-06-06 05:02:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:24 --> Config Class Initialized
INFO - 2023-06-06 05:02:24 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:24 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:24 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:24 --> URI Class Initialized
INFO - 2023-06-06 05:02:24 --> Router Class Initialized
INFO - 2023-06-06 05:02:24 --> Output Class Initialized
INFO - 2023-06-06 05:02:24 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:24 --> Input Class Initialized
INFO - 2023-06-06 05:02:24 --> Language Class Initialized
INFO - 2023-06-06 05:02:24 --> Loader Class Initialized
INFO - 2023-06-06 05:02:24 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:24 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:24 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:24 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:24 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:24 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:24 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:24 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:24 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:24 --> Parser Class Initialized
INFO - 2023-06-06 05:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:24 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:24 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:24 --> Controller Class Initialized
INFO - 2023-06-06 05:02:24 --> Model Class Initialized
INFO - 2023-06-06 05:02:24 --> Model Class Initialized
INFO - 2023-06-06 05:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-06 05:02:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:02:24 --> Model Class Initialized
INFO - 2023-06-06 05:02:24 --> Model Class Initialized
INFO - 2023-06-06 05:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:02:24 --> Final output sent to browser
DEBUG - 2023-06-06 05:02:24 --> Total execution time: 0.0536
ERROR - 2023-06-06 05:02:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:26 --> Config Class Initialized
INFO - 2023-06-06 05:02:26 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:26 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:26 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:26 --> URI Class Initialized
INFO - 2023-06-06 05:02:26 --> Router Class Initialized
INFO - 2023-06-06 05:02:26 --> Output Class Initialized
INFO - 2023-06-06 05:02:26 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:26 --> Input Class Initialized
INFO - 2023-06-06 05:02:26 --> Language Class Initialized
INFO - 2023-06-06 05:02:26 --> Loader Class Initialized
INFO - 2023-06-06 05:02:26 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:26 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:26 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:26 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:26 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:26 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:26 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:26 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:26 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:26 --> Parser Class Initialized
INFO - 2023-06-06 05:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:26 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:26 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:26 --> Controller Class Initialized
INFO - 2023-06-06 05:02:26 --> Model Class Initialized
INFO - 2023-06-06 05:02:26 --> Model Class Initialized
INFO - 2023-06-06 05:02:26 --> Final output sent to browser
DEBUG - 2023-06-06 05:02:26 --> Total execution time: 0.0177
ERROR - 2023-06-06 05:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:31 --> Config Class Initialized
INFO - 2023-06-06 05:02:31 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:31 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:31 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:31 --> URI Class Initialized
INFO - 2023-06-06 05:02:31 --> Router Class Initialized
INFO - 2023-06-06 05:02:31 --> Output Class Initialized
INFO - 2023-06-06 05:02:31 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:31 --> Input Class Initialized
INFO - 2023-06-06 05:02:31 --> Language Class Initialized
INFO - 2023-06-06 05:02:31 --> Loader Class Initialized
INFO - 2023-06-06 05:02:31 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:31 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:31 --> Parser Class Initialized
INFO - 2023-06-06 05:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:31 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:31 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:31 --> Controller Class Initialized
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
INFO - 2023-06-06 05:02:31 --> Final output sent to browser
DEBUG - 2023-06-06 05:02:31 --> Total execution time: 0.0153
ERROR - 2023-06-06 05:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:31 --> Config Class Initialized
INFO - 2023-06-06 05:02:31 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:31 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:31 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:31 --> URI Class Initialized
DEBUG - 2023-06-06 05:02:31 --> No URI present. Default controller set.
INFO - 2023-06-06 05:02:31 --> Router Class Initialized
INFO - 2023-06-06 05:02:31 --> Output Class Initialized
INFO - 2023-06-06 05:02:31 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:31 --> Input Class Initialized
INFO - 2023-06-06 05:02:31 --> Language Class Initialized
INFO - 2023-06-06 05:02:31 --> Loader Class Initialized
INFO - 2023-06-06 05:02:31 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:31 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:31 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:31 --> Parser Class Initialized
INFO - 2023-06-06 05:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:31 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:31 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:31 --> Controller Class Initialized
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
INFO - 2023-06-06 05:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:02:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:02:31 --> Model Class Initialized
INFO - 2023-06-06 05:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:02:31 --> Final output sent to browser
DEBUG - 2023-06-06 05:02:31 --> Total execution time: 0.0624
ERROR - 2023-06-06 05:02:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:39 --> Config Class Initialized
INFO - 2023-06-06 05:02:39 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:39 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:39 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:39 --> URI Class Initialized
DEBUG - 2023-06-06 05:02:39 --> No URI present. Default controller set.
INFO - 2023-06-06 05:02:39 --> Router Class Initialized
INFO - 2023-06-06 05:02:39 --> Output Class Initialized
INFO - 2023-06-06 05:02:39 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:39 --> Input Class Initialized
INFO - 2023-06-06 05:02:39 --> Language Class Initialized
INFO - 2023-06-06 05:02:39 --> Loader Class Initialized
INFO - 2023-06-06 05:02:39 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:39 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:39 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:39 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:39 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:39 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:39 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:39 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:39 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:39 --> Parser Class Initialized
INFO - 2023-06-06 05:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:39 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:39 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:39 --> Controller Class Initialized
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
INFO - 2023-06-06 05:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:02:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:02:39 --> Model Class Initialized
INFO - 2023-06-06 05:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:02:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:02:39 --> Final output sent to browser
DEBUG - 2023-06-06 05:02:39 --> Total execution time: 0.0654
ERROR - 2023-06-06 05:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:48 --> Config Class Initialized
INFO - 2023-06-06 05:02:48 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:48 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:48 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:48 --> URI Class Initialized
DEBUG - 2023-06-06 05:02:48 --> No URI present. Default controller set.
INFO - 2023-06-06 05:02:48 --> Router Class Initialized
INFO - 2023-06-06 05:02:48 --> Output Class Initialized
INFO - 2023-06-06 05:02:48 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:48 --> Input Class Initialized
INFO - 2023-06-06 05:02:48 --> Language Class Initialized
INFO - 2023-06-06 05:02:48 --> Loader Class Initialized
INFO - 2023-06-06 05:02:48 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:48 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:48 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:48 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:48 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:48 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:48 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:48 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:48 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:48 --> Parser Class Initialized
INFO - 2023-06-06 05:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:48 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:48 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:48 --> Controller Class Initialized
INFO - 2023-06-06 05:02:48 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:02:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:02:49 --> Config Class Initialized
INFO - 2023-06-06 05:02:49 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:02:49 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:02:49 --> Utf8 Class Initialized
INFO - 2023-06-06 05:02:49 --> URI Class Initialized
INFO - 2023-06-06 05:02:49 --> Router Class Initialized
INFO - 2023-06-06 05:02:49 --> Output Class Initialized
INFO - 2023-06-06 05:02:49 --> Security Class Initialized
DEBUG - 2023-06-06 05:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:02:49 --> Input Class Initialized
INFO - 2023-06-06 05:02:49 --> Language Class Initialized
INFO - 2023-06-06 05:02:49 --> Loader Class Initialized
INFO - 2023-06-06 05:02:49 --> Helper loaded: url_helper
INFO - 2023-06-06 05:02:49 --> Helper loaded: file_helper
INFO - 2023-06-06 05:02:49 --> Helper loaded: html_helper
INFO - 2023-06-06 05:02:49 --> Helper loaded: text_helper
INFO - 2023-06-06 05:02:49 --> Helper loaded: form_helper
INFO - 2023-06-06 05:02:49 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:02:49 --> Helper loaded: security_helper
INFO - 2023-06-06 05:02:49 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:02:49 --> Database Driver Class Initialized
INFO - 2023-06-06 05:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:02:49 --> Parser Class Initialized
INFO - 2023-06-06 05:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:02:49 --> Pagination Class Initialized
INFO - 2023-06-06 05:02:49 --> Form Validation Class Initialized
INFO - 2023-06-06 05:02:49 --> Controller Class Initialized
INFO - 2023-06-06 05:02:49 --> Model Class Initialized
DEBUG - 2023-06-06 05:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:02:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:02:49 --> Model Class Initialized
INFO - 2023-06-06 05:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:02:49 --> Final output sent to browser
DEBUG - 2023-06-06 05:02:49 --> Total execution time: 0.0310
ERROR - 2023-06-06 05:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:20 --> Config Class Initialized
INFO - 2023-06-06 05:03:20 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:20 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:20 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:20 --> URI Class Initialized
DEBUG - 2023-06-06 05:03:20 --> No URI present. Default controller set.
INFO - 2023-06-06 05:03:20 --> Router Class Initialized
INFO - 2023-06-06 05:03:20 --> Output Class Initialized
INFO - 2023-06-06 05:03:20 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:20 --> Input Class Initialized
INFO - 2023-06-06 05:03:20 --> Language Class Initialized
INFO - 2023-06-06 05:03:20 --> Loader Class Initialized
INFO - 2023-06-06 05:03:21 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:21 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:21 --> Parser Class Initialized
INFO - 2023-06-06 05:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:21 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:21 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:21 --> Controller Class Initialized
INFO - 2023-06-06 05:03:21 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:03:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:21 --> Config Class Initialized
INFO - 2023-06-06 05:03:21 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:21 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:21 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:21 --> URI Class Initialized
INFO - 2023-06-06 05:03:21 --> Router Class Initialized
INFO - 2023-06-06 05:03:21 --> Output Class Initialized
INFO - 2023-06-06 05:03:21 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:21 --> Input Class Initialized
INFO - 2023-06-06 05:03:21 --> Language Class Initialized
INFO - 2023-06-06 05:03:21 --> Loader Class Initialized
INFO - 2023-06-06 05:03:21 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:21 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:21 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:21 --> Parser Class Initialized
INFO - 2023-06-06 05:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:21 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:21 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:21 --> Controller Class Initialized
INFO - 2023-06-06 05:03:21 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:03:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:03:21 --> Model Class Initialized
INFO - 2023-06-06 05:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:03:21 --> Final output sent to browser
DEBUG - 2023-06-06 05:03:21 --> Total execution time: 0.0308
ERROR - 2023-06-06 05:03:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:38 --> Config Class Initialized
INFO - 2023-06-06 05:03:38 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:38 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:38 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:38 --> URI Class Initialized
INFO - 2023-06-06 05:03:38 --> Router Class Initialized
INFO - 2023-06-06 05:03:38 --> Output Class Initialized
INFO - 2023-06-06 05:03:38 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:38 --> Input Class Initialized
INFO - 2023-06-06 05:03:38 --> Language Class Initialized
INFO - 2023-06-06 05:03:38 --> Loader Class Initialized
INFO - 2023-06-06 05:03:38 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:38 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:38 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:38 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:38 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:38 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:38 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:38 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:38 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:38 --> Parser Class Initialized
INFO - 2023-06-06 05:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:38 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:38 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:38 --> Controller Class Initialized
INFO - 2023-06-06 05:03:38 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:38 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-06 05:03:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:03:38 --> Model Class Initialized
INFO - 2023-06-06 05:03:38 --> Model Class Initialized
INFO - 2023-06-06 05:03:38 --> Model Class Initialized
INFO - 2023-06-06 05:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:03:38 --> Final output sent to browser
DEBUG - 2023-06-06 05:03:38 --> Total execution time: 0.0615
ERROR - 2023-06-06 05:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:44 --> Config Class Initialized
INFO - 2023-06-06 05:03:44 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:44 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:44 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:44 --> URI Class Initialized
INFO - 2023-06-06 05:03:44 --> Router Class Initialized
INFO - 2023-06-06 05:03:44 --> Output Class Initialized
INFO - 2023-06-06 05:03:44 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:44 --> Input Class Initialized
INFO - 2023-06-06 05:03:44 --> Language Class Initialized
INFO - 2023-06-06 05:03:44 --> Loader Class Initialized
INFO - 2023-06-06 05:03:44 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:44 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:44 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:44 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:44 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:44 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:44 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:44 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:44 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:44 --> Parser Class Initialized
INFO - 2023-06-06 05:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:44 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:44 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:44 --> Controller Class Initialized
INFO - 2023-06-06 05:03:44 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:03:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:03:44 --> Model Class Initialized
INFO - 2023-06-06 05:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:03:44 --> Final output sent to browser
DEBUG - 2023-06-06 05:03:44 --> Total execution time: 0.0333
ERROR - 2023-06-06 05:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:45 --> Config Class Initialized
INFO - 2023-06-06 05:03:45 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:45 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:45 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:45 --> URI Class Initialized
INFO - 2023-06-06 05:03:45 --> Router Class Initialized
INFO - 2023-06-06 05:03:45 --> Output Class Initialized
INFO - 2023-06-06 05:03:45 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:45 --> Input Class Initialized
INFO - 2023-06-06 05:03:45 --> Language Class Initialized
INFO - 2023-06-06 05:03:45 --> Loader Class Initialized
INFO - 2023-06-06 05:03:45 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:45 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:45 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:45 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:45 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:45 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:45 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:45 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:45 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:45 --> Parser Class Initialized
INFO - 2023-06-06 05:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:45 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:45 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:45 --> Controller Class Initialized
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
INFO - 2023-06-06 05:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:03:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:03:45 --> Model Class Initialized
INFO - 2023-06-06 05:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:03:45 --> Final output sent to browser
DEBUG - 2023-06-06 05:03:45 --> Total execution time: 0.0786
ERROR - 2023-06-06 05:03:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:53 --> Config Class Initialized
INFO - 2023-06-06 05:03:53 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:53 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:53 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:53 --> URI Class Initialized
DEBUG - 2023-06-06 05:03:53 --> No URI present. Default controller set.
INFO - 2023-06-06 05:03:53 --> Router Class Initialized
INFO - 2023-06-06 05:03:53 --> Output Class Initialized
INFO - 2023-06-06 05:03:53 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:53 --> Input Class Initialized
INFO - 2023-06-06 05:03:53 --> Language Class Initialized
INFO - 2023-06-06 05:03:53 --> Loader Class Initialized
INFO - 2023-06-06 05:03:53 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:53 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:53 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:53 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:53 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:53 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:53 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:53 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:53 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:53 --> Parser Class Initialized
INFO - 2023-06-06 05:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:53 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:53 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:53 --> Controller Class Initialized
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
INFO - 2023-06-06 05:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:03:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:03:53 --> Model Class Initialized
INFO - 2023-06-06 05:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:03:53 --> Final output sent to browser
DEBUG - 2023-06-06 05:03:53 --> Total execution time: 0.0657
ERROR - 2023-06-06 05:03:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:54 --> Config Class Initialized
INFO - 2023-06-06 05:03:54 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:54 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:54 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:54 --> URI Class Initialized
INFO - 2023-06-06 05:03:54 --> Router Class Initialized
INFO - 2023-06-06 05:03:54 --> Output Class Initialized
INFO - 2023-06-06 05:03:54 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:54 --> Input Class Initialized
INFO - 2023-06-06 05:03:54 --> Language Class Initialized
INFO - 2023-06-06 05:03:54 --> Loader Class Initialized
INFO - 2023-06-06 05:03:54 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:54 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:54 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:54 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:54 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:54 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:54 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:54 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:54 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:54 --> Parser Class Initialized
INFO - 2023-06-06 05:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:54 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:54 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:54 --> Controller Class Initialized
INFO - 2023-06-06 05:03:54 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:03:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:03:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:03:54 --> Model Class Initialized
INFO - 2023-06-06 05:03:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:03:54 --> Final output sent to browser
DEBUG - 2023-06-06 05:03:54 --> Total execution time: 0.0299
ERROR - 2023-06-06 05:03:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:03:55 --> Config Class Initialized
INFO - 2023-06-06 05:03:55 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:03:55 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:03:55 --> Utf8 Class Initialized
INFO - 2023-06-06 05:03:55 --> URI Class Initialized
INFO - 2023-06-06 05:03:55 --> Router Class Initialized
INFO - 2023-06-06 05:03:55 --> Output Class Initialized
INFO - 2023-06-06 05:03:55 --> Security Class Initialized
DEBUG - 2023-06-06 05:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:03:55 --> Input Class Initialized
INFO - 2023-06-06 05:03:55 --> Language Class Initialized
INFO - 2023-06-06 05:03:55 --> Loader Class Initialized
INFO - 2023-06-06 05:03:55 --> Helper loaded: url_helper
INFO - 2023-06-06 05:03:55 --> Helper loaded: file_helper
INFO - 2023-06-06 05:03:55 --> Helper loaded: html_helper
INFO - 2023-06-06 05:03:55 --> Helper loaded: text_helper
INFO - 2023-06-06 05:03:55 --> Helper loaded: form_helper
INFO - 2023-06-06 05:03:55 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:03:55 --> Helper loaded: security_helper
INFO - 2023-06-06 05:03:55 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:03:55 --> Database Driver Class Initialized
INFO - 2023-06-06 05:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:03:55 --> Parser Class Initialized
INFO - 2023-06-06 05:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:03:55 --> Pagination Class Initialized
INFO - 2023-06-06 05:03:55 --> Form Validation Class Initialized
INFO - 2023-06-06 05:03:55 --> Controller Class Initialized
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:03:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
INFO - 2023-06-06 05:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:03:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:03:55 --> Model Class Initialized
INFO - 2023-06-06 05:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:03:55 --> Final output sent to browser
DEBUG - 2023-06-06 05:03:55 --> Total execution time: 0.0628
ERROR - 2023-06-06 05:09:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:09:18 --> Config Class Initialized
INFO - 2023-06-06 05:09:18 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:09:18 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:09:18 --> Utf8 Class Initialized
INFO - 2023-06-06 05:09:18 --> URI Class Initialized
DEBUG - 2023-06-06 05:09:18 --> No URI present. Default controller set.
INFO - 2023-06-06 05:09:18 --> Router Class Initialized
INFO - 2023-06-06 05:09:18 --> Output Class Initialized
INFO - 2023-06-06 05:09:18 --> Security Class Initialized
DEBUG - 2023-06-06 05:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:09:18 --> Input Class Initialized
INFO - 2023-06-06 05:09:18 --> Language Class Initialized
INFO - 2023-06-06 05:09:18 --> Loader Class Initialized
INFO - 2023-06-06 05:09:18 --> Helper loaded: url_helper
INFO - 2023-06-06 05:09:18 --> Helper loaded: file_helper
INFO - 2023-06-06 05:09:18 --> Helper loaded: html_helper
INFO - 2023-06-06 05:09:18 --> Helper loaded: text_helper
INFO - 2023-06-06 05:09:18 --> Helper loaded: form_helper
INFO - 2023-06-06 05:09:18 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:09:18 --> Helper loaded: security_helper
INFO - 2023-06-06 05:09:18 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:09:18 --> Database Driver Class Initialized
INFO - 2023-06-06 05:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:09:18 --> Parser Class Initialized
INFO - 2023-06-06 05:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:09:18 --> Pagination Class Initialized
INFO - 2023-06-06 05:09:18 --> Form Validation Class Initialized
INFO - 2023-06-06 05:09:18 --> Controller Class Initialized
INFO - 2023-06-06 05:09:18 --> Model Class Initialized
DEBUG - 2023-06-06 05:09:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:09:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:09:19 --> Config Class Initialized
INFO - 2023-06-06 05:09:19 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:09:19 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:09:19 --> Utf8 Class Initialized
INFO - 2023-06-06 05:09:19 --> URI Class Initialized
INFO - 2023-06-06 05:09:19 --> Router Class Initialized
INFO - 2023-06-06 05:09:19 --> Output Class Initialized
INFO - 2023-06-06 05:09:19 --> Security Class Initialized
DEBUG - 2023-06-06 05:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:09:19 --> Input Class Initialized
INFO - 2023-06-06 05:09:19 --> Language Class Initialized
INFO - 2023-06-06 05:09:19 --> Loader Class Initialized
INFO - 2023-06-06 05:09:19 --> Helper loaded: url_helper
INFO - 2023-06-06 05:09:19 --> Helper loaded: file_helper
INFO - 2023-06-06 05:09:19 --> Helper loaded: html_helper
INFO - 2023-06-06 05:09:19 --> Helper loaded: text_helper
INFO - 2023-06-06 05:09:19 --> Helper loaded: form_helper
INFO - 2023-06-06 05:09:19 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:09:19 --> Helper loaded: security_helper
INFO - 2023-06-06 05:09:19 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:09:19 --> Database Driver Class Initialized
INFO - 2023-06-06 05:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:09:19 --> Parser Class Initialized
INFO - 2023-06-06 05:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:09:19 --> Pagination Class Initialized
INFO - 2023-06-06 05:09:19 --> Form Validation Class Initialized
INFO - 2023-06-06 05:09:19 --> Controller Class Initialized
INFO - 2023-06-06 05:09:19 --> Model Class Initialized
DEBUG - 2023-06-06 05:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:09:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:09:19 --> Model Class Initialized
INFO - 2023-06-06 05:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:09:19 --> Final output sent to browser
DEBUG - 2023-06-06 05:09:19 --> Total execution time: 0.0289
ERROR - 2023-06-06 05:09:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:09:41 --> Config Class Initialized
INFO - 2023-06-06 05:09:41 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:09:41 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:09:41 --> Utf8 Class Initialized
INFO - 2023-06-06 05:09:41 --> URI Class Initialized
INFO - 2023-06-06 05:09:41 --> Router Class Initialized
INFO - 2023-06-06 05:09:41 --> Output Class Initialized
INFO - 2023-06-06 05:09:41 --> Security Class Initialized
DEBUG - 2023-06-06 05:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:09:41 --> Input Class Initialized
INFO - 2023-06-06 05:09:41 --> Language Class Initialized
INFO - 2023-06-06 05:09:41 --> Loader Class Initialized
INFO - 2023-06-06 05:09:41 --> Helper loaded: url_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: file_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: html_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: text_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: form_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: security_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:09:41 --> Database Driver Class Initialized
INFO - 2023-06-06 05:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:09:41 --> Parser Class Initialized
INFO - 2023-06-06 05:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:09:41 --> Pagination Class Initialized
INFO - 2023-06-06 05:09:41 --> Form Validation Class Initialized
INFO - 2023-06-06 05:09:41 --> Controller Class Initialized
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
DEBUG - 2023-06-06 05:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
INFO - 2023-06-06 05:09:41 --> Final output sent to browser
DEBUG - 2023-06-06 05:09:41 --> Total execution time: 0.0221
ERROR - 2023-06-06 05:09:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:09:41 --> Config Class Initialized
INFO - 2023-06-06 05:09:41 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:09:41 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:09:41 --> Utf8 Class Initialized
INFO - 2023-06-06 05:09:41 --> URI Class Initialized
DEBUG - 2023-06-06 05:09:41 --> No URI present. Default controller set.
INFO - 2023-06-06 05:09:41 --> Router Class Initialized
INFO - 2023-06-06 05:09:41 --> Output Class Initialized
INFO - 2023-06-06 05:09:41 --> Security Class Initialized
DEBUG - 2023-06-06 05:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:09:41 --> Input Class Initialized
INFO - 2023-06-06 05:09:41 --> Language Class Initialized
INFO - 2023-06-06 05:09:41 --> Loader Class Initialized
INFO - 2023-06-06 05:09:41 --> Helper loaded: url_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: file_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: html_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: text_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: form_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: security_helper
INFO - 2023-06-06 05:09:41 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:09:41 --> Database Driver Class Initialized
INFO - 2023-06-06 05:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:09:41 --> Parser Class Initialized
INFO - 2023-06-06 05:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:09:41 --> Pagination Class Initialized
INFO - 2023-06-06 05:09:41 --> Form Validation Class Initialized
INFO - 2023-06-06 05:09:41 --> Controller Class Initialized
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
DEBUG - 2023-06-06 05:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
DEBUG - 2023-06-06 05:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
DEBUG - 2023-06-06 05:09:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
INFO - 2023-06-06 05:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:09:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:09:41 --> Model Class Initialized
INFO - 2023-06-06 05:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:09:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:09:41 --> Final output sent to browser
DEBUG - 2023-06-06 05:09:41 --> Total execution time: 0.0787
ERROR - 2023-06-06 05:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:10:08 --> Config Class Initialized
INFO - 2023-06-06 05:10:08 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:10:08 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:10:08 --> Utf8 Class Initialized
INFO - 2023-06-06 05:10:08 --> URI Class Initialized
INFO - 2023-06-06 05:10:08 --> Router Class Initialized
INFO - 2023-06-06 05:10:08 --> Output Class Initialized
INFO - 2023-06-06 05:10:08 --> Security Class Initialized
DEBUG - 2023-06-06 05:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:10:08 --> Input Class Initialized
INFO - 2023-06-06 05:10:08 --> Language Class Initialized
INFO - 2023-06-06 05:10:08 --> Loader Class Initialized
INFO - 2023-06-06 05:10:08 --> Helper loaded: url_helper
INFO - 2023-06-06 05:10:08 --> Helper loaded: file_helper
INFO - 2023-06-06 05:10:08 --> Helper loaded: html_helper
INFO - 2023-06-06 05:10:08 --> Helper loaded: text_helper
INFO - 2023-06-06 05:10:08 --> Helper loaded: form_helper
INFO - 2023-06-06 05:10:08 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:10:08 --> Helper loaded: security_helper
INFO - 2023-06-06 05:10:08 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:10:08 --> Database Driver Class Initialized
INFO - 2023-06-06 05:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:10:08 --> Parser Class Initialized
INFO - 2023-06-06 05:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:10:08 --> Pagination Class Initialized
INFO - 2023-06-06 05:10:08 --> Form Validation Class Initialized
INFO - 2023-06-06 05:10:08 --> Controller Class Initialized
INFO - 2023-06-06 05:10:08 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:10:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:10:08 --> Model Class Initialized
INFO - 2023-06-06 05:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:10:08 --> Final output sent to browser
DEBUG - 2023-06-06 05:10:08 --> Total execution time: 0.0326
ERROR - 2023-06-06 05:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:10:09 --> Config Class Initialized
INFO - 2023-06-06 05:10:09 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:10:09 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:10:09 --> Utf8 Class Initialized
INFO - 2023-06-06 05:10:09 --> URI Class Initialized
INFO - 2023-06-06 05:10:09 --> Router Class Initialized
INFO - 2023-06-06 05:10:09 --> Output Class Initialized
INFO - 2023-06-06 05:10:09 --> Security Class Initialized
DEBUG - 2023-06-06 05:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:10:09 --> Input Class Initialized
INFO - 2023-06-06 05:10:09 --> Language Class Initialized
INFO - 2023-06-06 05:10:09 --> Loader Class Initialized
INFO - 2023-06-06 05:10:09 --> Helper loaded: url_helper
INFO - 2023-06-06 05:10:09 --> Helper loaded: file_helper
INFO - 2023-06-06 05:10:09 --> Helper loaded: html_helper
INFO - 2023-06-06 05:10:09 --> Helper loaded: text_helper
INFO - 2023-06-06 05:10:09 --> Helper loaded: form_helper
INFO - 2023-06-06 05:10:09 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:10:09 --> Helper loaded: security_helper
INFO - 2023-06-06 05:10:09 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:10:09 --> Database Driver Class Initialized
INFO - 2023-06-06 05:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:10:09 --> Parser Class Initialized
INFO - 2023-06-06 05:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:10:09 --> Pagination Class Initialized
INFO - 2023-06-06 05:10:09 --> Form Validation Class Initialized
INFO - 2023-06-06 05:10:09 --> Controller Class Initialized
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
INFO - 2023-06-06 05:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:10:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:10:09 --> Model Class Initialized
INFO - 2023-06-06 05:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:10:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:10:09 --> Final output sent to browser
DEBUG - 2023-06-06 05:10:09 --> Total execution time: 0.0808
ERROR - 2023-06-06 05:10:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:10:36 --> Config Class Initialized
INFO - 2023-06-06 05:10:36 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:10:36 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:10:36 --> Utf8 Class Initialized
INFO - 2023-06-06 05:10:36 --> URI Class Initialized
DEBUG - 2023-06-06 05:10:36 --> No URI present. Default controller set.
INFO - 2023-06-06 05:10:36 --> Router Class Initialized
INFO - 2023-06-06 05:10:36 --> Output Class Initialized
INFO - 2023-06-06 05:10:36 --> Security Class Initialized
DEBUG - 2023-06-06 05:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:10:36 --> Input Class Initialized
INFO - 2023-06-06 05:10:36 --> Language Class Initialized
INFO - 2023-06-06 05:10:36 --> Loader Class Initialized
INFO - 2023-06-06 05:10:36 --> Helper loaded: url_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: file_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: html_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: text_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: form_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: security_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:10:36 --> Database Driver Class Initialized
INFO - 2023-06-06 05:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:10:36 --> Parser Class Initialized
INFO - 2023-06-06 05:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:10:36 --> Pagination Class Initialized
INFO - 2023-06-06 05:10:36 --> Form Validation Class Initialized
INFO - 2023-06-06 05:10:36 --> Controller Class Initialized
INFO - 2023-06-06 05:10:36 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:10:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:10:36 --> Config Class Initialized
INFO - 2023-06-06 05:10:36 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:10:36 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:10:36 --> Utf8 Class Initialized
INFO - 2023-06-06 05:10:36 --> URI Class Initialized
INFO - 2023-06-06 05:10:36 --> Router Class Initialized
INFO - 2023-06-06 05:10:36 --> Output Class Initialized
INFO - 2023-06-06 05:10:36 --> Security Class Initialized
DEBUG - 2023-06-06 05:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:10:36 --> Input Class Initialized
INFO - 2023-06-06 05:10:36 --> Language Class Initialized
INFO - 2023-06-06 05:10:36 --> Loader Class Initialized
INFO - 2023-06-06 05:10:36 --> Helper loaded: url_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: file_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: html_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: text_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: form_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: security_helper
INFO - 2023-06-06 05:10:36 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:10:36 --> Database Driver Class Initialized
INFO - 2023-06-06 05:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:10:36 --> Parser Class Initialized
INFO - 2023-06-06 05:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:10:36 --> Pagination Class Initialized
INFO - 2023-06-06 05:10:36 --> Form Validation Class Initialized
INFO - 2023-06-06 05:10:36 --> Controller Class Initialized
INFO - 2023-06-06 05:10:36 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:10:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:10:36 --> Model Class Initialized
INFO - 2023-06-06 05:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:10:36 --> Final output sent to browser
DEBUG - 2023-06-06 05:10:36 --> Total execution time: 0.0336
ERROR - 2023-06-06 05:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:10:51 --> Config Class Initialized
INFO - 2023-06-06 05:10:51 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:10:51 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:10:51 --> Utf8 Class Initialized
INFO - 2023-06-06 05:10:51 --> URI Class Initialized
INFO - 2023-06-06 05:10:51 --> Router Class Initialized
INFO - 2023-06-06 05:10:51 --> Output Class Initialized
INFO - 2023-06-06 05:10:51 --> Security Class Initialized
DEBUG - 2023-06-06 05:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:10:51 --> Input Class Initialized
INFO - 2023-06-06 05:10:51 --> Language Class Initialized
INFO - 2023-06-06 05:10:51 --> Loader Class Initialized
INFO - 2023-06-06 05:10:51 --> Helper loaded: url_helper
INFO - 2023-06-06 05:10:51 --> Helper loaded: file_helper
INFO - 2023-06-06 05:10:51 --> Helper loaded: html_helper
INFO - 2023-06-06 05:10:51 --> Helper loaded: text_helper
INFO - 2023-06-06 05:10:51 --> Helper loaded: form_helper
INFO - 2023-06-06 05:10:51 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:10:51 --> Helper loaded: security_helper
INFO - 2023-06-06 05:10:51 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:10:51 --> Database Driver Class Initialized
INFO - 2023-06-06 05:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:10:52 --> Parser Class Initialized
INFO - 2023-06-06 05:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:10:52 --> Pagination Class Initialized
INFO - 2023-06-06 05:10:52 --> Form Validation Class Initialized
INFO - 2023-06-06 05:10:52 --> Controller Class Initialized
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
INFO - 2023-06-06 05:10:52 --> Final output sent to browser
DEBUG - 2023-06-06 05:10:52 --> Total execution time: 0.0194
ERROR - 2023-06-06 05:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:10:52 --> Config Class Initialized
INFO - 2023-06-06 05:10:52 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:10:52 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:10:52 --> Utf8 Class Initialized
INFO - 2023-06-06 05:10:52 --> URI Class Initialized
DEBUG - 2023-06-06 05:10:52 --> No URI present. Default controller set.
INFO - 2023-06-06 05:10:52 --> Router Class Initialized
INFO - 2023-06-06 05:10:52 --> Output Class Initialized
INFO - 2023-06-06 05:10:52 --> Security Class Initialized
DEBUG - 2023-06-06 05:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:10:52 --> Input Class Initialized
INFO - 2023-06-06 05:10:52 --> Language Class Initialized
INFO - 2023-06-06 05:10:52 --> Loader Class Initialized
INFO - 2023-06-06 05:10:52 --> Helper loaded: url_helper
INFO - 2023-06-06 05:10:52 --> Helper loaded: file_helper
INFO - 2023-06-06 05:10:52 --> Helper loaded: html_helper
INFO - 2023-06-06 05:10:52 --> Helper loaded: text_helper
INFO - 2023-06-06 05:10:52 --> Helper loaded: form_helper
INFO - 2023-06-06 05:10:52 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:10:52 --> Helper loaded: security_helper
INFO - 2023-06-06 05:10:52 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:10:52 --> Database Driver Class Initialized
INFO - 2023-06-06 05:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:10:52 --> Parser Class Initialized
INFO - 2023-06-06 05:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:10:52 --> Pagination Class Initialized
INFO - 2023-06-06 05:10:52 --> Form Validation Class Initialized
INFO - 2023-06-06 05:10:52 --> Controller Class Initialized
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
DEBUG - 2023-06-06 05:10:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
INFO - 2023-06-06 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:10:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:10:52 --> Model Class Initialized
INFO - 2023-06-06 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:10:52 --> Final output sent to browser
DEBUG - 2023-06-06 05:10:52 --> Total execution time: 0.0685
ERROR - 2023-06-06 05:11:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:11:00 --> Config Class Initialized
INFO - 2023-06-06 05:11:00 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:11:00 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:11:00 --> Utf8 Class Initialized
INFO - 2023-06-06 05:11:00 --> URI Class Initialized
DEBUG - 2023-06-06 05:11:00 --> No URI present. Default controller set.
INFO - 2023-06-06 05:11:00 --> Router Class Initialized
INFO - 2023-06-06 05:11:00 --> Output Class Initialized
INFO - 2023-06-06 05:11:00 --> Security Class Initialized
DEBUG - 2023-06-06 05:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:11:00 --> Input Class Initialized
INFO - 2023-06-06 05:11:00 --> Language Class Initialized
INFO - 2023-06-06 05:11:00 --> Loader Class Initialized
INFO - 2023-06-06 05:11:00 --> Helper loaded: url_helper
INFO - 2023-06-06 05:11:00 --> Helper loaded: file_helper
INFO - 2023-06-06 05:11:00 --> Helper loaded: html_helper
INFO - 2023-06-06 05:11:00 --> Helper loaded: text_helper
INFO - 2023-06-06 05:11:00 --> Helper loaded: form_helper
INFO - 2023-06-06 05:11:00 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:11:00 --> Helper loaded: security_helper
INFO - 2023-06-06 05:11:00 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:11:00 --> Database Driver Class Initialized
INFO - 2023-06-06 05:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:11:00 --> Parser Class Initialized
INFO - 2023-06-06 05:11:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:11:00 --> Pagination Class Initialized
INFO - 2023-06-06 05:11:00 --> Form Validation Class Initialized
INFO - 2023-06-06 05:11:00 --> Controller Class Initialized
INFO - 2023-06-06 05:11:00 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:11:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:11:02 --> Config Class Initialized
INFO - 2023-06-06 05:11:02 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:11:02 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:11:02 --> Utf8 Class Initialized
INFO - 2023-06-06 05:11:02 --> URI Class Initialized
INFO - 2023-06-06 05:11:02 --> Router Class Initialized
INFO - 2023-06-06 05:11:02 --> Output Class Initialized
INFO - 2023-06-06 05:11:02 --> Security Class Initialized
DEBUG - 2023-06-06 05:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:11:02 --> Input Class Initialized
INFO - 2023-06-06 05:11:02 --> Language Class Initialized
INFO - 2023-06-06 05:11:02 --> Loader Class Initialized
INFO - 2023-06-06 05:11:02 --> Helper loaded: url_helper
INFO - 2023-06-06 05:11:02 --> Helper loaded: file_helper
INFO - 2023-06-06 05:11:02 --> Helper loaded: html_helper
INFO - 2023-06-06 05:11:02 --> Helper loaded: text_helper
INFO - 2023-06-06 05:11:02 --> Helper loaded: form_helper
INFO - 2023-06-06 05:11:02 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:11:02 --> Helper loaded: security_helper
INFO - 2023-06-06 05:11:02 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:11:02 --> Database Driver Class Initialized
INFO - 2023-06-06 05:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:11:02 --> Parser Class Initialized
INFO - 2023-06-06 05:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:11:02 --> Pagination Class Initialized
INFO - 2023-06-06 05:11:02 --> Form Validation Class Initialized
INFO - 2023-06-06 05:11:02 --> Controller Class Initialized
INFO - 2023-06-06 05:11:02 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:11:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:11:02 --> Model Class Initialized
INFO - 2023-06-06 05:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:11:02 --> Final output sent to browser
DEBUG - 2023-06-06 05:11:02 --> Total execution time: 0.0306
ERROR - 2023-06-06 05:11:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:11:05 --> Config Class Initialized
INFO - 2023-06-06 05:11:05 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:11:05 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:11:05 --> Utf8 Class Initialized
INFO - 2023-06-06 05:11:05 --> URI Class Initialized
INFO - 2023-06-06 05:11:05 --> Router Class Initialized
INFO - 2023-06-06 05:11:05 --> Output Class Initialized
INFO - 2023-06-06 05:11:05 --> Security Class Initialized
DEBUG - 2023-06-06 05:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:11:05 --> Input Class Initialized
INFO - 2023-06-06 05:11:05 --> Language Class Initialized
INFO - 2023-06-06 05:11:05 --> Loader Class Initialized
INFO - 2023-06-06 05:11:05 --> Helper loaded: url_helper
INFO - 2023-06-06 05:11:05 --> Helper loaded: file_helper
INFO - 2023-06-06 05:11:05 --> Helper loaded: html_helper
INFO - 2023-06-06 05:11:05 --> Helper loaded: text_helper
INFO - 2023-06-06 05:11:05 --> Helper loaded: form_helper
INFO - 2023-06-06 05:11:05 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:11:05 --> Helper loaded: security_helper
INFO - 2023-06-06 05:11:05 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:11:05 --> Database Driver Class Initialized
INFO - 2023-06-06 05:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:11:05 --> Parser Class Initialized
INFO - 2023-06-06 05:11:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:11:05 --> Pagination Class Initialized
INFO - 2023-06-06 05:11:05 --> Form Validation Class Initialized
INFO - 2023-06-06 05:11:05 --> Controller Class Initialized
INFO - 2023-06-06 05:11:05 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:05 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:05 --> Model Class Initialized
INFO - 2023-06-06 05:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-06 05:11:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:11:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:11:05 --> Model Class Initialized
INFO - 2023-06-06 05:11:06 --> Model Class Initialized
INFO - 2023-06-06 05:11:06 --> Model Class Initialized
INFO - 2023-06-06 05:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:11:06 --> Final output sent to browser
DEBUG - 2023-06-06 05:11:06 --> Total execution time: 0.0751
ERROR - 2023-06-06 05:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:11:06 --> Config Class Initialized
INFO - 2023-06-06 05:11:06 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:11:06 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:11:06 --> Utf8 Class Initialized
INFO - 2023-06-06 05:11:06 --> URI Class Initialized
INFO - 2023-06-06 05:11:06 --> Router Class Initialized
INFO - 2023-06-06 05:11:06 --> Output Class Initialized
INFO - 2023-06-06 05:11:06 --> Security Class Initialized
DEBUG - 2023-06-06 05:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:11:06 --> Input Class Initialized
INFO - 2023-06-06 05:11:06 --> Language Class Initialized
INFO - 2023-06-06 05:11:06 --> Loader Class Initialized
INFO - 2023-06-06 05:11:06 --> Helper loaded: url_helper
INFO - 2023-06-06 05:11:06 --> Helper loaded: file_helper
INFO - 2023-06-06 05:11:06 --> Helper loaded: html_helper
INFO - 2023-06-06 05:11:06 --> Helper loaded: text_helper
INFO - 2023-06-06 05:11:06 --> Helper loaded: form_helper
INFO - 2023-06-06 05:11:06 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:11:06 --> Helper loaded: security_helper
INFO - 2023-06-06 05:11:06 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:11:06 --> Database Driver Class Initialized
INFO - 2023-06-06 05:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:11:06 --> Parser Class Initialized
INFO - 2023-06-06 05:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:11:06 --> Pagination Class Initialized
INFO - 2023-06-06 05:11:06 --> Form Validation Class Initialized
INFO - 2023-06-06 05:11:06 --> Controller Class Initialized
INFO - 2023-06-06 05:11:06 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:06 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:06 --> Model Class Initialized
INFO - 2023-06-06 05:11:06 --> Final output sent to browser
DEBUG - 2023-06-06 05:11:06 --> Total execution time: 0.0229
ERROR - 2023-06-06 05:11:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:11:33 --> Config Class Initialized
INFO - 2023-06-06 05:11:33 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:11:33 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:11:33 --> Utf8 Class Initialized
INFO - 2023-06-06 05:11:33 --> URI Class Initialized
DEBUG - 2023-06-06 05:11:33 --> No URI present. Default controller set.
INFO - 2023-06-06 05:11:33 --> Router Class Initialized
INFO - 2023-06-06 05:11:33 --> Output Class Initialized
INFO - 2023-06-06 05:11:33 --> Security Class Initialized
DEBUG - 2023-06-06 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:11:33 --> Input Class Initialized
INFO - 2023-06-06 05:11:33 --> Language Class Initialized
INFO - 2023-06-06 05:11:33 --> Loader Class Initialized
INFO - 2023-06-06 05:11:33 --> Helper loaded: url_helper
INFO - 2023-06-06 05:11:33 --> Helper loaded: file_helper
INFO - 2023-06-06 05:11:33 --> Helper loaded: html_helper
INFO - 2023-06-06 05:11:33 --> Helper loaded: text_helper
INFO - 2023-06-06 05:11:33 --> Helper loaded: form_helper
INFO - 2023-06-06 05:11:33 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:11:33 --> Helper loaded: security_helper
INFO - 2023-06-06 05:11:33 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:11:33 --> Database Driver Class Initialized
INFO - 2023-06-06 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:11:33 --> Parser Class Initialized
INFO - 2023-06-06 05:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:11:33 --> Pagination Class Initialized
INFO - 2023-06-06 05:11:33 --> Form Validation Class Initialized
INFO - 2023-06-06 05:11:33 --> Controller Class Initialized
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
INFO - 2023-06-06 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:11:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:11:33 --> Model Class Initialized
INFO - 2023-06-06 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:11:33 --> Final output sent to browser
DEBUG - 2023-06-06 05:11:33 --> Total execution time: 0.0669
ERROR - 2023-06-06 05:11:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:11:44 --> Config Class Initialized
INFO - 2023-06-06 05:11:44 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:11:44 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:11:44 --> Utf8 Class Initialized
INFO - 2023-06-06 05:11:44 --> URI Class Initialized
INFO - 2023-06-06 05:11:44 --> Router Class Initialized
INFO - 2023-06-06 05:11:44 --> Output Class Initialized
INFO - 2023-06-06 05:11:44 --> Security Class Initialized
DEBUG - 2023-06-06 05:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:11:44 --> Input Class Initialized
INFO - 2023-06-06 05:11:44 --> Language Class Initialized
INFO - 2023-06-06 05:11:44 --> Loader Class Initialized
INFO - 2023-06-06 05:11:44 --> Helper loaded: url_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: file_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: html_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: text_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: form_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: security_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:11:44 --> Database Driver Class Initialized
INFO - 2023-06-06 05:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:11:44 --> Parser Class Initialized
INFO - 2023-06-06 05:11:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:11:44 --> Pagination Class Initialized
INFO - 2023-06-06 05:11:44 --> Form Validation Class Initialized
INFO - 2023-06-06 05:11:44 --> Controller Class Initialized
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:11:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:11:44 --> Final output sent to browser
DEBUG - 2023-06-06 05:11:44 --> Total execution time: 0.0307
ERROR - 2023-06-06 05:11:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:11:44 --> Config Class Initialized
INFO - 2023-06-06 05:11:44 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:11:44 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:11:44 --> Utf8 Class Initialized
INFO - 2023-06-06 05:11:44 --> URI Class Initialized
INFO - 2023-06-06 05:11:44 --> Router Class Initialized
INFO - 2023-06-06 05:11:44 --> Output Class Initialized
INFO - 2023-06-06 05:11:44 --> Security Class Initialized
DEBUG - 2023-06-06 05:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:11:44 --> Input Class Initialized
INFO - 2023-06-06 05:11:44 --> Language Class Initialized
INFO - 2023-06-06 05:11:44 --> Loader Class Initialized
INFO - 2023-06-06 05:11:44 --> Helper loaded: url_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: file_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: html_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: text_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: form_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: security_helper
INFO - 2023-06-06 05:11:44 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:11:44 --> Database Driver Class Initialized
INFO - 2023-06-06 05:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:11:44 --> Parser Class Initialized
INFO - 2023-06-06 05:11:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:11:44 --> Pagination Class Initialized
INFO - 2023-06-06 05:11:44 --> Form Validation Class Initialized
INFO - 2023-06-06 05:11:44 --> Controller Class Initialized
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
DEBUG - 2023-06-06 05:11:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:11:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:11:44 --> Model Class Initialized
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:11:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:11:44 --> Final output sent to browser
DEBUG - 2023-06-06 05:11:44 --> Total execution time: 0.0672
ERROR - 2023-06-06 05:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:36 --> Config Class Initialized
INFO - 2023-06-06 05:15:36 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:36 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:36 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:36 --> URI Class Initialized
DEBUG - 2023-06-06 05:15:36 --> No URI present. Default controller set.
INFO - 2023-06-06 05:15:36 --> Router Class Initialized
INFO - 2023-06-06 05:15:36 --> Output Class Initialized
INFO - 2023-06-06 05:15:36 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:36 --> Input Class Initialized
INFO - 2023-06-06 05:15:36 --> Language Class Initialized
INFO - 2023-06-06 05:15:36 --> Loader Class Initialized
INFO - 2023-06-06 05:15:36 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:36 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:36 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:36 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:36 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:36 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:36 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:36 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:36 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:36 --> Parser Class Initialized
INFO - 2023-06-06 05:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:36 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:36 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:36 --> Controller Class Initialized
INFO - 2023-06-06 05:15:36 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:37 --> Config Class Initialized
INFO - 2023-06-06 05:15:37 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:37 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:37 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:37 --> URI Class Initialized
INFO - 2023-06-06 05:15:37 --> Router Class Initialized
INFO - 2023-06-06 05:15:37 --> Output Class Initialized
INFO - 2023-06-06 05:15:37 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:37 --> Input Class Initialized
INFO - 2023-06-06 05:15:37 --> Language Class Initialized
INFO - 2023-06-06 05:15:37 --> Loader Class Initialized
INFO - 2023-06-06 05:15:37 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:37 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:37 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:37 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:37 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:37 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:37 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:37 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:37 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:37 --> Parser Class Initialized
INFO - 2023-06-06 05:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:37 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:37 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:37 --> Controller Class Initialized
INFO - 2023-06-06 05:15:37 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:15:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:15:37 --> Model Class Initialized
INFO - 2023-06-06 05:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:15:37 --> Final output sent to browser
DEBUG - 2023-06-06 05:15:37 --> Total execution time: 0.0278
ERROR - 2023-06-06 05:15:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:42 --> Config Class Initialized
INFO - 2023-06-06 05:15:42 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:42 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:42 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:42 --> URI Class Initialized
INFO - 2023-06-06 05:15:42 --> Router Class Initialized
INFO - 2023-06-06 05:15:42 --> Output Class Initialized
INFO - 2023-06-06 05:15:42 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:42 --> Input Class Initialized
INFO - 2023-06-06 05:15:42 --> Language Class Initialized
INFO - 2023-06-06 05:15:42 --> Loader Class Initialized
INFO - 2023-06-06 05:15:42 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:42 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:42 --> Parser Class Initialized
INFO - 2023-06-06 05:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:42 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:42 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:42 --> Controller Class Initialized
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
INFO - 2023-06-06 05:15:42 --> Final output sent to browser
DEBUG - 2023-06-06 05:15:42 --> Total execution time: 0.0175
ERROR - 2023-06-06 05:15:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:42 --> Config Class Initialized
INFO - 2023-06-06 05:15:42 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:42 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:42 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:42 --> URI Class Initialized
DEBUG - 2023-06-06 05:15:42 --> No URI present. Default controller set.
INFO - 2023-06-06 05:15:42 --> Router Class Initialized
INFO - 2023-06-06 05:15:42 --> Output Class Initialized
INFO - 2023-06-06 05:15:42 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:42 --> Input Class Initialized
INFO - 2023-06-06 05:15:42 --> Language Class Initialized
INFO - 2023-06-06 05:15:42 --> Loader Class Initialized
INFO - 2023-06-06 05:15:42 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:42 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:42 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:42 --> Parser Class Initialized
INFO - 2023-06-06 05:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:42 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:42 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:42 --> Controller Class Initialized
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
INFO - 2023-06-06 05:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:15:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:15:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:15:42 --> Model Class Initialized
INFO - 2023-06-06 05:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:15:43 --> Final output sent to browser
DEBUG - 2023-06-06 05:15:43 --> Total execution time: 0.1996
ERROR - 2023-06-06 05:15:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:44 --> Config Class Initialized
INFO - 2023-06-06 05:15:44 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:44 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:44 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:44 --> URI Class Initialized
INFO - 2023-06-06 05:15:44 --> Router Class Initialized
INFO - 2023-06-06 05:15:44 --> Output Class Initialized
INFO - 2023-06-06 05:15:44 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:44 --> Input Class Initialized
INFO - 2023-06-06 05:15:44 --> Language Class Initialized
INFO - 2023-06-06 05:15:44 --> Loader Class Initialized
INFO - 2023-06-06 05:15:44 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:44 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:44 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:44 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:44 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:44 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:44 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:44 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:44 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:44 --> Parser Class Initialized
INFO - 2023-06-06 05:15:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:44 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:44 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:44 --> Controller Class Initialized
DEBUG - 2023-06-06 05:15:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:44 --> Model Class Initialized
INFO - 2023-06-06 05:15:44 --> Final output sent to browser
DEBUG - 2023-06-06 05:15:44 --> Total execution time: 0.0159
ERROR - 2023-06-06 05:15:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:54 --> Config Class Initialized
INFO - 2023-06-06 05:15:54 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:54 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:54 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:54 --> URI Class Initialized
INFO - 2023-06-06 05:15:54 --> Router Class Initialized
INFO - 2023-06-06 05:15:54 --> Output Class Initialized
INFO - 2023-06-06 05:15:54 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:54 --> Input Class Initialized
INFO - 2023-06-06 05:15:54 --> Language Class Initialized
INFO - 2023-06-06 05:15:54 --> Loader Class Initialized
INFO - 2023-06-06 05:15:54 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:54 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:54 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:54 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:54 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:54 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:54 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:54 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:54 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:54 --> Parser Class Initialized
INFO - 2023-06-06 05:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:54 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:54 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:54 --> Controller Class Initialized
INFO - 2023-06-06 05:15:54 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:54 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:54 --> Model Class Initialized
INFO - 2023-06-06 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-06 05:15:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:15:54 --> Model Class Initialized
INFO - 2023-06-06 05:15:54 --> Model Class Initialized
INFO - 2023-06-06 05:15:54 --> Model Class Initialized
INFO - 2023-06-06 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:15:54 --> Final output sent to browser
DEBUG - 2023-06-06 05:15:54 --> Total execution time: 0.1370
ERROR - 2023-06-06 05:15:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:55 --> Config Class Initialized
INFO - 2023-06-06 05:15:55 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:55 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:55 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:55 --> URI Class Initialized
INFO - 2023-06-06 05:15:55 --> Router Class Initialized
INFO - 2023-06-06 05:15:55 --> Output Class Initialized
INFO - 2023-06-06 05:15:55 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:55 --> Input Class Initialized
INFO - 2023-06-06 05:15:55 --> Language Class Initialized
INFO - 2023-06-06 05:15:55 --> Loader Class Initialized
INFO - 2023-06-06 05:15:55 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:55 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:55 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:55 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:55 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:55 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:55 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:55 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:55 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:55 --> Parser Class Initialized
INFO - 2023-06-06 05:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:55 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:55 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:55 --> Controller Class Initialized
INFO - 2023-06-06 05:15:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:55 --> Model Class Initialized
INFO - 2023-06-06 05:15:55 --> Final output sent to browser
DEBUG - 2023-06-06 05:15:55 --> Total execution time: 0.0531
ERROR - 2023-06-06 05:15:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:15:59 --> Config Class Initialized
INFO - 2023-06-06 05:15:59 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:15:59 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:15:59 --> Utf8 Class Initialized
INFO - 2023-06-06 05:15:59 --> URI Class Initialized
INFO - 2023-06-06 05:15:59 --> Router Class Initialized
INFO - 2023-06-06 05:15:59 --> Output Class Initialized
INFO - 2023-06-06 05:15:59 --> Security Class Initialized
DEBUG - 2023-06-06 05:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:15:59 --> Input Class Initialized
INFO - 2023-06-06 05:15:59 --> Language Class Initialized
INFO - 2023-06-06 05:15:59 --> Loader Class Initialized
INFO - 2023-06-06 05:15:59 --> Helper loaded: url_helper
INFO - 2023-06-06 05:15:59 --> Helper loaded: file_helper
INFO - 2023-06-06 05:15:59 --> Helper loaded: html_helper
INFO - 2023-06-06 05:15:59 --> Helper loaded: text_helper
INFO - 2023-06-06 05:15:59 --> Helper loaded: form_helper
INFO - 2023-06-06 05:15:59 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:15:59 --> Helper loaded: security_helper
INFO - 2023-06-06 05:15:59 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:15:59 --> Database Driver Class Initialized
INFO - 2023-06-06 05:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:15:59 --> Parser Class Initialized
INFO - 2023-06-06 05:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:15:59 --> Pagination Class Initialized
INFO - 2023-06-06 05:15:59 --> Form Validation Class Initialized
INFO - 2023-06-06 05:15:59 --> Controller Class Initialized
INFO - 2023-06-06 05:15:59 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:59 --> Model Class Initialized
DEBUG - 2023-06-06 05:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:15:59 --> Model Class Initialized
INFO - 2023-06-06 05:16:00 --> Final output sent to browser
DEBUG - 2023-06-06 05:16:00 --> Total execution time: 0.2117
ERROR - 2023-06-06 05:16:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:16:14 --> Config Class Initialized
INFO - 2023-06-06 05:16:14 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:16:14 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:16:14 --> Utf8 Class Initialized
INFO - 2023-06-06 05:16:14 --> URI Class Initialized
INFO - 2023-06-06 05:16:14 --> Router Class Initialized
INFO - 2023-06-06 05:16:14 --> Output Class Initialized
INFO - 2023-06-06 05:16:14 --> Security Class Initialized
DEBUG - 2023-06-06 05:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:16:14 --> Input Class Initialized
INFO - 2023-06-06 05:16:14 --> Language Class Initialized
INFO - 2023-06-06 05:16:14 --> Loader Class Initialized
INFO - 2023-06-06 05:16:14 --> Helper loaded: url_helper
INFO - 2023-06-06 05:16:14 --> Helper loaded: file_helper
INFO - 2023-06-06 05:16:14 --> Helper loaded: html_helper
INFO - 2023-06-06 05:16:14 --> Helper loaded: text_helper
INFO - 2023-06-06 05:16:14 --> Helper loaded: form_helper
INFO - 2023-06-06 05:16:14 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:16:14 --> Helper loaded: security_helper
INFO - 2023-06-06 05:16:14 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:16:14 --> Database Driver Class Initialized
INFO - 2023-06-06 05:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:16:14 --> Parser Class Initialized
INFO - 2023-06-06 05:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:16:14 --> Pagination Class Initialized
INFO - 2023-06-06 05:16:14 --> Form Validation Class Initialized
INFO - 2023-06-06 05:16:14 --> Controller Class Initialized
INFO - 2023-06-06 05:16:14 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:14 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:14 --> Model Class Initialized
INFO - 2023-06-06 05:16:14 --> Final output sent to browser
DEBUG - 2023-06-06 05:16:14 --> Total execution time: 0.0898
ERROR - 2023-06-06 05:16:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:16:55 --> Config Class Initialized
INFO - 2023-06-06 05:16:55 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:16:55 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:16:55 --> Utf8 Class Initialized
INFO - 2023-06-06 05:16:55 --> URI Class Initialized
DEBUG - 2023-06-06 05:16:55 --> No URI present. Default controller set.
INFO - 2023-06-06 05:16:55 --> Router Class Initialized
INFO - 2023-06-06 05:16:55 --> Output Class Initialized
INFO - 2023-06-06 05:16:55 --> Security Class Initialized
DEBUG - 2023-06-06 05:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:16:55 --> Input Class Initialized
INFO - 2023-06-06 05:16:55 --> Language Class Initialized
INFO - 2023-06-06 05:16:55 --> Loader Class Initialized
INFO - 2023-06-06 05:16:55 --> Helper loaded: url_helper
INFO - 2023-06-06 05:16:55 --> Helper loaded: file_helper
INFO - 2023-06-06 05:16:55 --> Helper loaded: html_helper
INFO - 2023-06-06 05:16:55 --> Helper loaded: text_helper
INFO - 2023-06-06 05:16:55 --> Helper loaded: form_helper
INFO - 2023-06-06 05:16:55 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:16:55 --> Helper loaded: security_helper
INFO - 2023-06-06 05:16:55 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:16:55 --> Database Driver Class Initialized
INFO - 2023-06-06 05:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:16:55 --> Parser Class Initialized
INFO - 2023-06-06 05:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:16:55 --> Pagination Class Initialized
INFO - 2023-06-06 05:16:55 --> Form Validation Class Initialized
INFO - 2023-06-06 05:16:55 --> Controller Class Initialized
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
INFO - 2023-06-06 05:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:16:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:16:55 --> Model Class Initialized
INFO - 2023-06-06 05:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:16:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:16:55 --> Final output sent to browser
DEBUG - 2023-06-06 05:16:55 --> Total execution time: 0.1954
ERROR - 2023-06-06 05:16:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:16:58 --> Config Class Initialized
INFO - 2023-06-06 05:16:58 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:16:58 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:16:58 --> Utf8 Class Initialized
INFO - 2023-06-06 05:16:58 --> URI Class Initialized
DEBUG - 2023-06-06 05:16:58 --> No URI present. Default controller set.
INFO - 2023-06-06 05:16:58 --> Router Class Initialized
INFO - 2023-06-06 05:16:58 --> Output Class Initialized
INFO - 2023-06-06 05:16:58 --> Security Class Initialized
DEBUG - 2023-06-06 05:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:16:58 --> Input Class Initialized
INFO - 2023-06-06 05:16:58 --> Language Class Initialized
INFO - 2023-06-06 05:16:58 --> Loader Class Initialized
INFO - 2023-06-06 05:16:58 --> Helper loaded: url_helper
INFO - 2023-06-06 05:16:58 --> Helper loaded: file_helper
INFO - 2023-06-06 05:16:58 --> Helper loaded: html_helper
INFO - 2023-06-06 05:16:58 --> Helper loaded: text_helper
INFO - 2023-06-06 05:16:58 --> Helper loaded: form_helper
INFO - 2023-06-06 05:16:58 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:16:58 --> Helper loaded: security_helper
INFO - 2023-06-06 05:16:58 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:16:58 --> Database Driver Class Initialized
INFO - 2023-06-06 05:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:16:58 --> Parser Class Initialized
INFO - 2023-06-06 05:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:16:58 --> Pagination Class Initialized
INFO - 2023-06-06 05:16:58 --> Form Validation Class Initialized
INFO - 2023-06-06 05:16:58 --> Controller Class Initialized
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
DEBUG - 2023-06-06 05:16:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:16:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
INFO - 2023-06-06 05:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:16:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:16:58 --> Model Class Initialized
INFO - 2023-06-06 05:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:16:58 --> Final output sent to browser
DEBUG - 2023-06-06 05:16:58 --> Total execution time: 0.1841
ERROR - 2023-06-06 05:17:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:17:26 --> Config Class Initialized
INFO - 2023-06-06 05:17:26 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:17:26 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:17:26 --> Utf8 Class Initialized
INFO - 2023-06-06 05:17:26 --> URI Class Initialized
DEBUG - 2023-06-06 05:17:26 --> No URI present. Default controller set.
INFO - 2023-06-06 05:17:26 --> Router Class Initialized
INFO - 2023-06-06 05:17:26 --> Output Class Initialized
INFO - 2023-06-06 05:17:26 --> Security Class Initialized
DEBUG - 2023-06-06 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:17:26 --> Input Class Initialized
INFO - 2023-06-06 05:17:26 --> Language Class Initialized
INFO - 2023-06-06 05:17:26 --> Loader Class Initialized
INFO - 2023-06-06 05:17:26 --> Helper loaded: url_helper
INFO - 2023-06-06 05:17:26 --> Helper loaded: file_helper
INFO - 2023-06-06 05:17:26 --> Helper loaded: html_helper
INFO - 2023-06-06 05:17:26 --> Helper loaded: text_helper
INFO - 2023-06-06 05:17:26 --> Helper loaded: form_helper
INFO - 2023-06-06 05:17:26 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:17:26 --> Helper loaded: security_helper
INFO - 2023-06-06 05:17:26 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:17:26 --> Database Driver Class Initialized
INFO - 2023-06-06 05:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:17:26 --> Parser Class Initialized
INFO - 2023-06-06 05:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:17:26 --> Pagination Class Initialized
INFO - 2023-06-06 05:17:26 --> Form Validation Class Initialized
INFO - 2023-06-06 05:17:26 --> Controller Class Initialized
INFO - 2023-06-06 05:17:26 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 05:17:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:17:27 --> Config Class Initialized
INFO - 2023-06-06 05:17:27 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:17:27 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:17:27 --> Utf8 Class Initialized
INFO - 2023-06-06 05:17:27 --> URI Class Initialized
INFO - 2023-06-06 05:17:27 --> Router Class Initialized
INFO - 2023-06-06 05:17:27 --> Output Class Initialized
INFO - 2023-06-06 05:17:27 --> Security Class Initialized
DEBUG - 2023-06-06 05:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:17:27 --> Input Class Initialized
INFO - 2023-06-06 05:17:27 --> Language Class Initialized
INFO - 2023-06-06 05:17:27 --> Loader Class Initialized
INFO - 2023-06-06 05:17:27 --> Helper loaded: url_helper
INFO - 2023-06-06 05:17:27 --> Helper loaded: file_helper
INFO - 2023-06-06 05:17:27 --> Helper loaded: html_helper
INFO - 2023-06-06 05:17:27 --> Helper loaded: text_helper
INFO - 2023-06-06 05:17:27 --> Helper loaded: form_helper
INFO - 2023-06-06 05:17:27 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:17:27 --> Helper loaded: security_helper
INFO - 2023-06-06 05:17:27 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:17:27 --> Database Driver Class Initialized
INFO - 2023-06-06 05:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:17:27 --> Parser Class Initialized
INFO - 2023-06-06 05:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:17:27 --> Pagination Class Initialized
INFO - 2023-06-06 05:17:27 --> Form Validation Class Initialized
INFO - 2023-06-06 05:17:27 --> Controller Class Initialized
INFO - 2023-06-06 05:17:27 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 05:17:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:17:27 --> Model Class Initialized
INFO - 2023-06-06 05:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:17:27 --> Final output sent to browser
DEBUG - 2023-06-06 05:17:27 --> Total execution time: 0.0336
ERROR - 2023-06-06 05:17:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:17:32 --> Config Class Initialized
INFO - 2023-06-06 05:17:32 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:17:32 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:17:32 --> Utf8 Class Initialized
INFO - 2023-06-06 05:17:32 --> URI Class Initialized
INFO - 2023-06-06 05:17:32 --> Router Class Initialized
INFO - 2023-06-06 05:17:32 --> Output Class Initialized
INFO - 2023-06-06 05:17:32 --> Security Class Initialized
DEBUG - 2023-06-06 05:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:17:32 --> Input Class Initialized
INFO - 2023-06-06 05:17:32 --> Language Class Initialized
INFO - 2023-06-06 05:17:32 --> Loader Class Initialized
INFO - 2023-06-06 05:17:32 --> Helper loaded: url_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: file_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: html_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: text_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: form_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: security_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:17:32 --> Database Driver Class Initialized
INFO - 2023-06-06 05:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:17:32 --> Parser Class Initialized
INFO - 2023-06-06 05:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:17:32 --> Pagination Class Initialized
INFO - 2023-06-06 05:17:32 --> Form Validation Class Initialized
INFO - 2023-06-06 05:17:32 --> Controller Class Initialized
INFO - 2023-06-06 05:17:32 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:32 --> Model Class Initialized
INFO - 2023-06-06 05:17:32 --> Final output sent to browser
DEBUG - 2023-06-06 05:17:32 --> Total execution time: 0.0172
ERROR - 2023-06-06 05:17:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:17:32 --> Config Class Initialized
INFO - 2023-06-06 05:17:32 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:17:32 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:17:32 --> Utf8 Class Initialized
INFO - 2023-06-06 05:17:32 --> URI Class Initialized
DEBUG - 2023-06-06 05:17:32 --> No URI present. Default controller set.
INFO - 2023-06-06 05:17:32 --> Router Class Initialized
INFO - 2023-06-06 05:17:32 --> Output Class Initialized
INFO - 2023-06-06 05:17:32 --> Security Class Initialized
DEBUG - 2023-06-06 05:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:17:32 --> Input Class Initialized
INFO - 2023-06-06 05:17:32 --> Language Class Initialized
INFO - 2023-06-06 05:17:32 --> Loader Class Initialized
INFO - 2023-06-06 05:17:32 --> Helper loaded: url_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: file_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: html_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: text_helper
INFO - 2023-06-06 05:17:32 --> Helper loaded: form_helper
INFO - 2023-06-06 05:17:33 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:17:33 --> Helper loaded: security_helper
INFO - 2023-06-06 05:17:33 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:17:33 --> Database Driver Class Initialized
INFO - 2023-06-06 05:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:17:33 --> Parser Class Initialized
INFO - 2023-06-06 05:17:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:17:33 --> Pagination Class Initialized
INFO - 2023-06-06 05:17:33 --> Form Validation Class Initialized
INFO - 2023-06-06 05:17:33 --> Controller Class Initialized
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
INFO - 2023-06-06 05:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:17:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:17:33 --> Model Class Initialized
INFO - 2023-06-06 05:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:17:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:17:33 --> Final output sent to browser
DEBUG - 2023-06-06 05:17:33 --> Total execution time: 0.0820
ERROR - 2023-06-06 05:17:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:17:38 --> Config Class Initialized
INFO - 2023-06-06 05:17:38 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:17:38 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:17:38 --> Utf8 Class Initialized
INFO - 2023-06-06 05:17:38 --> URI Class Initialized
DEBUG - 2023-06-06 05:17:38 --> No URI present. Default controller set.
INFO - 2023-06-06 05:17:38 --> Router Class Initialized
INFO - 2023-06-06 05:17:38 --> Output Class Initialized
INFO - 2023-06-06 05:17:38 --> Security Class Initialized
DEBUG - 2023-06-06 05:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:17:38 --> Input Class Initialized
INFO - 2023-06-06 05:17:38 --> Language Class Initialized
INFO - 2023-06-06 05:17:38 --> Loader Class Initialized
INFO - 2023-06-06 05:17:38 --> Helper loaded: url_helper
INFO - 2023-06-06 05:17:38 --> Helper loaded: file_helper
INFO - 2023-06-06 05:17:38 --> Helper loaded: html_helper
INFO - 2023-06-06 05:17:38 --> Helper loaded: text_helper
INFO - 2023-06-06 05:17:38 --> Helper loaded: form_helper
INFO - 2023-06-06 05:17:38 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:17:38 --> Helper loaded: security_helper
INFO - 2023-06-06 05:17:38 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:17:38 --> Database Driver Class Initialized
INFO - 2023-06-06 05:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:17:38 --> Parser Class Initialized
INFO - 2023-06-06 05:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:17:38 --> Pagination Class Initialized
INFO - 2023-06-06 05:17:38 --> Form Validation Class Initialized
INFO - 2023-06-06 05:17:38 --> Controller Class Initialized
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
INFO - 2023-06-06 05:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:17:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:17:38 --> Model Class Initialized
INFO - 2023-06-06 05:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:17:38 --> Final output sent to browser
DEBUG - 2023-06-06 05:17:38 --> Total execution time: 0.0807
ERROR - 2023-06-06 05:17:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:17:53 --> Config Class Initialized
INFO - 2023-06-06 05:17:53 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:17:53 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:17:53 --> Utf8 Class Initialized
INFO - 2023-06-06 05:17:53 --> URI Class Initialized
DEBUG - 2023-06-06 05:17:53 --> No URI present. Default controller set.
INFO - 2023-06-06 05:17:53 --> Router Class Initialized
INFO - 2023-06-06 05:17:53 --> Output Class Initialized
INFO - 2023-06-06 05:17:53 --> Security Class Initialized
DEBUG - 2023-06-06 05:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:17:53 --> Input Class Initialized
INFO - 2023-06-06 05:17:53 --> Language Class Initialized
INFO - 2023-06-06 05:17:53 --> Loader Class Initialized
INFO - 2023-06-06 05:17:53 --> Helper loaded: url_helper
INFO - 2023-06-06 05:17:53 --> Helper loaded: file_helper
INFO - 2023-06-06 05:17:53 --> Helper loaded: html_helper
INFO - 2023-06-06 05:17:53 --> Helper loaded: text_helper
INFO - 2023-06-06 05:17:53 --> Helper loaded: form_helper
INFO - 2023-06-06 05:17:53 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:17:53 --> Helper loaded: security_helper
INFO - 2023-06-06 05:17:53 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:17:53 --> Database Driver Class Initialized
INFO - 2023-06-06 05:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:17:53 --> Parser Class Initialized
INFO - 2023-06-06 05:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:17:53 --> Pagination Class Initialized
INFO - 2023-06-06 05:17:54 --> Form Validation Class Initialized
INFO - 2023-06-06 05:17:54 --> Controller Class Initialized
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
DEBUG - 2023-06-06 05:17:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
INFO - 2023-06-06 05:17:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:17:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:17:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:17:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:17:54 --> Model Class Initialized
INFO - 2023-06-06 05:17:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:17:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:17:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:17:54 --> Final output sent to browser
DEBUG - 2023-06-06 05:17:54 --> Total execution time: 0.0865
ERROR - 2023-06-06 05:18:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 05:18:05 --> Config Class Initialized
INFO - 2023-06-06 05:18:05 --> Hooks Class Initialized
DEBUG - 2023-06-06 05:18:05 --> UTF-8 Support Enabled
INFO - 2023-06-06 05:18:05 --> Utf8 Class Initialized
INFO - 2023-06-06 05:18:05 --> URI Class Initialized
DEBUG - 2023-06-06 05:18:05 --> No URI present. Default controller set.
INFO - 2023-06-06 05:18:05 --> Router Class Initialized
INFO - 2023-06-06 05:18:05 --> Output Class Initialized
INFO - 2023-06-06 05:18:05 --> Security Class Initialized
DEBUG - 2023-06-06 05:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 05:18:05 --> Input Class Initialized
INFO - 2023-06-06 05:18:05 --> Language Class Initialized
INFO - 2023-06-06 05:18:05 --> Loader Class Initialized
INFO - 2023-06-06 05:18:05 --> Helper loaded: url_helper
INFO - 2023-06-06 05:18:05 --> Helper loaded: file_helper
INFO - 2023-06-06 05:18:05 --> Helper loaded: html_helper
INFO - 2023-06-06 05:18:05 --> Helper loaded: text_helper
INFO - 2023-06-06 05:18:05 --> Helper loaded: form_helper
INFO - 2023-06-06 05:18:05 --> Helper loaded: lang_helper
INFO - 2023-06-06 05:18:05 --> Helper loaded: security_helper
INFO - 2023-06-06 05:18:05 --> Helper loaded: cookie_helper
INFO - 2023-06-06 05:18:05 --> Database Driver Class Initialized
INFO - 2023-06-06 05:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 05:18:05 --> Parser Class Initialized
INFO - 2023-06-06 05:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 05:18:05 --> Pagination Class Initialized
INFO - 2023-06-06 05:18:05 --> Form Validation Class Initialized
INFO - 2023-06-06 05:18:05 --> Controller Class Initialized
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
DEBUG - 2023-06-06 05:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
DEBUG - 2023-06-06 05:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
DEBUG - 2023-06-06 05:18:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 05:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
INFO - 2023-06-06 05:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 05:18:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 05:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 05:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 05:18:05 --> Model Class Initialized
INFO - 2023-06-06 05:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 05:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 05:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 05:18:05 --> Final output sent to browser
DEBUG - 2023-06-06 05:18:05 --> Total execution time: 0.1915
ERROR - 2023-06-06 06:07:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:07:31 --> Config Class Initialized
INFO - 2023-06-06 06:07:31 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:07:31 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:07:31 --> Utf8 Class Initialized
INFO - 2023-06-06 06:07:31 --> URI Class Initialized
DEBUG - 2023-06-06 06:07:31 --> No URI present. Default controller set.
INFO - 2023-06-06 06:07:31 --> Router Class Initialized
INFO - 2023-06-06 06:07:31 --> Output Class Initialized
INFO - 2023-06-06 06:07:31 --> Security Class Initialized
DEBUG - 2023-06-06 06:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:07:31 --> Input Class Initialized
INFO - 2023-06-06 06:07:31 --> Language Class Initialized
INFO - 2023-06-06 06:07:31 --> Loader Class Initialized
INFO - 2023-06-06 06:07:31 --> Helper loaded: url_helper
INFO - 2023-06-06 06:07:31 --> Helper loaded: file_helper
INFO - 2023-06-06 06:07:31 --> Helper loaded: html_helper
INFO - 2023-06-06 06:07:31 --> Helper loaded: text_helper
INFO - 2023-06-06 06:07:31 --> Helper loaded: form_helper
INFO - 2023-06-06 06:07:31 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:07:31 --> Helper loaded: security_helper
INFO - 2023-06-06 06:07:31 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:07:31 --> Database Driver Class Initialized
INFO - 2023-06-06 06:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:07:31 --> Parser Class Initialized
INFO - 2023-06-06 06:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:07:31 --> Pagination Class Initialized
INFO - 2023-06-06 06:07:31 --> Form Validation Class Initialized
INFO - 2023-06-06 06:07:31 --> Controller Class Initialized
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
DEBUG - 2023-06-06 06:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
DEBUG - 2023-06-06 06:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
DEBUG - 2023-06-06 06:07:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
INFO - 2023-06-06 06:07:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 06:07:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:07:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:07:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:07:31 --> Model Class Initialized
INFO - 2023-06-06 06:07:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 06:07:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 06:07:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:07:31 --> Final output sent to browser
DEBUG - 2023-06-06 06:07:31 --> Total execution time: 0.1810
ERROR - 2023-06-06 06:08:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:08:53 --> Config Class Initialized
INFO - 2023-06-06 06:08:53 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:08:53 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:08:53 --> Utf8 Class Initialized
INFO - 2023-06-06 06:08:53 --> URI Class Initialized
DEBUG - 2023-06-06 06:08:53 --> No URI present. Default controller set.
INFO - 2023-06-06 06:08:53 --> Router Class Initialized
INFO - 2023-06-06 06:08:53 --> Output Class Initialized
INFO - 2023-06-06 06:08:53 --> Security Class Initialized
DEBUG - 2023-06-06 06:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:08:53 --> Input Class Initialized
INFO - 2023-06-06 06:08:53 --> Language Class Initialized
INFO - 2023-06-06 06:08:53 --> Loader Class Initialized
INFO - 2023-06-06 06:08:53 --> Helper loaded: url_helper
INFO - 2023-06-06 06:08:53 --> Helper loaded: file_helper
INFO - 2023-06-06 06:08:53 --> Helper loaded: html_helper
INFO - 2023-06-06 06:08:53 --> Helper loaded: text_helper
INFO - 2023-06-06 06:08:53 --> Helper loaded: form_helper
INFO - 2023-06-06 06:08:53 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:08:53 --> Helper loaded: security_helper
INFO - 2023-06-06 06:08:53 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:08:53 --> Database Driver Class Initialized
INFO - 2023-06-06 06:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:08:53 --> Parser Class Initialized
INFO - 2023-06-06 06:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:08:53 --> Pagination Class Initialized
INFO - 2023-06-06 06:08:53 --> Form Validation Class Initialized
INFO - 2023-06-06 06:08:53 --> Controller Class Initialized
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
DEBUG - 2023-06-06 06:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
DEBUG - 2023-06-06 06:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
DEBUG - 2023-06-06 06:08:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
INFO - 2023-06-06 06:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 06:08:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:08:53 --> Model Class Initialized
INFO - 2023-06-06 06:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 06:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 06:08:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:08:53 --> Final output sent to browser
DEBUG - 2023-06-06 06:08:53 --> Total execution time: 0.1755
ERROR - 2023-06-06 06:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:17:25 --> Config Class Initialized
INFO - 2023-06-06 06:17:25 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:17:25 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:17:25 --> Utf8 Class Initialized
INFO - 2023-06-06 06:17:25 --> URI Class Initialized
DEBUG - 2023-06-06 06:17:25 --> No URI present. Default controller set.
INFO - 2023-06-06 06:17:25 --> Router Class Initialized
INFO - 2023-06-06 06:17:25 --> Output Class Initialized
INFO - 2023-06-06 06:17:25 --> Security Class Initialized
DEBUG - 2023-06-06 06:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:17:25 --> Input Class Initialized
INFO - 2023-06-06 06:17:25 --> Language Class Initialized
INFO - 2023-06-06 06:17:25 --> Loader Class Initialized
INFO - 2023-06-06 06:17:25 --> Helper loaded: url_helper
INFO - 2023-06-06 06:17:25 --> Helper loaded: file_helper
INFO - 2023-06-06 06:17:25 --> Helper loaded: html_helper
INFO - 2023-06-06 06:17:25 --> Helper loaded: text_helper
INFO - 2023-06-06 06:17:25 --> Helper loaded: form_helper
INFO - 2023-06-06 06:17:25 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:17:25 --> Helper loaded: security_helper
INFO - 2023-06-06 06:17:25 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:17:25 --> Database Driver Class Initialized
INFO - 2023-06-06 06:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:17:25 --> Parser Class Initialized
INFO - 2023-06-06 06:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:17:25 --> Pagination Class Initialized
INFO - 2023-06-06 06:17:25 --> Form Validation Class Initialized
INFO - 2023-06-06 06:17:25 --> Controller Class Initialized
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
INFO - 2023-06-06 06:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 06:17:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:17:25 --> Model Class Initialized
INFO - 2023-06-06 06:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 06:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 06:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:17:25 --> Final output sent to browser
DEBUG - 2023-06-06 06:17:25 --> Total execution time: 0.1889
ERROR - 2023-06-06 06:17:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:17:31 --> Config Class Initialized
INFO - 2023-06-06 06:17:31 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:17:31 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:17:31 --> Utf8 Class Initialized
INFO - 2023-06-06 06:17:31 --> URI Class Initialized
INFO - 2023-06-06 06:17:31 --> Router Class Initialized
INFO - 2023-06-06 06:17:31 --> Output Class Initialized
INFO - 2023-06-06 06:17:31 --> Security Class Initialized
DEBUG - 2023-06-06 06:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:17:31 --> Input Class Initialized
INFO - 2023-06-06 06:17:31 --> Language Class Initialized
INFO - 2023-06-06 06:17:31 --> Loader Class Initialized
INFO - 2023-06-06 06:17:31 --> Helper loaded: url_helper
INFO - 2023-06-06 06:17:31 --> Helper loaded: file_helper
INFO - 2023-06-06 06:17:31 --> Helper loaded: html_helper
INFO - 2023-06-06 06:17:31 --> Helper loaded: text_helper
INFO - 2023-06-06 06:17:31 --> Helper loaded: form_helper
INFO - 2023-06-06 06:17:31 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:17:31 --> Helper loaded: security_helper
INFO - 2023-06-06 06:17:31 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:17:31 --> Database Driver Class Initialized
INFO - 2023-06-06 06:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:17:31 --> Parser Class Initialized
INFO - 2023-06-06 06:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:17:31 --> Pagination Class Initialized
INFO - 2023-06-06 06:17:31 --> Form Validation Class Initialized
INFO - 2023-06-06 06:17:31 --> Controller Class Initialized
INFO - 2023-06-06 06:17:31 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:31 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:31 --> Model Class Initialized
INFO - 2023-06-06 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-06 06:17:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:17:31 --> Model Class Initialized
INFO - 2023-06-06 06:17:31 --> Model Class Initialized
INFO - 2023-06-06 06:17:31 --> Model Class Initialized
INFO - 2023-06-06 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 06:17:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:17:31 --> Final output sent to browser
DEBUG - 2023-06-06 06:17:31 --> Total execution time: 0.1301
ERROR - 2023-06-06 06:17:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:17:32 --> Config Class Initialized
INFO - 2023-06-06 06:17:32 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:17:32 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:17:32 --> Utf8 Class Initialized
INFO - 2023-06-06 06:17:32 --> URI Class Initialized
INFO - 2023-06-06 06:17:32 --> Router Class Initialized
INFO - 2023-06-06 06:17:32 --> Output Class Initialized
INFO - 2023-06-06 06:17:32 --> Security Class Initialized
DEBUG - 2023-06-06 06:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:17:32 --> Input Class Initialized
INFO - 2023-06-06 06:17:32 --> Language Class Initialized
INFO - 2023-06-06 06:17:32 --> Loader Class Initialized
INFO - 2023-06-06 06:17:32 --> Helper loaded: url_helper
INFO - 2023-06-06 06:17:32 --> Helper loaded: file_helper
INFO - 2023-06-06 06:17:32 --> Helper loaded: html_helper
INFO - 2023-06-06 06:17:32 --> Helper loaded: text_helper
INFO - 2023-06-06 06:17:32 --> Helper loaded: form_helper
INFO - 2023-06-06 06:17:32 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:17:32 --> Helper loaded: security_helper
INFO - 2023-06-06 06:17:32 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:17:32 --> Database Driver Class Initialized
INFO - 2023-06-06 06:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:17:32 --> Parser Class Initialized
INFO - 2023-06-06 06:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:17:32 --> Pagination Class Initialized
INFO - 2023-06-06 06:17:32 --> Form Validation Class Initialized
INFO - 2023-06-06 06:17:32 --> Controller Class Initialized
INFO - 2023-06-06 06:17:32 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:32 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:32 --> Model Class Initialized
INFO - 2023-06-06 06:17:32 --> Final output sent to browser
DEBUG - 2023-06-06 06:17:32 --> Total execution time: 0.0544
ERROR - 2023-06-06 06:17:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:17:36 --> Config Class Initialized
INFO - 2023-06-06 06:17:36 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:17:36 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:17:36 --> Utf8 Class Initialized
INFO - 2023-06-06 06:17:36 --> URI Class Initialized
INFO - 2023-06-06 06:17:36 --> Router Class Initialized
INFO - 2023-06-06 06:17:36 --> Output Class Initialized
INFO - 2023-06-06 06:17:36 --> Security Class Initialized
DEBUG - 2023-06-06 06:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:17:36 --> Input Class Initialized
INFO - 2023-06-06 06:17:36 --> Language Class Initialized
INFO - 2023-06-06 06:17:36 --> Loader Class Initialized
INFO - 2023-06-06 06:17:36 --> Helper loaded: url_helper
INFO - 2023-06-06 06:17:36 --> Helper loaded: file_helper
INFO - 2023-06-06 06:17:36 --> Helper loaded: html_helper
INFO - 2023-06-06 06:17:36 --> Helper loaded: text_helper
INFO - 2023-06-06 06:17:36 --> Helper loaded: form_helper
INFO - 2023-06-06 06:17:36 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:17:36 --> Helper loaded: security_helper
INFO - 2023-06-06 06:17:36 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:17:36 --> Database Driver Class Initialized
INFO - 2023-06-06 06:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:17:36 --> Parser Class Initialized
INFO - 2023-06-06 06:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:17:36 --> Pagination Class Initialized
INFO - 2023-06-06 06:17:36 --> Form Validation Class Initialized
INFO - 2023-06-06 06:17:36 --> Controller Class Initialized
INFO - 2023-06-06 06:17:36 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:17:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:36 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:36 --> Model Class Initialized
INFO - 2023-06-06 06:17:36 --> Final output sent to browser
DEBUG - 2023-06-06 06:17:36 --> Total execution time: 0.2272
ERROR - 2023-06-06 06:17:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:17:48 --> Config Class Initialized
INFO - 2023-06-06 06:17:48 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:17:48 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:17:48 --> Utf8 Class Initialized
INFO - 2023-06-06 06:17:48 --> URI Class Initialized
DEBUG - 2023-06-06 06:17:48 --> No URI present. Default controller set.
INFO - 2023-06-06 06:17:48 --> Router Class Initialized
INFO - 2023-06-06 06:17:48 --> Output Class Initialized
INFO - 2023-06-06 06:17:48 --> Security Class Initialized
DEBUG - 2023-06-06 06:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:17:48 --> Input Class Initialized
INFO - 2023-06-06 06:17:48 --> Language Class Initialized
INFO - 2023-06-06 06:17:48 --> Loader Class Initialized
INFO - 2023-06-06 06:17:48 --> Helper loaded: url_helper
INFO - 2023-06-06 06:17:48 --> Helper loaded: file_helper
INFO - 2023-06-06 06:17:48 --> Helper loaded: html_helper
INFO - 2023-06-06 06:17:48 --> Helper loaded: text_helper
INFO - 2023-06-06 06:17:48 --> Helper loaded: form_helper
INFO - 2023-06-06 06:17:48 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:17:48 --> Helper loaded: security_helper
INFO - 2023-06-06 06:17:48 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:17:48 --> Database Driver Class Initialized
INFO - 2023-06-06 06:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:17:48 --> Parser Class Initialized
INFO - 2023-06-06 06:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:17:48 --> Pagination Class Initialized
INFO - 2023-06-06 06:17:48 --> Form Validation Class Initialized
INFO - 2023-06-06 06:17:48 --> Controller Class Initialized
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
DEBUG - 2023-06-06 06:17:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
INFO - 2023-06-06 06:17:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 06:17:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:17:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:17:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:17:48 --> Model Class Initialized
INFO - 2023-06-06 06:17:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 06:17:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 06:17:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:17:48 --> Final output sent to browser
DEBUG - 2023-06-06 06:17:48 --> Total execution time: 0.1812
ERROR - 2023-06-06 06:42:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:42:13 --> Config Class Initialized
INFO - 2023-06-06 06:42:13 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:42:13 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:42:13 --> Utf8 Class Initialized
INFO - 2023-06-06 06:42:13 --> URI Class Initialized
INFO - 2023-06-06 06:42:13 --> Router Class Initialized
INFO - 2023-06-06 06:42:13 --> Output Class Initialized
INFO - 2023-06-06 06:42:13 --> Security Class Initialized
DEBUG - 2023-06-06 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:42:13 --> Input Class Initialized
INFO - 2023-06-06 06:42:13 --> Language Class Initialized
INFO - 2023-06-06 06:42:13 --> Loader Class Initialized
INFO - 2023-06-06 06:42:13 --> Helper loaded: url_helper
INFO - 2023-06-06 06:42:13 --> Helper loaded: file_helper
INFO - 2023-06-06 06:42:13 --> Helper loaded: html_helper
INFO - 2023-06-06 06:42:13 --> Helper loaded: text_helper
INFO - 2023-06-06 06:42:13 --> Helper loaded: form_helper
INFO - 2023-06-06 06:42:13 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:42:13 --> Helper loaded: security_helper
INFO - 2023-06-06 06:42:13 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:42:13 --> Database Driver Class Initialized
INFO - 2023-06-06 06:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:42:13 --> Parser Class Initialized
INFO - 2023-06-06 06:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:42:13 --> Pagination Class Initialized
INFO - 2023-06-06 06:42:13 --> Form Validation Class Initialized
INFO - 2023-06-06 06:42:13 --> Controller Class Initialized
INFO - 2023-06-06 06:42:13 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:13 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:13 --> Model Class Initialized
INFO - 2023-06-06 06:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-06 06:42:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:42:13 --> Model Class Initialized
INFO - 2023-06-06 06:42:13 --> Model Class Initialized
INFO - 2023-06-06 06:42:13 --> Model Class Initialized
INFO - 2023-06-06 06:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 06:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 06:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:42:13 --> Final output sent to browser
DEBUG - 2023-06-06 06:42:13 --> Total execution time: 0.1499
ERROR - 2023-06-06 06:42:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:42:14 --> Config Class Initialized
INFO - 2023-06-06 06:42:14 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:42:14 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:42:14 --> Utf8 Class Initialized
INFO - 2023-06-06 06:42:14 --> URI Class Initialized
INFO - 2023-06-06 06:42:14 --> Router Class Initialized
INFO - 2023-06-06 06:42:14 --> Output Class Initialized
INFO - 2023-06-06 06:42:14 --> Security Class Initialized
DEBUG - 2023-06-06 06:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:42:14 --> Input Class Initialized
INFO - 2023-06-06 06:42:14 --> Language Class Initialized
INFO - 2023-06-06 06:42:14 --> Loader Class Initialized
INFO - 2023-06-06 06:42:14 --> Helper loaded: url_helper
INFO - 2023-06-06 06:42:14 --> Helper loaded: file_helper
INFO - 2023-06-06 06:42:14 --> Helper loaded: html_helper
INFO - 2023-06-06 06:42:14 --> Helper loaded: text_helper
INFO - 2023-06-06 06:42:14 --> Helper loaded: form_helper
INFO - 2023-06-06 06:42:14 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:42:14 --> Helper loaded: security_helper
INFO - 2023-06-06 06:42:14 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:42:14 --> Database Driver Class Initialized
INFO - 2023-06-06 06:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:42:14 --> Parser Class Initialized
INFO - 2023-06-06 06:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:42:14 --> Pagination Class Initialized
INFO - 2023-06-06 06:42:14 --> Form Validation Class Initialized
INFO - 2023-06-06 06:42:14 --> Controller Class Initialized
INFO - 2023-06-06 06:42:14 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:14 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:14 --> Model Class Initialized
INFO - 2023-06-06 06:42:14 --> Final output sent to browser
DEBUG - 2023-06-06 06:42:14 --> Total execution time: 0.0490
ERROR - 2023-06-06 06:42:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:42:40 --> Config Class Initialized
INFO - 2023-06-06 06:42:40 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:42:40 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:42:40 --> Utf8 Class Initialized
INFO - 2023-06-06 06:42:40 --> URI Class Initialized
INFO - 2023-06-06 06:42:40 --> Router Class Initialized
INFO - 2023-06-06 06:42:40 --> Output Class Initialized
INFO - 2023-06-06 06:42:40 --> Security Class Initialized
DEBUG - 2023-06-06 06:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:42:40 --> Input Class Initialized
INFO - 2023-06-06 06:42:40 --> Language Class Initialized
INFO - 2023-06-06 06:42:40 --> Loader Class Initialized
INFO - 2023-06-06 06:42:40 --> Helper loaded: url_helper
INFO - 2023-06-06 06:42:40 --> Helper loaded: file_helper
INFO - 2023-06-06 06:42:40 --> Helper loaded: html_helper
INFO - 2023-06-06 06:42:40 --> Helper loaded: text_helper
INFO - 2023-06-06 06:42:40 --> Helper loaded: form_helper
INFO - 2023-06-06 06:42:40 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:42:40 --> Helper loaded: security_helper
INFO - 2023-06-06 06:42:40 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:42:40 --> Database Driver Class Initialized
INFO - 2023-06-06 06:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:42:40 --> Parser Class Initialized
INFO - 2023-06-06 06:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:42:40 --> Pagination Class Initialized
INFO - 2023-06-06 06:42:40 --> Form Validation Class Initialized
INFO - 2023-06-06 06:42:40 --> Controller Class Initialized
INFO - 2023-06-06 06:42:40 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:40 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:40 --> Model Class Initialized
INFO - 2023-06-06 06:42:40 --> Final output sent to browser
DEBUG - 2023-06-06 06:42:40 --> Total execution time: 0.0505
ERROR - 2023-06-06 06:42:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:42:55 --> Config Class Initialized
INFO - 2023-06-06 06:42:55 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:42:55 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:42:55 --> Utf8 Class Initialized
INFO - 2023-06-06 06:42:55 --> URI Class Initialized
DEBUG - 2023-06-06 06:42:55 --> No URI present. Default controller set.
INFO - 2023-06-06 06:42:55 --> Router Class Initialized
INFO - 2023-06-06 06:42:55 --> Output Class Initialized
INFO - 2023-06-06 06:42:55 --> Security Class Initialized
DEBUG - 2023-06-06 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:42:55 --> Input Class Initialized
INFO - 2023-06-06 06:42:55 --> Language Class Initialized
INFO - 2023-06-06 06:42:55 --> Loader Class Initialized
INFO - 2023-06-06 06:42:55 --> Helper loaded: url_helper
INFO - 2023-06-06 06:42:55 --> Helper loaded: file_helper
INFO - 2023-06-06 06:42:55 --> Helper loaded: html_helper
INFO - 2023-06-06 06:42:55 --> Helper loaded: text_helper
INFO - 2023-06-06 06:42:55 --> Helper loaded: form_helper
INFO - 2023-06-06 06:42:55 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:42:55 --> Helper loaded: security_helper
INFO - 2023-06-06 06:42:55 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:42:55 --> Database Driver Class Initialized
INFO - 2023-06-06 06:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:42:55 --> Parser Class Initialized
INFO - 2023-06-06 06:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:42:55 --> Pagination Class Initialized
INFO - 2023-06-06 06:42:55 --> Form Validation Class Initialized
INFO - 2023-06-06 06:42:55 --> Controller Class Initialized
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
DEBUG - 2023-06-06 06:42:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 06:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
INFO - 2023-06-06 06:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 06:42:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:42:55 --> Model Class Initialized
INFO - 2023-06-06 06:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 06:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 06:42:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:42:55 --> Final output sent to browser
DEBUG - 2023-06-06 06:42:55 --> Total execution time: 0.2005
ERROR - 2023-06-06 06:54:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:54:32 --> Config Class Initialized
INFO - 2023-06-06 06:54:32 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:54:32 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:54:32 --> Utf8 Class Initialized
INFO - 2023-06-06 06:54:32 --> URI Class Initialized
DEBUG - 2023-06-06 06:54:32 --> No URI present. Default controller set.
INFO - 2023-06-06 06:54:32 --> Router Class Initialized
INFO - 2023-06-06 06:54:32 --> Output Class Initialized
INFO - 2023-06-06 06:54:32 --> Security Class Initialized
DEBUG - 2023-06-06 06:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:54:32 --> Input Class Initialized
INFO - 2023-06-06 06:54:32 --> Language Class Initialized
INFO - 2023-06-06 06:54:32 --> Loader Class Initialized
INFO - 2023-06-06 06:54:32 --> Helper loaded: url_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: file_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: html_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: text_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: form_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: security_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:54:32 --> Database Driver Class Initialized
INFO - 2023-06-06 06:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:54:32 --> Parser Class Initialized
INFO - 2023-06-06 06:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:54:32 --> Pagination Class Initialized
INFO - 2023-06-06 06:54:32 --> Form Validation Class Initialized
INFO - 2023-06-06 06:54:32 --> Controller Class Initialized
INFO - 2023-06-06 06:54:32 --> Model Class Initialized
DEBUG - 2023-06-06 06:54:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 06:54:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 06:54:32 --> Config Class Initialized
INFO - 2023-06-06 06:54:32 --> Hooks Class Initialized
DEBUG - 2023-06-06 06:54:32 --> UTF-8 Support Enabled
INFO - 2023-06-06 06:54:32 --> Utf8 Class Initialized
INFO - 2023-06-06 06:54:32 --> URI Class Initialized
INFO - 2023-06-06 06:54:32 --> Router Class Initialized
INFO - 2023-06-06 06:54:32 --> Output Class Initialized
INFO - 2023-06-06 06:54:32 --> Security Class Initialized
DEBUG - 2023-06-06 06:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 06:54:32 --> Input Class Initialized
INFO - 2023-06-06 06:54:32 --> Language Class Initialized
INFO - 2023-06-06 06:54:32 --> Loader Class Initialized
INFO - 2023-06-06 06:54:32 --> Helper loaded: url_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: file_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: html_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: text_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: form_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: lang_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: security_helper
INFO - 2023-06-06 06:54:32 --> Helper loaded: cookie_helper
INFO - 2023-06-06 06:54:32 --> Database Driver Class Initialized
INFO - 2023-06-06 06:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 06:54:32 --> Parser Class Initialized
INFO - 2023-06-06 06:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 06:54:32 --> Pagination Class Initialized
INFO - 2023-06-06 06:54:32 --> Form Validation Class Initialized
INFO - 2023-06-06 06:54:32 --> Controller Class Initialized
INFO - 2023-06-06 06:54:32 --> Model Class Initialized
DEBUG - 2023-06-06 06:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 06:54:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 06:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 06:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 06:54:32 --> Model Class Initialized
INFO - 2023-06-06 06:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 06:54:32 --> Final output sent to browser
DEBUG - 2023-06-06 06:54:32 --> Total execution time: 0.0301
ERROR - 2023-06-06 07:47:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 07:47:29 --> Config Class Initialized
INFO - 2023-06-06 07:47:29 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:47:29 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:47:29 --> Utf8 Class Initialized
INFO - 2023-06-06 07:47:29 --> URI Class Initialized
DEBUG - 2023-06-06 07:47:29 --> No URI present. Default controller set.
INFO - 2023-06-06 07:47:29 --> Router Class Initialized
INFO - 2023-06-06 07:47:29 --> Output Class Initialized
INFO - 2023-06-06 07:47:29 --> Security Class Initialized
DEBUG - 2023-06-06 07:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:47:29 --> Input Class Initialized
INFO - 2023-06-06 07:47:29 --> Language Class Initialized
INFO - 2023-06-06 07:47:29 --> Loader Class Initialized
INFO - 2023-06-06 07:47:29 --> Helper loaded: url_helper
INFO - 2023-06-06 07:47:29 --> Helper loaded: file_helper
INFO - 2023-06-06 07:47:29 --> Helper loaded: html_helper
INFO - 2023-06-06 07:47:29 --> Helper loaded: text_helper
INFO - 2023-06-06 07:47:29 --> Helper loaded: form_helper
INFO - 2023-06-06 07:47:29 --> Helper loaded: lang_helper
INFO - 2023-06-06 07:47:29 --> Helper loaded: security_helper
INFO - 2023-06-06 07:47:29 --> Helper loaded: cookie_helper
INFO - 2023-06-06 07:47:29 --> Database Driver Class Initialized
INFO - 2023-06-06 07:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:47:29 --> Parser Class Initialized
INFO - 2023-06-06 07:47:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 07:47:29 --> Pagination Class Initialized
INFO - 2023-06-06 07:47:29 --> Form Validation Class Initialized
INFO - 2023-06-06 07:47:29 --> Controller Class Initialized
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
DEBUG - 2023-06-06 07:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
DEBUG - 2023-06-06 07:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
DEBUG - 2023-06-06 07:47:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 07:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
INFO - 2023-06-06 07:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 07:47:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 07:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 07:47:29 --> Model Class Initialized
INFO - 2023-06-06 07:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 07:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 07:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 07:47:29 --> Final output sent to browser
DEBUG - 2023-06-06 07:47:29 --> Total execution time: 0.1866
ERROR - 2023-06-06 07:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 07:47:44 --> Config Class Initialized
INFO - 2023-06-06 07:47:44 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:47:44 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:47:44 --> Utf8 Class Initialized
INFO - 2023-06-06 07:47:44 --> URI Class Initialized
DEBUG - 2023-06-06 07:47:44 --> No URI present. Default controller set.
INFO - 2023-06-06 07:47:44 --> Router Class Initialized
INFO - 2023-06-06 07:47:44 --> Output Class Initialized
INFO - 2023-06-06 07:47:44 --> Security Class Initialized
DEBUG - 2023-06-06 07:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:47:44 --> Input Class Initialized
INFO - 2023-06-06 07:47:44 --> Language Class Initialized
INFO - 2023-06-06 07:47:44 --> Loader Class Initialized
INFO - 2023-06-06 07:47:44 --> Helper loaded: url_helper
INFO - 2023-06-06 07:47:44 --> Helper loaded: file_helper
INFO - 2023-06-06 07:47:44 --> Helper loaded: html_helper
INFO - 2023-06-06 07:47:44 --> Helper loaded: text_helper
INFO - 2023-06-06 07:47:44 --> Helper loaded: form_helper
INFO - 2023-06-06 07:47:44 --> Helper loaded: lang_helper
INFO - 2023-06-06 07:47:44 --> Helper loaded: security_helper
INFO - 2023-06-06 07:47:44 --> Helper loaded: cookie_helper
INFO - 2023-06-06 07:47:44 --> Database Driver Class Initialized
INFO - 2023-06-06 07:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:47:44 --> Parser Class Initialized
INFO - 2023-06-06 07:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 07:47:44 --> Pagination Class Initialized
INFO - 2023-06-06 07:47:44 --> Form Validation Class Initialized
INFO - 2023-06-06 07:47:44 --> Controller Class Initialized
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
DEBUG - 2023-06-06 07:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
DEBUG - 2023-06-06 07:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
DEBUG - 2023-06-06 07:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 07:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
INFO - 2023-06-06 07:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 07:47:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 07:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 07:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 07:47:44 --> Model Class Initialized
INFO - 2023-06-06 07:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 07:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 07:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 07:47:44 --> Final output sent to browser
DEBUG - 2023-06-06 07:47:44 --> Total execution time: 0.1727
ERROR - 2023-06-06 12:15:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:15:31 --> Config Class Initialized
INFO - 2023-06-06 12:15:31 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:15:31 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:15:31 --> Utf8 Class Initialized
INFO - 2023-06-06 12:15:31 --> URI Class Initialized
DEBUG - 2023-06-06 12:15:31 --> No URI present. Default controller set.
INFO - 2023-06-06 12:15:31 --> Router Class Initialized
INFO - 2023-06-06 12:15:31 --> Output Class Initialized
INFO - 2023-06-06 12:15:31 --> Security Class Initialized
DEBUG - 2023-06-06 12:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:15:31 --> Input Class Initialized
INFO - 2023-06-06 12:15:31 --> Language Class Initialized
INFO - 2023-06-06 12:15:31 --> Loader Class Initialized
INFO - 2023-06-06 12:15:31 --> Helper loaded: url_helper
INFO - 2023-06-06 12:15:31 --> Helper loaded: file_helper
INFO - 2023-06-06 12:15:31 --> Helper loaded: html_helper
INFO - 2023-06-06 12:15:31 --> Helper loaded: text_helper
INFO - 2023-06-06 12:15:31 --> Helper loaded: form_helper
INFO - 2023-06-06 12:15:31 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:15:31 --> Helper loaded: security_helper
INFO - 2023-06-06 12:15:31 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:15:31 --> Database Driver Class Initialized
INFO - 2023-06-06 12:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:15:31 --> Parser Class Initialized
INFO - 2023-06-06 12:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:15:31 --> Pagination Class Initialized
INFO - 2023-06-06 12:15:31 --> Form Validation Class Initialized
INFO - 2023-06-06 12:15:31 --> Controller Class Initialized
INFO - 2023-06-06 12:15:31 --> Model Class Initialized
DEBUG - 2023-06-06 12:15:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 12:15:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:15:32 --> Config Class Initialized
INFO - 2023-06-06 12:15:32 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:15:32 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:15:32 --> Utf8 Class Initialized
INFO - 2023-06-06 12:15:32 --> URI Class Initialized
INFO - 2023-06-06 12:15:32 --> Router Class Initialized
INFO - 2023-06-06 12:15:32 --> Output Class Initialized
INFO - 2023-06-06 12:15:32 --> Security Class Initialized
DEBUG - 2023-06-06 12:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:15:32 --> Input Class Initialized
INFO - 2023-06-06 12:15:32 --> Language Class Initialized
INFO - 2023-06-06 12:15:32 --> Loader Class Initialized
INFO - 2023-06-06 12:15:32 --> Helper loaded: url_helper
INFO - 2023-06-06 12:15:32 --> Helper loaded: file_helper
INFO - 2023-06-06 12:15:32 --> Helper loaded: html_helper
INFO - 2023-06-06 12:15:32 --> Helper loaded: text_helper
INFO - 2023-06-06 12:15:32 --> Helper loaded: form_helper
INFO - 2023-06-06 12:15:32 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:15:32 --> Helper loaded: security_helper
INFO - 2023-06-06 12:15:32 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:15:32 --> Database Driver Class Initialized
INFO - 2023-06-06 12:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:15:32 --> Parser Class Initialized
INFO - 2023-06-06 12:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:15:32 --> Pagination Class Initialized
INFO - 2023-06-06 12:15:32 --> Form Validation Class Initialized
INFO - 2023-06-06 12:15:32 --> Controller Class Initialized
INFO - 2023-06-06 12:15:32 --> Model Class Initialized
DEBUG - 2023-06-06 12:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 12:15:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 12:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 12:15:32 --> Model Class Initialized
INFO - 2023-06-06 12:15:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 12:15:32 --> Final output sent to browser
DEBUG - 2023-06-06 12:15:32 --> Total execution time: 0.0388
ERROR - 2023-06-06 12:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:41 --> Config Class Initialized
INFO - 2023-06-06 12:33:41 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:41 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:41 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:41 --> URI Class Initialized
DEBUG - 2023-06-06 12:33:41 --> No URI present. Default controller set.
INFO - 2023-06-06 12:33:41 --> Router Class Initialized
INFO - 2023-06-06 12:33:41 --> Output Class Initialized
INFO - 2023-06-06 12:33:41 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:41 --> Input Class Initialized
INFO - 2023-06-06 12:33:41 --> Language Class Initialized
INFO - 2023-06-06 12:33:41 --> Loader Class Initialized
INFO - 2023-06-06 12:33:41 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:41 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:41 --> Parser Class Initialized
INFO - 2023-06-06 12:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:41 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:41 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:41 --> Controller Class Initialized
INFO - 2023-06-06 12:33:41 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-06 12:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:41 --> Config Class Initialized
INFO - 2023-06-06 12:33:41 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:41 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:41 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:41 --> URI Class Initialized
INFO - 2023-06-06 12:33:41 --> Router Class Initialized
INFO - 2023-06-06 12:33:41 --> Output Class Initialized
INFO - 2023-06-06 12:33:41 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:41 --> Input Class Initialized
INFO - 2023-06-06 12:33:41 --> Language Class Initialized
INFO - 2023-06-06 12:33:41 --> Loader Class Initialized
INFO - 2023-06-06 12:33:41 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:41 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:41 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:41 --> Parser Class Initialized
INFO - 2023-06-06 12:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:41 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:41 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:41 --> Controller Class Initialized
INFO - 2023-06-06 12:33:41 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-06 12:33:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 12:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 12:33:41 --> Model Class Initialized
INFO - 2023-06-06 12:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 12:33:41 --> Final output sent to browser
DEBUG - 2023-06-06 12:33:41 --> Total execution time: 0.0278
ERROR - 2023-06-06 12:33:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:44 --> Config Class Initialized
INFO - 2023-06-06 12:33:44 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:44 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:44 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:44 --> URI Class Initialized
INFO - 2023-06-06 12:33:44 --> Router Class Initialized
INFO - 2023-06-06 12:33:44 --> Output Class Initialized
INFO - 2023-06-06 12:33:44 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:44 --> Input Class Initialized
INFO - 2023-06-06 12:33:44 --> Language Class Initialized
INFO - 2023-06-06 12:33:44 --> Loader Class Initialized
INFO - 2023-06-06 12:33:44 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:44 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:44 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:44 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:44 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:44 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:44 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:44 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:44 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:44 --> Parser Class Initialized
INFO - 2023-06-06 12:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:44 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:44 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:44 --> Controller Class Initialized
INFO - 2023-06-06 12:33:44 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:44 --> Model Class Initialized
INFO - 2023-06-06 12:33:44 --> Final output sent to browser
DEBUG - 2023-06-06 12:33:44 --> Total execution time: 0.0178
ERROR - 2023-06-06 12:33:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:45 --> Config Class Initialized
INFO - 2023-06-06 12:33:45 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:45 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:45 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:45 --> URI Class Initialized
DEBUG - 2023-06-06 12:33:45 --> No URI present. Default controller set.
INFO - 2023-06-06 12:33:45 --> Router Class Initialized
INFO - 2023-06-06 12:33:45 --> Output Class Initialized
INFO - 2023-06-06 12:33:45 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:45 --> Input Class Initialized
INFO - 2023-06-06 12:33:45 --> Language Class Initialized
INFO - 2023-06-06 12:33:45 --> Loader Class Initialized
INFO - 2023-06-06 12:33:45 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:45 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:45 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:45 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:45 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:45 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:45 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:45 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:45 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:45 --> Parser Class Initialized
INFO - 2023-06-06 12:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:45 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:45 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:45 --> Controller Class Initialized
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
INFO - 2023-06-06 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-06 12:33:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 12:33:45 --> Model Class Initialized
INFO - 2023-06-06 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 12:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 12:33:45 --> Final output sent to browser
DEBUG - 2023-06-06 12:33:45 --> Total execution time: 0.1650
ERROR - 2023-06-06 12:33:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:46 --> Config Class Initialized
INFO - 2023-06-06 12:33:46 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:46 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:46 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:46 --> URI Class Initialized
INFO - 2023-06-06 12:33:46 --> Router Class Initialized
INFO - 2023-06-06 12:33:46 --> Output Class Initialized
INFO - 2023-06-06 12:33:46 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:46 --> Input Class Initialized
INFO - 2023-06-06 12:33:46 --> Language Class Initialized
INFO - 2023-06-06 12:33:46 --> Loader Class Initialized
INFO - 2023-06-06 12:33:46 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:46 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:46 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:46 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:46 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:46 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:46 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:46 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:46 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:46 --> Parser Class Initialized
INFO - 2023-06-06 12:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:46 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:46 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:46 --> Controller Class Initialized
DEBUG - 2023-06-06 12:33:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:46 --> Model Class Initialized
INFO - 2023-06-06 12:33:46 --> Final output sent to browser
DEBUG - 2023-06-06 12:33:46 --> Total execution time: 0.0132
ERROR - 2023-06-06 12:33:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:53 --> Config Class Initialized
INFO - 2023-06-06 12:33:53 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:53 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:53 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:53 --> URI Class Initialized
INFO - 2023-06-06 12:33:53 --> Router Class Initialized
INFO - 2023-06-06 12:33:53 --> Output Class Initialized
INFO - 2023-06-06 12:33:53 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:53 --> Input Class Initialized
INFO - 2023-06-06 12:33:53 --> Language Class Initialized
INFO - 2023-06-06 12:33:53 --> Loader Class Initialized
INFO - 2023-06-06 12:33:53 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:53 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:53 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:53 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:53 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:53 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:53 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:53 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:53 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:53 --> Parser Class Initialized
INFO - 2023-06-06 12:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:53 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:53 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:53 --> Controller Class Initialized
INFO - 2023-06-06 12:33:53 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:53 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:53 --> Model Class Initialized
INFO - 2023-06-06 12:33:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-06 12:33:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 12:33:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 12:33:53 --> Model Class Initialized
INFO - 2023-06-06 12:33:53 --> Model Class Initialized
INFO - 2023-06-06 12:33:53 --> Model Class Initialized
INFO - 2023-06-06 12:33:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 12:33:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 12:33:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 12:33:53 --> Final output sent to browser
DEBUG - 2023-06-06 12:33:53 --> Total execution time: 0.2672
ERROR - 2023-06-06 12:33:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:54 --> Config Class Initialized
INFO - 2023-06-06 12:33:54 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:54 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:54 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:54 --> URI Class Initialized
INFO - 2023-06-06 12:33:54 --> Router Class Initialized
INFO - 2023-06-06 12:33:54 --> Output Class Initialized
INFO - 2023-06-06 12:33:54 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:54 --> Input Class Initialized
INFO - 2023-06-06 12:33:54 --> Language Class Initialized
INFO - 2023-06-06 12:33:54 --> Loader Class Initialized
INFO - 2023-06-06 12:33:54 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:54 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:54 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:54 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:54 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:54 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:54 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:54 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:54 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:54 --> Parser Class Initialized
INFO - 2023-06-06 12:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:54 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:54 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:54 --> Controller Class Initialized
INFO - 2023-06-06 12:33:54 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:54 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:54 --> Model Class Initialized
INFO - 2023-06-06 12:33:54 --> Final output sent to browser
DEBUG - 2023-06-06 12:33:54 --> Total execution time: 0.0525
ERROR - 2023-06-06 12:33:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:33:57 --> Config Class Initialized
INFO - 2023-06-06 12:33:57 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:33:57 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:33:57 --> Utf8 Class Initialized
INFO - 2023-06-06 12:33:57 --> URI Class Initialized
INFO - 2023-06-06 12:33:57 --> Router Class Initialized
INFO - 2023-06-06 12:33:57 --> Output Class Initialized
INFO - 2023-06-06 12:33:57 --> Security Class Initialized
DEBUG - 2023-06-06 12:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:33:57 --> Input Class Initialized
INFO - 2023-06-06 12:33:57 --> Language Class Initialized
INFO - 2023-06-06 12:33:57 --> Loader Class Initialized
INFO - 2023-06-06 12:33:57 --> Helper loaded: url_helper
INFO - 2023-06-06 12:33:57 --> Helper loaded: file_helper
INFO - 2023-06-06 12:33:57 --> Helper loaded: html_helper
INFO - 2023-06-06 12:33:57 --> Helper loaded: text_helper
INFO - 2023-06-06 12:33:57 --> Helper loaded: form_helper
INFO - 2023-06-06 12:33:57 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:33:57 --> Helper loaded: security_helper
INFO - 2023-06-06 12:33:57 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:33:57 --> Database Driver Class Initialized
INFO - 2023-06-06 12:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:33:57 --> Parser Class Initialized
INFO - 2023-06-06 12:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:33:57 --> Pagination Class Initialized
INFO - 2023-06-06 12:33:57 --> Form Validation Class Initialized
INFO - 2023-06-06 12:33:57 --> Controller Class Initialized
INFO - 2023-06-06 12:33:57 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:57 --> Model Class Initialized
DEBUG - 2023-06-06 12:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:33:57 --> Model Class Initialized
INFO - 2023-06-06 12:33:58 --> Final output sent to browser
DEBUG - 2023-06-06 12:33:58 --> Total execution time: 0.1915
ERROR - 2023-06-06 12:34:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:34:29 --> Config Class Initialized
INFO - 2023-06-06 12:34:29 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:34:29 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:34:29 --> Utf8 Class Initialized
INFO - 2023-06-06 12:34:29 --> URI Class Initialized
INFO - 2023-06-06 12:34:29 --> Router Class Initialized
INFO - 2023-06-06 12:34:29 --> Output Class Initialized
INFO - 2023-06-06 12:34:29 --> Security Class Initialized
DEBUG - 2023-06-06 12:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:34:29 --> Input Class Initialized
INFO - 2023-06-06 12:34:29 --> Language Class Initialized
INFO - 2023-06-06 12:34:29 --> Loader Class Initialized
INFO - 2023-06-06 12:34:29 --> Helper loaded: url_helper
INFO - 2023-06-06 12:34:29 --> Helper loaded: file_helper
INFO - 2023-06-06 12:34:29 --> Helper loaded: html_helper
INFO - 2023-06-06 12:34:29 --> Helper loaded: text_helper
INFO - 2023-06-06 12:34:29 --> Helper loaded: form_helper
INFO - 2023-06-06 12:34:29 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:34:29 --> Helper loaded: security_helper
INFO - 2023-06-06 12:34:29 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:34:29 --> Database Driver Class Initialized
INFO - 2023-06-06 12:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:34:29 --> Parser Class Initialized
INFO - 2023-06-06 12:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:34:29 --> Pagination Class Initialized
INFO - 2023-06-06 12:34:29 --> Form Validation Class Initialized
INFO - 2023-06-06 12:34:29 --> Controller Class Initialized
INFO - 2023-06-06 12:34:29 --> Model Class Initialized
DEBUG - 2023-06-06 12:34:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:34:29 --> Model Class Initialized
DEBUG - 2023-06-06 12:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:34:29 --> Model Class Initialized
INFO - 2023-06-06 12:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-06 12:34:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-06 12:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-06 12:34:29 --> Model Class Initialized
INFO - 2023-06-06 12:34:29 --> Model Class Initialized
INFO - 2023-06-06 12:34:29 --> Model Class Initialized
INFO - 2023-06-06 12:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-06 12:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-06 12:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-06 12:34:29 --> Final output sent to browser
DEBUG - 2023-06-06 12:34:29 --> Total execution time: 0.1282
ERROR - 2023-06-06 12:34:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:34:30 --> Config Class Initialized
INFO - 2023-06-06 12:34:30 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:34:30 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:34:30 --> Utf8 Class Initialized
INFO - 2023-06-06 12:34:30 --> URI Class Initialized
INFO - 2023-06-06 12:34:30 --> Router Class Initialized
INFO - 2023-06-06 12:34:30 --> Output Class Initialized
INFO - 2023-06-06 12:34:30 --> Security Class Initialized
DEBUG - 2023-06-06 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:34:30 --> Input Class Initialized
INFO - 2023-06-06 12:34:30 --> Language Class Initialized
INFO - 2023-06-06 12:34:30 --> Loader Class Initialized
INFO - 2023-06-06 12:34:30 --> Helper loaded: url_helper
INFO - 2023-06-06 12:34:30 --> Helper loaded: file_helper
INFO - 2023-06-06 12:34:30 --> Helper loaded: html_helper
INFO - 2023-06-06 12:34:30 --> Helper loaded: text_helper
INFO - 2023-06-06 12:34:30 --> Helper loaded: form_helper
INFO - 2023-06-06 12:34:30 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:34:30 --> Helper loaded: security_helper
INFO - 2023-06-06 12:34:30 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:34:30 --> Database Driver Class Initialized
INFO - 2023-06-06 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:34:30 --> Parser Class Initialized
INFO - 2023-06-06 12:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:34:30 --> Pagination Class Initialized
INFO - 2023-06-06 12:34:30 --> Form Validation Class Initialized
INFO - 2023-06-06 12:34:30 --> Controller Class Initialized
INFO - 2023-06-06 12:34:30 --> Model Class Initialized
DEBUG - 2023-06-06 12:34:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:34:30 --> Model Class Initialized
DEBUG - 2023-06-06 12:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:34:30 --> Model Class Initialized
INFO - 2023-06-06 12:34:30 --> Final output sent to browser
DEBUG - 2023-06-06 12:34:30 --> Total execution time: 0.0534
ERROR - 2023-06-06 12:34:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-06 12:34:34 --> Config Class Initialized
INFO - 2023-06-06 12:34:34 --> Hooks Class Initialized
DEBUG - 2023-06-06 12:34:34 --> UTF-8 Support Enabled
INFO - 2023-06-06 12:34:34 --> Utf8 Class Initialized
INFO - 2023-06-06 12:34:34 --> URI Class Initialized
INFO - 2023-06-06 12:34:34 --> Router Class Initialized
INFO - 2023-06-06 12:34:34 --> Output Class Initialized
INFO - 2023-06-06 12:34:34 --> Security Class Initialized
DEBUG - 2023-06-06 12:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 12:34:34 --> Input Class Initialized
INFO - 2023-06-06 12:34:34 --> Language Class Initialized
INFO - 2023-06-06 12:34:34 --> Loader Class Initialized
INFO - 2023-06-06 12:34:34 --> Helper loaded: url_helper
INFO - 2023-06-06 12:34:34 --> Helper loaded: file_helper
INFO - 2023-06-06 12:34:34 --> Helper loaded: html_helper
INFO - 2023-06-06 12:34:34 --> Helper loaded: text_helper
INFO - 2023-06-06 12:34:34 --> Helper loaded: form_helper
INFO - 2023-06-06 12:34:34 --> Helper loaded: lang_helper
INFO - 2023-06-06 12:34:34 --> Helper loaded: security_helper
INFO - 2023-06-06 12:34:34 --> Helper loaded: cookie_helper
INFO - 2023-06-06 12:34:34 --> Database Driver Class Initialized
INFO - 2023-06-06 12:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 12:34:34 --> Parser Class Initialized
INFO - 2023-06-06 12:34:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-06 12:34:34 --> Pagination Class Initialized
INFO - 2023-06-06 12:34:34 --> Form Validation Class Initialized
INFO - 2023-06-06 12:34:34 --> Controller Class Initialized
INFO - 2023-06-06 12:34:34 --> Model Class Initialized
DEBUG - 2023-06-06 12:34:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-06 12:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:34:34 --> Model Class Initialized
DEBUG - 2023-06-06 12:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-06 12:34:34 --> Model Class Initialized
INFO - 2023-06-06 12:34:35 --> Final output sent to browser
DEBUG - 2023-06-06 12:34:35 --> Total execution time: 0.2036
