<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-03 02:15:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 02:15:12 --> Config Class Initialized
INFO - 2024-03-03 02:15:12 --> Hooks Class Initialized
DEBUG - 2024-03-03 02:15:12 --> UTF-8 Support Enabled
INFO - 2024-03-03 02:15:12 --> Utf8 Class Initialized
INFO - 2024-03-03 02:15:12 --> URI Class Initialized
INFO - 2024-03-03 02:15:12 --> Router Class Initialized
INFO - 2024-03-03 02:15:12 --> Output Class Initialized
INFO - 2024-03-03 02:15:12 --> Security Class Initialized
DEBUG - 2024-03-03 02:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 02:15:12 --> Input Class Initialized
INFO - 2024-03-03 02:15:12 --> Language Class Initialized
ERROR - 2024-03-03 02:15:12 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-03 03:45:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 03:45:12 --> Config Class Initialized
INFO - 2024-03-03 03:45:12 --> Hooks Class Initialized
DEBUG - 2024-03-03 03:45:12 --> UTF-8 Support Enabled
INFO - 2024-03-03 03:45:12 --> Utf8 Class Initialized
INFO - 2024-03-03 03:45:12 --> URI Class Initialized
INFO - 2024-03-03 03:45:12 --> Router Class Initialized
INFO - 2024-03-03 03:45:12 --> Output Class Initialized
INFO - 2024-03-03 03:45:12 --> Security Class Initialized
DEBUG - 2024-03-03 03:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 03:45:12 --> Input Class Initialized
INFO - 2024-03-03 03:45:12 --> Language Class Initialized
ERROR - 2024-03-03 03:45:12 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-03 08:14:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 08:14:01 --> Config Class Initialized
INFO - 2024-03-03 08:14:01 --> Hooks Class Initialized
DEBUG - 2024-03-03 08:14:01 --> UTF-8 Support Enabled
INFO - 2024-03-03 08:14:01 --> Utf8 Class Initialized
INFO - 2024-03-03 08:14:01 --> URI Class Initialized
DEBUG - 2024-03-03 08:14:01 --> No URI present. Default controller set.
INFO - 2024-03-03 08:14:01 --> Router Class Initialized
INFO - 2024-03-03 08:14:01 --> Output Class Initialized
INFO - 2024-03-03 08:14:01 --> Security Class Initialized
DEBUG - 2024-03-03 08:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 08:14:01 --> Input Class Initialized
INFO - 2024-03-03 08:14:01 --> Language Class Initialized
INFO - 2024-03-03 08:14:01 --> Loader Class Initialized
INFO - 2024-03-03 08:14:01 --> Helper loaded: url_helper
INFO - 2024-03-03 08:14:01 --> Helper loaded: file_helper
INFO - 2024-03-03 08:14:01 --> Helper loaded: html_helper
INFO - 2024-03-03 08:14:01 --> Helper loaded: text_helper
INFO - 2024-03-03 08:14:01 --> Helper loaded: form_helper
INFO - 2024-03-03 08:14:01 --> Helper loaded: lang_helper
INFO - 2024-03-03 08:14:01 --> Helper loaded: security_helper
INFO - 2024-03-03 08:14:01 --> Helper loaded: cookie_helper
INFO - 2024-03-03 08:14:01 --> Database Driver Class Initialized
INFO - 2024-03-03 08:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 08:14:01 --> Parser Class Initialized
INFO - 2024-03-03 08:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 08:14:01 --> Pagination Class Initialized
INFO - 2024-03-03 08:14:01 --> Form Validation Class Initialized
INFO - 2024-03-03 08:14:01 --> Controller Class Initialized
INFO - 2024-03-03 08:14:01 --> Model Class Initialized
DEBUG - 2024-03-03 08:14:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-03 08:14:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 08:14:02 --> Config Class Initialized
INFO - 2024-03-03 08:14:02 --> Hooks Class Initialized
DEBUG - 2024-03-03 08:14:02 --> UTF-8 Support Enabled
INFO - 2024-03-03 08:14:02 --> Utf8 Class Initialized
INFO - 2024-03-03 08:14:02 --> URI Class Initialized
DEBUG - 2024-03-03 08:14:02 --> No URI present. Default controller set.
INFO - 2024-03-03 08:14:02 --> Router Class Initialized
INFO - 2024-03-03 08:14:02 --> Output Class Initialized
INFO - 2024-03-03 08:14:02 --> Security Class Initialized
DEBUG - 2024-03-03 08:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 08:14:02 --> Input Class Initialized
INFO - 2024-03-03 08:14:02 --> Language Class Initialized
INFO - 2024-03-03 08:14:02 --> Loader Class Initialized
INFO - 2024-03-03 08:14:02 --> Helper loaded: url_helper
INFO - 2024-03-03 08:14:02 --> Helper loaded: file_helper
INFO - 2024-03-03 08:14:02 --> Helper loaded: html_helper
INFO - 2024-03-03 08:14:02 --> Helper loaded: text_helper
INFO - 2024-03-03 08:14:02 --> Helper loaded: form_helper
INFO - 2024-03-03 08:14:02 --> Helper loaded: lang_helper
INFO - 2024-03-03 08:14:02 --> Helper loaded: security_helper
INFO - 2024-03-03 08:14:02 --> Helper loaded: cookie_helper
INFO - 2024-03-03 08:14:02 --> Database Driver Class Initialized
INFO - 2024-03-03 08:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 08:14:02 --> Parser Class Initialized
INFO - 2024-03-03 08:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 08:14:02 --> Pagination Class Initialized
INFO - 2024-03-03 08:14:02 --> Form Validation Class Initialized
INFO - 2024-03-03 08:14:02 --> Controller Class Initialized
INFO - 2024-03-03 08:14:02 --> Model Class Initialized
DEBUG - 2024-03-03 08:14:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-03 08:14:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 08:14:03 --> Config Class Initialized
INFO - 2024-03-03 08:14:03 --> Hooks Class Initialized
DEBUG - 2024-03-03 08:14:03 --> UTF-8 Support Enabled
INFO - 2024-03-03 08:14:03 --> Utf8 Class Initialized
INFO - 2024-03-03 08:14:03 --> URI Class Initialized
DEBUG - 2024-03-03 08:14:03 --> No URI present. Default controller set.
INFO - 2024-03-03 08:14:03 --> Router Class Initialized
INFO - 2024-03-03 08:14:03 --> Output Class Initialized
INFO - 2024-03-03 08:14:03 --> Security Class Initialized
DEBUG - 2024-03-03 08:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 08:14:03 --> Input Class Initialized
INFO - 2024-03-03 08:14:03 --> Language Class Initialized
INFO - 2024-03-03 08:14:03 --> Loader Class Initialized
INFO - 2024-03-03 08:14:03 --> Helper loaded: url_helper
INFO - 2024-03-03 08:14:03 --> Helper loaded: file_helper
INFO - 2024-03-03 08:14:03 --> Helper loaded: html_helper
INFO - 2024-03-03 08:14:03 --> Helper loaded: text_helper
INFO - 2024-03-03 08:14:03 --> Helper loaded: form_helper
INFO - 2024-03-03 08:14:03 --> Helper loaded: lang_helper
INFO - 2024-03-03 08:14:03 --> Helper loaded: security_helper
INFO - 2024-03-03 08:14:03 --> Helper loaded: cookie_helper
INFO - 2024-03-03 08:14:03 --> Database Driver Class Initialized
INFO - 2024-03-03 08:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 08:14:03 --> Parser Class Initialized
INFO - 2024-03-03 08:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 08:14:03 --> Pagination Class Initialized
INFO - 2024-03-03 08:14:03 --> Form Validation Class Initialized
INFO - 2024-03-03 08:14:03 --> Controller Class Initialized
INFO - 2024-03-03 08:14:03 --> Model Class Initialized
DEBUG - 2024-03-03 08:14:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-03 08:14:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 08:14:04 --> Config Class Initialized
INFO - 2024-03-03 08:14:04 --> Hooks Class Initialized
DEBUG - 2024-03-03 08:14:04 --> UTF-8 Support Enabled
INFO - 2024-03-03 08:14:04 --> Utf8 Class Initialized
INFO - 2024-03-03 08:14:04 --> URI Class Initialized
DEBUG - 2024-03-03 08:14:04 --> No URI present. Default controller set.
INFO - 2024-03-03 08:14:04 --> Router Class Initialized
INFO - 2024-03-03 08:14:04 --> Output Class Initialized
INFO - 2024-03-03 08:14:04 --> Security Class Initialized
DEBUG - 2024-03-03 08:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 08:14:04 --> Input Class Initialized
INFO - 2024-03-03 08:14:04 --> Language Class Initialized
INFO - 2024-03-03 08:14:04 --> Loader Class Initialized
INFO - 2024-03-03 08:14:04 --> Helper loaded: url_helper
INFO - 2024-03-03 08:14:04 --> Helper loaded: file_helper
INFO - 2024-03-03 08:14:04 --> Helper loaded: html_helper
INFO - 2024-03-03 08:14:04 --> Helper loaded: text_helper
INFO - 2024-03-03 08:14:04 --> Helper loaded: form_helper
INFO - 2024-03-03 08:14:04 --> Helper loaded: lang_helper
INFO - 2024-03-03 08:14:04 --> Helper loaded: security_helper
INFO - 2024-03-03 08:14:04 --> Helper loaded: cookie_helper
INFO - 2024-03-03 08:14:04 --> Database Driver Class Initialized
INFO - 2024-03-03 08:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 08:14:04 --> Parser Class Initialized
INFO - 2024-03-03 08:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 08:14:04 --> Pagination Class Initialized
INFO - 2024-03-03 08:14:04 --> Form Validation Class Initialized
INFO - 2024-03-03 08:14:04 --> Controller Class Initialized
INFO - 2024-03-03 08:14:04 --> Model Class Initialized
DEBUG - 2024-03-03 08:14:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-03 16:05:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 16:05:33 --> Config Class Initialized
INFO - 2024-03-03 16:05:33 --> Hooks Class Initialized
DEBUG - 2024-03-03 16:05:33 --> UTF-8 Support Enabled
INFO - 2024-03-03 16:05:33 --> Utf8 Class Initialized
INFO - 2024-03-03 16:05:33 --> URI Class Initialized
DEBUG - 2024-03-03 16:05:33 --> No URI present. Default controller set.
INFO - 2024-03-03 16:05:33 --> Router Class Initialized
INFO - 2024-03-03 16:05:33 --> Output Class Initialized
INFO - 2024-03-03 16:05:33 --> Security Class Initialized
DEBUG - 2024-03-03 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 16:05:33 --> Input Class Initialized
INFO - 2024-03-03 16:05:33 --> Language Class Initialized
INFO - 2024-03-03 16:05:33 --> Loader Class Initialized
INFO - 2024-03-03 16:05:33 --> Helper loaded: url_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: file_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: html_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: text_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: form_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: lang_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: security_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: cookie_helper
INFO - 2024-03-03 16:05:33 --> Database Driver Class Initialized
INFO - 2024-03-03 16:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 16:05:33 --> Parser Class Initialized
INFO - 2024-03-03 16:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 16:05:33 --> Pagination Class Initialized
INFO - 2024-03-03 16:05:33 --> Form Validation Class Initialized
INFO - 2024-03-03 16:05:33 --> Controller Class Initialized
INFO - 2024-03-03 16:05:33 --> Model Class Initialized
DEBUG - 2024-03-03 16:05:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-03 16:05:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 16:05:33 --> Config Class Initialized
INFO - 2024-03-03 16:05:33 --> Hooks Class Initialized
DEBUG - 2024-03-03 16:05:33 --> UTF-8 Support Enabled
INFO - 2024-03-03 16:05:33 --> Utf8 Class Initialized
INFO - 2024-03-03 16:05:33 --> URI Class Initialized
INFO - 2024-03-03 16:05:33 --> Router Class Initialized
INFO - 2024-03-03 16:05:33 --> Output Class Initialized
INFO - 2024-03-03 16:05:33 --> Security Class Initialized
DEBUG - 2024-03-03 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 16:05:33 --> Input Class Initialized
INFO - 2024-03-03 16:05:33 --> Language Class Initialized
INFO - 2024-03-03 16:05:33 --> Loader Class Initialized
INFO - 2024-03-03 16:05:33 --> Helper loaded: url_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: file_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: html_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: text_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: form_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: lang_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: security_helper
INFO - 2024-03-03 16:05:33 --> Helper loaded: cookie_helper
INFO - 2024-03-03 16:05:33 --> Database Driver Class Initialized
INFO - 2024-03-03 16:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 16:05:33 --> Parser Class Initialized
INFO - 2024-03-03 16:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 16:05:33 --> Pagination Class Initialized
INFO - 2024-03-03 16:05:33 --> Form Validation Class Initialized
INFO - 2024-03-03 16:05:33 --> Controller Class Initialized
INFO - 2024-03-03 16:05:33 --> Model Class Initialized
DEBUG - 2024-03-03 16:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-03 16:05:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-03 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-03 16:05:33 --> Model Class Initialized
INFO - 2024-03-03 16:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-03 16:05:33 --> Final output sent to browser
DEBUG - 2024-03-03 16:05:33 --> Total execution time: 0.0395
ERROR - 2024-03-03 16:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 16:05:50 --> Config Class Initialized
INFO - 2024-03-03 16:05:50 --> Hooks Class Initialized
DEBUG - 2024-03-03 16:05:50 --> UTF-8 Support Enabled
INFO - 2024-03-03 16:05:50 --> Utf8 Class Initialized
INFO - 2024-03-03 16:05:50 --> URI Class Initialized
INFO - 2024-03-03 16:05:50 --> Router Class Initialized
INFO - 2024-03-03 16:05:50 --> Output Class Initialized
INFO - 2024-03-03 16:05:50 --> Security Class Initialized
DEBUG - 2024-03-03 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 16:05:50 --> Input Class Initialized
INFO - 2024-03-03 16:05:50 --> Language Class Initialized
INFO - 2024-03-03 16:05:50 --> Loader Class Initialized
INFO - 2024-03-03 16:05:50 --> Helper loaded: url_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: file_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: html_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: text_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: form_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: lang_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: security_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: cookie_helper
INFO - 2024-03-03 16:05:50 --> Database Driver Class Initialized
INFO - 2024-03-03 16:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 16:05:50 --> Parser Class Initialized
INFO - 2024-03-03 16:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 16:05:50 --> Pagination Class Initialized
INFO - 2024-03-03 16:05:50 --> Form Validation Class Initialized
INFO - 2024-03-03 16:05:50 --> Controller Class Initialized
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
DEBUG - 2024-03-03 16:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
INFO - 2024-03-03 16:05:50 --> Final output sent to browser
DEBUG - 2024-03-03 16:05:50 --> Total execution time: 0.0208
ERROR - 2024-03-03 16:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 16:05:50 --> Config Class Initialized
INFO - 2024-03-03 16:05:50 --> Hooks Class Initialized
DEBUG - 2024-03-03 16:05:50 --> UTF-8 Support Enabled
INFO - 2024-03-03 16:05:50 --> Utf8 Class Initialized
INFO - 2024-03-03 16:05:50 --> URI Class Initialized
DEBUG - 2024-03-03 16:05:50 --> No URI present. Default controller set.
INFO - 2024-03-03 16:05:50 --> Router Class Initialized
INFO - 2024-03-03 16:05:50 --> Output Class Initialized
INFO - 2024-03-03 16:05:50 --> Security Class Initialized
DEBUG - 2024-03-03 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 16:05:50 --> Input Class Initialized
INFO - 2024-03-03 16:05:50 --> Language Class Initialized
INFO - 2024-03-03 16:05:50 --> Loader Class Initialized
INFO - 2024-03-03 16:05:50 --> Helper loaded: url_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: file_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: html_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: text_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: form_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: lang_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: security_helper
INFO - 2024-03-03 16:05:50 --> Helper loaded: cookie_helper
INFO - 2024-03-03 16:05:50 --> Database Driver Class Initialized
INFO - 2024-03-03 16:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 16:05:50 --> Parser Class Initialized
INFO - 2024-03-03 16:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 16:05:50 --> Pagination Class Initialized
INFO - 2024-03-03 16:05:50 --> Form Validation Class Initialized
INFO - 2024-03-03 16:05:50 --> Controller Class Initialized
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
DEBUG - 2024-03-03 16:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
DEBUG - 2024-03-03 16:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
DEBUG - 2024-03-03 16:05:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-03 16:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
INFO - 2024-03-03 16:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-03 16:05:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-03 16:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-03 16:05:50 --> Model Class Initialized
INFO - 2024-03-03 16:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-03 16:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-03 16:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-03 16:05:50 --> Final output sent to browser
DEBUG - 2024-03-03 16:05:50 --> Total execution time: 0.4522
ERROR - 2024-03-03 16:05:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 16:05:52 --> Config Class Initialized
INFO - 2024-03-03 16:05:52 --> Hooks Class Initialized
DEBUG - 2024-03-03 16:05:52 --> UTF-8 Support Enabled
INFO - 2024-03-03 16:05:52 --> Utf8 Class Initialized
INFO - 2024-03-03 16:05:52 --> URI Class Initialized
INFO - 2024-03-03 16:05:52 --> Router Class Initialized
INFO - 2024-03-03 16:05:52 --> Output Class Initialized
INFO - 2024-03-03 16:05:52 --> Security Class Initialized
DEBUG - 2024-03-03 16:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 16:05:52 --> Input Class Initialized
INFO - 2024-03-03 16:05:52 --> Language Class Initialized
INFO - 2024-03-03 16:05:52 --> Loader Class Initialized
INFO - 2024-03-03 16:05:52 --> Helper loaded: url_helper
INFO - 2024-03-03 16:05:52 --> Helper loaded: file_helper
INFO - 2024-03-03 16:05:52 --> Helper loaded: html_helper
INFO - 2024-03-03 16:05:52 --> Helper loaded: text_helper
INFO - 2024-03-03 16:05:52 --> Helper loaded: form_helper
INFO - 2024-03-03 16:05:52 --> Helper loaded: lang_helper
INFO - 2024-03-03 16:05:52 --> Helper loaded: security_helper
INFO - 2024-03-03 16:05:52 --> Helper loaded: cookie_helper
INFO - 2024-03-03 16:05:52 --> Database Driver Class Initialized
INFO - 2024-03-03 16:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 16:05:52 --> Parser Class Initialized
INFO - 2024-03-03 16:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 16:05:52 --> Pagination Class Initialized
INFO - 2024-03-03 16:05:52 --> Form Validation Class Initialized
INFO - 2024-03-03 16:05:52 --> Controller Class Initialized
DEBUG - 2024-03-03 16:05:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-03 16:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:05:52 --> Model Class Initialized
INFO - 2024-03-03 16:05:52 --> Final output sent to browser
DEBUG - 2024-03-03 16:05:52 --> Total execution time: 0.0132
ERROR - 2024-03-03 16:06:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 16:06:42 --> Config Class Initialized
INFO - 2024-03-03 16:06:42 --> Hooks Class Initialized
DEBUG - 2024-03-03 16:06:42 --> UTF-8 Support Enabled
INFO - 2024-03-03 16:06:42 --> Utf8 Class Initialized
INFO - 2024-03-03 16:06:42 --> URI Class Initialized
INFO - 2024-03-03 16:06:42 --> Router Class Initialized
INFO - 2024-03-03 16:06:42 --> Output Class Initialized
INFO - 2024-03-03 16:06:42 --> Security Class Initialized
DEBUG - 2024-03-03 16:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 16:06:42 --> Input Class Initialized
INFO - 2024-03-03 16:06:42 --> Language Class Initialized
INFO - 2024-03-03 16:06:42 --> Loader Class Initialized
INFO - 2024-03-03 16:06:42 --> Helper loaded: url_helper
INFO - 2024-03-03 16:06:42 --> Helper loaded: file_helper
INFO - 2024-03-03 16:06:42 --> Helper loaded: html_helper
INFO - 2024-03-03 16:06:42 --> Helper loaded: text_helper
INFO - 2024-03-03 16:06:42 --> Helper loaded: form_helper
INFO - 2024-03-03 16:06:42 --> Helper loaded: lang_helper
INFO - 2024-03-03 16:06:42 --> Helper loaded: security_helper
INFO - 2024-03-03 16:06:42 --> Helper loaded: cookie_helper
INFO - 2024-03-03 16:06:42 --> Database Driver Class Initialized
INFO - 2024-03-03 16:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 16:06:42 --> Parser Class Initialized
INFO - 2024-03-03 16:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 16:06:42 --> Pagination Class Initialized
INFO - 2024-03-03 16:06:42 --> Form Validation Class Initialized
INFO - 2024-03-03 16:06:42 --> Controller Class Initialized
INFO - 2024-03-03 16:06:42 --> Model Class Initialized
DEBUG - 2024-03-03 16:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-03 16:06:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-03 16:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-03 16:06:42 --> Model Class Initialized
INFO - 2024-03-03 16:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-03 16:06:42 --> Final output sent to browser
DEBUG - 2024-03-03 16:06:42 --> Total execution time: 0.0397
ERROR - 2024-03-03 16:06:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 16:06:43 --> Config Class Initialized
INFO - 2024-03-03 16:06:43 --> Hooks Class Initialized
DEBUG - 2024-03-03 16:06:43 --> UTF-8 Support Enabled
INFO - 2024-03-03 16:06:43 --> Utf8 Class Initialized
INFO - 2024-03-03 16:06:43 --> URI Class Initialized
INFO - 2024-03-03 16:06:43 --> Router Class Initialized
INFO - 2024-03-03 16:06:43 --> Output Class Initialized
INFO - 2024-03-03 16:06:43 --> Security Class Initialized
DEBUG - 2024-03-03 16:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 16:06:43 --> Input Class Initialized
INFO - 2024-03-03 16:06:43 --> Language Class Initialized
INFO - 2024-03-03 16:06:43 --> Loader Class Initialized
INFO - 2024-03-03 16:06:43 --> Helper loaded: url_helper
INFO - 2024-03-03 16:06:43 --> Helper loaded: file_helper
INFO - 2024-03-03 16:06:43 --> Helper loaded: html_helper
INFO - 2024-03-03 16:06:43 --> Helper loaded: text_helper
INFO - 2024-03-03 16:06:43 --> Helper loaded: form_helper
INFO - 2024-03-03 16:06:43 --> Helper loaded: lang_helper
INFO - 2024-03-03 16:06:43 --> Helper loaded: security_helper
INFO - 2024-03-03 16:06:43 --> Helper loaded: cookie_helper
INFO - 2024-03-03 16:06:43 --> Database Driver Class Initialized
INFO - 2024-03-03 16:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 16:06:43 --> Parser Class Initialized
INFO - 2024-03-03 16:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 16:06:43 --> Pagination Class Initialized
INFO - 2024-03-03 16:06:43 --> Form Validation Class Initialized
INFO - 2024-03-03 16:06:43 --> Controller Class Initialized
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
DEBUG - 2024-03-03 16:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
DEBUG - 2024-03-03 16:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
DEBUG - 2024-03-03 16:06:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-03 16:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
INFO - 2024-03-03 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-03 16:06:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-03 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-03 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-03 16:06:43 --> Model Class Initialized
INFO - 2024-03-03 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-03 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-03 16:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-03 16:06:43 --> Final output sent to browser
DEBUG - 2024-03-03 16:06:43 --> Total execution time: 0.4461
ERROR - 2024-03-03 22:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-03 22:26:57 --> Config Class Initialized
INFO - 2024-03-03 22:26:57 --> Hooks Class Initialized
DEBUG - 2024-03-03 22:26:57 --> UTF-8 Support Enabled
INFO - 2024-03-03 22:26:57 --> Utf8 Class Initialized
INFO - 2024-03-03 22:26:57 --> URI Class Initialized
DEBUG - 2024-03-03 22:26:57 --> No URI present. Default controller set.
INFO - 2024-03-03 22:26:57 --> Router Class Initialized
INFO - 2024-03-03 22:26:57 --> Output Class Initialized
INFO - 2024-03-03 22:26:57 --> Security Class Initialized
DEBUG - 2024-03-03 22:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-03 22:26:57 --> Input Class Initialized
INFO - 2024-03-03 22:26:57 --> Language Class Initialized
INFO - 2024-03-03 22:26:57 --> Loader Class Initialized
INFO - 2024-03-03 22:26:57 --> Helper loaded: url_helper
INFO - 2024-03-03 22:26:57 --> Helper loaded: file_helper
INFO - 2024-03-03 22:26:57 --> Helper loaded: html_helper
INFO - 2024-03-03 22:26:57 --> Helper loaded: text_helper
INFO - 2024-03-03 22:26:57 --> Helper loaded: form_helper
INFO - 2024-03-03 22:26:57 --> Helper loaded: lang_helper
INFO - 2024-03-03 22:26:57 --> Helper loaded: security_helper
INFO - 2024-03-03 22:26:57 --> Helper loaded: cookie_helper
INFO - 2024-03-03 22:26:57 --> Database Driver Class Initialized
INFO - 2024-03-03 22:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-03 22:26:57 --> Parser Class Initialized
INFO - 2024-03-03 22:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-03 22:26:57 --> Pagination Class Initialized
INFO - 2024-03-03 22:26:57 --> Form Validation Class Initialized
INFO - 2024-03-03 22:26:57 --> Controller Class Initialized
INFO - 2024-03-03 22:26:57 --> Model Class Initialized
DEBUG - 2024-03-03 22:26:57 --> Session class already loaded. Second attempt ignored.
