<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-03 05:10:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 05:10:06 --> Config Class Initialized
INFO - 2023-12-03 05:10:06 --> Hooks Class Initialized
DEBUG - 2023-12-03 05:10:06 --> UTF-8 Support Enabled
INFO - 2023-12-03 05:10:06 --> Utf8 Class Initialized
INFO - 2023-12-03 05:10:06 --> URI Class Initialized
INFO - 2023-12-03 05:10:06 --> Router Class Initialized
INFO - 2023-12-03 05:10:06 --> Output Class Initialized
INFO - 2023-12-03 05:10:06 --> Security Class Initialized
DEBUG - 2023-12-03 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 05:10:06 --> Input Class Initialized
INFO - 2023-12-03 05:10:06 --> Language Class Initialized
ERROR - 2023-12-03 05:10:06 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-03 05:16:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 05:16:43 --> Config Class Initialized
INFO - 2023-12-03 05:16:43 --> Hooks Class Initialized
DEBUG - 2023-12-03 05:16:43 --> UTF-8 Support Enabled
INFO - 2023-12-03 05:16:43 --> Utf8 Class Initialized
INFO - 2023-12-03 05:16:43 --> URI Class Initialized
DEBUG - 2023-12-03 05:16:43 --> No URI present. Default controller set.
INFO - 2023-12-03 05:16:43 --> Router Class Initialized
INFO - 2023-12-03 05:16:43 --> Output Class Initialized
INFO - 2023-12-03 05:16:43 --> Security Class Initialized
DEBUG - 2023-12-03 05:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 05:16:43 --> Input Class Initialized
INFO - 2023-12-03 05:16:43 --> Language Class Initialized
INFO - 2023-12-03 05:16:43 --> Loader Class Initialized
INFO - 2023-12-03 05:16:43 --> Helper loaded: url_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: file_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: html_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: text_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: form_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: lang_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: security_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: cookie_helper
INFO - 2023-12-03 05:16:43 --> Database Driver Class Initialized
INFO - 2023-12-03 05:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 05:16:43 --> Parser Class Initialized
INFO - 2023-12-03 05:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-03 05:16:43 --> Pagination Class Initialized
INFO - 2023-12-03 05:16:43 --> Form Validation Class Initialized
INFO - 2023-12-03 05:16:43 --> Controller Class Initialized
INFO - 2023-12-03 05:16:43 --> Model Class Initialized
DEBUG - 2023-12-03 05:16:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-03 05:16:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 05:16:43 --> Config Class Initialized
INFO - 2023-12-03 05:16:43 --> Hooks Class Initialized
DEBUG - 2023-12-03 05:16:43 --> UTF-8 Support Enabled
INFO - 2023-12-03 05:16:43 --> Utf8 Class Initialized
INFO - 2023-12-03 05:16:43 --> URI Class Initialized
INFO - 2023-12-03 05:16:43 --> Router Class Initialized
INFO - 2023-12-03 05:16:43 --> Output Class Initialized
INFO - 2023-12-03 05:16:43 --> Security Class Initialized
DEBUG - 2023-12-03 05:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 05:16:43 --> Input Class Initialized
INFO - 2023-12-03 05:16:43 --> Language Class Initialized
INFO - 2023-12-03 05:16:43 --> Loader Class Initialized
INFO - 2023-12-03 05:16:43 --> Helper loaded: url_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: file_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: html_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: text_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: form_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: lang_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: security_helper
INFO - 2023-12-03 05:16:43 --> Helper loaded: cookie_helper
INFO - 2023-12-03 05:16:43 --> Database Driver Class Initialized
INFO - 2023-12-03 05:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 05:16:43 --> Parser Class Initialized
INFO - 2023-12-03 05:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-03 05:16:43 --> Pagination Class Initialized
INFO - 2023-12-03 05:16:43 --> Form Validation Class Initialized
INFO - 2023-12-03 05:16:43 --> Controller Class Initialized
INFO - 2023-12-03 05:16:43 --> Model Class Initialized
DEBUG - 2023-12-03 05:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-03 05:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-03 05:16:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-03 05:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-03 05:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-03 05:16:43 --> Model Class Initialized
INFO - 2023-12-03 05:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-03 05:16:43 --> Final output sent to browser
DEBUG - 2023-12-03 05:16:43 --> Total execution time: 0.0397
ERROR - 2023-12-03 13:09:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 13:09:27 --> Config Class Initialized
INFO - 2023-12-03 13:09:27 --> Hooks Class Initialized
DEBUG - 2023-12-03 13:09:27 --> UTF-8 Support Enabled
INFO - 2023-12-03 13:09:27 --> Utf8 Class Initialized
INFO - 2023-12-03 13:09:27 --> URI Class Initialized
DEBUG - 2023-12-03 13:09:27 --> No URI present. Default controller set.
INFO - 2023-12-03 13:09:27 --> Router Class Initialized
INFO - 2023-12-03 13:09:27 --> Output Class Initialized
INFO - 2023-12-03 13:09:27 --> Security Class Initialized
DEBUG - 2023-12-03 13:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 13:09:27 --> Input Class Initialized
INFO - 2023-12-03 13:09:27 --> Language Class Initialized
INFO - 2023-12-03 13:09:27 --> Loader Class Initialized
INFO - 2023-12-03 13:09:27 --> Helper loaded: url_helper
INFO - 2023-12-03 13:09:27 --> Helper loaded: file_helper
INFO - 2023-12-03 13:09:27 --> Helper loaded: html_helper
INFO - 2023-12-03 13:09:27 --> Helper loaded: text_helper
INFO - 2023-12-03 13:09:27 --> Helper loaded: form_helper
INFO - 2023-12-03 13:09:27 --> Helper loaded: lang_helper
INFO - 2023-12-03 13:09:27 --> Helper loaded: security_helper
INFO - 2023-12-03 13:09:27 --> Helper loaded: cookie_helper
INFO - 2023-12-03 13:09:27 --> Database Driver Class Initialized
INFO - 2023-12-03 13:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 13:09:27 --> Parser Class Initialized
INFO - 2023-12-03 13:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-03 13:09:27 --> Pagination Class Initialized
INFO - 2023-12-03 13:09:27 --> Form Validation Class Initialized
INFO - 2023-12-03 13:09:27 --> Controller Class Initialized
INFO - 2023-12-03 13:09:27 --> Model Class Initialized
DEBUG - 2023-12-03 13:09:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-03 13:09:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 13:09:29 --> Config Class Initialized
INFO - 2023-12-03 13:09:29 --> Hooks Class Initialized
DEBUG - 2023-12-03 13:09:29 --> UTF-8 Support Enabled
INFO - 2023-12-03 13:09:29 --> Utf8 Class Initialized
INFO - 2023-12-03 13:09:29 --> URI Class Initialized
INFO - 2023-12-03 13:09:29 --> Router Class Initialized
INFO - 2023-12-03 13:09:29 --> Output Class Initialized
INFO - 2023-12-03 13:09:29 --> Security Class Initialized
DEBUG - 2023-12-03 13:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 13:09:29 --> Input Class Initialized
INFO - 2023-12-03 13:09:29 --> Language Class Initialized
INFO - 2023-12-03 13:09:29 --> Loader Class Initialized
INFO - 2023-12-03 13:09:29 --> Helper loaded: url_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: file_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: html_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: text_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: form_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: lang_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: security_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: cookie_helper
INFO - 2023-12-03 13:09:29 --> Database Driver Class Initialized
ERROR - 2023-12-03 13:09:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 13:09:29 --> Config Class Initialized
INFO - 2023-12-03 13:09:29 --> Hooks Class Initialized
INFO - 2023-12-03 13:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 13:09:29 --> Parser Class Initialized
DEBUG - 2023-12-03 13:09:29 --> UTF-8 Support Enabled
INFO - 2023-12-03 13:09:29 --> Utf8 Class Initialized
INFO - 2023-12-03 13:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-03 13:09:29 --> Pagination Class Initialized
INFO - 2023-12-03 13:09:29 --> URI Class Initialized
INFO - 2023-12-03 13:09:29 --> Router Class Initialized
INFO - 2023-12-03 13:09:29 --> Form Validation Class Initialized
INFO - 2023-12-03 13:09:29 --> Controller Class Initialized
INFO - 2023-12-03 13:09:29 --> Model Class Initialized
DEBUG - 2023-12-03 13:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:09:29 --> Output Class Initialized
INFO - 2023-12-03 13:09:29 --> Security Class Initialized
DEBUG - 2023-12-03 13:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 13:09:29 --> Input Class Initialized
INFO - 2023-12-03 13:09:29 --> Language Class Initialized
INFO - 2023-12-03 13:09:29 --> Loader Class Initialized
INFO - 2023-12-03 13:09:29 --> Helper loaded: url_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: file_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: html_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: text_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: form_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: lang_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: security_helper
INFO - 2023-12-03 13:09:29 --> Helper loaded: cookie_helper
INFO - 2023-12-03 13:09:29 --> Database Driver Class Initialized
INFO - 2023-12-03 13:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 13:09:29 --> Parser Class Initialized
INFO - 2023-12-03 13:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-03 13:09:29 --> Pagination Class Initialized
INFO - 2023-12-03 13:09:29 --> Form Validation Class Initialized
INFO - 2023-12-03 13:09:29 --> Controller Class Initialized
DEBUG - 2023-12-03 13:09:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 13:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:09:29 --> Model Class Initialized
INFO - 2023-12-03 13:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-03 13:09:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-03 13:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-03 13:09:29 --> Model Class Initialized
INFO - 2023-12-03 13:09:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-03 13:09:29 --> Final output sent to browser
DEBUG - 2023-12-03 13:09:29 --> Total execution time: 0.0364
ERROR - 2023-12-03 13:09:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 13:09:32 --> Config Class Initialized
INFO - 2023-12-03 13:09:32 --> Hooks Class Initialized
DEBUG - 2023-12-03 13:09:32 --> UTF-8 Support Enabled
INFO - 2023-12-03 13:09:32 --> Utf8 Class Initialized
INFO - 2023-12-03 13:09:32 --> URI Class Initialized
INFO - 2023-12-03 13:09:32 --> Router Class Initialized
INFO - 2023-12-03 13:09:32 --> Output Class Initialized
INFO - 2023-12-03 13:09:32 --> Security Class Initialized
DEBUG - 2023-12-03 13:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 13:09:32 --> Input Class Initialized
INFO - 2023-12-03 13:09:32 --> Language Class Initialized
INFO - 2023-12-03 13:09:32 --> Loader Class Initialized
INFO - 2023-12-03 13:09:32 --> Helper loaded: url_helper
INFO - 2023-12-03 13:09:32 --> Helper loaded: file_helper
INFO - 2023-12-03 13:09:32 --> Helper loaded: html_helper
INFO - 2023-12-03 13:09:32 --> Helper loaded: text_helper
INFO - 2023-12-03 13:09:32 --> Helper loaded: form_helper
INFO - 2023-12-03 13:09:32 --> Helper loaded: lang_helper
INFO - 2023-12-03 13:09:32 --> Helper loaded: security_helper
INFO - 2023-12-03 13:09:32 --> Helper loaded: cookie_helper
INFO - 2023-12-03 13:09:32 --> Database Driver Class Initialized
INFO - 2023-12-03 13:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 13:09:32 --> Parser Class Initialized
INFO - 2023-12-03 13:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-03 13:09:32 --> Pagination Class Initialized
INFO - 2023-12-03 13:09:32 --> Form Validation Class Initialized
INFO - 2023-12-03 13:09:32 --> Controller Class Initialized
INFO - 2023-12-03 13:09:32 --> Model Class Initialized
DEBUG - 2023-12-03 13:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:09:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-03 13:09:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:09:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-03 13:09:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-03 13:09:32 --> Model Class Initialized
INFO - 2023-12-03 13:09:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-03 13:09:32 --> Final output sent to browser
DEBUG - 2023-12-03 13:09:32 --> Total execution time: 0.0325
ERROR - 2023-12-03 13:09:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 13:09:35 --> Config Class Initialized
INFO - 2023-12-03 13:09:35 --> Hooks Class Initialized
DEBUG - 2023-12-03 13:09:35 --> UTF-8 Support Enabled
INFO - 2023-12-03 13:09:35 --> Utf8 Class Initialized
INFO - 2023-12-03 13:09:35 --> URI Class Initialized
INFO - 2023-12-03 13:09:35 --> Router Class Initialized
INFO - 2023-12-03 13:09:35 --> Output Class Initialized
INFO - 2023-12-03 13:09:35 --> Security Class Initialized
DEBUG - 2023-12-03 13:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 13:09:35 --> Input Class Initialized
INFO - 2023-12-03 13:09:35 --> Language Class Initialized
INFO - 2023-12-03 13:09:35 --> Loader Class Initialized
INFO - 2023-12-03 13:09:35 --> Helper loaded: url_helper
INFO - 2023-12-03 13:09:35 --> Helper loaded: file_helper
INFO - 2023-12-03 13:09:35 --> Helper loaded: html_helper
INFO - 2023-12-03 13:09:35 --> Helper loaded: text_helper
INFO - 2023-12-03 13:09:35 --> Helper loaded: form_helper
INFO - 2023-12-03 13:09:35 --> Helper loaded: lang_helper
INFO - 2023-12-03 13:09:35 --> Helper loaded: security_helper
INFO - 2023-12-03 13:09:35 --> Helper loaded: cookie_helper
INFO - 2023-12-03 13:09:35 --> Database Driver Class Initialized
INFO - 2023-12-03 13:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 13:09:35 --> Parser Class Initialized
INFO - 2023-12-03 13:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-03 13:09:35 --> Pagination Class Initialized
INFO - 2023-12-03 13:09:35 --> Form Validation Class Initialized
INFO - 2023-12-03 13:09:35 --> Controller Class Initialized
INFO - 2023-12-03 13:09:35 --> Model Class Initialized
DEBUG - 2023-12-03 13:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-03 13:09:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-03 13:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-03 13:09:35 --> Model Class Initialized
INFO - 2023-12-03 13:09:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-03 13:09:35 --> Final output sent to browser
DEBUG - 2023-12-03 13:09:35 --> Total execution time: 0.0291
ERROR - 2023-12-03 18:40:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-03 18:40:14 --> Config Class Initialized
INFO - 2023-12-03 18:40:14 --> Hooks Class Initialized
DEBUG - 2023-12-03 18:40:14 --> UTF-8 Support Enabled
INFO - 2023-12-03 18:40:14 --> Utf8 Class Initialized
INFO - 2023-12-03 18:40:14 --> URI Class Initialized
INFO - 2023-12-03 18:40:14 --> Router Class Initialized
INFO - 2023-12-03 18:40:14 --> Output Class Initialized
INFO - 2023-12-03 18:40:14 --> Security Class Initialized
DEBUG - 2023-12-03 18:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 18:40:14 --> Input Class Initialized
INFO - 2023-12-03 18:40:14 --> Language Class Initialized
ERROR - 2023-12-03 18:40:14 --> 404 Page Not Found: Well-known/assetlinks.json
