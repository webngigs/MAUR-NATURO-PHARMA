<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-02 03:46:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:46:33 --> Config Class Initialized
INFO - 2023-11-02 03:46:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:46:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:46:33 --> Utf8 Class Initialized
INFO - 2023-11-02 03:46:33 --> URI Class Initialized
DEBUG - 2023-11-02 03:46:33 --> No URI present. Default controller set.
INFO - 2023-11-02 03:46:33 --> Router Class Initialized
INFO - 2023-11-02 03:46:33 --> Output Class Initialized
INFO - 2023-11-02 03:46:33 --> Security Class Initialized
DEBUG - 2023-11-02 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:46:33 --> Input Class Initialized
INFO - 2023-11-02 03:46:33 --> Language Class Initialized
INFO - 2023-11-02 03:46:33 --> Loader Class Initialized
INFO - 2023-11-02 03:46:33 --> Helper loaded: url_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: file_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: html_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: text_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: form_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: security_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:46:33 --> Database Driver Class Initialized
INFO - 2023-11-02 03:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:46:33 --> Parser Class Initialized
INFO - 2023-11-02 03:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:46:33 --> Pagination Class Initialized
INFO - 2023-11-02 03:46:33 --> Form Validation Class Initialized
INFO - 2023-11-02 03:46:33 --> Controller Class Initialized
INFO - 2023-11-02 03:46:33 --> Model Class Initialized
DEBUG - 2023-11-02 03:46:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:46:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:46:33 --> Config Class Initialized
INFO - 2023-11-02 03:46:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:46:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:46:33 --> Utf8 Class Initialized
INFO - 2023-11-02 03:46:33 --> URI Class Initialized
INFO - 2023-11-02 03:46:33 --> Router Class Initialized
INFO - 2023-11-02 03:46:33 --> Output Class Initialized
INFO - 2023-11-02 03:46:33 --> Security Class Initialized
DEBUG - 2023-11-02 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:46:33 --> Input Class Initialized
INFO - 2023-11-02 03:46:33 --> Language Class Initialized
INFO - 2023-11-02 03:46:33 --> Loader Class Initialized
INFO - 2023-11-02 03:46:33 --> Helper loaded: url_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: file_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: html_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: text_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: form_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: security_helper
INFO - 2023-11-02 03:46:33 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:46:33 --> Database Driver Class Initialized
INFO - 2023-11-02 03:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:46:33 --> Parser Class Initialized
INFO - 2023-11-02 03:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:46:33 --> Pagination Class Initialized
INFO - 2023-11-02 03:46:33 --> Form Validation Class Initialized
INFO - 2023-11-02 03:46:33 --> Controller Class Initialized
INFO - 2023-11-02 03:46:33 --> Model Class Initialized
DEBUG - 2023-11-02 03:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 03:46:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 03:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 03:46:33 --> Model Class Initialized
INFO - 2023-11-02 03:46:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 03:46:33 --> Final output sent to browser
DEBUG - 2023-11-02 03:46:33 --> Total execution time: 0.0364
ERROR - 2023-11-02 03:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:47:13 --> Config Class Initialized
INFO - 2023-11-02 03:47:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:47:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:47:13 --> Utf8 Class Initialized
INFO - 2023-11-02 03:47:13 --> URI Class Initialized
DEBUG - 2023-11-02 03:47:13 --> No URI present. Default controller set.
INFO - 2023-11-02 03:47:13 --> Router Class Initialized
INFO - 2023-11-02 03:47:13 --> Output Class Initialized
INFO - 2023-11-02 03:47:13 --> Security Class Initialized
DEBUG - 2023-11-02 03:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:47:13 --> Input Class Initialized
INFO - 2023-11-02 03:47:13 --> Language Class Initialized
INFO - 2023-11-02 03:47:13 --> Loader Class Initialized
INFO - 2023-11-02 03:47:13 --> Helper loaded: url_helper
INFO - 2023-11-02 03:47:13 --> Helper loaded: file_helper
INFO - 2023-11-02 03:47:13 --> Helper loaded: html_helper
INFO - 2023-11-02 03:47:13 --> Helper loaded: text_helper
INFO - 2023-11-02 03:47:13 --> Helper loaded: form_helper
INFO - 2023-11-02 03:47:13 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:47:13 --> Helper loaded: security_helper
INFO - 2023-11-02 03:47:13 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:47:13 --> Database Driver Class Initialized
INFO - 2023-11-02 03:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:47:13 --> Parser Class Initialized
INFO - 2023-11-02 03:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:47:13 --> Pagination Class Initialized
INFO - 2023-11-02 03:47:13 --> Form Validation Class Initialized
INFO - 2023-11-02 03:47:13 --> Controller Class Initialized
INFO - 2023-11-02 03:47:13 --> Model Class Initialized
DEBUG - 2023-11-02 03:47:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:47:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:47:14 --> Config Class Initialized
INFO - 2023-11-02 03:47:14 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:47:14 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:47:14 --> Utf8 Class Initialized
INFO - 2023-11-02 03:47:14 --> URI Class Initialized
INFO - 2023-11-02 03:47:14 --> Router Class Initialized
INFO - 2023-11-02 03:47:14 --> Output Class Initialized
INFO - 2023-11-02 03:47:14 --> Security Class Initialized
DEBUG - 2023-11-02 03:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:47:14 --> Input Class Initialized
INFO - 2023-11-02 03:47:14 --> Language Class Initialized
INFO - 2023-11-02 03:47:14 --> Loader Class Initialized
INFO - 2023-11-02 03:47:14 --> Helper loaded: url_helper
INFO - 2023-11-02 03:47:14 --> Helper loaded: file_helper
INFO - 2023-11-02 03:47:14 --> Helper loaded: html_helper
INFO - 2023-11-02 03:47:14 --> Helper loaded: text_helper
INFO - 2023-11-02 03:47:14 --> Helper loaded: form_helper
INFO - 2023-11-02 03:47:14 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:47:14 --> Helper loaded: security_helper
INFO - 2023-11-02 03:47:14 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:47:14 --> Database Driver Class Initialized
INFO - 2023-11-02 03:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:47:14 --> Parser Class Initialized
INFO - 2023-11-02 03:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:47:14 --> Pagination Class Initialized
INFO - 2023-11-02 03:47:14 --> Form Validation Class Initialized
INFO - 2023-11-02 03:47:14 --> Controller Class Initialized
INFO - 2023-11-02 03:47:14 --> Model Class Initialized
DEBUG - 2023-11-02 03:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 03:47:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 03:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 03:47:14 --> Model Class Initialized
INFO - 2023-11-02 03:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 03:47:14 --> Final output sent to browser
DEBUG - 2023-11-02 03:47:14 --> Total execution time: 0.0358
ERROR - 2023-11-02 03:48:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:48:47 --> Config Class Initialized
INFO - 2023-11-02 03:48:47 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:48:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:48:47 --> Utf8 Class Initialized
INFO - 2023-11-02 03:48:47 --> URI Class Initialized
DEBUG - 2023-11-02 03:48:47 --> No URI present. Default controller set.
INFO - 2023-11-02 03:48:47 --> Router Class Initialized
INFO - 2023-11-02 03:48:47 --> Output Class Initialized
INFO - 2023-11-02 03:48:47 --> Security Class Initialized
DEBUG - 2023-11-02 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:48:47 --> Input Class Initialized
INFO - 2023-11-02 03:48:47 --> Language Class Initialized
INFO - 2023-11-02 03:48:47 --> Loader Class Initialized
INFO - 2023-11-02 03:48:47 --> Helper loaded: url_helper
INFO - 2023-11-02 03:48:47 --> Helper loaded: file_helper
INFO - 2023-11-02 03:48:47 --> Helper loaded: html_helper
INFO - 2023-11-02 03:48:47 --> Helper loaded: text_helper
INFO - 2023-11-02 03:48:47 --> Helper loaded: form_helper
INFO - 2023-11-02 03:48:47 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:48:47 --> Helper loaded: security_helper
INFO - 2023-11-02 03:48:47 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:48:47 --> Database Driver Class Initialized
INFO - 2023-11-02 03:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:48:47 --> Parser Class Initialized
INFO - 2023-11-02 03:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:48:47 --> Pagination Class Initialized
INFO - 2023-11-02 03:48:47 --> Form Validation Class Initialized
INFO - 2023-11-02 03:48:47 --> Controller Class Initialized
INFO - 2023-11-02 03:48:47 --> Model Class Initialized
DEBUG - 2023-11-02 03:48:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:48:49 --> Config Class Initialized
INFO - 2023-11-02 03:48:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:48:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:48:49 --> Utf8 Class Initialized
INFO - 2023-11-02 03:48:49 --> URI Class Initialized
INFO - 2023-11-02 03:48:49 --> Router Class Initialized
INFO - 2023-11-02 03:48:49 --> Output Class Initialized
INFO - 2023-11-02 03:48:49 --> Security Class Initialized
DEBUG - 2023-11-02 03:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:48:49 --> Input Class Initialized
INFO - 2023-11-02 03:48:49 --> Language Class Initialized
INFO - 2023-11-02 03:48:49 --> Loader Class Initialized
INFO - 2023-11-02 03:48:49 --> Helper loaded: url_helper
INFO - 2023-11-02 03:48:49 --> Helper loaded: file_helper
INFO - 2023-11-02 03:48:49 --> Helper loaded: html_helper
INFO - 2023-11-02 03:48:49 --> Helper loaded: text_helper
INFO - 2023-11-02 03:48:49 --> Helper loaded: form_helper
INFO - 2023-11-02 03:48:49 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:48:49 --> Helper loaded: security_helper
INFO - 2023-11-02 03:48:49 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:48:49 --> Database Driver Class Initialized
INFO - 2023-11-02 03:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:48:49 --> Parser Class Initialized
INFO - 2023-11-02 03:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:48:49 --> Pagination Class Initialized
INFO - 2023-11-02 03:48:49 --> Form Validation Class Initialized
INFO - 2023-11-02 03:48:49 --> Controller Class Initialized
INFO - 2023-11-02 03:48:49 --> Model Class Initialized
DEBUG - 2023-11-02 03:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 03:48:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 03:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 03:48:49 --> Model Class Initialized
INFO - 2023-11-02 03:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 03:48:49 --> Final output sent to browser
DEBUG - 2023-11-02 03:48:49 --> Total execution time: 0.0358
ERROR - 2023-11-02 03:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:49:40 --> Config Class Initialized
INFO - 2023-11-02 03:49:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:49:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:49:40 --> Utf8 Class Initialized
INFO - 2023-11-02 03:49:40 --> URI Class Initialized
DEBUG - 2023-11-02 03:49:40 --> No URI present. Default controller set.
INFO - 2023-11-02 03:49:40 --> Router Class Initialized
INFO - 2023-11-02 03:49:40 --> Output Class Initialized
INFO - 2023-11-02 03:49:40 --> Security Class Initialized
DEBUG - 2023-11-02 03:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:49:40 --> Input Class Initialized
INFO - 2023-11-02 03:49:40 --> Language Class Initialized
INFO - 2023-11-02 03:49:40 --> Loader Class Initialized
INFO - 2023-11-02 03:49:40 --> Helper loaded: url_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: file_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: html_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: text_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: form_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: security_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:49:40 --> Database Driver Class Initialized
INFO - 2023-11-02 03:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:49:40 --> Parser Class Initialized
INFO - 2023-11-02 03:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:49:40 --> Pagination Class Initialized
INFO - 2023-11-02 03:49:40 --> Form Validation Class Initialized
INFO - 2023-11-02 03:49:40 --> Controller Class Initialized
INFO - 2023-11-02 03:49:40 --> Model Class Initialized
DEBUG - 2023-11-02 03:49:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:49:40 --> Config Class Initialized
INFO - 2023-11-02 03:49:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:49:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:49:40 --> Utf8 Class Initialized
INFO - 2023-11-02 03:49:40 --> URI Class Initialized
INFO - 2023-11-02 03:49:40 --> Router Class Initialized
INFO - 2023-11-02 03:49:40 --> Output Class Initialized
INFO - 2023-11-02 03:49:40 --> Security Class Initialized
DEBUG - 2023-11-02 03:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:49:40 --> Input Class Initialized
INFO - 2023-11-02 03:49:40 --> Language Class Initialized
INFO - 2023-11-02 03:49:40 --> Loader Class Initialized
INFO - 2023-11-02 03:49:40 --> Helper loaded: url_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: file_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: html_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: text_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: form_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: security_helper
INFO - 2023-11-02 03:49:40 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:49:40 --> Database Driver Class Initialized
INFO - 2023-11-02 03:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:49:40 --> Parser Class Initialized
INFO - 2023-11-02 03:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:49:40 --> Pagination Class Initialized
INFO - 2023-11-02 03:49:40 --> Form Validation Class Initialized
INFO - 2023-11-02 03:49:40 --> Controller Class Initialized
INFO - 2023-11-02 03:49:40 --> Model Class Initialized
DEBUG - 2023-11-02 03:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 03:49:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 03:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 03:49:40 --> Model Class Initialized
INFO - 2023-11-02 03:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 03:49:40 --> Final output sent to browser
DEBUG - 2023-11-02 03:49:40 --> Total execution time: 0.0320
ERROR - 2023-11-02 03:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:53:05 --> Config Class Initialized
INFO - 2023-11-02 03:53:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:53:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:53:05 --> Utf8 Class Initialized
INFO - 2023-11-02 03:53:05 --> URI Class Initialized
DEBUG - 2023-11-02 03:53:05 --> No URI present. Default controller set.
INFO - 2023-11-02 03:53:05 --> Router Class Initialized
INFO - 2023-11-02 03:53:05 --> Output Class Initialized
INFO - 2023-11-02 03:53:05 --> Security Class Initialized
DEBUG - 2023-11-02 03:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:53:05 --> Input Class Initialized
INFO - 2023-11-02 03:53:05 --> Language Class Initialized
INFO - 2023-11-02 03:53:05 --> Loader Class Initialized
INFO - 2023-11-02 03:53:05 --> Helper loaded: url_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: file_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: html_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: text_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: form_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: security_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:53:05 --> Database Driver Class Initialized
INFO - 2023-11-02 03:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:53:05 --> Parser Class Initialized
INFO - 2023-11-02 03:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:53:05 --> Pagination Class Initialized
INFO - 2023-11-02 03:53:05 --> Form Validation Class Initialized
INFO - 2023-11-02 03:53:05 --> Controller Class Initialized
INFO - 2023-11-02 03:53:05 --> Model Class Initialized
DEBUG - 2023-11-02 03:53:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:53:05 --> Config Class Initialized
INFO - 2023-11-02 03:53:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:53:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:53:05 --> Utf8 Class Initialized
INFO - 2023-11-02 03:53:05 --> URI Class Initialized
INFO - 2023-11-02 03:53:05 --> Router Class Initialized
INFO - 2023-11-02 03:53:05 --> Output Class Initialized
INFO - 2023-11-02 03:53:05 --> Security Class Initialized
DEBUG - 2023-11-02 03:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:53:05 --> Input Class Initialized
INFO - 2023-11-02 03:53:05 --> Language Class Initialized
INFO - 2023-11-02 03:53:05 --> Loader Class Initialized
INFO - 2023-11-02 03:53:05 --> Helper loaded: url_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: file_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: html_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: text_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: form_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: security_helper
INFO - 2023-11-02 03:53:05 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:53:05 --> Database Driver Class Initialized
INFO - 2023-11-02 03:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:53:05 --> Parser Class Initialized
INFO - 2023-11-02 03:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:53:05 --> Pagination Class Initialized
INFO - 2023-11-02 03:53:05 --> Form Validation Class Initialized
INFO - 2023-11-02 03:53:05 --> Controller Class Initialized
INFO - 2023-11-02 03:53:05 --> Model Class Initialized
DEBUG - 2023-11-02 03:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 03:53:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 03:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 03:53:05 --> Model Class Initialized
INFO - 2023-11-02 03:53:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 03:53:05 --> Final output sent to browser
DEBUG - 2023-11-02 03:53:05 --> Total execution time: 0.0349
ERROR - 2023-11-02 03:55:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:55:49 --> Config Class Initialized
INFO - 2023-11-02 03:55:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:55:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:55:49 --> Utf8 Class Initialized
INFO - 2023-11-02 03:55:49 --> URI Class Initialized
DEBUG - 2023-11-02 03:55:49 --> No URI present. Default controller set.
INFO - 2023-11-02 03:55:49 --> Router Class Initialized
INFO - 2023-11-02 03:55:49 --> Output Class Initialized
INFO - 2023-11-02 03:55:49 --> Security Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:55:49 --> Input Class Initialized
INFO - 2023-11-02 03:55:49 --> Language Class Initialized
INFO - 2023-11-02 03:55:49 --> Loader Class Initialized
INFO - 2023-11-02 03:55:49 --> Helper loaded: url_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: file_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: html_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: text_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: form_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: security_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:55:49 --> Database Driver Class Initialized
INFO - 2023-11-02 03:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:55:49 --> Parser Class Initialized
INFO - 2023-11-02 03:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:55:49 --> Pagination Class Initialized
INFO - 2023-11-02 03:55:49 --> Form Validation Class Initialized
INFO - 2023-11-02 03:55:49 --> Controller Class Initialized
INFO - 2023-11-02 03:55:49 --> Model Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:55:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:55:49 --> Config Class Initialized
INFO - 2023-11-02 03:55:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:55:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:55:49 --> Utf8 Class Initialized
INFO - 2023-11-02 03:55:49 --> URI Class Initialized
DEBUG - 2023-11-02 03:55:49 --> No URI present. Default controller set.
INFO - 2023-11-02 03:55:49 --> Router Class Initialized
INFO - 2023-11-02 03:55:49 --> Output Class Initialized
INFO - 2023-11-02 03:55:49 --> Security Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:55:49 --> Input Class Initialized
INFO - 2023-11-02 03:55:49 --> Language Class Initialized
INFO - 2023-11-02 03:55:49 --> Loader Class Initialized
INFO - 2023-11-02 03:55:49 --> Helper loaded: url_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: file_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: html_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: text_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: form_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: security_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:55:49 --> Database Driver Class Initialized
INFO - 2023-11-02 03:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:55:49 --> Parser Class Initialized
INFO - 2023-11-02 03:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:55:49 --> Pagination Class Initialized
INFO - 2023-11-02 03:55:49 --> Form Validation Class Initialized
INFO - 2023-11-02 03:55:49 --> Controller Class Initialized
INFO - 2023-11-02 03:55:49 --> Model Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:55:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:55:49 --> Config Class Initialized
INFO - 2023-11-02 03:55:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:55:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:55:49 --> Utf8 Class Initialized
INFO - 2023-11-02 03:55:49 --> URI Class Initialized
DEBUG - 2023-11-02 03:55:49 --> No URI present. Default controller set.
INFO - 2023-11-02 03:55:49 --> Router Class Initialized
INFO - 2023-11-02 03:55:49 --> Output Class Initialized
INFO - 2023-11-02 03:55:49 --> Security Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:55:49 --> Input Class Initialized
INFO - 2023-11-02 03:55:49 --> Language Class Initialized
INFO - 2023-11-02 03:55:49 --> Loader Class Initialized
INFO - 2023-11-02 03:55:49 --> Helper loaded: url_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: file_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: html_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: text_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: form_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: security_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: cookie_helper
ERROR - 2023-11-02 03:55:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:55:49 --> Config Class Initialized
INFO - 2023-11-02 03:55:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:55:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:55:49 --> Utf8 Class Initialized
INFO - 2023-11-02 03:55:49 --> URI Class Initialized
DEBUG - 2023-11-02 03:55:49 --> No URI present. Default controller set.
INFO - 2023-11-02 03:55:49 --> Router Class Initialized
INFO - 2023-11-02 03:55:49 --> Database Driver Class Initialized
INFO - 2023-11-02 03:55:49 --> Output Class Initialized
INFO - 2023-11-02 03:55:49 --> Security Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:55:49 --> Input Class Initialized
INFO - 2023-11-02 03:55:49 --> Language Class Initialized
INFO - 2023-11-02 03:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:55:49 --> Parser Class Initialized
INFO - 2023-11-02 03:55:49 --> Loader Class Initialized
INFO - 2023-11-02 03:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:55:49 --> Pagination Class Initialized
INFO - 2023-11-02 03:55:49 --> Helper loaded: url_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: file_helper
INFO - 2023-11-02 03:55:49 --> Form Validation Class Initialized
INFO - 2023-11-02 03:55:49 --> Helper loaded: html_helper
INFO - 2023-11-02 03:55:49 --> Controller Class Initialized
INFO - 2023-11-02 03:55:49 --> Model Class Initialized
INFO - 2023-11-02 03:55:49 --> Helper loaded: text_helper
DEBUG - 2023-11-02 03:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:55:49 --> Helper loaded: form_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: security_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:55:49 --> Database Driver Class Initialized
INFO - 2023-11-02 03:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:55:49 --> Parser Class Initialized
INFO - 2023-11-02 03:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:55:49 --> Pagination Class Initialized
INFO - 2023-11-02 03:55:49 --> Form Validation Class Initialized
INFO - 2023-11-02 03:55:49 --> Controller Class Initialized
INFO - 2023-11-02 03:55:49 --> Model Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:55:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:55:49 --> Config Class Initialized
INFO - 2023-11-02 03:55:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:55:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:55:49 --> Utf8 Class Initialized
INFO - 2023-11-02 03:55:49 --> URI Class Initialized
DEBUG - 2023-11-02 03:55:49 --> No URI present. Default controller set.
INFO - 2023-11-02 03:55:49 --> Router Class Initialized
INFO - 2023-11-02 03:55:49 --> Output Class Initialized
INFO - 2023-11-02 03:55:49 --> Security Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:55:49 --> Input Class Initialized
INFO - 2023-11-02 03:55:49 --> Language Class Initialized
INFO - 2023-11-02 03:55:49 --> Loader Class Initialized
INFO - 2023-11-02 03:55:49 --> Helper loaded: url_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: file_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: html_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: text_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: form_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: security_helper
INFO - 2023-11-02 03:55:49 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:55:49 --> Database Driver Class Initialized
INFO - 2023-11-02 03:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:55:49 --> Parser Class Initialized
INFO - 2023-11-02 03:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:55:49 --> Pagination Class Initialized
INFO - 2023-11-02 03:55:49 --> Form Validation Class Initialized
INFO - 2023-11-02 03:55:49 --> Controller Class Initialized
INFO - 2023-11-02 03:55:49 --> Model Class Initialized
DEBUG - 2023-11-02 03:55:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:55:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:55:50 --> Config Class Initialized
INFO - 2023-11-02 03:55:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:55:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:55:50 --> Utf8 Class Initialized
INFO - 2023-11-02 03:55:50 --> URI Class Initialized
DEBUG - 2023-11-02 03:55:50 --> No URI present. Default controller set.
INFO - 2023-11-02 03:55:50 --> Router Class Initialized
INFO - 2023-11-02 03:55:50 --> Output Class Initialized
INFO - 2023-11-02 03:55:50 --> Security Class Initialized
DEBUG - 2023-11-02 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:55:50 --> Input Class Initialized
INFO - 2023-11-02 03:55:50 --> Language Class Initialized
INFO - 2023-11-02 03:55:50 --> Loader Class Initialized
INFO - 2023-11-02 03:55:50 --> Helper loaded: url_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: file_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: html_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: text_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: form_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: security_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:55:50 --> Database Driver Class Initialized
INFO - 2023-11-02 03:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:55:50 --> Parser Class Initialized
INFO - 2023-11-02 03:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:55:50 --> Pagination Class Initialized
INFO - 2023-11-02 03:55:50 --> Form Validation Class Initialized
INFO - 2023-11-02 03:55:50 --> Controller Class Initialized
INFO - 2023-11-02 03:55:50 --> Model Class Initialized
DEBUG - 2023-11-02 03:55:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 03:55:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:55:50 --> Config Class Initialized
INFO - 2023-11-02 03:55:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:55:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:55:50 --> Utf8 Class Initialized
INFO - 2023-11-02 03:55:50 --> URI Class Initialized
INFO - 2023-11-02 03:55:50 --> Router Class Initialized
INFO - 2023-11-02 03:55:50 --> Output Class Initialized
INFO - 2023-11-02 03:55:50 --> Security Class Initialized
DEBUG - 2023-11-02 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:55:50 --> Input Class Initialized
INFO - 2023-11-02 03:55:50 --> Language Class Initialized
INFO - 2023-11-02 03:55:50 --> Loader Class Initialized
INFO - 2023-11-02 03:55:50 --> Helper loaded: url_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: file_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: html_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: text_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: form_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: security_helper
INFO - 2023-11-02 03:55:50 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:55:50 --> Database Driver Class Initialized
INFO - 2023-11-02 03:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:55:50 --> Parser Class Initialized
INFO - 2023-11-02 03:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:55:50 --> Pagination Class Initialized
INFO - 2023-11-02 03:55:50 --> Form Validation Class Initialized
INFO - 2023-11-02 03:55:50 --> Controller Class Initialized
INFO - 2023-11-02 03:55:50 --> Model Class Initialized
DEBUG - 2023-11-02 03:55:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:55:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 03:55:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 03:55:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 03:55:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 03:55:50 --> Model Class Initialized
INFO - 2023-11-02 03:55:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 03:55:50 --> Final output sent to browser
DEBUG - 2023-11-02 03:55:50 --> Total execution time: 0.0314
ERROR - 2023-11-02 03:56:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 03:56:13 --> Config Class Initialized
INFO - 2023-11-02 03:56:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 03:56:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 03:56:13 --> Utf8 Class Initialized
INFO - 2023-11-02 03:56:13 --> URI Class Initialized
DEBUG - 2023-11-02 03:56:13 --> No URI present. Default controller set.
INFO - 2023-11-02 03:56:13 --> Router Class Initialized
INFO - 2023-11-02 03:56:13 --> Output Class Initialized
INFO - 2023-11-02 03:56:13 --> Security Class Initialized
DEBUG - 2023-11-02 03:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 03:56:13 --> Input Class Initialized
INFO - 2023-11-02 03:56:13 --> Language Class Initialized
INFO - 2023-11-02 03:56:13 --> Loader Class Initialized
INFO - 2023-11-02 03:56:13 --> Helper loaded: url_helper
INFO - 2023-11-02 03:56:13 --> Helper loaded: file_helper
INFO - 2023-11-02 03:56:13 --> Helper loaded: html_helper
INFO - 2023-11-02 03:56:13 --> Helper loaded: text_helper
INFO - 2023-11-02 03:56:13 --> Helper loaded: form_helper
INFO - 2023-11-02 03:56:13 --> Helper loaded: lang_helper
INFO - 2023-11-02 03:56:13 --> Helper loaded: security_helper
INFO - 2023-11-02 03:56:13 --> Helper loaded: cookie_helper
INFO - 2023-11-02 03:56:13 --> Database Driver Class Initialized
INFO - 2023-11-02 03:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 03:56:13 --> Parser Class Initialized
INFO - 2023-11-02 03:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 03:56:13 --> Pagination Class Initialized
INFO - 2023-11-02 03:56:13 --> Form Validation Class Initialized
INFO - 2023-11-02 03:56:13 --> Controller Class Initialized
INFO - 2023-11-02 03:56:13 --> Model Class Initialized
DEBUG - 2023-11-02 03:56:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 04:56:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 04:56:59 --> Config Class Initialized
INFO - 2023-11-02 04:56:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 04:56:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 04:56:59 --> Utf8 Class Initialized
INFO - 2023-11-02 04:56:59 --> URI Class Initialized
DEBUG - 2023-11-02 04:56:59 --> No URI present. Default controller set.
INFO - 2023-11-02 04:56:59 --> Router Class Initialized
INFO - 2023-11-02 04:56:59 --> Output Class Initialized
INFO - 2023-11-02 04:56:59 --> Security Class Initialized
DEBUG - 2023-11-02 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 04:56:59 --> Input Class Initialized
INFO - 2023-11-02 04:56:59 --> Language Class Initialized
INFO - 2023-11-02 04:56:59 --> Loader Class Initialized
INFO - 2023-11-02 04:56:59 --> Helper loaded: url_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: file_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: html_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: text_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: form_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: lang_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: security_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: cookie_helper
INFO - 2023-11-02 04:56:59 --> Database Driver Class Initialized
INFO - 2023-11-02 04:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 04:56:59 --> Parser Class Initialized
INFO - 2023-11-02 04:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 04:56:59 --> Pagination Class Initialized
INFO - 2023-11-02 04:56:59 --> Form Validation Class Initialized
INFO - 2023-11-02 04:56:59 --> Controller Class Initialized
INFO - 2023-11-02 04:56:59 --> Model Class Initialized
DEBUG - 2023-11-02 04:56:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 04:56:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 04:56:59 --> Config Class Initialized
INFO - 2023-11-02 04:56:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 04:56:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 04:56:59 --> Utf8 Class Initialized
INFO - 2023-11-02 04:56:59 --> URI Class Initialized
INFO - 2023-11-02 04:56:59 --> Router Class Initialized
INFO - 2023-11-02 04:56:59 --> Output Class Initialized
INFO - 2023-11-02 04:56:59 --> Security Class Initialized
DEBUG - 2023-11-02 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 04:56:59 --> Input Class Initialized
INFO - 2023-11-02 04:56:59 --> Language Class Initialized
INFO - 2023-11-02 04:56:59 --> Loader Class Initialized
INFO - 2023-11-02 04:56:59 --> Helper loaded: url_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: file_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: html_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: text_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: form_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: lang_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: security_helper
INFO - 2023-11-02 04:56:59 --> Helper loaded: cookie_helper
INFO - 2023-11-02 04:56:59 --> Database Driver Class Initialized
INFO - 2023-11-02 04:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 04:56:59 --> Parser Class Initialized
INFO - 2023-11-02 04:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 04:56:59 --> Pagination Class Initialized
INFO - 2023-11-02 04:56:59 --> Form Validation Class Initialized
INFO - 2023-11-02 04:56:59 --> Controller Class Initialized
INFO - 2023-11-02 04:56:59 --> Model Class Initialized
DEBUG - 2023-11-02 04:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 04:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 04:56:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 04:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 04:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 04:56:59 --> Model Class Initialized
INFO - 2023-11-02 04:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 04:56:59 --> Final output sent to browser
DEBUG - 2023-11-02 04:56:59 --> Total execution time: 0.0349
ERROR - 2023-11-02 04:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 04:57:07 --> Config Class Initialized
INFO - 2023-11-02 04:57:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 04:57:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 04:57:07 --> Utf8 Class Initialized
INFO - 2023-11-02 04:57:07 --> URI Class Initialized
DEBUG - 2023-11-02 04:57:07 --> No URI present. Default controller set.
INFO - 2023-11-02 04:57:07 --> Router Class Initialized
INFO - 2023-11-02 04:57:07 --> Output Class Initialized
INFO - 2023-11-02 04:57:07 --> Security Class Initialized
DEBUG - 2023-11-02 04:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 04:57:07 --> Input Class Initialized
INFO - 2023-11-02 04:57:07 --> Language Class Initialized
INFO - 2023-11-02 04:57:07 --> Loader Class Initialized
INFO - 2023-11-02 04:57:07 --> Helper loaded: url_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: file_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: html_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: text_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: form_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: lang_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: security_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: cookie_helper
INFO - 2023-11-02 04:57:07 --> Database Driver Class Initialized
INFO - 2023-11-02 04:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 04:57:07 --> Parser Class Initialized
INFO - 2023-11-02 04:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 04:57:07 --> Pagination Class Initialized
INFO - 2023-11-02 04:57:07 --> Form Validation Class Initialized
INFO - 2023-11-02 04:57:07 --> Controller Class Initialized
INFO - 2023-11-02 04:57:07 --> Model Class Initialized
DEBUG - 2023-11-02 04:57:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 04:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 04:57:07 --> Config Class Initialized
INFO - 2023-11-02 04:57:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 04:57:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 04:57:07 --> Utf8 Class Initialized
INFO - 2023-11-02 04:57:07 --> URI Class Initialized
INFO - 2023-11-02 04:57:07 --> Router Class Initialized
INFO - 2023-11-02 04:57:07 --> Output Class Initialized
INFO - 2023-11-02 04:57:07 --> Security Class Initialized
DEBUG - 2023-11-02 04:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 04:57:07 --> Input Class Initialized
INFO - 2023-11-02 04:57:07 --> Language Class Initialized
INFO - 2023-11-02 04:57:07 --> Loader Class Initialized
INFO - 2023-11-02 04:57:07 --> Helper loaded: url_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: file_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: html_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: text_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: form_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: lang_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: security_helper
INFO - 2023-11-02 04:57:07 --> Helper loaded: cookie_helper
INFO - 2023-11-02 04:57:07 --> Database Driver Class Initialized
INFO - 2023-11-02 04:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 04:57:07 --> Parser Class Initialized
INFO - 2023-11-02 04:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 04:57:07 --> Pagination Class Initialized
INFO - 2023-11-02 04:57:07 --> Form Validation Class Initialized
INFO - 2023-11-02 04:57:07 --> Controller Class Initialized
INFO - 2023-11-02 04:57:07 --> Model Class Initialized
DEBUG - 2023-11-02 04:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 04:57:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 04:57:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 04:57:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 04:57:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 04:57:08 --> Model Class Initialized
INFO - 2023-11-02 04:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 04:57:08 --> Final output sent to browser
DEBUG - 2023-11-02 04:57:08 --> Total execution time: 0.0393
ERROR - 2023-11-02 04:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 04:57:10 --> Config Class Initialized
INFO - 2023-11-02 04:57:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 04:57:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 04:57:10 --> Utf8 Class Initialized
INFO - 2023-11-02 04:57:10 --> URI Class Initialized
DEBUG - 2023-11-02 04:57:10 --> No URI present. Default controller set.
INFO - 2023-11-02 04:57:10 --> Router Class Initialized
INFO - 2023-11-02 04:57:10 --> Output Class Initialized
INFO - 2023-11-02 04:57:10 --> Security Class Initialized
DEBUG - 2023-11-02 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 04:57:10 --> Input Class Initialized
INFO - 2023-11-02 04:57:10 --> Language Class Initialized
INFO - 2023-11-02 04:57:10 --> Loader Class Initialized
INFO - 2023-11-02 04:57:10 --> Helper loaded: url_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: file_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: html_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: text_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: form_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: lang_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: security_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: cookie_helper
INFO - 2023-11-02 04:57:10 --> Database Driver Class Initialized
INFO - 2023-11-02 04:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 04:57:10 --> Parser Class Initialized
INFO - 2023-11-02 04:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 04:57:10 --> Pagination Class Initialized
INFO - 2023-11-02 04:57:10 --> Form Validation Class Initialized
INFO - 2023-11-02 04:57:10 --> Controller Class Initialized
INFO - 2023-11-02 04:57:10 --> Model Class Initialized
DEBUG - 2023-11-02 04:57:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 04:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 04:57:10 --> Config Class Initialized
INFO - 2023-11-02 04:57:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 04:57:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 04:57:10 --> Utf8 Class Initialized
INFO - 2023-11-02 04:57:10 --> URI Class Initialized
INFO - 2023-11-02 04:57:10 --> Router Class Initialized
INFO - 2023-11-02 04:57:10 --> Output Class Initialized
INFO - 2023-11-02 04:57:10 --> Security Class Initialized
DEBUG - 2023-11-02 04:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 04:57:10 --> Input Class Initialized
INFO - 2023-11-02 04:57:10 --> Language Class Initialized
INFO - 2023-11-02 04:57:10 --> Loader Class Initialized
INFO - 2023-11-02 04:57:10 --> Helper loaded: url_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: file_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: html_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: text_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: form_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: lang_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: security_helper
INFO - 2023-11-02 04:57:10 --> Helper loaded: cookie_helper
INFO - 2023-11-02 04:57:10 --> Database Driver Class Initialized
INFO - 2023-11-02 04:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 04:57:10 --> Parser Class Initialized
INFO - 2023-11-02 04:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 04:57:10 --> Pagination Class Initialized
INFO - 2023-11-02 04:57:10 --> Form Validation Class Initialized
INFO - 2023-11-02 04:57:10 --> Controller Class Initialized
INFO - 2023-11-02 04:57:10 --> Model Class Initialized
DEBUG - 2023-11-02 04:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 04:57:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 04:57:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 04:57:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 04:57:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 04:57:10 --> Model Class Initialized
INFO - 2023-11-02 04:57:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 04:57:10 --> Final output sent to browser
DEBUG - 2023-11-02 04:57:10 --> Total execution time: 0.0308
ERROR - 2023-11-02 05:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:02:25 --> Config Class Initialized
INFO - 2023-11-02 05:02:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:02:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:02:25 --> Utf8 Class Initialized
INFO - 2023-11-02 05:02:25 --> URI Class Initialized
DEBUG - 2023-11-02 05:02:25 --> No URI present. Default controller set.
INFO - 2023-11-02 05:02:25 --> Router Class Initialized
INFO - 2023-11-02 05:02:25 --> Output Class Initialized
INFO - 2023-11-02 05:02:25 --> Security Class Initialized
DEBUG - 2023-11-02 05:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:02:25 --> Input Class Initialized
INFO - 2023-11-02 05:02:25 --> Language Class Initialized
INFO - 2023-11-02 05:02:25 --> Loader Class Initialized
INFO - 2023-11-02 05:02:25 --> Helper loaded: url_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: file_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: html_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: text_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: form_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: security_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:02:25 --> Database Driver Class Initialized
INFO - 2023-11-02 05:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:02:25 --> Parser Class Initialized
INFO - 2023-11-02 05:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:02:25 --> Pagination Class Initialized
INFO - 2023-11-02 05:02:25 --> Form Validation Class Initialized
INFO - 2023-11-02 05:02:25 --> Controller Class Initialized
INFO - 2023-11-02 05:02:25 --> Model Class Initialized
DEBUG - 2023-11-02 05:02:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:02:25 --> Config Class Initialized
INFO - 2023-11-02 05:02:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:02:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:02:25 --> Utf8 Class Initialized
INFO - 2023-11-02 05:02:25 --> URI Class Initialized
INFO - 2023-11-02 05:02:25 --> Router Class Initialized
INFO - 2023-11-02 05:02:25 --> Output Class Initialized
INFO - 2023-11-02 05:02:25 --> Security Class Initialized
DEBUG - 2023-11-02 05:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:02:25 --> Input Class Initialized
INFO - 2023-11-02 05:02:25 --> Language Class Initialized
INFO - 2023-11-02 05:02:25 --> Loader Class Initialized
INFO - 2023-11-02 05:02:25 --> Helper loaded: url_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: file_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: html_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: text_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: form_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: security_helper
INFO - 2023-11-02 05:02:25 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:02:25 --> Database Driver Class Initialized
INFO - 2023-11-02 05:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:02:25 --> Parser Class Initialized
INFO - 2023-11-02 05:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:02:25 --> Pagination Class Initialized
INFO - 2023-11-02 05:02:25 --> Form Validation Class Initialized
INFO - 2023-11-02 05:02:25 --> Controller Class Initialized
INFO - 2023-11-02 05:02:25 --> Model Class Initialized
DEBUG - 2023-11-02 05:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 05:02:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 05:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 05:02:25 --> Model Class Initialized
INFO - 2023-11-02 05:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 05:02:25 --> Final output sent to browser
DEBUG - 2023-11-02 05:02:25 --> Total execution time: 0.0355
ERROR - 2023-11-02 05:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:04:01 --> Config Class Initialized
INFO - 2023-11-02 05:04:01 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:04:01 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:04:01 --> Utf8 Class Initialized
INFO - 2023-11-02 05:04:01 --> URI Class Initialized
INFO - 2023-11-02 05:04:01 --> Router Class Initialized
INFO - 2023-11-02 05:04:01 --> Output Class Initialized
INFO - 2023-11-02 05:04:01 --> Security Class Initialized
DEBUG - 2023-11-02 05:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:04:01 --> Input Class Initialized
INFO - 2023-11-02 05:04:01 --> Language Class Initialized
ERROR - 2023-11-02 05:04:01 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-02 05:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:04:20 --> Config Class Initialized
INFO - 2023-11-02 05:04:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:04:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:04:20 --> Utf8 Class Initialized
INFO - 2023-11-02 05:04:20 --> URI Class Initialized
DEBUG - 2023-11-02 05:04:20 --> No URI present. Default controller set.
INFO - 2023-11-02 05:04:20 --> Router Class Initialized
INFO - 2023-11-02 05:04:20 --> Output Class Initialized
INFO - 2023-11-02 05:04:20 --> Security Class Initialized
DEBUG - 2023-11-02 05:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:04:20 --> Input Class Initialized
INFO - 2023-11-02 05:04:20 --> Language Class Initialized
INFO - 2023-11-02 05:04:20 --> Loader Class Initialized
INFO - 2023-11-02 05:04:20 --> Helper loaded: url_helper
INFO - 2023-11-02 05:04:20 --> Helper loaded: file_helper
INFO - 2023-11-02 05:04:20 --> Helper loaded: html_helper
INFO - 2023-11-02 05:04:20 --> Helper loaded: text_helper
INFO - 2023-11-02 05:04:20 --> Helper loaded: form_helper
INFO - 2023-11-02 05:04:20 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:04:20 --> Helper loaded: security_helper
INFO - 2023-11-02 05:04:20 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:04:20 --> Database Driver Class Initialized
INFO - 2023-11-02 05:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:04:20 --> Parser Class Initialized
INFO - 2023-11-02 05:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:04:20 --> Pagination Class Initialized
INFO - 2023-11-02 05:04:20 --> Form Validation Class Initialized
INFO - 2023-11-02 05:04:20 --> Controller Class Initialized
INFO - 2023-11-02 05:04:20 --> Model Class Initialized
DEBUG - 2023-11-02 05:04:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:25:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:25:38 --> Config Class Initialized
INFO - 2023-11-02 05:25:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:25:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:25:38 --> Utf8 Class Initialized
INFO - 2023-11-02 05:25:38 --> URI Class Initialized
DEBUG - 2023-11-02 05:25:38 --> No URI present. Default controller set.
INFO - 2023-11-02 05:25:38 --> Router Class Initialized
INFO - 2023-11-02 05:25:38 --> Output Class Initialized
INFO - 2023-11-02 05:25:38 --> Security Class Initialized
DEBUG - 2023-11-02 05:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:25:38 --> Input Class Initialized
INFO - 2023-11-02 05:25:38 --> Language Class Initialized
INFO - 2023-11-02 05:25:38 --> Loader Class Initialized
INFO - 2023-11-02 05:25:38 --> Helper loaded: url_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: file_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: html_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: text_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: form_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: security_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:25:38 --> Database Driver Class Initialized
INFO - 2023-11-02 05:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:25:38 --> Parser Class Initialized
INFO - 2023-11-02 05:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:25:38 --> Pagination Class Initialized
INFO - 2023-11-02 05:25:38 --> Form Validation Class Initialized
INFO - 2023-11-02 05:25:38 --> Controller Class Initialized
INFO - 2023-11-02 05:25:38 --> Model Class Initialized
DEBUG - 2023-11-02 05:25:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:25:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:25:38 --> Config Class Initialized
INFO - 2023-11-02 05:25:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:25:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:25:38 --> Utf8 Class Initialized
INFO - 2023-11-02 05:25:38 --> URI Class Initialized
INFO - 2023-11-02 05:25:38 --> Router Class Initialized
INFO - 2023-11-02 05:25:38 --> Output Class Initialized
INFO - 2023-11-02 05:25:38 --> Security Class Initialized
DEBUG - 2023-11-02 05:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:25:38 --> Input Class Initialized
INFO - 2023-11-02 05:25:38 --> Language Class Initialized
INFO - 2023-11-02 05:25:38 --> Loader Class Initialized
INFO - 2023-11-02 05:25:38 --> Helper loaded: url_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: file_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: html_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: text_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: form_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: security_helper
INFO - 2023-11-02 05:25:38 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:25:38 --> Database Driver Class Initialized
INFO - 2023-11-02 05:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:25:38 --> Parser Class Initialized
INFO - 2023-11-02 05:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:25:38 --> Pagination Class Initialized
INFO - 2023-11-02 05:25:38 --> Form Validation Class Initialized
INFO - 2023-11-02 05:25:38 --> Controller Class Initialized
INFO - 2023-11-02 05:25:38 --> Model Class Initialized
DEBUG - 2023-11-02 05:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:25:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 05:25:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:25:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 05:25:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 05:25:38 --> Model Class Initialized
INFO - 2023-11-02 05:25:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 05:25:38 --> Final output sent to browser
DEBUG - 2023-11-02 05:25:38 --> Total execution time: 0.0397
ERROR - 2023-11-02 05:28:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:28:50 --> Config Class Initialized
INFO - 2023-11-02 05:28:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:28:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:28:50 --> Utf8 Class Initialized
INFO - 2023-11-02 05:28:50 --> URI Class Initialized
DEBUG - 2023-11-02 05:28:50 --> No URI present. Default controller set.
INFO - 2023-11-02 05:28:50 --> Router Class Initialized
INFO - 2023-11-02 05:28:50 --> Output Class Initialized
INFO - 2023-11-02 05:28:50 --> Security Class Initialized
DEBUG - 2023-11-02 05:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:28:50 --> Input Class Initialized
INFO - 2023-11-02 05:28:50 --> Language Class Initialized
INFO - 2023-11-02 05:28:50 --> Loader Class Initialized
INFO - 2023-11-02 05:28:50 --> Helper loaded: url_helper
INFO - 2023-11-02 05:28:50 --> Helper loaded: file_helper
INFO - 2023-11-02 05:28:50 --> Helper loaded: html_helper
INFO - 2023-11-02 05:28:50 --> Helper loaded: text_helper
INFO - 2023-11-02 05:28:50 --> Helper loaded: form_helper
INFO - 2023-11-02 05:28:50 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:28:50 --> Helper loaded: security_helper
INFO - 2023-11-02 05:28:50 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:28:50 --> Database Driver Class Initialized
INFO - 2023-11-02 05:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:28:50 --> Parser Class Initialized
INFO - 2023-11-02 05:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:28:50 --> Pagination Class Initialized
INFO - 2023-11-02 05:28:50 --> Form Validation Class Initialized
INFO - 2023-11-02 05:28:50 --> Controller Class Initialized
INFO - 2023-11-02 05:28:50 --> Model Class Initialized
DEBUG - 2023-11-02 05:28:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:28:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:28:51 --> Config Class Initialized
INFO - 2023-11-02 05:28:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:28:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:28:51 --> Utf8 Class Initialized
INFO - 2023-11-02 05:28:51 --> URI Class Initialized
INFO - 2023-11-02 05:28:51 --> Router Class Initialized
INFO - 2023-11-02 05:28:51 --> Output Class Initialized
INFO - 2023-11-02 05:28:51 --> Security Class Initialized
DEBUG - 2023-11-02 05:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:28:51 --> Input Class Initialized
INFO - 2023-11-02 05:28:51 --> Language Class Initialized
INFO - 2023-11-02 05:28:51 --> Loader Class Initialized
INFO - 2023-11-02 05:28:51 --> Helper loaded: url_helper
INFO - 2023-11-02 05:28:51 --> Helper loaded: file_helper
INFO - 2023-11-02 05:28:51 --> Helper loaded: html_helper
INFO - 2023-11-02 05:28:51 --> Helper loaded: text_helper
INFO - 2023-11-02 05:28:51 --> Helper loaded: form_helper
INFO - 2023-11-02 05:28:51 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:28:51 --> Helper loaded: security_helper
INFO - 2023-11-02 05:28:51 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:28:51 --> Database Driver Class Initialized
INFO - 2023-11-02 05:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:28:51 --> Parser Class Initialized
INFO - 2023-11-02 05:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:28:51 --> Pagination Class Initialized
INFO - 2023-11-02 05:28:51 --> Form Validation Class Initialized
INFO - 2023-11-02 05:28:51 --> Controller Class Initialized
INFO - 2023-11-02 05:28:51 --> Model Class Initialized
DEBUG - 2023-11-02 05:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 05:28:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 05:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 05:28:51 --> Model Class Initialized
INFO - 2023-11-02 05:28:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 05:28:51 --> Final output sent to browser
DEBUG - 2023-11-02 05:28:51 --> Total execution time: 0.0405
ERROR - 2023-11-02 05:29:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:05 --> Config Class Initialized
INFO - 2023-11-02 05:29:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:05 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:05 --> URI Class Initialized
DEBUG - 2023-11-02 05:29:05 --> No URI present. Default controller set.
INFO - 2023-11-02 05:29:05 --> Router Class Initialized
INFO - 2023-11-02 05:29:05 --> Output Class Initialized
INFO - 2023-11-02 05:29:05 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:05 --> Input Class Initialized
INFO - 2023-11-02 05:29:05 --> Language Class Initialized
INFO - 2023-11-02 05:29:05 --> Loader Class Initialized
INFO - 2023-11-02 05:29:05 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:05 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:05 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:05 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:05 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:05 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:05 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:05 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:05 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:05 --> Parser Class Initialized
INFO - 2023-11-02 05:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:05 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:05 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:05 --> Controller Class Initialized
INFO - 2023-11-02 05:29:05 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:29:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:06 --> Config Class Initialized
INFO - 2023-11-02 05:29:06 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:06 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:06 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:06 --> URI Class Initialized
INFO - 2023-11-02 05:29:06 --> Router Class Initialized
INFO - 2023-11-02 05:29:06 --> Output Class Initialized
INFO - 2023-11-02 05:29:06 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:06 --> Input Class Initialized
INFO - 2023-11-02 05:29:06 --> Language Class Initialized
INFO - 2023-11-02 05:29:06 --> Loader Class Initialized
INFO - 2023-11-02 05:29:06 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:06 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:06 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:06 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:06 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:06 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:06 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:06 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:06 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:06 --> Parser Class Initialized
INFO - 2023-11-02 05:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:06 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:06 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:06 --> Controller Class Initialized
INFO - 2023-11-02 05:29:06 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 05:29:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 05:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 05:29:06 --> Model Class Initialized
INFO - 2023-11-02 05:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 05:29:06 --> Final output sent to browser
DEBUG - 2023-11-02 05:29:06 --> Total execution time: 0.0300
ERROR - 2023-11-02 05:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:09 --> Config Class Initialized
INFO - 2023-11-02 05:29:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:09 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:09 --> URI Class Initialized
DEBUG - 2023-11-02 05:29:09 --> No URI present. Default controller set.
INFO - 2023-11-02 05:29:09 --> Router Class Initialized
INFO - 2023-11-02 05:29:09 --> Output Class Initialized
INFO - 2023-11-02 05:29:09 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:09 --> Input Class Initialized
INFO - 2023-11-02 05:29:09 --> Language Class Initialized
INFO - 2023-11-02 05:29:09 --> Loader Class Initialized
INFO - 2023-11-02 05:29:09 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:09 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:09 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:09 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:09 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:09 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:09 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:09 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:09 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:09 --> Parser Class Initialized
INFO - 2023-11-02 05:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:09 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:09 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:09 --> Controller Class Initialized
INFO - 2023-11-02 05:29:09 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:10 --> Config Class Initialized
INFO - 2023-11-02 05:29:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:10 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:10 --> URI Class Initialized
INFO - 2023-11-02 05:29:10 --> Router Class Initialized
INFO - 2023-11-02 05:29:10 --> Output Class Initialized
INFO - 2023-11-02 05:29:10 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:10 --> Input Class Initialized
INFO - 2023-11-02 05:29:10 --> Language Class Initialized
INFO - 2023-11-02 05:29:10 --> Loader Class Initialized
INFO - 2023-11-02 05:29:10 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:10 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:10 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:10 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:10 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:10 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:10 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:10 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:10 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:10 --> Parser Class Initialized
INFO - 2023-11-02 05:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:10 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:10 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:10 --> Controller Class Initialized
INFO - 2023-11-02 05:29:10 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 05:29:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 05:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 05:29:10 --> Model Class Initialized
INFO - 2023-11-02 05:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 05:29:10 --> Final output sent to browser
DEBUG - 2023-11-02 05:29:10 --> Total execution time: 0.0285
ERROR - 2023-11-02 05:29:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:18 --> Config Class Initialized
INFO - 2023-11-02 05:29:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:18 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:18 --> URI Class Initialized
DEBUG - 2023-11-02 05:29:18 --> No URI present. Default controller set.
INFO - 2023-11-02 05:29:18 --> Router Class Initialized
INFO - 2023-11-02 05:29:18 --> Output Class Initialized
INFO - 2023-11-02 05:29:18 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:18 --> Input Class Initialized
INFO - 2023-11-02 05:29:18 --> Language Class Initialized
INFO - 2023-11-02 05:29:18 --> Loader Class Initialized
INFO - 2023-11-02 05:29:18 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:18 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:18 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:18 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:18 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:18 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:18 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:18 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:18 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:18 --> Parser Class Initialized
INFO - 2023-11-02 05:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:18 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:18 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:18 --> Controller Class Initialized
INFO - 2023-11-02 05:29:18 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:29:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:19 --> Config Class Initialized
INFO - 2023-11-02 05:29:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:19 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:19 --> URI Class Initialized
INFO - 2023-11-02 05:29:19 --> Router Class Initialized
INFO - 2023-11-02 05:29:19 --> Output Class Initialized
INFO - 2023-11-02 05:29:19 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:19 --> Input Class Initialized
INFO - 2023-11-02 05:29:19 --> Language Class Initialized
INFO - 2023-11-02 05:29:19 --> Loader Class Initialized
INFO - 2023-11-02 05:29:19 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:19 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:19 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:19 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:19 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:19 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:19 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:19 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:19 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:19 --> Parser Class Initialized
INFO - 2023-11-02 05:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:19 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:19 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:19 --> Controller Class Initialized
INFO - 2023-11-02 05:29:19 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 05:29:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 05:29:19 --> Model Class Initialized
INFO - 2023-11-02 05:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 05:29:19 --> Final output sent to browser
DEBUG - 2023-11-02 05:29:19 --> Total execution time: 0.0281
ERROR - 2023-11-02 05:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:30 --> Config Class Initialized
INFO - 2023-11-02 05:29:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:30 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:30 --> URI Class Initialized
DEBUG - 2023-11-02 05:29:30 --> No URI present. Default controller set.
INFO - 2023-11-02 05:29:30 --> Router Class Initialized
INFO - 2023-11-02 05:29:30 --> Output Class Initialized
INFO - 2023-11-02 05:29:30 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:30 --> Input Class Initialized
INFO - 2023-11-02 05:29:30 --> Language Class Initialized
INFO - 2023-11-02 05:29:30 --> Loader Class Initialized
INFO - 2023-11-02 05:29:30 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:30 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:30 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:30 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:30 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:30 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:30 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:30 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:30 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:30 --> Parser Class Initialized
INFO - 2023-11-02 05:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:30 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:30 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:30 --> Controller Class Initialized
INFO - 2023-11-02 05:29:30 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 05:29:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 05:29:31 --> Config Class Initialized
INFO - 2023-11-02 05:29:31 --> Hooks Class Initialized
DEBUG - 2023-11-02 05:29:31 --> UTF-8 Support Enabled
INFO - 2023-11-02 05:29:31 --> Utf8 Class Initialized
INFO - 2023-11-02 05:29:31 --> URI Class Initialized
INFO - 2023-11-02 05:29:31 --> Router Class Initialized
INFO - 2023-11-02 05:29:31 --> Output Class Initialized
INFO - 2023-11-02 05:29:31 --> Security Class Initialized
DEBUG - 2023-11-02 05:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 05:29:31 --> Input Class Initialized
INFO - 2023-11-02 05:29:31 --> Language Class Initialized
INFO - 2023-11-02 05:29:31 --> Loader Class Initialized
INFO - 2023-11-02 05:29:31 --> Helper loaded: url_helper
INFO - 2023-11-02 05:29:31 --> Helper loaded: file_helper
INFO - 2023-11-02 05:29:31 --> Helper loaded: html_helper
INFO - 2023-11-02 05:29:31 --> Helper loaded: text_helper
INFO - 2023-11-02 05:29:31 --> Helper loaded: form_helper
INFO - 2023-11-02 05:29:31 --> Helper loaded: lang_helper
INFO - 2023-11-02 05:29:31 --> Helper loaded: security_helper
INFO - 2023-11-02 05:29:31 --> Helper loaded: cookie_helper
INFO - 2023-11-02 05:29:31 --> Database Driver Class Initialized
INFO - 2023-11-02 05:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 05:29:31 --> Parser Class Initialized
INFO - 2023-11-02 05:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 05:29:31 --> Pagination Class Initialized
INFO - 2023-11-02 05:29:31 --> Form Validation Class Initialized
INFO - 2023-11-02 05:29:31 --> Controller Class Initialized
INFO - 2023-11-02 05:29:31 --> Model Class Initialized
DEBUG - 2023-11-02 05:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 05:29:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 05:29:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 05:29:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 05:29:31 --> Model Class Initialized
INFO - 2023-11-02 05:29:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 05:29:31 --> Final output sent to browser
DEBUG - 2023-11-02 05:29:31 --> Total execution time: 0.2402
ERROR - 2023-11-02 07:42:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 07:42:09 --> Config Class Initialized
INFO - 2023-11-02 07:42:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 07:42:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 07:42:09 --> Utf8 Class Initialized
INFO - 2023-11-02 07:42:09 --> URI Class Initialized
DEBUG - 2023-11-02 07:42:09 --> No URI present. Default controller set.
INFO - 2023-11-02 07:42:09 --> Router Class Initialized
INFO - 2023-11-02 07:42:09 --> Output Class Initialized
INFO - 2023-11-02 07:42:09 --> Security Class Initialized
DEBUG - 2023-11-02 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 07:42:09 --> Input Class Initialized
INFO - 2023-11-02 07:42:09 --> Language Class Initialized
INFO - 2023-11-02 07:42:09 --> Loader Class Initialized
INFO - 2023-11-02 07:42:09 --> Helper loaded: url_helper
INFO - 2023-11-02 07:42:09 --> Helper loaded: file_helper
INFO - 2023-11-02 07:42:09 --> Helper loaded: html_helper
INFO - 2023-11-02 07:42:09 --> Helper loaded: text_helper
INFO - 2023-11-02 07:42:09 --> Helper loaded: form_helper
INFO - 2023-11-02 07:42:09 --> Helper loaded: lang_helper
INFO - 2023-11-02 07:42:09 --> Helper loaded: security_helper
INFO - 2023-11-02 07:42:09 --> Helper loaded: cookie_helper
INFO - 2023-11-02 07:42:09 --> Database Driver Class Initialized
INFO - 2023-11-02 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 07:42:09 --> Parser Class Initialized
INFO - 2023-11-02 07:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 07:42:09 --> Pagination Class Initialized
INFO - 2023-11-02 07:42:09 --> Form Validation Class Initialized
INFO - 2023-11-02 07:42:09 --> Controller Class Initialized
INFO - 2023-11-02 07:42:09 --> Model Class Initialized
DEBUG - 2023-11-02 07:42:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 07:42:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 07:42:10 --> Config Class Initialized
INFO - 2023-11-02 07:42:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 07:42:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 07:42:10 --> Utf8 Class Initialized
INFO - 2023-11-02 07:42:10 --> URI Class Initialized
INFO - 2023-11-02 07:42:10 --> Router Class Initialized
INFO - 2023-11-02 07:42:10 --> Output Class Initialized
INFO - 2023-11-02 07:42:10 --> Security Class Initialized
DEBUG - 2023-11-02 07:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 07:42:10 --> Input Class Initialized
INFO - 2023-11-02 07:42:10 --> Language Class Initialized
INFO - 2023-11-02 07:42:10 --> Loader Class Initialized
INFO - 2023-11-02 07:42:10 --> Helper loaded: url_helper
INFO - 2023-11-02 07:42:10 --> Helper loaded: file_helper
INFO - 2023-11-02 07:42:10 --> Helper loaded: html_helper
INFO - 2023-11-02 07:42:10 --> Helper loaded: text_helper
INFO - 2023-11-02 07:42:10 --> Helper loaded: form_helper
INFO - 2023-11-02 07:42:10 --> Helper loaded: lang_helper
INFO - 2023-11-02 07:42:10 --> Helper loaded: security_helper
INFO - 2023-11-02 07:42:10 --> Helper loaded: cookie_helper
INFO - 2023-11-02 07:42:10 --> Database Driver Class Initialized
INFO - 2023-11-02 07:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 07:42:10 --> Parser Class Initialized
INFO - 2023-11-02 07:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 07:42:10 --> Pagination Class Initialized
INFO - 2023-11-02 07:42:10 --> Form Validation Class Initialized
INFO - 2023-11-02 07:42:10 --> Controller Class Initialized
INFO - 2023-11-02 07:42:10 --> Model Class Initialized
DEBUG - 2023-11-02 07:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 07:42:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 07:42:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 07:42:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 07:42:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 07:42:10 --> Model Class Initialized
INFO - 2023-11-02 07:42:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 07:42:10 --> Final output sent to browser
DEBUG - 2023-11-02 07:42:10 --> Total execution time: 0.0320
ERROR - 2023-11-02 07:43:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 07:43:10 --> Config Class Initialized
INFO - 2023-11-02 07:43:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 07:43:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 07:43:10 --> Utf8 Class Initialized
INFO - 2023-11-02 07:43:10 --> URI Class Initialized
DEBUG - 2023-11-02 07:43:10 --> No URI present. Default controller set.
INFO - 2023-11-02 07:43:10 --> Router Class Initialized
INFO - 2023-11-02 07:43:10 --> Output Class Initialized
INFO - 2023-11-02 07:43:10 --> Security Class Initialized
DEBUG - 2023-11-02 07:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 07:43:10 --> Input Class Initialized
INFO - 2023-11-02 07:43:10 --> Language Class Initialized
INFO - 2023-11-02 07:43:10 --> Loader Class Initialized
INFO - 2023-11-02 07:43:10 --> Helper loaded: url_helper
INFO - 2023-11-02 07:43:10 --> Helper loaded: file_helper
INFO - 2023-11-02 07:43:10 --> Helper loaded: html_helper
INFO - 2023-11-02 07:43:10 --> Helper loaded: text_helper
INFO - 2023-11-02 07:43:10 --> Helper loaded: form_helper
INFO - 2023-11-02 07:43:10 --> Helper loaded: lang_helper
INFO - 2023-11-02 07:43:10 --> Helper loaded: security_helper
INFO - 2023-11-02 07:43:10 --> Helper loaded: cookie_helper
INFO - 2023-11-02 07:43:10 --> Database Driver Class Initialized
INFO - 2023-11-02 07:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 07:43:10 --> Parser Class Initialized
INFO - 2023-11-02 07:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 07:43:10 --> Pagination Class Initialized
INFO - 2023-11-02 07:43:10 --> Form Validation Class Initialized
INFO - 2023-11-02 07:43:10 --> Controller Class Initialized
INFO - 2023-11-02 07:43:10 --> Model Class Initialized
DEBUG - 2023-11-02 07:43:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 07:43:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 07:43:11 --> Config Class Initialized
INFO - 2023-11-02 07:43:11 --> Hooks Class Initialized
DEBUG - 2023-11-02 07:43:11 --> UTF-8 Support Enabled
INFO - 2023-11-02 07:43:11 --> Utf8 Class Initialized
INFO - 2023-11-02 07:43:11 --> URI Class Initialized
INFO - 2023-11-02 07:43:11 --> Router Class Initialized
INFO - 2023-11-02 07:43:11 --> Output Class Initialized
INFO - 2023-11-02 07:43:11 --> Security Class Initialized
DEBUG - 2023-11-02 07:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 07:43:11 --> Input Class Initialized
INFO - 2023-11-02 07:43:11 --> Language Class Initialized
INFO - 2023-11-02 07:43:11 --> Loader Class Initialized
INFO - 2023-11-02 07:43:11 --> Helper loaded: url_helper
INFO - 2023-11-02 07:43:11 --> Helper loaded: file_helper
INFO - 2023-11-02 07:43:11 --> Helper loaded: html_helper
INFO - 2023-11-02 07:43:11 --> Helper loaded: text_helper
INFO - 2023-11-02 07:43:11 --> Helper loaded: form_helper
INFO - 2023-11-02 07:43:11 --> Helper loaded: lang_helper
INFO - 2023-11-02 07:43:11 --> Helper loaded: security_helper
INFO - 2023-11-02 07:43:11 --> Helper loaded: cookie_helper
INFO - 2023-11-02 07:43:11 --> Database Driver Class Initialized
INFO - 2023-11-02 07:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 07:43:11 --> Parser Class Initialized
INFO - 2023-11-02 07:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 07:43:11 --> Pagination Class Initialized
INFO - 2023-11-02 07:43:11 --> Form Validation Class Initialized
INFO - 2023-11-02 07:43:11 --> Controller Class Initialized
INFO - 2023-11-02 07:43:11 --> Model Class Initialized
DEBUG - 2023-11-02 07:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 07:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 07:43:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 07:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 07:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 07:43:11 --> Model Class Initialized
INFO - 2023-11-02 07:43:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 07:43:11 --> Final output sent to browser
DEBUG - 2023-11-02 07:43:11 --> Total execution time: 0.0351
ERROR - 2023-11-02 08:16:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:29 --> Config Class Initialized
INFO - 2023-11-02 08:16:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:29 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:29 --> URI Class Initialized
DEBUG - 2023-11-02 08:16:29 --> No URI present. Default controller set.
INFO - 2023-11-02 08:16:29 --> Router Class Initialized
INFO - 2023-11-02 08:16:29 --> Output Class Initialized
INFO - 2023-11-02 08:16:29 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:29 --> Input Class Initialized
INFO - 2023-11-02 08:16:29 --> Language Class Initialized
INFO - 2023-11-02 08:16:29 --> Loader Class Initialized
INFO - 2023-11-02 08:16:29 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:29 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:29 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:29 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:29 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:29 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:29 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:29 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:29 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:29 --> Parser Class Initialized
INFO - 2023-11-02 08:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:29 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:29 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:29 --> Controller Class Initialized
INFO - 2023-11-02 08:16:29 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 08:16:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:30 --> Config Class Initialized
INFO - 2023-11-02 08:16:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:30 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:30 --> URI Class Initialized
INFO - 2023-11-02 08:16:30 --> Router Class Initialized
INFO - 2023-11-02 08:16:30 --> Output Class Initialized
INFO - 2023-11-02 08:16:30 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:30 --> Input Class Initialized
INFO - 2023-11-02 08:16:30 --> Language Class Initialized
INFO - 2023-11-02 08:16:30 --> Loader Class Initialized
INFO - 2023-11-02 08:16:30 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:30 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:30 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:30 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:30 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:30 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:30 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:30 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:30 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:30 --> Parser Class Initialized
INFO - 2023-11-02 08:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:30 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:30 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:30 --> Controller Class Initialized
INFO - 2023-11-02 08:16:30 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 08:16:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:16:30 --> Model Class Initialized
INFO - 2023-11-02 08:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:16:30 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:30 --> Total execution time: 0.0371
ERROR - 2023-11-02 08:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:33 --> Config Class Initialized
INFO - 2023-11-02 08:16:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:33 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:33 --> URI Class Initialized
INFO - 2023-11-02 08:16:33 --> Router Class Initialized
INFO - 2023-11-02 08:16:33 --> Output Class Initialized
INFO - 2023-11-02 08:16:33 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:33 --> Input Class Initialized
INFO - 2023-11-02 08:16:33 --> Language Class Initialized
INFO - 2023-11-02 08:16:33 --> Loader Class Initialized
INFO - 2023-11-02 08:16:33 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:33 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:33 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:33 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:33 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:33 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:33 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:33 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:33 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:33 --> Parser Class Initialized
INFO - 2023-11-02 08:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:33 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:33 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:33 --> Controller Class Initialized
INFO - 2023-11-02 08:16:33 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:33 --> Model Class Initialized
INFO - 2023-11-02 08:16:33 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:33 --> Total execution time: 0.0190
ERROR - 2023-11-02 08:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:34 --> Config Class Initialized
INFO - 2023-11-02 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:34 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:34 --> URI Class Initialized
DEBUG - 2023-11-02 08:16:34 --> No URI present. Default controller set.
INFO - 2023-11-02 08:16:34 --> Router Class Initialized
INFO - 2023-11-02 08:16:34 --> Output Class Initialized
INFO - 2023-11-02 08:16:34 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:34 --> Input Class Initialized
INFO - 2023-11-02 08:16:34 --> Language Class Initialized
INFO - 2023-11-02 08:16:34 --> Loader Class Initialized
INFO - 2023-11-02 08:16:34 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:34 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:34 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:34 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:34 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:34 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:34 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:34 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:34 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:34 --> Parser Class Initialized
INFO - 2023-11-02 08:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:34 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:34 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:34 --> Controller Class Initialized
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
INFO - 2023-11-02 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-02 08:16:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:16:34 --> Model Class Initialized
INFO - 2023-11-02 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:16:34 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:34 --> Total execution time: 0.4137
ERROR - 2023-11-02 08:16:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:36 --> Config Class Initialized
INFO - 2023-11-02 08:16:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:36 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:36 --> URI Class Initialized
INFO - 2023-11-02 08:16:36 --> Router Class Initialized
INFO - 2023-11-02 08:16:36 --> Output Class Initialized
INFO - 2023-11-02 08:16:36 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:36 --> Input Class Initialized
INFO - 2023-11-02 08:16:36 --> Language Class Initialized
INFO - 2023-11-02 08:16:36 --> Loader Class Initialized
INFO - 2023-11-02 08:16:36 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:36 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:36 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:36 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:36 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:36 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:36 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:36 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:36 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:36 --> Parser Class Initialized
INFO - 2023-11-02 08:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:36 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:36 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:36 --> Controller Class Initialized
DEBUG - 2023-11-02 08:16:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:36 --> Model Class Initialized
INFO - 2023-11-02 08:16:36 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:36 --> Total execution time: 0.0146
ERROR - 2023-11-02 08:16:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:45 --> Config Class Initialized
INFO - 2023-11-02 08:16:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:45 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:45 --> URI Class Initialized
INFO - 2023-11-02 08:16:45 --> Router Class Initialized
INFO - 2023-11-02 08:16:45 --> Output Class Initialized
INFO - 2023-11-02 08:16:45 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:45 --> Input Class Initialized
INFO - 2023-11-02 08:16:45 --> Language Class Initialized
INFO - 2023-11-02 08:16:45 --> Loader Class Initialized
INFO - 2023-11-02 08:16:45 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:45 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:45 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:45 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:45 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:45 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:45 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:45 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:45 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:45 --> Parser Class Initialized
INFO - 2023-11-02 08:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:45 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:45 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:45 --> Controller Class Initialized
DEBUG - 2023-11-02 08:16:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:45 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:45 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:45 --> Model Class Initialized
INFO - 2023-11-02 08:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-11-02 08:16:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:16:45 --> Model Class Initialized
INFO - 2023-11-02 08:16:45 --> Model Class Initialized
INFO - 2023-11-02 08:16:45 --> Model Class Initialized
INFO - 2023-11-02 08:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:16:45 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:45 --> Total execution time: 0.1935
ERROR - 2023-11-02 08:16:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:46 --> Config Class Initialized
INFO - 2023-11-02 08:16:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:46 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:46 --> URI Class Initialized
INFO - 2023-11-02 08:16:46 --> Router Class Initialized
INFO - 2023-11-02 08:16:46 --> Output Class Initialized
INFO - 2023-11-02 08:16:46 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:46 --> Input Class Initialized
INFO - 2023-11-02 08:16:46 --> Language Class Initialized
INFO - 2023-11-02 08:16:46 --> Loader Class Initialized
INFO - 2023-11-02 08:16:46 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:46 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:46 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:46 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:46 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:46 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:46 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:46 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:46 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:46 --> Parser Class Initialized
INFO - 2023-11-02 08:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:46 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:46 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:46 --> Controller Class Initialized
DEBUG - 2023-11-02 08:16:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:46 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:46 --> Model Class Initialized
INFO - 2023-11-02 08:16:46 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:46 --> Total execution time: 0.0385
ERROR - 2023-11-02 08:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:52 --> Config Class Initialized
INFO - 2023-11-02 08:16:52 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:52 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:52 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:52 --> URI Class Initialized
INFO - 2023-11-02 08:16:52 --> Router Class Initialized
INFO - 2023-11-02 08:16:52 --> Output Class Initialized
INFO - 2023-11-02 08:16:52 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:52 --> Input Class Initialized
INFO - 2023-11-02 08:16:52 --> Language Class Initialized
INFO - 2023-11-02 08:16:52 --> Loader Class Initialized
INFO - 2023-11-02 08:16:52 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:52 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:52 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:52 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:52 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:52 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:52 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:52 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:52 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:52 --> Parser Class Initialized
INFO - 2023-11-02 08:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:52 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:52 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:52 --> Controller Class Initialized
INFO - 2023-11-02 08:16:52 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:52 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:52 --> Model Class Initialized
INFO - 2023-11-02 08:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-02 08:16:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:16:52 --> Model Class Initialized
INFO - 2023-11-02 08:16:52 --> Model Class Initialized
INFO - 2023-11-02 08:16:52 --> Model Class Initialized
INFO - 2023-11-02 08:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:16:53 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:53 --> Total execution time: 0.2074
ERROR - 2023-11-02 08:16:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:16:53 --> Config Class Initialized
INFO - 2023-11-02 08:16:53 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:16:53 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:16:53 --> Utf8 Class Initialized
INFO - 2023-11-02 08:16:53 --> URI Class Initialized
INFO - 2023-11-02 08:16:53 --> Router Class Initialized
INFO - 2023-11-02 08:16:53 --> Output Class Initialized
INFO - 2023-11-02 08:16:53 --> Security Class Initialized
DEBUG - 2023-11-02 08:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:16:53 --> Input Class Initialized
INFO - 2023-11-02 08:16:53 --> Language Class Initialized
INFO - 2023-11-02 08:16:53 --> Loader Class Initialized
INFO - 2023-11-02 08:16:53 --> Helper loaded: url_helper
INFO - 2023-11-02 08:16:53 --> Helper loaded: file_helper
INFO - 2023-11-02 08:16:53 --> Helper loaded: html_helper
INFO - 2023-11-02 08:16:53 --> Helper loaded: text_helper
INFO - 2023-11-02 08:16:53 --> Helper loaded: form_helper
INFO - 2023-11-02 08:16:53 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:16:53 --> Helper loaded: security_helper
INFO - 2023-11-02 08:16:53 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:16:53 --> Database Driver Class Initialized
INFO - 2023-11-02 08:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:16:53 --> Parser Class Initialized
INFO - 2023-11-02 08:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:16:53 --> Pagination Class Initialized
INFO - 2023-11-02 08:16:53 --> Form Validation Class Initialized
INFO - 2023-11-02 08:16:53 --> Controller Class Initialized
INFO - 2023-11-02 08:16:53 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:53 --> Model Class Initialized
DEBUG - 2023-11-02 08:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:16:53 --> Model Class Initialized
INFO - 2023-11-02 08:16:53 --> Final output sent to browser
DEBUG - 2023-11-02 08:16:53 --> Total execution time: 0.0522
ERROR - 2023-11-02 08:17:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:17:02 --> Config Class Initialized
INFO - 2023-11-02 08:17:02 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:17:02 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:17:02 --> Utf8 Class Initialized
INFO - 2023-11-02 08:17:02 --> URI Class Initialized
INFO - 2023-11-02 08:17:02 --> Router Class Initialized
INFO - 2023-11-02 08:17:02 --> Output Class Initialized
INFO - 2023-11-02 08:17:02 --> Security Class Initialized
DEBUG - 2023-11-02 08:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:17:02 --> Input Class Initialized
INFO - 2023-11-02 08:17:02 --> Language Class Initialized
INFO - 2023-11-02 08:17:02 --> Loader Class Initialized
INFO - 2023-11-02 08:17:02 --> Helper loaded: url_helper
INFO - 2023-11-02 08:17:02 --> Helper loaded: file_helper
INFO - 2023-11-02 08:17:02 --> Helper loaded: html_helper
INFO - 2023-11-02 08:17:02 --> Helper loaded: text_helper
INFO - 2023-11-02 08:17:02 --> Helper loaded: form_helper
INFO - 2023-11-02 08:17:02 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:17:02 --> Helper loaded: security_helper
INFO - 2023-11-02 08:17:02 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:17:02 --> Database Driver Class Initialized
INFO - 2023-11-02 08:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:17:02 --> Parser Class Initialized
INFO - 2023-11-02 08:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:17:02 --> Pagination Class Initialized
INFO - 2023-11-02 08:17:02 --> Form Validation Class Initialized
INFO - 2023-11-02 08:17:02 --> Controller Class Initialized
INFO - 2023-11-02 08:17:02 --> Model Class Initialized
DEBUG - 2023-11-02 08:17:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:17:02 --> Model Class Initialized
DEBUG - 2023-11-02 08:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:17:02 --> Model Class Initialized
DEBUG - 2023-11-02 08:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-11-02 08:17:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:17:02 --> Model Class Initialized
INFO - 2023-11-02 08:17:02 --> Model Class Initialized
INFO - 2023-11-02 08:17:02 --> Model Class Initialized
INFO - 2023-11-02 08:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:17:02 --> Final output sent to browser
DEBUG - 2023-11-02 08:17:02 --> Total execution time: 0.2006
ERROR - 2023-11-02 08:17:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:17:45 --> Config Class Initialized
INFO - 2023-11-02 08:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:17:45 --> Utf8 Class Initialized
INFO - 2023-11-02 08:17:45 --> URI Class Initialized
INFO - 2023-11-02 08:17:45 --> Router Class Initialized
INFO - 2023-11-02 08:17:45 --> Output Class Initialized
INFO - 2023-11-02 08:17:45 --> Security Class Initialized
DEBUG - 2023-11-02 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:17:45 --> Input Class Initialized
INFO - 2023-11-02 08:17:45 --> Language Class Initialized
INFO - 2023-11-02 08:17:45 --> Loader Class Initialized
INFO - 2023-11-02 08:17:45 --> Helper loaded: url_helper
INFO - 2023-11-02 08:17:45 --> Helper loaded: file_helper
INFO - 2023-11-02 08:17:45 --> Helper loaded: html_helper
INFO - 2023-11-02 08:17:45 --> Helper loaded: text_helper
INFO - 2023-11-02 08:17:45 --> Helper loaded: form_helper
INFO - 2023-11-02 08:17:45 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:17:45 --> Helper loaded: security_helper
INFO - 2023-11-02 08:17:45 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:17:45 --> Database Driver Class Initialized
INFO - 2023-11-02 08:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:17:45 --> Parser Class Initialized
INFO - 2023-11-02 08:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:17:45 --> Pagination Class Initialized
INFO - 2023-11-02 08:17:45 --> Form Validation Class Initialized
INFO - 2023-11-02 08:17:45 --> Controller Class Initialized
INFO - 2023-11-02 08:17:45 --> Model Class Initialized
INFO - 2023-11-02 08:17:45 --> Model Class Initialized
INFO - 2023-11-02 08:17:45 --> Model Class Initialized
INFO - 2023-11-02 08:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-11-02 08:17:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:17:45 --> Model Class Initialized
INFO - 2023-11-02 08:17:45 --> Model Class Initialized
INFO - 2023-11-02 08:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:17:45 --> Final output sent to browser
DEBUG - 2023-11-02 08:17:45 --> Total execution time: 0.2422
ERROR - 2023-11-02 08:17:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:17:47 --> Config Class Initialized
INFO - 2023-11-02 08:17:47 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:17:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:17:47 --> Utf8 Class Initialized
INFO - 2023-11-02 08:17:47 --> URI Class Initialized
INFO - 2023-11-02 08:17:47 --> Router Class Initialized
INFO - 2023-11-02 08:17:47 --> Output Class Initialized
INFO - 2023-11-02 08:17:47 --> Security Class Initialized
DEBUG - 2023-11-02 08:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:17:47 --> Input Class Initialized
INFO - 2023-11-02 08:17:47 --> Language Class Initialized
INFO - 2023-11-02 08:17:47 --> Loader Class Initialized
INFO - 2023-11-02 08:17:47 --> Helper loaded: url_helper
INFO - 2023-11-02 08:17:47 --> Helper loaded: file_helper
INFO - 2023-11-02 08:17:47 --> Helper loaded: html_helper
INFO - 2023-11-02 08:17:47 --> Helper loaded: text_helper
INFO - 2023-11-02 08:17:47 --> Helper loaded: form_helper
INFO - 2023-11-02 08:17:47 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:17:47 --> Helper loaded: security_helper
INFO - 2023-11-02 08:17:47 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:17:47 --> Database Driver Class Initialized
INFO - 2023-11-02 08:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:17:47 --> Parser Class Initialized
INFO - 2023-11-02 08:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:17:47 --> Pagination Class Initialized
INFO - 2023-11-02 08:17:47 --> Form Validation Class Initialized
INFO - 2023-11-02 08:17:47 --> Controller Class Initialized
INFO - 2023-11-02 08:17:47 --> Model Class Initialized
INFO - 2023-11-02 08:17:47 --> Model Class Initialized
INFO - 2023-11-02 08:17:47 --> Final output sent to browser
DEBUG - 2023-11-02 08:17:47 --> Total execution time: 0.0288
ERROR - 2023-11-02 08:17:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:17:50 --> Config Class Initialized
INFO - 2023-11-02 08:17:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:17:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:17:50 --> Utf8 Class Initialized
INFO - 2023-11-02 08:17:50 --> URI Class Initialized
INFO - 2023-11-02 08:17:50 --> Router Class Initialized
INFO - 2023-11-02 08:17:50 --> Output Class Initialized
INFO - 2023-11-02 08:17:50 --> Security Class Initialized
DEBUG - 2023-11-02 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:17:50 --> Input Class Initialized
INFO - 2023-11-02 08:17:50 --> Language Class Initialized
INFO - 2023-11-02 08:17:50 --> Loader Class Initialized
INFO - 2023-11-02 08:17:50 --> Helper loaded: url_helper
INFO - 2023-11-02 08:17:50 --> Helper loaded: file_helper
INFO - 2023-11-02 08:17:50 --> Helper loaded: html_helper
INFO - 2023-11-02 08:17:50 --> Helper loaded: text_helper
INFO - 2023-11-02 08:17:50 --> Helper loaded: form_helper
INFO - 2023-11-02 08:17:50 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:17:50 --> Helper loaded: security_helper
INFO - 2023-11-02 08:17:50 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:17:50 --> Database Driver Class Initialized
INFO - 2023-11-02 08:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:17:50 --> Parser Class Initialized
INFO - 2023-11-02 08:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:17:50 --> Pagination Class Initialized
INFO - 2023-11-02 08:17:50 --> Form Validation Class Initialized
INFO - 2023-11-02 08:17:50 --> Controller Class Initialized
INFO - 2023-11-02 08:17:50 --> Model Class Initialized
INFO - 2023-11-02 08:17:50 --> Model Class Initialized
INFO - 2023-11-02 08:17:50 --> Final output sent to browser
DEBUG - 2023-11-02 08:17:50 --> Total execution time: 0.0605
ERROR - 2023-11-02 08:19:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:19:25 --> Config Class Initialized
INFO - 2023-11-02 08:19:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:19:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:19:25 --> Utf8 Class Initialized
INFO - 2023-11-02 08:19:25 --> URI Class Initialized
INFO - 2023-11-02 08:19:25 --> Router Class Initialized
INFO - 2023-11-02 08:19:25 --> Output Class Initialized
INFO - 2023-11-02 08:19:25 --> Security Class Initialized
DEBUG - 2023-11-02 08:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:19:25 --> Input Class Initialized
INFO - 2023-11-02 08:19:25 --> Language Class Initialized
INFO - 2023-11-02 08:19:25 --> Loader Class Initialized
INFO - 2023-11-02 08:19:25 --> Helper loaded: url_helper
INFO - 2023-11-02 08:19:25 --> Helper loaded: file_helper
INFO - 2023-11-02 08:19:25 --> Helper loaded: html_helper
INFO - 2023-11-02 08:19:25 --> Helper loaded: text_helper
INFO - 2023-11-02 08:19:25 --> Helper loaded: form_helper
INFO - 2023-11-02 08:19:25 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:19:25 --> Helper loaded: security_helper
INFO - 2023-11-02 08:19:25 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:19:25 --> Database Driver Class Initialized
INFO - 2023-11-02 08:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:19:25 --> Parser Class Initialized
INFO - 2023-11-02 08:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:19:25 --> Pagination Class Initialized
INFO - 2023-11-02 08:19:25 --> Form Validation Class Initialized
INFO - 2023-11-02 08:19:25 --> Controller Class Initialized
DEBUG - 2023-11-02 08:19:25 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:25 --> Model Class Initialized
INFO - 2023-11-02 08:19:25 --> Model Class Initialized
INFO - 2023-11-02 08:19:25 --> Model Class Initialized
INFO - 2023-11-02 08:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-11-02 08:19:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:19:25 --> Model Class Initialized
INFO - 2023-11-02 08:19:25 --> Model Class Initialized
INFO - 2023-11-02 08:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:19:25 --> Final output sent to browser
DEBUG - 2023-11-02 08:19:25 --> Total execution time: 0.2420
ERROR - 2023-11-02 08:19:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:19:51 --> Config Class Initialized
INFO - 2023-11-02 08:19:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:19:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:19:51 --> Utf8 Class Initialized
INFO - 2023-11-02 08:19:51 --> URI Class Initialized
DEBUG - 2023-11-02 08:19:51 --> No URI present. Default controller set.
INFO - 2023-11-02 08:19:51 --> Router Class Initialized
INFO - 2023-11-02 08:19:51 --> Output Class Initialized
INFO - 2023-11-02 08:19:51 --> Security Class Initialized
DEBUG - 2023-11-02 08:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:19:51 --> Input Class Initialized
INFO - 2023-11-02 08:19:51 --> Language Class Initialized
INFO - 2023-11-02 08:19:51 --> Loader Class Initialized
INFO - 2023-11-02 08:19:51 --> Helper loaded: url_helper
INFO - 2023-11-02 08:19:51 --> Helper loaded: file_helper
INFO - 2023-11-02 08:19:51 --> Helper loaded: html_helper
INFO - 2023-11-02 08:19:51 --> Helper loaded: text_helper
INFO - 2023-11-02 08:19:51 --> Helper loaded: form_helper
INFO - 2023-11-02 08:19:51 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:19:51 --> Helper loaded: security_helper
INFO - 2023-11-02 08:19:51 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:19:51 --> Database Driver Class Initialized
INFO - 2023-11-02 08:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:19:51 --> Parser Class Initialized
INFO - 2023-11-02 08:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:19:51 --> Pagination Class Initialized
INFO - 2023-11-02 08:19:51 --> Form Validation Class Initialized
INFO - 2023-11-02 08:19:51 --> Controller Class Initialized
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
DEBUG - 2023-11-02 08:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
DEBUG - 2023-11-02 08:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
DEBUG - 2023-11-02 08:19:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
INFO - 2023-11-02 08:19:51 --> Model Class Initialized
INFO - 2023-11-02 08:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-02 08:19:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:19:52 --> Model Class Initialized
INFO - 2023-11-02 08:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:19:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:19:52 --> Final output sent to browser
DEBUG - 2023-11-02 08:19:52 --> Total execution time: 0.3641
ERROR - 2023-11-02 08:19:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:19:56 --> Config Class Initialized
INFO - 2023-11-02 08:19:56 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:19:56 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:19:56 --> Utf8 Class Initialized
INFO - 2023-11-02 08:19:56 --> URI Class Initialized
INFO - 2023-11-02 08:19:56 --> Router Class Initialized
INFO - 2023-11-02 08:19:56 --> Output Class Initialized
INFO - 2023-11-02 08:19:56 --> Security Class Initialized
DEBUG - 2023-11-02 08:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:19:56 --> Input Class Initialized
INFO - 2023-11-02 08:19:56 --> Language Class Initialized
INFO - 2023-11-02 08:19:56 --> Loader Class Initialized
INFO - 2023-11-02 08:19:56 --> Helper loaded: url_helper
INFO - 2023-11-02 08:19:56 --> Helper loaded: file_helper
INFO - 2023-11-02 08:19:56 --> Helper loaded: html_helper
INFO - 2023-11-02 08:19:56 --> Helper loaded: text_helper
INFO - 2023-11-02 08:19:56 --> Helper loaded: form_helper
INFO - 2023-11-02 08:19:56 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:19:56 --> Helper loaded: security_helper
INFO - 2023-11-02 08:19:56 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:19:56 --> Database Driver Class Initialized
INFO - 2023-11-02 08:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:19:56 --> Parser Class Initialized
INFO - 2023-11-02 08:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:19:56 --> Pagination Class Initialized
INFO - 2023-11-02 08:19:56 --> Form Validation Class Initialized
INFO - 2023-11-02 08:19:56 --> Controller Class Initialized
INFO - 2023-11-02 08:19:56 --> Model Class Initialized
DEBUG - 2023-11-02 08:19:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:56 --> Model Class Initialized
DEBUG - 2023-11-02 08:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:56 --> Model Class Initialized
INFO - 2023-11-02 08:19:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-11-02 08:19:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:19:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:19:56 --> Model Class Initialized
INFO - 2023-11-02 08:19:56 --> Model Class Initialized
INFO - 2023-11-02 08:19:56 --> Model Class Initialized
INFO - 2023-11-02 08:19:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:19:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:19:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:19:56 --> Final output sent to browser
DEBUG - 2023-11-02 08:19:56 --> Total execution time: 0.1950
ERROR - 2023-11-02 08:19:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:19:57 --> Config Class Initialized
INFO - 2023-11-02 08:19:57 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:19:57 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:19:57 --> Utf8 Class Initialized
INFO - 2023-11-02 08:19:57 --> URI Class Initialized
INFO - 2023-11-02 08:19:57 --> Router Class Initialized
INFO - 2023-11-02 08:19:57 --> Output Class Initialized
INFO - 2023-11-02 08:19:57 --> Security Class Initialized
DEBUG - 2023-11-02 08:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:19:57 --> Input Class Initialized
INFO - 2023-11-02 08:19:57 --> Language Class Initialized
INFO - 2023-11-02 08:19:57 --> Loader Class Initialized
INFO - 2023-11-02 08:19:57 --> Helper loaded: url_helper
INFO - 2023-11-02 08:19:57 --> Helper loaded: file_helper
INFO - 2023-11-02 08:19:57 --> Helper loaded: html_helper
INFO - 2023-11-02 08:19:57 --> Helper loaded: text_helper
INFO - 2023-11-02 08:19:57 --> Helper loaded: form_helper
INFO - 2023-11-02 08:19:57 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:19:57 --> Helper loaded: security_helper
INFO - 2023-11-02 08:19:57 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:19:57 --> Database Driver Class Initialized
INFO - 2023-11-02 08:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:19:57 --> Parser Class Initialized
INFO - 2023-11-02 08:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:19:57 --> Pagination Class Initialized
INFO - 2023-11-02 08:19:57 --> Form Validation Class Initialized
INFO - 2023-11-02 08:19:57 --> Controller Class Initialized
INFO - 2023-11-02 08:19:57 --> Model Class Initialized
DEBUG - 2023-11-02 08:19:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:19:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:57 --> Model Class Initialized
DEBUG - 2023-11-02 08:19:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:19:57 --> Model Class Initialized
INFO - 2023-11-02 08:19:57 --> Final output sent to browser
DEBUG - 2023-11-02 08:19:57 --> Total execution time: 0.0464
ERROR - 2023-11-02 08:20:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:20:01 --> Config Class Initialized
INFO - 2023-11-02 08:20:01 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:20:01 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:20:01 --> Utf8 Class Initialized
INFO - 2023-11-02 08:20:01 --> URI Class Initialized
INFO - 2023-11-02 08:20:01 --> Router Class Initialized
INFO - 2023-11-02 08:20:01 --> Output Class Initialized
INFO - 2023-11-02 08:20:01 --> Security Class Initialized
DEBUG - 2023-11-02 08:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:20:01 --> Input Class Initialized
INFO - 2023-11-02 08:20:01 --> Language Class Initialized
INFO - 2023-11-02 08:20:01 --> Loader Class Initialized
INFO - 2023-11-02 08:20:01 --> Helper loaded: url_helper
INFO - 2023-11-02 08:20:01 --> Helper loaded: file_helper
INFO - 2023-11-02 08:20:01 --> Helper loaded: html_helper
INFO - 2023-11-02 08:20:01 --> Helper loaded: text_helper
INFO - 2023-11-02 08:20:01 --> Helper loaded: form_helper
INFO - 2023-11-02 08:20:01 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:20:01 --> Helper loaded: security_helper
INFO - 2023-11-02 08:20:01 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:20:01 --> Database Driver Class Initialized
INFO - 2023-11-02 08:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:20:01 --> Parser Class Initialized
INFO - 2023-11-02 08:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:20:01 --> Pagination Class Initialized
INFO - 2023-11-02 08:20:01 --> Form Validation Class Initialized
INFO - 2023-11-02 08:20:01 --> Controller Class Initialized
INFO - 2023-11-02 08:20:01 --> Model Class Initialized
DEBUG - 2023-11-02 08:20:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:20:01 --> Model Class Initialized
DEBUG - 2023-11-02 08:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:20:01 --> Model Class Initialized
INFO - 2023-11-02 08:20:01 --> Final output sent to browser
DEBUG - 2023-11-02 08:20:01 --> Total execution time: 0.1619
ERROR - 2023-11-02 08:21:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:21:05 --> Config Class Initialized
INFO - 2023-11-02 08:21:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:21:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:21:05 --> Utf8 Class Initialized
INFO - 2023-11-02 08:21:05 --> URI Class Initialized
INFO - 2023-11-02 08:21:05 --> Router Class Initialized
INFO - 2023-11-02 08:21:05 --> Output Class Initialized
INFO - 2023-11-02 08:21:05 --> Security Class Initialized
DEBUG - 2023-11-02 08:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:21:05 --> Input Class Initialized
INFO - 2023-11-02 08:21:05 --> Language Class Initialized
INFO - 2023-11-02 08:21:05 --> Loader Class Initialized
INFO - 2023-11-02 08:21:05 --> Helper loaded: url_helper
INFO - 2023-11-02 08:21:05 --> Helper loaded: file_helper
INFO - 2023-11-02 08:21:05 --> Helper loaded: html_helper
INFO - 2023-11-02 08:21:05 --> Helper loaded: text_helper
INFO - 2023-11-02 08:21:05 --> Helper loaded: form_helper
INFO - 2023-11-02 08:21:05 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:21:05 --> Helper loaded: security_helper
INFO - 2023-11-02 08:21:05 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:21:05 --> Database Driver Class Initialized
INFO - 2023-11-02 08:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:21:05 --> Parser Class Initialized
INFO - 2023-11-02 08:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:21:05 --> Pagination Class Initialized
INFO - 2023-11-02 08:21:05 --> Form Validation Class Initialized
INFO - 2023-11-02 08:21:05 --> Controller Class Initialized
INFO - 2023-11-02 08:21:05 --> Model Class Initialized
DEBUG - 2023-11-02 08:21:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:21:05 --> Model Class Initialized
DEBUG - 2023-11-02 08:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:21:05 --> Model Class Initialized
INFO - 2023-11-02 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-11-02 08:21:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 08:21:05 --> Model Class Initialized
INFO - 2023-11-02 08:21:05 --> Model Class Initialized
INFO - 2023-11-02 08:21:05 --> Model Class Initialized
INFO - 2023-11-02 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 08:21:05 --> Final output sent to browser
DEBUG - 2023-11-02 08:21:05 --> Total execution time: 0.2109
ERROR - 2023-11-02 08:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:21:06 --> Config Class Initialized
INFO - 2023-11-02 08:21:06 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:21:06 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:21:06 --> Utf8 Class Initialized
INFO - 2023-11-02 08:21:06 --> URI Class Initialized
INFO - 2023-11-02 08:21:06 --> Router Class Initialized
INFO - 2023-11-02 08:21:06 --> Output Class Initialized
INFO - 2023-11-02 08:21:06 --> Security Class Initialized
DEBUG - 2023-11-02 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:21:06 --> Input Class Initialized
INFO - 2023-11-02 08:21:06 --> Language Class Initialized
INFO - 2023-11-02 08:21:06 --> Loader Class Initialized
INFO - 2023-11-02 08:21:06 --> Helper loaded: url_helper
INFO - 2023-11-02 08:21:06 --> Helper loaded: file_helper
INFO - 2023-11-02 08:21:06 --> Helper loaded: html_helper
INFO - 2023-11-02 08:21:06 --> Helper loaded: text_helper
INFO - 2023-11-02 08:21:06 --> Helper loaded: form_helper
INFO - 2023-11-02 08:21:06 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:21:06 --> Helper loaded: security_helper
INFO - 2023-11-02 08:21:06 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:21:06 --> Database Driver Class Initialized
INFO - 2023-11-02 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:21:06 --> Parser Class Initialized
INFO - 2023-11-02 08:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:21:06 --> Pagination Class Initialized
INFO - 2023-11-02 08:21:06 --> Form Validation Class Initialized
INFO - 2023-11-02 08:21:06 --> Controller Class Initialized
INFO - 2023-11-02 08:21:06 --> Model Class Initialized
DEBUG - 2023-11-02 08:21:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:21:06 --> Model Class Initialized
DEBUG - 2023-11-02 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:21:06 --> Model Class Initialized
INFO - 2023-11-02 08:21:06 --> Final output sent to browser
DEBUG - 2023-11-02 08:21:06 --> Total execution time: 0.0466
ERROR - 2023-11-02 08:21:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 08:21:12 --> Config Class Initialized
INFO - 2023-11-02 08:21:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:21:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:21:12 --> Utf8 Class Initialized
INFO - 2023-11-02 08:21:12 --> URI Class Initialized
INFO - 2023-11-02 08:21:12 --> Router Class Initialized
INFO - 2023-11-02 08:21:12 --> Output Class Initialized
INFO - 2023-11-02 08:21:12 --> Security Class Initialized
DEBUG - 2023-11-02 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:21:12 --> Input Class Initialized
INFO - 2023-11-02 08:21:12 --> Language Class Initialized
INFO - 2023-11-02 08:21:12 --> Loader Class Initialized
INFO - 2023-11-02 08:21:12 --> Helper loaded: url_helper
INFO - 2023-11-02 08:21:12 --> Helper loaded: file_helper
INFO - 2023-11-02 08:21:12 --> Helper loaded: html_helper
INFO - 2023-11-02 08:21:12 --> Helper loaded: text_helper
INFO - 2023-11-02 08:21:12 --> Helper loaded: form_helper
INFO - 2023-11-02 08:21:12 --> Helper loaded: lang_helper
INFO - 2023-11-02 08:21:12 --> Helper loaded: security_helper
INFO - 2023-11-02 08:21:12 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:21:12 --> Database Driver Class Initialized
INFO - 2023-11-02 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:21:12 --> Parser Class Initialized
INFO - 2023-11-02 08:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 08:21:12 --> Pagination Class Initialized
INFO - 2023-11-02 08:21:12 --> Form Validation Class Initialized
INFO - 2023-11-02 08:21:12 --> Controller Class Initialized
INFO - 2023-11-02 08:21:12 --> Model Class Initialized
DEBUG - 2023-11-02 08:21:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 08:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:21:12 --> Model Class Initialized
DEBUG - 2023-11-02 08:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 08:21:12 --> Model Class Initialized
INFO - 2023-11-02 08:21:12 --> Final output sent to browser
DEBUG - 2023-11-02 08:21:12 --> Total execution time: 0.1537
ERROR - 2023-11-02 10:23:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 10:23:28 --> Config Class Initialized
INFO - 2023-11-02 10:23:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:23:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:23:28 --> Utf8 Class Initialized
INFO - 2023-11-02 10:23:28 --> URI Class Initialized
DEBUG - 2023-11-02 10:23:28 --> No URI present. Default controller set.
INFO - 2023-11-02 10:23:28 --> Router Class Initialized
INFO - 2023-11-02 10:23:28 --> Output Class Initialized
INFO - 2023-11-02 10:23:28 --> Security Class Initialized
DEBUG - 2023-11-02 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:23:28 --> Input Class Initialized
INFO - 2023-11-02 10:23:28 --> Language Class Initialized
INFO - 2023-11-02 10:23:28 --> Loader Class Initialized
INFO - 2023-11-02 10:23:28 --> Helper loaded: url_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: file_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: html_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: text_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: form_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: lang_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: security_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: cookie_helper
INFO - 2023-11-02 10:23:28 --> Database Driver Class Initialized
INFO - 2023-11-02 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:23:28 --> Parser Class Initialized
INFO - 2023-11-02 10:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 10:23:28 --> Pagination Class Initialized
INFO - 2023-11-02 10:23:28 --> Form Validation Class Initialized
INFO - 2023-11-02 10:23:28 --> Controller Class Initialized
INFO - 2023-11-02 10:23:28 --> Model Class Initialized
DEBUG - 2023-11-02 10:23:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 10:23:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 10:23:28 --> Config Class Initialized
INFO - 2023-11-02 10:23:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:23:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:23:28 --> Utf8 Class Initialized
INFO - 2023-11-02 10:23:28 --> URI Class Initialized
INFO - 2023-11-02 10:23:28 --> Router Class Initialized
INFO - 2023-11-02 10:23:28 --> Output Class Initialized
INFO - 2023-11-02 10:23:28 --> Security Class Initialized
DEBUG - 2023-11-02 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:23:28 --> Input Class Initialized
INFO - 2023-11-02 10:23:28 --> Language Class Initialized
INFO - 2023-11-02 10:23:28 --> Loader Class Initialized
INFO - 2023-11-02 10:23:28 --> Helper loaded: url_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: file_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: html_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: text_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: form_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: lang_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: security_helper
INFO - 2023-11-02 10:23:28 --> Helper loaded: cookie_helper
INFO - 2023-11-02 10:23:28 --> Database Driver Class Initialized
INFO - 2023-11-02 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:23:28 --> Parser Class Initialized
INFO - 2023-11-02 10:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 10:23:28 --> Pagination Class Initialized
INFO - 2023-11-02 10:23:28 --> Form Validation Class Initialized
INFO - 2023-11-02 10:23:28 --> Controller Class Initialized
INFO - 2023-11-02 10:23:28 --> Model Class Initialized
DEBUG - 2023-11-02 10:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:23:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 10:23:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:23:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 10:23:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 10:23:28 --> Model Class Initialized
INFO - 2023-11-02 10:23:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 10:23:28 --> Final output sent to browser
DEBUG - 2023-11-02 10:23:28 --> Total execution time: 0.0353
ERROR - 2023-11-02 10:49:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 10:49:22 --> Config Class Initialized
INFO - 2023-11-02 10:49:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:49:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:49:22 --> Utf8 Class Initialized
INFO - 2023-11-02 10:49:22 --> URI Class Initialized
DEBUG - 2023-11-02 10:49:22 --> No URI present. Default controller set.
INFO - 2023-11-02 10:49:22 --> Router Class Initialized
INFO - 2023-11-02 10:49:22 --> Output Class Initialized
INFO - 2023-11-02 10:49:22 --> Security Class Initialized
DEBUG - 2023-11-02 10:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:49:22 --> Input Class Initialized
INFO - 2023-11-02 10:49:22 --> Language Class Initialized
INFO - 2023-11-02 10:49:22 --> Loader Class Initialized
INFO - 2023-11-02 10:49:22 --> Helper loaded: url_helper
INFO - 2023-11-02 10:49:22 --> Helper loaded: file_helper
INFO - 2023-11-02 10:49:22 --> Helper loaded: html_helper
INFO - 2023-11-02 10:49:22 --> Helper loaded: text_helper
INFO - 2023-11-02 10:49:22 --> Helper loaded: form_helper
INFO - 2023-11-02 10:49:22 --> Helper loaded: lang_helper
INFO - 2023-11-02 10:49:22 --> Helper loaded: security_helper
INFO - 2023-11-02 10:49:22 --> Helper loaded: cookie_helper
INFO - 2023-11-02 10:49:22 --> Database Driver Class Initialized
INFO - 2023-11-02 10:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:49:22 --> Parser Class Initialized
INFO - 2023-11-02 10:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 10:49:22 --> Pagination Class Initialized
INFO - 2023-11-02 10:49:22 --> Form Validation Class Initialized
INFO - 2023-11-02 10:49:22 --> Controller Class Initialized
INFO - 2023-11-02 10:49:22 --> Model Class Initialized
DEBUG - 2023-11-02 10:49:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 10:49:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 10:49:23 --> Config Class Initialized
INFO - 2023-11-02 10:49:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:49:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:49:23 --> Utf8 Class Initialized
INFO - 2023-11-02 10:49:23 --> URI Class Initialized
INFO - 2023-11-02 10:49:23 --> Router Class Initialized
INFO - 2023-11-02 10:49:23 --> Output Class Initialized
INFO - 2023-11-02 10:49:23 --> Security Class Initialized
DEBUG - 2023-11-02 10:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:49:23 --> Input Class Initialized
INFO - 2023-11-02 10:49:23 --> Language Class Initialized
INFO - 2023-11-02 10:49:23 --> Loader Class Initialized
INFO - 2023-11-02 10:49:23 --> Helper loaded: url_helper
INFO - 2023-11-02 10:49:23 --> Helper loaded: file_helper
INFO - 2023-11-02 10:49:23 --> Helper loaded: html_helper
INFO - 2023-11-02 10:49:23 --> Helper loaded: text_helper
INFO - 2023-11-02 10:49:23 --> Helper loaded: form_helper
INFO - 2023-11-02 10:49:23 --> Helper loaded: lang_helper
INFO - 2023-11-02 10:49:23 --> Helper loaded: security_helper
INFO - 2023-11-02 10:49:23 --> Helper loaded: cookie_helper
INFO - 2023-11-02 10:49:23 --> Database Driver Class Initialized
INFO - 2023-11-02 10:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:49:23 --> Parser Class Initialized
INFO - 2023-11-02 10:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 10:49:23 --> Pagination Class Initialized
INFO - 2023-11-02 10:49:23 --> Form Validation Class Initialized
INFO - 2023-11-02 10:49:23 --> Controller Class Initialized
INFO - 2023-11-02 10:49:23 --> Model Class Initialized
DEBUG - 2023-11-02 10:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 10:49:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 10:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 10:49:23 --> Model Class Initialized
INFO - 2023-11-02 10:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 10:49:23 --> Final output sent to browser
DEBUG - 2023-11-02 10:49:23 --> Total execution time: 0.0303
ERROR - 2023-11-02 12:35:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:35:38 --> Config Class Initialized
INFO - 2023-11-02 12:35:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:35:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:35:38 --> Utf8 Class Initialized
INFO - 2023-11-02 12:35:38 --> URI Class Initialized
DEBUG - 2023-11-02 12:35:38 --> No URI present. Default controller set.
INFO - 2023-11-02 12:35:38 --> Router Class Initialized
INFO - 2023-11-02 12:35:38 --> Output Class Initialized
INFO - 2023-11-02 12:35:38 --> Security Class Initialized
DEBUG - 2023-11-02 12:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:35:38 --> Input Class Initialized
INFO - 2023-11-02 12:35:38 --> Language Class Initialized
INFO - 2023-11-02 12:35:38 --> Loader Class Initialized
INFO - 2023-11-02 12:35:38 --> Helper loaded: url_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: file_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: html_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: text_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: form_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: lang_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: security_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: cookie_helper
INFO - 2023-11-02 12:35:38 --> Database Driver Class Initialized
INFO - 2023-11-02 12:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:35:38 --> Parser Class Initialized
INFO - 2023-11-02 12:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 12:35:38 --> Pagination Class Initialized
INFO - 2023-11-02 12:35:38 --> Form Validation Class Initialized
INFO - 2023-11-02 12:35:38 --> Controller Class Initialized
INFO - 2023-11-02 12:35:38 --> Model Class Initialized
DEBUG - 2023-11-02 12:35:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 12:35:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:35:38 --> Config Class Initialized
INFO - 2023-11-02 12:35:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:35:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:35:38 --> Utf8 Class Initialized
INFO - 2023-11-02 12:35:38 --> URI Class Initialized
INFO - 2023-11-02 12:35:38 --> Router Class Initialized
INFO - 2023-11-02 12:35:38 --> Output Class Initialized
INFO - 2023-11-02 12:35:38 --> Security Class Initialized
DEBUG - 2023-11-02 12:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:35:38 --> Input Class Initialized
INFO - 2023-11-02 12:35:38 --> Language Class Initialized
INFO - 2023-11-02 12:35:38 --> Loader Class Initialized
INFO - 2023-11-02 12:35:38 --> Helper loaded: url_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: file_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: html_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: text_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: form_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: lang_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: security_helper
INFO - 2023-11-02 12:35:38 --> Helper loaded: cookie_helper
INFO - 2023-11-02 12:35:38 --> Database Driver Class Initialized
INFO - 2023-11-02 12:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:35:38 --> Parser Class Initialized
INFO - 2023-11-02 12:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 12:35:38 --> Pagination Class Initialized
INFO - 2023-11-02 12:35:38 --> Form Validation Class Initialized
INFO - 2023-11-02 12:35:38 --> Controller Class Initialized
INFO - 2023-11-02 12:35:38 --> Model Class Initialized
DEBUG - 2023-11-02 12:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:35:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 12:35:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:35:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 12:35:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 12:35:38 --> Model Class Initialized
INFO - 2023-11-02 12:35:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 12:35:38 --> Final output sent to browser
DEBUG - 2023-11-02 12:35:38 --> Total execution time: 0.0352
ERROR - 2023-11-02 12:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:38:14 --> Config Class Initialized
INFO - 2023-11-02 12:38:14 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:38:14 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:38:14 --> Utf8 Class Initialized
INFO - 2023-11-02 12:38:14 --> URI Class Initialized
DEBUG - 2023-11-02 12:38:14 --> No URI present. Default controller set.
INFO - 2023-11-02 12:38:14 --> Router Class Initialized
INFO - 2023-11-02 12:38:14 --> Output Class Initialized
INFO - 2023-11-02 12:38:14 --> Security Class Initialized
DEBUG - 2023-11-02 12:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:38:14 --> Input Class Initialized
INFO - 2023-11-02 12:38:14 --> Language Class Initialized
INFO - 2023-11-02 12:38:14 --> Loader Class Initialized
INFO - 2023-11-02 12:38:14 --> Helper loaded: url_helper
INFO - 2023-11-02 12:38:14 --> Helper loaded: file_helper
INFO - 2023-11-02 12:38:14 --> Helper loaded: html_helper
INFO - 2023-11-02 12:38:14 --> Helper loaded: text_helper
INFO - 2023-11-02 12:38:14 --> Helper loaded: form_helper
INFO - 2023-11-02 12:38:14 --> Helper loaded: lang_helper
INFO - 2023-11-02 12:38:14 --> Helper loaded: security_helper
INFO - 2023-11-02 12:38:14 --> Helper loaded: cookie_helper
INFO - 2023-11-02 12:38:14 --> Database Driver Class Initialized
INFO - 2023-11-02 12:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:38:14 --> Parser Class Initialized
INFO - 2023-11-02 12:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 12:38:14 --> Pagination Class Initialized
INFO - 2023-11-02 12:38:14 --> Form Validation Class Initialized
INFO - 2023-11-02 12:38:14 --> Controller Class Initialized
INFO - 2023-11-02 12:38:14 --> Model Class Initialized
DEBUG - 2023-11-02 12:38:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 15:45:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 15:45:59 --> Config Class Initialized
INFO - 2023-11-02 15:45:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 15:45:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 15:45:59 --> Utf8 Class Initialized
INFO - 2023-11-02 15:45:59 --> URI Class Initialized
DEBUG - 2023-11-02 15:45:59 --> No URI present. Default controller set.
INFO - 2023-11-02 15:45:59 --> Router Class Initialized
INFO - 2023-11-02 15:45:59 --> Output Class Initialized
INFO - 2023-11-02 15:45:59 --> Security Class Initialized
DEBUG - 2023-11-02 15:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 15:45:59 --> Input Class Initialized
INFO - 2023-11-02 15:45:59 --> Language Class Initialized
INFO - 2023-11-02 15:45:59 --> Loader Class Initialized
INFO - 2023-11-02 15:45:59 --> Helper loaded: url_helper
INFO - 2023-11-02 15:45:59 --> Helper loaded: file_helper
INFO - 2023-11-02 15:45:59 --> Helper loaded: html_helper
INFO - 2023-11-02 15:45:59 --> Helper loaded: text_helper
INFO - 2023-11-02 15:45:59 --> Helper loaded: form_helper
INFO - 2023-11-02 15:45:59 --> Helper loaded: lang_helper
INFO - 2023-11-02 15:45:59 --> Helper loaded: security_helper
INFO - 2023-11-02 15:45:59 --> Helper loaded: cookie_helper
INFO - 2023-11-02 15:45:59 --> Database Driver Class Initialized
INFO - 2023-11-02 15:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 15:45:59 --> Parser Class Initialized
INFO - 2023-11-02 15:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 15:45:59 --> Pagination Class Initialized
INFO - 2023-11-02 15:45:59 --> Form Validation Class Initialized
INFO - 2023-11-02 15:45:59 --> Controller Class Initialized
INFO - 2023-11-02 15:45:59 --> Model Class Initialized
DEBUG - 2023-11-02 15:45:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-02 15:46:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 15:46:00 --> Config Class Initialized
INFO - 2023-11-02 15:46:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 15:46:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 15:46:00 --> Utf8 Class Initialized
INFO - 2023-11-02 15:46:00 --> URI Class Initialized
INFO - 2023-11-02 15:46:00 --> Router Class Initialized
INFO - 2023-11-02 15:46:00 --> Output Class Initialized
INFO - 2023-11-02 15:46:00 --> Security Class Initialized
DEBUG - 2023-11-02 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 15:46:00 --> Input Class Initialized
INFO - 2023-11-02 15:46:00 --> Language Class Initialized
INFO - 2023-11-02 15:46:00 --> Loader Class Initialized
INFO - 2023-11-02 15:46:00 --> Helper loaded: url_helper
INFO - 2023-11-02 15:46:00 --> Helper loaded: file_helper
INFO - 2023-11-02 15:46:00 --> Helper loaded: html_helper
INFO - 2023-11-02 15:46:00 --> Helper loaded: text_helper
INFO - 2023-11-02 15:46:00 --> Helper loaded: form_helper
INFO - 2023-11-02 15:46:00 --> Helper loaded: lang_helper
INFO - 2023-11-02 15:46:00 --> Helper loaded: security_helper
INFO - 2023-11-02 15:46:00 --> Helper loaded: cookie_helper
INFO - 2023-11-02 15:46:00 --> Database Driver Class Initialized
INFO - 2023-11-02 15:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 15:46:00 --> Parser Class Initialized
INFO - 2023-11-02 15:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 15:46:00 --> Pagination Class Initialized
INFO - 2023-11-02 15:46:00 --> Form Validation Class Initialized
INFO - 2023-11-02 15:46:00 --> Controller Class Initialized
INFO - 2023-11-02 15:46:00 --> Model Class Initialized
DEBUG - 2023-11-02 15:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-02 15:46:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 15:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 15:46:00 --> Model Class Initialized
INFO - 2023-11-02 15:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 15:46:00 --> Final output sent to browser
DEBUG - 2023-11-02 15:46:00 --> Total execution time: 0.0316
ERROR - 2023-11-02 15:46:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 15:46:03 --> Config Class Initialized
INFO - 2023-11-02 15:46:03 --> Hooks Class Initialized
DEBUG - 2023-11-02 15:46:03 --> UTF-8 Support Enabled
INFO - 2023-11-02 15:46:03 --> Utf8 Class Initialized
INFO - 2023-11-02 15:46:03 --> URI Class Initialized
INFO - 2023-11-02 15:46:03 --> Router Class Initialized
INFO - 2023-11-02 15:46:03 --> Output Class Initialized
INFO - 2023-11-02 15:46:03 --> Security Class Initialized
DEBUG - 2023-11-02 15:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 15:46:03 --> Input Class Initialized
INFO - 2023-11-02 15:46:03 --> Language Class Initialized
INFO - 2023-11-02 15:46:03 --> Loader Class Initialized
INFO - 2023-11-02 15:46:03 --> Helper loaded: url_helper
INFO - 2023-11-02 15:46:03 --> Helper loaded: file_helper
INFO - 2023-11-02 15:46:03 --> Helper loaded: html_helper
INFO - 2023-11-02 15:46:03 --> Helper loaded: text_helper
INFO - 2023-11-02 15:46:03 --> Helper loaded: form_helper
INFO - 2023-11-02 15:46:03 --> Helper loaded: lang_helper
INFO - 2023-11-02 15:46:03 --> Helper loaded: security_helper
INFO - 2023-11-02 15:46:03 --> Helper loaded: cookie_helper
INFO - 2023-11-02 15:46:03 --> Database Driver Class Initialized
INFO - 2023-11-02 15:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 15:46:03 --> Parser Class Initialized
INFO - 2023-11-02 15:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 15:46:03 --> Pagination Class Initialized
INFO - 2023-11-02 15:46:03 --> Form Validation Class Initialized
INFO - 2023-11-02 15:46:03 --> Controller Class Initialized
INFO - 2023-11-02 15:46:03 --> Model Class Initialized
DEBUG - 2023-11-02 15:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:03 --> Model Class Initialized
INFO - 2023-11-02 15:46:03 --> Final output sent to browser
DEBUG - 2023-11-02 15:46:03 --> Total execution time: 0.0226
ERROR - 2023-11-02 15:46:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 15:46:04 --> Config Class Initialized
INFO - 2023-11-02 15:46:04 --> Hooks Class Initialized
DEBUG - 2023-11-02 15:46:04 --> UTF-8 Support Enabled
INFO - 2023-11-02 15:46:04 --> Utf8 Class Initialized
INFO - 2023-11-02 15:46:04 --> URI Class Initialized
DEBUG - 2023-11-02 15:46:04 --> No URI present. Default controller set.
INFO - 2023-11-02 15:46:04 --> Router Class Initialized
INFO - 2023-11-02 15:46:04 --> Output Class Initialized
INFO - 2023-11-02 15:46:04 --> Security Class Initialized
DEBUG - 2023-11-02 15:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 15:46:04 --> Input Class Initialized
INFO - 2023-11-02 15:46:04 --> Language Class Initialized
INFO - 2023-11-02 15:46:04 --> Loader Class Initialized
INFO - 2023-11-02 15:46:04 --> Helper loaded: url_helper
INFO - 2023-11-02 15:46:04 --> Helper loaded: file_helper
INFO - 2023-11-02 15:46:04 --> Helper loaded: html_helper
INFO - 2023-11-02 15:46:04 --> Helper loaded: text_helper
INFO - 2023-11-02 15:46:04 --> Helper loaded: form_helper
INFO - 2023-11-02 15:46:04 --> Helper loaded: lang_helper
INFO - 2023-11-02 15:46:04 --> Helper loaded: security_helper
INFO - 2023-11-02 15:46:04 --> Helper loaded: cookie_helper
INFO - 2023-11-02 15:46:04 --> Database Driver Class Initialized
INFO - 2023-11-02 15:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 15:46:04 --> Parser Class Initialized
INFO - 2023-11-02 15:46:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 15:46:04 --> Pagination Class Initialized
INFO - 2023-11-02 15:46:04 --> Form Validation Class Initialized
INFO - 2023-11-02 15:46:04 --> Controller Class Initialized
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
DEBUG - 2023-11-02 15:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
DEBUG - 2023-11-02 15:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
DEBUG - 2023-11-02 15:46:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 15:46:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
INFO - 2023-11-02 15:46:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-02 15:46:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 15:46:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 15:46:04 --> Model Class Initialized
INFO - 2023-11-02 15:46:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 15:46:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 15:46:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 15:46:04 --> Final output sent to browser
DEBUG - 2023-11-02 15:46:04 --> Total execution time: 0.3719
ERROR - 2023-11-02 15:46:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 15:46:05 --> Config Class Initialized
INFO - 2023-11-02 15:46:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 15:46:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 15:46:05 --> Utf8 Class Initialized
INFO - 2023-11-02 15:46:05 --> URI Class Initialized
INFO - 2023-11-02 15:46:05 --> Router Class Initialized
INFO - 2023-11-02 15:46:05 --> Output Class Initialized
INFO - 2023-11-02 15:46:05 --> Security Class Initialized
DEBUG - 2023-11-02 15:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 15:46:05 --> Input Class Initialized
INFO - 2023-11-02 15:46:05 --> Language Class Initialized
INFO - 2023-11-02 15:46:05 --> Loader Class Initialized
INFO - 2023-11-02 15:46:05 --> Helper loaded: url_helper
INFO - 2023-11-02 15:46:05 --> Helper loaded: file_helper
INFO - 2023-11-02 15:46:05 --> Helper loaded: html_helper
INFO - 2023-11-02 15:46:05 --> Helper loaded: text_helper
INFO - 2023-11-02 15:46:05 --> Helper loaded: form_helper
INFO - 2023-11-02 15:46:05 --> Helper loaded: lang_helper
INFO - 2023-11-02 15:46:05 --> Helper loaded: security_helper
INFO - 2023-11-02 15:46:05 --> Helper loaded: cookie_helper
INFO - 2023-11-02 15:46:05 --> Database Driver Class Initialized
INFO - 2023-11-02 15:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 15:46:05 --> Parser Class Initialized
INFO - 2023-11-02 15:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 15:46:05 --> Pagination Class Initialized
INFO - 2023-11-02 15:46:05 --> Form Validation Class Initialized
INFO - 2023-11-02 15:46:05 --> Controller Class Initialized
DEBUG - 2023-11-02 15:46:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 15:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:05 --> Model Class Initialized
INFO - 2023-11-02 15:46:05 --> Final output sent to browser
DEBUG - 2023-11-02 15:46:05 --> Total execution time: 0.0148
ERROR - 2023-11-02 15:46:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 15:46:18 --> Config Class Initialized
INFO - 2023-11-02 15:46:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 15:46:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 15:46:18 --> Utf8 Class Initialized
INFO - 2023-11-02 15:46:18 --> URI Class Initialized
INFO - 2023-11-02 15:46:18 --> Router Class Initialized
INFO - 2023-11-02 15:46:18 --> Output Class Initialized
INFO - 2023-11-02 15:46:18 --> Security Class Initialized
DEBUG - 2023-11-02 15:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 15:46:18 --> Input Class Initialized
INFO - 2023-11-02 15:46:18 --> Language Class Initialized
INFO - 2023-11-02 15:46:18 --> Loader Class Initialized
INFO - 2023-11-02 15:46:18 --> Helper loaded: url_helper
INFO - 2023-11-02 15:46:18 --> Helper loaded: file_helper
INFO - 2023-11-02 15:46:18 --> Helper loaded: html_helper
INFO - 2023-11-02 15:46:18 --> Helper loaded: text_helper
INFO - 2023-11-02 15:46:18 --> Helper loaded: form_helper
INFO - 2023-11-02 15:46:18 --> Helper loaded: lang_helper
INFO - 2023-11-02 15:46:18 --> Helper loaded: security_helper
INFO - 2023-11-02 15:46:18 --> Helper loaded: cookie_helper
INFO - 2023-11-02 15:46:18 --> Database Driver Class Initialized
INFO - 2023-11-02 15:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 15:46:18 --> Parser Class Initialized
INFO - 2023-11-02 15:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-02 15:46:18 --> Pagination Class Initialized
INFO - 2023-11-02 15:46:18 --> Form Validation Class Initialized
INFO - 2023-11-02 15:46:18 --> Controller Class Initialized
DEBUG - 2023-11-02 15:46:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 15:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:18 --> Model Class Initialized
INFO - 2023-11-02 15:46:18 --> Model Class Initialized
DEBUG - 2023-11-02 15:46:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 15:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:18 --> Model Class Initialized
DEBUG - 2023-11-02 15:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-11-02 15:46:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-02 15:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-02 15:46:18 --> Model Class Initialized
INFO - 2023-11-02 15:46:18 --> Model Class Initialized
INFO - 2023-11-02 15:46:18 --> Model Class Initialized
INFO - 2023-11-02 15:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-02 15:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-02 15:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-02 15:46:19 --> Final output sent to browser
DEBUG - 2023-11-02 15:46:19 --> Total execution time: 0.1977
ERROR - 2023-11-02 19:03:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-02 19:03:27 --> Config Class Initialized
INFO - 2023-11-02 19:03:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 19:03:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 19:03:27 --> Utf8 Class Initialized
INFO - 2023-11-02 19:03:27 --> URI Class Initialized
INFO - 2023-11-02 19:03:27 --> Router Class Initialized
INFO - 2023-11-02 19:03:27 --> Output Class Initialized
INFO - 2023-11-02 19:03:27 --> Security Class Initialized
DEBUG - 2023-11-02 19:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 19:03:27 --> Input Class Initialized
INFO - 2023-11-02 19:03:27 --> Language Class Initialized
ERROR - 2023-11-02 19:03:27 --> 404 Page Not Found: Well-known/assetlinks.json
