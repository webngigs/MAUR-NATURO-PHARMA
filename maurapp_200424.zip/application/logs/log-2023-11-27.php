<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-27 02:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 02:38:15 --> Config Class Initialized
INFO - 2023-11-27 02:38:15 --> Hooks Class Initialized
DEBUG - 2023-11-27 02:38:15 --> UTF-8 Support Enabled
INFO - 2023-11-27 02:38:15 --> Utf8 Class Initialized
INFO - 2023-11-27 02:38:15 --> URI Class Initialized
INFO - 2023-11-27 02:38:15 --> Router Class Initialized
INFO - 2023-11-27 02:38:15 --> Output Class Initialized
INFO - 2023-11-27 02:38:15 --> Security Class Initialized
DEBUG - 2023-11-27 02:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 02:38:15 --> Input Class Initialized
INFO - 2023-11-27 02:38:15 --> Language Class Initialized
ERROR - 2023-11-27 02:38:15 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-27 06:07:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:07:40 --> Config Class Initialized
INFO - 2023-11-27 06:07:40 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:07:40 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:07:40 --> Utf8 Class Initialized
INFO - 2023-11-27 06:07:40 --> URI Class Initialized
DEBUG - 2023-11-27 06:07:40 --> No URI present. Default controller set.
INFO - 2023-11-27 06:07:40 --> Router Class Initialized
INFO - 2023-11-27 06:07:40 --> Output Class Initialized
INFO - 2023-11-27 06:07:40 --> Security Class Initialized
DEBUG - 2023-11-27 06:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:07:40 --> Input Class Initialized
INFO - 2023-11-27 06:07:40 --> Language Class Initialized
INFO - 2023-11-27 06:07:40 --> Loader Class Initialized
INFO - 2023-11-27 06:07:40 --> Helper loaded: url_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: file_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: html_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: text_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: form_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: security_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:07:40 --> Database Driver Class Initialized
INFO - 2023-11-27 06:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:07:40 --> Parser Class Initialized
INFO - 2023-11-27 06:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:07:40 --> Pagination Class Initialized
INFO - 2023-11-27 06:07:40 --> Form Validation Class Initialized
INFO - 2023-11-27 06:07:40 --> Controller Class Initialized
INFO - 2023-11-27 06:07:40 --> Model Class Initialized
DEBUG - 2023-11-27 06:07:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-27 06:07:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:07:40 --> Config Class Initialized
INFO - 2023-11-27 06:07:40 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:07:40 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:07:40 --> Utf8 Class Initialized
INFO - 2023-11-27 06:07:40 --> URI Class Initialized
INFO - 2023-11-27 06:07:40 --> Router Class Initialized
INFO - 2023-11-27 06:07:40 --> Output Class Initialized
INFO - 2023-11-27 06:07:40 --> Security Class Initialized
DEBUG - 2023-11-27 06:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:07:40 --> Input Class Initialized
INFO - 2023-11-27 06:07:40 --> Language Class Initialized
INFO - 2023-11-27 06:07:40 --> Loader Class Initialized
INFO - 2023-11-27 06:07:40 --> Helper loaded: url_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: file_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: html_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: text_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: form_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: security_helper
INFO - 2023-11-27 06:07:40 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:07:40 --> Database Driver Class Initialized
INFO - 2023-11-27 06:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:07:40 --> Parser Class Initialized
INFO - 2023-11-27 06:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:07:40 --> Pagination Class Initialized
INFO - 2023-11-27 06:07:40 --> Form Validation Class Initialized
INFO - 2023-11-27 06:07:40 --> Controller Class Initialized
INFO - 2023-11-27 06:07:40 --> Model Class Initialized
DEBUG - 2023-11-27 06:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-27 06:07:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 06:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 06:07:40 --> Model Class Initialized
INFO - 2023-11-27 06:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 06:07:40 --> Final output sent to browser
DEBUG - 2023-11-27 06:07:40 --> Total execution time: 0.0337
ERROR - 2023-11-27 06:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:01 --> Config Class Initialized
INFO - 2023-11-27 06:08:01 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:01 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:01 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:01 --> URI Class Initialized
INFO - 2023-11-27 06:08:01 --> Router Class Initialized
INFO - 2023-11-27 06:08:01 --> Output Class Initialized
INFO - 2023-11-27 06:08:01 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:01 --> Input Class Initialized
INFO - 2023-11-27 06:08:01 --> Language Class Initialized
INFO - 2023-11-27 06:08:01 --> Loader Class Initialized
INFO - 2023-11-27 06:08:01 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:01 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:01 --> Parser Class Initialized
INFO - 2023-11-27 06:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:01 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:01 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:01 --> Controller Class Initialized
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
INFO - 2023-11-27 06:08:01 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:01 --> Total execution time: 0.0256
ERROR - 2023-11-27 06:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:01 --> Config Class Initialized
INFO - 2023-11-27 06:08:01 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:01 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:01 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:01 --> URI Class Initialized
DEBUG - 2023-11-27 06:08:01 --> No URI present. Default controller set.
INFO - 2023-11-27 06:08:01 --> Router Class Initialized
INFO - 2023-11-27 06:08:01 --> Output Class Initialized
INFO - 2023-11-27 06:08:01 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:01 --> Input Class Initialized
INFO - 2023-11-27 06:08:01 --> Language Class Initialized
INFO - 2023-11-27 06:08:01 --> Loader Class Initialized
INFO - 2023-11-27 06:08:01 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:01 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:01 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:01 --> Parser Class Initialized
INFO - 2023-11-27 06:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:01 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:01 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:01 --> Controller Class Initialized
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 06:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
INFO - 2023-11-27 06:08:01 --> Model Class Initialized
INFO - 2023-11-27 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-27 06:08:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 06:08:02 --> Model Class Initialized
INFO - 2023-11-27 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-27 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-27 06:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 06:08:02 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:02 --> Total execution time: 0.4346
ERROR - 2023-11-27 06:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:02 --> Config Class Initialized
INFO - 2023-11-27 06:08:02 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:02 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:02 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:02 --> URI Class Initialized
INFO - 2023-11-27 06:08:02 --> Router Class Initialized
INFO - 2023-11-27 06:08:02 --> Output Class Initialized
INFO - 2023-11-27 06:08:02 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:02 --> Input Class Initialized
INFO - 2023-11-27 06:08:02 --> Language Class Initialized
INFO - 2023-11-27 06:08:02 --> Loader Class Initialized
INFO - 2023-11-27 06:08:02 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:02 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:02 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:02 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:02 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:02 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:02 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:02 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:02 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:02 --> Parser Class Initialized
INFO - 2023-11-27 06:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:02 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:02 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:02 --> Controller Class Initialized
DEBUG - 2023-11-27 06:08:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 06:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:02 --> Model Class Initialized
INFO - 2023-11-27 06:08:02 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:02 --> Total execution time: 0.0134
ERROR - 2023-11-27 06:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:25 --> Config Class Initialized
INFO - 2023-11-27 06:08:25 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:25 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:25 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:25 --> URI Class Initialized
INFO - 2023-11-27 06:08:25 --> Router Class Initialized
INFO - 2023-11-27 06:08:25 --> Output Class Initialized
INFO - 2023-11-27 06:08:25 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:25 --> Input Class Initialized
INFO - 2023-11-27 06:08:25 --> Language Class Initialized
INFO - 2023-11-27 06:08:25 --> Loader Class Initialized
INFO - 2023-11-27 06:08:25 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:25 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:25 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:25 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:25 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:25 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:25 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:25 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:25 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:25 --> Parser Class Initialized
INFO - 2023-11-27 06:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:25 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:25 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:25 --> Controller Class Initialized
INFO - 2023-11-27 06:08:25 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 06:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:25 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:25 --> Model Class Initialized
INFO - 2023-11-27 06:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-11-27 06:08:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 06:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 06:08:25 --> Model Class Initialized
INFO - 2023-11-27 06:08:25 --> Model Class Initialized
INFO - 2023-11-27 06:08:25 --> Model Class Initialized
INFO - 2023-11-27 06:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-27 06:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-27 06:08:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 06:08:25 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:25 --> Total execution time: 0.2041
ERROR - 2023-11-27 06:08:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:26 --> Config Class Initialized
INFO - 2023-11-27 06:08:26 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:26 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:26 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:26 --> URI Class Initialized
INFO - 2023-11-27 06:08:26 --> Router Class Initialized
INFO - 2023-11-27 06:08:26 --> Output Class Initialized
INFO - 2023-11-27 06:08:26 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:26 --> Input Class Initialized
INFO - 2023-11-27 06:08:26 --> Language Class Initialized
INFO - 2023-11-27 06:08:26 --> Loader Class Initialized
INFO - 2023-11-27 06:08:26 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:26 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:26 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:26 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:26 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:26 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:26 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:26 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:26 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:26 --> Parser Class Initialized
INFO - 2023-11-27 06:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:26 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:26 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:26 --> Controller Class Initialized
INFO - 2023-11-27 06:08:26 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 06:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:26 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:26 --> Model Class Initialized
INFO - 2023-11-27 06:08:26 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:26 --> Total execution time: 0.0505
ERROR - 2023-11-27 06:08:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:30 --> Config Class Initialized
INFO - 2023-11-27 06:08:30 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:30 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:30 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:30 --> URI Class Initialized
INFO - 2023-11-27 06:08:30 --> Router Class Initialized
INFO - 2023-11-27 06:08:30 --> Output Class Initialized
INFO - 2023-11-27 06:08:30 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:30 --> Input Class Initialized
INFO - 2023-11-27 06:08:30 --> Language Class Initialized
INFO - 2023-11-27 06:08:30 --> Loader Class Initialized
INFO - 2023-11-27 06:08:30 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:30 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:30 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:30 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:30 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:30 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:30 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:30 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:30 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:30 --> Parser Class Initialized
INFO - 2023-11-27 06:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:30 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:30 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:30 --> Controller Class Initialized
INFO - 2023-11-27 06:08:30 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 06:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:30 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:30 --> Model Class Initialized
INFO - 2023-11-27 06:08:30 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:30 --> Total execution time: 0.0498
ERROR - 2023-11-27 06:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:31 --> Config Class Initialized
INFO - 2023-11-27 06:08:31 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:31 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:31 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:31 --> URI Class Initialized
INFO - 2023-11-27 06:08:31 --> Router Class Initialized
INFO - 2023-11-27 06:08:31 --> Output Class Initialized
INFO - 2023-11-27 06:08:31 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:31 --> Input Class Initialized
INFO - 2023-11-27 06:08:31 --> Language Class Initialized
INFO - 2023-11-27 06:08:31 --> Loader Class Initialized
INFO - 2023-11-27 06:08:31 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:31 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:31 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:31 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:31 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:31 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:31 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:31 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:31 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:31 --> Parser Class Initialized
INFO - 2023-11-27 06:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:31 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:31 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:31 --> Controller Class Initialized
INFO - 2023-11-27 06:08:31 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 06:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:31 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:31 --> Model Class Initialized
INFO - 2023-11-27 06:08:31 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:31 --> Total execution time: 0.0467
ERROR - 2023-11-27 06:08:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 06:08:33 --> Config Class Initialized
INFO - 2023-11-27 06:08:33 --> Hooks Class Initialized
DEBUG - 2023-11-27 06:08:33 --> UTF-8 Support Enabled
INFO - 2023-11-27 06:08:33 --> Utf8 Class Initialized
INFO - 2023-11-27 06:08:33 --> URI Class Initialized
INFO - 2023-11-27 06:08:33 --> Router Class Initialized
INFO - 2023-11-27 06:08:33 --> Output Class Initialized
INFO - 2023-11-27 06:08:33 --> Security Class Initialized
DEBUG - 2023-11-27 06:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 06:08:33 --> Input Class Initialized
INFO - 2023-11-27 06:08:33 --> Language Class Initialized
INFO - 2023-11-27 06:08:33 --> Loader Class Initialized
INFO - 2023-11-27 06:08:33 --> Helper loaded: url_helper
INFO - 2023-11-27 06:08:33 --> Helper loaded: file_helper
INFO - 2023-11-27 06:08:33 --> Helper loaded: html_helper
INFO - 2023-11-27 06:08:33 --> Helper loaded: text_helper
INFO - 2023-11-27 06:08:33 --> Helper loaded: form_helper
INFO - 2023-11-27 06:08:33 --> Helper loaded: lang_helper
INFO - 2023-11-27 06:08:33 --> Helper loaded: security_helper
INFO - 2023-11-27 06:08:33 --> Helper loaded: cookie_helper
INFO - 2023-11-27 06:08:33 --> Database Driver Class Initialized
INFO - 2023-11-27 06:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 06:08:33 --> Parser Class Initialized
INFO - 2023-11-27 06:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 06:08:33 --> Pagination Class Initialized
INFO - 2023-11-27 06:08:33 --> Form Validation Class Initialized
INFO - 2023-11-27 06:08:33 --> Controller Class Initialized
INFO - 2023-11-27 06:08:33 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 06:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:33 --> Model Class Initialized
DEBUG - 2023-11-27 06:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 06:08:33 --> Model Class Initialized
INFO - 2023-11-27 06:08:33 --> Final output sent to browser
DEBUG - 2023-11-27 06:08:33 --> Total execution time: 0.0458
ERROR - 2023-11-27 13:09:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 13:09:44 --> Config Class Initialized
INFO - 2023-11-27 13:09:44 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:09:44 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:09:44 --> Utf8 Class Initialized
INFO - 2023-11-27 13:09:44 --> URI Class Initialized
DEBUG - 2023-11-27 13:09:44 --> No URI present. Default controller set.
INFO - 2023-11-27 13:09:44 --> Router Class Initialized
INFO - 2023-11-27 13:09:44 --> Output Class Initialized
INFO - 2023-11-27 13:09:44 --> Security Class Initialized
DEBUG - 2023-11-27 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:09:44 --> Input Class Initialized
INFO - 2023-11-27 13:09:44 --> Language Class Initialized
INFO - 2023-11-27 13:09:44 --> Loader Class Initialized
INFO - 2023-11-27 13:09:44 --> Helper loaded: url_helper
INFO - 2023-11-27 13:09:44 --> Helper loaded: file_helper
INFO - 2023-11-27 13:09:44 --> Helper loaded: html_helper
INFO - 2023-11-27 13:09:44 --> Helper loaded: text_helper
INFO - 2023-11-27 13:09:44 --> Helper loaded: form_helper
INFO - 2023-11-27 13:09:44 --> Helper loaded: lang_helper
INFO - 2023-11-27 13:09:44 --> Helper loaded: security_helper
INFO - 2023-11-27 13:09:44 --> Helper loaded: cookie_helper
INFO - 2023-11-27 13:09:44 --> Database Driver Class Initialized
INFO - 2023-11-27 13:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:09:44 --> Parser Class Initialized
INFO - 2023-11-27 13:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 13:09:44 --> Pagination Class Initialized
INFO - 2023-11-27 13:09:44 --> Form Validation Class Initialized
INFO - 2023-11-27 13:09:44 --> Controller Class Initialized
INFO - 2023-11-27 13:09:44 --> Model Class Initialized
DEBUG - 2023-11-27 13:09:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-27 13:09:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 13:09:45 --> Config Class Initialized
INFO - 2023-11-27 13:09:45 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:09:45 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:09:45 --> Utf8 Class Initialized
INFO - 2023-11-27 13:09:45 --> URI Class Initialized
INFO - 2023-11-27 13:09:45 --> Router Class Initialized
INFO - 2023-11-27 13:09:45 --> Output Class Initialized
INFO - 2023-11-27 13:09:45 --> Security Class Initialized
DEBUG - 2023-11-27 13:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:09:45 --> Input Class Initialized
INFO - 2023-11-27 13:09:45 --> Language Class Initialized
INFO - 2023-11-27 13:09:45 --> Loader Class Initialized
INFO - 2023-11-27 13:09:45 --> Helper loaded: url_helper
INFO - 2023-11-27 13:09:45 --> Helper loaded: file_helper
INFO - 2023-11-27 13:09:45 --> Helper loaded: html_helper
INFO - 2023-11-27 13:09:45 --> Helper loaded: text_helper
INFO - 2023-11-27 13:09:45 --> Helper loaded: form_helper
INFO - 2023-11-27 13:09:45 --> Helper loaded: lang_helper
INFO - 2023-11-27 13:09:45 --> Helper loaded: security_helper
INFO - 2023-11-27 13:09:45 --> Helper loaded: cookie_helper
INFO - 2023-11-27 13:09:45 --> Database Driver Class Initialized
INFO - 2023-11-27 13:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:09:45 --> Parser Class Initialized
INFO - 2023-11-27 13:09:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 13:09:45 --> Pagination Class Initialized
INFO - 2023-11-27 13:09:45 --> Form Validation Class Initialized
INFO - 2023-11-27 13:09:45 --> Controller Class Initialized
INFO - 2023-11-27 13:09:45 --> Model Class Initialized
DEBUG - 2023-11-27 13:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 13:09:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-27 13:09:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 13:09:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 13:09:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 13:09:45 --> Model Class Initialized
INFO - 2023-11-27 13:09:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 13:09:45 --> Final output sent to browser
DEBUG - 2023-11-27 13:09:45 --> Total execution time: 0.0357
ERROR - 2023-11-27 16:58:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:58:45 --> Config Class Initialized
INFO - 2023-11-27 16:58:45 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:58:45 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:58:45 --> Utf8 Class Initialized
INFO - 2023-11-27 16:58:45 --> URI Class Initialized
DEBUG - 2023-11-27 16:58:45 --> No URI present. Default controller set.
INFO - 2023-11-27 16:58:45 --> Router Class Initialized
INFO - 2023-11-27 16:58:45 --> Output Class Initialized
INFO - 2023-11-27 16:58:45 --> Security Class Initialized
DEBUG - 2023-11-27 16:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:58:45 --> Input Class Initialized
INFO - 2023-11-27 16:58:45 --> Language Class Initialized
INFO - 2023-11-27 16:58:45 --> Loader Class Initialized
INFO - 2023-11-27 16:58:45 --> Helper loaded: url_helper
INFO - 2023-11-27 16:58:45 --> Helper loaded: file_helper
INFO - 2023-11-27 16:58:45 --> Helper loaded: html_helper
INFO - 2023-11-27 16:58:45 --> Helper loaded: text_helper
INFO - 2023-11-27 16:58:45 --> Helper loaded: form_helper
INFO - 2023-11-27 16:58:45 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:58:45 --> Helper loaded: security_helper
INFO - 2023-11-27 16:58:45 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:58:45 --> Database Driver Class Initialized
INFO - 2023-11-27 16:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:58:45 --> Parser Class Initialized
INFO - 2023-11-27 16:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:58:45 --> Pagination Class Initialized
INFO - 2023-11-27 16:58:45 --> Form Validation Class Initialized
INFO - 2023-11-27 16:58:45 --> Controller Class Initialized
INFO - 2023-11-27 16:58:45 --> Model Class Initialized
DEBUG - 2023-11-27 16:58:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-27 16:58:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:58:46 --> Config Class Initialized
INFO - 2023-11-27 16:58:46 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:58:46 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:58:46 --> Utf8 Class Initialized
INFO - 2023-11-27 16:58:46 --> URI Class Initialized
INFO - 2023-11-27 16:58:46 --> Router Class Initialized
INFO - 2023-11-27 16:58:46 --> Output Class Initialized
INFO - 2023-11-27 16:58:46 --> Security Class Initialized
DEBUG - 2023-11-27 16:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:58:46 --> Input Class Initialized
INFO - 2023-11-27 16:58:46 --> Language Class Initialized
INFO - 2023-11-27 16:58:46 --> Loader Class Initialized
INFO - 2023-11-27 16:58:46 --> Helper loaded: url_helper
INFO - 2023-11-27 16:58:46 --> Helper loaded: file_helper
INFO - 2023-11-27 16:58:46 --> Helper loaded: html_helper
INFO - 2023-11-27 16:58:46 --> Helper loaded: text_helper
INFO - 2023-11-27 16:58:46 --> Helper loaded: form_helper
INFO - 2023-11-27 16:58:46 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:58:46 --> Helper loaded: security_helper
INFO - 2023-11-27 16:58:46 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:58:46 --> Database Driver Class Initialized
INFO - 2023-11-27 16:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:58:46 --> Parser Class Initialized
INFO - 2023-11-27 16:58:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:58:46 --> Pagination Class Initialized
INFO - 2023-11-27 16:58:46 --> Form Validation Class Initialized
INFO - 2023-11-27 16:58:46 --> Controller Class Initialized
INFO - 2023-11-27 16:58:46 --> Model Class Initialized
DEBUG - 2023-11-27 16:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-27 16:58:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 16:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 16:58:46 --> Model Class Initialized
INFO - 2023-11-27 16:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 16:58:46 --> Final output sent to browser
DEBUG - 2023-11-27 16:58:46 --> Total execution time: 0.0377
ERROR - 2023-11-27 16:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:59:09 --> Config Class Initialized
INFO - 2023-11-27 16:59:09 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:59:09 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:59:09 --> Utf8 Class Initialized
INFO - 2023-11-27 16:59:09 --> URI Class Initialized
INFO - 2023-11-27 16:59:09 --> Router Class Initialized
INFO - 2023-11-27 16:59:09 --> Output Class Initialized
INFO - 2023-11-27 16:59:09 --> Security Class Initialized
DEBUG - 2023-11-27 16:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:59:09 --> Input Class Initialized
INFO - 2023-11-27 16:59:09 --> Language Class Initialized
INFO - 2023-11-27 16:59:09 --> Loader Class Initialized
INFO - 2023-11-27 16:59:09 --> Helper loaded: url_helper
INFO - 2023-11-27 16:59:09 --> Helper loaded: file_helper
INFO - 2023-11-27 16:59:09 --> Helper loaded: html_helper
INFO - 2023-11-27 16:59:09 --> Helper loaded: text_helper
INFO - 2023-11-27 16:59:09 --> Helper loaded: form_helper
INFO - 2023-11-27 16:59:09 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:59:09 --> Helper loaded: security_helper
INFO - 2023-11-27 16:59:09 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:59:09 --> Database Driver Class Initialized
INFO - 2023-11-27 16:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:59:09 --> Parser Class Initialized
INFO - 2023-11-27 16:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:59:09 --> Pagination Class Initialized
INFO - 2023-11-27 16:59:09 --> Form Validation Class Initialized
INFO - 2023-11-27 16:59:09 --> Controller Class Initialized
INFO - 2023-11-27 16:59:09 --> Model Class Initialized
DEBUG - 2023-11-27 16:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:09 --> Model Class Initialized
INFO - 2023-11-27 16:59:09 --> Final output sent to browser
DEBUG - 2023-11-27 16:59:09 --> Total execution time: 0.0247
ERROR - 2023-11-27 16:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:59:10 --> Config Class Initialized
INFO - 2023-11-27 16:59:10 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:59:10 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:59:10 --> Utf8 Class Initialized
INFO - 2023-11-27 16:59:10 --> URI Class Initialized
INFO - 2023-11-27 16:59:10 --> Router Class Initialized
INFO - 2023-11-27 16:59:10 --> Output Class Initialized
INFO - 2023-11-27 16:59:10 --> Security Class Initialized
DEBUG - 2023-11-27 16:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:59:10 --> Input Class Initialized
INFO - 2023-11-27 16:59:10 --> Language Class Initialized
INFO - 2023-11-27 16:59:10 --> Loader Class Initialized
INFO - 2023-11-27 16:59:10 --> Helper loaded: url_helper
INFO - 2023-11-27 16:59:10 --> Helper loaded: file_helper
INFO - 2023-11-27 16:59:10 --> Helper loaded: html_helper
INFO - 2023-11-27 16:59:10 --> Helper loaded: text_helper
INFO - 2023-11-27 16:59:10 --> Helper loaded: form_helper
INFO - 2023-11-27 16:59:10 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:59:10 --> Helper loaded: security_helper
INFO - 2023-11-27 16:59:10 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:59:10 --> Database Driver Class Initialized
INFO - 2023-11-27 16:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:59:10 --> Parser Class Initialized
INFO - 2023-11-27 16:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:59:10 --> Pagination Class Initialized
INFO - 2023-11-27 16:59:10 --> Form Validation Class Initialized
INFO - 2023-11-27 16:59:10 --> Controller Class Initialized
INFO - 2023-11-27 16:59:10 --> Model Class Initialized
DEBUG - 2023-11-27 16:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-27 16:59:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 16:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 16:59:10 --> Model Class Initialized
INFO - 2023-11-27 16:59:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 16:59:10 --> Final output sent to browser
DEBUG - 2023-11-27 16:59:10 --> Total execution time: 0.0341
ERROR - 2023-11-27 16:59:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:59:44 --> Config Class Initialized
INFO - 2023-11-27 16:59:44 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:59:44 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:59:44 --> Utf8 Class Initialized
INFO - 2023-11-27 16:59:44 --> URI Class Initialized
INFO - 2023-11-27 16:59:44 --> Router Class Initialized
INFO - 2023-11-27 16:59:44 --> Output Class Initialized
INFO - 2023-11-27 16:59:44 --> Security Class Initialized
DEBUG - 2023-11-27 16:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:59:44 --> Input Class Initialized
INFO - 2023-11-27 16:59:44 --> Language Class Initialized
INFO - 2023-11-27 16:59:44 --> Loader Class Initialized
INFO - 2023-11-27 16:59:44 --> Helper loaded: url_helper
INFO - 2023-11-27 16:59:44 --> Helper loaded: file_helper
INFO - 2023-11-27 16:59:44 --> Helper loaded: html_helper
INFO - 2023-11-27 16:59:44 --> Helper loaded: text_helper
INFO - 2023-11-27 16:59:44 --> Helper loaded: form_helper
INFO - 2023-11-27 16:59:44 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:59:44 --> Helper loaded: security_helper
INFO - 2023-11-27 16:59:44 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:59:44 --> Database Driver Class Initialized
INFO - 2023-11-27 16:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:59:44 --> Parser Class Initialized
INFO - 2023-11-27 16:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:59:44 --> Pagination Class Initialized
INFO - 2023-11-27 16:59:44 --> Form Validation Class Initialized
INFO - 2023-11-27 16:59:44 --> Controller Class Initialized
INFO - 2023-11-27 16:59:44 --> Model Class Initialized
DEBUG - 2023-11-27 16:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:44 --> Model Class Initialized
INFO - 2023-11-27 16:59:44 --> Final output sent to browser
DEBUG - 2023-11-27 16:59:44 --> Total execution time: 0.0196
ERROR - 2023-11-27 16:59:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:59:45 --> Config Class Initialized
INFO - 2023-11-27 16:59:45 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:59:45 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:59:45 --> Utf8 Class Initialized
INFO - 2023-11-27 16:59:45 --> URI Class Initialized
INFO - 2023-11-27 16:59:45 --> Router Class Initialized
INFO - 2023-11-27 16:59:45 --> Output Class Initialized
INFO - 2023-11-27 16:59:45 --> Security Class Initialized
DEBUG - 2023-11-27 16:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:59:45 --> Input Class Initialized
INFO - 2023-11-27 16:59:45 --> Language Class Initialized
INFO - 2023-11-27 16:59:45 --> Loader Class Initialized
INFO - 2023-11-27 16:59:45 --> Helper loaded: url_helper
INFO - 2023-11-27 16:59:45 --> Helper loaded: file_helper
INFO - 2023-11-27 16:59:45 --> Helper loaded: html_helper
INFO - 2023-11-27 16:59:45 --> Helper loaded: text_helper
INFO - 2023-11-27 16:59:45 --> Helper loaded: form_helper
INFO - 2023-11-27 16:59:45 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:59:45 --> Helper loaded: security_helper
INFO - 2023-11-27 16:59:45 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:59:45 --> Database Driver Class Initialized
INFO - 2023-11-27 16:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:59:45 --> Parser Class Initialized
INFO - 2023-11-27 16:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:59:45 --> Pagination Class Initialized
INFO - 2023-11-27 16:59:45 --> Form Validation Class Initialized
INFO - 2023-11-27 16:59:45 --> Controller Class Initialized
INFO - 2023-11-27 16:59:45 --> Model Class Initialized
DEBUG - 2023-11-27 16:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-27 16:59:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 16:59:45 --> Model Class Initialized
INFO - 2023-11-27 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 16:59:45 --> Final output sent to browser
DEBUG - 2023-11-27 16:59:45 --> Total execution time: 0.0335
ERROR - 2023-11-27 16:59:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:59:47 --> Config Class Initialized
INFO - 2023-11-27 16:59:47 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:59:47 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:59:47 --> Utf8 Class Initialized
INFO - 2023-11-27 16:59:47 --> URI Class Initialized
INFO - 2023-11-27 16:59:47 --> Router Class Initialized
INFO - 2023-11-27 16:59:47 --> Output Class Initialized
INFO - 2023-11-27 16:59:47 --> Security Class Initialized
DEBUG - 2023-11-27 16:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:59:47 --> Input Class Initialized
INFO - 2023-11-27 16:59:47 --> Language Class Initialized
INFO - 2023-11-27 16:59:47 --> Loader Class Initialized
INFO - 2023-11-27 16:59:47 --> Helper loaded: url_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: file_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: html_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: text_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: form_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: security_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:59:47 --> Database Driver Class Initialized
INFO - 2023-11-27 16:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:59:47 --> Parser Class Initialized
INFO - 2023-11-27 16:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:59:47 --> Pagination Class Initialized
INFO - 2023-11-27 16:59:47 --> Form Validation Class Initialized
INFO - 2023-11-27 16:59:47 --> Controller Class Initialized
INFO - 2023-11-27 16:59:47 --> Model Class Initialized
DEBUG - 2023-11-27 16:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-27 16:59:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 16:59:47 --> Model Class Initialized
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 16:59:47 --> Final output sent to browser
DEBUG - 2023-11-27 16:59:47 --> Total execution time: 0.0390
ERROR - 2023-11-27 16:59:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 16:59:47 --> Config Class Initialized
INFO - 2023-11-27 16:59:47 --> Hooks Class Initialized
DEBUG - 2023-11-27 16:59:47 --> UTF-8 Support Enabled
INFO - 2023-11-27 16:59:47 --> Utf8 Class Initialized
INFO - 2023-11-27 16:59:47 --> URI Class Initialized
INFO - 2023-11-27 16:59:47 --> Router Class Initialized
INFO - 2023-11-27 16:59:47 --> Output Class Initialized
INFO - 2023-11-27 16:59:47 --> Security Class Initialized
DEBUG - 2023-11-27 16:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 16:59:47 --> Input Class Initialized
INFO - 2023-11-27 16:59:47 --> Language Class Initialized
INFO - 2023-11-27 16:59:47 --> Loader Class Initialized
INFO - 2023-11-27 16:59:47 --> Helper loaded: url_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: file_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: html_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: text_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: form_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: lang_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: security_helper
INFO - 2023-11-27 16:59:47 --> Helper loaded: cookie_helper
INFO - 2023-11-27 16:59:47 --> Database Driver Class Initialized
INFO - 2023-11-27 16:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 16:59:47 --> Parser Class Initialized
INFO - 2023-11-27 16:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-27 16:59:47 --> Pagination Class Initialized
INFO - 2023-11-27 16:59:47 --> Form Validation Class Initialized
INFO - 2023-11-27 16:59:47 --> Controller Class Initialized
INFO - 2023-11-27 16:59:47 --> Model Class Initialized
DEBUG - 2023-11-27 16:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-27 16:59:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-27 16:59:47 --> Model Class Initialized
INFO - 2023-11-27 16:59:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-27 16:59:47 --> Final output sent to browser
DEBUG - 2023-11-27 16:59:47 --> Total execution time: 0.0327
ERROR - 2023-11-27 17:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-27 17:39:05 --> Config Class Initialized
INFO - 2023-11-27 17:39:05 --> Hooks Class Initialized
DEBUG - 2023-11-27 17:39:05 --> UTF-8 Support Enabled
INFO - 2023-11-27 17:39:05 --> Utf8 Class Initialized
INFO - 2023-11-27 17:39:05 --> URI Class Initialized
INFO - 2023-11-27 17:39:05 --> Router Class Initialized
INFO - 2023-11-27 17:39:05 --> Output Class Initialized
INFO - 2023-11-27 17:39:05 --> Security Class Initialized
DEBUG - 2023-11-27 17:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 17:39:05 --> Input Class Initialized
INFO - 2023-11-27 17:39:05 --> Language Class Initialized
ERROR - 2023-11-27 17:39:05 --> 404 Page Not Found: Well-known/assetlinks.json
