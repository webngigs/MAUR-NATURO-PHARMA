<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-16 03:30:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:21 --> Config Class Initialized
INFO - 2024-04-16 03:30:21 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:21 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:21 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:21 --> URI Class Initialized
DEBUG - 2024-04-16 03:30:21 --> No URI present. Default controller set.
INFO - 2024-04-16 03:30:21 --> Router Class Initialized
INFO - 2024-04-16 03:30:21 --> Output Class Initialized
INFO - 2024-04-16 03:30:21 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:21 --> Input Class Initialized
INFO - 2024-04-16 03:30:21 --> Language Class Initialized
INFO - 2024-04-16 03:30:21 --> Loader Class Initialized
INFO - 2024-04-16 03:30:21 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:21 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:21 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:21 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:21 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:21 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:21 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:21 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:21 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:21 --> Parser Class Initialized
INFO - 2024-04-16 03:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:21 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:21 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:21 --> Controller Class Initialized
INFO - 2024-04-16 03:30:21 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-16 03:30:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:22 --> Config Class Initialized
INFO - 2024-04-16 03:30:22 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:22 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:22 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:22 --> URI Class Initialized
INFO - 2024-04-16 03:30:22 --> Router Class Initialized
INFO - 2024-04-16 03:30:22 --> Output Class Initialized
INFO - 2024-04-16 03:30:22 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:22 --> Input Class Initialized
INFO - 2024-04-16 03:30:22 --> Language Class Initialized
INFO - 2024-04-16 03:30:22 --> Loader Class Initialized
INFO - 2024-04-16 03:30:22 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:22 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:22 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:22 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:22 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:22 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:22 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:22 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:22 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:22 --> Parser Class Initialized
INFO - 2024-04-16 03:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:22 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:22 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:22 --> Controller Class Initialized
INFO - 2024-04-16 03:30:22 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-16 03:30:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:30:22 --> Model Class Initialized
INFO - 2024-04-16 03:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:30:22 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:22 --> Total execution time: 0.0326
ERROR - 2024-04-16 03:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:31 --> Config Class Initialized
INFO - 2024-04-16 03:30:31 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:31 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:31 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:31 --> URI Class Initialized
INFO - 2024-04-16 03:30:31 --> Router Class Initialized
INFO - 2024-04-16 03:30:31 --> Output Class Initialized
INFO - 2024-04-16 03:30:31 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:31 --> Input Class Initialized
INFO - 2024-04-16 03:30:31 --> Language Class Initialized
INFO - 2024-04-16 03:30:31 --> Loader Class Initialized
INFO - 2024-04-16 03:30:31 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:31 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:31 --> Parser Class Initialized
INFO - 2024-04-16 03:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:31 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:31 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:31 --> Controller Class Initialized
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
INFO - 2024-04-16 03:30:31 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:31 --> Total execution time: 0.0200
ERROR - 2024-04-16 03:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:31 --> Config Class Initialized
INFO - 2024-04-16 03:30:31 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:31 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:31 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:31 --> URI Class Initialized
DEBUG - 2024-04-16 03:30:31 --> No URI present. Default controller set.
INFO - 2024-04-16 03:30:31 --> Router Class Initialized
INFO - 2024-04-16 03:30:31 --> Output Class Initialized
INFO - 2024-04-16 03:30:31 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:31 --> Input Class Initialized
INFO - 2024-04-16 03:30:31 --> Language Class Initialized
INFO - 2024-04-16 03:30:31 --> Loader Class Initialized
INFO - 2024-04-16 03:30:31 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:31 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:31 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:31 --> Parser Class Initialized
INFO - 2024-04-16 03:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:31 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:31 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:31 --> Controller Class Initialized
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
INFO - 2024-04-16 03:30:31 --> Model Class Initialized
INFO - 2024-04-16 03:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 03:30:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:30:32 --> Model Class Initialized
INFO - 2024-04-16 03:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:30:32 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:32 --> Total execution time: 0.3791
ERROR - 2024-04-16 03:30:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:40 --> Config Class Initialized
INFO - 2024-04-16 03:30:40 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:40 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:40 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:40 --> URI Class Initialized
INFO - 2024-04-16 03:30:40 --> Router Class Initialized
INFO - 2024-04-16 03:30:40 --> Output Class Initialized
INFO - 2024-04-16 03:30:40 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:40 --> Input Class Initialized
INFO - 2024-04-16 03:30:40 --> Language Class Initialized
INFO - 2024-04-16 03:30:40 --> Loader Class Initialized
INFO - 2024-04-16 03:30:40 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:40 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:40 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:40 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:40 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:40 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:40 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:40 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:40 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:40 --> Parser Class Initialized
INFO - 2024-04-16 03:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:40 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:40 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:40 --> Controller Class Initialized
INFO - 2024-04-16 03:30:40 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:40 --> Model Class Initialized
INFO - 2024-04-16 03:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-04-16 03:30:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:30:40 --> Model Class Initialized
INFO - 2024-04-16 03:30:40 --> Model Class Initialized
INFO - 2024-04-16 03:30:40 --> Model Class Initialized
INFO - 2024-04-16 03:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:30:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:30:40 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:40 --> Total execution time: 0.2104
ERROR - 2024-04-16 03:30:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:41 --> Config Class Initialized
INFO - 2024-04-16 03:30:41 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:41 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:41 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:41 --> URI Class Initialized
INFO - 2024-04-16 03:30:41 --> Router Class Initialized
INFO - 2024-04-16 03:30:41 --> Output Class Initialized
INFO - 2024-04-16 03:30:41 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:41 --> Input Class Initialized
INFO - 2024-04-16 03:30:41 --> Language Class Initialized
INFO - 2024-04-16 03:30:41 --> Loader Class Initialized
INFO - 2024-04-16 03:30:41 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:41 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:41 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:41 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:41 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:41 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:41 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:41 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:41 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:41 --> Parser Class Initialized
INFO - 2024-04-16 03:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:41 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:41 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:41 --> Controller Class Initialized
INFO - 2024-04-16 03:30:41 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:41 --> Model Class Initialized
INFO - 2024-04-16 03:30:41 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:41 --> Total execution time: 0.2611
ERROR - 2024-04-16 03:30:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:45 --> Config Class Initialized
INFO - 2024-04-16 03:30:45 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:45 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:45 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:45 --> URI Class Initialized
DEBUG - 2024-04-16 03:30:45 --> No URI present. Default controller set.
INFO - 2024-04-16 03:30:45 --> Router Class Initialized
INFO - 2024-04-16 03:30:45 --> Output Class Initialized
INFO - 2024-04-16 03:30:45 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:45 --> Input Class Initialized
INFO - 2024-04-16 03:30:45 --> Language Class Initialized
INFO - 2024-04-16 03:30:45 --> Loader Class Initialized
INFO - 2024-04-16 03:30:45 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:45 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:45 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:45 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:45 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:45 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:45 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:45 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:45 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:45 --> Parser Class Initialized
INFO - 2024-04-16 03:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:45 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:45 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:45 --> Controller Class Initialized
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
INFO - 2024-04-16 03:30:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 03:30:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:30:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:30:45 --> Model Class Initialized
INFO - 2024-04-16 03:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:30:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:30:46 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:46 --> Total execution time: 0.3665
ERROR - 2024-04-16 03:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:52 --> Config Class Initialized
INFO - 2024-04-16 03:30:52 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:52 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:52 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:52 --> URI Class Initialized
INFO - 2024-04-16 03:30:52 --> Router Class Initialized
INFO - 2024-04-16 03:30:52 --> Output Class Initialized
INFO - 2024-04-16 03:30:52 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:52 --> Input Class Initialized
INFO - 2024-04-16 03:30:52 --> Language Class Initialized
INFO - 2024-04-16 03:30:52 --> Loader Class Initialized
INFO - 2024-04-16 03:30:52 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:52 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:52 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:52 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:52 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:52 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:52 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:52 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:52 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:52 --> Parser Class Initialized
INFO - 2024-04-16 03:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:52 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:52 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:52 --> Controller Class Initialized
INFO - 2024-04-16 03:30:52 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:52 --> Model Class Initialized
INFO - 2024-04-16 03:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2024-04-16 03:30:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:30:52 --> Model Class Initialized
INFO - 2024-04-16 03:30:52 --> Model Class Initialized
INFO - 2024-04-16 03:30:52 --> Model Class Initialized
INFO - 2024-04-16 03:30:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:30:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:30:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:30:53 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:53 --> Total execution time: 0.2080
ERROR - 2024-04-16 03:30:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:53 --> Config Class Initialized
INFO - 2024-04-16 03:30:53 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:53 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:53 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:53 --> URI Class Initialized
INFO - 2024-04-16 03:30:53 --> Router Class Initialized
INFO - 2024-04-16 03:30:53 --> Output Class Initialized
INFO - 2024-04-16 03:30:53 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:53 --> Input Class Initialized
INFO - 2024-04-16 03:30:53 --> Language Class Initialized
INFO - 2024-04-16 03:30:53 --> Loader Class Initialized
INFO - 2024-04-16 03:30:53 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:53 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:53 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:53 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:53 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:53 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:53 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:53 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:53 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:53 --> Parser Class Initialized
INFO - 2024-04-16 03:30:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:53 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:53 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:53 --> Controller Class Initialized
INFO - 2024-04-16 03:30:53 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:53 --> Model Class Initialized
INFO - 2024-04-16 03:30:53 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:53 --> Total execution time: 0.0161
ERROR - 2024-04-16 03:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:58 --> Config Class Initialized
INFO - 2024-04-16 03:30:58 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:58 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:58 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:58 --> URI Class Initialized
INFO - 2024-04-16 03:30:58 --> Router Class Initialized
INFO - 2024-04-16 03:30:58 --> Output Class Initialized
INFO - 2024-04-16 03:30:58 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:58 --> Input Class Initialized
INFO - 2024-04-16 03:30:58 --> Language Class Initialized
INFO - 2024-04-16 03:30:58 --> Loader Class Initialized
INFO - 2024-04-16 03:30:58 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:58 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:58 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:58 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:58 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:58 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:58 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:58 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:58 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:58 --> Parser Class Initialized
INFO - 2024-04-16 03:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:58 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:58 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:58 --> Controller Class Initialized
INFO - 2024-04-16 03:30:58 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:58 --> Model Class Initialized
INFO - 2024-04-16 03:30:58 --> Final output sent to browser
DEBUG - 2024-04-16 03:30:58 --> Total execution time: 0.0197
ERROR - 2024-04-16 03:30:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:30:59 --> Config Class Initialized
INFO - 2024-04-16 03:30:59 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:30:59 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:30:59 --> Utf8 Class Initialized
INFO - 2024-04-16 03:30:59 --> URI Class Initialized
DEBUG - 2024-04-16 03:30:59 --> No URI present. Default controller set.
INFO - 2024-04-16 03:30:59 --> Router Class Initialized
INFO - 2024-04-16 03:30:59 --> Output Class Initialized
INFO - 2024-04-16 03:30:59 --> Security Class Initialized
DEBUG - 2024-04-16 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:30:59 --> Input Class Initialized
INFO - 2024-04-16 03:30:59 --> Language Class Initialized
INFO - 2024-04-16 03:30:59 --> Loader Class Initialized
INFO - 2024-04-16 03:30:59 --> Helper loaded: url_helper
INFO - 2024-04-16 03:30:59 --> Helper loaded: file_helper
INFO - 2024-04-16 03:30:59 --> Helper loaded: html_helper
INFO - 2024-04-16 03:30:59 --> Helper loaded: text_helper
INFO - 2024-04-16 03:30:59 --> Helper loaded: form_helper
INFO - 2024-04-16 03:30:59 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:30:59 --> Helper loaded: security_helper
INFO - 2024-04-16 03:30:59 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:30:59 --> Database Driver Class Initialized
INFO - 2024-04-16 03:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:30:59 --> Parser Class Initialized
INFO - 2024-04-16 03:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:30:59 --> Pagination Class Initialized
INFO - 2024-04-16 03:30:59 --> Form Validation Class Initialized
INFO - 2024-04-16 03:30:59 --> Controller Class Initialized
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
DEBUG - 2024-04-16 03:30:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
INFO - 2024-04-16 03:30:59 --> Model Class Initialized
INFO - 2024-04-16 03:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 03:31:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:31:00 --> Model Class Initialized
INFO - 2024-04-16 03:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:31:00 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:00 --> Total execution time: 0.3696
ERROR - 2024-04-16 03:31:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:31:15 --> Config Class Initialized
INFO - 2024-04-16 03:31:15 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:31:15 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:31:15 --> Utf8 Class Initialized
INFO - 2024-04-16 03:31:15 --> URI Class Initialized
INFO - 2024-04-16 03:31:15 --> Router Class Initialized
INFO - 2024-04-16 03:31:15 --> Output Class Initialized
INFO - 2024-04-16 03:31:15 --> Security Class Initialized
DEBUG - 2024-04-16 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:31:15 --> Input Class Initialized
INFO - 2024-04-16 03:31:15 --> Language Class Initialized
INFO - 2024-04-16 03:31:15 --> Loader Class Initialized
INFO - 2024-04-16 03:31:15 --> Helper loaded: url_helper
INFO - 2024-04-16 03:31:15 --> Helper loaded: file_helper
INFO - 2024-04-16 03:31:15 --> Helper loaded: html_helper
INFO - 2024-04-16 03:31:15 --> Helper loaded: text_helper
INFO - 2024-04-16 03:31:15 --> Helper loaded: form_helper
INFO - 2024-04-16 03:31:15 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:31:15 --> Helper loaded: security_helper
INFO - 2024-04-16 03:31:15 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:31:15 --> Database Driver Class Initialized
INFO - 2024-04-16 03:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:31:15 --> Parser Class Initialized
INFO - 2024-04-16 03:31:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:31:15 --> Pagination Class Initialized
INFO - 2024-04-16 03:31:15 --> Form Validation Class Initialized
INFO - 2024-04-16 03:31:15 --> Controller Class Initialized
INFO - 2024-04-16 03:31:15 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:31:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:15 --> Model Class Initialized
INFO - 2024-04-16 03:31:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-04-16 03:31:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:31:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:31:15 --> Model Class Initialized
INFO - 2024-04-16 03:31:15 --> Model Class Initialized
INFO - 2024-04-16 03:31:15 --> Model Class Initialized
INFO - 2024-04-16 03:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:31:16 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:16 --> Total execution time: 0.2315
ERROR - 2024-04-16 03:31:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:31:16 --> Config Class Initialized
INFO - 2024-04-16 03:31:16 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:31:16 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:31:16 --> Utf8 Class Initialized
INFO - 2024-04-16 03:31:16 --> URI Class Initialized
INFO - 2024-04-16 03:31:16 --> Router Class Initialized
INFO - 2024-04-16 03:31:16 --> Output Class Initialized
INFO - 2024-04-16 03:31:16 --> Security Class Initialized
DEBUG - 2024-04-16 03:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:31:16 --> Input Class Initialized
INFO - 2024-04-16 03:31:16 --> Language Class Initialized
INFO - 2024-04-16 03:31:16 --> Loader Class Initialized
INFO - 2024-04-16 03:31:16 --> Helper loaded: url_helper
INFO - 2024-04-16 03:31:16 --> Helper loaded: file_helper
INFO - 2024-04-16 03:31:16 --> Helper loaded: html_helper
INFO - 2024-04-16 03:31:16 --> Helper loaded: text_helper
INFO - 2024-04-16 03:31:16 --> Helper loaded: form_helper
INFO - 2024-04-16 03:31:16 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:31:16 --> Helper loaded: security_helper
INFO - 2024-04-16 03:31:16 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:31:16 --> Database Driver Class Initialized
INFO - 2024-04-16 03:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:31:16 --> Parser Class Initialized
INFO - 2024-04-16 03:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:31:16 --> Pagination Class Initialized
INFO - 2024-04-16 03:31:16 --> Form Validation Class Initialized
INFO - 2024-04-16 03:31:16 --> Controller Class Initialized
INFO - 2024-04-16 03:31:16 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:16 --> Model Class Initialized
INFO - 2024-04-16 03:31:16 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:16 --> Total execution time: 0.0327
ERROR - 2024-04-16 03:31:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:31:21 --> Config Class Initialized
INFO - 2024-04-16 03:31:21 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:31:21 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:31:21 --> Utf8 Class Initialized
INFO - 2024-04-16 03:31:21 --> URI Class Initialized
INFO - 2024-04-16 03:31:21 --> Router Class Initialized
INFO - 2024-04-16 03:31:21 --> Output Class Initialized
INFO - 2024-04-16 03:31:21 --> Security Class Initialized
DEBUG - 2024-04-16 03:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:31:21 --> Input Class Initialized
INFO - 2024-04-16 03:31:21 --> Language Class Initialized
INFO - 2024-04-16 03:31:21 --> Loader Class Initialized
INFO - 2024-04-16 03:31:21 --> Helper loaded: url_helper
INFO - 2024-04-16 03:31:21 --> Helper loaded: file_helper
INFO - 2024-04-16 03:31:21 --> Helper loaded: html_helper
INFO - 2024-04-16 03:31:21 --> Helper loaded: text_helper
INFO - 2024-04-16 03:31:21 --> Helper loaded: form_helper
INFO - 2024-04-16 03:31:21 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:31:21 --> Helper loaded: security_helper
INFO - 2024-04-16 03:31:21 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:31:21 --> Database Driver Class Initialized
INFO - 2024-04-16 03:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:31:21 --> Parser Class Initialized
INFO - 2024-04-16 03:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:31:21 --> Pagination Class Initialized
INFO - 2024-04-16 03:31:21 --> Form Validation Class Initialized
INFO - 2024-04-16 03:31:21 --> Controller Class Initialized
INFO - 2024-04-16 03:31:21 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:21 --> Model Class Initialized
INFO - 2024-04-16 03:31:21 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:21 --> Total execution time: 0.0521
ERROR - 2024-04-16 03:31:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:31:29 --> Config Class Initialized
INFO - 2024-04-16 03:31:29 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:31:29 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:31:29 --> Utf8 Class Initialized
INFO - 2024-04-16 03:31:29 --> URI Class Initialized
INFO - 2024-04-16 03:31:29 --> Router Class Initialized
INFO - 2024-04-16 03:31:29 --> Output Class Initialized
INFO - 2024-04-16 03:31:29 --> Security Class Initialized
DEBUG - 2024-04-16 03:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:31:29 --> Input Class Initialized
INFO - 2024-04-16 03:31:29 --> Language Class Initialized
INFO - 2024-04-16 03:31:29 --> Loader Class Initialized
INFO - 2024-04-16 03:31:29 --> Helper loaded: url_helper
INFO - 2024-04-16 03:31:29 --> Helper loaded: file_helper
INFO - 2024-04-16 03:31:29 --> Helper loaded: html_helper
INFO - 2024-04-16 03:31:29 --> Helper loaded: text_helper
INFO - 2024-04-16 03:31:29 --> Helper loaded: form_helper
INFO - 2024-04-16 03:31:29 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:31:29 --> Helper loaded: security_helper
INFO - 2024-04-16 03:31:29 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:31:29 --> Database Driver Class Initialized
INFO - 2024-04-16 03:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:31:29 --> Parser Class Initialized
INFO - 2024-04-16 03:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:31:29 --> Pagination Class Initialized
INFO - 2024-04-16 03:31:29 --> Form Validation Class Initialized
INFO - 2024-04-16 03:31:29 --> Controller Class Initialized
INFO - 2024-04-16 03:31:29 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:29 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2024-04-16 03:31:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:31:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:31:29 --> Model Class Initialized
INFO - 2024-04-16 03:31:29 --> Model Class Initialized
INFO - 2024-04-16 03:31:29 --> Model Class Initialized
INFO - 2024-04-16 03:31:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:31:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:31:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:31:29 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:29 --> Total execution time: 0.2262
ERROR - 2024-04-16 03:31:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:31:42 --> Config Class Initialized
INFO - 2024-04-16 03:31:42 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:31:42 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:31:42 --> Utf8 Class Initialized
INFO - 2024-04-16 03:31:42 --> URI Class Initialized
INFO - 2024-04-16 03:31:42 --> Router Class Initialized
INFO - 2024-04-16 03:31:42 --> Output Class Initialized
INFO - 2024-04-16 03:31:42 --> Security Class Initialized
DEBUG - 2024-04-16 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:31:42 --> Input Class Initialized
INFO - 2024-04-16 03:31:42 --> Language Class Initialized
INFO - 2024-04-16 03:31:42 --> Loader Class Initialized
INFO - 2024-04-16 03:31:42 --> Helper loaded: url_helper
INFO - 2024-04-16 03:31:42 --> Helper loaded: file_helper
INFO - 2024-04-16 03:31:42 --> Helper loaded: html_helper
INFO - 2024-04-16 03:31:42 --> Helper loaded: text_helper
INFO - 2024-04-16 03:31:42 --> Helper loaded: form_helper
INFO - 2024-04-16 03:31:42 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:31:42 --> Helper loaded: security_helper
INFO - 2024-04-16 03:31:42 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:31:42 --> Database Driver Class Initialized
INFO - 2024-04-16 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:31:42 --> Parser Class Initialized
INFO - 2024-04-16 03:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:31:42 --> Pagination Class Initialized
INFO - 2024-04-16 03:31:42 --> Form Validation Class Initialized
INFO - 2024-04-16 03:31:42 --> Controller Class Initialized
INFO - 2024-04-16 03:31:42 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:42 --> Model Class Initialized
INFO - 2024-04-16 03:31:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-04-16 03:31:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:31:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:31:42 --> Model Class Initialized
INFO - 2024-04-16 03:31:42 --> Model Class Initialized
INFO - 2024-04-16 03:31:42 --> Model Class Initialized
INFO - 2024-04-16 03:31:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:31:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:31:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:31:42 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:42 --> Total execution time: 0.2575
ERROR - 2024-04-16 03:31:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:31:43 --> Config Class Initialized
INFO - 2024-04-16 03:31:43 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:31:43 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:31:43 --> Utf8 Class Initialized
INFO - 2024-04-16 03:31:43 --> URI Class Initialized
INFO - 2024-04-16 03:31:43 --> Router Class Initialized
INFO - 2024-04-16 03:31:43 --> Output Class Initialized
INFO - 2024-04-16 03:31:43 --> Security Class Initialized
DEBUG - 2024-04-16 03:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:31:43 --> Input Class Initialized
INFO - 2024-04-16 03:31:43 --> Language Class Initialized
INFO - 2024-04-16 03:31:43 --> Loader Class Initialized
INFO - 2024-04-16 03:31:43 --> Helper loaded: url_helper
INFO - 2024-04-16 03:31:43 --> Helper loaded: file_helper
INFO - 2024-04-16 03:31:43 --> Helper loaded: html_helper
INFO - 2024-04-16 03:31:43 --> Helper loaded: text_helper
INFO - 2024-04-16 03:31:43 --> Helper loaded: form_helper
INFO - 2024-04-16 03:31:43 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:31:43 --> Helper loaded: security_helper
INFO - 2024-04-16 03:31:43 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:31:43 --> Database Driver Class Initialized
INFO - 2024-04-16 03:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:31:43 --> Parser Class Initialized
INFO - 2024-04-16 03:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:31:43 --> Pagination Class Initialized
INFO - 2024-04-16 03:31:43 --> Form Validation Class Initialized
INFO - 2024-04-16 03:31:43 --> Controller Class Initialized
INFO - 2024-04-16 03:31:43 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:43 --> Model Class Initialized
INFO - 2024-04-16 03:31:43 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:43 --> Total execution time: 0.0326
ERROR - 2024-04-16 03:31:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 03:31:55 --> Config Class Initialized
INFO - 2024-04-16 03:31:55 --> Hooks Class Initialized
DEBUG - 2024-04-16 03:31:55 --> UTF-8 Support Enabled
INFO - 2024-04-16 03:31:55 --> Utf8 Class Initialized
INFO - 2024-04-16 03:31:55 --> URI Class Initialized
DEBUG - 2024-04-16 03:31:55 --> No URI present. Default controller set.
INFO - 2024-04-16 03:31:55 --> Router Class Initialized
INFO - 2024-04-16 03:31:55 --> Output Class Initialized
INFO - 2024-04-16 03:31:55 --> Security Class Initialized
DEBUG - 2024-04-16 03:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 03:31:55 --> Input Class Initialized
INFO - 2024-04-16 03:31:55 --> Language Class Initialized
INFO - 2024-04-16 03:31:55 --> Loader Class Initialized
INFO - 2024-04-16 03:31:55 --> Helper loaded: url_helper
INFO - 2024-04-16 03:31:55 --> Helper loaded: file_helper
INFO - 2024-04-16 03:31:55 --> Helper loaded: html_helper
INFO - 2024-04-16 03:31:55 --> Helper loaded: text_helper
INFO - 2024-04-16 03:31:55 --> Helper loaded: form_helper
INFO - 2024-04-16 03:31:55 --> Helper loaded: lang_helper
INFO - 2024-04-16 03:31:55 --> Helper loaded: security_helper
INFO - 2024-04-16 03:31:55 --> Helper loaded: cookie_helper
INFO - 2024-04-16 03:31:55 --> Database Driver Class Initialized
INFO - 2024-04-16 03:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 03:31:55 --> Parser Class Initialized
INFO - 2024-04-16 03:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 03:31:55 --> Pagination Class Initialized
INFO - 2024-04-16 03:31:55 --> Form Validation Class Initialized
INFO - 2024-04-16 03:31:55 --> Controller Class Initialized
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
DEBUG - 2024-04-16 03:31:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 03:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
INFO - 2024-04-16 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 03:31:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 03:31:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 03:31:55 --> Model Class Initialized
INFO - 2024-04-16 03:31:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 03:31:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 03:31:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 03:31:56 --> Final output sent to browser
DEBUG - 2024-04-16 03:31:56 --> Total execution time: 0.3821
ERROR - 2024-04-16 07:35:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 07:35:15 --> Config Class Initialized
INFO - 2024-04-16 07:35:15 --> Hooks Class Initialized
DEBUG - 2024-04-16 07:35:15 --> UTF-8 Support Enabled
INFO - 2024-04-16 07:35:15 --> Utf8 Class Initialized
INFO - 2024-04-16 07:35:15 --> URI Class Initialized
DEBUG - 2024-04-16 07:35:15 --> No URI present. Default controller set.
INFO - 2024-04-16 07:35:15 --> Router Class Initialized
INFO - 2024-04-16 07:35:15 --> Output Class Initialized
INFO - 2024-04-16 07:35:15 --> Security Class Initialized
DEBUG - 2024-04-16 07:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 07:35:15 --> Input Class Initialized
INFO - 2024-04-16 07:35:15 --> Language Class Initialized
INFO - 2024-04-16 07:35:15 --> Loader Class Initialized
INFO - 2024-04-16 07:35:15 --> Helper loaded: url_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: file_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: html_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: text_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: form_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: lang_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: security_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: cookie_helper
INFO - 2024-04-16 07:35:15 --> Database Driver Class Initialized
INFO - 2024-04-16 07:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 07:35:15 --> Parser Class Initialized
INFO - 2024-04-16 07:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 07:35:15 --> Pagination Class Initialized
INFO - 2024-04-16 07:35:15 --> Form Validation Class Initialized
INFO - 2024-04-16 07:35:15 --> Controller Class Initialized
INFO - 2024-04-16 07:35:15 --> Model Class Initialized
DEBUG - 2024-04-16 07:35:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-16 07:35:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 07:35:15 --> Config Class Initialized
INFO - 2024-04-16 07:35:15 --> Hooks Class Initialized
DEBUG - 2024-04-16 07:35:15 --> UTF-8 Support Enabled
INFO - 2024-04-16 07:35:15 --> Utf8 Class Initialized
INFO - 2024-04-16 07:35:15 --> URI Class Initialized
INFO - 2024-04-16 07:35:15 --> Router Class Initialized
INFO - 2024-04-16 07:35:15 --> Output Class Initialized
INFO - 2024-04-16 07:35:15 --> Security Class Initialized
DEBUG - 2024-04-16 07:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 07:35:15 --> Input Class Initialized
INFO - 2024-04-16 07:35:15 --> Language Class Initialized
INFO - 2024-04-16 07:35:15 --> Loader Class Initialized
INFO - 2024-04-16 07:35:15 --> Helper loaded: url_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: file_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: html_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: text_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: form_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: lang_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: security_helper
INFO - 2024-04-16 07:35:15 --> Helper loaded: cookie_helper
INFO - 2024-04-16 07:35:15 --> Database Driver Class Initialized
INFO - 2024-04-16 07:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 07:35:15 --> Parser Class Initialized
INFO - 2024-04-16 07:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 07:35:15 --> Pagination Class Initialized
INFO - 2024-04-16 07:35:15 --> Form Validation Class Initialized
INFO - 2024-04-16 07:35:15 --> Controller Class Initialized
INFO - 2024-04-16 07:35:15 --> Model Class Initialized
DEBUG - 2024-04-16 07:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:35:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-16 07:35:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:35:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 07:35:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 07:35:15 --> Model Class Initialized
INFO - 2024-04-16 07:35:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 07:35:15 --> Final output sent to browser
DEBUG - 2024-04-16 07:35:15 --> Total execution time: 0.0320
ERROR - 2024-04-16 07:35:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 07:35:26 --> Config Class Initialized
INFO - 2024-04-16 07:35:26 --> Hooks Class Initialized
DEBUG - 2024-04-16 07:35:26 --> UTF-8 Support Enabled
INFO - 2024-04-16 07:35:26 --> Utf8 Class Initialized
INFO - 2024-04-16 07:35:26 --> URI Class Initialized
INFO - 2024-04-16 07:35:26 --> Router Class Initialized
INFO - 2024-04-16 07:35:26 --> Output Class Initialized
INFO - 2024-04-16 07:35:26 --> Security Class Initialized
DEBUG - 2024-04-16 07:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 07:35:26 --> Input Class Initialized
INFO - 2024-04-16 07:35:26 --> Language Class Initialized
INFO - 2024-04-16 07:35:26 --> Loader Class Initialized
INFO - 2024-04-16 07:35:26 --> Helper loaded: url_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: file_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: html_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: text_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: form_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: lang_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: security_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: cookie_helper
INFO - 2024-04-16 07:35:26 --> Database Driver Class Initialized
INFO - 2024-04-16 07:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 07:35:26 --> Parser Class Initialized
INFO - 2024-04-16 07:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 07:35:26 --> Pagination Class Initialized
INFO - 2024-04-16 07:35:26 --> Form Validation Class Initialized
INFO - 2024-04-16 07:35:26 --> Controller Class Initialized
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
DEBUG - 2024-04-16 07:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
INFO - 2024-04-16 07:35:26 --> Final output sent to browser
DEBUG - 2024-04-16 07:35:26 --> Total execution time: 0.0196
ERROR - 2024-04-16 07:35:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 07:35:26 --> Config Class Initialized
INFO - 2024-04-16 07:35:26 --> Hooks Class Initialized
DEBUG - 2024-04-16 07:35:26 --> UTF-8 Support Enabled
INFO - 2024-04-16 07:35:26 --> Utf8 Class Initialized
INFO - 2024-04-16 07:35:26 --> URI Class Initialized
DEBUG - 2024-04-16 07:35:26 --> No URI present. Default controller set.
INFO - 2024-04-16 07:35:26 --> Router Class Initialized
INFO - 2024-04-16 07:35:26 --> Output Class Initialized
INFO - 2024-04-16 07:35:26 --> Security Class Initialized
DEBUG - 2024-04-16 07:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 07:35:26 --> Input Class Initialized
INFO - 2024-04-16 07:35:26 --> Language Class Initialized
INFO - 2024-04-16 07:35:26 --> Loader Class Initialized
INFO - 2024-04-16 07:35:26 --> Helper loaded: url_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: file_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: html_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: text_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: form_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: lang_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: security_helper
INFO - 2024-04-16 07:35:26 --> Helper loaded: cookie_helper
INFO - 2024-04-16 07:35:26 --> Database Driver Class Initialized
INFO - 2024-04-16 07:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 07:35:26 --> Parser Class Initialized
INFO - 2024-04-16 07:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 07:35:26 --> Pagination Class Initialized
INFO - 2024-04-16 07:35:26 --> Form Validation Class Initialized
INFO - 2024-04-16 07:35:26 --> Controller Class Initialized
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
DEBUG - 2024-04-16 07:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
DEBUG - 2024-04-16 07:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
DEBUG - 2024-04-16 07:35:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 07:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
INFO - 2024-04-16 07:35:26 --> Model Class Initialized
INFO - 2024-04-16 07:35:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 07:35:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:35:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 07:35:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 07:35:27 --> Model Class Initialized
INFO - 2024-04-16 07:35:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 07:35:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 07:35:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 07:35:27 --> Final output sent to browser
DEBUG - 2024-04-16 07:35:27 --> Total execution time: 0.3739
ERROR - 2024-04-16 07:35:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 07:35:59 --> Config Class Initialized
INFO - 2024-04-16 07:35:59 --> Hooks Class Initialized
DEBUG - 2024-04-16 07:35:59 --> UTF-8 Support Enabled
INFO - 2024-04-16 07:35:59 --> Utf8 Class Initialized
INFO - 2024-04-16 07:35:59 --> URI Class Initialized
INFO - 2024-04-16 07:35:59 --> Router Class Initialized
INFO - 2024-04-16 07:35:59 --> Output Class Initialized
INFO - 2024-04-16 07:35:59 --> Security Class Initialized
DEBUG - 2024-04-16 07:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 07:35:59 --> Input Class Initialized
INFO - 2024-04-16 07:35:59 --> Language Class Initialized
INFO - 2024-04-16 07:35:59 --> Loader Class Initialized
INFO - 2024-04-16 07:35:59 --> Helper loaded: url_helper
INFO - 2024-04-16 07:35:59 --> Helper loaded: file_helper
INFO - 2024-04-16 07:35:59 --> Helper loaded: html_helper
INFO - 2024-04-16 07:35:59 --> Helper loaded: text_helper
INFO - 2024-04-16 07:35:59 --> Helper loaded: form_helper
INFO - 2024-04-16 07:35:59 --> Helper loaded: lang_helper
INFO - 2024-04-16 07:35:59 --> Helper loaded: security_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: cookie_helper
INFO - 2024-04-16 07:36:00 --> Database Driver Class Initialized
INFO - 2024-04-16 07:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 07:36:00 --> Parser Class Initialized
INFO - 2024-04-16 07:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 07:36:00 --> Pagination Class Initialized
INFO - 2024-04-16 07:36:00 --> Form Validation Class Initialized
INFO - 2024-04-16 07:36:00 --> Controller Class Initialized
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
DEBUG - 2024-04-16 07:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-16 07:36:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 07:36:00 --> Final output sent to browser
DEBUG - 2024-04-16 07:36:00 --> Total execution time: 0.0315
ERROR - 2024-04-16 07:36:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 07:36:00 --> Config Class Initialized
INFO - 2024-04-16 07:36:00 --> Hooks Class Initialized
DEBUG - 2024-04-16 07:36:00 --> UTF-8 Support Enabled
INFO - 2024-04-16 07:36:00 --> Utf8 Class Initialized
INFO - 2024-04-16 07:36:00 --> URI Class Initialized
INFO - 2024-04-16 07:36:00 --> Router Class Initialized
INFO - 2024-04-16 07:36:00 --> Output Class Initialized
INFO - 2024-04-16 07:36:00 --> Security Class Initialized
DEBUG - 2024-04-16 07:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 07:36:00 --> Input Class Initialized
INFO - 2024-04-16 07:36:00 --> Language Class Initialized
INFO - 2024-04-16 07:36:00 --> Loader Class Initialized
INFO - 2024-04-16 07:36:00 --> Helper loaded: url_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: file_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: html_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: text_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: form_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: lang_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: security_helper
INFO - 2024-04-16 07:36:00 --> Helper loaded: cookie_helper
INFO - 2024-04-16 07:36:00 --> Database Driver Class Initialized
INFO - 2024-04-16 07:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 07:36:00 --> Parser Class Initialized
INFO - 2024-04-16 07:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 07:36:00 --> Pagination Class Initialized
INFO - 2024-04-16 07:36:00 --> Form Validation Class Initialized
INFO - 2024-04-16 07:36:00 --> Controller Class Initialized
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
DEBUG - 2024-04-16 07:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
DEBUG - 2024-04-16 07:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
DEBUG - 2024-04-16 07:36:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 07:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 07:36:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 07:36:00 --> Model Class Initialized
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 07:36:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 07:36:00 --> Final output sent to browser
DEBUG - 2024-04-16 07:36:00 --> Total execution time: 0.3598
ERROR - 2024-04-16 08:16:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 08:16:51 --> Config Class Initialized
INFO - 2024-04-16 08:16:51 --> Hooks Class Initialized
DEBUG - 2024-04-16 08:16:51 --> UTF-8 Support Enabled
INFO - 2024-04-16 08:16:51 --> Utf8 Class Initialized
INFO - 2024-04-16 08:16:51 --> URI Class Initialized
DEBUG - 2024-04-16 08:16:51 --> No URI present. Default controller set.
INFO - 2024-04-16 08:16:51 --> Router Class Initialized
INFO - 2024-04-16 08:16:51 --> Output Class Initialized
INFO - 2024-04-16 08:16:51 --> Security Class Initialized
DEBUG - 2024-04-16 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 08:16:51 --> Input Class Initialized
INFO - 2024-04-16 08:16:51 --> Language Class Initialized
INFO - 2024-04-16 08:16:51 --> Loader Class Initialized
INFO - 2024-04-16 08:16:51 --> Helper loaded: url_helper
INFO - 2024-04-16 08:16:51 --> Helper loaded: file_helper
INFO - 2024-04-16 08:16:51 --> Helper loaded: html_helper
INFO - 2024-04-16 08:16:51 --> Helper loaded: text_helper
INFO - 2024-04-16 08:16:51 --> Helper loaded: form_helper
INFO - 2024-04-16 08:16:51 --> Helper loaded: lang_helper
INFO - 2024-04-16 08:16:51 --> Helper loaded: security_helper
INFO - 2024-04-16 08:16:51 --> Helper loaded: cookie_helper
INFO - 2024-04-16 08:16:51 --> Database Driver Class Initialized
INFO - 2024-04-16 08:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 08:16:51 --> Parser Class Initialized
INFO - 2024-04-16 08:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 08:16:51 --> Pagination Class Initialized
INFO - 2024-04-16 08:16:51 --> Form Validation Class Initialized
INFO - 2024-04-16 08:16:51 --> Controller Class Initialized
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
DEBUG - 2024-04-16 08:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
DEBUG - 2024-04-16 08:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
DEBUG - 2024-04-16 08:16:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 08:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
INFO - 2024-04-16 08:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 08:16:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 08:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 08:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 08:16:51 --> Model Class Initialized
INFO - 2024-04-16 08:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 08:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 08:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 08:16:52 --> Final output sent to browser
DEBUG - 2024-04-16 08:16:52 --> Total execution time: 0.3727
ERROR - 2024-04-16 09:06:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:06:59 --> Config Class Initialized
INFO - 2024-04-16 09:06:59 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:06:59 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:06:59 --> Utf8 Class Initialized
INFO - 2024-04-16 09:06:59 --> URI Class Initialized
DEBUG - 2024-04-16 09:06:59 --> No URI present. Default controller set.
INFO - 2024-04-16 09:06:59 --> Router Class Initialized
INFO - 2024-04-16 09:06:59 --> Output Class Initialized
INFO - 2024-04-16 09:06:59 --> Security Class Initialized
DEBUG - 2024-04-16 09:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:06:59 --> Input Class Initialized
INFO - 2024-04-16 09:06:59 --> Language Class Initialized
INFO - 2024-04-16 09:06:59 --> Loader Class Initialized
INFO - 2024-04-16 09:06:59 --> Helper loaded: url_helper
INFO - 2024-04-16 09:06:59 --> Helper loaded: file_helper
INFO - 2024-04-16 09:06:59 --> Helper loaded: html_helper
INFO - 2024-04-16 09:06:59 --> Helper loaded: text_helper
INFO - 2024-04-16 09:06:59 --> Helper loaded: form_helper
INFO - 2024-04-16 09:06:59 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:06:59 --> Helper loaded: security_helper
INFO - 2024-04-16 09:06:59 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:06:59 --> Database Driver Class Initialized
INFO - 2024-04-16 09:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:06:59 --> Parser Class Initialized
INFO - 2024-04-16 09:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:06:59 --> Pagination Class Initialized
INFO - 2024-04-16 09:06:59 --> Form Validation Class Initialized
INFO - 2024-04-16 09:06:59 --> Controller Class Initialized
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
DEBUG - 2024-04-16 09:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
DEBUG - 2024-04-16 09:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
DEBUG - 2024-04-16 09:06:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
INFO - 2024-04-16 09:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 09:06:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:06:59 --> Model Class Initialized
INFO - 2024-04-16 09:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:06:59 --> Final output sent to browser
DEBUG - 2024-04-16 09:06:59 --> Total execution time: 0.3725
ERROR - 2024-04-16 09:07:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:07:09 --> Config Class Initialized
INFO - 2024-04-16 09:07:09 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:07:09 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:07:09 --> Utf8 Class Initialized
INFO - 2024-04-16 09:07:09 --> URI Class Initialized
INFO - 2024-04-16 09:07:09 --> Router Class Initialized
INFO - 2024-04-16 09:07:09 --> Output Class Initialized
INFO - 2024-04-16 09:07:09 --> Security Class Initialized
DEBUG - 2024-04-16 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:07:09 --> Input Class Initialized
INFO - 2024-04-16 09:07:09 --> Language Class Initialized
INFO - 2024-04-16 09:07:09 --> Loader Class Initialized
INFO - 2024-04-16 09:07:09 --> Helper loaded: url_helper
INFO - 2024-04-16 09:07:09 --> Helper loaded: file_helper
INFO - 2024-04-16 09:07:09 --> Helper loaded: html_helper
INFO - 2024-04-16 09:07:09 --> Helper loaded: text_helper
INFO - 2024-04-16 09:07:09 --> Helper loaded: form_helper
INFO - 2024-04-16 09:07:09 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:07:09 --> Helper loaded: security_helper
INFO - 2024-04-16 09:07:09 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:07:09 --> Database Driver Class Initialized
INFO - 2024-04-16 09:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:07:09 --> Parser Class Initialized
INFO - 2024-04-16 09:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:07:09 --> Pagination Class Initialized
INFO - 2024-04-16 09:07:09 --> Form Validation Class Initialized
INFO - 2024-04-16 09:07:09 --> Controller Class Initialized
INFO - 2024-04-16 09:07:09 --> Model Class Initialized
DEBUG - 2024-04-16 09:07:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:07:09 --> Model Class Initialized
INFO - 2024-04-16 09:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-04-16 09:07:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:07:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:07:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:07:10 --> Model Class Initialized
INFO - 2024-04-16 09:07:10 --> Model Class Initialized
INFO - 2024-04-16 09:07:10 --> Model Class Initialized
INFO - 2024-04-16 09:07:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:07:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:07:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:07:10 --> Final output sent to browser
DEBUG - 2024-04-16 09:07:10 --> Total execution time: 0.2139
ERROR - 2024-04-16 09:07:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:07:11 --> Config Class Initialized
INFO - 2024-04-16 09:07:11 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:07:11 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:07:11 --> Utf8 Class Initialized
INFO - 2024-04-16 09:07:11 --> URI Class Initialized
INFO - 2024-04-16 09:07:11 --> Router Class Initialized
INFO - 2024-04-16 09:07:11 --> Output Class Initialized
INFO - 2024-04-16 09:07:11 --> Security Class Initialized
DEBUG - 2024-04-16 09:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:07:11 --> Input Class Initialized
INFO - 2024-04-16 09:07:11 --> Language Class Initialized
INFO - 2024-04-16 09:07:11 --> Loader Class Initialized
INFO - 2024-04-16 09:07:11 --> Helper loaded: url_helper
INFO - 2024-04-16 09:07:11 --> Helper loaded: file_helper
INFO - 2024-04-16 09:07:11 --> Helper loaded: html_helper
INFO - 2024-04-16 09:07:11 --> Helper loaded: text_helper
INFO - 2024-04-16 09:07:11 --> Helper loaded: form_helper
INFO - 2024-04-16 09:07:11 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:07:11 --> Helper loaded: security_helper
INFO - 2024-04-16 09:07:11 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:07:11 --> Database Driver Class Initialized
INFO - 2024-04-16 09:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:07:11 --> Parser Class Initialized
INFO - 2024-04-16 09:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:07:11 --> Pagination Class Initialized
INFO - 2024-04-16 09:07:11 --> Form Validation Class Initialized
INFO - 2024-04-16 09:07:11 --> Controller Class Initialized
INFO - 2024-04-16 09:07:11 --> Model Class Initialized
DEBUG - 2024-04-16 09:07:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:07:11 --> Model Class Initialized
INFO - 2024-04-16 09:07:11 --> Final output sent to browser
DEBUG - 2024-04-16 09:07:11 --> Total execution time: 0.2585
ERROR - 2024-04-16 09:07:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:07:19 --> Config Class Initialized
INFO - 2024-04-16 09:07:19 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:07:19 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:07:19 --> Utf8 Class Initialized
INFO - 2024-04-16 09:07:19 --> URI Class Initialized
DEBUG - 2024-04-16 09:07:19 --> No URI present. Default controller set.
INFO - 2024-04-16 09:07:19 --> Router Class Initialized
INFO - 2024-04-16 09:07:19 --> Output Class Initialized
INFO - 2024-04-16 09:07:19 --> Security Class Initialized
DEBUG - 2024-04-16 09:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:07:19 --> Input Class Initialized
INFO - 2024-04-16 09:07:19 --> Language Class Initialized
INFO - 2024-04-16 09:07:19 --> Loader Class Initialized
INFO - 2024-04-16 09:07:19 --> Helper loaded: url_helper
INFO - 2024-04-16 09:07:19 --> Helper loaded: file_helper
INFO - 2024-04-16 09:07:19 --> Helper loaded: html_helper
INFO - 2024-04-16 09:07:19 --> Helper loaded: text_helper
INFO - 2024-04-16 09:07:19 --> Helper loaded: form_helper
INFO - 2024-04-16 09:07:19 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:07:19 --> Helper loaded: security_helper
INFO - 2024-04-16 09:07:19 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:07:19 --> Database Driver Class Initialized
INFO - 2024-04-16 09:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:07:19 --> Parser Class Initialized
INFO - 2024-04-16 09:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:07:19 --> Pagination Class Initialized
INFO - 2024-04-16 09:07:19 --> Form Validation Class Initialized
INFO - 2024-04-16 09:07:19 --> Controller Class Initialized
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
DEBUG - 2024-04-16 09:07:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
DEBUG - 2024-04-16 09:07:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
DEBUG - 2024-04-16 09:07:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:07:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
INFO - 2024-04-16 09:07:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 09:07:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:07:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:07:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:07:19 --> Model Class Initialized
INFO - 2024-04-16 09:07:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:07:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:07:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:07:19 --> Final output sent to browser
DEBUG - 2024-04-16 09:07:19 --> Total execution time: 0.3697
ERROR - 2024-04-16 09:42:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:42:00 --> Config Class Initialized
INFO - 2024-04-16 09:42:00 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:42:00 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:42:00 --> Utf8 Class Initialized
INFO - 2024-04-16 09:42:00 --> URI Class Initialized
DEBUG - 2024-04-16 09:42:00 --> No URI present. Default controller set.
INFO - 2024-04-16 09:42:00 --> Router Class Initialized
INFO - 2024-04-16 09:42:00 --> Output Class Initialized
INFO - 2024-04-16 09:42:00 --> Security Class Initialized
DEBUG - 2024-04-16 09:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:42:00 --> Input Class Initialized
INFO - 2024-04-16 09:42:00 --> Language Class Initialized
INFO - 2024-04-16 09:42:00 --> Loader Class Initialized
INFO - 2024-04-16 09:42:00 --> Helper loaded: url_helper
INFO - 2024-04-16 09:42:00 --> Helper loaded: file_helper
INFO - 2024-04-16 09:42:00 --> Helper loaded: html_helper
INFO - 2024-04-16 09:42:00 --> Helper loaded: text_helper
INFO - 2024-04-16 09:42:00 --> Helper loaded: form_helper
INFO - 2024-04-16 09:42:00 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:42:00 --> Helper loaded: security_helper
INFO - 2024-04-16 09:42:00 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:42:00 --> Database Driver Class Initialized
INFO - 2024-04-16 09:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:42:00 --> Parser Class Initialized
INFO - 2024-04-16 09:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:42:00 --> Pagination Class Initialized
INFO - 2024-04-16 09:42:00 --> Form Validation Class Initialized
INFO - 2024-04-16 09:42:00 --> Controller Class Initialized
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
INFO - 2024-04-16 09:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 09:42:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:42:00 --> Model Class Initialized
INFO - 2024-04-16 09:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:42:00 --> Final output sent to browser
DEBUG - 2024-04-16 09:42:00 --> Total execution time: 0.3638
ERROR - 2024-04-16 09:42:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:42:14 --> Config Class Initialized
INFO - 2024-04-16 09:42:14 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:42:14 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:42:14 --> Utf8 Class Initialized
INFO - 2024-04-16 09:42:14 --> URI Class Initialized
INFO - 2024-04-16 09:42:14 --> Router Class Initialized
INFO - 2024-04-16 09:42:14 --> Output Class Initialized
INFO - 2024-04-16 09:42:14 --> Security Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:42:14 --> Input Class Initialized
INFO - 2024-04-16 09:42:14 --> Language Class Initialized
INFO - 2024-04-16 09:42:14 --> Loader Class Initialized
INFO - 2024-04-16 09:42:14 --> Helper loaded: url_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: file_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: html_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: text_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: form_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: security_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:42:14 --> Database Driver Class Initialized
INFO - 2024-04-16 09:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:42:14 --> Parser Class Initialized
INFO - 2024-04-16 09:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:42:14 --> Pagination Class Initialized
INFO - 2024-04-16 09:42:14 --> Form Validation Class Initialized
INFO - 2024-04-16 09:42:14 --> Controller Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-04-16 09:42:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
ERROR - 2024-04-16 09:42:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:42:14 --> Config Class Initialized
INFO - 2024-04-16 09:42:14 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:42:14 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:42:14 --> Utf8 Class Initialized
INFO - 2024-04-16 09:42:14 --> URI Class Initialized
INFO - 2024-04-16 09:42:14 --> Router Class Initialized
INFO - 2024-04-16 09:42:14 --> Output Class Initialized
INFO - 2024-04-16 09:42:14 --> Security Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:42:14 --> Input Class Initialized
INFO - 2024-04-16 09:42:14 --> Language Class Initialized
INFO - 2024-04-16 09:42:14 --> Loader Class Initialized
INFO - 2024-04-16 09:42:14 --> Helper loaded: url_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: file_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: html_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: text_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: form_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: security_helper
INFO - 2024-04-16 09:42:14 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:42:14 --> Database Driver Class Initialized
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:42:14 --> Final output sent to browser
DEBUG - 2024-04-16 09:42:14 --> Total execution time: 0.2153
INFO - 2024-04-16 09:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:42:14 --> Parser Class Initialized
INFO - 2024-04-16 09:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:42:14 --> Pagination Class Initialized
INFO - 2024-04-16 09:42:14 --> Form Validation Class Initialized
INFO - 2024-04-16 09:42:14 --> Controller Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:14 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-04-16 09:42:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
INFO - 2024-04-16 09:42:14 --> Model Class Initialized
INFO - 2024-04-16 09:42:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:42:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:42:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:42:15 --> Final output sent to browser
DEBUG - 2024-04-16 09:42:15 --> Total execution time: 0.3419
ERROR - 2024-04-16 09:42:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:42:16 --> Config Class Initialized
INFO - 2024-04-16 09:42:16 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:42:16 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:42:16 --> Utf8 Class Initialized
INFO - 2024-04-16 09:42:16 --> URI Class Initialized
INFO - 2024-04-16 09:42:16 --> Router Class Initialized
INFO - 2024-04-16 09:42:16 --> Output Class Initialized
INFO - 2024-04-16 09:42:16 --> Security Class Initialized
DEBUG - 2024-04-16 09:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:42:16 --> Input Class Initialized
INFO - 2024-04-16 09:42:16 --> Language Class Initialized
INFO - 2024-04-16 09:42:16 --> Loader Class Initialized
INFO - 2024-04-16 09:42:16 --> Helper loaded: url_helper
INFO - 2024-04-16 09:42:16 --> Helper loaded: file_helper
INFO - 2024-04-16 09:42:16 --> Helper loaded: html_helper
INFO - 2024-04-16 09:42:16 --> Helper loaded: text_helper
INFO - 2024-04-16 09:42:16 --> Helper loaded: form_helper
INFO - 2024-04-16 09:42:16 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:42:16 --> Helper loaded: security_helper
INFO - 2024-04-16 09:42:16 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:42:16 --> Database Driver Class Initialized
INFO - 2024-04-16 09:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:42:16 --> Parser Class Initialized
INFO - 2024-04-16 09:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:42:16 --> Pagination Class Initialized
INFO - 2024-04-16 09:42:16 --> Form Validation Class Initialized
INFO - 2024-04-16 09:42:16 --> Controller Class Initialized
DEBUG - 2024-04-16 09:42:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:16 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:16 --> Model Class Initialized
INFO - 2024-04-16 09:42:16 --> Final output sent to browser
DEBUG - 2024-04-16 09:42:16 --> Total execution time: 0.0261
ERROR - 2024-04-16 09:42:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:42:24 --> Config Class Initialized
INFO - 2024-04-16 09:42:24 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:42:24 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:42:24 --> Utf8 Class Initialized
INFO - 2024-04-16 09:42:24 --> URI Class Initialized
INFO - 2024-04-16 09:42:24 --> Router Class Initialized
INFO - 2024-04-16 09:42:24 --> Output Class Initialized
INFO - 2024-04-16 09:42:24 --> Security Class Initialized
DEBUG - 2024-04-16 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:42:24 --> Input Class Initialized
INFO - 2024-04-16 09:42:24 --> Language Class Initialized
INFO - 2024-04-16 09:42:24 --> Loader Class Initialized
INFO - 2024-04-16 09:42:24 --> Helper loaded: url_helper
INFO - 2024-04-16 09:42:24 --> Helper loaded: file_helper
INFO - 2024-04-16 09:42:24 --> Helper loaded: html_helper
INFO - 2024-04-16 09:42:24 --> Helper loaded: text_helper
INFO - 2024-04-16 09:42:24 --> Helper loaded: form_helper
INFO - 2024-04-16 09:42:24 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:42:24 --> Helper loaded: security_helper
INFO - 2024-04-16 09:42:24 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:42:24 --> Database Driver Class Initialized
INFO - 2024-04-16 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:42:24 --> Parser Class Initialized
INFO - 2024-04-16 09:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:42:24 --> Pagination Class Initialized
INFO - 2024-04-16 09:42:24 --> Form Validation Class Initialized
INFO - 2024-04-16 09:42:24 --> Controller Class Initialized
DEBUG - 2024-04-16 09:42:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:24 --> Model Class Initialized
DEBUG - 2024-04-16 09:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:42:24 --> Model Class Initialized
INFO - 2024-04-16 09:42:24 --> Final output sent to browser
DEBUG - 2024-04-16 09:42:24 --> Total execution time: 0.0433
ERROR - 2024-04-16 09:46:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:46:20 --> Config Class Initialized
INFO - 2024-04-16 09:46:20 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:46:20 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:46:20 --> Utf8 Class Initialized
INFO - 2024-04-16 09:46:20 --> URI Class Initialized
DEBUG - 2024-04-16 09:46:20 --> No URI present. Default controller set.
INFO - 2024-04-16 09:46:20 --> Router Class Initialized
INFO - 2024-04-16 09:46:20 --> Output Class Initialized
INFO - 2024-04-16 09:46:20 --> Security Class Initialized
DEBUG - 2024-04-16 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:46:20 --> Input Class Initialized
INFO - 2024-04-16 09:46:20 --> Language Class Initialized
INFO - 2024-04-16 09:46:20 --> Loader Class Initialized
INFO - 2024-04-16 09:46:20 --> Helper loaded: url_helper
INFO - 2024-04-16 09:46:20 --> Helper loaded: file_helper
INFO - 2024-04-16 09:46:20 --> Helper loaded: html_helper
INFO - 2024-04-16 09:46:20 --> Helper loaded: text_helper
INFO - 2024-04-16 09:46:20 --> Helper loaded: form_helper
INFO - 2024-04-16 09:46:20 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:46:20 --> Helper loaded: security_helper
INFO - 2024-04-16 09:46:20 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:46:20 --> Database Driver Class Initialized
INFO - 2024-04-16 09:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:46:20 --> Parser Class Initialized
INFO - 2024-04-16 09:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:46:20 --> Pagination Class Initialized
INFO - 2024-04-16 09:46:20 --> Form Validation Class Initialized
INFO - 2024-04-16 09:46:20 --> Controller Class Initialized
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
DEBUG - 2024-04-16 09:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
DEBUG - 2024-04-16 09:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
DEBUG - 2024-04-16 09:46:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
INFO - 2024-04-16 09:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 09:46:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:46:20 --> Model Class Initialized
INFO - 2024-04-16 09:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:46:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:46:20 --> Final output sent to browser
DEBUG - 2024-04-16 09:46:20 --> Total execution time: 0.3704
ERROR - 2024-04-16 09:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:46:29 --> Config Class Initialized
INFO - 2024-04-16 09:46:29 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:46:29 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:46:29 --> Utf8 Class Initialized
INFO - 2024-04-16 09:46:29 --> URI Class Initialized
INFO - 2024-04-16 09:46:29 --> Router Class Initialized
INFO - 2024-04-16 09:46:29 --> Output Class Initialized
INFO - 2024-04-16 09:46:29 --> Security Class Initialized
DEBUG - 2024-04-16 09:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:46:29 --> Input Class Initialized
INFO - 2024-04-16 09:46:29 --> Language Class Initialized
INFO - 2024-04-16 09:46:29 --> Loader Class Initialized
INFO - 2024-04-16 09:46:29 --> Helper loaded: url_helper
INFO - 2024-04-16 09:46:29 --> Helper loaded: file_helper
INFO - 2024-04-16 09:46:29 --> Helper loaded: html_helper
INFO - 2024-04-16 09:46:29 --> Helper loaded: text_helper
INFO - 2024-04-16 09:46:29 --> Helper loaded: form_helper
INFO - 2024-04-16 09:46:29 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:46:29 --> Helper loaded: security_helper
INFO - 2024-04-16 09:46:29 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:46:29 --> Database Driver Class Initialized
INFO - 2024-04-16 09:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:46:29 --> Parser Class Initialized
INFO - 2024-04-16 09:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:46:29 --> Pagination Class Initialized
INFO - 2024-04-16 09:46:29 --> Form Validation Class Initialized
INFO - 2024-04-16 09:46:29 --> Controller Class Initialized
DEBUG - 2024-04-16 09:46:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:29 --> Model Class Initialized
DEBUG - 2024-04-16 09:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:29 --> Model Class Initialized
DEBUG - 2024-04-16 09:46:29 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:29 --> Model Class Initialized
INFO - 2024-04-16 09:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-04-16 09:46:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 09:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 09:46:29 --> Model Class Initialized
INFO - 2024-04-16 09:46:29 --> Model Class Initialized
INFO - 2024-04-16 09:46:29 --> Model Class Initialized
INFO - 2024-04-16 09:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 09:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 09:46:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 09:46:29 --> Final output sent to browser
DEBUG - 2024-04-16 09:46:29 --> Total execution time: 0.2064
ERROR - 2024-04-16 09:46:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:46:30 --> Config Class Initialized
INFO - 2024-04-16 09:46:30 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:46:30 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:46:30 --> Utf8 Class Initialized
INFO - 2024-04-16 09:46:30 --> URI Class Initialized
INFO - 2024-04-16 09:46:30 --> Router Class Initialized
INFO - 2024-04-16 09:46:30 --> Output Class Initialized
INFO - 2024-04-16 09:46:30 --> Security Class Initialized
DEBUG - 2024-04-16 09:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:46:30 --> Input Class Initialized
INFO - 2024-04-16 09:46:30 --> Language Class Initialized
INFO - 2024-04-16 09:46:30 --> Loader Class Initialized
INFO - 2024-04-16 09:46:30 --> Helper loaded: url_helper
INFO - 2024-04-16 09:46:30 --> Helper loaded: file_helper
INFO - 2024-04-16 09:46:30 --> Helper loaded: html_helper
INFO - 2024-04-16 09:46:30 --> Helper loaded: text_helper
INFO - 2024-04-16 09:46:30 --> Helper loaded: form_helper
INFO - 2024-04-16 09:46:30 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:46:30 --> Helper loaded: security_helper
INFO - 2024-04-16 09:46:30 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:46:30 --> Database Driver Class Initialized
INFO - 2024-04-16 09:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:46:30 --> Parser Class Initialized
INFO - 2024-04-16 09:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:46:30 --> Pagination Class Initialized
INFO - 2024-04-16 09:46:30 --> Form Validation Class Initialized
INFO - 2024-04-16 09:46:30 --> Controller Class Initialized
DEBUG - 2024-04-16 09:46:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:30 --> Model Class Initialized
DEBUG - 2024-04-16 09:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:30 --> Model Class Initialized
INFO - 2024-04-16 09:46:30 --> Final output sent to browser
DEBUG - 2024-04-16 09:46:30 --> Total execution time: 0.0219
ERROR - 2024-04-16 09:46:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 09:46:39 --> Config Class Initialized
INFO - 2024-04-16 09:46:39 --> Hooks Class Initialized
DEBUG - 2024-04-16 09:46:39 --> UTF-8 Support Enabled
INFO - 2024-04-16 09:46:39 --> Utf8 Class Initialized
INFO - 2024-04-16 09:46:39 --> URI Class Initialized
INFO - 2024-04-16 09:46:39 --> Router Class Initialized
INFO - 2024-04-16 09:46:39 --> Output Class Initialized
INFO - 2024-04-16 09:46:39 --> Security Class Initialized
DEBUG - 2024-04-16 09:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 09:46:39 --> Input Class Initialized
INFO - 2024-04-16 09:46:39 --> Language Class Initialized
INFO - 2024-04-16 09:46:39 --> Loader Class Initialized
INFO - 2024-04-16 09:46:39 --> Helper loaded: url_helper
INFO - 2024-04-16 09:46:39 --> Helper loaded: file_helper
INFO - 2024-04-16 09:46:39 --> Helper loaded: html_helper
INFO - 2024-04-16 09:46:39 --> Helper loaded: text_helper
INFO - 2024-04-16 09:46:39 --> Helper loaded: form_helper
INFO - 2024-04-16 09:46:39 --> Helper loaded: lang_helper
INFO - 2024-04-16 09:46:39 --> Helper loaded: security_helper
INFO - 2024-04-16 09:46:39 --> Helper loaded: cookie_helper
INFO - 2024-04-16 09:46:39 --> Database Driver Class Initialized
INFO - 2024-04-16 09:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 09:46:39 --> Parser Class Initialized
INFO - 2024-04-16 09:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 09:46:39 --> Pagination Class Initialized
INFO - 2024-04-16 09:46:39 --> Form Validation Class Initialized
INFO - 2024-04-16 09:46:39 --> Controller Class Initialized
DEBUG - 2024-04-16 09:46:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 09:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:39 --> Model Class Initialized
DEBUG - 2024-04-16 09:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 09:46:39 --> Model Class Initialized
INFO - 2024-04-16 09:46:39 --> Final output sent to browser
DEBUG - 2024-04-16 09:46:39 --> Total execution time: 0.0384
ERROR - 2024-04-16 10:38:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 10:38:45 --> Config Class Initialized
INFO - 2024-04-16 10:38:45 --> Hooks Class Initialized
DEBUG - 2024-04-16 10:38:45 --> UTF-8 Support Enabled
INFO - 2024-04-16 10:38:45 --> Utf8 Class Initialized
INFO - 2024-04-16 10:38:45 --> URI Class Initialized
INFO - 2024-04-16 10:38:45 --> Router Class Initialized
INFO - 2024-04-16 10:38:45 --> Output Class Initialized
INFO - 2024-04-16 10:38:45 --> Security Class Initialized
DEBUG - 2024-04-16 10:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 10:38:45 --> Input Class Initialized
INFO - 2024-04-16 10:38:45 --> Language Class Initialized
ERROR - 2024-04-16 10:38:45 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-16 11:18:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:18:28 --> Config Class Initialized
INFO - 2024-04-16 11:18:28 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:18:28 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:18:28 --> Utf8 Class Initialized
INFO - 2024-04-16 11:18:28 --> URI Class Initialized
DEBUG - 2024-04-16 11:18:28 --> No URI present. Default controller set.
INFO - 2024-04-16 11:18:28 --> Router Class Initialized
INFO - 2024-04-16 11:18:28 --> Output Class Initialized
INFO - 2024-04-16 11:18:28 --> Security Class Initialized
DEBUG - 2024-04-16 11:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:18:28 --> Input Class Initialized
INFO - 2024-04-16 11:18:28 --> Language Class Initialized
INFO - 2024-04-16 11:18:28 --> Loader Class Initialized
INFO - 2024-04-16 11:18:28 --> Helper loaded: url_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: file_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: html_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: text_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: form_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: security_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:18:28 --> Database Driver Class Initialized
INFO - 2024-04-16 11:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:18:28 --> Parser Class Initialized
INFO - 2024-04-16 11:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:18:28 --> Pagination Class Initialized
INFO - 2024-04-16 11:18:28 --> Form Validation Class Initialized
INFO - 2024-04-16 11:18:28 --> Controller Class Initialized
INFO - 2024-04-16 11:18:28 --> Model Class Initialized
DEBUG - 2024-04-16 11:18:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-16 11:18:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:18:28 --> Config Class Initialized
INFO - 2024-04-16 11:18:28 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:18:28 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:18:28 --> Utf8 Class Initialized
INFO - 2024-04-16 11:18:28 --> URI Class Initialized
INFO - 2024-04-16 11:18:28 --> Router Class Initialized
INFO - 2024-04-16 11:18:28 --> Output Class Initialized
INFO - 2024-04-16 11:18:28 --> Security Class Initialized
DEBUG - 2024-04-16 11:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:18:28 --> Input Class Initialized
INFO - 2024-04-16 11:18:28 --> Language Class Initialized
INFO - 2024-04-16 11:18:28 --> Loader Class Initialized
INFO - 2024-04-16 11:18:28 --> Helper loaded: url_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: file_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: html_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: text_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: form_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: security_helper
INFO - 2024-04-16 11:18:28 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:18:28 --> Database Driver Class Initialized
INFO - 2024-04-16 11:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:18:28 --> Parser Class Initialized
INFO - 2024-04-16 11:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:18:28 --> Pagination Class Initialized
INFO - 2024-04-16 11:18:28 --> Form Validation Class Initialized
INFO - 2024-04-16 11:18:28 --> Controller Class Initialized
INFO - 2024-04-16 11:18:28 --> Model Class Initialized
DEBUG - 2024-04-16 11:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-16 11:18:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 11:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 11:18:29 --> Model Class Initialized
INFO - 2024-04-16 11:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 11:18:29 --> Final output sent to browser
DEBUG - 2024-04-16 11:18:29 --> Total execution time: 0.0340
ERROR - 2024-04-16 11:18:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:18:29 --> Config Class Initialized
INFO - 2024-04-16 11:18:29 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:18:29 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:18:29 --> Utf8 Class Initialized
INFO - 2024-04-16 11:18:29 --> URI Class Initialized
INFO - 2024-04-16 11:18:29 --> Router Class Initialized
INFO - 2024-04-16 11:18:29 --> Output Class Initialized
INFO - 2024-04-16 11:18:29 --> Security Class Initialized
DEBUG - 2024-04-16 11:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:18:29 --> Input Class Initialized
INFO - 2024-04-16 11:18:29 --> Language Class Initialized
ERROR - 2024-04-16 11:18:29 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2024-04-16 11:18:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:18:29 --> Config Class Initialized
INFO - 2024-04-16 11:18:29 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:18:29 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:18:29 --> Utf8 Class Initialized
INFO - 2024-04-16 11:18:29 --> URI Class Initialized
INFO - 2024-04-16 11:18:29 --> Router Class Initialized
INFO - 2024-04-16 11:18:29 --> Output Class Initialized
INFO - 2024-04-16 11:18:29 --> Security Class Initialized
DEBUG - 2024-04-16 11:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:18:29 --> Input Class Initialized
INFO - 2024-04-16 11:18:29 --> Language Class Initialized
ERROR - 2024-04-16 11:18:29 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2024-04-16 11:18:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:18:36 --> Config Class Initialized
INFO - 2024-04-16 11:18:36 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:18:36 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:18:36 --> Utf8 Class Initialized
INFO - 2024-04-16 11:18:36 --> URI Class Initialized
INFO - 2024-04-16 11:18:36 --> Router Class Initialized
INFO - 2024-04-16 11:18:36 --> Output Class Initialized
INFO - 2024-04-16 11:18:36 --> Security Class Initialized
DEBUG - 2024-04-16 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:18:36 --> Input Class Initialized
INFO - 2024-04-16 11:18:36 --> Language Class Initialized
INFO - 2024-04-16 11:18:36 --> Loader Class Initialized
INFO - 2024-04-16 11:18:36 --> Helper loaded: url_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: file_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: html_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: text_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: form_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: security_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:18:36 --> Database Driver Class Initialized
INFO - 2024-04-16 11:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:18:36 --> Parser Class Initialized
INFO - 2024-04-16 11:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:18:36 --> Pagination Class Initialized
INFO - 2024-04-16 11:18:36 --> Form Validation Class Initialized
INFO - 2024-04-16 11:18:36 --> Controller Class Initialized
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
DEBUG - 2024-04-16 11:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
INFO - 2024-04-16 11:18:36 --> Final output sent to browser
DEBUG - 2024-04-16 11:18:36 --> Total execution time: 0.0207
ERROR - 2024-04-16 11:18:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:18:36 --> Config Class Initialized
INFO - 2024-04-16 11:18:36 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:18:36 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:18:36 --> Utf8 Class Initialized
INFO - 2024-04-16 11:18:36 --> URI Class Initialized
DEBUG - 2024-04-16 11:18:36 --> No URI present. Default controller set.
INFO - 2024-04-16 11:18:36 --> Router Class Initialized
INFO - 2024-04-16 11:18:36 --> Output Class Initialized
INFO - 2024-04-16 11:18:36 --> Security Class Initialized
DEBUG - 2024-04-16 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:18:36 --> Input Class Initialized
INFO - 2024-04-16 11:18:36 --> Language Class Initialized
INFO - 2024-04-16 11:18:36 --> Loader Class Initialized
INFO - 2024-04-16 11:18:36 --> Helper loaded: url_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: file_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: html_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: text_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: form_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: security_helper
INFO - 2024-04-16 11:18:36 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:18:36 --> Database Driver Class Initialized
INFO - 2024-04-16 11:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:18:36 --> Parser Class Initialized
INFO - 2024-04-16 11:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:18:36 --> Pagination Class Initialized
INFO - 2024-04-16 11:18:36 --> Form Validation Class Initialized
INFO - 2024-04-16 11:18:36 --> Controller Class Initialized
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
DEBUG - 2024-04-16 11:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
DEBUG - 2024-04-16 11:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
DEBUG - 2024-04-16 11:18:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
INFO - 2024-04-16 11:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 11:18:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 11:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 11:18:36 --> Model Class Initialized
INFO - 2024-04-16 11:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 11:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 11:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 11:18:36 --> Final output sent to browser
DEBUG - 2024-04-16 11:18:36 --> Total execution time: 0.5943
ERROR - 2024-04-16 11:18:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:18:37 --> Config Class Initialized
INFO - 2024-04-16 11:18:37 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:18:37 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:18:37 --> Utf8 Class Initialized
INFO - 2024-04-16 11:18:37 --> URI Class Initialized
INFO - 2024-04-16 11:18:37 --> Router Class Initialized
INFO - 2024-04-16 11:18:37 --> Output Class Initialized
INFO - 2024-04-16 11:18:37 --> Security Class Initialized
DEBUG - 2024-04-16 11:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:18:37 --> Input Class Initialized
INFO - 2024-04-16 11:18:37 --> Language Class Initialized
INFO - 2024-04-16 11:18:37 --> Loader Class Initialized
INFO - 2024-04-16 11:18:37 --> Helper loaded: url_helper
INFO - 2024-04-16 11:18:37 --> Helper loaded: file_helper
INFO - 2024-04-16 11:18:37 --> Helper loaded: html_helper
INFO - 2024-04-16 11:18:37 --> Helper loaded: text_helper
INFO - 2024-04-16 11:18:37 --> Helper loaded: form_helper
INFO - 2024-04-16 11:18:37 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:18:37 --> Helper loaded: security_helper
INFO - 2024-04-16 11:18:37 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:18:37 --> Database Driver Class Initialized
INFO - 2024-04-16 11:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:18:37 --> Parser Class Initialized
INFO - 2024-04-16 11:18:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:18:37 --> Pagination Class Initialized
INFO - 2024-04-16 11:18:37 --> Form Validation Class Initialized
INFO - 2024-04-16 11:18:37 --> Controller Class Initialized
DEBUG - 2024-04-16 11:18:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:18:37 --> Model Class Initialized
INFO - 2024-04-16 11:18:37 --> Final output sent to browser
DEBUG - 2024-04-16 11:18:37 --> Total execution time: 0.0176
ERROR - 2024-04-16 11:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:19:28 --> Config Class Initialized
INFO - 2024-04-16 11:19:28 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:19:28 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:19:28 --> Utf8 Class Initialized
INFO - 2024-04-16 11:19:28 --> URI Class Initialized
INFO - 2024-04-16 11:19:28 --> Router Class Initialized
INFO - 2024-04-16 11:19:28 --> Output Class Initialized
INFO - 2024-04-16 11:19:28 --> Security Class Initialized
DEBUG - 2024-04-16 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:19:28 --> Input Class Initialized
INFO - 2024-04-16 11:19:28 --> Language Class Initialized
INFO - 2024-04-16 11:19:28 --> Loader Class Initialized
INFO - 2024-04-16 11:19:28 --> Helper loaded: url_helper
INFO - 2024-04-16 11:19:28 --> Helper loaded: file_helper
INFO - 2024-04-16 11:19:28 --> Helper loaded: html_helper
INFO - 2024-04-16 11:19:28 --> Helper loaded: text_helper
INFO - 2024-04-16 11:19:28 --> Helper loaded: form_helper
INFO - 2024-04-16 11:19:28 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:19:28 --> Helper loaded: security_helper
INFO - 2024-04-16 11:19:28 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:19:28 --> Database Driver Class Initialized
INFO - 2024-04-16 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:19:28 --> Parser Class Initialized
INFO - 2024-04-16 11:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:19:28 --> Pagination Class Initialized
INFO - 2024-04-16 11:19:28 --> Form Validation Class Initialized
INFO - 2024-04-16 11:19:28 --> Controller Class Initialized
INFO - 2024-04-16 11:19:28 --> Model Class Initialized
DEBUG - 2024-04-16 11:19:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:19:28 --> Model Class Initialized
DEBUG - 2024-04-16 11:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:19:28 --> Model Class Initialized
INFO - 2024-04-16 11:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-16 11:19:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 11:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 11:19:28 --> Model Class Initialized
INFO - 2024-04-16 11:19:28 --> Model Class Initialized
INFO - 2024-04-16 11:19:28 --> Model Class Initialized
INFO - 2024-04-16 11:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 11:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 11:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 11:19:28 --> Final output sent to browser
DEBUG - 2024-04-16 11:19:28 --> Total execution time: 0.2921
ERROR - 2024-04-16 11:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:19:29 --> Config Class Initialized
INFO - 2024-04-16 11:19:29 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:19:29 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:19:29 --> Utf8 Class Initialized
INFO - 2024-04-16 11:19:29 --> URI Class Initialized
INFO - 2024-04-16 11:19:29 --> Router Class Initialized
INFO - 2024-04-16 11:19:29 --> Output Class Initialized
INFO - 2024-04-16 11:19:29 --> Security Class Initialized
DEBUG - 2024-04-16 11:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:19:29 --> Input Class Initialized
INFO - 2024-04-16 11:19:29 --> Language Class Initialized
INFO - 2024-04-16 11:19:29 --> Loader Class Initialized
INFO - 2024-04-16 11:19:29 --> Helper loaded: url_helper
INFO - 2024-04-16 11:19:29 --> Helper loaded: file_helper
INFO - 2024-04-16 11:19:29 --> Helper loaded: html_helper
INFO - 2024-04-16 11:19:29 --> Helper loaded: text_helper
INFO - 2024-04-16 11:19:29 --> Helper loaded: form_helper
INFO - 2024-04-16 11:19:29 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:19:29 --> Helper loaded: security_helper
INFO - 2024-04-16 11:19:29 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:19:29 --> Database Driver Class Initialized
INFO - 2024-04-16 11:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:19:29 --> Parser Class Initialized
INFO - 2024-04-16 11:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:19:29 --> Pagination Class Initialized
INFO - 2024-04-16 11:19:29 --> Form Validation Class Initialized
INFO - 2024-04-16 11:19:29 --> Controller Class Initialized
INFO - 2024-04-16 11:19:29 --> Model Class Initialized
DEBUG - 2024-04-16 11:19:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:19:29 --> Model Class Initialized
DEBUG - 2024-04-16 11:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:19:29 --> Model Class Initialized
INFO - 2024-04-16 11:19:29 --> Final output sent to browser
DEBUG - 2024-04-16 11:19:29 --> Total execution time: 0.0418
ERROR - 2024-04-16 11:19:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:19:34 --> Config Class Initialized
INFO - 2024-04-16 11:19:34 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:19:34 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:19:34 --> Utf8 Class Initialized
INFO - 2024-04-16 11:19:34 --> URI Class Initialized
INFO - 2024-04-16 11:19:34 --> Router Class Initialized
INFO - 2024-04-16 11:19:34 --> Output Class Initialized
INFO - 2024-04-16 11:19:34 --> Security Class Initialized
DEBUG - 2024-04-16 11:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:19:34 --> Input Class Initialized
INFO - 2024-04-16 11:19:34 --> Language Class Initialized
INFO - 2024-04-16 11:19:34 --> Loader Class Initialized
INFO - 2024-04-16 11:19:34 --> Helper loaded: url_helper
INFO - 2024-04-16 11:19:34 --> Helper loaded: file_helper
INFO - 2024-04-16 11:19:34 --> Helper loaded: html_helper
INFO - 2024-04-16 11:19:34 --> Helper loaded: text_helper
INFO - 2024-04-16 11:19:34 --> Helper loaded: form_helper
INFO - 2024-04-16 11:19:34 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:19:34 --> Helper loaded: security_helper
INFO - 2024-04-16 11:19:34 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:19:34 --> Database Driver Class Initialized
INFO - 2024-04-16 11:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:19:34 --> Parser Class Initialized
INFO - 2024-04-16 11:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:19:34 --> Pagination Class Initialized
INFO - 2024-04-16 11:19:34 --> Form Validation Class Initialized
INFO - 2024-04-16 11:19:34 --> Controller Class Initialized
INFO - 2024-04-16 11:19:34 --> Model Class Initialized
DEBUG - 2024-04-16 11:19:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:19:34 --> Model Class Initialized
DEBUG - 2024-04-16 11:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:19:34 --> Model Class Initialized
INFO - 2024-04-16 11:19:35 --> Final output sent to browser
DEBUG - 2024-04-16 11:19:35 --> Total execution time: 1.2447
ERROR - 2024-04-16 11:26:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:26:17 --> Config Class Initialized
INFO - 2024-04-16 11:26:17 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:26:17 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:26:17 --> Utf8 Class Initialized
INFO - 2024-04-16 11:26:17 --> URI Class Initialized
DEBUG - 2024-04-16 11:26:17 --> No URI present. Default controller set.
INFO - 2024-04-16 11:26:17 --> Router Class Initialized
INFO - 2024-04-16 11:26:17 --> Output Class Initialized
INFO - 2024-04-16 11:26:17 --> Security Class Initialized
DEBUG - 2024-04-16 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:26:17 --> Input Class Initialized
INFO - 2024-04-16 11:26:17 --> Language Class Initialized
INFO - 2024-04-16 11:26:17 --> Loader Class Initialized
INFO - 2024-04-16 11:26:17 --> Helper loaded: url_helper
INFO - 2024-04-16 11:26:17 --> Helper loaded: file_helper
INFO - 2024-04-16 11:26:17 --> Helper loaded: html_helper
INFO - 2024-04-16 11:26:17 --> Helper loaded: text_helper
INFO - 2024-04-16 11:26:17 --> Helper loaded: form_helper
INFO - 2024-04-16 11:26:17 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:26:17 --> Helper loaded: security_helper
INFO - 2024-04-16 11:26:17 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:26:17 --> Database Driver Class Initialized
INFO - 2024-04-16 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:26:17 --> Parser Class Initialized
INFO - 2024-04-16 11:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:26:17 --> Pagination Class Initialized
INFO - 2024-04-16 11:26:17 --> Form Validation Class Initialized
INFO - 2024-04-16 11:26:17 --> Controller Class Initialized
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
INFO - 2024-04-16 11:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-16 11:26:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 11:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 11:26:17 --> Model Class Initialized
INFO - 2024-04-16 11:26:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 11:26:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 11:26:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 11:26:18 --> Final output sent to browser
DEBUG - 2024-04-16 11:26:18 --> Total execution time: 0.6350
ERROR - 2024-04-16 11:26:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:26:28 --> Config Class Initialized
INFO - 2024-04-16 11:26:28 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:26:28 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:26:28 --> Utf8 Class Initialized
INFO - 2024-04-16 11:26:28 --> URI Class Initialized
INFO - 2024-04-16 11:26:28 --> Router Class Initialized
INFO - 2024-04-16 11:26:28 --> Output Class Initialized
INFO - 2024-04-16 11:26:28 --> Security Class Initialized
DEBUG - 2024-04-16 11:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:26:28 --> Input Class Initialized
INFO - 2024-04-16 11:26:28 --> Language Class Initialized
INFO - 2024-04-16 11:26:28 --> Loader Class Initialized
INFO - 2024-04-16 11:26:28 --> Helper loaded: url_helper
INFO - 2024-04-16 11:26:28 --> Helper loaded: file_helper
INFO - 2024-04-16 11:26:28 --> Helper loaded: html_helper
INFO - 2024-04-16 11:26:28 --> Helper loaded: text_helper
INFO - 2024-04-16 11:26:28 --> Helper loaded: form_helper
INFO - 2024-04-16 11:26:28 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:26:28 --> Helper loaded: security_helper
INFO - 2024-04-16 11:26:28 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:26:28 --> Database Driver Class Initialized
INFO - 2024-04-16 11:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:26:28 --> Parser Class Initialized
INFO - 2024-04-16 11:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:26:28 --> Pagination Class Initialized
INFO - 2024-04-16 11:26:28 --> Form Validation Class Initialized
INFO - 2024-04-16 11:26:28 --> Controller Class Initialized
INFO - 2024-04-16 11:26:28 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:28 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:28 --> Model Class Initialized
INFO - 2024-04-16 11:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-16 11:26:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-16 11:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-16 11:26:28 --> Model Class Initialized
INFO - 2024-04-16 11:26:28 --> Model Class Initialized
INFO - 2024-04-16 11:26:28 --> Model Class Initialized
INFO - 2024-04-16 11:26:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-16 11:26:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-16 11:26:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-16 11:26:29 --> Final output sent to browser
DEBUG - 2024-04-16 11:26:29 --> Total execution time: 0.2893
ERROR - 2024-04-16 11:26:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:26:29 --> Config Class Initialized
INFO - 2024-04-16 11:26:29 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:26:29 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:26:29 --> Utf8 Class Initialized
INFO - 2024-04-16 11:26:29 --> URI Class Initialized
INFO - 2024-04-16 11:26:29 --> Router Class Initialized
INFO - 2024-04-16 11:26:29 --> Output Class Initialized
INFO - 2024-04-16 11:26:29 --> Security Class Initialized
DEBUG - 2024-04-16 11:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:26:29 --> Input Class Initialized
INFO - 2024-04-16 11:26:29 --> Language Class Initialized
INFO - 2024-04-16 11:26:29 --> Loader Class Initialized
INFO - 2024-04-16 11:26:29 --> Helper loaded: url_helper
INFO - 2024-04-16 11:26:29 --> Helper loaded: file_helper
INFO - 2024-04-16 11:26:29 --> Helper loaded: html_helper
INFO - 2024-04-16 11:26:29 --> Helper loaded: text_helper
INFO - 2024-04-16 11:26:29 --> Helper loaded: form_helper
INFO - 2024-04-16 11:26:29 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:26:29 --> Helper loaded: security_helper
INFO - 2024-04-16 11:26:29 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:26:29 --> Database Driver Class Initialized
INFO - 2024-04-16 11:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:26:29 --> Parser Class Initialized
INFO - 2024-04-16 11:26:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:26:29 --> Pagination Class Initialized
INFO - 2024-04-16 11:26:29 --> Form Validation Class Initialized
INFO - 2024-04-16 11:26:29 --> Controller Class Initialized
INFO - 2024-04-16 11:26:29 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:29 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:29 --> Model Class Initialized
INFO - 2024-04-16 11:26:29 --> Final output sent to browser
DEBUG - 2024-04-16 11:26:29 --> Total execution time: 0.0391
ERROR - 2024-04-16 11:26:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 11:26:32 --> Config Class Initialized
INFO - 2024-04-16 11:26:32 --> Hooks Class Initialized
DEBUG - 2024-04-16 11:26:32 --> UTF-8 Support Enabled
INFO - 2024-04-16 11:26:32 --> Utf8 Class Initialized
INFO - 2024-04-16 11:26:32 --> URI Class Initialized
INFO - 2024-04-16 11:26:32 --> Router Class Initialized
INFO - 2024-04-16 11:26:32 --> Output Class Initialized
INFO - 2024-04-16 11:26:32 --> Security Class Initialized
DEBUG - 2024-04-16 11:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 11:26:32 --> Input Class Initialized
INFO - 2024-04-16 11:26:32 --> Language Class Initialized
INFO - 2024-04-16 11:26:32 --> Loader Class Initialized
INFO - 2024-04-16 11:26:32 --> Helper loaded: url_helper
INFO - 2024-04-16 11:26:32 --> Helper loaded: file_helper
INFO - 2024-04-16 11:26:32 --> Helper loaded: html_helper
INFO - 2024-04-16 11:26:32 --> Helper loaded: text_helper
INFO - 2024-04-16 11:26:32 --> Helper loaded: form_helper
INFO - 2024-04-16 11:26:32 --> Helper loaded: lang_helper
INFO - 2024-04-16 11:26:32 --> Helper loaded: security_helper
INFO - 2024-04-16 11:26:32 --> Helper loaded: cookie_helper
INFO - 2024-04-16 11:26:32 --> Database Driver Class Initialized
INFO - 2024-04-16 11:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 11:26:32 --> Parser Class Initialized
INFO - 2024-04-16 11:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 11:26:32 --> Pagination Class Initialized
INFO - 2024-04-16 11:26:32 --> Form Validation Class Initialized
INFO - 2024-04-16 11:26:32 --> Controller Class Initialized
INFO - 2024-04-16 11:26:32 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-16 11:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:32 --> Model Class Initialized
DEBUG - 2024-04-16 11:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-16 11:26:32 --> Model Class Initialized
INFO - 2024-04-16 11:26:33 --> Final output sent to browser
DEBUG - 2024-04-16 11:26:33 --> Total execution time: 1.2333
ERROR - 2024-04-16 13:54:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 13:54:05 --> Config Class Initialized
INFO - 2024-04-16 13:54:05 --> Hooks Class Initialized
DEBUG - 2024-04-16 13:54:05 --> UTF-8 Support Enabled
INFO - 2024-04-16 13:54:05 --> Utf8 Class Initialized
INFO - 2024-04-16 13:54:05 --> URI Class Initialized
DEBUG - 2024-04-16 13:54:05 --> No URI present. Default controller set.
INFO - 2024-04-16 13:54:05 --> Router Class Initialized
INFO - 2024-04-16 13:54:05 --> Output Class Initialized
INFO - 2024-04-16 13:54:05 --> Security Class Initialized
DEBUG - 2024-04-16 13:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 13:54:05 --> Input Class Initialized
INFO - 2024-04-16 13:54:05 --> Language Class Initialized
INFO - 2024-04-16 13:54:05 --> Loader Class Initialized
INFO - 2024-04-16 13:54:05 --> Helper loaded: url_helper
INFO - 2024-04-16 13:54:05 --> Helper loaded: file_helper
INFO - 2024-04-16 13:54:05 --> Helper loaded: html_helper
INFO - 2024-04-16 13:54:05 --> Helper loaded: text_helper
INFO - 2024-04-16 13:54:05 --> Helper loaded: form_helper
INFO - 2024-04-16 13:54:05 --> Helper loaded: lang_helper
INFO - 2024-04-16 13:54:05 --> Helper loaded: security_helper
INFO - 2024-04-16 13:54:05 --> Helper loaded: cookie_helper
INFO - 2024-04-16 13:54:05 --> Database Driver Class Initialized
INFO - 2024-04-16 13:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-16 13:54:05 --> Parser Class Initialized
INFO - 2024-04-16 13:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-16 13:54:05 --> Pagination Class Initialized
INFO - 2024-04-16 13:54:05 --> Form Validation Class Initialized
INFO - 2024-04-16 13:54:05 --> Controller Class Initialized
INFO - 2024-04-16 13:54:05 --> Model Class Initialized
DEBUG - 2024-04-16 13:54:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-16 17:54:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-16 17:54:14 --> Config Class Initialized
INFO - 2024-04-16 17:54:14 --> Hooks Class Initialized
DEBUG - 2024-04-16 17:54:14 --> UTF-8 Support Enabled
INFO - 2024-04-16 17:54:14 --> Utf8 Class Initialized
INFO - 2024-04-16 17:54:14 --> URI Class Initialized
INFO - 2024-04-16 17:54:14 --> Router Class Initialized
INFO - 2024-04-16 17:54:14 --> Output Class Initialized
INFO - 2024-04-16 17:54:14 --> Security Class Initialized
DEBUG - 2024-04-16 17:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-16 17:54:14 --> Input Class Initialized
INFO - 2024-04-16 17:54:14 --> Language Class Initialized
ERROR - 2024-04-16 17:54:14 --> 404 Page Not Found: Well-known/assetlinks.json
