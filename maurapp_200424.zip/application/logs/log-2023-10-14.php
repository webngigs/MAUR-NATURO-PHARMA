<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-14 01:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 01:39:19 --> Config Class Initialized
INFO - 2023-10-14 01:39:19 --> Hooks Class Initialized
DEBUG - 2023-10-14 01:39:19 --> UTF-8 Support Enabled
INFO - 2023-10-14 01:39:19 --> Utf8 Class Initialized
INFO - 2023-10-14 01:39:19 --> URI Class Initialized
DEBUG - 2023-10-14 01:39:19 --> No URI present. Default controller set.
INFO - 2023-10-14 01:39:19 --> Router Class Initialized
INFO - 2023-10-14 01:39:19 --> Output Class Initialized
INFO - 2023-10-14 01:39:19 --> Security Class Initialized
DEBUG - 2023-10-14 01:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 01:39:19 --> Input Class Initialized
INFO - 2023-10-14 01:39:19 --> Language Class Initialized
INFO - 2023-10-14 01:39:19 --> Loader Class Initialized
INFO - 2023-10-14 01:39:19 --> Helper loaded: url_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: file_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: html_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: text_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: form_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: lang_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: security_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: cookie_helper
INFO - 2023-10-14 01:39:19 --> Database Driver Class Initialized
INFO - 2023-10-14 01:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 01:39:19 --> Parser Class Initialized
INFO - 2023-10-14 01:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 01:39:19 --> Pagination Class Initialized
INFO - 2023-10-14 01:39:19 --> Form Validation Class Initialized
INFO - 2023-10-14 01:39:19 --> Controller Class Initialized
INFO - 2023-10-14 01:39:19 --> Model Class Initialized
DEBUG - 2023-10-14 01:39:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 01:39:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 01:39:19 --> Config Class Initialized
INFO - 2023-10-14 01:39:19 --> Hooks Class Initialized
DEBUG - 2023-10-14 01:39:19 --> UTF-8 Support Enabled
INFO - 2023-10-14 01:39:19 --> Utf8 Class Initialized
INFO - 2023-10-14 01:39:19 --> URI Class Initialized
INFO - 2023-10-14 01:39:19 --> Router Class Initialized
INFO - 2023-10-14 01:39:19 --> Output Class Initialized
INFO - 2023-10-14 01:39:19 --> Security Class Initialized
DEBUG - 2023-10-14 01:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 01:39:19 --> Input Class Initialized
INFO - 2023-10-14 01:39:19 --> Language Class Initialized
INFO - 2023-10-14 01:39:19 --> Loader Class Initialized
INFO - 2023-10-14 01:39:19 --> Helper loaded: url_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: file_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: html_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: text_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: form_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: lang_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: security_helper
INFO - 2023-10-14 01:39:19 --> Helper loaded: cookie_helper
INFO - 2023-10-14 01:39:19 --> Database Driver Class Initialized
INFO - 2023-10-14 01:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 01:39:19 --> Parser Class Initialized
INFO - 2023-10-14 01:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 01:39:19 --> Pagination Class Initialized
INFO - 2023-10-14 01:39:19 --> Form Validation Class Initialized
INFO - 2023-10-14 01:39:19 --> Controller Class Initialized
INFO - 2023-10-14 01:39:19 --> Model Class Initialized
DEBUG - 2023-10-14 01:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 01:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 01:39:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 01:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 01:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 01:39:19 --> Model Class Initialized
INFO - 2023-10-14 01:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 01:39:19 --> Final output sent to browser
DEBUG - 2023-10-14 01:39:19 --> Total execution time: 0.0348
ERROR - 2023-10-14 04:29:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:37 --> Config Class Initialized
INFO - 2023-10-14 04:29:37 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:37 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:37 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:37 --> URI Class Initialized
DEBUG - 2023-10-14 04:29:37 --> No URI present. Default controller set.
INFO - 2023-10-14 04:29:37 --> Router Class Initialized
INFO - 2023-10-14 04:29:37 --> Output Class Initialized
INFO - 2023-10-14 04:29:37 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:37 --> Input Class Initialized
INFO - 2023-10-14 04:29:37 --> Language Class Initialized
INFO - 2023-10-14 04:29:37 --> Loader Class Initialized
INFO - 2023-10-14 04:29:37 --> Helper loaded: url_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: file_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: html_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: text_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: form_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: security_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:29:37 --> Database Driver Class Initialized
INFO - 2023-10-14 04:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:29:37 --> Parser Class Initialized
INFO - 2023-10-14 04:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:29:37 --> Pagination Class Initialized
INFO - 2023-10-14 04:29:37 --> Form Validation Class Initialized
INFO - 2023-10-14 04:29:37 --> Controller Class Initialized
INFO - 2023-10-14 04:29:37 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 04:29:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:37 --> Config Class Initialized
INFO - 2023-10-14 04:29:37 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:37 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:37 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:37 --> URI Class Initialized
INFO - 2023-10-14 04:29:37 --> Router Class Initialized
INFO - 2023-10-14 04:29:37 --> Output Class Initialized
INFO - 2023-10-14 04:29:37 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:37 --> Input Class Initialized
INFO - 2023-10-14 04:29:37 --> Language Class Initialized
INFO - 2023-10-14 04:29:37 --> Loader Class Initialized
INFO - 2023-10-14 04:29:37 --> Helper loaded: url_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: file_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: html_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: text_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: form_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: security_helper
INFO - 2023-10-14 04:29:37 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:29:37 --> Database Driver Class Initialized
INFO - 2023-10-14 04:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:29:37 --> Parser Class Initialized
INFO - 2023-10-14 04:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:29:37 --> Pagination Class Initialized
INFO - 2023-10-14 04:29:37 --> Form Validation Class Initialized
INFO - 2023-10-14 04:29:37 --> Controller Class Initialized
INFO - 2023-10-14 04:29:37 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 04:29:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:29:37 --> Model Class Initialized
INFO - 2023-10-14 04:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:29:37 --> Final output sent to browser
DEBUG - 2023-10-14 04:29:37 --> Total execution time: 0.0347
ERROR - 2023-10-14 04:29:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:40 --> Config Class Initialized
INFO - 2023-10-14 04:29:40 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:40 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:40 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:40 --> URI Class Initialized
INFO - 2023-10-14 04:29:40 --> Router Class Initialized
INFO - 2023-10-14 04:29:40 --> Output Class Initialized
INFO - 2023-10-14 04:29:40 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:40 --> Input Class Initialized
INFO - 2023-10-14 04:29:40 --> Language Class Initialized
INFO - 2023-10-14 04:29:40 --> Loader Class Initialized
INFO - 2023-10-14 04:29:40 --> Helper loaded: url_helper
INFO - 2023-10-14 04:29:40 --> Helper loaded: file_helper
INFO - 2023-10-14 04:29:40 --> Helper loaded: html_helper
INFO - 2023-10-14 04:29:40 --> Helper loaded: text_helper
INFO - 2023-10-14 04:29:40 --> Helper loaded: form_helper
INFO - 2023-10-14 04:29:40 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:29:40 --> Helper loaded: security_helper
INFO - 2023-10-14 04:29:40 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:29:40 --> Database Driver Class Initialized
INFO - 2023-10-14 04:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:29:40 --> Parser Class Initialized
INFO - 2023-10-14 04:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:29:40 --> Pagination Class Initialized
INFO - 2023-10-14 04:29:40 --> Form Validation Class Initialized
INFO - 2023-10-14 04:29:40 --> Controller Class Initialized
INFO - 2023-10-14 04:29:40 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:40 --> Model Class Initialized
INFO - 2023-10-14 04:29:40 --> Final output sent to browser
DEBUG - 2023-10-14 04:29:40 --> Total execution time: 0.0184
ERROR - 2023-10-14 04:29:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:41 --> Config Class Initialized
INFO - 2023-10-14 04:29:41 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:41 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:41 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:41 --> URI Class Initialized
DEBUG - 2023-10-14 04:29:41 --> No URI present. Default controller set.
INFO - 2023-10-14 04:29:41 --> Router Class Initialized
INFO - 2023-10-14 04:29:41 --> Output Class Initialized
INFO - 2023-10-14 04:29:41 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:41 --> Input Class Initialized
INFO - 2023-10-14 04:29:41 --> Language Class Initialized
INFO - 2023-10-14 04:29:41 --> Loader Class Initialized
INFO - 2023-10-14 04:29:41 --> Helper loaded: url_helper
INFO - 2023-10-14 04:29:41 --> Helper loaded: file_helper
INFO - 2023-10-14 04:29:41 --> Helper loaded: html_helper
INFO - 2023-10-14 04:29:41 --> Helper loaded: text_helper
INFO - 2023-10-14 04:29:41 --> Helper loaded: form_helper
INFO - 2023-10-14 04:29:41 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:29:41 --> Helper loaded: security_helper
INFO - 2023-10-14 04:29:41 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:29:41 --> Database Driver Class Initialized
INFO - 2023-10-14 04:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:29:41 --> Parser Class Initialized
INFO - 2023-10-14 04:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:29:41 --> Pagination Class Initialized
INFO - 2023-10-14 04:29:41 --> Form Validation Class Initialized
INFO - 2023-10-14 04:29:41 --> Controller Class Initialized
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
INFO - 2023-10-14 04:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:29:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:29:41 --> Model Class Initialized
INFO - 2023-10-14 04:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:29:41 --> Final output sent to browser
DEBUG - 2023-10-14 04:29:41 --> Total execution time: 0.3690
ERROR - 2023-10-14 04:29:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:42 --> Config Class Initialized
INFO - 2023-10-14 04:29:42 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:42 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:42 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:42 --> URI Class Initialized
INFO - 2023-10-14 04:29:42 --> Router Class Initialized
INFO - 2023-10-14 04:29:42 --> Output Class Initialized
INFO - 2023-10-14 04:29:42 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:42 --> Input Class Initialized
INFO - 2023-10-14 04:29:42 --> Language Class Initialized
INFO - 2023-10-14 04:29:42 --> Loader Class Initialized
INFO - 2023-10-14 04:29:42 --> Helper loaded: url_helper
INFO - 2023-10-14 04:29:42 --> Helper loaded: file_helper
INFO - 2023-10-14 04:29:42 --> Helper loaded: html_helper
INFO - 2023-10-14 04:29:42 --> Helper loaded: text_helper
INFO - 2023-10-14 04:29:42 --> Helper loaded: form_helper
INFO - 2023-10-14 04:29:42 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:29:42 --> Helper loaded: security_helper
INFO - 2023-10-14 04:29:42 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:29:42 --> Database Driver Class Initialized
INFO - 2023-10-14 04:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:29:42 --> Parser Class Initialized
INFO - 2023-10-14 04:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:29:42 --> Pagination Class Initialized
INFO - 2023-10-14 04:29:42 --> Form Validation Class Initialized
INFO - 2023-10-14 04:29:42 --> Controller Class Initialized
DEBUG - 2023-10-14 04:29:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:42 --> Model Class Initialized
INFO - 2023-10-14 04:29:42 --> Final output sent to browser
DEBUG - 2023-10-14 04:29:42 --> Total execution time: 0.0130
ERROR - 2023-10-14 04:29:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:58 --> Config Class Initialized
INFO - 2023-10-14 04:29:58 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:58 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:58 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:58 --> URI Class Initialized
DEBUG - 2023-10-14 04:29:58 --> No URI present. Default controller set.
INFO - 2023-10-14 04:29:58 --> Router Class Initialized
INFO - 2023-10-14 04:29:58 --> Output Class Initialized
INFO - 2023-10-14 04:29:58 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:58 --> Input Class Initialized
INFO - 2023-10-14 04:29:58 --> Language Class Initialized
INFO - 2023-10-14 04:29:58 --> Loader Class Initialized
INFO - 2023-10-14 04:29:58 --> Helper loaded: url_helper
INFO - 2023-10-14 04:29:58 --> Helper loaded: file_helper
INFO - 2023-10-14 04:29:58 --> Helper loaded: html_helper
INFO - 2023-10-14 04:29:58 --> Helper loaded: text_helper
INFO - 2023-10-14 04:29:58 --> Helper loaded: form_helper
INFO - 2023-10-14 04:29:58 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:29:58 --> Helper loaded: security_helper
INFO - 2023-10-14 04:29:58 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:29:58 --> Database Driver Class Initialized
INFO - 2023-10-14 04:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:29:58 --> Parser Class Initialized
INFO - 2023-10-14 04:29:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:29:58 --> Pagination Class Initialized
INFO - 2023-10-14 04:29:58 --> Form Validation Class Initialized
INFO - 2023-10-14 04:29:58 --> Controller Class Initialized
INFO - 2023-10-14 04:29:58 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 04:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:59 --> Config Class Initialized
INFO - 2023-10-14 04:29:59 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:59 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:59 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:59 --> URI Class Initialized
INFO - 2023-10-14 04:29:59 --> Router Class Initialized
INFO - 2023-10-14 04:29:59 --> Output Class Initialized
INFO - 2023-10-14 04:29:59 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:59 --> Input Class Initialized
INFO - 2023-10-14 04:29:59 --> Language Class Initialized
INFO - 2023-10-14 04:29:59 --> Loader Class Initialized
INFO - 2023-10-14 04:29:59 --> Helper loaded: url_helper
INFO - 2023-10-14 04:29:59 --> Helper loaded: file_helper
INFO - 2023-10-14 04:29:59 --> Helper loaded: html_helper
INFO - 2023-10-14 04:29:59 --> Helper loaded: text_helper
INFO - 2023-10-14 04:29:59 --> Helper loaded: form_helper
INFO - 2023-10-14 04:29:59 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:29:59 --> Helper loaded: security_helper
INFO - 2023-10-14 04:29:59 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:29:59 --> Database Driver Class Initialized
INFO - 2023-10-14 04:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:29:59 --> Parser Class Initialized
INFO - 2023-10-14 04:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:29:59 --> Pagination Class Initialized
INFO - 2023-10-14 04:29:59 --> Form Validation Class Initialized
INFO - 2023-10-14 04:29:59 --> Controller Class Initialized
INFO - 2023-10-14 04:29:59 --> Model Class Initialized
DEBUG - 2023-10-14 04:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 04:29:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:29:59 --> Model Class Initialized
INFO - 2023-10-14 04:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:29:59 --> Final output sent to browser
DEBUG - 2023-10-14 04:29:59 --> Total execution time: 0.0301
ERROR - 2023-10-14 04:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:59 --> Config Class Initialized
INFO - 2023-10-14 04:29:59 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:59 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:59 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:59 --> URI Class Initialized
INFO - 2023-10-14 04:29:59 --> Router Class Initialized
INFO - 2023-10-14 04:29:59 --> Output Class Initialized
INFO - 2023-10-14 04:29:59 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:59 --> Input Class Initialized
INFO - 2023-10-14 04:29:59 --> Language Class Initialized
ERROR - 2023-10-14 04:29:59 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-10-14 04:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:29:59 --> Config Class Initialized
INFO - 2023-10-14 04:29:59 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:29:59 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:29:59 --> Utf8 Class Initialized
INFO - 2023-10-14 04:29:59 --> URI Class Initialized
INFO - 2023-10-14 04:29:59 --> Router Class Initialized
INFO - 2023-10-14 04:29:59 --> Output Class Initialized
INFO - 2023-10-14 04:29:59 --> Security Class Initialized
DEBUG - 2023-10-14 04:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:29:59 --> Input Class Initialized
INFO - 2023-10-14 04:29:59 --> Language Class Initialized
ERROR - 2023-10-14 04:29:59 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-10-14 04:30:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:30:04 --> Config Class Initialized
INFO - 2023-10-14 04:30:04 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:30:04 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:30:04 --> Utf8 Class Initialized
INFO - 2023-10-14 04:30:04 --> URI Class Initialized
INFO - 2023-10-14 04:30:04 --> Router Class Initialized
INFO - 2023-10-14 04:30:04 --> Output Class Initialized
INFO - 2023-10-14 04:30:04 --> Security Class Initialized
DEBUG - 2023-10-14 04:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:30:04 --> Input Class Initialized
INFO - 2023-10-14 04:30:04 --> Language Class Initialized
INFO - 2023-10-14 04:30:04 --> Loader Class Initialized
INFO - 2023-10-14 04:30:04 --> Helper loaded: url_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: file_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: html_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: text_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: form_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: security_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:30:04 --> Database Driver Class Initialized
INFO - 2023-10-14 04:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:30:04 --> Parser Class Initialized
INFO - 2023-10-14 04:30:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:30:04 --> Pagination Class Initialized
INFO - 2023-10-14 04:30:04 --> Form Validation Class Initialized
INFO - 2023-10-14 04:30:04 --> Controller Class Initialized
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
INFO - 2023-10-14 04:30:04 --> Final output sent to browser
DEBUG - 2023-10-14 04:30:04 --> Total execution time: 0.0181
ERROR - 2023-10-14 04:30:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:30:04 --> Config Class Initialized
INFO - 2023-10-14 04:30:04 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:30:04 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:30:04 --> Utf8 Class Initialized
INFO - 2023-10-14 04:30:04 --> URI Class Initialized
DEBUG - 2023-10-14 04:30:04 --> No URI present. Default controller set.
INFO - 2023-10-14 04:30:04 --> Router Class Initialized
INFO - 2023-10-14 04:30:04 --> Output Class Initialized
INFO - 2023-10-14 04:30:04 --> Security Class Initialized
DEBUG - 2023-10-14 04:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:30:04 --> Input Class Initialized
INFO - 2023-10-14 04:30:04 --> Language Class Initialized
INFO - 2023-10-14 04:30:04 --> Loader Class Initialized
INFO - 2023-10-14 04:30:04 --> Helper loaded: url_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: file_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: html_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: text_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: form_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: security_helper
INFO - 2023-10-14 04:30:04 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:30:04 --> Database Driver Class Initialized
INFO - 2023-10-14 04:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:30:04 --> Parser Class Initialized
INFO - 2023-10-14 04:30:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:30:04 --> Pagination Class Initialized
INFO - 2023-10-14 04:30:04 --> Form Validation Class Initialized
INFO - 2023-10-14 04:30:04 --> Controller Class Initialized
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
INFO - 2023-10-14 04:30:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:30:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:30:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:30:04 --> Model Class Initialized
INFO - 2023-10-14 04:30:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:30:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:30:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:30:04 --> Final output sent to browser
DEBUG - 2023-10-14 04:30:04 --> Total execution time: 0.2037
ERROR - 2023-10-14 04:30:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:30:09 --> Config Class Initialized
INFO - 2023-10-14 04:30:09 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:30:09 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:30:09 --> Utf8 Class Initialized
INFO - 2023-10-14 04:30:09 --> URI Class Initialized
INFO - 2023-10-14 04:30:09 --> Router Class Initialized
INFO - 2023-10-14 04:30:09 --> Output Class Initialized
INFO - 2023-10-14 04:30:09 --> Security Class Initialized
DEBUG - 2023-10-14 04:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:30:09 --> Input Class Initialized
INFO - 2023-10-14 04:30:09 --> Language Class Initialized
INFO - 2023-10-14 04:30:09 --> Loader Class Initialized
INFO - 2023-10-14 04:30:09 --> Helper loaded: url_helper
INFO - 2023-10-14 04:30:09 --> Helper loaded: file_helper
INFO - 2023-10-14 04:30:09 --> Helper loaded: html_helper
INFO - 2023-10-14 04:30:09 --> Helper loaded: text_helper
INFO - 2023-10-14 04:30:09 --> Helper loaded: form_helper
INFO - 2023-10-14 04:30:09 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:30:09 --> Helper loaded: security_helper
INFO - 2023-10-14 04:30:09 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:30:09 --> Database Driver Class Initialized
INFO - 2023-10-14 04:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:30:09 --> Parser Class Initialized
INFO - 2023-10-14 04:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:30:09 --> Pagination Class Initialized
INFO - 2023-10-14 04:30:09 --> Form Validation Class Initialized
INFO - 2023-10-14 04:30:09 --> Controller Class Initialized
INFO - 2023-10-14 04:30:09 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:09 --> Model Class Initialized
INFO - 2023-10-14 04:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-14 04:30:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:30:09 --> Model Class Initialized
INFO - 2023-10-14 04:30:09 --> Model Class Initialized
INFO - 2023-10-14 04:30:09 --> Model Class Initialized
INFO - 2023-10-14 04:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:30:09 --> Final output sent to browser
DEBUG - 2023-10-14 04:30:09 --> Total execution time: 0.1297
ERROR - 2023-10-14 04:30:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:30:10 --> Config Class Initialized
INFO - 2023-10-14 04:30:10 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:30:10 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:30:10 --> Utf8 Class Initialized
INFO - 2023-10-14 04:30:10 --> URI Class Initialized
INFO - 2023-10-14 04:30:10 --> Router Class Initialized
INFO - 2023-10-14 04:30:10 --> Output Class Initialized
INFO - 2023-10-14 04:30:10 --> Security Class Initialized
DEBUG - 2023-10-14 04:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:30:10 --> Input Class Initialized
INFO - 2023-10-14 04:30:10 --> Language Class Initialized
INFO - 2023-10-14 04:30:10 --> Loader Class Initialized
INFO - 2023-10-14 04:30:10 --> Helper loaded: url_helper
INFO - 2023-10-14 04:30:10 --> Helper loaded: file_helper
INFO - 2023-10-14 04:30:10 --> Helper loaded: html_helper
INFO - 2023-10-14 04:30:10 --> Helper loaded: text_helper
INFO - 2023-10-14 04:30:10 --> Helper loaded: form_helper
INFO - 2023-10-14 04:30:10 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:30:10 --> Helper loaded: security_helper
INFO - 2023-10-14 04:30:10 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:30:10 --> Database Driver Class Initialized
INFO - 2023-10-14 04:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:30:10 --> Parser Class Initialized
INFO - 2023-10-14 04:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:30:10 --> Pagination Class Initialized
INFO - 2023-10-14 04:30:10 --> Form Validation Class Initialized
INFO - 2023-10-14 04:30:10 --> Controller Class Initialized
INFO - 2023-10-14 04:30:10 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:10 --> Model Class Initialized
INFO - 2023-10-14 04:30:10 --> Final output sent to browser
DEBUG - 2023-10-14 04:30:10 --> Total execution time: 0.0710
ERROR - 2023-10-14 04:30:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:30:38 --> Config Class Initialized
INFO - 2023-10-14 04:30:38 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:30:38 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:30:38 --> Utf8 Class Initialized
INFO - 2023-10-14 04:30:38 --> URI Class Initialized
INFO - 2023-10-14 04:30:38 --> Router Class Initialized
INFO - 2023-10-14 04:30:38 --> Output Class Initialized
INFO - 2023-10-14 04:30:38 --> Security Class Initialized
DEBUG - 2023-10-14 04:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:30:38 --> Input Class Initialized
INFO - 2023-10-14 04:30:38 --> Language Class Initialized
INFO - 2023-10-14 04:30:38 --> Loader Class Initialized
INFO - 2023-10-14 04:30:38 --> Helper loaded: url_helper
INFO - 2023-10-14 04:30:38 --> Helper loaded: file_helper
INFO - 2023-10-14 04:30:38 --> Helper loaded: html_helper
INFO - 2023-10-14 04:30:38 --> Helper loaded: text_helper
INFO - 2023-10-14 04:30:38 --> Helper loaded: form_helper
INFO - 2023-10-14 04:30:38 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:30:38 --> Helper loaded: security_helper
INFO - 2023-10-14 04:30:38 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:30:38 --> Database Driver Class Initialized
INFO - 2023-10-14 04:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:30:38 --> Parser Class Initialized
INFO - 2023-10-14 04:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:30:38 --> Pagination Class Initialized
INFO - 2023-10-14 04:30:38 --> Form Validation Class Initialized
INFO - 2023-10-14 04:30:38 --> Controller Class Initialized
INFO - 2023-10-14 04:30:38 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:38 --> Model Class Initialized
INFO - 2023-10-14 04:30:38 --> Final output sent to browser
DEBUG - 2023-10-14 04:30:38 --> Total execution time: 0.0733
ERROR - 2023-10-14 04:30:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:30:59 --> Config Class Initialized
INFO - 2023-10-14 04:30:59 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:30:59 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:30:59 --> Utf8 Class Initialized
INFO - 2023-10-14 04:30:59 --> URI Class Initialized
DEBUG - 2023-10-14 04:30:59 --> No URI present. Default controller set.
INFO - 2023-10-14 04:30:59 --> Router Class Initialized
INFO - 2023-10-14 04:30:59 --> Output Class Initialized
INFO - 2023-10-14 04:30:59 --> Security Class Initialized
DEBUG - 2023-10-14 04:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:30:59 --> Input Class Initialized
INFO - 2023-10-14 04:30:59 --> Language Class Initialized
INFO - 2023-10-14 04:30:59 --> Loader Class Initialized
INFO - 2023-10-14 04:30:59 --> Helper loaded: url_helper
INFO - 2023-10-14 04:30:59 --> Helper loaded: file_helper
INFO - 2023-10-14 04:30:59 --> Helper loaded: html_helper
INFO - 2023-10-14 04:30:59 --> Helper loaded: text_helper
INFO - 2023-10-14 04:30:59 --> Helper loaded: form_helper
INFO - 2023-10-14 04:30:59 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:30:59 --> Helper loaded: security_helper
INFO - 2023-10-14 04:30:59 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:30:59 --> Database Driver Class Initialized
INFO - 2023-10-14 04:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:30:59 --> Parser Class Initialized
INFO - 2023-10-14 04:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:30:59 --> Pagination Class Initialized
INFO - 2023-10-14 04:30:59 --> Form Validation Class Initialized
INFO - 2023-10-14 04:30:59 --> Controller Class Initialized
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
DEBUG - 2023-10-14 04:30:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
INFO - 2023-10-14 04:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:30:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:30:59 --> Model Class Initialized
INFO - 2023-10-14 04:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:30:59 --> Final output sent to browser
DEBUG - 2023-10-14 04:30:59 --> Total execution time: 0.2062
ERROR - 2023-10-14 04:32:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:32:47 --> Config Class Initialized
INFO - 2023-10-14 04:32:47 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:32:47 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:32:47 --> Utf8 Class Initialized
INFO - 2023-10-14 04:32:47 --> URI Class Initialized
INFO - 2023-10-14 04:32:47 --> Router Class Initialized
INFO - 2023-10-14 04:32:47 --> Output Class Initialized
INFO - 2023-10-14 04:32:47 --> Security Class Initialized
DEBUG - 2023-10-14 04:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:32:47 --> Input Class Initialized
INFO - 2023-10-14 04:32:47 --> Language Class Initialized
INFO - 2023-10-14 04:32:47 --> Loader Class Initialized
INFO - 2023-10-14 04:32:47 --> Helper loaded: url_helper
INFO - 2023-10-14 04:32:47 --> Helper loaded: file_helper
INFO - 2023-10-14 04:32:47 --> Helper loaded: html_helper
INFO - 2023-10-14 04:32:47 --> Helper loaded: text_helper
INFO - 2023-10-14 04:32:47 --> Helper loaded: form_helper
INFO - 2023-10-14 04:32:47 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:32:47 --> Helper loaded: security_helper
INFO - 2023-10-14 04:32:47 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:32:47 --> Database Driver Class Initialized
INFO - 2023-10-14 04:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:32:47 --> Parser Class Initialized
INFO - 2023-10-14 04:32:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:32:47 --> Pagination Class Initialized
INFO - 2023-10-14 04:32:47 --> Form Validation Class Initialized
INFO - 2023-10-14 04:32:47 --> Controller Class Initialized
INFO - 2023-10-14 04:32:47 --> Model Class Initialized
DEBUG - 2023-10-14 04:32:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:32:47 --> Model Class Initialized
DEBUG - 2023-10-14 04:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:32:47 --> Model Class Initialized
INFO - 2023-10-14 04:32:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 04:32:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:32:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:32:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:32:47 --> Model Class Initialized
INFO - 2023-10-14 04:32:47 --> Model Class Initialized
INFO - 2023-10-14 04:32:47 --> Model Class Initialized
INFO - 2023-10-14 04:32:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:32:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:32:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:32:47 --> Final output sent to browser
DEBUG - 2023-10-14 04:32:47 --> Total execution time: 0.1433
ERROR - 2023-10-14 04:32:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:32:48 --> Config Class Initialized
INFO - 2023-10-14 04:32:48 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:32:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:32:48 --> Utf8 Class Initialized
INFO - 2023-10-14 04:32:48 --> URI Class Initialized
INFO - 2023-10-14 04:32:48 --> Router Class Initialized
INFO - 2023-10-14 04:32:48 --> Output Class Initialized
INFO - 2023-10-14 04:32:48 --> Security Class Initialized
DEBUG - 2023-10-14 04:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:32:48 --> Input Class Initialized
INFO - 2023-10-14 04:32:48 --> Language Class Initialized
INFO - 2023-10-14 04:32:48 --> Loader Class Initialized
INFO - 2023-10-14 04:32:48 --> Helper loaded: url_helper
INFO - 2023-10-14 04:32:48 --> Helper loaded: file_helper
INFO - 2023-10-14 04:32:48 --> Helper loaded: html_helper
INFO - 2023-10-14 04:32:48 --> Helper loaded: text_helper
INFO - 2023-10-14 04:32:48 --> Helper loaded: form_helper
INFO - 2023-10-14 04:32:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:32:48 --> Helper loaded: security_helper
INFO - 2023-10-14 04:32:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:32:48 --> Database Driver Class Initialized
INFO - 2023-10-14 04:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:32:48 --> Parser Class Initialized
INFO - 2023-10-14 04:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:32:48 --> Pagination Class Initialized
INFO - 2023-10-14 04:32:48 --> Form Validation Class Initialized
INFO - 2023-10-14 04:32:48 --> Controller Class Initialized
INFO - 2023-10-14 04:32:48 --> Model Class Initialized
DEBUG - 2023-10-14 04:32:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:32:48 --> Model Class Initialized
DEBUG - 2023-10-14 04:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:32:48 --> Model Class Initialized
INFO - 2023-10-14 04:32:48 --> Final output sent to browser
DEBUG - 2023-10-14 04:32:48 --> Total execution time: 0.0439
ERROR - 2023-10-14 04:32:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:32:52 --> Config Class Initialized
INFO - 2023-10-14 04:32:52 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:32:52 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:32:52 --> Utf8 Class Initialized
INFO - 2023-10-14 04:32:52 --> URI Class Initialized
INFO - 2023-10-14 04:32:52 --> Router Class Initialized
INFO - 2023-10-14 04:32:52 --> Output Class Initialized
INFO - 2023-10-14 04:32:52 --> Security Class Initialized
DEBUG - 2023-10-14 04:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:32:52 --> Input Class Initialized
INFO - 2023-10-14 04:32:52 --> Language Class Initialized
INFO - 2023-10-14 04:32:52 --> Loader Class Initialized
INFO - 2023-10-14 04:32:52 --> Helper loaded: url_helper
INFO - 2023-10-14 04:32:52 --> Helper loaded: file_helper
INFO - 2023-10-14 04:32:52 --> Helper loaded: html_helper
INFO - 2023-10-14 04:32:52 --> Helper loaded: text_helper
INFO - 2023-10-14 04:32:52 --> Helper loaded: form_helper
INFO - 2023-10-14 04:32:52 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:32:52 --> Helper loaded: security_helper
INFO - 2023-10-14 04:32:52 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:32:52 --> Database Driver Class Initialized
INFO - 2023-10-14 04:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:32:52 --> Parser Class Initialized
INFO - 2023-10-14 04:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:32:52 --> Pagination Class Initialized
INFO - 2023-10-14 04:32:52 --> Form Validation Class Initialized
INFO - 2023-10-14 04:32:52 --> Controller Class Initialized
INFO - 2023-10-14 04:32:52 --> Model Class Initialized
DEBUG - 2023-10-14 04:32:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:32:52 --> Model Class Initialized
DEBUG - 2023-10-14 04:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:32:52 --> Model Class Initialized
INFO - 2023-10-14 04:32:52 --> Final output sent to browser
DEBUG - 2023-10-14 04:32:52 --> Total execution time: 0.3953
ERROR - 2023-10-14 04:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:39:02 --> Config Class Initialized
INFO - 2023-10-14 04:39:02 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:39:02 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:39:02 --> Utf8 Class Initialized
INFO - 2023-10-14 04:39:02 --> URI Class Initialized
DEBUG - 2023-10-14 04:39:02 --> No URI present. Default controller set.
INFO - 2023-10-14 04:39:02 --> Router Class Initialized
INFO - 2023-10-14 04:39:02 --> Output Class Initialized
INFO - 2023-10-14 04:39:02 --> Security Class Initialized
DEBUG - 2023-10-14 04:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:39:02 --> Input Class Initialized
INFO - 2023-10-14 04:39:02 --> Language Class Initialized
INFO - 2023-10-14 04:39:02 --> Loader Class Initialized
INFO - 2023-10-14 04:39:02 --> Helper loaded: url_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: file_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: html_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: text_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: form_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: security_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:39:02 --> Database Driver Class Initialized
INFO - 2023-10-14 04:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:39:02 --> Parser Class Initialized
INFO - 2023-10-14 04:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:39:02 --> Pagination Class Initialized
INFO - 2023-10-14 04:39:02 --> Form Validation Class Initialized
INFO - 2023-10-14 04:39:02 --> Controller Class Initialized
INFO - 2023-10-14 04:39:02 --> Model Class Initialized
DEBUG - 2023-10-14 04:39:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 04:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:39:02 --> Config Class Initialized
INFO - 2023-10-14 04:39:02 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:39:02 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:39:02 --> Utf8 Class Initialized
INFO - 2023-10-14 04:39:02 --> URI Class Initialized
INFO - 2023-10-14 04:39:02 --> Router Class Initialized
INFO - 2023-10-14 04:39:02 --> Output Class Initialized
INFO - 2023-10-14 04:39:02 --> Security Class Initialized
DEBUG - 2023-10-14 04:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:39:02 --> Input Class Initialized
INFO - 2023-10-14 04:39:02 --> Language Class Initialized
INFO - 2023-10-14 04:39:02 --> Loader Class Initialized
INFO - 2023-10-14 04:39:02 --> Helper loaded: url_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: file_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: html_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: text_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: form_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: security_helper
INFO - 2023-10-14 04:39:02 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:39:02 --> Database Driver Class Initialized
INFO - 2023-10-14 04:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:39:02 --> Parser Class Initialized
INFO - 2023-10-14 04:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:39:02 --> Pagination Class Initialized
INFO - 2023-10-14 04:39:02 --> Form Validation Class Initialized
INFO - 2023-10-14 04:39:02 --> Controller Class Initialized
INFO - 2023-10-14 04:39:02 --> Model Class Initialized
DEBUG - 2023-10-14 04:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 04:39:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:39:02 --> Model Class Initialized
INFO - 2023-10-14 04:39:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:39:02 --> Final output sent to browser
DEBUG - 2023-10-14 04:39:02 --> Total execution time: 0.0312
ERROR - 2023-10-14 04:40:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:40:13 --> Config Class Initialized
INFO - 2023-10-14 04:40:13 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:40:13 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:40:13 --> Utf8 Class Initialized
INFO - 2023-10-14 04:40:13 --> URI Class Initialized
INFO - 2023-10-14 04:40:13 --> Router Class Initialized
INFO - 2023-10-14 04:40:13 --> Output Class Initialized
INFO - 2023-10-14 04:40:13 --> Security Class Initialized
DEBUG - 2023-10-14 04:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:40:13 --> Input Class Initialized
INFO - 2023-10-14 04:40:13 --> Language Class Initialized
INFO - 2023-10-14 04:40:13 --> Loader Class Initialized
INFO - 2023-10-14 04:40:13 --> Helper loaded: url_helper
INFO - 2023-10-14 04:40:13 --> Helper loaded: file_helper
INFO - 2023-10-14 04:40:13 --> Helper loaded: html_helper
INFO - 2023-10-14 04:40:13 --> Helper loaded: text_helper
INFO - 2023-10-14 04:40:13 --> Helper loaded: form_helper
INFO - 2023-10-14 04:40:13 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:40:13 --> Helper loaded: security_helper
INFO - 2023-10-14 04:40:13 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:40:13 --> Database Driver Class Initialized
INFO - 2023-10-14 04:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:40:13 --> Parser Class Initialized
INFO - 2023-10-14 04:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:40:13 --> Pagination Class Initialized
INFO - 2023-10-14 04:40:13 --> Form Validation Class Initialized
INFO - 2023-10-14 04:40:13 --> Controller Class Initialized
INFO - 2023-10-14 04:40:13 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:13 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:13 --> Model Class Initialized
INFO - 2023-10-14 04:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-14 04:40:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:40:13 --> Model Class Initialized
INFO - 2023-10-14 04:40:13 --> Model Class Initialized
INFO - 2023-10-14 04:40:13 --> Model Class Initialized
INFO - 2023-10-14 04:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:40:13 --> Final output sent to browser
DEBUG - 2023-10-14 04:40:13 --> Total execution time: 0.2139
ERROR - 2023-10-14 04:40:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:40:14 --> Config Class Initialized
INFO - 2023-10-14 04:40:14 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:40:14 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:40:14 --> Utf8 Class Initialized
INFO - 2023-10-14 04:40:14 --> URI Class Initialized
INFO - 2023-10-14 04:40:14 --> Router Class Initialized
INFO - 2023-10-14 04:40:14 --> Output Class Initialized
INFO - 2023-10-14 04:40:14 --> Security Class Initialized
DEBUG - 2023-10-14 04:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:40:14 --> Input Class Initialized
INFO - 2023-10-14 04:40:14 --> Language Class Initialized
INFO - 2023-10-14 04:40:14 --> Loader Class Initialized
INFO - 2023-10-14 04:40:14 --> Helper loaded: url_helper
INFO - 2023-10-14 04:40:14 --> Helper loaded: file_helper
INFO - 2023-10-14 04:40:14 --> Helper loaded: html_helper
INFO - 2023-10-14 04:40:14 --> Helper loaded: text_helper
INFO - 2023-10-14 04:40:14 --> Helper loaded: form_helper
INFO - 2023-10-14 04:40:14 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:40:14 --> Helper loaded: security_helper
INFO - 2023-10-14 04:40:14 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:40:14 --> Database Driver Class Initialized
INFO - 2023-10-14 04:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:40:14 --> Parser Class Initialized
INFO - 2023-10-14 04:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:40:14 --> Pagination Class Initialized
INFO - 2023-10-14 04:40:14 --> Form Validation Class Initialized
INFO - 2023-10-14 04:40:14 --> Controller Class Initialized
INFO - 2023-10-14 04:40:14 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:14 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:14 --> Model Class Initialized
INFO - 2023-10-14 04:40:14 --> Final output sent to browser
DEBUG - 2023-10-14 04:40:14 --> Total execution time: 0.0529
ERROR - 2023-10-14 04:40:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:40:25 --> Config Class Initialized
INFO - 2023-10-14 04:40:25 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:40:25 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:40:25 --> Utf8 Class Initialized
INFO - 2023-10-14 04:40:25 --> URI Class Initialized
INFO - 2023-10-14 04:40:25 --> Router Class Initialized
INFO - 2023-10-14 04:40:25 --> Output Class Initialized
INFO - 2023-10-14 04:40:25 --> Security Class Initialized
DEBUG - 2023-10-14 04:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:40:25 --> Input Class Initialized
INFO - 2023-10-14 04:40:25 --> Language Class Initialized
INFO - 2023-10-14 04:40:25 --> Loader Class Initialized
INFO - 2023-10-14 04:40:25 --> Helper loaded: url_helper
INFO - 2023-10-14 04:40:25 --> Helper loaded: file_helper
INFO - 2023-10-14 04:40:25 --> Helper loaded: html_helper
INFO - 2023-10-14 04:40:25 --> Helper loaded: text_helper
INFO - 2023-10-14 04:40:25 --> Helper loaded: form_helper
INFO - 2023-10-14 04:40:25 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:40:25 --> Helper loaded: security_helper
INFO - 2023-10-14 04:40:25 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:40:25 --> Database Driver Class Initialized
INFO - 2023-10-14 04:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:40:25 --> Parser Class Initialized
INFO - 2023-10-14 04:40:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:40:25 --> Pagination Class Initialized
INFO - 2023-10-14 04:40:25 --> Form Validation Class Initialized
INFO - 2023-10-14 04:40:25 --> Controller Class Initialized
INFO - 2023-10-14 04:40:25 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:25 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:25 --> Model Class Initialized
INFO - 2023-10-14 04:40:25 --> Final output sent to browser
DEBUG - 2023-10-14 04:40:25 --> Total execution time: 0.1806
ERROR - 2023-10-14 04:40:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:40:31 --> Config Class Initialized
INFO - 2023-10-14 04:40:31 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:40:31 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:40:31 --> Utf8 Class Initialized
INFO - 2023-10-14 04:40:31 --> URI Class Initialized
DEBUG - 2023-10-14 04:40:31 --> No URI present. Default controller set.
INFO - 2023-10-14 04:40:31 --> Router Class Initialized
INFO - 2023-10-14 04:40:31 --> Output Class Initialized
INFO - 2023-10-14 04:40:31 --> Security Class Initialized
DEBUG - 2023-10-14 04:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:40:31 --> Input Class Initialized
INFO - 2023-10-14 04:40:31 --> Language Class Initialized
INFO - 2023-10-14 04:40:31 --> Loader Class Initialized
INFO - 2023-10-14 04:40:31 --> Helper loaded: url_helper
INFO - 2023-10-14 04:40:31 --> Helper loaded: file_helper
INFO - 2023-10-14 04:40:31 --> Helper loaded: html_helper
INFO - 2023-10-14 04:40:31 --> Helper loaded: text_helper
INFO - 2023-10-14 04:40:31 --> Helper loaded: form_helper
INFO - 2023-10-14 04:40:31 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:40:31 --> Helper loaded: security_helper
INFO - 2023-10-14 04:40:31 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:40:31 --> Database Driver Class Initialized
INFO - 2023-10-14 04:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:40:31 --> Parser Class Initialized
INFO - 2023-10-14 04:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:40:31 --> Pagination Class Initialized
INFO - 2023-10-14 04:40:31 --> Form Validation Class Initialized
INFO - 2023-10-14 04:40:31 --> Controller Class Initialized
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
INFO - 2023-10-14 04:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:40:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:40:31 --> Model Class Initialized
INFO - 2023-10-14 04:40:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:40:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:40:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:40:32 --> Final output sent to browser
DEBUG - 2023-10-14 04:40:32 --> Total execution time: 0.3701
ERROR - 2023-10-14 04:40:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:40:48 --> Config Class Initialized
INFO - 2023-10-14 04:40:48 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:40:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:40:48 --> Utf8 Class Initialized
INFO - 2023-10-14 04:40:48 --> URI Class Initialized
DEBUG - 2023-10-14 04:40:48 --> No URI present. Default controller set.
INFO - 2023-10-14 04:40:48 --> Router Class Initialized
INFO - 2023-10-14 04:40:48 --> Output Class Initialized
INFO - 2023-10-14 04:40:48 --> Security Class Initialized
DEBUG - 2023-10-14 04:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:40:48 --> Input Class Initialized
INFO - 2023-10-14 04:40:48 --> Language Class Initialized
INFO - 2023-10-14 04:40:48 --> Loader Class Initialized
INFO - 2023-10-14 04:40:48 --> Helper loaded: url_helper
INFO - 2023-10-14 04:40:48 --> Helper loaded: file_helper
INFO - 2023-10-14 04:40:48 --> Helper loaded: html_helper
INFO - 2023-10-14 04:40:48 --> Helper loaded: text_helper
INFO - 2023-10-14 04:40:48 --> Helper loaded: form_helper
INFO - 2023-10-14 04:40:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:40:48 --> Helper loaded: security_helper
INFO - 2023-10-14 04:40:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:40:48 --> Database Driver Class Initialized
INFO - 2023-10-14 04:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:40:48 --> Parser Class Initialized
INFO - 2023-10-14 04:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:40:48 --> Pagination Class Initialized
INFO - 2023-10-14 04:40:48 --> Form Validation Class Initialized
INFO - 2023-10-14 04:40:48 --> Controller Class Initialized
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
DEBUG - 2023-10-14 04:40:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
INFO - 2023-10-14 04:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:40:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:40:48 --> Model Class Initialized
INFO - 2023-10-14 04:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:40:48 --> Final output sent to browser
DEBUG - 2023-10-14 04:40:48 --> Total execution time: 0.3751
ERROR - 2023-10-14 04:56:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:56:35 --> Config Class Initialized
INFO - 2023-10-14 04:56:35 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:56:35 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:56:35 --> Utf8 Class Initialized
INFO - 2023-10-14 04:56:35 --> URI Class Initialized
DEBUG - 2023-10-14 04:56:35 --> No URI present. Default controller set.
INFO - 2023-10-14 04:56:35 --> Router Class Initialized
INFO - 2023-10-14 04:56:35 --> Output Class Initialized
INFO - 2023-10-14 04:56:35 --> Security Class Initialized
DEBUG - 2023-10-14 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:56:35 --> Input Class Initialized
INFO - 2023-10-14 04:56:35 --> Language Class Initialized
INFO - 2023-10-14 04:56:35 --> Loader Class Initialized
INFO - 2023-10-14 04:56:35 --> Helper loaded: url_helper
INFO - 2023-10-14 04:56:35 --> Helper loaded: file_helper
INFO - 2023-10-14 04:56:35 --> Helper loaded: html_helper
INFO - 2023-10-14 04:56:35 --> Helper loaded: text_helper
INFO - 2023-10-14 04:56:35 --> Helper loaded: form_helper
INFO - 2023-10-14 04:56:35 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:56:35 --> Helper loaded: security_helper
INFO - 2023-10-14 04:56:35 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:56:35 --> Database Driver Class Initialized
INFO - 2023-10-14 04:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:56:35 --> Parser Class Initialized
INFO - 2023-10-14 04:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:56:35 --> Pagination Class Initialized
INFO - 2023-10-14 04:56:35 --> Form Validation Class Initialized
INFO - 2023-10-14 04:56:35 --> Controller Class Initialized
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
DEBUG - 2023-10-14 04:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
DEBUG - 2023-10-14 04:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
DEBUG - 2023-10-14 04:56:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
INFO - 2023-10-14 04:56:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:56:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:56:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:56:35 --> Model Class Initialized
INFO - 2023-10-14 04:56:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:56:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:56:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:56:35 --> Final output sent to browser
DEBUG - 2023-10-14 04:56:35 --> Total execution time: 0.1993
ERROR - 2023-10-14 04:56:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:56:44 --> Config Class Initialized
INFO - 2023-10-14 04:56:44 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:56:44 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:56:44 --> Utf8 Class Initialized
INFO - 2023-10-14 04:56:44 --> URI Class Initialized
INFO - 2023-10-14 04:56:44 --> Router Class Initialized
INFO - 2023-10-14 04:56:44 --> Output Class Initialized
INFO - 2023-10-14 04:56:44 --> Security Class Initialized
DEBUG - 2023-10-14 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:56:44 --> Input Class Initialized
INFO - 2023-10-14 04:56:44 --> Language Class Initialized
INFO - 2023-10-14 04:56:44 --> Loader Class Initialized
INFO - 2023-10-14 04:56:44 --> Helper loaded: url_helper
INFO - 2023-10-14 04:56:44 --> Helper loaded: file_helper
INFO - 2023-10-14 04:56:44 --> Helper loaded: html_helper
INFO - 2023-10-14 04:56:44 --> Helper loaded: text_helper
INFO - 2023-10-14 04:56:44 --> Helper loaded: form_helper
INFO - 2023-10-14 04:56:44 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:56:44 --> Helper loaded: security_helper
INFO - 2023-10-14 04:56:44 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:56:44 --> Database Driver Class Initialized
INFO - 2023-10-14 04:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:56:44 --> Parser Class Initialized
INFO - 2023-10-14 04:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:56:44 --> Pagination Class Initialized
INFO - 2023-10-14 04:56:44 --> Form Validation Class Initialized
INFO - 2023-10-14 04:56:44 --> Controller Class Initialized
INFO - 2023-10-14 04:56:44 --> Model Class Initialized
DEBUG - 2023-10-14 04:56:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:44 --> Model Class Initialized
INFO - 2023-10-14 04:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-14 04:56:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:56:44 --> Model Class Initialized
INFO - 2023-10-14 04:56:44 --> Model Class Initialized
INFO - 2023-10-14 04:56:44 --> Model Class Initialized
INFO - 2023-10-14 04:56:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:56:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:56:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:56:45 --> Final output sent to browser
DEBUG - 2023-10-14 04:56:45 --> Total execution time: 0.1252
ERROR - 2023-10-14 04:56:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:56:45 --> Config Class Initialized
INFO - 2023-10-14 04:56:45 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:56:45 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:56:45 --> Utf8 Class Initialized
INFO - 2023-10-14 04:56:45 --> URI Class Initialized
INFO - 2023-10-14 04:56:45 --> Router Class Initialized
INFO - 2023-10-14 04:56:45 --> Output Class Initialized
INFO - 2023-10-14 04:56:45 --> Security Class Initialized
DEBUG - 2023-10-14 04:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:56:45 --> Input Class Initialized
INFO - 2023-10-14 04:56:45 --> Language Class Initialized
INFO - 2023-10-14 04:56:45 --> Loader Class Initialized
INFO - 2023-10-14 04:56:45 --> Helper loaded: url_helper
INFO - 2023-10-14 04:56:45 --> Helper loaded: file_helper
INFO - 2023-10-14 04:56:45 --> Helper loaded: html_helper
INFO - 2023-10-14 04:56:45 --> Helper loaded: text_helper
INFO - 2023-10-14 04:56:45 --> Helper loaded: form_helper
INFO - 2023-10-14 04:56:45 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:56:45 --> Helper loaded: security_helper
INFO - 2023-10-14 04:56:45 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:56:45 --> Database Driver Class Initialized
INFO - 2023-10-14 04:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:56:45 --> Parser Class Initialized
INFO - 2023-10-14 04:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:56:45 --> Pagination Class Initialized
INFO - 2023-10-14 04:56:45 --> Form Validation Class Initialized
INFO - 2023-10-14 04:56:45 --> Controller Class Initialized
INFO - 2023-10-14 04:56:45 --> Model Class Initialized
DEBUG - 2023-10-14 04:56:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:45 --> Model Class Initialized
INFO - 2023-10-14 04:56:45 --> Final output sent to browser
DEBUG - 2023-10-14 04:56:45 --> Total execution time: 0.0717
ERROR - 2023-10-14 04:56:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:56:49 --> Config Class Initialized
INFO - 2023-10-14 04:56:49 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:56:49 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:56:49 --> Utf8 Class Initialized
INFO - 2023-10-14 04:56:49 --> URI Class Initialized
INFO - 2023-10-14 04:56:49 --> Router Class Initialized
INFO - 2023-10-14 04:56:49 --> Output Class Initialized
INFO - 2023-10-14 04:56:49 --> Security Class Initialized
DEBUG - 2023-10-14 04:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:56:49 --> Input Class Initialized
INFO - 2023-10-14 04:56:49 --> Language Class Initialized
INFO - 2023-10-14 04:56:49 --> Loader Class Initialized
INFO - 2023-10-14 04:56:49 --> Helper loaded: url_helper
INFO - 2023-10-14 04:56:49 --> Helper loaded: file_helper
INFO - 2023-10-14 04:56:49 --> Helper loaded: html_helper
INFO - 2023-10-14 04:56:49 --> Helper loaded: text_helper
INFO - 2023-10-14 04:56:49 --> Helper loaded: form_helper
INFO - 2023-10-14 04:56:49 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:56:49 --> Helper loaded: security_helper
INFO - 2023-10-14 04:56:49 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:56:49 --> Database Driver Class Initialized
INFO - 2023-10-14 04:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:56:49 --> Parser Class Initialized
INFO - 2023-10-14 04:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:56:49 --> Pagination Class Initialized
INFO - 2023-10-14 04:56:49 --> Form Validation Class Initialized
INFO - 2023-10-14 04:56:49 --> Controller Class Initialized
INFO - 2023-10-14 04:56:49 --> Model Class Initialized
DEBUG - 2023-10-14 04:56:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:56:49 --> Model Class Initialized
INFO - 2023-10-14 04:56:50 --> Final output sent to browser
DEBUG - 2023-10-14 04:56:50 --> Total execution time: 0.0721
ERROR - 2023-10-14 04:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:01 --> Config Class Initialized
INFO - 2023-10-14 04:57:01 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:01 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:01 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:01 --> URI Class Initialized
DEBUG - 2023-10-14 04:57:01 --> No URI present. Default controller set.
INFO - 2023-10-14 04:57:01 --> Router Class Initialized
INFO - 2023-10-14 04:57:01 --> Output Class Initialized
INFO - 2023-10-14 04:57:01 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:01 --> Input Class Initialized
INFO - 2023-10-14 04:57:01 --> Language Class Initialized
INFO - 2023-10-14 04:57:01 --> Loader Class Initialized
INFO - 2023-10-14 04:57:01 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:01 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:01 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:01 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:01 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:01 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:01 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:01 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:01 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:01 --> Parser Class Initialized
INFO - 2023-10-14 04:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:01 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:01 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:01 --> Controller Class Initialized
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
INFO - 2023-10-14 04:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:57:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:57:01 --> Model Class Initialized
INFO - 2023-10-14 04:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:57:01 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:01 --> Total execution time: 0.2070
ERROR - 2023-10-14 04:57:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:11 --> Config Class Initialized
INFO - 2023-10-14 04:57:11 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:11 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:11 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:11 --> URI Class Initialized
INFO - 2023-10-14 04:57:11 --> Router Class Initialized
INFO - 2023-10-14 04:57:11 --> Output Class Initialized
INFO - 2023-10-14 04:57:11 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:11 --> Input Class Initialized
INFO - 2023-10-14 04:57:11 --> Language Class Initialized
INFO - 2023-10-14 04:57:11 --> Loader Class Initialized
INFO - 2023-10-14 04:57:11 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:11 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:11 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:11 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:11 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:11 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:11 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:11 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:11 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:11 --> Parser Class Initialized
INFO - 2023-10-14 04:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:11 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:11 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:11 --> Controller Class Initialized
INFO - 2023-10-14 04:57:11 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:11 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:11 --> Model Class Initialized
INFO - 2023-10-14 04:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 04:57:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:57:11 --> Model Class Initialized
INFO - 2023-10-14 04:57:11 --> Model Class Initialized
INFO - 2023-10-14 04:57:11 --> Model Class Initialized
INFO - 2023-10-14 04:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:57:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:57:11 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:11 --> Total execution time: 0.1415
ERROR - 2023-10-14 04:57:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:12 --> Config Class Initialized
INFO - 2023-10-14 04:57:12 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:12 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:12 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:12 --> URI Class Initialized
INFO - 2023-10-14 04:57:12 --> Router Class Initialized
INFO - 2023-10-14 04:57:12 --> Output Class Initialized
INFO - 2023-10-14 04:57:12 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:12 --> Input Class Initialized
INFO - 2023-10-14 04:57:12 --> Language Class Initialized
INFO - 2023-10-14 04:57:12 --> Loader Class Initialized
INFO - 2023-10-14 04:57:12 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:12 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:12 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:12 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:12 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:12 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:12 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:12 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:12 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:12 --> Parser Class Initialized
INFO - 2023-10-14 04:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:12 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:12 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:12 --> Controller Class Initialized
INFO - 2023-10-14 04:57:12 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:12 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:12 --> Model Class Initialized
INFO - 2023-10-14 04:57:12 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:12 --> Total execution time: 0.0391
ERROR - 2023-10-14 04:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:14 --> Config Class Initialized
INFO - 2023-10-14 04:57:14 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:14 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:14 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:14 --> URI Class Initialized
INFO - 2023-10-14 04:57:14 --> Router Class Initialized
INFO - 2023-10-14 04:57:14 --> Output Class Initialized
INFO - 2023-10-14 04:57:14 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:14 --> Input Class Initialized
INFO - 2023-10-14 04:57:14 --> Language Class Initialized
INFO - 2023-10-14 04:57:14 --> Loader Class Initialized
INFO - 2023-10-14 04:57:14 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:14 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:14 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:14 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:14 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:14 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:14 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:14 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:14 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:14 --> Parser Class Initialized
INFO - 2023-10-14 04:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:14 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:14 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:14 --> Controller Class Initialized
INFO - 2023-10-14 04:57:14 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:14 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:14 --> Model Class Initialized
INFO - 2023-10-14 04:57:15 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:15 --> Total execution time: 0.3643
ERROR - 2023-10-14 04:57:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:41 --> Config Class Initialized
INFO - 2023-10-14 04:57:41 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:41 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:41 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:41 --> URI Class Initialized
DEBUG - 2023-10-14 04:57:41 --> No URI present. Default controller set.
INFO - 2023-10-14 04:57:41 --> Router Class Initialized
INFO - 2023-10-14 04:57:41 --> Output Class Initialized
INFO - 2023-10-14 04:57:41 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:41 --> Input Class Initialized
INFO - 2023-10-14 04:57:41 --> Language Class Initialized
INFO - 2023-10-14 04:57:41 --> Loader Class Initialized
INFO - 2023-10-14 04:57:41 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:41 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:41 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:41 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:41 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:41 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:41 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:41 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:41 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:41 --> Parser Class Initialized
INFO - 2023-10-14 04:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:41 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:41 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:41 --> Controller Class Initialized
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
INFO - 2023-10-14 04:57:41 --> Model Class Initialized
INFO - 2023-10-14 04:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:57:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:57:42 --> Model Class Initialized
INFO - 2023-10-14 04:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:57:42 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:42 --> Total execution time: 0.2042
ERROR - 2023-10-14 04:57:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:49 --> Config Class Initialized
INFO - 2023-10-14 04:57:49 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:49 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:49 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:49 --> URI Class Initialized
INFO - 2023-10-14 04:57:49 --> Router Class Initialized
INFO - 2023-10-14 04:57:49 --> Output Class Initialized
INFO - 2023-10-14 04:57:49 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:49 --> Input Class Initialized
INFO - 2023-10-14 04:57:49 --> Language Class Initialized
INFO - 2023-10-14 04:57:49 --> Loader Class Initialized
INFO - 2023-10-14 04:57:49 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:49 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:49 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:49 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:49 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:49 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:49 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:49 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:49 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:49 --> Parser Class Initialized
INFO - 2023-10-14 04:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:49 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:49 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:49 --> Controller Class Initialized
INFO - 2023-10-14 04:57:49 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:49 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:49 --> Model Class Initialized
INFO - 2023-10-14 04:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 04:57:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:57:49 --> Model Class Initialized
INFO - 2023-10-14 04:57:49 --> Model Class Initialized
INFO - 2023-10-14 04:57:49 --> Model Class Initialized
INFO - 2023-10-14 04:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:57:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:57:49 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:49 --> Total execution time: 0.1363
ERROR - 2023-10-14 04:57:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:50 --> Config Class Initialized
INFO - 2023-10-14 04:57:50 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:50 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:50 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:50 --> URI Class Initialized
INFO - 2023-10-14 04:57:50 --> Router Class Initialized
INFO - 2023-10-14 04:57:50 --> Output Class Initialized
INFO - 2023-10-14 04:57:50 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:50 --> Input Class Initialized
INFO - 2023-10-14 04:57:50 --> Language Class Initialized
INFO - 2023-10-14 04:57:50 --> Loader Class Initialized
INFO - 2023-10-14 04:57:50 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:50 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:50 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:50 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:50 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:50 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:50 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:50 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:50 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:50 --> Parser Class Initialized
INFO - 2023-10-14 04:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:50 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:50 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:50 --> Controller Class Initialized
INFO - 2023-10-14 04:57:50 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:50 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:50 --> Model Class Initialized
INFO - 2023-10-14 04:57:50 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:50 --> Total execution time: 0.0401
ERROR - 2023-10-14 04:57:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:58 --> Config Class Initialized
INFO - 2023-10-14 04:57:58 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:58 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:58 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:58 --> URI Class Initialized
INFO - 2023-10-14 04:57:58 --> Router Class Initialized
INFO - 2023-10-14 04:57:58 --> Output Class Initialized
INFO - 2023-10-14 04:57:58 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:58 --> Input Class Initialized
INFO - 2023-10-14 04:57:58 --> Language Class Initialized
INFO - 2023-10-14 04:57:58 --> Loader Class Initialized
INFO - 2023-10-14 04:57:58 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:58 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:58 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:58 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:58 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:58 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:58 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:58 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:58 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:58 --> Parser Class Initialized
INFO - 2023-10-14 04:57:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:58 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:58 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:58 --> Controller Class Initialized
INFO - 2023-10-14 04:57:58 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:58 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:58 --> Model Class Initialized
INFO - 2023-10-14 04:57:58 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:58 --> Total execution time: 0.0305
ERROR - 2023-10-14 04:57:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:57:59 --> Config Class Initialized
INFO - 2023-10-14 04:57:59 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:57:59 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:57:59 --> Utf8 Class Initialized
INFO - 2023-10-14 04:57:59 --> URI Class Initialized
INFO - 2023-10-14 04:57:59 --> Router Class Initialized
INFO - 2023-10-14 04:57:59 --> Output Class Initialized
INFO - 2023-10-14 04:57:59 --> Security Class Initialized
DEBUG - 2023-10-14 04:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:57:59 --> Input Class Initialized
INFO - 2023-10-14 04:57:59 --> Language Class Initialized
INFO - 2023-10-14 04:57:59 --> Loader Class Initialized
INFO - 2023-10-14 04:57:59 --> Helper loaded: url_helper
INFO - 2023-10-14 04:57:59 --> Helper loaded: file_helper
INFO - 2023-10-14 04:57:59 --> Helper loaded: html_helper
INFO - 2023-10-14 04:57:59 --> Helper loaded: text_helper
INFO - 2023-10-14 04:57:59 --> Helper loaded: form_helper
INFO - 2023-10-14 04:57:59 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:57:59 --> Helper loaded: security_helper
INFO - 2023-10-14 04:57:59 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:57:59 --> Database Driver Class Initialized
INFO - 2023-10-14 04:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:57:59 --> Parser Class Initialized
INFO - 2023-10-14 04:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:57:59 --> Pagination Class Initialized
INFO - 2023-10-14 04:57:59 --> Form Validation Class Initialized
INFO - 2023-10-14 04:57:59 --> Controller Class Initialized
INFO - 2023-10-14 04:57:59 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:59 --> Model Class Initialized
DEBUG - 2023-10-14 04:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:57:59 --> Model Class Initialized
INFO - 2023-10-14 04:57:59 --> Final output sent to browser
DEBUG - 2023-10-14 04:57:59 --> Total execution time: 0.0287
ERROR - 2023-10-14 04:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 04:58:09 --> Config Class Initialized
INFO - 2023-10-14 04:58:09 --> Hooks Class Initialized
DEBUG - 2023-10-14 04:58:09 --> UTF-8 Support Enabled
INFO - 2023-10-14 04:58:09 --> Utf8 Class Initialized
INFO - 2023-10-14 04:58:09 --> URI Class Initialized
DEBUG - 2023-10-14 04:58:09 --> No URI present. Default controller set.
INFO - 2023-10-14 04:58:09 --> Router Class Initialized
INFO - 2023-10-14 04:58:09 --> Output Class Initialized
INFO - 2023-10-14 04:58:09 --> Security Class Initialized
DEBUG - 2023-10-14 04:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 04:58:09 --> Input Class Initialized
INFO - 2023-10-14 04:58:09 --> Language Class Initialized
INFO - 2023-10-14 04:58:09 --> Loader Class Initialized
INFO - 2023-10-14 04:58:09 --> Helper loaded: url_helper
INFO - 2023-10-14 04:58:09 --> Helper loaded: file_helper
INFO - 2023-10-14 04:58:09 --> Helper loaded: html_helper
INFO - 2023-10-14 04:58:09 --> Helper loaded: text_helper
INFO - 2023-10-14 04:58:09 --> Helper loaded: form_helper
INFO - 2023-10-14 04:58:09 --> Helper loaded: lang_helper
INFO - 2023-10-14 04:58:09 --> Helper loaded: security_helper
INFO - 2023-10-14 04:58:09 --> Helper loaded: cookie_helper
INFO - 2023-10-14 04:58:09 --> Database Driver Class Initialized
INFO - 2023-10-14 04:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 04:58:09 --> Parser Class Initialized
INFO - 2023-10-14 04:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 04:58:09 --> Pagination Class Initialized
INFO - 2023-10-14 04:58:09 --> Form Validation Class Initialized
INFO - 2023-10-14 04:58:09 --> Controller Class Initialized
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
DEBUG - 2023-10-14 04:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
DEBUG - 2023-10-14 04:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
DEBUG - 2023-10-14 04:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 04:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
INFO - 2023-10-14 04:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 04:58:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 04:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 04:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 04:58:09 --> Model Class Initialized
INFO - 2023-10-14 04:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 04:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 04:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 04:58:09 --> Final output sent to browser
DEBUG - 2023-10-14 04:58:09 --> Total execution time: 0.1967
ERROR - 2023-10-14 05:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 05:22:49 --> Config Class Initialized
INFO - 2023-10-14 05:22:49 --> Hooks Class Initialized
DEBUG - 2023-10-14 05:22:49 --> UTF-8 Support Enabled
INFO - 2023-10-14 05:22:49 --> Utf8 Class Initialized
INFO - 2023-10-14 05:22:49 --> URI Class Initialized
DEBUG - 2023-10-14 05:22:49 --> No URI present. Default controller set.
INFO - 2023-10-14 05:22:49 --> Router Class Initialized
INFO - 2023-10-14 05:22:49 --> Output Class Initialized
INFO - 2023-10-14 05:22:49 --> Security Class Initialized
DEBUG - 2023-10-14 05:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 05:22:49 --> Input Class Initialized
INFO - 2023-10-14 05:22:49 --> Language Class Initialized
INFO - 2023-10-14 05:22:49 --> Loader Class Initialized
INFO - 2023-10-14 05:22:49 --> Helper loaded: url_helper
INFO - 2023-10-14 05:22:49 --> Helper loaded: file_helper
INFO - 2023-10-14 05:22:49 --> Helper loaded: html_helper
INFO - 2023-10-14 05:22:49 --> Helper loaded: text_helper
INFO - 2023-10-14 05:22:49 --> Helper loaded: form_helper
INFO - 2023-10-14 05:22:49 --> Helper loaded: lang_helper
INFO - 2023-10-14 05:22:49 --> Helper loaded: security_helper
INFO - 2023-10-14 05:22:49 --> Helper loaded: cookie_helper
INFO - 2023-10-14 05:22:49 --> Database Driver Class Initialized
INFO - 2023-10-14 05:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 05:22:49 --> Parser Class Initialized
INFO - 2023-10-14 05:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 05:22:49 --> Pagination Class Initialized
INFO - 2023-10-14 05:22:49 --> Form Validation Class Initialized
INFO - 2023-10-14 05:22:49 --> Controller Class Initialized
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
DEBUG - 2023-10-14 05:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
DEBUG - 2023-10-14 05:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
DEBUG - 2023-10-14 05:22:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 05:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
INFO - 2023-10-14 05:22:49 --> Model Class Initialized
INFO - 2023-10-14 05:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 05:22:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 05:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 05:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 05:22:50 --> Model Class Initialized
INFO - 2023-10-14 05:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 05:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 05:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 05:22:50 --> Final output sent to browser
DEBUG - 2023-10-14 05:22:50 --> Total execution time: 0.2002
ERROR - 2023-10-14 06:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:26 --> Config Class Initialized
INFO - 2023-10-14 06:15:26 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:26 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:26 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:26 --> URI Class Initialized
DEBUG - 2023-10-14 06:15:26 --> No URI present. Default controller set.
INFO - 2023-10-14 06:15:26 --> Router Class Initialized
INFO - 2023-10-14 06:15:26 --> Output Class Initialized
INFO - 2023-10-14 06:15:26 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:26 --> Input Class Initialized
INFO - 2023-10-14 06:15:26 --> Language Class Initialized
INFO - 2023-10-14 06:15:26 --> Loader Class Initialized
INFO - 2023-10-14 06:15:26 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:26 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:26 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:26 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:26 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:26 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:26 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:26 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:26 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:26 --> Parser Class Initialized
INFO - 2023-10-14 06:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:26 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:26 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:26 --> Controller Class Initialized
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
INFO - 2023-10-14 06:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 06:15:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:15:26 --> Model Class Initialized
INFO - 2023-10-14 06:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:15:26 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:26 --> Total execution time: 0.3598
ERROR - 2023-10-14 06:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:37 --> Config Class Initialized
INFO - 2023-10-14 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:37 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:37 --> URI Class Initialized
INFO - 2023-10-14 06:15:37 --> Router Class Initialized
INFO - 2023-10-14 06:15:37 --> Output Class Initialized
INFO - 2023-10-14 06:15:37 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:37 --> Input Class Initialized
INFO - 2023-10-14 06:15:37 --> Language Class Initialized
INFO - 2023-10-14 06:15:37 --> Loader Class Initialized
INFO - 2023-10-14 06:15:37 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:37 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:37 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:37 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:37 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:37 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:37 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:37 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:37 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:37 --> Parser Class Initialized
INFO - 2023-10-14 06:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:37 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:37 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:37 --> Controller Class Initialized
INFO - 2023-10-14 06:15:37 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:37 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:37 --> Model Class Initialized
INFO - 2023-10-14 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 06:15:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:15:37 --> Model Class Initialized
INFO - 2023-10-14 06:15:37 --> Model Class Initialized
INFO - 2023-10-14 06:15:37 --> Model Class Initialized
INFO - 2023-10-14 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:15:37 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:37 --> Total execution time: 0.1870
ERROR - 2023-10-14 06:15:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:38 --> Config Class Initialized
INFO - 2023-10-14 06:15:38 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:38 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:38 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:38 --> URI Class Initialized
INFO - 2023-10-14 06:15:38 --> Router Class Initialized
INFO - 2023-10-14 06:15:38 --> Output Class Initialized
INFO - 2023-10-14 06:15:38 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:38 --> Input Class Initialized
INFO - 2023-10-14 06:15:38 --> Language Class Initialized
INFO - 2023-10-14 06:15:38 --> Loader Class Initialized
INFO - 2023-10-14 06:15:38 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:38 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:38 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:38 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:38 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:38 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:38 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:38 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:38 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:38 --> Parser Class Initialized
INFO - 2023-10-14 06:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:38 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:38 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:38 --> Controller Class Initialized
INFO - 2023-10-14 06:15:38 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:38 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:38 --> Model Class Initialized
INFO - 2023-10-14 06:15:38 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:38 --> Total execution time: 0.0642
ERROR - 2023-10-14 06:15:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:42 --> Config Class Initialized
INFO - 2023-10-14 06:15:42 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:42 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:42 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:42 --> URI Class Initialized
INFO - 2023-10-14 06:15:42 --> Router Class Initialized
INFO - 2023-10-14 06:15:42 --> Output Class Initialized
INFO - 2023-10-14 06:15:42 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:42 --> Input Class Initialized
INFO - 2023-10-14 06:15:42 --> Language Class Initialized
INFO - 2023-10-14 06:15:42 --> Loader Class Initialized
INFO - 2023-10-14 06:15:42 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:42 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:42 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:42 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:42 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:42 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:42 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:42 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:42 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:42 --> Parser Class Initialized
INFO - 2023-10-14 06:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:42 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:42 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:42 --> Controller Class Initialized
INFO - 2023-10-14 06:15:42 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:42 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:42 --> Model Class Initialized
INFO - 2023-10-14 06:15:43 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:43 --> Total execution time: 0.0573
ERROR - 2023-10-14 06:15:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:43 --> Config Class Initialized
INFO - 2023-10-14 06:15:43 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:43 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:43 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:43 --> URI Class Initialized
INFO - 2023-10-14 06:15:43 --> Router Class Initialized
INFO - 2023-10-14 06:15:43 --> Output Class Initialized
INFO - 2023-10-14 06:15:43 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:43 --> Input Class Initialized
INFO - 2023-10-14 06:15:43 --> Language Class Initialized
INFO - 2023-10-14 06:15:43 --> Loader Class Initialized
INFO - 2023-10-14 06:15:43 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:43 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:43 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:43 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:43 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:43 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:43 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:43 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:43 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:43 --> Parser Class Initialized
INFO - 2023-10-14 06:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:43 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:43 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:43 --> Controller Class Initialized
INFO - 2023-10-14 06:15:43 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:43 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:43 --> Model Class Initialized
INFO - 2023-10-14 06:15:43 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:43 --> Total execution time: 0.0571
ERROR - 2023-10-14 06:15:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:44 --> Config Class Initialized
INFO - 2023-10-14 06:15:44 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:44 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:44 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:44 --> URI Class Initialized
INFO - 2023-10-14 06:15:44 --> Router Class Initialized
INFO - 2023-10-14 06:15:44 --> Output Class Initialized
INFO - 2023-10-14 06:15:44 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:44 --> Input Class Initialized
INFO - 2023-10-14 06:15:44 --> Language Class Initialized
INFO - 2023-10-14 06:15:44 --> Loader Class Initialized
INFO - 2023-10-14 06:15:44 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:44 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:44 --> Parser Class Initialized
INFO - 2023-10-14 06:15:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:44 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:44 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:44 --> Controller Class Initialized
INFO - 2023-10-14 06:15:44 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:44 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:44 --> Model Class Initialized
INFO - 2023-10-14 06:15:44 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:44 --> Total execution time: 0.0600
ERROR - 2023-10-14 06:15:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:44 --> Config Class Initialized
INFO - 2023-10-14 06:15:44 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:44 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:44 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:44 --> URI Class Initialized
INFO - 2023-10-14 06:15:44 --> Router Class Initialized
INFO - 2023-10-14 06:15:44 --> Output Class Initialized
INFO - 2023-10-14 06:15:44 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:44 --> Input Class Initialized
INFO - 2023-10-14 06:15:44 --> Language Class Initialized
INFO - 2023-10-14 06:15:44 --> Loader Class Initialized
INFO - 2023-10-14 06:15:44 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:44 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:44 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:44 --> Parser Class Initialized
INFO - 2023-10-14 06:15:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:44 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:44 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:44 --> Controller Class Initialized
INFO - 2023-10-14 06:15:44 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:44 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:44 --> Model Class Initialized
INFO - 2023-10-14 06:15:44 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:44 --> Total execution time: 0.0597
ERROR - 2023-10-14 06:15:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:45 --> Config Class Initialized
INFO - 2023-10-14 06:15:45 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:45 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:45 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:45 --> URI Class Initialized
INFO - 2023-10-14 06:15:45 --> Router Class Initialized
INFO - 2023-10-14 06:15:45 --> Output Class Initialized
INFO - 2023-10-14 06:15:45 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:45 --> Input Class Initialized
INFO - 2023-10-14 06:15:45 --> Language Class Initialized
INFO - 2023-10-14 06:15:45 --> Loader Class Initialized
INFO - 2023-10-14 06:15:45 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:45 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:45 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:45 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:45 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:45 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:45 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:45 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:45 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:45 --> Parser Class Initialized
INFO - 2023-10-14 06:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:45 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:45 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:45 --> Controller Class Initialized
INFO - 2023-10-14 06:15:45 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:45 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:45 --> Model Class Initialized
INFO - 2023-10-14 06:15:45 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:45 --> Total execution time: 0.0703
ERROR - 2023-10-14 06:15:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:46 --> Config Class Initialized
INFO - 2023-10-14 06:15:46 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:46 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:46 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:46 --> URI Class Initialized
INFO - 2023-10-14 06:15:46 --> Router Class Initialized
INFO - 2023-10-14 06:15:46 --> Output Class Initialized
INFO - 2023-10-14 06:15:46 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:46 --> Input Class Initialized
INFO - 2023-10-14 06:15:46 --> Language Class Initialized
INFO - 2023-10-14 06:15:46 --> Loader Class Initialized
INFO - 2023-10-14 06:15:46 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:46 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:46 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:46 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:46 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:46 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:46 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:46 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:46 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:46 --> Parser Class Initialized
INFO - 2023-10-14 06:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:46 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:46 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:46 --> Controller Class Initialized
INFO - 2023-10-14 06:15:46 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:46 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:46 --> Model Class Initialized
INFO - 2023-10-14 06:15:46 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:46 --> Total execution time: 0.0222
ERROR - 2023-10-14 06:15:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:47 --> Config Class Initialized
INFO - 2023-10-14 06:15:47 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:47 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:47 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:47 --> URI Class Initialized
INFO - 2023-10-14 06:15:47 --> Router Class Initialized
INFO - 2023-10-14 06:15:47 --> Output Class Initialized
INFO - 2023-10-14 06:15:47 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:47 --> Input Class Initialized
INFO - 2023-10-14 06:15:47 --> Language Class Initialized
INFO - 2023-10-14 06:15:47 --> Loader Class Initialized
INFO - 2023-10-14 06:15:47 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:47 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:47 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:47 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:47 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:47 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:47 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:47 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:47 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:47 --> Parser Class Initialized
INFO - 2023-10-14 06:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:47 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:47 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:47 --> Controller Class Initialized
INFO - 2023-10-14 06:15:47 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:47 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:47 --> Model Class Initialized
INFO - 2023-10-14 06:15:47 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:47 --> Total execution time: 0.0220
ERROR - 2023-10-14 06:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:49 --> Config Class Initialized
INFO - 2023-10-14 06:15:49 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:49 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:49 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:49 --> URI Class Initialized
INFO - 2023-10-14 06:15:49 --> Router Class Initialized
INFO - 2023-10-14 06:15:49 --> Output Class Initialized
INFO - 2023-10-14 06:15:49 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:49 --> Input Class Initialized
INFO - 2023-10-14 06:15:49 --> Language Class Initialized
INFO - 2023-10-14 06:15:49 --> Loader Class Initialized
INFO - 2023-10-14 06:15:49 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:49 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:49 --> Parser Class Initialized
INFO - 2023-10-14 06:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:49 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:49 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:49 --> Controller Class Initialized
INFO - 2023-10-14 06:15:49 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:49 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:49 --> Model Class Initialized
INFO - 2023-10-14 06:15:49 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:49 --> Total execution time: 0.0216
ERROR - 2023-10-14 06:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:49 --> Config Class Initialized
INFO - 2023-10-14 06:15:49 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:49 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:49 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:49 --> URI Class Initialized
INFO - 2023-10-14 06:15:49 --> Router Class Initialized
INFO - 2023-10-14 06:15:49 --> Output Class Initialized
INFO - 2023-10-14 06:15:49 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:49 --> Input Class Initialized
INFO - 2023-10-14 06:15:49 --> Language Class Initialized
INFO - 2023-10-14 06:15:49 --> Loader Class Initialized
INFO - 2023-10-14 06:15:49 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:49 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:49 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:49 --> Parser Class Initialized
INFO - 2023-10-14 06:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:49 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:49 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:49 --> Controller Class Initialized
INFO - 2023-10-14 06:15:49 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:49 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:49 --> Model Class Initialized
INFO - 2023-10-14 06:15:49 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:49 --> Total execution time: 0.0567
ERROR - 2023-10-14 06:15:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:15:55 --> Config Class Initialized
INFO - 2023-10-14 06:15:55 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:15:55 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:15:55 --> Utf8 Class Initialized
INFO - 2023-10-14 06:15:55 --> URI Class Initialized
INFO - 2023-10-14 06:15:55 --> Router Class Initialized
INFO - 2023-10-14 06:15:55 --> Output Class Initialized
INFO - 2023-10-14 06:15:55 --> Security Class Initialized
DEBUG - 2023-10-14 06:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:15:55 --> Input Class Initialized
INFO - 2023-10-14 06:15:55 --> Language Class Initialized
INFO - 2023-10-14 06:15:55 --> Loader Class Initialized
INFO - 2023-10-14 06:15:55 --> Helper loaded: url_helper
INFO - 2023-10-14 06:15:55 --> Helper loaded: file_helper
INFO - 2023-10-14 06:15:55 --> Helper loaded: html_helper
INFO - 2023-10-14 06:15:55 --> Helper loaded: text_helper
INFO - 2023-10-14 06:15:55 --> Helper loaded: form_helper
INFO - 2023-10-14 06:15:55 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:15:55 --> Helper loaded: security_helper
INFO - 2023-10-14 06:15:55 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:15:55 --> Database Driver Class Initialized
INFO - 2023-10-14 06:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:15:55 --> Parser Class Initialized
INFO - 2023-10-14 06:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:15:55 --> Pagination Class Initialized
INFO - 2023-10-14 06:15:55 --> Form Validation Class Initialized
INFO - 2023-10-14 06:15:55 --> Controller Class Initialized
INFO - 2023-10-14 06:15:55 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:55 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:55 --> Model Class Initialized
DEBUG - 2023-10-14 06:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 06:15:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:15:55 --> Model Class Initialized
INFO - 2023-10-14 06:15:55 --> Model Class Initialized
INFO - 2023-10-14 06:15:55 --> Model Class Initialized
INFO - 2023-10-14 06:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:15:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:15:55 --> Final output sent to browser
DEBUG - 2023-10-14 06:15:55 --> Total execution time: 0.1941
ERROR - 2023-10-14 06:18:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:18:15 --> Config Class Initialized
INFO - 2023-10-14 06:18:15 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:18:15 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:18:15 --> Utf8 Class Initialized
INFO - 2023-10-14 06:18:15 --> URI Class Initialized
DEBUG - 2023-10-14 06:18:15 --> No URI present. Default controller set.
INFO - 2023-10-14 06:18:15 --> Router Class Initialized
INFO - 2023-10-14 06:18:15 --> Output Class Initialized
INFO - 2023-10-14 06:18:15 --> Security Class Initialized
DEBUG - 2023-10-14 06:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:18:15 --> Input Class Initialized
INFO - 2023-10-14 06:18:15 --> Language Class Initialized
INFO - 2023-10-14 06:18:15 --> Loader Class Initialized
INFO - 2023-10-14 06:18:15 --> Helper loaded: url_helper
INFO - 2023-10-14 06:18:15 --> Helper loaded: file_helper
INFO - 2023-10-14 06:18:15 --> Helper loaded: html_helper
INFO - 2023-10-14 06:18:15 --> Helper loaded: text_helper
INFO - 2023-10-14 06:18:15 --> Helper loaded: form_helper
INFO - 2023-10-14 06:18:15 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:18:15 --> Helper loaded: security_helper
INFO - 2023-10-14 06:18:15 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:18:15 --> Database Driver Class Initialized
INFO - 2023-10-14 06:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:18:15 --> Parser Class Initialized
INFO - 2023-10-14 06:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:18:15 --> Pagination Class Initialized
INFO - 2023-10-14 06:18:15 --> Form Validation Class Initialized
INFO - 2023-10-14 06:18:15 --> Controller Class Initialized
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
INFO - 2023-10-14 06:18:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 06:18:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:18:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:18:15 --> Model Class Initialized
INFO - 2023-10-14 06:18:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:18:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:18:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:18:15 --> Final output sent to browser
DEBUG - 2023-10-14 06:18:15 --> Total execution time: 0.3616
ERROR - 2023-10-14 06:18:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:18:21 --> Config Class Initialized
INFO - 2023-10-14 06:18:21 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:18:21 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:18:21 --> Utf8 Class Initialized
INFO - 2023-10-14 06:18:21 --> URI Class Initialized
INFO - 2023-10-14 06:18:21 --> Router Class Initialized
INFO - 2023-10-14 06:18:21 --> Output Class Initialized
INFO - 2023-10-14 06:18:21 --> Security Class Initialized
DEBUG - 2023-10-14 06:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:18:21 --> Input Class Initialized
INFO - 2023-10-14 06:18:21 --> Language Class Initialized
INFO - 2023-10-14 06:18:21 --> Loader Class Initialized
INFO - 2023-10-14 06:18:21 --> Helper loaded: url_helper
INFO - 2023-10-14 06:18:21 --> Helper loaded: file_helper
INFO - 2023-10-14 06:18:21 --> Helper loaded: html_helper
INFO - 2023-10-14 06:18:21 --> Helper loaded: text_helper
INFO - 2023-10-14 06:18:21 --> Helper loaded: form_helper
INFO - 2023-10-14 06:18:21 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:18:21 --> Helper loaded: security_helper
INFO - 2023-10-14 06:18:21 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:18:21 --> Database Driver Class Initialized
INFO - 2023-10-14 06:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:18:21 --> Parser Class Initialized
INFO - 2023-10-14 06:18:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:18:21 --> Pagination Class Initialized
INFO - 2023-10-14 06:18:21 --> Form Validation Class Initialized
INFO - 2023-10-14 06:18:21 --> Controller Class Initialized
INFO - 2023-10-14 06:18:21 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:21 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:21 --> Model Class Initialized
INFO - 2023-10-14 06:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 06:18:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:18:21 --> Model Class Initialized
INFO - 2023-10-14 06:18:21 --> Model Class Initialized
INFO - 2023-10-14 06:18:21 --> Model Class Initialized
INFO - 2023-10-14 06:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:18:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:18:21 --> Final output sent to browser
DEBUG - 2023-10-14 06:18:21 --> Total execution time: 0.2353
ERROR - 2023-10-14 06:18:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:18:22 --> Config Class Initialized
INFO - 2023-10-14 06:18:22 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:18:22 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:18:22 --> Utf8 Class Initialized
INFO - 2023-10-14 06:18:22 --> URI Class Initialized
INFO - 2023-10-14 06:18:22 --> Router Class Initialized
INFO - 2023-10-14 06:18:22 --> Output Class Initialized
INFO - 2023-10-14 06:18:22 --> Security Class Initialized
DEBUG - 2023-10-14 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:18:22 --> Input Class Initialized
INFO - 2023-10-14 06:18:22 --> Language Class Initialized
INFO - 2023-10-14 06:18:22 --> Loader Class Initialized
INFO - 2023-10-14 06:18:22 --> Helper loaded: url_helper
INFO - 2023-10-14 06:18:22 --> Helper loaded: file_helper
INFO - 2023-10-14 06:18:22 --> Helper loaded: html_helper
INFO - 2023-10-14 06:18:22 --> Helper loaded: text_helper
INFO - 2023-10-14 06:18:22 --> Helper loaded: form_helper
INFO - 2023-10-14 06:18:22 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:18:22 --> Helper loaded: security_helper
INFO - 2023-10-14 06:18:22 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:18:22 --> Database Driver Class Initialized
INFO - 2023-10-14 06:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:18:22 --> Parser Class Initialized
INFO - 2023-10-14 06:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:18:22 --> Pagination Class Initialized
INFO - 2023-10-14 06:18:22 --> Form Validation Class Initialized
INFO - 2023-10-14 06:18:22 --> Controller Class Initialized
INFO - 2023-10-14 06:18:22 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:22 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:22 --> Model Class Initialized
INFO - 2023-10-14 06:18:22 --> Final output sent to browser
DEBUG - 2023-10-14 06:18:22 --> Total execution time: 0.0604
ERROR - 2023-10-14 06:18:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:18:31 --> Config Class Initialized
INFO - 2023-10-14 06:18:31 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:18:31 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:18:31 --> Utf8 Class Initialized
INFO - 2023-10-14 06:18:31 --> URI Class Initialized
INFO - 2023-10-14 06:18:31 --> Router Class Initialized
INFO - 2023-10-14 06:18:31 --> Output Class Initialized
INFO - 2023-10-14 06:18:31 --> Security Class Initialized
DEBUG - 2023-10-14 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:18:31 --> Input Class Initialized
INFO - 2023-10-14 06:18:31 --> Language Class Initialized
INFO - 2023-10-14 06:18:31 --> Loader Class Initialized
INFO - 2023-10-14 06:18:31 --> Helper loaded: url_helper
INFO - 2023-10-14 06:18:31 --> Helper loaded: file_helper
INFO - 2023-10-14 06:18:31 --> Helper loaded: html_helper
INFO - 2023-10-14 06:18:31 --> Helper loaded: text_helper
INFO - 2023-10-14 06:18:31 --> Helper loaded: form_helper
INFO - 2023-10-14 06:18:31 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:18:31 --> Helper loaded: security_helper
INFO - 2023-10-14 06:18:31 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:18:31 --> Database Driver Class Initialized
INFO - 2023-10-14 06:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:18:31 --> Parser Class Initialized
INFO - 2023-10-14 06:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:18:31 --> Pagination Class Initialized
INFO - 2023-10-14 06:18:31 --> Form Validation Class Initialized
INFO - 2023-10-14 06:18:31 --> Controller Class Initialized
INFO - 2023-10-14 06:18:31 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:31 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:31 --> Model Class Initialized
INFO - 2023-10-14 06:18:31 --> Final output sent to browser
DEBUG - 2023-10-14 06:18:31 --> Total execution time: 0.0576
ERROR - 2023-10-14 06:18:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:18:33 --> Config Class Initialized
INFO - 2023-10-14 06:18:33 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:18:33 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:18:33 --> Utf8 Class Initialized
INFO - 2023-10-14 06:18:33 --> URI Class Initialized
INFO - 2023-10-14 06:18:33 --> Router Class Initialized
INFO - 2023-10-14 06:18:33 --> Output Class Initialized
INFO - 2023-10-14 06:18:33 --> Security Class Initialized
DEBUG - 2023-10-14 06:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:18:33 --> Input Class Initialized
INFO - 2023-10-14 06:18:33 --> Language Class Initialized
INFO - 2023-10-14 06:18:33 --> Loader Class Initialized
INFO - 2023-10-14 06:18:33 --> Helper loaded: url_helper
INFO - 2023-10-14 06:18:33 --> Helper loaded: file_helper
INFO - 2023-10-14 06:18:33 --> Helper loaded: html_helper
INFO - 2023-10-14 06:18:33 --> Helper loaded: text_helper
INFO - 2023-10-14 06:18:33 --> Helper loaded: form_helper
INFO - 2023-10-14 06:18:33 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:18:33 --> Helper loaded: security_helper
INFO - 2023-10-14 06:18:33 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:18:33 --> Database Driver Class Initialized
INFO - 2023-10-14 06:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:18:33 --> Parser Class Initialized
INFO - 2023-10-14 06:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:18:33 --> Pagination Class Initialized
INFO - 2023-10-14 06:18:33 --> Form Validation Class Initialized
INFO - 2023-10-14 06:18:33 --> Controller Class Initialized
INFO - 2023-10-14 06:18:33 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:33 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:33 --> Model Class Initialized
INFO - 2023-10-14 06:18:33 --> Final output sent to browser
DEBUG - 2023-10-14 06:18:33 --> Total execution time: 0.0447
ERROR - 2023-10-14 06:18:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:18:36 --> Config Class Initialized
INFO - 2023-10-14 06:18:36 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:18:36 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:18:36 --> Utf8 Class Initialized
INFO - 2023-10-14 06:18:36 --> URI Class Initialized
INFO - 2023-10-14 06:18:36 --> Router Class Initialized
INFO - 2023-10-14 06:18:36 --> Output Class Initialized
INFO - 2023-10-14 06:18:36 --> Security Class Initialized
DEBUG - 2023-10-14 06:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:18:36 --> Input Class Initialized
INFO - 2023-10-14 06:18:36 --> Language Class Initialized
INFO - 2023-10-14 06:18:36 --> Loader Class Initialized
INFO - 2023-10-14 06:18:36 --> Helper loaded: url_helper
INFO - 2023-10-14 06:18:36 --> Helper loaded: file_helper
INFO - 2023-10-14 06:18:36 --> Helper loaded: html_helper
INFO - 2023-10-14 06:18:36 --> Helper loaded: text_helper
INFO - 2023-10-14 06:18:36 --> Helper loaded: form_helper
INFO - 2023-10-14 06:18:36 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:18:36 --> Helper loaded: security_helper
INFO - 2023-10-14 06:18:36 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:18:36 --> Database Driver Class Initialized
INFO - 2023-10-14 06:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:18:36 --> Parser Class Initialized
INFO - 2023-10-14 06:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:18:36 --> Pagination Class Initialized
INFO - 2023-10-14 06:18:36 --> Form Validation Class Initialized
INFO - 2023-10-14 06:18:36 --> Controller Class Initialized
INFO - 2023-10-14 06:18:36 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:36 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:36 --> Model Class Initialized
DEBUG - 2023-10-14 06:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 06:18:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:18:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:18:36 --> Model Class Initialized
INFO - 2023-10-14 06:18:36 --> Model Class Initialized
INFO - 2023-10-14 06:18:36 --> Model Class Initialized
INFO - 2023-10-14 06:18:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:18:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:18:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:18:37 --> Final output sent to browser
DEBUG - 2023-10-14 06:18:37 --> Total execution time: 0.2026
ERROR - 2023-10-14 06:19:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:30 --> Config Class Initialized
INFO - 2023-10-14 06:19:30 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:30 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:30 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:30 --> URI Class Initialized
INFO - 2023-10-14 06:19:30 --> Router Class Initialized
INFO - 2023-10-14 06:19:30 --> Output Class Initialized
INFO - 2023-10-14 06:19:30 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:30 --> Input Class Initialized
INFO - 2023-10-14 06:19:30 --> Language Class Initialized
INFO - 2023-10-14 06:19:30 --> Loader Class Initialized
INFO - 2023-10-14 06:19:30 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:30 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:30 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:30 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:30 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:30 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:30 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:30 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:30 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:30 --> Parser Class Initialized
INFO - 2023-10-14 06:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:30 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:30 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:30 --> Controller Class Initialized
INFO - 2023-10-14 06:19:30 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:30 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:30 --> Model Class Initialized
INFO - 2023-10-14 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 06:19:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:19:30 --> Model Class Initialized
INFO - 2023-10-14 06:19:30 --> Model Class Initialized
INFO - 2023-10-14 06:19:30 --> Model Class Initialized
INFO - 2023-10-14 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:19:30 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:30 --> Total execution time: 0.1898
ERROR - 2023-10-14 06:19:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:31 --> Config Class Initialized
INFO - 2023-10-14 06:19:31 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:31 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:31 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:31 --> URI Class Initialized
INFO - 2023-10-14 06:19:31 --> Router Class Initialized
INFO - 2023-10-14 06:19:31 --> Output Class Initialized
INFO - 2023-10-14 06:19:31 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:31 --> Input Class Initialized
INFO - 2023-10-14 06:19:31 --> Language Class Initialized
INFO - 2023-10-14 06:19:31 --> Loader Class Initialized
INFO - 2023-10-14 06:19:31 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:31 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:31 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:31 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:31 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:31 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:31 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:31 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:31 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:31 --> Parser Class Initialized
INFO - 2023-10-14 06:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:31 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:31 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:31 --> Controller Class Initialized
INFO - 2023-10-14 06:19:31 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:31 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:31 --> Model Class Initialized
INFO - 2023-10-14 06:19:31 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:31 --> Total execution time: 0.0578
ERROR - 2023-10-14 06:19:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:36 --> Config Class Initialized
INFO - 2023-10-14 06:19:36 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:36 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:36 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:36 --> URI Class Initialized
INFO - 2023-10-14 06:19:36 --> Router Class Initialized
INFO - 2023-10-14 06:19:36 --> Output Class Initialized
INFO - 2023-10-14 06:19:36 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:36 --> Input Class Initialized
INFO - 2023-10-14 06:19:36 --> Language Class Initialized
INFO - 2023-10-14 06:19:36 --> Loader Class Initialized
INFO - 2023-10-14 06:19:36 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:36 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:36 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:36 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:36 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:36 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:36 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:36 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:36 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:36 --> Parser Class Initialized
INFO - 2023-10-14 06:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:36 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:36 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:36 --> Controller Class Initialized
INFO - 2023-10-14 06:19:36 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:36 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:36 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 06:19:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:19:36 --> Model Class Initialized
INFO - 2023-10-14 06:19:36 --> Model Class Initialized
INFO - 2023-10-14 06:19:36 --> Model Class Initialized
INFO - 2023-10-14 06:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:19:36 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:36 --> Total execution time: 0.1901
ERROR - 2023-10-14 06:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:39 --> Config Class Initialized
INFO - 2023-10-14 06:19:39 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:39 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:39 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:39 --> URI Class Initialized
INFO - 2023-10-14 06:19:39 --> Router Class Initialized
INFO - 2023-10-14 06:19:39 --> Output Class Initialized
INFO - 2023-10-14 06:19:39 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:39 --> Input Class Initialized
INFO - 2023-10-14 06:19:39 --> Language Class Initialized
INFO - 2023-10-14 06:19:39 --> Loader Class Initialized
INFO - 2023-10-14 06:19:39 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:39 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:39 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:39 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:39 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:39 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:39 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:39 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:39 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:39 --> Parser Class Initialized
INFO - 2023-10-14 06:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:39 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:39 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:39 --> Controller Class Initialized
INFO - 2023-10-14 06:19:39 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:39 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:39 --> Model Class Initialized
INFO - 2023-10-14 06:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 06:19:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:19:39 --> Model Class Initialized
INFO - 2023-10-14 06:19:39 --> Model Class Initialized
INFO - 2023-10-14 06:19:39 --> Model Class Initialized
INFO - 2023-10-14 06:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:19:40 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:40 --> Total execution time: 0.1819
ERROR - 2023-10-14 06:19:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:40 --> Config Class Initialized
INFO - 2023-10-14 06:19:40 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:40 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:40 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:40 --> URI Class Initialized
INFO - 2023-10-14 06:19:40 --> Router Class Initialized
INFO - 2023-10-14 06:19:40 --> Output Class Initialized
INFO - 2023-10-14 06:19:40 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:40 --> Input Class Initialized
INFO - 2023-10-14 06:19:40 --> Language Class Initialized
INFO - 2023-10-14 06:19:40 --> Loader Class Initialized
INFO - 2023-10-14 06:19:40 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:40 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:40 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:40 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:40 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:40 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:40 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:40 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:40 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:40 --> Parser Class Initialized
INFO - 2023-10-14 06:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:40 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:40 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:40 --> Controller Class Initialized
INFO - 2023-10-14 06:19:40 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:40 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:40 --> Model Class Initialized
INFO - 2023-10-14 06:19:40 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:40 --> Total execution time: 0.0524
ERROR - 2023-10-14 06:19:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:47 --> Config Class Initialized
INFO - 2023-10-14 06:19:47 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:47 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:47 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:47 --> URI Class Initialized
INFO - 2023-10-14 06:19:47 --> Router Class Initialized
INFO - 2023-10-14 06:19:47 --> Output Class Initialized
INFO - 2023-10-14 06:19:47 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:47 --> Input Class Initialized
INFO - 2023-10-14 06:19:47 --> Language Class Initialized
INFO - 2023-10-14 06:19:47 --> Loader Class Initialized
INFO - 2023-10-14 06:19:47 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:47 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:47 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:47 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:47 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:47 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:47 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:47 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:47 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:47 --> Parser Class Initialized
INFO - 2023-10-14 06:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:47 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:47 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:47 --> Controller Class Initialized
INFO - 2023-10-14 06:19:47 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:47 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:47 --> Model Class Initialized
ERROR - 2023-10-14 06:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-10-14 06:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-10-14 06:19:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:19:47 --> Model Class Initialized
INFO - 2023-10-14 06:19:47 --> Model Class Initialized
INFO - 2023-10-14 06:19:47 --> Model Class Initialized
INFO - 2023-10-14 06:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:19:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:19:47 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:47 --> Total execution time: 0.2394
ERROR - 2023-10-14 06:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:48 --> Config Class Initialized
INFO - 2023-10-14 06:19:48 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:48 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:48 --> URI Class Initialized
INFO - 2023-10-14 06:19:48 --> Router Class Initialized
INFO - 2023-10-14 06:19:48 --> Output Class Initialized
INFO - 2023-10-14 06:19:48 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:48 --> Input Class Initialized
INFO - 2023-10-14 06:19:48 --> Language Class Initialized
INFO - 2023-10-14 06:19:48 --> Loader Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:48 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:48 --> Parser Class Initialized
INFO - 2023-10-14 06:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:48 --> Controller Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:48 --> Total execution time: 0.0211
ERROR - 2023-10-14 06:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:48 --> Config Class Initialized
INFO - 2023-10-14 06:19:48 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:48 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:48 --> URI Class Initialized
INFO - 2023-10-14 06:19:48 --> Router Class Initialized
INFO - 2023-10-14 06:19:48 --> Output Class Initialized
INFO - 2023-10-14 06:19:48 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:48 --> Input Class Initialized
INFO - 2023-10-14 06:19:48 --> Language Class Initialized
ERROR - 2023-10-14 06:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:48 --> Config Class Initialized
INFO - 2023-10-14 06:19:48 --> Hooks Class Initialized
INFO - 2023-10-14 06:19:48 --> Loader Class Initialized
DEBUG - 2023-10-14 06:19:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:48 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:48 --> URI Class Initialized
ERROR - 2023-10-14 06:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:48 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:48 --> Router Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:48 --> Config Class Initialized
INFO - 2023-10-14 06:19:48 --> Hooks Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:48 --> Output Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:48 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:48 --> Utf8 Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:48 --> Input Class Initialized
INFO - 2023-10-14 06:19:48 --> URI Class Initialized
INFO - 2023-10-14 06:19:48 --> Language Class Initialized
INFO - 2023-10-14 06:19:48 --> Router Class Initialized
INFO - 2023-10-14 06:19:48 --> Output Class Initialized
INFO - 2023-10-14 06:19:48 --> Security Class Initialized
INFO - 2023-10-14 06:19:48 --> Loader Class Initialized
INFO - 2023-10-14 06:19:48 --> Database Driver Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:48 --> Input Class Initialized
INFO - 2023-10-14 06:19:48 --> Language Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:48 --> Parser Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:48 --> Loader Class Initialized
INFO - 2023-10-14 06:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:48 --> Controller Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: text_helper
ERROR - 2023-10-14 06:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:48 --> Config Class Initialized
INFO - 2023-10-14 06:19:48 --> Hooks Class Initialized
INFO - 2023-10-14 06:19:48 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Utf8 Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> URI Class Initialized
INFO - 2023-10-14 06:19:48 --> Router Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Output Class Initialized
INFO - 2023-10-14 06:19:48 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:48 --> Security Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:48 --> Input Class Initialized
INFO - 2023-10-14 06:19:48 --> Language Class Initialized
ERROR - 2023-10-14 06:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:48 --> Config Class Initialized
INFO - 2023-10-14 06:19:48 --> Hooks Class Initialized
ERROR - 2023-10-14 06:19:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:48 --> Config Class Initialized
INFO - 2023-10-14 06:19:48 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:48 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:48 --> Loader Class Initialized
INFO - 2023-10-14 06:19:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:48 --> Total execution time: 0.0192
INFO - 2023-10-14 06:19:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-10-14 06:19:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:48 --> URI Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:48 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:48 --> Parser Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:48 --> Router Class Initialized
INFO - 2023-10-14 06:19:48 --> URI Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:48 --> Router Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:48 --> Output Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:48 --> Output Class Initialized
INFO - 2023-10-14 06:19:48 --> Security Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:48 --> Controller Class Initialized
INFO - 2023-10-14 06:19:48 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:48 --> Input Class Initialized
INFO - 2023-10-14 06:19:48 --> Language Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:48 --> Input Class Initialized
INFO - 2023-10-14 06:19:48 --> Language Class Initialized
INFO - 2023-10-14 06:19:48 --> Loader Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Database Driver Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:48 --> Loader Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: file_helper
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: text_helper
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:48 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:48 --> Total execution time: 0.0251
INFO - 2023-10-14 06:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:48 --> Parser Class Initialized
INFO - 2023-10-14 06:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:48 --> Controller Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:48 --> Total execution time: 0.0329
INFO - 2023-10-14 06:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:48 --> Parser Class Initialized
INFO - 2023-10-14 06:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:48 --> Controller Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:48 --> Total execution time: 0.0357
INFO - 2023-10-14 06:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:48 --> Parser Class Initialized
INFO - 2023-10-14 06:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:48 --> Controller Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:48 --> Total execution time: 0.0415
INFO - 2023-10-14 06:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:48 --> Parser Class Initialized
INFO - 2023-10-14 06:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:48 --> Controller Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
INFO - 2023-10-14 06:19:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:48 --> Total execution time: 0.0516
ERROR - 2023-10-14 06:19:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:55 --> Config Class Initialized
INFO - 2023-10-14 06:19:55 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:55 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:55 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:55 --> URI Class Initialized
INFO - 2023-10-14 06:19:55 --> Router Class Initialized
INFO - 2023-10-14 06:19:55 --> Output Class Initialized
INFO - 2023-10-14 06:19:55 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:55 --> Input Class Initialized
INFO - 2023-10-14 06:19:55 --> Language Class Initialized
INFO - 2023-10-14 06:19:55 --> Loader Class Initialized
INFO - 2023-10-14 06:19:55 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:55 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:55 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:55 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:55 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:55 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:55 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:55 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:55 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:55 --> Parser Class Initialized
INFO - 2023-10-14 06:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:55 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:55 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:55 --> Controller Class Initialized
INFO - 2023-10-14 06:19:55 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:55 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:55 --> Model Class Initialized
INFO - 2023-10-14 06:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 06:19:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:19:55 --> Model Class Initialized
INFO - 2023-10-14 06:19:55 --> Model Class Initialized
INFO - 2023-10-14 06:19:55 --> Model Class Initialized
INFO - 2023-10-14 06:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:19:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:19:55 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:55 --> Total execution time: 0.1976
ERROR - 2023-10-14 06:19:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:19:56 --> Config Class Initialized
INFO - 2023-10-14 06:19:56 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:19:56 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:19:56 --> Utf8 Class Initialized
INFO - 2023-10-14 06:19:56 --> URI Class Initialized
INFO - 2023-10-14 06:19:56 --> Router Class Initialized
INFO - 2023-10-14 06:19:56 --> Output Class Initialized
INFO - 2023-10-14 06:19:56 --> Security Class Initialized
DEBUG - 2023-10-14 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:19:56 --> Input Class Initialized
INFO - 2023-10-14 06:19:56 --> Language Class Initialized
INFO - 2023-10-14 06:19:56 --> Loader Class Initialized
INFO - 2023-10-14 06:19:56 --> Helper loaded: url_helper
INFO - 2023-10-14 06:19:56 --> Helper loaded: file_helper
INFO - 2023-10-14 06:19:56 --> Helper loaded: html_helper
INFO - 2023-10-14 06:19:56 --> Helper loaded: text_helper
INFO - 2023-10-14 06:19:56 --> Helper loaded: form_helper
INFO - 2023-10-14 06:19:56 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:19:56 --> Helper loaded: security_helper
INFO - 2023-10-14 06:19:56 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:19:56 --> Database Driver Class Initialized
INFO - 2023-10-14 06:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:19:56 --> Parser Class Initialized
INFO - 2023-10-14 06:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:19:56 --> Pagination Class Initialized
INFO - 2023-10-14 06:19:56 --> Form Validation Class Initialized
INFO - 2023-10-14 06:19:56 --> Controller Class Initialized
INFO - 2023-10-14 06:19:56 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:56 --> Model Class Initialized
DEBUG - 2023-10-14 06:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:19:56 --> Model Class Initialized
INFO - 2023-10-14 06:19:56 --> Final output sent to browser
DEBUG - 2023-10-14 06:19:56 --> Total execution time: 0.0532
ERROR - 2023-10-14 06:20:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:00 --> Config Class Initialized
INFO - 2023-10-14 06:20:00 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:00 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:00 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:00 --> URI Class Initialized
INFO - 2023-10-14 06:20:00 --> Router Class Initialized
INFO - 2023-10-14 06:20:00 --> Output Class Initialized
INFO - 2023-10-14 06:20:00 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:00 --> Input Class Initialized
INFO - 2023-10-14 06:20:00 --> Language Class Initialized
INFO - 2023-10-14 06:20:00 --> Loader Class Initialized
INFO - 2023-10-14 06:20:00 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:00 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:00 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:00 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:00 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:00 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:00 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:00 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:00 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:00 --> Parser Class Initialized
INFO - 2023-10-14 06:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:00 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:00 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:00 --> Controller Class Initialized
INFO - 2023-10-14 06:20:00 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:00 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:00 --> Model Class Initialized
INFO - 2023-10-14 06:20:00 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:00 --> Total execution time: 0.0542
ERROR - 2023-10-14 06:20:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:01 --> Config Class Initialized
INFO - 2023-10-14 06:20:01 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:01 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:01 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:01 --> URI Class Initialized
INFO - 2023-10-14 06:20:01 --> Router Class Initialized
INFO - 2023-10-14 06:20:01 --> Output Class Initialized
INFO - 2023-10-14 06:20:01 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:01 --> Input Class Initialized
INFO - 2023-10-14 06:20:01 --> Language Class Initialized
INFO - 2023-10-14 06:20:01 --> Loader Class Initialized
INFO - 2023-10-14 06:20:01 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:01 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:01 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:01 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:01 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:01 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:01 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:01 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:01 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:01 --> Parser Class Initialized
INFO - 2023-10-14 06:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:01 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:01 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:01 --> Controller Class Initialized
INFO - 2023-10-14 06:20:01 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:01 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:01 --> Model Class Initialized
INFO - 2023-10-14 06:20:01 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:01 --> Total execution time: 0.0262
ERROR - 2023-10-14 06:20:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:04 --> Config Class Initialized
INFO - 2023-10-14 06:20:04 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:04 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:04 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:04 --> URI Class Initialized
INFO - 2023-10-14 06:20:04 --> Router Class Initialized
INFO - 2023-10-14 06:20:04 --> Output Class Initialized
INFO - 2023-10-14 06:20:04 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:04 --> Input Class Initialized
INFO - 2023-10-14 06:20:04 --> Language Class Initialized
INFO - 2023-10-14 06:20:04 --> Loader Class Initialized
INFO - 2023-10-14 06:20:04 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:04 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:04 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:04 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:04 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:04 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:04 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:04 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:04 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:04 --> Parser Class Initialized
INFO - 2023-10-14 06:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:04 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:04 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:04 --> Controller Class Initialized
INFO - 2023-10-14 06:20:04 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:04 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:04 --> Model Class Initialized
INFO - 2023-10-14 06:20:04 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:04 --> Total execution time: 0.0434
ERROR - 2023-10-14 06:20:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:05 --> Config Class Initialized
INFO - 2023-10-14 06:20:05 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:05 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:05 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:05 --> URI Class Initialized
INFO - 2023-10-14 06:20:05 --> Router Class Initialized
INFO - 2023-10-14 06:20:05 --> Output Class Initialized
INFO - 2023-10-14 06:20:05 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:05 --> Input Class Initialized
INFO - 2023-10-14 06:20:05 --> Language Class Initialized
INFO - 2023-10-14 06:20:05 --> Loader Class Initialized
INFO - 2023-10-14 06:20:05 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:05 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:05 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:05 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:05 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:05 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:05 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:05 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:05 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:05 --> Parser Class Initialized
INFO - 2023-10-14 06:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:05 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:05 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:05 --> Controller Class Initialized
INFO - 2023-10-14 06:20:05 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:05 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:05 --> Model Class Initialized
INFO - 2023-10-14 06:20:05 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:05 --> Total execution time: 0.1432
ERROR - 2023-10-14 06:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:06 --> Config Class Initialized
INFO - 2023-10-14 06:20:06 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:06 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:06 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:06 --> URI Class Initialized
INFO - 2023-10-14 06:20:06 --> Router Class Initialized
INFO - 2023-10-14 06:20:06 --> Output Class Initialized
INFO - 2023-10-14 06:20:06 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:06 --> Input Class Initialized
INFO - 2023-10-14 06:20:06 --> Language Class Initialized
INFO - 2023-10-14 06:20:06 --> Loader Class Initialized
INFO - 2023-10-14 06:20:06 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:06 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:06 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:06 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:06 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:06 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:06 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:06 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:06 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:06 --> Parser Class Initialized
INFO - 2023-10-14 06:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:06 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:06 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:06 --> Controller Class Initialized
INFO - 2023-10-14 06:20:06 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:06 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:06 --> Model Class Initialized
INFO - 2023-10-14 06:20:06 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:06 --> Total execution time: 0.0674
ERROR - 2023-10-14 06:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:07 --> Config Class Initialized
INFO - 2023-10-14 06:20:07 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:07 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:07 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:07 --> URI Class Initialized
INFO - 2023-10-14 06:20:07 --> Router Class Initialized
INFO - 2023-10-14 06:20:07 --> Output Class Initialized
INFO - 2023-10-14 06:20:07 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:07 --> Input Class Initialized
INFO - 2023-10-14 06:20:07 --> Language Class Initialized
INFO - 2023-10-14 06:20:07 --> Loader Class Initialized
INFO - 2023-10-14 06:20:07 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:07 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:07 --> Parser Class Initialized
INFO - 2023-10-14 06:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:07 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:07 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:07 --> Controller Class Initialized
INFO - 2023-10-14 06:20:07 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:07 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:07 --> Model Class Initialized
INFO - 2023-10-14 06:20:07 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:07 --> Total execution time: 0.0461
ERROR - 2023-10-14 06:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:07 --> Config Class Initialized
INFO - 2023-10-14 06:20:07 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:07 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:07 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:07 --> URI Class Initialized
INFO - 2023-10-14 06:20:07 --> Router Class Initialized
INFO - 2023-10-14 06:20:07 --> Output Class Initialized
INFO - 2023-10-14 06:20:07 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:07 --> Input Class Initialized
INFO - 2023-10-14 06:20:07 --> Language Class Initialized
INFO - 2023-10-14 06:20:07 --> Loader Class Initialized
INFO - 2023-10-14 06:20:07 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:07 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:07 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:07 --> Parser Class Initialized
INFO - 2023-10-14 06:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:07 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:07 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:07 --> Controller Class Initialized
INFO - 2023-10-14 06:20:07 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:07 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:07 --> Model Class Initialized
INFO - 2023-10-14 06:20:07 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:07 --> Total execution time: 0.0259
ERROR - 2023-10-14 06:20:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:10 --> Config Class Initialized
INFO - 2023-10-14 06:20:10 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:10 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:10 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:10 --> URI Class Initialized
INFO - 2023-10-14 06:20:10 --> Router Class Initialized
INFO - 2023-10-14 06:20:10 --> Output Class Initialized
INFO - 2023-10-14 06:20:10 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:10 --> Input Class Initialized
INFO - 2023-10-14 06:20:10 --> Language Class Initialized
INFO - 2023-10-14 06:20:10 --> Loader Class Initialized
INFO - 2023-10-14 06:20:10 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:10 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:10 --> Parser Class Initialized
INFO - 2023-10-14 06:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:10 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:10 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:10 --> Controller Class Initialized
INFO - 2023-10-14 06:20:10 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:10 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:10 --> Model Class Initialized
INFO - 2023-10-14 06:20:10 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:10 --> Total execution time: 0.0416
ERROR - 2023-10-14 06:20:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:10 --> Config Class Initialized
INFO - 2023-10-14 06:20:10 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:10 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:10 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:10 --> URI Class Initialized
INFO - 2023-10-14 06:20:10 --> Router Class Initialized
INFO - 2023-10-14 06:20:10 --> Output Class Initialized
INFO - 2023-10-14 06:20:10 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:10 --> Input Class Initialized
INFO - 2023-10-14 06:20:10 --> Language Class Initialized
INFO - 2023-10-14 06:20:10 --> Loader Class Initialized
INFO - 2023-10-14 06:20:10 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:10 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:10 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:10 --> Parser Class Initialized
INFO - 2023-10-14 06:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:10 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:10 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:10 --> Controller Class Initialized
INFO - 2023-10-14 06:20:10 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:10 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:10 --> Model Class Initialized
INFO - 2023-10-14 06:20:11 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:11 --> Total execution time: 0.0545
ERROR - 2023-10-14 06:20:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:12 --> Config Class Initialized
INFO - 2023-10-14 06:20:12 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:12 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:12 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:12 --> URI Class Initialized
INFO - 2023-10-14 06:20:12 --> Router Class Initialized
INFO - 2023-10-14 06:20:12 --> Output Class Initialized
INFO - 2023-10-14 06:20:12 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:12 --> Input Class Initialized
INFO - 2023-10-14 06:20:12 --> Language Class Initialized
INFO - 2023-10-14 06:20:12 --> Loader Class Initialized
INFO - 2023-10-14 06:20:12 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:12 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:12 --> Parser Class Initialized
INFO - 2023-10-14 06:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:12 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:12 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:12 --> Controller Class Initialized
INFO - 2023-10-14 06:20:12 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:12 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:12 --> Model Class Initialized
INFO - 2023-10-14 06:20:12 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:12 --> Total execution time: 0.0542
ERROR - 2023-10-14 06:20:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:12 --> Config Class Initialized
INFO - 2023-10-14 06:20:12 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:12 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:12 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:12 --> URI Class Initialized
INFO - 2023-10-14 06:20:12 --> Router Class Initialized
INFO - 2023-10-14 06:20:12 --> Output Class Initialized
INFO - 2023-10-14 06:20:12 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:12 --> Input Class Initialized
INFO - 2023-10-14 06:20:12 --> Language Class Initialized
INFO - 2023-10-14 06:20:12 --> Loader Class Initialized
INFO - 2023-10-14 06:20:12 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:12 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:12 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:12 --> Parser Class Initialized
INFO - 2023-10-14 06:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:12 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:12 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:12 --> Controller Class Initialized
INFO - 2023-10-14 06:20:12 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:12 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:12 --> Model Class Initialized
INFO - 2023-10-14 06:20:12 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:12 --> Total execution time: 0.0517
ERROR - 2023-10-14 06:20:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:13 --> Config Class Initialized
INFO - 2023-10-14 06:20:13 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:13 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:13 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:13 --> URI Class Initialized
INFO - 2023-10-14 06:20:13 --> Router Class Initialized
INFO - 2023-10-14 06:20:13 --> Output Class Initialized
INFO - 2023-10-14 06:20:13 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:13 --> Input Class Initialized
INFO - 2023-10-14 06:20:13 --> Language Class Initialized
INFO - 2023-10-14 06:20:13 --> Loader Class Initialized
INFO - 2023-10-14 06:20:13 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:13 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:13 --> Parser Class Initialized
INFO - 2023-10-14 06:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:13 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:13 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:13 --> Controller Class Initialized
INFO - 2023-10-14 06:20:13 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:13 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:13 --> Model Class Initialized
INFO - 2023-10-14 06:20:13 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:13 --> Total execution time: 0.0527
ERROR - 2023-10-14 06:20:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:13 --> Config Class Initialized
INFO - 2023-10-14 06:20:13 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:13 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:13 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:13 --> URI Class Initialized
INFO - 2023-10-14 06:20:13 --> Router Class Initialized
INFO - 2023-10-14 06:20:13 --> Output Class Initialized
INFO - 2023-10-14 06:20:13 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:13 --> Input Class Initialized
INFO - 2023-10-14 06:20:13 --> Language Class Initialized
INFO - 2023-10-14 06:20:13 --> Loader Class Initialized
INFO - 2023-10-14 06:20:13 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:13 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:13 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:13 --> Parser Class Initialized
INFO - 2023-10-14 06:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:13 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:13 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:13 --> Controller Class Initialized
INFO - 2023-10-14 06:20:13 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:13 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:13 --> Model Class Initialized
INFO - 2023-10-14 06:20:14 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:14 --> Total execution time: 0.0575
ERROR - 2023-10-14 06:20:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:15 --> Config Class Initialized
INFO - 2023-10-14 06:20:15 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:15 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:15 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:15 --> URI Class Initialized
INFO - 2023-10-14 06:20:15 --> Router Class Initialized
INFO - 2023-10-14 06:20:15 --> Output Class Initialized
INFO - 2023-10-14 06:20:15 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:15 --> Input Class Initialized
INFO - 2023-10-14 06:20:15 --> Language Class Initialized
INFO - 2023-10-14 06:20:15 --> Loader Class Initialized
INFO - 2023-10-14 06:20:15 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:15 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:15 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:15 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:15 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:15 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:15 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:15 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:15 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:15 --> Parser Class Initialized
INFO - 2023-10-14 06:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:15 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:15 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:15 --> Controller Class Initialized
INFO - 2023-10-14 06:20:15 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:15 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:15 --> Model Class Initialized
INFO - 2023-10-14 06:20:15 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:15 --> Total execution time: 0.0591
ERROR - 2023-10-14 06:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:16 --> Config Class Initialized
INFO - 2023-10-14 06:20:16 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:16 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:16 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:16 --> URI Class Initialized
INFO - 2023-10-14 06:20:16 --> Router Class Initialized
INFO - 2023-10-14 06:20:16 --> Output Class Initialized
INFO - 2023-10-14 06:20:16 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:16 --> Input Class Initialized
INFO - 2023-10-14 06:20:16 --> Language Class Initialized
INFO - 2023-10-14 06:20:16 --> Loader Class Initialized
INFO - 2023-10-14 06:20:16 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:16 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:16 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:16 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:16 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:16 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:16 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:16 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:16 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:16 --> Parser Class Initialized
INFO - 2023-10-14 06:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:16 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:16 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:16 --> Controller Class Initialized
INFO - 2023-10-14 06:20:16 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:16 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:16 --> Model Class Initialized
INFO - 2023-10-14 06:20:16 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:16 --> Total execution time: 0.0550
ERROR - 2023-10-14 06:20:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:21 --> Config Class Initialized
INFO - 2023-10-14 06:20:21 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:21 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:21 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:21 --> URI Class Initialized
INFO - 2023-10-14 06:20:21 --> Router Class Initialized
INFO - 2023-10-14 06:20:21 --> Output Class Initialized
INFO - 2023-10-14 06:20:21 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:21 --> Input Class Initialized
INFO - 2023-10-14 06:20:21 --> Language Class Initialized
INFO - 2023-10-14 06:20:21 --> Loader Class Initialized
INFO - 2023-10-14 06:20:21 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:21 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:21 --> Parser Class Initialized
INFO - 2023-10-14 06:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:21 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:21 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:21 --> Controller Class Initialized
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
ERROR - 2023-10-14 06:20:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-10-14 06:20:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-10-14 06:20:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:20:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
INFO - 2023-10-14 06:20:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:20:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:20:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:20:21 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:21 --> Total execution time: 0.2050
ERROR - 2023-10-14 06:20:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:21 --> Config Class Initialized
INFO - 2023-10-14 06:20:21 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:21 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:21 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:21 --> URI Class Initialized
INFO - 2023-10-14 06:20:21 --> Router Class Initialized
INFO - 2023-10-14 06:20:21 --> Output Class Initialized
INFO - 2023-10-14 06:20:21 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:21 --> Input Class Initialized
INFO - 2023-10-14 06:20:21 --> Language Class Initialized
INFO - 2023-10-14 06:20:21 --> Loader Class Initialized
INFO - 2023-10-14 06:20:21 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:21 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:21 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:21 --> Parser Class Initialized
INFO - 2023-10-14 06:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:21 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:21 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:21 --> Controller Class Initialized
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
INFO - 2023-10-14 06:20:21 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:21 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:21 --> Total execution time: 0.0184
ERROR - 2023-10-14 06:20:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:39 --> Config Class Initialized
INFO - 2023-10-14 06:20:39 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:39 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:39 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:39 --> URI Class Initialized
INFO - 2023-10-14 06:20:39 --> Router Class Initialized
INFO - 2023-10-14 06:20:39 --> Output Class Initialized
INFO - 2023-10-14 06:20:39 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:39 --> Input Class Initialized
INFO - 2023-10-14 06:20:39 --> Language Class Initialized
INFO - 2023-10-14 06:20:39 --> Loader Class Initialized
INFO - 2023-10-14 06:20:39 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:39 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:39 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:39 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:39 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:39 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:39 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:39 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:39 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:39 --> Parser Class Initialized
INFO - 2023-10-14 06:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:39 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:39 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:39 --> Controller Class Initialized
INFO - 2023-10-14 06:20:39 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:39 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:39 --> Model Class Initialized
ERROR - 2023-10-14 06:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:20:40 --> Config Class Initialized
INFO - 2023-10-14 06:20:40 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:20:40 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:20:40 --> Utf8 Class Initialized
INFO - 2023-10-14 06:20:40 --> URI Class Initialized
INFO - 2023-10-14 06:20:40 --> Router Class Initialized
INFO - 2023-10-14 06:20:40 --> Output Class Initialized
INFO - 2023-10-14 06:20:40 --> Security Class Initialized
DEBUG - 2023-10-14 06:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:20:40 --> Input Class Initialized
INFO - 2023-10-14 06:20:40 --> Language Class Initialized
INFO - 2023-10-14 06:20:40 --> Loader Class Initialized
INFO - 2023-10-14 06:20:40 --> Helper loaded: url_helper
INFO - 2023-10-14 06:20:40 --> Helper loaded: file_helper
INFO - 2023-10-14 06:20:40 --> Helper loaded: html_helper
INFO - 2023-10-14 06:20:40 --> Helper loaded: text_helper
INFO - 2023-10-14 06:20:40 --> Helper loaded: form_helper
INFO - 2023-10-14 06:20:40 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:20:40 --> Helper loaded: security_helper
INFO - 2023-10-14 06:20:40 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:20:40 --> Database Driver Class Initialized
INFO - 2023-10-14 06:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:20:40 --> Parser Class Initialized
INFO - 2023-10-14 06:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:20:40 --> Pagination Class Initialized
INFO - 2023-10-14 06:20:40 --> Form Validation Class Initialized
INFO - 2023-10-14 06:20:40 --> Controller Class Initialized
INFO - 2023-10-14 06:20:40 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:40 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:40 --> Model Class Initialized
DEBUG - 2023-10-14 06:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 06:20:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:20:40 --> Model Class Initialized
INFO - 2023-10-14 06:20:40 --> Model Class Initialized
INFO - 2023-10-14 06:20:40 --> Model Class Initialized
INFO - 2023-10-14 06:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:20:40 --> Final output sent to browser
DEBUG - 2023-10-14 06:20:40 --> Total execution time: 0.1990
ERROR - 2023-10-14 06:22:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:41 --> Config Class Initialized
INFO - 2023-10-14 06:22:41 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:41 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:41 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:41 --> URI Class Initialized
INFO - 2023-10-14 06:22:41 --> Router Class Initialized
INFO - 2023-10-14 06:22:41 --> Output Class Initialized
INFO - 2023-10-14 06:22:41 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:41 --> Input Class Initialized
INFO - 2023-10-14 06:22:41 --> Language Class Initialized
INFO - 2023-10-14 06:22:41 --> Loader Class Initialized
INFO - 2023-10-14 06:22:41 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:41 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:41 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:41 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:41 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:41 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:41 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:41 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:41 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:41 --> Parser Class Initialized
INFO - 2023-10-14 06:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:41 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:41 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:41 --> Controller Class Initialized
INFO - 2023-10-14 06:22:41 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:41 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:41 --> Model Class Initialized
INFO - 2023-10-14 06:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 06:22:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:22:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:22:41 --> Model Class Initialized
INFO - 2023-10-14 06:22:41 --> Model Class Initialized
INFO - 2023-10-14 06:22:41 --> Model Class Initialized
INFO - 2023-10-14 06:22:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:22:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:22:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:22:42 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:42 --> Total execution time: 0.1969
ERROR - 2023-10-14 06:22:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:42 --> Config Class Initialized
INFO - 2023-10-14 06:22:42 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:42 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:42 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:42 --> URI Class Initialized
INFO - 2023-10-14 06:22:42 --> Router Class Initialized
INFO - 2023-10-14 06:22:42 --> Output Class Initialized
INFO - 2023-10-14 06:22:42 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:42 --> Input Class Initialized
INFO - 2023-10-14 06:22:42 --> Language Class Initialized
INFO - 2023-10-14 06:22:42 --> Loader Class Initialized
INFO - 2023-10-14 06:22:42 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:42 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:42 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:42 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:42 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:42 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:42 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:42 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:42 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:42 --> Parser Class Initialized
INFO - 2023-10-14 06:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:42 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:42 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:42 --> Controller Class Initialized
INFO - 2023-10-14 06:22:42 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:42 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:42 --> Model Class Initialized
INFO - 2023-10-14 06:22:42 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:42 --> Total execution time: 0.0570
ERROR - 2023-10-14 06:22:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:48 --> Config Class Initialized
INFO - 2023-10-14 06:22:48 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:48 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:48 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:48 --> URI Class Initialized
INFO - 2023-10-14 06:22:48 --> Router Class Initialized
INFO - 2023-10-14 06:22:48 --> Output Class Initialized
INFO - 2023-10-14 06:22:48 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:48 --> Input Class Initialized
INFO - 2023-10-14 06:22:48 --> Language Class Initialized
INFO - 2023-10-14 06:22:48 --> Loader Class Initialized
INFO - 2023-10-14 06:22:48 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:48 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:48 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:48 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:48 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:48 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:48 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:48 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:48 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:48 --> Parser Class Initialized
INFO - 2023-10-14 06:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:48 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:48 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:48 --> Controller Class Initialized
INFO - 2023-10-14 06:22:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:48 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:48 --> Model Class Initialized
INFO - 2023-10-14 06:22:48 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:48 --> Total execution time: 0.0592
ERROR - 2023-10-14 06:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:49 --> Config Class Initialized
INFO - 2023-10-14 06:22:49 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:49 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:49 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:49 --> URI Class Initialized
INFO - 2023-10-14 06:22:49 --> Router Class Initialized
INFO - 2023-10-14 06:22:49 --> Output Class Initialized
INFO - 2023-10-14 06:22:49 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:49 --> Input Class Initialized
INFO - 2023-10-14 06:22:49 --> Language Class Initialized
INFO - 2023-10-14 06:22:49 --> Loader Class Initialized
INFO - 2023-10-14 06:22:49 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:49 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:49 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:49 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:49 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:49 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:49 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:49 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:49 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:49 --> Parser Class Initialized
INFO - 2023-10-14 06:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:49 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:49 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:49 --> Controller Class Initialized
INFO - 2023-10-14 06:22:49 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:49 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:49 --> Model Class Initialized
INFO - 2023-10-14 06:22:49 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:49 --> Total execution time: 0.0588
ERROR - 2023-10-14 06:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:50 --> Config Class Initialized
INFO - 2023-10-14 06:22:50 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:50 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:50 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:50 --> URI Class Initialized
INFO - 2023-10-14 06:22:50 --> Router Class Initialized
INFO - 2023-10-14 06:22:50 --> Output Class Initialized
INFO - 2023-10-14 06:22:50 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:50 --> Input Class Initialized
INFO - 2023-10-14 06:22:50 --> Language Class Initialized
INFO - 2023-10-14 06:22:50 --> Loader Class Initialized
INFO - 2023-10-14 06:22:50 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:50 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:50 --> Parser Class Initialized
INFO - 2023-10-14 06:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:50 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:50 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:50 --> Controller Class Initialized
INFO - 2023-10-14 06:22:50 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:50 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:50 --> Model Class Initialized
INFO - 2023-10-14 06:22:50 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:50 --> Total execution time: 0.0512
ERROR - 2023-10-14 06:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:50 --> Config Class Initialized
INFO - 2023-10-14 06:22:50 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:50 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:50 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:50 --> URI Class Initialized
INFO - 2023-10-14 06:22:50 --> Router Class Initialized
INFO - 2023-10-14 06:22:50 --> Output Class Initialized
INFO - 2023-10-14 06:22:50 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:50 --> Input Class Initialized
INFO - 2023-10-14 06:22:50 --> Language Class Initialized
INFO - 2023-10-14 06:22:50 --> Loader Class Initialized
INFO - 2023-10-14 06:22:50 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:50 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:50 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:50 --> Parser Class Initialized
INFO - 2023-10-14 06:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:50 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:50 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:50 --> Controller Class Initialized
INFO - 2023-10-14 06:22:50 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:50 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:50 --> Model Class Initialized
INFO - 2023-10-14 06:22:51 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:51 --> Total execution time: 0.0407
ERROR - 2023-10-14 06:22:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:53 --> Config Class Initialized
INFO - 2023-10-14 06:22:53 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:53 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:53 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:53 --> URI Class Initialized
INFO - 2023-10-14 06:22:53 --> Router Class Initialized
INFO - 2023-10-14 06:22:53 --> Output Class Initialized
INFO - 2023-10-14 06:22:53 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:53 --> Input Class Initialized
INFO - 2023-10-14 06:22:53 --> Language Class Initialized
INFO - 2023-10-14 06:22:53 --> Loader Class Initialized
INFO - 2023-10-14 06:22:53 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:53 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:53 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:53 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:53 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:53 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:53 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:53 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:53 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:53 --> Parser Class Initialized
INFO - 2023-10-14 06:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:53 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:53 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:53 --> Controller Class Initialized
INFO - 2023-10-14 06:22:53 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:53 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:53 --> Model Class Initialized
ERROR - 2023-10-14 06:22:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-10-14 06:22:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-10-14 06:22:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:22:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:22:53 --> Model Class Initialized
INFO - 2023-10-14 06:22:53 --> Model Class Initialized
INFO - 2023-10-14 06:22:53 --> Model Class Initialized
INFO - 2023-10-14 06:22:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:22:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:22:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:22:53 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:53 --> Total execution time: 0.2125
ERROR - 2023-10-14 06:22:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:22:54 --> Config Class Initialized
INFO - 2023-10-14 06:22:54 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:22:54 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:22:54 --> Utf8 Class Initialized
INFO - 2023-10-14 06:22:54 --> URI Class Initialized
INFO - 2023-10-14 06:22:54 --> Router Class Initialized
INFO - 2023-10-14 06:22:54 --> Output Class Initialized
INFO - 2023-10-14 06:22:54 --> Security Class Initialized
DEBUG - 2023-10-14 06:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:22:54 --> Input Class Initialized
INFO - 2023-10-14 06:22:54 --> Language Class Initialized
INFO - 2023-10-14 06:22:54 --> Loader Class Initialized
INFO - 2023-10-14 06:22:54 --> Helper loaded: url_helper
INFO - 2023-10-14 06:22:54 --> Helper loaded: file_helper
INFO - 2023-10-14 06:22:54 --> Helper loaded: html_helper
INFO - 2023-10-14 06:22:54 --> Helper loaded: text_helper
INFO - 2023-10-14 06:22:54 --> Helper loaded: form_helper
INFO - 2023-10-14 06:22:54 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:22:54 --> Helper loaded: security_helper
INFO - 2023-10-14 06:22:54 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:22:54 --> Database Driver Class Initialized
INFO - 2023-10-14 06:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:22:54 --> Parser Class Initialized
INFO - 2023-10-14 06:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:22:54 --> Pagination Class Initialized
INFO - 2023-10-14 06:22:54 --> Form Validation Class Initialized
INFO - 2023-10-14 06:22:54 --> Controller Class Initialized
INFO - 2023-10-14 06:22:54 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:54 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:54 --> Model Class Initialized
INFO - 2023-10-14 06:22:54 --> Model Class Initialized
DEBUG - 2023-10-14 06:22:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:22:54 --> Final output sent to browser
DEBUG - 2023-10-14 06:22:54 --> Total execution time: 0.0199
ERROR - 2023-10-14 06:23:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:23:14 --> Config Class Initialized
INFO - 2023-10-14 06:23:14 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:23:14 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:23:14 --> Utf8 Class Initialized
INFO - 2023-10-14 06:23:14 --> URI Class Initialized
INFO - 2023-10-14 06:23:14 --> Router Class Initialized
INFO - 2023-10-14 06:23:14 --> Output Class Initialized
INFO - 2023-10-14 06:23:14 --> Security Class Initialized
DEBUG - 2023-10-14 06:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:23:14 --> Input Class Initialized
INFO - 2023-10-14 06:23:14 --> Language Class Initialized
INFO - 2023-10-14 06:23:14 --> Loader Class Initialized
INFO - 2023-10-14 06:23:14 --> Helper loaded: url_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: file_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: html_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: text_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: form_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: security_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:23:14 --> Database Driver Class Initialized
INFO - 2023-10-14 06:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:23:14 --> Parser Class Initialized
INFO - 2023-10-14 06:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:23:14 --> Pagination Class Initialized
INFO - 2023-10-14 06:23:14 --> Form Validation Class Initialized
INFO - 2023-10-14 06:23:14 --> Controller Class Initialized
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
DEBUG - 2023-10-14 06:23:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
DEBUG - 2023-10-14 06:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
ERROR - 2023-10-14 06:23:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:23:14 --> Config Class Initialized
INFO - 2023-10-14 06:23:14 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:23:14 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:23:14 --> Utf8 Class Initialized
INFO - 2023-10-14 06:23:14 --> URI Class Initialized
INFO - 2023-10-14 06:23:14 --> Router Class Initialized
INFO - 2023-10-14 06:23:14 --> Output Class Initialized
INFO - 2023-10-14 06:23:14 --> Security Class Initialized
DEBUG - 2023-10-14 06:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:23:14 --> Input Class Initialized
INFO - 2023-10-14 06:23:14 --> Language Class Initialized
INFO - 2023-10-14 06:23:14 --> Loader Class Initialized
INFO - 2023-10-14 06:23:14 --> Helper loaded: url_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: file_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: html_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: text_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: form_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: security_helper
INFO - 2023-10-14 06:23:14 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:23:14 --> Database Driver Class Initialized
INFO - 2023-10-14 06:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:23:14 --> Parser Class Initialized
INFO - 2023-10-14 06:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:23:14 --> Pagination Class Initialized
INFO - 2023-10-14 06:23:14 --> Form Validation Class Initialized
INFO - 2023-10-14 06:23:14 --> Controller Class Initialized
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
DEBUG - 2023-10-14 06:23:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 06:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
DEBUG - 2023-10-14 06:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
DEBUG - 2023-10-14 06:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 06:23:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 06:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 06:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
INFO - 2023-10-14 06:23:14 --> Model Class Initialized
INFO - 2023-10-14 06:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 06:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 06:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 06:23:14 --> Final output sent to browser
DEBUG - 2023-10-14 06:23:14 --> Total execution time: 0.1923
ERROR - 2023-10-14 06:51:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:51:31 --> Config Class Initialized
INFO - 2023-10-14 06:51:31 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:51:31 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:51:31 --> Utf8 Class Initialized
INFO - 2023-10-14 06:51:31 --> URI Class Initialized
DEBUG - 2023-10-14 06:51:31 --> No URI present. Default controller set.
INFO - 2023-10-14 06:51:31 --> Router Class Initialized
INFO - 2023-10-14 06:51:31 --> Output Class Initialized
INFO - 2023-10-14 06:51:31 --> Security Class Initialized
DEBUG - 2023-10-14 06:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:51:31 --> Input Class Initialized
INFO - 2023-10-14 06:51:31 --> Language Class Initialized
INFO - 2023-10-14 06:51:31 --> Loader Class Initialized
INFO - 2023-10-14 06:51:31 --> Helper loaded: url_helper
INFO - 2023-10-14 06:51:31 --> Helper loaded: file_helper
INFO - 2023-10-14 06:51:31 --> Helper loaded: html_helper
INFO - 2023-10-14 06:51:31 --> Helper loaded: text_helper
INFO - 2023-10-14 06:51:31 --> Helper loaded: form_helper
INFO - 2023-10-14 06:51:31 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:51:31 --> Helper loaded: security_helper
INFO - 2023-10-14 06:51:31 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:51:31 --> Database Driver Class Initialized
INFO - 2023-10-14 06:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:51:31 --> Parser Class Initialized
INFO - 2023-10-14 06:51:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:51:31 --> Pagination Class Initialized
INFO - 2023-10-14 06:51:31 --> Form Validation Class Initialized
INFO - 2023-10-14 06:51:31 --> Controller Class Initialized
INFO - 2023-10-14 06:51:31 --> Model Class Initialized
DEBUG - 2023-10-14 06:51:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 06:51:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:51:32 --> Config Class Initialized
INFO - 2023-10-14 06:51:32 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:51:32 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:51:32 --> Utf8 Class Initialized
INFO - 2023-10-14 06:51:32 --> URI Class Initialized
DEBUG - 2023-10-14 06:51:32 --> No URI present. Default controller set.
INFO - 2023-10-14 06:51:32 --> Router Class Initialized
INFO - 2023-10-14 06:51:32 --> Output Class Initialized
INFO - 2023-10-14 06:51:32 --> Security Class Initialized
DEBUG - 2023-10-14 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:51:32 --> Input Class Initialized
INFO - 2023-10-14 06:51:32 --> Language Class Initialized
INFO - 2023-10-14 06:51:32 --> Loader Class Initialized
INFO - 2023-10-14 06:51:32 --> Helper loaded: url_helper
INFO - 2023-10-14 06:51:32 --> Helper loaded: file_helper
INFO - 2023-10-14 06:51:32 --> Helper loaded: html_helper
INFO - 2023-10-14 06:51:32 --> Helper loaded: text_helper
INFO - 2023-10-14 06:51:32 --> Helper loaded: form_helper
INFO - 2023-10-14 06:51:32 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:51:32 --> Helper loaded: security_helper
INFO - 2023-10-14 06:51:32 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:51:32 --> Database Driver Class Initialized
INFO - 2023-10-14 06:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:51:32 --> Parser Class Initialized
INFO - 2023-10-14 06:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:51:32 --> Pagination Class Initialized
INFO - 2023-10-14 06:51:32 --> Form Validation Class Initialized
INFO - 2023-10-14 06:51:32 --> Controller Class Initialized
INFO - 2023-10-14 06:51:32 --> Model Class Initialized
DEBUG - 2023-10-14 06:51:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 06:51:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:51:33 --> Config Class Initialized
INFO - 2023-10-14 06:51:33 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:51:33 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:51:33 --> Utf8 Class Initialized
INFO - 2023-10-14 06:51:33 --> URI Class Initialized
DEBUG - 2023-10-14 06:51:33 --> No URI present. Default controller set.
INFO - 2023-10-14 06:51:33 --> Router Class Initialized
INFO - 2023-10-14 06:51:33 --> Output Class Initialized
INFO - 2023-10-14 06:51:33 --> Security Class Initialized
DEBUG - 2023-10-14 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:51:33 --> Input Class Initialized
INFO - 2023-10-14 06:51:33 --> Language Class Initialized
INFO - 2023-10-14 06:51:33 --> Loader Class Initialized
INFO - 2023-10-14 06:51:33 --> Helper loaded: url_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: file_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: html_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: text_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: form_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: security_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:51:33 --> Database Driver Class Initialized
INFO - 2023-10-14 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:51:33 --> Parser Class Initialized
INFO - 2023-10-14 06:51:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:51:33 --> Pagination Class Initialized
INFO - 2023-10-14 06:51:33 --> Form Validation Class Initialized
INFO - 2023-10-14 06:51:33 --> Controller Class Initialized
INFO - 2023-10-14 06:51:33 --> Model Class Initialized
DEBUG - 2023-10-14 06:51:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 06:51:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 06:51:33 --> Config Class Initialized
INFO - 2023-10-14 06:51:33 --> Hooks Class Initialized
DEBUG - 2023-10-14 06:51:33 --> UTF-8 Support Enabled
INFO - 2023-10-14 06:51:33 --> Utf8 Class Initialized
INFO - 2023-10-14 06:51:33 --> URI Class Initialized
DEBUG - 2023-10-14 06:51:33 --> No URI present. Default controller set.
INFO - 2023-10-14 06:51:33 --> Router Class Initialized
INFO - 2023-10-14 06:51:33 --> Output Class Initialized
INFO - 2023-10-14 06:51:33 --> Security Class Initialized
DEBUG - 2023-10-14 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 06:51:33 --> Input Class Initialized
INFO - 2023-10-14 06:51:33 --> Language Class Initialized
INFO - 2023-10-14 06:51:33 --> Loader Class Initialized
INFO - 2023-10-14 06:51:33 --> Helper loaded: url_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: file_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: html_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: text_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: form_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: lang_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: security_helper
INFO - 2023-10-14 06:51:33 --> Helper loaded: cookie_helper
INFO - 2023-10-14 06:51:33 --> Database Driver Class Initialized
INFO - 2023-10-14 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 06:51:33 --> Parser Class Initialized
INFO - 2023-10-14 06:51:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 06:51:33 --> Pagination Class Initialized
INFO - 2023-10-14 06:51:33 --> Form Validation Class Initialized
INFO - 2023-10-14 06:51:33 --> Controller Class Initialized
INFO - 2023-10-14 06:51:33 --> Model Class Initialized
DEBUG - 2023-10-14 06:51:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 07:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:01:01 --> Config Class Initialized
INFO - 2023-10-14 07:01:01 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:01:01 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:01:01 --> Utf8 Class Initialized
INFO - 2023-10-14 07:01:01 --> URI Class Initialized
DEBUG - 2023-10-14 07:01:01 --> No URI present. Default controller set.
INFO - 2023-10-14 07:01:01 --> Router Class Initialized
INFO - 2023-10-14 07:01:01 --> Output Class Initialized
INFO - 2023-10-14 07:01:01 --> Security Class Initialized
DEBUG - 2023-10-14 07:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:01:01 --> Input Class Initialized
INFO - 2023-10-14 07:01:01 --> Language Class Initialized
INFO - 2023-10-14 07:01:01 --> Loader Class Initialized
INFO - 2023-10-14 07:01:01 --> Helper loaded: url_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: file_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: html_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: text_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: form_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: security_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:01:01 --> Database Driver Class Initialized
INFO - 2023-10-14 07:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:01:01 --> Parser Class Initialized
INFO - 2023-10-14 07:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:01:01 --> Pagination Class Initialized
INFO - 2023-10-14 07:01:01 --> Form Validation Class Initialized
INFO - 2023-10-14 07:01:01 --> Controller Class Initialized
INFO - 2023-10-14 07:01:01 --> Model Class Initialized
DEBUG - 2023-10-14 07:01:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 07:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:01:01 --> Config Class Initialized
INFO - 2023-10-14 07:01:01 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:01:01 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:01:01 --> Utf8 Class Initialized
INFO - 2023-10-14 07:01:01 --> URI Class Initialized
INFO - 2023-10-14 07:01:01 --> Router Class Initialized
INFO - 2023-10-14 07:01:01 --> Output Class Initialized
INFO - 2023-10-14 07:01:01 --> Security Class Initialized
DEBUG - 2023-10-14 07:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:01:01 --> Input Class Initialized
INFO - 2023-10-14 07:01:01 --> Language Class Initialized
INFO - 2023-10-14 07:01:01 --> Loader Class Initialized
INFO - 2023-10-14 07:01:01 --> Helper loaded: url_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: file_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: html_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: text_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: form_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: security_helper
INFO - 2023-10-14 07:01:01 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:01:01 --> Database Driver Class Initialized
INFO - 2023-10-14 07:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:01:01 --> Parser Class Initialized
INFO - 2023-10-14 07:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:01:01 --> Pagination Class Initialized
INFO - 2023-10-14 07:01:01 --> Form Validation Class Initialized
INFO - 2023-10-14 07:01:01 --> Controller Class Initialized
INFO - 2023-10-14 07:01:01 --> Model Class Initialized
DEBUG - 2023-10-14 07:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 07:01:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:01:01 --> Model Class Initialized
INFO - 2023-10-14 07:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:01:01 --> Final output sent to browser
DEBUG - 2023-10-14 07:01:01 --> Total execution time: 0.0292
ERROR - 2023-10-14 07:01:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:01:19 --> Config Class Initialized
INFO - 2023-10-14 07:01:19 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:01:19 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:01:19 --> Utf8 Class Initialized
INFO - 2023-10-14 07:01:19 --> URI Class Initialized
INFO - 2023-10-14 07:01:19 --> Router Class Initialized
INFO - 2023-10-14 07:01:19 --> Output Class Initialized
INFO - 2023-10-14 07:01:19 --> Security Class Initialized
DEBUG - 2023-10-14 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:01:19 --> Input Class Initialized
INFO - 2023-10-14 07:01:19 --> Language Class Initialized
INFO - 2023-10-14 07:01:19 --> Loader Class Initialized
INFO - 2023-10-14 07:01:19 --> Helper loaded: url_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: file_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: html_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: text_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: form_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: security_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:01:19 --> Database Driver Class Initialized
INFO - 2023-10-14 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:01:19 --> Parser Class Initialized
INFO - 2023-10-14 07:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:01:19 --> Pagination Class Initialized
INFO - 2023-10-14 07:01:19 --> Form Validation Class Initialized
INFO - 2023-10-14 07:01:19 --> Controller Class Initialized
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
DEBUG - 2023-10-14 07:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
INFO - 2023-10-14 07:01:19 --> Final output sent to browser
DEBUG - 2023-10-14 07:01:19 --> Total execution time: 0.0197
ERROR - 2023-10-14 07:01:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:01:19 --> Config Class Initialized
INFO - 2023-10-14 07:01:19 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:01:19 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:01:19 --> Utf8 Class Initialized
INFO - 2023-10-14 07:01:19 --> URI Class Initialized
DEBUG - 2023-10-14 07:01:19 --> No URI present. Default controller set.
INFO - 2023-10-14 07:01:19 --> Router Class Initialized
INFO - 2023-10-14 07:01:19 --> Output Class Initialized
INFO - 2023-10-14 07:01:19 --> Security Class Initialized
DEBUG - 2023-10-14 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:01:19 --> Input Class Initialized
INFO - 2023-10-14 07:01:19 --> Language Class Initialized
INFO - 2023-10-14 07:01:19 --> Loader Class Initialized
INFO - 2023-10-14 07:01:19 --> Helper loaded: url_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: file_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: html_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: text_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: form_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: security_helper
INFO - 2023-10-14 07:01:19 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:01:19 --> Database Driver Class Initialized
INFO - 2023-10-14 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:01:19 --> Parser Class Initialized
INFO - 2023-10-14 07:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:01:19 --> Pagination Class Initialized
INFO - 2023-10-14 07:01:19 --> Form Validation Class Initialized
INFO - 2023-10-14 07:01:19 --> Controller Class Initialized
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
DEBUG - 2023-10-14 07:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
DEBUG - 2023-10-14 07:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
DEBUG - 2023-10-14 07:01:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
INFO - 2023-10-14 07:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 07:01:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:01:19 --> Model Class Initialized
INFO - 2023-10-14 07:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:01:19 --> Final output sent to browser
DEBUG - 2023-10-14 07:01:19 --> Total execution time: 0.3763
ERROR - 2023-10-14 07:01:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:01:20 --> Config Class Initialized
INFO - 2023-10-14 07:01:20 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:01:20 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:01:20 --> Utf8 Class Initialized
INFO - 2023-10-14 07:01:20 --> URI Class Initialized
INFO - 2023-10-14 07:01:20 --> Router Class Initialized
INFO - 2023-10-14 07:01:20 --> Output Class Initialized
INFO - 2023-10-14 07:01:20 --> Security Class Initialized
DEBUG - 2023-10-14 07:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:01:20 --> Input Class Initialized
INFO - 2023-10-14 07:01:20 --> Language Class Initialized
INFO - 2023-10-14 07:01:20 --> Loader Class Initialized
INFO - 2023-10-14 07:01:20 --> Helper loaded: url_helper
INFO - 2023-10-14 07:01:20 --> Helper loaded: file_helper
INFO - 2023-10-14 07:01:20 --> Helper loaded: html_helper
INFO - 2023-10-14 07:01:20 --> Helper loaded: text_helper
INFO - 2023-10-14 07:01:20 --> Helper loaded: form_helper
INFO - 2023-10-14 07:01:20 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:01:20 --> Helper loaded: security_helper
INFO - 2023-10-14 07:01:20 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:01:20 --> Database Driver Class Initialized
INFO - 2023-10-14 07:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:01:20 --> Parser Class Initialized
INFO - 2023-10-14 07:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:01:20 --> Pagination Class Initialized
INFO - 2023-10-14 07:01:20 --> Form Validation Class Initialized
INFO - 2023-10-14 07:01:20 --> Controller Class Initialized
DEBUG - 2023-10-14 07:01:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:01:20 --> Model Class Initialized
INFO - 2023-10-14 07:01:20 --> Final output sent to browser
DEBUG - 2023-10-14 07:01:20 --> Total execution time: 0.0134
ERROR - 2023-10-14 07:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:04:44 --> Config Class Initialized
INFO - 2023-10-14 07:04:44 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:04:44 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:04:44 --> Utf8 Class Initialized
INFO - 2023-10-14 07:04:44 --> URI Class Initialized
INFO - 2023-10-14 07:04:44 --> Router Class Initialized
INFO - 2023-10-14 07:04:44 --> Output Class Initialized
INFO - 2023-10-14 07:04:44 --> Security Class Initialized
DEBUG - 2023-10-14 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:04:44 --> Input Class Initialized
INFO - 2023-10-14 07:04:44 --> Language Class Initialized
INFO - 2023-10-14 07:04:44 --> Loader Class Initialized
INFO - 2023-10-14 07:04:44 --> Helper loaded: url_helper
INFO - 2023-10-14 07:04:44 --> Helper loaded: file_helper
INFO - 2023-10-14 07:04:44 --> Helper loaded: html_helper
INFO - 2023-10-14 07:04:44 --> Helper loaded: text_helper
INFO - 2023-10-14 07:04:44 --> Helper loaded: form_helper
INFO - 2023-10-14 07:04:44 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:04:44 --> Helper loaded: security_helper
INFO - 2023-10-14 07:04:44 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:04:44 --> Database Driver Class Initialized
INFO - 2023-10-14 07:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:04:44 --> Parser Class Initialized
INFO - 2023-10-14 07:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:04:44 --> Pagination Class Initialized
INFO - 2023-10-14 07:04:44 --> Form Validation Class Initialized
INFO - 2023-10-14 07:04:44 --> Controller Class Initialized
DEBUG - 2023-10-14 07:04:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:04:44 --> Model Class Initialized
DEBUG - 2023-10-14 07:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:04:44 --> Model Class Initialized
DEBUG - 2023-10-14 07:04:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:04:44 --> Model Class Initialized
INFO - 2023-10-14 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-14 07:04:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:04:44 --> Model Class Initialized
INFO - 2023-10-14 07:04:44 --> Model Class Initialized
INFO - 2023-10-14 07:04:44 --> Model Class Initialized
INFO - 2023-10-14 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:04:44 --> Final output sent to browser
DEBUG - 2023-10-14 07:04:44 --> Total execution time: 0.1936
ERROR - 2023-10-14 07:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:04:45 --> Config Class Initialized
INFO - 2023-10-14 07:04:45 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:04:45 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:04:45 --> Utf8 Class Initialized
INFO - 2023-10-14 07:04:45 --> URI Class Initialized
INFO - 2023-10-14 07:04:45 --> Router Class Initialized
INFO - 2023-10-14 07:04:45 --> Output Class Initialized
INFO - 2023-10-14 07:04:45 --> Security Class Initialized
DEBUG - 2023-10-14 07:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:04:45 --> Input Class Initialized
INFO - 2023-10-14 07:04:45 --> Language Class Initialized
INFO - 2023-10-14 07:04:45 --> Loader Class Initialized
INFO - 2023-10-14 07:04:45 --> Helper loaded: url_helper
INFO - 2023-10-14 07:04:45 --> Helper loaded: file_helper
INFO - 2023-10-14 07:04:45 --> Helper loaded: html_helper
INFO - 2023-10-14 07:04:45 --> Helper loaded: text_helper
INFO - 2023-10-14 07:04:45 --> Helper loaded: form_helper
INFO - 2023-10-14 07:04:45 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:04:45 --> Helper loaded: security_helper
INFO - 2023-10-14 07:04:45 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:04:45 --> Database Driver Class Initialized
INFO - 2023-10-14 07:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:04:45 --> Parser Class Initialized
INFO - 2023-10-14 07:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:04:45 --> Pagination Class Initialized
INFO - 2023-10-14 07:04:45 --> Form Validation Class Initialized
INFO - 2023-10-14 07:04:45 --> Controller Class Initialized
DEBUG - 2023-10-14 07:04:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:04:45 --> Model Class Initialized
DEBUG - 2023-10-14 07:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:04:45 --> Model Class Initialized
INFO - 2023-10-14 07:04:45 --> Final output sent to browser
DEBUG - 2023-10-14 07:04:45 --> Total execution time: 0.0308
ERROR - 2023-10-14 07:05:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:05:22 --> Config Class Initialized
INFO - 2023-10-14 07:05:22 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:05:22 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:05:22 --> Utf8 Class Initialized
INFO - 2023-10-14 07:05:22 --> URI Class Initialized
DEBUG - 2023-10-14 07:05:22 --> No URI present. Default controller set.
INFO - 2023-10-14 07:05:22 --> Router Class Initialized
INFO - 2023-10-14 07:05:22 --> Output Class Initialized
INFO - 2023-10-14 07:05:22 --> Security Class Initialized
DEBUG - 2023-10-14 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:05:22 --> Input Class Initialized
INFO - 2023-10-14 07:05:22 --> Language Class Initialized
INFO - 2023-10-14 07:05:22 --> Loader Class Initialized
INFO - 2023-10-14 07:05:22 --> Helper loaded: url_helper
INFO - 2023-10-14 07:05:22 --> Helper loaded: file_helper
INFO - 2023-10-14 07:05:22 --> Helper loaded: html_helper
INFO - 2023-10-14 07:05:22 --> Helper loaded: text_helper
INFO - 2023-10-14 07:05:22 --> Helper loaded: form_helper
INFO - 2023-10-14 07:05:22 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:05:22 --> Helper loaded: security_helper
INFO - 2023-10-14 07:05:22 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:05:22 --> Database Driver Class Initialized
INFO - 2023-10-14 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:05:22 --> Parser Class Initialized
INFO - 2023-10-14 07:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:05:22 --> Pagination Class Initialized
INFO - 2023-10-14 07:05:22 --> Form Validation Class Initialized
INFO - 2023-10-14 07:05:22 --> Controller Class Initialized
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
INFO - 2023-10-14 07:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 07:05:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:05:22 --> Model Class Initialized
INFO - 2023-10-14 07:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:05:22 --> Final output sent to browser
DEBUG - 2023-10-14 07:05:22 --> Total execution time: 0.3404
ERROR - 2023-10-14 07:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:05:44 --> Config Class Initialized
INFO - 2023-10-14 07:05:44 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:05:44 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:05:44 --> Utf8 Class Initialized
INFO - 2023-10-14 07:05:44 --> URI Class Initialized
INFO - 2023-10-14 07:05:44 --> Router Class Initialized
INFO - 2023-10-14 07:05:45 --> Output Class Initialized
INFO - 2023-10-14 07:05:45 --> Security Class Initialized
DEBUG - 2023-10-14 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:05:45 --> Input Class Initialized
INFO - 2023-10-14 07:05:45 --> Language Class Initialized
INFO - 2023-10-14 07:05:45 --> Loader Class Initialized
INFO - 2023-10-14 07:05:45 --> Helper loaded: url_helper
INFO - 2023-10-14 07:05:45 --> Helper loaded: file_helper
INFO - 2023-10-14 07:05:45 --> Helper loaded: html_helper
INFO - 2023-10-14 07:05:45 --> Helper loaded: text_helper
INFO - 2023-10-14 07:05:45 --> Helper loaded: form_helper
INFO - 2023-10-14 07:05:45 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:05:45 --> Helper loaded: security_helper
INFO - 2023-10-14 07:05:45 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:05:45 --> Database Driver Class Initialized
INFO - 2023-10-14 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:05:45 --> Parser Class Initialized
INFO - 2023-10-14 07:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:05:45 --> Pagination Class Initialized
INFO - 2023-10-14 07:05:45 --> Form Validation Class Initialized
INFO - 2023-10-14 07:05:45 --> Controller Class Initialized
DEBUG - 2023-10-14 07:05:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:45 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:45 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:45 --> Model Class Initialized
INFO - 2023-10-14 07:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-14 07:05:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:05:45 --> Model Class Initialized
INFO - 2023-10-14 07:05:45 --> Model Class Initialized
INFO - 2023-10-14 07:05:45 --> Model Class Initialized
INFO - 2023-10-14 07:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:05:45 --> Final output sent to browser
DEBUG - 2023-10-14 07:05:45 --> Total execution time: 0.2064
ERROR - 2023-10-14 07:05:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:05:46 --> Config Class Initialized
INFO - 2023-10-14 07:05:46 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:05:46 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:05:46 --> Utf8 Class Initialized
INFO - 2023-10-14 07:05:46 --> URI Class Initialized
INFO - 2023-10-14 07:05:46 --> Router Class Initialized
INFO - 2023-10-14 07:05:46 --> Output Class Initialized
INFO - 2023-10-14 07:05:46 --> Security Class Initialized
DEBUG - 2023-10-14 07:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:05:46 --> Input Class Initialized
INFO - 2023-10-14 07:05:46 --> Language Class Initialized
INFO - 2023-10-14 07:05:46 --> Loader Class Initialized
INFO - 2023-10-14 07:05:46 --> Helper loaded: url_helper
INFO - 2023-10-14 07:05:46 --> Helper loaded: file_helper
INFO - 2023-10-14 07:05:46 --> Helper loaded: html_helper
INFO - 2023-10-14 07:05:46 --> Helper loaded: text_helper
INFO - 2023-10-14 07:05:46 --> Helper loaded: form_helper
INFO - 2023-10-14 07:05:46 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:05:46 --> Helper loaded: security_helper
INFO - 2023-10-14 07:05:46 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:05:46 --> Database Driver Class Initialized
INFO - 2023-10-14 07:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:05:46 --> Parser Class Initialized
INFO - 2023-10-14 07:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:05:46 --> Pagination Class Initialized
INFO - 2023-10-14 07:05:46 --> Form Validation Class Initialized
INFO - 2023-10-14 07:05:46 --> Controller Class Initialized
DEBUG - 2023-10-14 07:05:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:46 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:46 --> Model Class Initialized
INFO - 2023-10-14 07:05:46 --> Final output sent to browser
DEBUG - 2023-10-14 07:05:46 --> Total execution time: 0.0323
ERROR - 2023-10-14 07:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:05:51 --> Config Class Initialized
INFO - 2023-10-14 07:05:51 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:05:51 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:05:51 --> Utf8 Class Initialized
INFO - 2023-10-14 07:05:51 --> URI Class Initialized
INFO - 2023-10-14 07:05:51 --> Router Class Initialized
INFO - 2023-10-14 07:05:51 --> Output Class Initialized
INFO - 2023-10-14 07:05:51 --> Security Class Initialized
DEBUG - 2023-10-14 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:05:51 --> Input Class Initialized
INFO - 2023-10-14 07:05:51 --> Language Class Initialized
INFO - 2023-10-14 07:05:51 --> Loader Class Initialized
INFO - 2023-10-14 07:05:51 --> Helper loaded: url_helper
INFO - 2023-10-14 07:05:51 --> Helper loaded: file_helper
INFO - 2023-10-14 07:05:51 --> Helper loaded: html_helper
INFO - 2023-10-14 07:05:51 --> Helper loaded: text_helper
INFO - 2023-10-14 07:05:51 --> Helper loaded: form_helper
INFO - 2023-10-14 07:05:51 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:05:51 --> Helper loaded: security_helper
INFO - 2023-10-14 07:05:51 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:05:51 --> Database Driver Class Initialized
INFO - 2023-10-14 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:05:51 --> Parser Class Initialized
INFO - 2023-10-14 07:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:05:51 --> Pagination Class Initialized
INFO - 2023-10-14 07:05:51 --> Form Validation Class Initialized
INFO - 2023-10-14 07:05:51 --> Controller Class Initialized
DEBUG - 2023-10-14 07:05:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:51 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:51 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:51 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:51 --> Model Class Initialized
INFO - 2023-10-14 07:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-14 07:05:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:05:51 --> Model Class Initialized
INFO - 2023-10-14 07:05:51 --> Model Class Initialized
INFO - 2023-10-14 07:05:51 --> Model Class Initialized
INFO - 2023-10-14 07:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:05:51 --> Final output sent to browser
DEBUG - 2023-10-14 07:05:51 --> Total execution time: 0.2003
ERROR - 2023-10-14 07:05:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:05:52 --> Config Class Initialized
INFO - 2023-10-14 07:05:52 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:05:52 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:05:52 --> Utf8 Class Initialized
INFO - 2023-10-14 07:05:52 --> URI Class Initialized
INFO - 2023-10-14 07:05:52 --> Router Class Initialized
INFO - 2023-10-14 07:05:52 --> Output Class Initialized
INFO - 2023-10-14 07:05:52 --> Security Class Initialized
DEBUG - 2023-10-14 07:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:05:52 --> Input Class Initialized
INFO - 2023-10-14 07:05:52 --> Language Class Initialized
INFO - 2023-10-14 07:05:52 --> Loader Class Initialized
INFO - 2023-10-14 07:05:52 --> Helper loaded: url_helper
INFO - 2023-10-14 07:05:52 --> Helper loaded: file_helper
INFO - 2023-10-14 07:05:52 --> Helper loaded: html_helper
INFO - 2023-10-14 07:05:52 --> Helper loaded: text_helper
INFO - 2023-10-14 07:05:52 --> Helper loaded: form_helper
INFO - 2023-10-14 07:05:52 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:05:52 --> Helper loaded: security_helper
INFO - 2023-10-14 07:05:52 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:05:52 --> Database Driver Class Initialized
INFO - 2023-10-14 07:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:05:52 --> Parser Class Initialized
INFO - 2023-10-14 07:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:05:52 --> Pagination Class Initialized
INFO - 2023-10-14 07:05:52 --> Form Validation Class Initialized
INFO - 2023-10-14 07:05:52 --> Controller Class Initialized
DEBUG - 2023-10-14 07:05:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:52 --> Model Class Initialized
DEBUG - 2023-10-14 07:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:05:52 --> Model Class Initialized
INFO - 2023-10-14 07:05:52 --> Final output sent to browser
DEBUG - 2023-10-14 07:05:52 --> Total execution time: 0.0315
ERROR - 2023-10-14 07:37:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:37:54 --> Config Class Initialized
INFO - 2023-10-14 07:37:54 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:37:54 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:37:54 --> Utf8 Class Initialized
INFO - 2023-10-14 07:37:54 --> URI Class Initialized
INFO - 2023-10-14 07:37:54 --> Router Class Initialized
INFO - 2023-10-14 07:37:54 --> Output Class Initialized
INFO - 2023-10-14 07:37:54 --> Security Class Initialized
DEBUG - 2023-10-14 07:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:37:54 --> Input Class Initialized
INFO - 2023-10-14 07:37:54 --> Language Class Initialized
INFO - 2023-10-14 07:37:54 --> Loader Class Initialized
INFO - 2023-10-14 07:37:54 --> Helper loaded: url_helper
INFO - 2023-10-14 07:37:54 --> Helper loaded: file_helper
INFO - 2023-10-14 07:37:54 --> Helper loaded: html_helper
INFO - 2023-10-14 07:37:54 --> Helper loaded: text_helper
INFO - 2023-10-14 07:37:54 --> Helper loaded: form_helper
INFO - 2023-10-14 07:37:54 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:37:54 --> Helper loaded: security_helper
INFO - 2023-10-14 07:37:54 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:37:54 --> Database Driver Class Initialized
INFO - 2023-10-14 07:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:37:54 --> Parser Class Initialized
INFO - 2023-10-14 07:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:37:54 --> Pagination Class Initialized
INFO - 2023-10-14 07:37:54 --> Form Validation Class Initialized
INFO - 2023-10-14 07:37:54 --> Controller Class Initialized
INFO - 2023-10-14 07:37:54 --> Model Class Initialized
DEBUG - 2023-10-14 07:37:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:54 --> Model Class Initialized
DEBUG - 2023-10-14 07:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:54 --> Model Class Initialized
INFO - 2023-10-14 07:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 07:37:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:37:54 --> Model Class Initialized
INFO - 2023-10-14 07:37:54 --> Model Class Initialized
INFO - 2023-10-14 07:37:54 --> Model Class Initialized
INFO - 2023-10-14 07:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:37:54 --> Final output sent to browser
DEBUG - 2023-10-14 07:37:54 --> Total execution time: 0.2234
ERROR - 2023-10-14 07:37:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:37:55 --> Config Class Initialized
INFO - 2023-10-14 07:37:55 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:37:55 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:37:55 --> Utf8 Class Initialized
INFO - 2023-10-14 07:37:55 --> URI Class Initialized
INFO - 2023-10-14 07:37:55 --> Router Class Initialized
INFO - 2023-10-14 07:37:55 --> Output Class Initialized
INFO - 2023-10-14 07:37:55 --> Security Class Initialized
DEBUG - 2023-10-14 07:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:37:55 --> Input Class Initialized
INFO - 2023-10-14 07:37:55 --> Language Class Initialized
INFO - 2023-10-14 07:37:55 --> Loader Class Initialized
INFO - 2023-10-14 07:37:55 --> Helper loaded: url_helper
INFO - 2023-10-14 07:37:55 --> Helper loaded: file_helper
INFO - 2023-10-14 07:37:55 --> Helper loaded: html_helper
INFO - 2023-10-14 07:37:55 --> Helper loaded: text_helper
INFO - 2023-10-14 07:37:55 --> Helper loaded: form_helper
INFO - 2023-10-14 07:37:55 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:37:55 --> Helper loaded: security_helper
INFO - 2023-10-14 07:37:55 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:37:55 --> Database Driver Class Initialized
INFO - 2023-10-14 07:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:37:55 --> Parser Class Initialized
INFO - 2023-10-14 07:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:37:55 --> Pagination Class Initialized
INFO - 2023-10-14 07:37:55 --> Form Validation Class Initialized
INFO - 2023-10-14 07:37:55 --> Controller Class Initialized
INFO - 2023-10-14 07:37:55 --> Model Class Initialized
DEBUG - 2023-10-14 07:37:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:55 --> Model Class Initialized
DEBUG - 2023-10-14 07:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:55 --> Model Class Initialized
INFO - 2023-10-14 07:37:55 --> Final output sent to browser
DEBUG - 2023-10-14 07:37:55 --> Total execution time: 0.0721
ERROR - 2023-10-14 07:37:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:37:59 --> Config Class Initialized
INFO - 2023-10-14 07:37:59 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:37:59 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:37:59 --> Utf8 Class Initialized
INFO - 2023-10-14 07:37:59 --> URI Class Initialized
INFO - 2023-10-14 07:37:59 --> Router Class Initialized
INFO - 2023-10-14 07:37:59 --> Output Class Initialized
INFO - 2023-10-14 07:37:59 --> Security Class Initialized
DEBUG - 2023-10-14 07:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:37:59 --> Input Class Initialized
INFO - 2023-10-14 07:37:59 --> Language Class Initialized
INFO - 2023-10-14 07:37:59 --> Loader Class Initialized
INFO - 2023-10-14 07:37:59 --> Helper loaded: url_helper
INFO - 2023-10-14 07:37:59 --> Helper loaded: file_helper
INFO - 2023-10-14 07:37:59 --> Helper loaded: html_helper
INFO - 2023-10-14 07:37:59 --> Helper loaded: text_helper
INFO - 2023-10-14 07:37:59 --> Helper loaded: form_helper
INFO - 2023-10-14 07:37:59 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:37:59 --> Helper loaded: security_helper
INFO - 2023-10-14 07:37:59 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:37:59 --> Database Driver Class Initialized
INFO - 2023-10-14 07:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:37:59 --> Parser Class Initialized
INFO - 2023-10-14 07:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:37:59 --> Pagination Class Initialized
INFO - 2023-10-14 07:37:59 --> Form Validation Class Initialized
INFO - 2023-10-14 07:37:59 --> Controller Class Initialized
INFO - 2023-10-14 07:37:59 --> Model Class Initialized
DEBUG - 2023-10-14 07:37:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:59 --> Model Class Initialized
DEBUG - 2023-10-14 07:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:59 --> Model Class Initialized
INFO - 2023-10-14 07:37:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 07:37:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:37:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:37:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:37:59 --> Model Class Initialized
INFO - 2023-10-14 07:37:59 --> Model Class Initialized
INFO - 2023-10-14 07:37:59 --> Model Class Initialized
INFO - 2023-10-14 07:37:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:37:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:37:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:37:59 --> Final output sent to browser
DEBUG - 2023-10-14 07:37:59 --> Total execution time: 0.2054
ERROR - 2023-10-14 07:38:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:38:00 --> Config Class Initialized
INFO - 2023-10-14 07:38:00 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:38:00 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:38:00 --> Utf8 Class Initialized
INFO - 2023-10-14 07:38:00 --> URI Class Initialized
INFO - 2023-10-14 07:38:00 --> Router Class Initialized
INFO - 2023-10-14 07:38:00 --> Output Class Initialized
INFO - 2023-10-14 07:38:00 --> Security Class Initialized
DEBUG - 2023-10-14 07:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:38:00 --> Input Class Initialized
INFO - 2023-10-14 07:38:00 --> Language Class Initialized
INFO - 2023-10-14 07:38:00 --> Loader Class Initialized
INFO - 2023-10-14 07:38:00 --> Helper loaded: url_helper
INFO - 2023-10-14 07:38:00 --> Helper loaded: file_helper
INFO - 2023-10-14 07:38:00 --> Helper loaded: html_helper
INFO - 2023-10-14 07:38:00 --> Helper loaded: text_helper
INFO - 2023-10-14 07:38:00 --> Helper loaded: form_helper
INFO - 2023-10-14 07:38:00 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:38:00 --> Helper loaded: security_helper
INFO - 2023-10-14 07:38:00 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:38:00 --> Database Driver Class Initialized
INFO - 2023-10-14 07:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:38:00 --> Parser Class Initialized
INFO - 2023-10-14 07:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:38:00 --> Pagination Class Initialized
INFO - 2023-10-14 07:38:00 --> Form Validation Class Initialized
INFO - 2023-10-14 07:38:00 --> Controller Class Initialized
INFO - 2023-10-14 07:38:00 --> Model Class Initialized
DEBUG - 2023-10-14 07:38:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:38:00 --> Model Class Initialized
DEBUG - 2023-10-14 07:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:38:00 --> Model Class Initialized
INFO - 2023-10-14 07:38:00 --> Final output sent to browser
DEBUG - 2023-10-14 07:38:00 --> Total execution time: 0.0588
ERROR - 2023-10-14 07:38:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:38:08 --> Config Class Initialized
INFO - 2023-10-14 07:38:08 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:38:08 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:38:08 --> Utf8 Class Initialized
INFO - 2023-10-14 07:38:08 --> URI Class Initialized
INFO - 2023-10-14 07:38:08 --> Router Class Initialized
INFO - 2023-10-14 07:38:08 --> Output Class Initialized
INFO - 2023-10-14 07:38:08 --> Security Class Initialized
DEBUG - 2023-10-14 07:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:38:08 --> Input Class Initialized
INFO - 2023-10-14 07:38:08 --> Language Class Initialized
INFO - 2023-10-14 07:38:08 --> Loader Class Initialized
INFO - 2023-10-14 07:38:08 --> Helper loaded: url_helper
INFO - 2023-10-14 07:38:08 --> Helper loaded: file_helper
INFO - 2023-10-14 07:38:08 --> Helper loaded: html_helper
INFO - 2023-10-14 07:38:08 --> Helper loaded: text_helper
INFO - 2023-10-14 07:38:08 --> Helper loaded: form_helper
INFO - 2023-10-14 07:38:08 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:38:08 --> Helper loaded: security_helper
INFO - 2023-10-14 07:38:08 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:38:08 --> Database Driver Class Initialized
INFO - 2023-10-14 07:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:38:08 --> Parser Class Initialized
INFO - 2023-10-14 07:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:38:08 --> Pagination Class Initialized
INFO - 2023-10-14 07:38:08 --> Form Validation Class Initialized
INFO - 2023-10-14 07:38:08 --> Controller Class Initialized
INFO - 2023-10-14 07:38:08 --> Model Class Initialized
DEBUG - 2023-10-14 07:38:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:38:08 --> Model Class Initialized
INFO - 2023-10-14 07:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-10-14 07:38:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 07:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 07:38:08 --> Model Class Initialized
INFO - 2023-10-14 07:38:08 --> Model Class Initialized
INFO - 2023-10-14 07:38:08 --> Model Class Initialized
INFO - 2023-10-14 07:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 07:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 07:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 07:38:08 --> Final output sent to browser
DEBUG - 2023-10-14 07:38:08 --> Total execution time: 0.2048
ERROR - 2023-10-14 07:38:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 07:38:09 --> Config Class Initialized
INFO - 2023-10-14 07:38:09 --> Hooks Class Initialized
DEBUG - 2023-10-14 07:38:09 --> UTF-8 Support Enabled
INFO - 2023-10-14 07:38:09 --> Utf8 Class Initialized
INFO - 2023-10-14 07:38:09 --> URI Class Initialized
INFO - 2023-10-14 07:38:09 --> Router Class Initialized
INFO - 2023-10-14 07:38:09 --> Output Class Initialized
INFO - 2023-10-14 07:38:09 --> Security Class Initialized
DEBUG - 2023-10-14 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 07:38:09 --> Input Class Initialized
INFO - 2023-10-14 07:38:09 --> Language Class Initialized
INFO - 2023-10-14 07:38:09 --> Loader Class Initialized
INFO - 2023-10-14 07:38:09 --> Helper loaded: url_helper
INFO - 2023-10-14 07:38:09 --> Helper loaded: file_helper
INFO - 2023-10-14 07:38:09 --> Helper loaded: html_helper
INFO - 2023-10-14 07:38:09 --> Helper loaded: text_helper
INFO - 2023-10-14 07:38:09 --> Helper loaded: form_helper
INFO - 2023-10-14 07:38:09 --> Helper loaded: lang_helper
INFO - 2023-10-14 07:38:09 --> Helper loaded: security_helper
INFO - 2023-10-14 07:38:09 --> Helper loaded: cookie_helper
INFO - 2023-10-14 07:38:09 --> Database Driver Class Initialized
INFO - 2023-10-14 07:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 07:38:09 --> Parser Class Initialized
INFO - 2023-10-14 07:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 07:38:09 --> Pagination Class Initialized
INFO - 2023-10-14 07:38:09 --> Form Validation Class Initialized
INFO - 2023-10-14 07:38:09 --> Controller Class Initialized
INFO - 2023-10-14 07:38:09 --> Model Class Initialized
DEBUG - 2023-10-14 07:38:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 07:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 07:38:09 --> Model Class Initialized
INFO - 2023-10-14 07:38:09 --> Final output sent to browser
DEBUG - 2023-10-14 07:38:09 --> Total execution time: 0.0290
ERROR - 2023-10-14 14:27:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:27:58 --> Config Class Initialized
INFO - 2023-10-14 14:27:58 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:27:58 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:27:58 --> Utf8 Class Initialized
INFO - 2023-10-14 14:27:58 --> URI Class Initialized
DEBUG - 2023-10-14 14:27:58 --> No URI present. Default controller set.
INFO - 2023-10-14 14:27:58 --> Router Class Initialized
INFO - 2023-10-14 14:27:58 --> Output Class Initialized
INFO - 2023-10-14 14:27:58 --> Security Class Initialized
DEBUG - 2023-10-14 14:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:27:58 --> Input Class Initialized
INFO - 2023-10-14 14:27:58 --> Language Class Initialized
INFO - 2023-10-14 14:27:58 --> Loader Class Initialized
INFO - 2023-10-14 14:27:58 --> Helper loaded: url_helper
INFO - 2023-10-14 14:27:58 --> Helper loaded: file_helper
INFO - 2023-10-14 14:27:58 --> Helper loaded: html_helper
INFO - 2023-10-14 14:27:58 --> Helper loaded: text_helper
INFO - 2023-10-14 14:27:58 --> Helper loaded: form_helper
INFO - 2023-10-14 14:27:58 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:27:58 --> Helper loaded: security_helper
INFO - 2023-10-14 14:27:58 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:27:58 --> Database Driver Class Initialized
INFO - 2023-10-14 14:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:27:58 --> Parser Class Initialized
INFO - 2023-10-14 14:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:27:58 --> Pagination Class Initialized
INFO - 2023-10-14 14:27:58 --> Form Validation Class Initialized
INFO - 2023-10-14 14:27:58 --> Controller Class Initialized
INFO - 2023-10-14 14:27:58 --> Model Class Initialized
DEBUG - 2023-10-14 14:27:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 14:27:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:27:59 --> Config Class Initialized
INFO - 2023-10-14 14:27:59 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:27:59 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:27:59 --> Utf8 Class Initialized
INFO - 2023-10-14 14:27:59 --> URI Class Initialized
INFO - 2023-10-14 14:27:59 --> Router Class Initialized
INFO - 2023-10-14 14:27:59 --> Output Class Initialized
INFO - 2023-10-14 14:27:59 --> Security Class Initialized
DEBUG - 2023-10-14 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:27:59 --> Input Class Initialized
INFO - 2023-10-14 14:27:59 --> Language Class Initialized
INFO - 2023-10-14 14:27:59 --> Loader Class Initialized
INFO - 2023-10-14 14:27:59 --> Helper loaded: url_helper
INFO - 2023-10-14 14:27:59 --> Helper loaded: file_helper
INFO - 2023-10-14 14:27:59 --> Helper loaded: html_helper
INFO - 2023-10-14 14:27:59 --> Helper loaded: text_helper
INFO - 2023-10-14 14:27:59 --> Helper loaded: form_helper
INFO - 2023-10-14 14:27:59 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:27:59 --> Helper loaded: security_helper
INFO - 2023-10-14 14:27:59 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:27:59 --> Database Driver Class Initialized
INFO - 2023-10-14 14:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:27:59 --> Parser Class Initialized
INFO - 2023-10-14 14:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:27:59 --> Pagination Class Initialized
INFO - 2023-10-14 14:27:59 --> Form Validation Class Initialized
INFO - 2023-10-14 14:27:59 --> Controller Class Initialized
INFO - 2023-10-14 14:27:59 --> Model Class Initialized
DEBUG - 2023-10-14 14:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 14:27:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:27:59 --> Model Class Initialized
INFO - 2023-10-14 14:27:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:27:59 --> Final output sent to browser
DEBUG - 2023-10-14 14:27:59 --> Total execution time: 0.0345
ERROR - 2023-10-14 14:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:28:23 --> Config Class Initialized
INFO - 2023-10-14 14:28:23 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:28:23 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:28:23 --> Utf8 Class Initialized
INFO - 2023-10-14 14:28:23 --> URI Class Initialized
INFO - 2023-10-14 14:28:23 --> Router Class Initialized
INFO - 2023-10-14 14:28:23 --> Output Class Initialized
INFO - 2023-10-14 14:28:23 --> Security Class Initialized
DEBUG - 2023-10-14 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:28:23 --> Input Class Initialized
INFO - 2023-10-14 14:28:23 --> Language Class Initialized
INFO - 2023-10-14 14:28:23 --> Loader Class Initialized
INFO - 2023-10-14 14:28:23 --> Helper loaded: url_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: file_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: html_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: text_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: form_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: security_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:28:23 --> Database Driver Class Initialized
INFO - 2023-10-14 14:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:28:23 --> Parser Class Initialized
INFO - 2023-10-14 14:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:28:23 --> Pagination Class Initialized
INFO - 2023-10-14 14:28:23 --> Form Validation Class Initialized
INFO - 2023-10-14 14:28:23 --> Controller Class Initialized
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
INFO - 2023-10-14 14:28:23 --> Final output sent to browser
DEBUG - 2023-10-14 14:28:23 --> Total execution time: 0.0210
ERROR - 2023-10-14 14:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:28:23 --> Config Class Initialized
INFO - 2023-10-14 14:28:23 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:28:23 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:28:23 --> Utf8 Class Initialized
INFO - 2023-10-14 14:28:23 --> URI Class Initialized
DEBUG - 2023-10-14 14:28:23 --> No URI present. Default controller set.
INFO - 2023-10-14 14:28:23 --> Router Class Initialized
INFO - 2023-10-14 14:28:23 --> Output Class Initialized
INFO - 2023-10-14 14:28:23 --> Security Class Initialized
DEBUG - 2023-10-14 14:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:28:23 --> Input Class Initialized
INFO - 2023-10-14 14:28:23 --> Language Class Initialized
INFO - 2023-10-14 14:28:23 --> Loader Class Initialized
INFO - 2023-10-14 14:28:23 --> Helper loaded: url_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: file_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: html_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: text_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: form_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: security_helper
INFO - 2023-10-14 14:28:23 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:28:23 --> Database Driver Class Initialized
INFO - 2023-10-14 14:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:28:23 --> Parser Class Initialized
INFO - 2023-10-14 14:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:28:23 --> Pagination Class Initialized
INFO - 2023-10-14 14:28:23 --> Form Validation Class Initialized
INFO - 2023-10-14 14:28:23 --> Controller Class Initialized
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
INFO - 2023-10-14 14:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 14:28:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:28:23 --> Model Class Initialized
INFO - 2023-10-14 14:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:28:23 --> Final output sent to browser
DEBUG - 2023-10-14 14:28:23 --> Total execution time: 0.2037
ERROR - 2023-10-14 14:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:28:38 --> Config Class Initialized
INFO - 2023-10-14 14:28:38 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:28:38 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:28:38 --> Utf8 Class Initialized
INFO - 2023-10-14 14:28:38 --> URI Class Initialized
INFO - 2023-10-14 14:28:38 --> Router Class Initialized
INFO - 2023-10-14 14:28:38 --> Output Class Initialized
INFO - 2023-10-14 14:28:38 --> Security Class Initialized
DEBUG - 2023-10-14 14:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:28:38 --> Input Class Initialized
INFO - 2023-10-14 14:28:38 --> Language Class Initialized
INFO - 2023-10-14 14:28:38 --> Loader Class Initialized
INFO - 2023-10-14 14:28:38 --> Helper loaded: url_helper
INFO - 2023-10-14 14:28:38 --> Helper loaded: file_helper
INFO - 2023-10-14 14:28:38 --> Helper loaded: html_helper
INFO - 2023-10-14 14:28:38 --> Helper loaded: text_helper
INFO - 2023-10-14 14:28:38 --> Helper loaded: form_helper
INFO - 2023-10-14 14:28:38 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:28:38 --> Helper loaded: security_helper
INFO - 2023-10-14 14:28:38 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:28:38 --> Database Driver Class Initialized
INFO - 2023-10-14 14:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:28:38 --> Parser Class Initialized
INFO - 2023-10-14 14:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:28:38 --> Pagination Class Initialized
INFO - 2023-10-14 14:28:38 --> Form Validation Class Initialized
INFO - 2023-10-14 14:28:38 --> Controller Class Initialized
INFO - 2023-10-14 14:28:38 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:38 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:38 --> Model Class Initialized
INFO - 2023-10-14 14:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 14:28:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:28:38 --> Model Class Initialized
INFO - 2023-10-14 14:28:38 --> Model Class Initialized
INFO - 2023-10-14 14:28:38 --> Model Class Initialized
INFO - 2023-10-14 14:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:28:38 --> Final output sent to browser
DEBUG - 2023-10-14 14:28:38 --> Total execution time: 0.1415
ERROR - 2023-10-14 14:28:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:28:39 --> Config Class Initialized
INFO - 2023-10-14 14:28:39 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:28:39 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:28:39 --> Utf8 Class Initialized
INFO - 2023-10-14 14:28:39 --> URI Class Initialized
INFO - 2023-10-14 14:28:39 --> Router Class Initialized
INFO - 2023-10-14 14:28:39 --> Output Class Initialized
INFO - 2023-10-14 14:28:39 --> Security Class Initialized
DEBUG - 2023-10-14 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:28:39 --> Input Class Initialized
INFO - 2023-10-14 14:28:39 --> Language Class Initialized
INFO - 2023-10-14 14:28:39 --> Loader Class Initialized
INFO - 2023-10-14 14:28:39 --> Helper loaded: url_helper
INFO - 2023-10-14 14:28:39 --> Helper loaded: file_helper
INFO - 2023-10-14 14:28:39 --> Helper loaded: html_helper
INFO - 2023-10-14 14:28:39 --> Helper loaded: text_helper
INFO - 2023-10-14 14:28:39 --> Helper loaded: form_helper
INFO - 2023-10-14 14:28:39 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:28:39 --> Helper loaded: security_helper
INFO - 2023-10-14 14:28:39 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:28:39 --> Database Driver Class Initialized
INFO - 2023-10-14 14:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:28:39 --> Parser Class Initialized
INFO - 2023-10-14 14:28:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:28:39 --> Pagination Class Initialized
INFO - 2023-10-14 14:28:39 --> Form Validation Class Initialized
INFO - 2023-10-14 14:28:39 --> Controller Class Initialized
INFO - 2023-10-14 14:28:39 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:39 --> Model Class Initialized
DEBUG - 2023-10-14 14:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:28:39 --> Model Class Initialized
INFO - 2023-10-14 14:28:39 --> Final output sent to browser
DEBUG - 2023-10-14 14:28:39 --> Total execution time: 0.0398
ERROR - 2023-10-14 14:29:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:29:41 --> Config Class Initialized
INFO - 2023-10-14 14:29:41 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:29:41 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:29:41 --> Utf8 Class Initialized
INFO - 2023-10-14 14:29:41 --> URI Class Initialized
INFO - 2023-10-14 14:29:41 --> Router Class Initialized
INFO - 2023-10-14 14:29:41 --> Output Class Initialized
INFO - 2023-10-14 14:29:41 --> Security Class Initialized
DEBUG - 2023-10-14 14:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:29:41 --> Input Class Initialized
INFO - 2023-10-14 14:29:41 --> Language Class Initialized
INFO - 2023-10-14 14:29:41 --> Loader Class Initialized
INFO - 2023-10-14 14:29:41 --> Helper loaded: url_helper
INFO - 2023-10-14 14:29:41 --> Helper loaded: file_helper
INFO - 2023-10-14 14:29:41 --> Helper loaded: html_helper
INFO - 2023-10-14 14:29:41 --> Helper loaded: text_helper
INFO - 2023-10-14 14:29:41 --> Helper loaded: form_helper
INFO - 2023-10-14 14:29:41 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:29:41 --> Helper loaded: security_helper
INFO - 2023-10-14 14:29:41 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:29:41 --> Database Driver Class Initialized
INFO - 2023-10-14 14:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:29:41 --> Parser Class Initialized
INFO - 2023-10-14 14:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:29:41 --> Pagination Class Initialized
INFO - 2023-10-14 14:29:41 --> Form Validation Class Initialized
INFO - 2023-10-14 14:29:41 --> Controller Class Initialized
INFO - 2023-10-14 14:29:41 --> Model Class Initialized
DEBUG - 2023-10-14 14:29:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:29:41 --> Model Class Initialized
DEBUG - 2023-10-14 14:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:29:41 --> Model Class Initialized
DEBUG - 2023-10-14 14:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 14:29:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:29:41 --> Model Class Initialized
INFO - 2023-10-14 14:29:41 --> Model Class Initialized
INFO - 2023-10-14 14:29:41 --> Model Class Initialized
INFO - 2023-10-14 14:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:29:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:29:41 --> Final output sent to browser
DEBUG - 2023-10-14 14:29:41 --> Total execution time: 0.1642
ERROR - 2023-10-14 14:30:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:00 --> Config Class Initialized
INFO - 2023-10-14 14:30:00 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:00 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:00 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:00 --> URI Class Initialized
INFO - 2023-10-14 14:30:00 --> Router Class Initialized
INFO - 2023-10-14 14:30:00 --> Output Class Initialized
INFO - 2023-10-14 14:30:00 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:00 --> Input Class Initialized
INFO - 2023-10-14 14:30:00 --> Language Class Initialized
INFO - 2023-10-14 14:30:00 --> Loader Class Initialized
INFO - 2023-10-14 14:30:00 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:00 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:00 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:00 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:00 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:00 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:00 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:00 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:00 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:00 --> Parser Class Initialized
INFO - 2023-10-14 14:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:00 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:00 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:00 --> Controller Class Initialized
INFO - 2023-10-14 14:30:00 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:00 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:00 --> Model Class Initialized
INFO - 2023-10-14 14:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 14:30:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:30:00 --> Model Class Initialized
INFO - 2023-10-14 14:30:00 --> Model Class Initialized
INFO - 2023-10-14 14:30:00 --> Model Class Initialized
INFO - 2023-10-14 14:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:30:00 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:00 --> Total execution time: 0.1660
ERROR - 2023-10-14 14:30:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:01 --> Config Class Initialized
INFO - 2023-10-14 14:30:01 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:01 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:01 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:01 --> URI Class Initialized
INFO - 2023-10-14 14:30:01 --> Router Class Initialized
INFO - 2023-10-14 14:30:01 --> Output Class Initialized
INFO - 2023-10-14 14:30:01 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:01 --> Input Class Initialized
INFO - 2023-10-14 14:30:01 --> Language Class Initialized
INFO - 2023-10-14 14:30:01 --> Loader Class Initialized
INFO - 2023-10-14 14:30:01 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:01 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:01 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:01 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:01 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:01 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:01 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:01 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:01 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:01 --> Parser Class Initialized
INFO - 2023-10-14 14:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:01 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:01 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:01 --> Controller Class Initialized
INFO - 2023-10-14 14:30:01 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:01 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:01 --> Model Class Initialized
INFO - 2023-10-14 14:30:01 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:01 --> Total execution time: 0.0429
ERROR - 2023-10-14 14:30:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:05 --> Config Class Initialized
INFO - 2023-10-14 14:30:05 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:05 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:05 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:05 --> URI Class Initialized
INFO - 2023-10-14 14:30:05 --> Router Class Initialized
INFO - 2023-10-14 14:30:05 --> Output Class Initialized
INFO - 2023-10-14 14:30:05 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:05 --> Input Class Initialized
INFO - 2023-10-14 14:30:05 --> Language Class Initialized
INFO - 2023-10-14 14:30:05 --> Loader Class Initialized
INFO - 2023-10-14 14:30:05 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:05 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:05 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:05 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:05 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:05 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:05 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:05 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:05 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:05 --> Parser Class Initialized
INFO - 2023-10-14 14:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:05 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:05 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:05 --> Controller Class Initialized
INFO - 2023-10-14 14:30:05 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:05 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:05 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 14:30:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:30:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:30:05 --> Model Class Initialized
INFO - 2023-10-14 14:30:05 --> Model Class Initialized
INFO - 2023-10-14 14:30:05 --> Model Class Initialized
INFO - 2023-10-14 14:30:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:30:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:30:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:30:05 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:05 --> Total execution time: 0.1527
ERROR - 2023-10-14 14:30:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:28 --> Config Class Initialized
INFO - 2023-10-14 14:30:28 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:28 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:28 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:28 --> URI Class Initialized
INFO - 2023-10-14 14:30:28 --> Router Class Initialized
INFO - 2023-10-14 14:30:28 --> Output Class Initialized
INFO - 2023-10-14 14:30:28 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:28 --> Input Class Initialized
INFO - 2023-10-14 14:30:28 --> Language Class Initialized
INFO - 2023-10-14 14:30:28 --> Loader Class Initialized
INFO - 2023-10-14 14:30:28 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:28 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:28 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:28 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:28 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:28 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:28 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:28 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:28 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:28 --> Parser Class Initialized
INFO - 2023-10-14 14:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:28 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:28 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:28 --> Controller Class Initialized
INFO - 2023-10-14 14:30:28 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:28 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:28 --> Model Class Initialized
INFO - 2023-10-14 14:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 14:30:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:30:28 --> Model Class Initialized
INFO - 2023-10-14 14:30:28 --> Model Class Initialized
INFO - 2023-10-14 14:30:28 --> Model Class Initialized
INFO - 2023-10-14 14:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:30:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:30:28 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:28 --> Total execution time: 0.1376
ERROR - 2023-10-14 14:30:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:29 --> Config Class Initialized
INFO - 2023-10-14 14:30:29 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:29 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:29 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:29 --> URI Class Initialized
INFO - 2023-10-14 14:30:29 --> Router Class Initialized
INFO - 2023-10-14 14:30:29 --> Output Class Initialized
INFO - 2023-10-14 14:30:29 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:29 --> Input Class Initialized
INFO - 2023-10-14 14:30:29 --> Language Class Initialized
INFO - 2023-10-14 14:30:29 --> Loader Class Initialized
INFO - 2023-10-14 14:30:29 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:29 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:29 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:29 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:29 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:29 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:29 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:29 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:29 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:29 --> Parser Class Initialized
INFO - 2023-10-14 14:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:29 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:29 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:29 --> Controller Class Initialized
INFO - 2023-10-14 14:30:29 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:29 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:29 --> Model Class Initialized
INFO - 2023-10-14 14:30:29 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:29 --> Total execution time: 0.0383
ERROR - 2023-10-14 14:30:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:34 --> Config Class Initialized
INFO - 2023-10-14 14:30:34 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:34 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:34 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:34 --> URI Class Initialized
INFO - 2023-10-14 14:30:34 --> Router Class Initialized
INFO - 2023-10-14 14:30:34 --> Output Class Initialized
INFO - 2023-10-14 14:30:34 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:34 --> Input Class Initialized
INFO - 2023-10-14 14:30:34 --> Language Class Initialized
INFO - 2023-10-14 14:30:34 --> Loader Class Initialized
INFO - 2023-10-14 14:30:34 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:34 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:34 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:34 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:34 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:34 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:34 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:34 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:34 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:34 --> Parser Class Initialized
INFO - 2023-10-14 14:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:34 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:34 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:34 --> Controller Class Initialized
INFO - 2023-10-14 14:30:34 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:34 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:34 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 14:30:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:30:34 --> Model Class Initialized
INFO - 2023-10-14 14:30:34 --> Model Class Initialized
INFO - 2023-10-14 14:30:34 --> Model Class Initialized
INFO - 2023-10-14 14:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:30:34 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:34 --> Total execution time: 0.1385
ERROR - 2023-10-14 14:30:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:44 --> Config Class Initialized
INFO - 2023-10-14 14:30:44 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:44 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:44 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:44 --> URI Class Initialized
INFO - 2023-10-14 14:30:44 --> Router Class Initialized
INFO - 2023-10-14 14:30:44 --> Output Class Initialized
INFO - 2023-10-14 14:30:44 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:44 --> Input Class Initialized
INFO - 2023-10-14 14:30:44 --> Language Class Initialized
INFO - 2023-10-14 14:30:44 --> Loader Class Initialized
INFO - 2023-10-14 14:30:44 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:44 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:44 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:44 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:44 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:44 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:44 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:44 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:44 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:44 --> Parser Class Initialized
INFO - 2023-10-14 14:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:44 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:44 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:44 --> Controller Class Initialized
INFO - 2023-10-14 14:30:44 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:44 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:44 --> Model Class Initialized
INFO - 2023-10-14 14:30:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 14:30:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:30:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:30:44 --> Model Class Initialized
INFO - 2023-10-14 14:30:44 --> Model Class Initialized
INFO - 2023-10-14 14:30:44 --> Model Class Initialized
INFO - 2023-10-14 14:30:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:30:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:30:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:30:44 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:44 --> Total execution time: 0.1353
ERROR - 2023-10-14 14:30:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:45 --> Config Class Initialized
INFO - 2023-10-14 14:30:45 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:45 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:45 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:45 --> URI Class Initialized
INFO - 2023-10-14 14:30:45 --> Router Class Initialized
INFO - 2023-10-14 14:30:45 --> Output Class Initialized
INFO - 2023-10-14 14:30:45 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:45 --> Input Class Initialized
INFO - 2023-10-14 14:30:45 --> Language Class Initialized
INFO - 2023-10-14 14:30:45 --> Loader Class Initialized
INFO - 2023-10-14 14:30:45 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:45 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:45 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:45 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:45 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:45 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:45 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:45 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:45 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:45 --> Parser Class Initialized
INFO - 2023-10-14 14:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:45 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:45 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:45 --> Controller Class Initialized
INFO - 2023-10-14 14:30:45 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:45 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:45 --> Model Class Initialized
INFO - 2023-10-14 14:30:45 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:45 --> Total execution time: 0.0376
ERROR - 2023-10-14 14:30:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:51 --> Config Class Initialized
INFO - 2023-10-14 14:30:51 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:51 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:51 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:51 --> URI Class Initialized
INFO - 2023-10-14 14:30:51 --> Router Class Initialized
INFO - 2023-10-14 14:30:51 --> Output Class Initialized
INFO - 2023-10-14 14:30:51 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:51 --> Input Class Initialized
INFO - 2023-10-14 14:30:51 --> Language Class Initialized
INFO - 2023-10-14 14:30:51 --> Loader Class Initialized
INFO - 2023-10-14 14:30:51 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:51 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:51 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:51 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:51 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:51 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:51 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:51 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:51 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:51 --> Parser Class Initialized
INFO - 2023-10-14 14:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:51 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:51 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:51 --> Controller Class Initialized
INFO - 2023-10-14 14:30:51 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:51 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:51 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 14:30:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:30:51 --> Model Class Initialized
INFO - 2023-10-14 14:30:51 --> Model Class Initialized
INFO - 2023-10-14 14:30:51 --> Model Class Initialized
INFO - 2023-10-14 14:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:30:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:30:51 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:51 --> Total execution time: 0.1424
ERROR - 2023-10-14 14:30:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:57 --> Config Class Initialized
INFO - 2023-10-14 14:30:57 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:57 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:57 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:57 --> URI Class Initialized
INFO - 2023-10-14 14:30:57 --> Router Class Initialized
INFO - 2023-10-14 14:30:57 --> Output Class Initialized
INFO - 2023-10-14 14:30:57 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:57 --> Input Class Initialized
INFO - 2023-10-14 14:30:57 --> Language Class Initialized
INFO - 2023-10-14 14:30:57 --> Loader Class Initialized
INFO - 2023-10-14 14:30:57 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:57 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:57 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:57 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:57 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:57 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:57 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:57 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:57 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:57 --> Parser Class Initialized
INFO - 2023-10-14 14:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:57 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:57 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:57 --> Controller Class Initialized
INFO - 2023-10-14 14:30:57 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:57 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:57 --> Model Class Initialized
INFO - 2023-10-14 14:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 14:30:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:30:57 --> Model Class Initialized
INFO - 2023-10-14 14:30:57 --> Model Class Initialized
INFO - 2023-10-14 14:30:57 --> Model Class Initialized
INFO - 2023-10-14 14:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:30:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:30:57 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:57 --> Total execution time: 0.1312
ERROR - 2023-10-14 14:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:30:58 --> Config Class Initialized
INFO - 2023-10-14 14:30:58 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:30:58 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:30:58 --> Utf8 Class Initialized
INFO - 2023-10-14 14:30:58 --> URI Class Initialized
INFO - 2023-10-14 14:30:58 --> Router Class Initialized
INFO - 2023-10-14 14:30:58 --> Output Class Initialized
INFO - 2023-10-14 14:30:58 --> Security Class Initialized
DEBUG - 2023-10-14 14:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:30:58 --> Input Class Initialized
INFO - 2023-10-14 14:30:58 --> Language Class Initialized
INFO - 2023-10-14 14:30:58 --> Loader Class Initialized
INFO - 2023-10-14 14:30:58 --> Helper loaded: url_helper
INFO - 2023-10-14 14:30:58 --> Helper loaded: file_helper
INFO - 2023-10-14 14:30:58 --> Helper loaded: html_helper
INFO - 2023-10-14 14:30:58 --> Helper loaded: text_helper
INFO - 2023-10-14 14:30:58 --> Helper loaded: form_helper
INFO - 2023-10-14 14:30:58 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:30:58 --> Helper loaded: security_helper
INFO - 2023-10-14 14:30:58 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:30:58 --> Database Driver Class Initialized
INFO - 2023-10-14 14:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:30:58 --> Parser Class Initialized
INFO - 2023-10-14 14:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:30:58 --> Pagination Class Initialized
INFO - 2023-10-14 14:30:58 --> Form Validation Class Initialized
INFO - 2023-10-14 14:30:58 --> Controller Class Initialized
INFO - 2023-10-14 14:30:58 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:58 --> Model Class Initialized
DEBUG - 2023-10-14 14:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:30:58 --> Model Class Initialized
INFO - 2023-10-14 14:30:58 --> Final output sent to browser
DEBUG - 2023-10-14 14:30:58 --> Total execution time: 0.0392
ERROR - 2023-10-14 14:31:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:31:04 --> Config Class Initialized
INFO - 2023-10-14 14:31:04 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:31:04 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:31:04 --> Utf8 Class Initialized
INFO - 2023-10-14 14:31:04 --> URI Class Initialized
INFO - 2023-10-14 14:31:04 --> Router Class Initialized
INFO - 2023-10-14 14:31:04 --> Output Class Initialized
INFO - 2023-10-14 14:31:04 --> Security Class Initialized
DEBUG - 2023-10-14 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:31:04 --> Input Class Initialized
INFO - 2023-10-14 14:31:04 --> Language Class Initialized
INFO - 2023-10-14 14:31:04 --> Loader Class Initialized
INFO - 2023-10-14 14:31:04 --> Helper loaded: url_helper
INFO - 2023-10-14 14:31:04 --> Helper loaded: file_helper
INFO - 2023-10-14 14:31:04 --> Helper loaded: html_helper
INFO - 2023-10-14 14:31:04 --> Helper loaded: text_helper
INFO - 2023-10-14 14:31:04 --> Helper loaded: form_helper
INFO - 2023-10-14 14:31:04 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:31:04 --> Helper loaded: security_helper
INFO - 2023-10-14 14:31:04 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:31:04 --> Database Driver Class Initialized
INFO - 2023-10-14 14:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:31:04 --> Parser Class Initialized
INFO - 2023-10-14 14:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:31:04 --> Pagination Class Initialized
INFO - 2023-10-14 14:31:04 --> Form Validation Class Initialized
INFO - 2023-10-14 14:31:04 --> Controller Class Initialized
INFO - 2023-10-14 14:31:04 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:04 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:04 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-14 14:31:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:31:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:31:04 --> Model Class Initialized
INFO - 2023-10-14 14:31:04 --> Model Class Initialized
INFO - 2023-10-14 14:31:04 --> Model Class Initialized
INFO - 2023-10-14 14:31:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:31:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:31:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:31:04 --> Final output sent to browser
DEBUG - 2023-10-14 14:31:04 --> Total execution time: 0.1426
ERROR - 2023-10-14 14:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:31:31 --> Config Class Initialized
INFO - 2023-10-14 14:31:31 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:31:31 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:31:31 --> Utf8 Class Initialized
INFO - 2023-10-14 14:31:31 --> URI Class Initialized
INFO - 2023-10-14 14:31:31 --> Router Class Initialized
INFO - 2023-10-14 14:31:31 --> Output Class Initialized
INFO - 2023-10-14 14:31:31 --> Security Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:31:31 --> Input Class Initialized
INFO - 2023-10-14 14:31:31 --> Language Class Initialized
INFO - 2023-10-14 14:31:31 --> Loader Class Initialized
INFO - 2023-10-14 14:31:31 --> Helper loaded: url_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: file_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: html_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: text_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: form_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: security_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:31:31 --> Database Driver Class Initialized
INFO - 2023-10-14 14:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:31:31 --> Parser Class Initialized
INFO - 2023-10-14 14:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:31:31 --> Pagination Class Initialized
INFO - 2023-10-14 14:31:31 --> Form Validation Class Initialized
INFO - 2023-10-14 14:31:31 --> Controller Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 14:31:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:31:31 --> Final output sent to browser
DEBUG - 2023-10-14 14:31:31 --> Total execution time: 0.1351
ERROR - 2023-10-14 14:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:31:31 --> Config Class Initialized
INFO - 2023-10-14 14:31:31 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:31:31 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:31:31 --> Utf8 Class Initialized
INFO - 2023-10-14 14:31:31 --> URI Class Initialized
DEBUG - 2023-10-14 14:31:31 --> No URI present. Default controller set.
INFO - 2023-10-14 14:31:31 --> Router Class Initialized
INFO - 2023-10-14 14:31:31 --> Output Class Initialized
INFO - 2023-10-14 14:31:31 --> Security Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:31:31 --> Input Class Initialized
INFO - 2023-10-14 14:31:31 --> Language Class Initialized
INFO - 2023-10-14 14:31:31 --> Loader Class Initialized
INFO - 2023-10-14 14:31:31 --> Helper loaded: url_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: file_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: html_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: text_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: form_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: security_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:31:31 --> Database Driver Class Initialized
INFO - 2023-10-14 14:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:31:31 --> Parser Class Initialized
INFO - 2023-10-14 14:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:31:31 --> Pagination Class Initialized
INFO - 2023-10-14 14:31:31 --> Form Validation Class Initialized
INFO - 2023-10-14 14:31:31 --> Controller Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 14:31:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
ERROR - 2023-10-14 14:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:31:31 --> Config Class Initialized
INFO - 2023-10-14 14:31:31 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:31:31 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:31:31 --> Utf8 Class Initialized
INFO - 2023-10-14 14:31:31 --> URI Class Initialized
INFO - 2023-10-14 14:31:31 --> Router Class Initialized
INFO - 2023-10-14 14:31:31 --> Output Class Initialized
INFO - 2023-10-14 14:31:31 --> Security Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:31:31 --> Input Class Initialized
INFO - 2023-10-14 14:31:31 --> Language Class Initialized
INFO - 2023-10-14 14:31:31 --> Loader Class Initialized
INFO - 2023-10-14 14:31:31 --> Helper loaded: url_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: file_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: html_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: text_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: form_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: security_helper
INFO - 2023-10-14 14:31:31 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:31:31 --> Database Driver Class Initialized
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:31:31 --> Final output sent to browser
DEBUG - 2023-10-14 14:31:31 --> Total execution time: 0.1957
INFO - 2023-10-14 14:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:31:31 --> Parser Class Initialized
INFO - 2023-10-14 14:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:31:31 --> Pagination Class Initialized
INFO - 2023-10-14 14:31:31 --> Form Validation Class Initialized
INFO - 2023-10-14 14:31:31 --> Controller Class Initialized
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 14:31:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:31:31 --> Model Class Initialized
INFO - 2023-10-14 14:31:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:31:31 --> Final output sent to browser
DEBUG - 2023-10-14 14:31:31 --> Total execution time: 0.0303
ERROR - 2023-10-14 14:31:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 14:31:32 --> Config Class Initialized
INFO - 2023-10-14 14:31:32 --> Hooks Class Initialized
DEBUG - 2023-10-14 14:31:32 --> UTF-8 Support Enabled
INFO - 2023-10-14 14:31:32 --> Utf8 Class Initialized
INFO - 2023-10-14 14:31:32 --> URI Class Initialized
INFO - 2023-10-14 14:31:32 --> Router Class Initialized
INFO - 2023-10-14 14:31:32 --> Output Class Initialized
INFO - 2023-10-14 14:31:32 --> Security Class Initialized
DEBUG - 2023-10-14 14:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 14:31:32 --> Input Class Initialized
INFO - 2023-10-14 14:31:32 --> Language Class Initialized
INFO - 2023-10-14 14:31:32 --> Loader Class Initialized
INFO - 2023-10-14 14:31:32 --> Helper loaded: url_helper
INFO - 2023-10-14 14:31:32 --> Helper loaded: file_helper
INFO - 2023-10-14 14:31:32 --> Helper loaded: html_helper
INFO - 2023-10-14 14:31:32 --> Helper loaded: text_helper
INFO - 2023-10-14 14:31:32 --> Helper loaded: form_helper
INFO - 2023-10-14 14:31:32 --> Helper loaded: lang_helper
INFO - 2023-10-14 14:31:32 --> Helper loaded: security_helper
INFO - 2023-10-14 14:31:32 --> Helper loaded: cookie_helper
INFO - 2023-10-14 14:31:32 --> Database Driver Class Initialized
INFO - 2023-10-14 14:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 14:31:32 --> Parser Class Initialized
INFO - 2023-10-14 14:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 14:31:32 --> Pagination Class Initialized
INFO - 2023-10-14 14:31:32 --> Form Validation Class Initialized
INFO - 2023-10-14 14:31:32 --> Controller Class Initialized
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
DEBUG - 2023-10-14 14:31:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 14:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
INFO - 2023-10-14 14:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 14:31:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 14:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 14:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 14:31:32 --> Model Class Initialized
INFO - 2023-10-14 14:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 14:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 14:31:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 14:31:32 --> Final output sent to browser
DEBUG - 2023-10-14 14:31:32 --> Total execution time: 0.1981
ERROR - 2023-10-14 17:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:10:50 --> Config Class Initialized
INFO - 2023-10-14 17:10:50 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:10:50 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:10:50 --> Utf8 Class Initialized
INFO - 2023-10-14 17:10:50 --> URI Class Initialized
DEBUG - 2023-10-14 17:10:50 --> No URI present. Default controller set.
INFO - 2023-10-14 17:10:50 --> Router Class Initialized
INFO - 2023-10-14 17:10:50 --> Output Class Initialized
INFO - 2023-10-14 17:10:50 --> Security Class Initialized
DEBUG - 2023-10-14 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:10:50 --> Input Class Initialized
INFO - 2023-10-14 17:10:50 --> Language Class Initialized
INFO - 2023-10-14 17:10:50 --> Loader Class Initialized
INFO - 2023-10-14 17:10:50 --> Helper loaded: url_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: file_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: html_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: text_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: form_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: security_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:10:50 --> Database Driver Class Initialized
INFO - 2023-10-14 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:10:50 --> Parser Class Initialized
INFO - 2023-10-14 17:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:10:50 --> Pagination Class Initialized
INFO - 2023-10-14 17:10:50 --> Form Validation Class Initialized
INFO - 2023-10-14 17:10:50 --> Controller Class Initialized
INFO - 2023-10-14 17:10:50 --> Model Class Initialized
DEBUG - 2023-10-14 17:10:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 17:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:10:50 --> Config Class Initialized
INFO - 2023-10-14 17:10:50 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:10:50 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:10:50 --> Utf8 Class Initialized
INFO - 2023-10-14 17:10:50 --> URI Class Initialized
INFO - 2023-10-14 17:10:50 --> Router Class Initialized
INFO - 2023-10-14 17:10:50 --> Output Class Initialized
INFO - 2023-10-14 17:10:50 --> Security Class Initialized
DEBUG - 2023-10-14 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:10:50 --> Input Class Initialized
INFO - 2023-10-14 17:10:50 --> Language Class Initialized
INFO - 2023-10-14 17:10:50 --> Loader Class Initialized
INFO - 2023-10-14 17:10:50 --> Helper loaded: url_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: file_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: html_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: text_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: form_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: security_helper
INFO - 2023-10-14 17:10:50 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:10:50 --> Database Driver Class Initialized
INFO - 2023-10-14 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:10:50 --> Parser Class Initialized
INFO - 2023-10-14 17:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:10:50 --> Pagination Class Initialized
INFO - 2023-10-14 17:10:50 --> Form Validation Class Initialized
INFO - 2023-10-14 17:10:50 --> Controller Class Initialized
INFO - 2023-10-14 17:10:50 --> Model Class Initialized
DEBUG - 2023-10-14 17:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 17:10:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:10:50 --> Model Class Initialized
INFO - 2023-10-14 17:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:10:50 --> Final output sent to browser
DEBUG - 2023-10-14 17:10:50 --> Total execution time: 0.0317
ERROR - 2023-10-14 17:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:11:14 --> Config Class Initialized
INFO - 2023-10-14 17:11:14 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:11:14 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:11:14 --> Utf8 Class Initialized
INFO - 2023-10-14 17:11:14 --> URI Class Initialized
INFO - 2023-10-14 17:11:14 --> Router Class Initialized
INFO - 2023-10-14 17:11:14 --> Output Class Initialized
INFO - 2023-10-14 17:11:14 --> Security Class Initialized
DEBUG - 2023-10-14 17:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:11:14 --> Input Class Initialized
INFO - 2023-10-14 17:11:14 --> Language Class Initialized
INFO - 2023-10-14 17:11:14 --> Loader Class Initialized
INFO - 2023-10-14 17:11:14 --> Helper loaded: url_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: file_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: html_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: text_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: form_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: security_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:11:14 --> Database Driver Class Initialized
INFO - 2023-10-14 17:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:11:14 --> Parser Class Initialized
INFO - 2023-10-14 17:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:11:14 --> Pagination Class Initialized
INFO - 2023-10-14 17:11:14 --> Form Validation Class Initialized
INFO - 2023-10-14 17:11:14 --> Controller Class Initialized
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
DEBUG - 2023-10-14 17:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
INFO - 2023-10-14 17:11:14 --> Final output sent to browser
DEBUG - 2023-10-14 17:11:14 --> Total execution time: 0.0191
ERROR - 2023-10-14 17:11:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:11:14 --> Config Class Initialized
INFO - 2023-10-14 17:11:14 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:11:14 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:11:14 --> Utf8 Class Initialized
INFO - 2023-10-14 17:11:14 --> URI Class Initialized
DEBUG - 2023-10-14 17:11:14 --> No URI present. Default controller set.
INFO - 2023-10-14 17:11:14 --> Router Class Initialized
INFO - 2023-10-14 17:11:14 --> Output Class Initialized
INFO - 2023-10-14 17:11:14 --> Security Class Initialized
DEBUG - 2023-10-14 17:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:11:14 --> Input Class Initialized
INFO - 2023-10-14 17:11:14 --> Language Class Initialized
INFO - 2023-10-14 17:11:14 --> Loader Class Initialized
INFO - 2023-10-14 17:11:14 --> Helper loaded: url_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: file_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: html_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: text_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: form_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: security_helper
INFO - 2023-10-14 17:11:14 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:11:14 --> Database Driver Class Initialized
INFO - 2023-10-14 17:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:11:14 --> Parser Class Initialized
INFO - 2023-10-14 17:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:11:14 --> Pagination Class Initialized
INFO - 2023-10-14 17:11:14 --> Form Validation Class Initialized
INFO - 2023-10-14 17:11:14 --> Controller Class Initialized
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
DEBUG - 2023-10-14 17:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
DEBUG - 2023-10-14 17:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
DEBUG - 2023-10-14 17:11:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
INFO - 2023-10-14 17:11:14 --> Model Class Initialized
INFO - 2023-10-14 17:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 17:11:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:11:15 --> Model Class Initialized
INFO - 2023-10-14 17:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 17:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 17:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:11:15 --> Final output sent to browser
DEBUG - 2023-10-14 17:11:15 --> Total execution time: 0.3596
ERROR - 2023-10-14 17:11:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:11:16 --> Config Class Initialized
INFO - 2023-10-14 17:11:16 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:11:16 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:11:16 --> Utf8 Class Initialized
INFO - 2023-10-14 17:11:16 --> URI Class Initialized
INFO - 2023-10-14 17:11:16 --> Router Class Initialized
INFO - 2023-10-14 17:11:16 --> Output Class Initialized
INFO - 2023-10-14 17:11:16 --> Security Class Initialized
DEBUG - 2023-10-14 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:11:16 --> Input Class Initialized
INFO - 2023-10-14 17:11:16 --> Language Class Initialized
INFO - 2023-10-14 17:11:16 --> Loader Class Initialized
INFO - 2023-10-14 17:11:16 --> Helper loaded: url_helper
INFO - 2023-10-14 17:11:16 --> Helper loaded: file_helper
INFO - 2023-10-14 17:11:16 --> Helper loaded: html_helper
INFO - 2023-10-14 17:11:16 --> Helper loaded: text_helper
INFO - 2023-10-14 17:11:16 --> Helper loaded: form_helper
INFO - 2023-10-14 17:11:16 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:11:16 --> Helper loaded: security_helper
INFO - 2023-10-14 17:11:16 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:11:16 --> Database Driver Class Initialized
INFO - 2023-10-14 17:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:11:16 --> Parser Class Initialized
INFO - 2023-10-14 17:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:11:16 --> Pagination Class Initialized
INFO - 2023-10-14 17:11:16 --> Form Validation Class Initialized
INFO - 2023-10-14 17:11:16 --> Controller Class Initialized
DEBUG - 2023-10-14 17:11:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:11:16 --> Model Class Initialized
INFO - 2023-10-14 17:11:16 --> Final output sent to browser
DEBUG - 2023-10-14 17:11:16 --> Total execution time: 0.0132
ERROR - 2023-10-14 17:29:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:29:03 --> Config Class Initialized
INFO - 2023-10-14 17:29:03 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:29:03 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:29:03 --> Utf8 Class Initialized
INFO - 2023-10-14 17:29:03 --> URI Class Initialized
DEBUG - 2023-10-14 17:29:03 --> No URI present. Default controller set.
INFO - 2023-10-14 17:29:03 --> Router Class Initialized
INFO - 2023-10-14 17:29:03 --> Output Class Initialized
INFO - 2023-10-14 17:29:03 --> Security Class Initialized
DEBUG - 2023-10-14 17:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:29:03 --> Input Class Initialized
INFO - 2023-10-14 17:29:03 --> Language Class Initialized
INFO - 2023-10-14 17:29:03 --> Loader Class Initialized
INFO - 2023-10-14 17:29:03 --> Helper loaded: url_helper
INFO - 2023-10-14 17:29:03 --> Helper loaded: file_helper
INFO - 2023-10-14 17:29:03 --> Helper loaded: html_helper
INFO - 2023-10-14 17:29:03 --> Helper loaded: text_helper
INFO - 2023-10-14 17:29:03 --> Helper loaded: form_helper
INFO - 2023-10-14 17:29:03 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:29:03 --> Helper loaded: security_helper
INFO - 2023-10-14 17:29:03 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:29:03 --> Database Driver Class Initialized
INFO - 2023-10-14 17:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:29:03 --> Parser Class Initialized
INFO - 2023-10-14 17:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:29:03 --> Pagination Class Initialized
INFO - 2023-10-14 17:29:03 --> Form Validation Class Initialized
INFO - 2023-10-14 17:29:03 --> Controller Class Initialized
INFO - 2023-10-14 17:29:03 --> Model Class Initialized
DEBUG - 2023-10-14 17:29:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 17:29:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:29:04 --> Config Class Initialized
INFO - 2023-10-14 17:29:04 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:29:04 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:29:04 --> Utf8 Class Initialized
INFO - 2023-10-14 17:29:04 --> URI Class Initialized
INFO - 2023-10-14 17:29:04 --> Router Class Initialized
INFO - 2023-10-14 17:29:04 --> Output Class Initialized
INFO - 2023-10-14 17:29:04 --> Security Class Initialized
DEBUG - 2023-10-14 17:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:29:04 --> Input Class Initialized
INFO - 2023-10-14 17:29:04 --> Language Class Initialized
INFO - 2023-10-14 17:29:04 --> Loader Class Initialized
INFO - 2023-10-14 17:29:04 --> Helper loaded: url_helper
INFO - 2023-10-14 17:29:04 --> Helper loaded: file_helper
INFO - 2023-10-14 17:29:04 --> Helper loaded: html_helper
INFO - 2023-10-14 17:29:04 --> Helper loaded: text_helper
INFO - 2023-10-14 17:29:04 --> Helper loaded: form_helper
INFO - 2023-10-14 17:29:04 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:29:04 --> Helper loaded: security_helper
INFO - 2023-10-14 17:29:04 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:29:04 --> Database Driver Class Initialized
INFO - 2023-10-14 17:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:29:04 --> Parser Class Initialized
INFO - 2023-10-14 17:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:29:04 --> Pagination Class Initialized
INFO - 2023-10-14 17:29:04 --> Form Validation Class Initialized
INFO - 2023-10-14 17:29:04 --> Controller Class Initialized
INFO - 2023-10-14 17:29:04 --> Model Class Initialized
DEBUG - 2023-10-14 17:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 17:29:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:29:04 --> Model Class Initialized
INFO - 2023-10-14 17:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:29:04 --> Final output sent to browser
DEBUG - 2023-10-14 17:29:04 --> Total execution time: 0.0319
ERROR - 2023-10-14 17:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:29:09 --> Config Class Initialized
INFO - 2023-10-14 17:29:09 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:29:09 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:29:09 --> Utf8 Class Initialized
INFO - 2023-10-14 17:29:09 --> URI Class Initialized
INFO - 2023-10-14 17:29:09 --> Router Class Initialized
INFO - 2023-10-14 17:29:09 --> Output Class Initialized
INFO - 2023-10-14 17:29:09 --> Security Class Initialized
DEBUG - 2023-10-14 17:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:29:09 --> Input Class Initialized
INFO - 2023-10-14 17:29:09 --> Language Class Initialized
INFO - 2023-10-14 17:29:09 --> Loader Class Initialized
INFO - 2023-10-14 17:29:09 --> Helper loaded: url_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: file_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: html_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: text_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: form_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: security_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:29:09 --> Database Driver Class Initialized
INFO - 2023-10-14 17:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:29:09 --> Parser Class Initialized
INFO - 2023-10-14 17:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:29:09 --> Pagination Class Initialized
INFO - 2023-10-14 17:29:09 --> Form Validation Class Initialized
INFO - 2023-10-14 17:29:09 --> Controller Class Initialized
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
DEBUG - 2023-10-14 17:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
INFO - 2023-10-14 17:29:09 --> Final output sent to browser
DEBUG - 2023-10-14 17:29:09 --> Total execution time: 0.0167
ERROR - 2023-10-14 17:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:29:09 --> Config Class Initialized
INFO - 2023-10-14 17:29:09 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:29:09 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:29:09 --> Utf8 Class Initialized
INFO - 2023-10-14 17:29:09 --> URI Class Initialized
DEBUG - 2023-10-14 17:29:09 --> No URI present. Default controller set.
INFO - 2023-10-14 17:29:09 --> Router Class Initialized
INFO - 2023-10-14 17:29:09 --> Output Class Initialized
INFO - 2023-10-14 17:29:09 --> Security Class Initialized
DEBUG - 2023-10-14 17:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:29:09 --> Input Class Initialized
INFO - 2023-10-14 17:29:09 --> Language Class Initialized
INFO - 2023-10-14 17:29:09 --> Loader Class Initialized
INFO - 2023-10-14 17:29:09 --> Helper loaded: url_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: file_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: html_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: text_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: form_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: security_helper
INFO - 2023-10-14 17:29:09 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:29:09 --> Database Driver Class Initialized
INFO - 2023-10-14 17:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:29:09 --> Parser Class Initialized
INFO - 2023-10-14 17:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:29:09 --> Pagination Class Initialized
INFO - 2023-10-14 17:29:09 --> Form Validation Class Initialized
INFO - 2023-10-14 17:29:09 --> Controller Class Initialized
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
DEBUG - 2023-10-14 17:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
DEBUG - 2023-10-14 17:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
DEBUG - 2023-10-14 17:29:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
INFO - 2023-10-14 17:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 17:29:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:29:09 --> Model Class Initialized
INFO - 2023-10-14 17:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 17:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 17:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:29:09 --> Final output sent to browser
DEBUG - 2023-10-14 17:29:09 --> Total execution time: 0.3480
ERROR - 2023-10-14 17:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:29:10 --> Config Class Initialized
INFO - 2023-10-14 17:29:10 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:29:10 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:29:10 --> Utf8 Class Initialized
INFO - 2023-10-14 17:29:10 --> URI Class Initialized
INFO - 2023-10-14 17:29:10 --> Router Class Initialized
INFO - 2023-10-14 17:29:10 --> Output Class Initialized
INFO - 2023-10-14 17:29:10 --> Security Class Initialized
DEBUG - 2023-10-14 17:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:29:10 --> Input Class Initialized
INFO - 2023-10-14 17:29:10 --> Language Class Initialized
INFO - 2023-10-14 17:29:10 --> Loader Class Initialized
INFO - 2023-10-14 17:29:10 --> Helper loaded: url_helper
INFO - 2023-10-14 17:29:10 --> Helper loaded: file_helper
INFO - 2023-10-14 17:29:10 --> Helper loaded: html_helper
INFO - 2023-10-14 17:29:10 --> Helper loaded: text_helper
INFO - 2023-10-14 17:29:10 --> Helper loaded: form_helper
INFO - 2023-10-14 17:29:10 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:29:10 --> Helper loaded: security_helper
INFO - 2023-10-14 17:29:10 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:29:10 --> Database Driver Class Initialized
INFO - 2023-10-14 17:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:29:10 --> Parser Class Initialized
INFO - 2023-10-14 17:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:29:10 --> Pagination Class Initialized
INFO - 2023-10-14 17:29:10 --> Form Validation Class Initialized
INFO - 2023-10-14 17:29:10 --> Controller Class Initialized
DEBUG - 2023-10-14 17:29:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:29:10 --> Model Class Initialized
INFO - 2023-10-14 17:29:10 --> Final output sent to browser
DEBUG - 2023-10-14 17:29:10 --> Total execution time: 0.0130
ERROR - 2023-10-14 17:36:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:36:58 --> Config Class Initialized
INFO - 2023-10-14 17:36:58 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:36:58 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:36:58 --> Utf8 Class Initialized
INFO - 2023-10-14 17:36:58 --> URI Class Initialized
DEBUG - 2023-10-14 17:36:58 --> No URI present. Default controller set.
INFO - 2023-10-14 17:36:58 --> Router Class Initialized
INFO - 2023-10-14 17:36:58 --> Output Class Initialized
INFO - 2023-10-14 17:36:58 --> Security Class Initialized
DEBUG - 2023-10-14 17:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:36:58 --> Input Class Initialized
INFO - 2023-10-14 17:36:58 --> Language Class Initialized
INFO - 2023-10-14 17:36:58 --> Loader Class Initialized
INFO - 2023-10-14 17:36:58 --> Helper loaded: url_helper
INFO - 2023-10-14 17:36:58 --> Helper loaded: file_helper
INFO - 2023-10-14 17:36:58 --> Helper loaded: html_helper
INFO - 2023-10-14 17:36:58 --> Helper loaded: text_helper
INFO - 2023-10-14 17:36:58 --> Helper loaded: form_helper
INFO - 2023-10-14 17:36:58 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:36:58 --> Helper loaded: security_helper
INFO - 2023-10-14 17:36:58 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:36:58 --> Database Driver Class Initialized
INFO - 2023-10-14 17:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:36:58 --> Parser Class Initialized
INFO - 2023-10-14 17:36:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:36:58 --> Pagination Class Initialized
INFO - 2023-10-14 17:36:58 --> Form Validation Class Initialized
INFO - 2023-10-14 17:36:58 --> Controller Class Initialized
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
DEBUG - 2023-10-14 17:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
DEBUG - 2023-10-14 17:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
DEBUG - 2023-10-14 17:36:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
INFO - 2023-10-14 17:36:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 17:36:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:36:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:36:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:36:58 --> Model Class Initialized
INFO - 2023-10-14 17:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 17:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 17:36:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:36:59 --> Final output sent to browser
DEBUG - 2023-10-14 17:36:59 --> Total execution time: 0.3584
ERROR - 2023-10-14 17:37:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:37:13 --> Config Class Initialized
INFO - 2023-10-14 17:37:13 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:37:13 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:37:13 --> Utf8 Class Initialized
INFO - 2023-10-14 17:37:13 --> URI Class Initialized
DEBUG - 2023-10-14 17:37:13 --> No URI present. Default controller set.
INFO - 2023-10-14 17:37:13 --> Router Class Initialized
INFO - 2023-10-14 17:37:13 --> Output Class Initialized
INFO - 2023-10-14 17:37:13 --> Security Class Initialized
DEBUG - 2023-10-14 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:37:13 --> Input Class Initialized
INFO - 2023-10-14 17:37:13 --> Language Class Initialized
INFO - 2023-10-14 17:37:13 --> Loader Class Initialized
INFO - 2023-10-14 17:37:13 --> Helper loaded: url_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: file_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: html_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: text_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: form_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: security_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:37:13 --> Database Driver Class Initialized
INFO - 2023-10-14 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:37:13 --> Parser Class Initialized
INFO - 2023-10-14 17:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:37:13 --> Pagination Class Initialized
INFO - 2023-10-14 17:37:13 --> Form Validation Class Initialized
INFO - 2023-10-14 17:37:13 --> Controller Class Initialized
INFO - 2023-10-14 17:37:13 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-14 17:37:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:37:13 --> Config Class Initialized
INFO - 2023-10-14 17:37:13 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:37:13 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:37:13 --> Utf8 Class Initialized
INFO - 2023-10-14 17:37:13 --> URI Class Initialized
INFO - 2023-10-14 17:37:13 --> Router Class Initialized
INFO - 2023-10-14 17:37:13 --> Output Class Initialized
INFO - 2023-10-14 17:37:13 --> Security Class Initialized
DEBUG - 2023-10-14 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:37:13 --> Input Class Initialized
INFO - 2023-10-14 17:37:13 --> Language Class Initialized
INFO - 2023-10-14 17:37:13 --> Loader Class Initialized
INFO - 2023-10-14 17:37:13 --> Helper loaded: url_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: file_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: html_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: text_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: form_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: security_helper
INFO - 2023-10-14 17:37:13 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:37:13 --> Database Driver Class Initialized
INFO - 2023-10-14 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:37:13 --> Parser Class Initialized
INFO - 2023-10-14 17:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:37:13 --> Pagination Class Initialized
INFO - 2023-10-14 17:37:13 --> Form Validation Class Initialized
INFO - 2023-10-14 17:37:13 --> Controller Class Initialized
INFO - 2023-10-14 17:37:13 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-14 17:37:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:37:13 --> Model Class Initialized
INFO - 2023-10-14 17:37:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:37:13 --> Final output sent to browser
DEBUG - 2023-10-14 17:37:13 --> Total execution time: 0.0280
ERROR - 2023-10-14 17:37:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:37:17 --> Config Class Initialized
INFO - 2023-10-14 17:37:17 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:37:17 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:37:17 --> Utf8 Class Initialized
INFO - 2023-10-14 17:37:17 --> URI Class Initialized
INFO - 2023-10-14 17:37:17 --> Router Class Initialized
INFO - 2023-10-14 17:37:17 --> Output Class Initialized
INFO - 2023-10-14 17:37:17 --> Security Class Initialized
DEBUG - 2023-10-14 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:37:17 --> Input Class Initialized
INFO - 2023-10-14 17:37:17 --> Language Class Initialized
INFO - 2023-10-14 17:37:17 --> Loader Class Initialized
INFO - 2023-10-14 17:37:17 --> Helper loaded: url_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: file_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: html_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: text_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: form_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: security_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:37:17 --> Database Driver Class Initialized
INFO - 2023-10-14 17:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:37:17 --> Parser Class Initialized
INFO - 2023-10-14 17:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:37:17 --> Pagination Class Initialized
INFO - 2023-10-14 17:37:17 --> Form Validation Class Initialized
INFO - 2023-10-14 17:37:17 --> Controller Class Initialized
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
INFO - 2023-10-14 17:37:17 --> Final output sent to browser
DEBUG - 2023-10-14 17:37:17 --> Total execution time: 0.0177
ERROR - 2023-10-14 17:37:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:37:17 --> Config Class Initialized
INFO - 2023-10-14 17:37:17 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:37:17 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:37:17 --> Utf8 Class Initialized
INFO - 2023-10-14 17:37:17 --> URI Class Initialized
DEBUG - 2023-10-14 17:37:17 --> No URI present. Default controller set.
INFO - 2023-10-14 17:37:17 --> Router Class Initialized
INFO - 2023-10-14 17:37:17 --> Output Class Initialized
INFO - 2023-10-14 17:37:17 --> Security Class Initialized
DEBUG - 2023-10-14 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:37:17 --> Input Class Initialized
INFO - 2023-10-14 17:37:17 --> Language Class Initialized
INFO - 2023-10-14 17:37:17 --> Loader Class Initialized
INFO - 2023-10-14 17:37:17 --> Helper loaded: url_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: file_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: html_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: text_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: form_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: security_helper
INFO - 2023-10-14 17:37:17 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:37:17 --> Database Driver Class Initialized
INFO - 2023-10-14 17:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:37:17 --> Parser Class Initialized
INFO - 2023-10-14 17:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:37:17 --> Pagination Class Initialized
INFO - 2023-10-14 17:37:17 --> Form Validation Class Initialized
INFO - 2023-10-14 17:37:17 --> Controller Class Initialized
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
INFO - 2023-10-14 17:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-14 17:37:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:37:17 --> Model Class Initialized
INFO - 2023-10-14 17:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 17:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 17:37:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:37:17 --> Final output sent to browser
DEBUG - 2023-10-14 17:37:17 --> Total execution time: 0.1943
ERROR - 2023-10-14 17:37:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:37:25 --> Config Class Initialized
INFO - 2023-10-14 17:37:25 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:37:25 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:37:25 --> Utf8 Class Initialized
INFO - 2023-10-14 17:37:25 --> URI Class Initialized
INFO - 2023-10-14 17:37:25 --> Router Class Initialized
INFO - 2023-10-14 17:37:25 --> Output Class Initialized
INFO - 2023-10-14 17:37:25 --> Security Class Initialized
DEBUG - 2023-10-14 17:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:37:25 --> Input Class Initialized
INFO - 2023-10-14 17:37:25 --> Language Class Initialized
INFO - 2023-10-14 17:37:25 --> Loader Class Initialized
INFO - 2023-10-14 17:37:25 --> Helper loaded: url_helper
INFO - 2023-10-14 17:37:25 --> Helper loaded: file_helper
INFO - 2023-10-14 17:37:25 --> Helper loaded: html_helper
INFO - 2023-10-14 17:37:25 --> Helper loaded: text_helper
INFO - 2023-10-14 17:37:25 --> Helper loaded: form_helper
INFO - 2023-10-14 17:37:25 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:37:25 --> Helper loaded: security_helper
INFO - 2023-10-14 17:37:25 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:37:25 --> Database Driver Class Initialized
INFO - 2023-10-14 17:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:37:25 --> Parser Class Initialized
INFO - 2023-10-14 17:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:37:25 --> Pagination Class Initialized
INFO - 2023-10-14 17:37:25 --> Form Validation Class Initialized
INFO - 2023-10-14 17:37:25 --> Controller Class Initialized
INFO - 2023-10-14 17:37:25 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:25 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:25 --> Model Class Initialized
INFO - 2023-10-14 17:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-14 17:37:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-14 17:37:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-14 17:37:25 --> Model Class Initialized
INFO - 2023-10-14 17:37:25 --> Model Class Initialized
INFO - 2023-10-14 17:37:25 --> Model Class Initialized
INFO - 2023-10-14 17:37:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-14 17:37:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-14 17:37:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-14 17:37:26 --> Final output sent to browser
DEBUG - 2023-10-14 17:37:26 --> Total execution time: 0.1273
ERROR - 2023-10-14 17:37:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-14 17:37:26 --> Config Class Initialized
INFO - 2023-10-14 17:37:26 --> Hooks Class Initialized
DEBUG - 2023-10-14 17:37:26 --> UTF-8 Support Enabled
INFO - 2023-10-14 17:37:26 --> Utf8 Class Initialized
INFO - 2023-10-14 17:37:26 --> URI Class Initialized
INFO - 2023-10-14 17:37:26 --> Router Class Initialized
INFO - 2023-10-14 17:37:26 --> Output Class Initialized
INFO - 2023-10-14 17:37:26 --> Security Class Initialized
DEBUG - 2023-10-14 17:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-14 17:37:26 --> Input Class Initialized
INFO - 2023-10-14 17:37:26 --> Language Class Initialized
INFO - 2023-10-14 17:37:26 --> Loader Class Initialized
INFO - 2023-10-14 17:37:26 --> Helper loaded: url_helper
INFO - 2023-10-14 17:37:26 --> Helper loaded: file_helper
INFO - 2023-10-14 17:37:26 --> Helper loaded: html_helper
INFO - 2023-10-14 17:37:26 --> Helper loaded: text_helper
INFO - 2023-10-14 17:37:26 --> Helper loaded: form_helper
INFO - 2023-10-14 17:37:26 --> Helper loaded: lang_helper
INFO - 2023-10-14 17:37:26 --> Helper loaded: security_helper
INFO - 2023-10-14 17:37:26 --> Helper loaded: cookie_helper
INFO - 2023-10-14 17:37:26 --> Database Driver Class Initialized
INFO - 2023-10-14 17:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-14 17:37:26 --> Parser Class Initialized
INFO - 2023-10-14 17:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-14 17:37:26 --> Pagination Class Initialized
INFO - 2023-10-14 17:37:26 --> Form Validation Class Initialized
INFO - 2023-10-14 17:37:26 --> Controller Class Initialized
INFO - 2023-10-14 17:37:26 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-14 17:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:26 --> Model Class Initialized
DEBUG - 2023-10-14 17:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-14 17:37:26 --> Model Class Initialized
INFO - 2023-10-14 17:37:26 --> Final output sent to browser
DEBUG - 2023-10-14 17:37:26 --> Total execution time: 0.0371
