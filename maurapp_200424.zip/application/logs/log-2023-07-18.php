<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-18 06:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:25 --> Config Class Initialized
INFO - 2023-07-18 06:13:25 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:25 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:25 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:25 --> URI Class Initialized
DEBUG - 2023-07-18 06:13:25 --> No URI present. Default controller set.
INFO - 2023-07-18 06:13:25 --> Router Class Initialized
INFO - 2023-07-18 06:13:25 --> Output Class Initialized
INFO - 2023-07-18 06:13:25 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:25 --> Input Class Initialized
INFO - 2023-07-18 06:13:25 --> Language Class Initialized
INFO - 2023-07-18 06:13:25 --> Loader Class Initialized
INFO - 2023-07-18 06:13:25 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:25 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:25 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:25 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:25 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:25 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:25 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:25 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:25 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:25 --> Parser Class Initialized
INFO - 2023-07-18 06:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:25 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:25 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:25 --> Controller Class Initialized
INFO - 2023-07-18 06:13:25 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-18 06:13:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:26 --> Config Class Initialized
INFO - 2023-07-18 06:13:26 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:26 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:26 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:26 --> URI Class Initialized
INFO - 2023-07-18 06:13:26 --> Router Class Initialized
INFO - 2023-07-18 06:13:26 --> Output Class Initialized
INFO - 2023-07-18 06:13:26 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:26 --> Input Class Initialized
INFO - 2023-07-18 06:13:26 --> Language Class Initialized
INFO - 2023-07-18 06:13:26 --> Loader Class Initialized
INFO - 2023-07-18 06:13:26 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:26 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:26 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:26 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:26 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:26 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:26 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:26 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:26 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:26 --> Parser Class Initialized
INFO - 2023-07-18 06:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:26 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:26 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:26 --> Controller Class Initialized
INFO - 2023-07-18 06:13:26 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-18 06:13:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 06:13:26 --> Model Class Initialized
INFO - 2023-07-18 06:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 06:13:26 --> Final output sent to browser
DEBUG - 2023-07-18 06:13:26 --> Total execution time: 0.2028
ERROR - 2023-07-18 06:13:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:29 --> Config Class Initialized
INFO - 2023-07-18 06:13:29 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:29 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:29 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:29 --> URI Class Initialized
INFO - 2023-07-18 06:13:29 --> Router Class Initialized
INFO - 2023-07-18 06:13:29 --> Output Class Initialized
INFO - 2023-07-18 06:13:29 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:29 --> Input Class Initialized
INFO - 2023-07-18 06:13:29 --> Language Class Initialized
INFO - 2023-07-18 06:13:29 --> Loader Class Initialized
INFO - 2023-07-18 06:13:29 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:29 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:29 --> Parser Class Initialized
INFO - 2023-07-18 06:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:29 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:29 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:29 --> Controller Class Initialized
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
INFO - 2023-07-18 06:13:29 --> Final output sent to browser
DEBUG - 2023-07-18 06:13:29 --> Total execution time: 0.0186
ERROR - 2023-07-18 06:13:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:29 --> Config Class Initialized
INFO - 2023-07-18 06:13:29 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:29 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:29 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:29 --> URI Class Initialized
DEBUG - 2023-07-18 06:13:29 --> No URI present. Default controller set.
INFO - 2023-07-18 06:13:29 --> Router Class Initialized
INFO - 2023-07-18 06:13:29 --> Output Class Initialized
INFO - 2023-07-18 06:13:29 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:29 --> Input Class Initialized
INFO - 2023-07-18 06:13:29 --> Language Class Initialized
INFO - 2023-07-18 06:13:29 --> Loader Class Initialized
INFO - 2023-07-18 06:13:29 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:29 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:29 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:29 --> Parser Class Initialized
INFO - 2023-07-18 06:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:29 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:29 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:29 --> Controller Class Initialized
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
INFO - 2023-07-18 06:13:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 06:13:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 06:13:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 06:13:29 --> Model Class Initialized
INFO - 2023-07-18 06:13:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 06:13:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 06:13:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 06:13:29 --> Final output sent to browser
DEBUG - 2023-07-18 06:13:29 --> Total execution time: 0.1749
ERROR - 2023-07-18 06:13:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:30 --> Config Class Initialized
INFO - 2023-07-18 06:13:30 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:30 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:30 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:30 --> URI Class Initialized
INFO - 2023-07-18 06:13:30 --> Router Class Initialized
INFO - 2023-07-18 06:13:30 --> Output Class Initialized
INFO - 2023-07-18 06:13:30 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:30 --> Input Class Initialized
INFO - 2023-07-18 06:13:30 --> Language Class Initialized
INFO - 2023-07-18 06:13:30 --> Loader Class Initialized
INFO - 2023-07-18 06:13:30 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:30 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:30 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:30 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:30 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:30 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:30 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:30 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:30 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:30 --> Parser Class Initialized
INFO - 2023-07-18 06:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:30 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:30 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:30 --> Controller Class Initialized
DEBUG - 2023-07-18 06:13:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:30 --> Model Class Initialized
INFO - 2023-07-18 06:13:30 --> Final output sent to browser
DEBUG - 2023-07-18 06:13:30 --> Total execution time: 0.0134
ERROR - 2023-07-18 06:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:40 --> Config Class Initialized
INFO - 2023-07-18 06:13:40 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:40 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:40 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:40 --> URI Class Initialized
INFO - 2023-07-18 06:13:40 --> Router Class Initialized
INFO - 2023-07-18 06:13:40 --> Output Class Initialized
INFO - 2023-07-18 06:13:40 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:40 --> Input Class Initialized
INFO - 2023-07-18 06:13:40 --> Language Class Initialized
INFO - 2023-07-18 06:13:40 --> Loader Class Initialized
INFO - 2023-07-18 06:13:40 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:40 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:40 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:40 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:40 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:40 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:40 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:40 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:40 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:40 --> Parser Class Initialized
INFO - 2023-07-18 06:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:40 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:40 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:40 --> Controller Class Initialized
INFO - 2023-07-18 06:13:40 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:40 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:40 --> Model Class Initialized
INFO - 2023-07-18 06:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-18 06:13:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 06:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 06:13:40 --> Model Class Initialized
INFO - 2023-07-18 06:13:40 --> Model Class Initialized
INFO - 2023-07-18 06:13:40 --> Model Class Initialized
INFO - 2023-07-18 06:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 06:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 06:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 06:13:40 --> Final output sent to browser
DEBUG - 2023-07-18 06:13:40 --> Total execution time: 0.1304
ERROR - 2023-07-18 06:13:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:41 --> Config Class Initialized
INFO - 2023-07-18 06:13:41 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:41 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:41 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:41 --> URI Class Initialized
INFO - 2023-07-18 06:13:41 --> Router Class Initialized
INFO - 2023-07-18 06:13:41 --> Output Class Initialized
INFO - 2023-07-18 06:13:41 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:41 --> Input Class Initialized
INFO - 2023-07-18 06:13:41 --> Language Class Initialized
INFO - 2023-07-18 06:13:41 --> Loader Class Initialized
INFO - 2023-07-18 06:13:41 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:41 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:41 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:41 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:41 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:41 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:41 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:41 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:41 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:41 --> Parser Class Initialized
INFO - 2023-07-18 06:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:41 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:41 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:41 --> Controller Class Initialized
INFO - 2023-07-18 06:13:41 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:41 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:41 --> Model Class Initialized
INFO - 2023-07-18 06:13:41 --> Final output sent to browser
DEBUG - 2023-07-18 06:13:41 --> Total execution time: 0.0567
ERROR - 2023-07-18 06:13:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:13:46 --> Config Class Initialized
INFO - 2023-07-18 06:13:46 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:13:46 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:13:46 --> Utf8 Class Initialized
INFO - 2023-07-18 06:13:46 --> URI Class Initialized
INFO - 2023-07-18 06:13:46 --> Router Class Initialized
INFO - 2023-07-18 06:13:46 --> Output Class Initialized
INFO - 2023-07-18 06:13:46 --> Security Class Initialized
DEBUG - 2023-07-18 06:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:13:46 --> Input Class Initialized
INFO - 2023-07-18 06:13:46 --> Language Class Initialized
INFO - 2023-07-18 06:13:46 --> Loader Class Initialized
INFO - 2023-07-18 06:13:46 --> Helper loaded: url_helper
INFO - 2023-07-18 06:13:46 --> Helper loaded: file_helper
INFO - 2023-07-18 06:13:46 --> Helper loaded: html_helper
INFO - 2023-07-18 06:13:46 --> Helper loaded: text_helper
INFO - 2023-07-18 06:13:46 --> Helper loaded: form_helper
INFO - 2023-07-18 06:13:46 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:13:46 --> Helper loaded: security_helper
INFO - 2023-07-18 06:13:46 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:13:46 --> Database Driver Class Initialized
INFO - 2023-07-18 06:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:13:46 --> Parser Class Initialized
INFO - 2023-07-18 06:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:13:46 --> Pagination Class Initialized
INFO - 2023-07-18 06:13:46 --> Form Validation Class Initialized
INFO - 2023-07-18 06:13:46 --> Controller Class Initialized
INFO - 2023-07-18 06:13:46 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:46 --> Model Class Initialized
DEBUG - 2023-07-18 06:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:13:46 --> Model Class Initialized
INFO - 2023-07-18 06:13:47 --> Final output sent to browser
DEBUG - 2023-07-18 06:13:47 --> Total execution time: 0.3319
ERROR - 2023-07-18 06:14:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:14:45 --> Config Class Initialized
INFO - 2023-07-18 06:14:45 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:14:45 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:14:45 --> Utf8 Class Initialized
INFO - 2023-07-18 06:14:45 --> URI Class Initialized
INFO - 2023-07-18 06:14:45 --> Router Class Initialized
INFO - 2023-07-18 06:14:45 --> Output Class Initialized
INFO - 2023-07-18 06:14:45 --> Security Class Initialized
DEBUG - 2023-07-18 06:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:14:45 --> Input Class Initialized
INFO - 2023-07-18 06:14:45 --> Language Class Initialized
INFO - 2023-07-18 06:14:45 --> Loader Class Initialized
INFO - 2023-07-18 06:14:45 --> Helper loaded: url_helper
INFO - 2023-07-18 06:14:45 --> Helper loaded: file_helper
INFO - 2023-07-18 06:14:45 --> Helper loaded: html_helper
INFO - 2023-07-18 06:14:45 --> Helper loaded: text_helper
INFO - 2023-07-18 06:14:45 --> Helper loaded: form_helper
INFO - 2023-07-18 06:14:45 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:14:45 --> Helper loaded: security_helper
INFO - 2023-07-18 06:14:45 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:14:45 --> Database Driver Class Initialized
INFO - 2023-07-18 06:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:14:45 --> Parser Class Initialized
INFO - 2023-07-18 06:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:14:45 --> Pagination Class Initialized
INFO - 2023-07-18 06:14:45 --> Form Validation Class Initialized
INFO - 2023-07-18 06:14:45 --> Controller Class Initialized
INFO - 2023-07-18 06:14:45 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:45 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:45 --> Model Class Initialized
INFO - 2023-07-18 06:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-18 06:14:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 06:14:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 06:14:45 --> Model Class Initialized
INFO - 2023-07-18 06:14:45 --> Model Class Initialized
INFO - 2023-07-18 06:14:45 --> Model Class Initialized
INFO - 2023-07-18 06:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 06:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 06:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 06:14:46 --> Final output sent to browser
DEBUG - 2023-07-18 06:14:46 --> Total execution time: 0.1374
ERROR - 2023-07-18 06:14:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:14:46 --> Config Class Initialized
INFO - 2023-07-18 06:14:46 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:14:46 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:14:46 --> Utf8 Class Initialized
INFO - 2023-07-18 06:14:46 --> URI Class Initialized
INFO - 2023-07-18 06:14:46 --> Router Class Initialized
INFO - 2023-07-18 06:14:46 --> Output Class Initialized
INFO - 2023-07-18 06:14:46 --> Security Class Initialized
DEBUG - 2023-07-18 06:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:14:46 --> Input Class Initialized
INFO - 2023-07-18 06:14:46 --> Language Class Initialized
INFO - 2023-07-18 06:14:46 --> Loader Class Initialized
INFO - 2023-07-18 06:14:46 --> Helper loaded: url_helper
INFO - 2023-07-18 06:14:46 --> Helper loaded: file_helper
INFO - 2023-07-18 06:14:46 --> Helper loaded: html_helper
INFO - 2023-07-18 06:14:46 --> Helper loaded: text_helper
INFO - 2023-07-18 06:14:46 --> Helper loaded: form_helper
INFO - 2023-07-18 06:14:46 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:14:46 --> Helper loaded: security_helper
INFO - 2023-07-18 06:14:46 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:14:46 --> Database Driver Class Initialized
INFO - 2023-07-18 06:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:14:46 --> Parser Class Initialized
INFO - 2023-07-18 06:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:14:46 --> Pagination Class Initialized
INFO - 2023-07-18 06:14:46 --> Form Validation Class Initialized
INFO - 2023-07-18 06:14:46 --> Controller Class Initialized
INFO - 2023-07-18 06:14:46 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:46 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:46 --> Model Class Initialized
INFO - 2023-07-18 06:14:46 --> Final output sent to browser
DEBUG - 2023-07-18 06:14:46 --> Total execution time: 0.0655
ERROR - 2023-07-18 06:14:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:14:49 --> Config Class Initialized
INFO - 2023-07-18 06:14:49 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:14:49 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:14:49 --> Utf8 Class Initialized
INFO - 2023-07-18 06:14:49 --> URI Class Initialized
INFO - 2023-07-18 06:14:49 --> Router Class Initialized
INFO - 2023-07-18 06:14:49 --> Output Class Initialized
INFO - 2023-07-18 06:14:49 --> Security Class Initialized
DEBUG - 2023-07-18 06:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:14:49 --> Input Class Initialized
INFO - 2023-07-18 06:14:49 --> Language Class Initialized
INFO - 2023-07-18 06:14:49 --> Loader Class Initialized
INFO - 2023-07-18 06:14:49 --> Helper loaded: url_helper
INFO - 2023-07-18 06:14:49 --> Helper loaded: file_helper
INFO - 2023-07-18 06:14:49 --> Helper loaded: html_helper
INFO - 2023-07-18 06:14:49 --> Helper loaded: text_helper
INFO - 2023-07-18 06:14:49 --> Helper loaded: form_helper
INFO - 2023-07-18 06:14:49 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:14:49 --> Helper loaded: security_helper
INFO - 2023-07-18 06:14:49 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:14:49 --> Database Driver Class Initialized
INFO - 2023-07-18 06:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:14:49 --> Parser Class Initialized
INFO - 2023-07-18 06:14:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:14:49 --> Pagination Class Initialized
INFO - 2023-07-18 06:14:49 --> Form Validation Class Initialized
INFO - 2023-07-18 06:14:49 --> Controller Class Initialized
INFO - 2023-07-18 06:14:49 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:49 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:49 --> Model Class Initialized
INFO - 2023-07-18 06:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-18 06:14:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 06:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 06:14:49 --> Model Class Initialized
INFO - 2023-07-18 06:14:49 --> Model Class Initialized
INFO - 2023-07-18 06:14:49 --> Model Class Initialized
INFO - 2023-07-18 06:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 06:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 06:14:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 06:14:49 --> Final output sent to browser
DEBUG - 2023-07-18 06:14:49 --> Total execution time: 0.1467
ERROR - 2023-07-18 06:14:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:14:50 --> Config Class Initialized
INFO - 2023-07-18 06:14:50 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:14:50 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:14:50 --> Utf8 Class Initialized
INFO - 2023-07-18 06:14:50 --> URI Class Initialized
INFO - 2023-07-18 06:14:50 --> Router Class Initialized
INFO - 2023-07-18 06:14:50 --> Output Class Initialized
INFO - 2023-07-18 06:14:50 --> Security Class Initialized
DEBUG - 2023-07-18 06:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:14:50 --> Input Class Initialized
INFO - 2023-07-18 06:14:50 --> Language Class Initialized
INFO - 2023-07-18 06:14:50 --> Loader Class Initialized
INFO - 2023-07-18 06:14:50 --> Helper loaded: url_helper
INFO - 2023-07-18 06:14:50 --> Helper loaded: file_helper
INFO - 2023-07-18 06:14:50 --> Helper loaded: html_helper
INFO - 2023-07-18 06:14:50 --> Helper loaded: text_helper
INFO - 2023-07-18 06:14:50 --> Helper loaded: form_helper
INFO - 2023-07-18 06:14:50 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:14:50 --> Helper loaded: security_helper
INFO - 2023-07-18 06:14:50 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:14:50 --> Database Driver Class Initialized
INFO - 2023-07-18 06:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:14:50 --> Parser Class Initialized
INFO - 2023-07-18 06:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:14:50 --> Pagination Class Initialized
INFO - 2023-07-18 06:14:50 --> Form Validation Class Initialized
INFO - 2023-07-18 06:14:50 --> Controller Class Initialized
INFO - 2023-07-18 06:14:50 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:50 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:50 --> Model Class Initialized
INFO - 2023-07-18 06:14:50 --> Final output sent to browser
DEBUG - 2023-07-18 06:14:50 --> Total execution time: 0.0494
ERROR - 2023-07-18 06:14:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:14:53 --> Config Class Initialized
INFO - 2023-07-18 06:14:53 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:14:53 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:14:53 --> Utf8 Class Initialized
INFO - 2023-07-18 06:14:53 --> URI Class Initialized
INFO - 2023-07-18 06:14:53 --> Router Class Initialized
INFO - 2023-07-18 06:14:53 --> Output Class Initialized
INFO - 2023-07-18 06:14:53 --> Security Class Initialized
DEBUG - 2023-07-18 06:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:14:53 --> Input Class Initialized
INFO - 2023-07-18 06:14:53 --> Language Class Initialized
INFO - 2023-07-18 06:14:53 --> Loader Class Initialized
INFO - 2023-07-18 06:14:53 --> Helper loaded: url_helper
INFO - 2023-07-18 06:14:53 --> Helper loaded: file_helper
INFO - 2023-07-18 06:14:53 --> Helper loaded: html_helper
INFO - 2023-07-18 06:14:53 --> Helper loaded: text_helper
INFO - 2023-07-18 06:14:53 --> Helper loaded: form_helper
INFO - 2023-07-18 06:14:53 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:14:53 --> Helper loaded: security_helper
INFO - 2023-07-18 06:14:53 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:14:53 --> Database Driver Class Initialized
INFO - 2023-07-18 06:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:14:53 --> Parser Class Initialized
INFO - 2023-07-18 06:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:14:53 --> Pagination Class Initialized
INFO - 2023-07-18 06:14:53 --> Form Validation Class Initialized
INFO - 2023-07-18 06:14:53 --> Controller Class Initialized
INFO - 2023-07-18 06:14:53 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:53 --> Model Class Initialized
DEBUG - 2023-07-18 06:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:14:53 --> Model Class Initialized
INFO - 2023-07-18 06:14:53 --> Final output sent to browser
DEBUG - 2023-07-18 06:14:53 --> Total execution time: 0.0636
ERROR - 2023-07-18 06:55:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 06:55:29 --> Config Class Initialized
INFO - 2023-07-18 06:55:29 --> Hooks Class Initialized
DEBUG - 2023-07-18 06:55:29 --> UTF-8 Support Enabled
INFO - 2023-07-18 06:55:29 --> Utf8 Class Initialized
INFO - 2023-07-18 06:55:29 --> URI Class Initialized
DEBUG - 2023-07-18 06:55:29 --> No URI present. Default controller set.
INFO - 2023-07-18 06:55:29 --> Router Class Initialized
INFO - 2023-07-18 06:55:29 --> Output Class Initialized
INFO - 2023-07-18 06:55:29 --> Security Class Initialized
DEBUG - 2023-07-18 06:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 06:55:29 --> Input Class Initialized
INFO - 2023-07-18 06:55:29 --> Language Class Initialized
INFO - 2023-07-18 06:55:29 --> Loader Class Initialized
INFO - 2023-07-18 06:55:29 --> Helper loaded: url_helper
INFO - 2023-07-18 06:55:29 --> Helper loaded: file_helper
INFO - 2023-07-18 06:55:29 --> Helper loaded: html_helper
INFO - 2023-07-18 06:55:29 --> Helper loaded: text_helper
INFO - 2023-07-18 06:55:29 --> Helper loaded: form_helper
INFO - 2023-07-18 06:55:29 --> Helper loaded: lang_helper
INFO - 2023-07-18 06:55:29 --> Helper loaded: security_helper
INFO - 2023-07-18 06:55:29 --> Helper loaded: cookie_helper
INFO - 2023-07-18 06:55:29 --> Database Driver Class Initialized
INFO - 2023-07-18 06:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 06:55:29 --> Parser Class Initialized
INFO - 2023-07-18 06:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 06:55:29 --> Pagination Class Initialized
INFO - 2023-07-18 06:55:29 --> Form Validation Class Initialized
INFO - 2023-07-18 06:55:29 --> Controller Class Initialized
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
DEBUG - 2023-07-18 06:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
DEBUG - 2023-07-18 06:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
DEBUG - 2023-07-18 06:55:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 06:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
INFO - 2023-07-18 06:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 06:55:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 06:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 06:55:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 06:55:29 --> Model Class Initialized
INFO - 2023-07-18 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 06:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 06:55:30 --> Final output sent to browser
DEBUG - 2023-07-18 06:55:30 --> Total execution time: 0.1761
ERROR - 2023-07-18 08:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:14:26 --> Config Class Initialized
INFO - 2023-07-18 08:14:26 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:14:26 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:14:26 --> Utf8 Class Initialized
INFO - 2023-07-18 08:14:26 --> URI Class Initialized
DEBUG - 2023-07-18 08:14:26 --> No URI present. Default controller set.
INFO - 2023-07-18 08:14:26 --> Router Class Initialized
INFO - 2023-07-18 08:14:26 --> Output Class Initialized
INFO - 2023-07-18 08:14:26 --> Security Class Initialized
DEBUG - 2023-07-18 08:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:14:26 --> Input Class Initialized
INFO - 2023-07-18 08:14:26 --> Language Class Initialized
INFO - 2023-07-18 08:14:26 --> Loader Class Initialized
INFO - 2023-07-18 08:14:26 --> Helper loaded: url_helper
INFO - 2023-07-18 08:14:26 --> Helper loaded: file_helper
INFO - 2023-07-18 08:14:26 --> Helper loaded: html_helper
INFO - 2023-07-18 08:14:26 --> Helper loaded: text_helper
INFO - 2023-07-18 08:14:26 --> Helper loaded: form_helper
INFO - 2023-07-18 08:14:26 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:14:26 --> Helper loaded: security_helper
INFO - 2023-07-18 08:14:26 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:14:26 --> Database Driver Class Initialized
INFO - 2023-07-18 08:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:14:26 --> Parser Class Initialized
INFO - 2023-07-18 08:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:14:26 --> Pagination Class Initialized
INFO - 2023-07-18 08:14:26 --> Form Validation Class Initialized
INFO - 2023-07-18 08:14:26 --> Controller Class Initialized
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
DEBUG - 2023-07-18 08:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
DEBUG - 2023-07-18 08:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
DEBUG - 2023-07-18 08:14:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
INFO - 2023-07-18 08:14:26 --> Model Class Initialized
INFO - 2023-07-18 08:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 08:14:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:14:27 --> Model Class Initialized
INFO - 2023-07-18 08:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:14:27 --> Final output sent to browser
DEBUG - 2023-07-18 08:14:27 --> Total execution time: 0.1738
ERROR - 2023-07-18 08:15:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:08 --> Config Class Initialized
INFO - 2023-07-18 08:15:08 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:08 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:08 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:08 --> URI Class Initialized
DEBUG - 2023-07-18 08:15:08 --> No URI present. Default controller set.
INFO - 2023-07-18 08:15:08 --> Router Class Initialized
INFO - 2023-07-18 08:15:08 --> Output Class Initialized
INFO - 2023-07-18 08:15:08 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:08 --> Input Class Initialized
INFO - 2023-07-18 08:15:08 --> Language Class Initialized
INFO - 2023-07-18 08:15:08 --> Loader Class Initialized
INFO - 2023-07-18 08:15:08 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:08 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:08 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:08 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:08 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:08 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:08 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:08 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:08 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:08 --> Parser Class Initialized
INFO - 2023-07-18 08:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:08 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:08 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:08 --> Controller Class Initialized
INFO - 2023-07-18 08:15:08 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-18 08:15:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:09 --> Config Class Initialized
INFO - 2023-07-18 08:15:09 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:09 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:09 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:09 --> URI Class Initialized
INFO - 2023-07-18 08:15:09 --> Router Class Initialized
INFO - 2023-07-18 08:15:09 --> Output Class Initialized
INFO - 2023-07-18 08:15:09 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:09 --> Input Class Initialized
INFO - 2023-07-18 08:15:09 --> Language Class Initialized
INFO - 2023-07-18 08:15:09 --> Loader Class Initialized
INFO - 2023-07-18 08:15:09 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:09 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:09 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:09 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:09 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:09 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:09 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:09 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:09 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:09 --> Parser Class Initialized
INFO - 2023-07-18 08:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:09 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:09 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:09 --> Controller Class Initialized
INFO - 2023-07-18 08:15:09 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-18 08:15:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:15:09 --> Model Class Initialized
INFO - 2023-07-18 08:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:15:09 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:09 --> Total execution time: 0.0300
ERROR - 2023-07-18 08:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:13 --> Config Class Initialized
INFO - 2023-07-18 08:15:13 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:13 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:13 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:13 --> URI Class Initialized
INFO - 2023-07-18 08:15:13 --> Router Class Initialized
INFO - 2023-07-18 08:15:13 --> Output Class Initialized
INFO - 2023-07-18 08:15:13 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:13 --> Input Class Initialized
INFO - 2023-07-18 08:15:13 --> Language Class Initialized
INFO - 2023-07-18 08:15:13 --> Loader Class Initialized
INFO - 2023-07-18 08:15:13 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:13 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:13 --> Parser Class Initialized
INFO - 2023-07-18 08:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:13 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:13 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:13 --> Controller Class Initialized
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
INFO - 2023-07-18 08:15:13 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:13 --> Total execution time: 0.0196
ERROR - 2023-07-18 08:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:13 --> Config Class Initialized
INFO - 2023-07-18 08:15:13 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:13 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:13 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:13 --> URI Class Initialized
DEBUG - 2023-07-18 08:15:13 --> No URI present. Default controller set.
INFO - 2023-07-18 08:15:13 --> Router Class Initialized
INFO - 2023-07-18 08:15:13 --> Output Class Initialized
INFO - 2023-07-18 08:15:13 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:13 --> Input Class Initialized
INFO - 2023-07-18 08:15:13 --> Language Class Initialized
INFO - 2023-07-18 08:15:13 --> Loader Class Initialized
INFO - 2023-07-18 08:15:13 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:13 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:13 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:13 --> Parser Class Initialized
INFO - 2023-07-18 08:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:13 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:13 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:13 --> Controller Class Initialized
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
INFO - 2023-07-18 08:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 08:15:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:15:13 --> Model Class Initialized
INFO - 2023-07-18 08:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:15:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:15:13 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:13 --> Total execution time: 0.0842
ERROR - 2023-07-18 08:15:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:24 --> Config Class Initialized
INFO - 2023-07-18 08:15:24 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:24 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:24 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:24 --> URI Class Initialized
INFO - 2023-07-18 08:15:24 --> Router Class Initialized
INFO - 2023-07-18 08:15:24 --> Output Class Initialized
INFO - 2023-07-18 08:15:24 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:24 --> Input Class Initialized
INFO - 2023-07-18 08:15:24 --> Language Class Initialized
INFO - 2023-07-18 08:15:24 --> Loader Class Initialized
INFO - 2023-07-18 08:15:24 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:24 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:24 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:24 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:24 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:24 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:24 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:24 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:24 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:24 --> Parser Class Initialized
INFO - 2023-07-18 08:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:24 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:24 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:24 --> Controller Class Initialized
INFO - 2023-07-18 08:15:24 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:24 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:24 --> Model Class Initialized
INFO - 2023-07-18 08:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-18 08:15:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:15:24 --> Model Class Initialized
INFO - 2023-07-18 08:15:24 --> Model Class Initialized
INFO - 2023-07-18 08:15:24 --> Model Class Initialized
INFO - 2023-07-18 08:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:15:24 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:24 --> Total execution time: 0.1342
ERROR - 2023-07-18 08:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:25 --> Config Class Initialized
INFO - 2023-07-18 08:15:25 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:25 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:25 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:25 --> URI Class Initialized
INFO - 2023-07-18 08:15:25 --> Router Class Initialized
INFO - 2023-07-18 08:15:25 --> Output Class Initialized
INFO - 2023-07-18 08:15:25 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:25 --> Input Class Initialized
INFO - 2023-07-18 08:15:25 --> Language Class Initialized
INFO - 2023-07-18 08:15:25 --> Loader Class Initialized
INFO - 2023-07-18 08:15:25 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:25 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:25 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:25 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:25 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:25 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:25 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:25 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:25 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:25 --> Parser Class Initialized
INFO - 2023-07-18 08:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:25 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:25 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:25 --> Controller Class Initialized
INFO - 2023-07-18 08:15:25 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:25 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:25 --> Model Class Initialized
INFO - 2023-07-18 08:15:25 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:25 --> Total execution time: 0.0426
ERROR - 2023-07-18 08:15:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:48 --> Config Class Initialized
INFO - 2023-07-18 08:15:48 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:48 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:48 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:48 --> URI Class Initialized
INFO - 2023-07-18 08:15:48 --> Router Class Initialized
INFO - 2023-07-18 08:15:48 --> Output Class Initialized
INFO - 2023-07-18 08:15:48 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:48 --> Input Class Initialized
INFO - 2023-07-18 08:15:48 --> Language Class Initialized
INFO - 2023-07-18 08:15:48 --> Loader Class Initialized
INFO - 2023-07-18 08:15:48 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:48 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:48 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:48 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:48 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:48 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:48 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:48 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:48 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:48 --> Parser Class Initialized
INFO - 2023-07-18 08:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:48 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:48 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:48 --> Controller Class Initialized
INFO - 2023-07-18 08:15:48 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:48 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:48 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-18 08:15:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:15:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:15:48 --> Model Class Initialized
INFO - 2023-07-18 08:15:48 --> Model Class Initialized
INFO - 2023-07-18 08:15:48 --> Model Class Initialized
INFO - 2023-07-18 08:15:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:15:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:15:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:15:48 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:48 --> Total execution time: 0.0993
ERROR - 2023-07-18 08:15:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:57 --> Config Class Initialized
INFO - 2023-07-18 08:15:57 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:57 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:57 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:57 --> URI Class Initialized
INFO - 2023-07-18 08:15:57 --> Router Class Initialized
INFO - 2023-07-18 08:15:57 --> Output Class Initialized
INFO - 2023-07-18 08:15:57 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:57 --> Input Class Initialized
INFO - 2023-07-18 08:15:57 --> Language Class Initialized
INFO - 2023-07-18 08:15:57 --> Loader Class Initialized
INFO - 2023-07-18 08:15:57 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:57 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:57 --> Parser Class Initialized
INFO - 2023-07-18 08:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:57 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:57 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:57 --> Controller Class Initialized
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
INFO - 2023-07-18 08:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-18 08:15:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
INFO - 2023-07-18 08:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:15:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:15:57 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:57 --> Total execution time: 0.0809
ERROR - 2023-07-18 08:15:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:15:57 --> Config Class Initialized
INFO - 2023-07-18 08:15:57 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:15:57 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:15:57 --> Utf8 Class Initialized
INFO - 2023-07-18 08:15:57 --> URI Class Initialized
INFO - 2023-07-18 08:15:57 --> Router Class Initialized
INFO - 2023-07-18 08:15:57 --> Output Class Initialized
INFO - 2023-07-18 08:15:57 --> Security Class Initialized
DEBUG - 2023-07-18 08:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:15:57 --> Input Class Initialized
INFO - 2023-07-18 08:15:57 --> Language Class Initialized
INFO - 2023-07-18 08:15:57 --> Loader Class Initialized
INFO - 2023-07-18 08:15:57 --> Helper loaded: url_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: file_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: html_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: text_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: form_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: security_helper
INFO - 2023-07-18 08:15:57 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:15:57 --> Database Driver Class Initialized
INFO - 2023-07-18 08:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:15:57 --> Parser Class Initialized
INFO - 2023-07-18 08:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:15:57 --> Pagination Class Initialized
INFO - 2023-07-18 08:15:57 --> Form Validation Class Initialized
INFO - 2023-07-18 08:15:57 --> Controller Class Initialized
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
DEBUG - 2023-07-18 08:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:15:57 --> Model Class Initialized
INFO - 2023-07-18 08:15:57 --> Final output sent to browser
DEBUG - 2023-07-18 08:15:57 --> Total execution time: 0.0363
ERROR - 2023-07-18 08:16:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:16:02 --> Config Class Initialized
INFO - 2023-07-18 08:16:02 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:16:02 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:16:02 --> Utf8 Class Initialized
INFO - 2023-07-18 08:16:02 --> URI Class Initialized
INFO - 2023-07-18 08:16:02 --> Router Class Initialized
INFO - 2023-07-18 08:16:02 --> Output Class Initialized
INFO - 2023-07-18 08:16:02 --> Security Class Initialized
DEBUG - 2023-07-18 08:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:16:02 --> Input Class Initialized
INFO - 2023-07-18 08:16:02 --> Language Class Initialized
INFO - 2023-07-18 08:16:02 --> Loader Class Initialized
INFO - 2023-07-18 08:16:02 --> Helper loaded: url_helper
INFO - 2023-07-18 08:16:02 --> Helper loaded: file_helper
INFO - 2023-07-18 08:16:02 --> Helper loaded: html_helper
INFO - 2023-07-18 08:16:02 --> Helper loaded: text_helper
INFO - 2023-07-18 08:16:02 --> Helper loaded: form_helper
INFO - 2023-07-18 08:16:02 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:16:02 --> Helper loaded: security_helper
INFO - 2023-07-18 08:16:02 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:16:02 --> Database Driver Class Initialized
INFO - 2023-07-18 08:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:16:02 --> Parser Class Initialized
INFO - 2023-07-18 08:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:16:02 --> Pagination Class Initialized
INFO - 2023-07-18 08:16:02 --> Form Validation Class Initialized
INFO - 2023-07-18 08:16:02 --> Controller Class Initialized
INFO - 2023-07-18 08:16:02 --> Model Class Initialized
DEBUG - 2023-07-18 08:16:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:16:02 --> Model Class Initialized
DEBUG - 2023-07-18 08:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:16:02 --> Model Class Initialized
INFO - 2023-07-18 08:16:02 --> Final output sent to browser
DEBUG - 2023-07-18 08:16:02 --> Total execution time: 0.0536
ERROR - 2023-07-18 08:40:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:40:52 --> Config Class Initialized
INFO - 2023-07-18 08:40:52 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:40:52 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:40:52 --> Utf8 Class Initialized
INFO - 2023-07-18 08:40:52 --> URI Class Initialized
DEBUG - 2023-07-18 08:40:52 --> No URI present. Default controller set.
INFO - 2023-07-18 08:40:52 --> Router Class Initialized
INFO - 2023-07-18 08:40:52 --> Output Class Initialized
INFO - 2023-07-18 08:40:52 --> Security Class Initialized
DEBUG - 2023-07-18 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:40:52 --> Input Class Initialized
INFO - 2023-07-18 08:40:52 --> Language Class Initialized
INFO - 2023-07-18 08:40:52 --> Loader Class Initialized
INFO - 2023-07-18 08:40:52 --> Helper loaded: url_helper
INFO - 2023-07-18 08:40:52 --> Helper loaded: file_helper
INFO - 2023-07-18 08:40:52 --> Helper loaded: html_helper
INFO - 2023-07-18 08:40:52 --> Helper loaded: text_helper
INFO - 2023-07-18 08:40:52 --> Helper loaded: form_helper
INFO - 2023-07-18 08:40:52 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:40:52 --> Helper loaded: security_helper
INFO - 2023-07-18 08:40:52 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:40:52 --> Database Driver Class Initialized
INFO - 2023-07-18 08:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:40:52 --> Parser Class Initialized
INFO - 2023-07-18 08:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:40:52 --> Pagination Class Initialized
INFO - 2023-07-18 08:40:52 --> Form Validation Class Initialized
INFO - 2023-07-18 08:40:52 --> Controller Class Initialized
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
DEBUG - 2023-07-18 08:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
DEBUG - 2023-07-18 08:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
DEBUG - 2023-07-18 08:40:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
INFO - 2023-07-18 08:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 08:40:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:40:52 --> Model Class Initialized
INFO - 2023-07-18 08:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:40:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:40:52 --> Final output sent to browser
DEBUG - 2023-07-18 08:40:52 --> Total execution time: 0.1892
ERROR - 2023-07-18 08:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:40:57 --> Config Class Initialized
INFO - 2023-07-18 08:40:57 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:40:57 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:40:57 --> Utf8 Class Initialized
INFO - 2023-07-18 08:40:57 --> URI Class Initialized
DEBUG - 2023-07-18 08:40:57 --> No URI present. Default controller set.
INFO - 2023-07-18 08:40:57 --> Router Class Initialized
INFO - 2023-07-18 08:40:57 --> Output Class Initialized
INFO - 2023-07-18 08:40:57 --> Security Class Initialized
DEBUG - 2023-07-18 08:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:40:57 --> Input Class Initialized
INFO - 2023-07-18 08:40:57 --> Language Class Initialized
INFO - 2023-07-18 08:40:57 --> Loader Class Initialized
INFO - 2023-07-18 08:40:57 --> Helper loaded: url_helper
INFO - 2023-07-18 08:40:57 --> Helper loaded: file_helper
INFO - 2023-07-18 08:40:57 --> Helper loaded: html_helper
INFO - 2023-07-18 08:40:57 --> Helper loaded: text_helper
INFO - 2023-07-18 08:40:57 --> Helper loaded: form_helper
INFO - 2023-07-18 08:40:57 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:40:57 --> Helper loaded: security_helper
INFO - 2023-07-18 08:40:57 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:40:57 --> Database Driver Class Initialized
INFO - 2023-07-18 08:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:40:57 --> Parser Class Initialized
INFO - 2023-07-18 08:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:40:57 --> Pagination Class Initialized
INFO - 2023-07-18 08:40:57 --> Form Validation Class Initialized
INFO - 2023-07-18 08:40:57 --> Controller Class Initialized
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
DEBUG - 2023-07-18 08:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
DEBUG - 2023-07-18 08:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
DEBUG - 2023-07-18 08:40:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
INFO - 2023-07-18 08:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 08:40:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:40:57 --> Model Class Initialized
INFO - 2023-07-18 08:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:40:58 --> Final output sent to browser
DEBUG - 2023-07-18 08:40:58 --> Total execution time: 0.1737
ERROR - 2023-07-18 08:41:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:41:01 --> Config Class Initialized
INFO - 2023-07-18 08:41:01 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:41:01 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:41:01 --> Utf8 Class Initialized
INFO - 2023-07-18 08:41:01 --> URI Class Initialized
INFO - 2023-07-18 08:41:01 --> Router Class Initialized
INFO - 2023-07-18 08:41:01 --> Output Class Initialized
INFO - 2023-07-18 08:41:01 --> Security Class Initialized
DEBUG - 2023-07-18 08:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:41:01 --> Input Class Initialized
INFO - 2023-07-18 08:41:01 --> Language Class Initialized
INFO - 2023-07-18 08:41:01 --> Loader Class Initialized
INFO - 2023-07-18 08:41:01 --> Helper loaded: url_helper
INFO - 2023-07-18 08:41:01 --> Helper loaded: file_helper
INFO - 2023-07-18 08:41:01 --> Helper loaded: html_helper
INFO - 2023-07-18 08:41:01 --> Helper loaded: text_helper
INFO - 2023-07-18 08:41:01 --> Helper loaded: form_helper
INFO - 2023-07-18 08:41:01 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:41:01 --> Helper loaded: security_helper
INFO - 2023-07-18 08:41:01 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:41:01 --> Database Driver Class Initialized
INFO - 2023-07-18 08:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:41:01 --> Parser Class Initialized
INFO - 2023-07-18 08:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:41:01 --> Pagination Class Initialized
INFO - 2023-07-18 08:41:01 --> Form Validation Class Initialized
INFO - 2023-07-18 08:41:01 --> Controller Class Initialized
INFO - 2023-07-18 08:41:01 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:01 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:01 --> Model Class Initialized
INFO - 2023-07-18 08:41:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-18 08:41:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:41:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:41:01 --> Model Class Initialized
INFO - 2023-07-18 08:41:01 --> Model Class Initialized
INFO - 2023-07-18 08:41:01 --> Model Class Initialized
INFO - 2023-07-18 08:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:41:02 --> Final output sent to browser
DEBUG - 2023-07-18 08:41:02 --> Total execution time: 0.1357
ERROR - 2023-07-18 08:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:41:02 --> Config Class Initialized
INFO - 2023-07-18 08:41:02 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:41:02 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:41:02 --> Utf8 Class Initialized
INFO - 2023-07-18 08:41:02 --> URI Class Initialized
INFO - 2023-07-18 08:41:02 --> Router Class Initialized
INFO - 2023-07-18 08:41:02 --> Output Class Initialized
INFO - 2023-07-18 08:41:02 --> Security Class Initialized
DEBUG - 2023-07-18 08:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:41:02 --> Input Class Initialized
INFO - 2023-07-18 08:41:02 --> Language Class Initialized
INFO - 2023-07-18 08:41:02 --> Loader Class Initialized
INFO - 2023-07-18 08:41:02 --> Helper loaded: url_helper
INFO - 2023-07-18 08:41:02 --> Helper loaded: file_helper
INFO - 2023-07-18 08:41:02 --> Helper loaded: html_helper
INFO - 2023-07-18 08:41:02 --> Helper loaded: text_helper
INFO - 2023-07-18 08:41:02 --> Helper loaded: form_helper
INFO - 2023-07-18 08:41:02 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:41:02 --> Helper loaded: security_helper
INFO - 2023-07-18 08:41:02 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:41:02 --> Database Driver Class Initialized
INFO - 2023-07-18 08:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:41:02 --> Parser Class Initialized
INFO - 2023-07-18 08:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:41:02 --> Pagination Class Initialized
INFO - 2023-07-18 08:41:02 --> Form Validation Class Initialized
INFO - 2023-07-18 08:41:02 --> Controller Class Initialized
INFO - 2023-07-18 08:41:02 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:02 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:02 --> Model Class Initialized
INFO - 2023-07-18 08:41:02 --> Final output sent to browser
DEBUG - 2023-07-18 08:41:02 --> Total execution time: 0.0520
ERROR - 2023-07-18 08:41:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:41:07 --> Config Class Initialized
INFO - 2023-07-18 08:41:07 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:41:07 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:41:07 --> Utf8 Class Initialized
INFO - 2023-07-18 08:41:07 --> URI Class Initialized
INFO - 2023-07-18 08:41:07 --> Router Class Initialized
INFO - 2023-07-18 08:41:07 --> Output Class Initialized
INFO - 2023-07-18 08:41:07 --> Security Class Initialized
DEBUG - 2023-07-18 08:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:41:07 --> Input Class Initialized
INFO - 2023-07-18 08:41:07 --> Language Class Initialized
INFO - 2023-07-18 08:41:07 --> Loader Class Initialized
INFO - 2023-07-18 08:41:07 --> Helper loaded: url_helper
INFO - 2023-07-18 08:41:07 --> Helper loaded: file_helper
INFO - 2023-07-18 08:41:07 --> Helper loaded: html_helper
INFO - 2023-07-18 08:41:07 --> Helper loaded: text_helper
INFO - 2023-07-18 08:41:07 --> Helper loaded: form_helper
INFO - 2023-07-18 08:41:07 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:41:07 --> Helper loaded: security_helper
INFO - 2023-07-18 08:41:07 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:41:07 --> Database Driver Class Initialized
INFO - 2023-07-18 08:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:41:07 --> Parser Class Initialized
INFO - 2023-07-18 08:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:41:07 --> Pagination Class Initialized
INFO - 2023-07-18 08:41:07 --> Form Validation Class Initialized
INFO - 2023-07-18 08:41:07 --> Controller Class Initialized
INFO - 2023-07-18 08:41:07 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:07 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:07 --> Model Class Initialized
INFO - 2023-07-18 08:41:07 --> Final output sent to browser
DEBUG - 2023-07-18 08:41:07 --> Total execution time: 0.0629
ERROR - 2023-07-18 08:41:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:41:20 --> Config Class Initialized
INFO - 2023-07-18 08:41:20 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:41:20 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:41:20 --> Utf8 Class Initialized
INFO - 2023-07-18 08:41:20 --> URI Class Initialized
INFO - 2023-07-18 08:41:20 --> Router Class Initialized
INFO - 2023-07-18 08:41:20 --> Output Class Initialized
INFO - 2023-07-18 08:41:20 --> Security Class Initialized
DEBUG - 2023-07-18 08:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:41:20 --> Input Class Initialized
INFO - 2023-07-18 08:41:20 --> Language Class Initialized
INFO - 2023-07-18 08:41:20 --> Loader Class Initialized
INFO - 2023-07-18 08:41:20 --> Helper loaded: url_helper
INFO - 2023-07-18 08:41:20 --> Helper loaded: file_helper
INFO - 2023-07-18 08:41:20 --> Helper loaded: html_helper
INFO - 2023-07-18 08:41:20 --> Helper loaded: text_helper
INFO - 2023-07-18 08:41:20 --> Helper loaded: form_helper
INFO - 2023-07-18 08:41:20 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:41:20 --> Helper loaded: security_helper
INFO - 2023-07-18 08:41:20 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:41:20 --> Database Driver Class Initialized
INFO - 2023-07-18 08:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:41:20 --> Parser Class Initialized
INFO - 2023-07-18 08:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:41:20 --> Pagination Class Initialized
INFO - 2023-07-18 08:41:20 --> Form Validation Class Initialized
INFO - 2023-07-18 08:41:20 --> Controller Class Initialized
INFO - 2023-07-18 08:41:20 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:20 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:20 --> Model Class Initialized
INFO - 2023-07-18 08:41:20 --> Final output sent to browser
DEBUG - 2023-07-18 08:41:20 --> Total execution time: 0.0398
ERROR - 2023-07-18 08:41:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:41:23 --> Config Class Initialized
INFO - 2023-07-18 08:41:23 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:41:23 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:41:23 --> Utf8 Class Initialized
INFO - 2023-07-18 08:41:23 --> URI Class Initialized
INFO - 2023-07-18 08:41:23 --> Router Class Initialized
INFO - 2023-07-18 08:41:23 --> Output Class Initialized
INFO - 2023-07-18 08:41:23 --> Security Class Initialized
DEBUG - 2023-07-18 08:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:41:23 --> Input Class Initialized
INFO - 2023-07-18 08:41:23 --> Language Class Initialized
INFO - 2023-07-18 08:41:23 --> Loader Class Initialized
INFO - 2023-07-18 08:41:23 --> Helper loaded: url_helper
INFO - 2023-07-18 08:41:23 --> Helper loaded: file_helper
INFO - 2023-07-18 08:41:23 --> Helper loaded: html_helper
INFO - 2023-07-18 08:41:23 --> Helper loaded: text_helper
INFO - 2023-07-18 08:41:23 --> Helper loaded: form_helper
INFO - 2023-07-18 08:41:23 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:41:23 --> Helper loaded: security_helper
INFO - 2023-07-18 08:41:23 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:41:23 --> Database Driver Class Initialized
INFO - 2023-07-18 08:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:41:23 --> Parser Class Initialized
INFO - 2023-07-18 08:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:41:23 --> Pagination Class Initialized
INFO - 2023-07-18 08:41:23 --> Form Validation Class Initialized
INFO - 2023-07-18 08:41:23 --> Controller Class Initialized
INFO - 2023-07-18 08:41:23 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:23 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:23 --> Model Class Initialized
INFO - 2023-07-18 08:41:23 --> Final output sent to browser
DEBUG - 2023-07-18 08:41:23 --> Total execution time: 0.0386
ERROR - 2023-07-18 08:41:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:41:39 --> Config Class Initialized
INFO - 2023-07-18 08:41:39 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:41:39 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:41:39 --> Utf8 Class Initialized
INFO - 2023-07-18 08:41:39 --> URI Class Initialized
INFO - 2023-07-18 08:41:39 --> Router Class Initialized
INFO - 2023-07-18 08:41:39 --> Output Class Initialized
INFO - 2023-07-18 08:41:39 --> Security Class Initialized
DEBUG - 2023-07-18 08:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:41:39 --> Input Class Initialized
INFO - 2023-07-18 08:41:39 --> Language Class Initialized
INFO - 2023-07-18 08:41:39 --> Loader Class Initialized
INFO - 2023-07-18 08:41:39 --> Helper loaded: url_helper
INFO - 2023-07-18 08:41:39 --> Helper loaded: file_helper
INFO - 2023-07-18 08:41:39 --> Helper loaded: html_helper
INFO - 2023-07-18 08:41:39 --> Helper loaded: text_helper
INFO - 2023-07-18 08:41:39 --> Helper loaded: form_helper
INFO - 2023-07-18 08:41:39 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:41:39 --> Helper loaded: security_helper
INFO - 2023-07-18 08:41:39 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:41:39 --> Database Driver Class Initialized
INFO - 2023-07-18 08:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:41:39 --> Parser Class Initialized
INFO - 2023-07-18 08:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:41:39 --> Pagination Class Initialized
INFO - 2023-07-18 08:41:39 --> Form Validation Class Initialized
INFO - 2023-07-18 08:41:39 --> Controller Class Initialized
INFO - 2023-07-18 08:41:39 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:39 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:39 --> Model Class Initialized
INFO - 2023-07-18 08:41:39 --> Final output sent to browser
DEBUG - 2023-07-18 08:41:39 --> Total execution time: 0.0378
ERROR - 2023-07-18 08:41:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:41:54 --> Config Class Initialized
INFO - 2023-07-18 08:41:54 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:41:54 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:41:54 --> Utf8 Class Initialized
INFO - 2023-07-18 08:41:54 --> URI Class Initialized
INFO - 2023-07-18 08:41:54 --> Router Class Initialized
INFO - 2023-07-18 08:41:54 --> Output Class Initialized
INFO - 2023-07-18 08:41:54 --> Security Class Initialized
DEBUG - 2023-07-18 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:41:54 --> Input Class Initialized
INFO - 2023-07-18 08:41:54 --> Language Class Initialized
INFO - 2023-07-18 08:41:54 --> Loader Class Initialized
INFO - 2023-07-18 08:41:54 --> Helper loaded: url_helper
INFO - 2023-07-18 08:41:54 --> Helper loaded: file_helper
INFO - 2023-07-18 08:41:54 --> Helper loaded: html_helper
INFO - 2023-07-18 08:41:54 --> Helper loaded: text_helper
INFO - 2023-07-18 08:41:54 --> Helper loaded: form_helper
INFO - 2023-07-18 08:41:54 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:41:54 --> Helper loaded: security_helper
INFO - 2023-07-18 08:41:54 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:41:54 --> Database Driver Class Initialized
INFO - 2023-07-18 08:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:41:54 --> Parser Class Initialized
INFO - 2023-07-18 08:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:41:54 --> Pagination Class Initialized
INFO - 2023-07-18 08:41:54 --> Form Validation Class Initialized
INFO - 2023-07-18 08:41:54 --> Controller Class Initialized
INFO - 2023-07-18 08:41:54 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:54 --> Model Class Initialized
DEBUG - 2023-07-18 08:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:41:54 --> Model Class Initialized
INFO - 2023-07-18 08:41:54 --> Final output sent to browser
DEBUG - 2023-07-18 08:41:54 --> Total execution time: 0.0625
ERROR - 2023-07-18 08:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:42:03 --> Config Class Initialized
INFO - 2023-07-18 08:42:03 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:42:03 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:42:03 --> Utf8 Class Initialized
INFO - 2023-07-18 08:42:03 --> URI Class Initialized
INFO - 2023-07-18 08:42:03 --> Router Class Initialized
INFO - 2023-07-18 08:42:03 --> Output Class Initialized
INFO - 2023-07-18 08:42:03 --> Security Class Initialized
DEBUG - 2023-07-18 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:42:03 --> Input Class Initialized
INFO - 2023-07-18 08:42:03 --> Language Class Initialized
INFO - 2023-07-18 08:42:03 --> Loader Class Initialized
INFO - 2023-07-18 08:42:03 --> Helper loaded: url_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: file_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: html_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: text_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: form_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: security_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:42:03 --> Database Driver Class Initialized
INFO - 2023-07-18 08:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:42:03 --> Parser Class Initialized
INFO - 2023-07-18 08:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:42:03 --> Pagination Class Initialized
INFO - 2023-07-18 08:42:03 --> Form Validation Class Initialized
INFO - 2023-07-18 08:42:03 --> Controller Class Initialized
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
INFO - 2023-07-18 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-18 08:42:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
INFO - 2023-07-18 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:42:03 --> Final output sent to browser
DEBUG - 2023-07-18 08:42:03 --> Total execution time: 0.1531
ERROR - 2023-07-18 08:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:42:03 --> Config Class Initialized
INFO - 2023-07-18 08:42:03 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:42:03 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:42:03 --> Utf8 Class Initialized
INFO - 2023-07-18 08:42:03 --> URI Class Initialized
INFO - 2023-07-18 08:42:03 --> Router Class Initialized
INFO - 2023-07-18 08:42:03 --> Output Class Initialized
INFO - 2023-07-18 08:42:03 --> Security Class Initialized
DEBUG - 2023-07-18 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:42:03 --> Input Class Initialized
INFO - 2023-07-18 08:42:03 --> Language Class Initialized
INFO - 2023-07-18 08:42:03 --> Loader Class Initialized
INFO - 2023-07-18 08:42:03 --> Helper loaded: url_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: file_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: html_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: text_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: form_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: security_helper
INFO - 2023-07-18 08:42:03 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:42:03 --> Database Driver Class Initialized
INFO - 2023-07-18 08:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:42:03 --> Parser Class Initialized
INFO - 2023-07-18 08:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:42:03 --> Pagination Class Initialized
INFO - 2023-07-18 08:42:03 --> Form Validation Class Initialized
INFO - 2023-07-18 08:42:03 --> Controller Class Initialized
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:03 --> Model Class Initialized
INFO - 2023-07-18 08:42:03 --> Final output sent to browser
DEBUG - 2023-07-18 08:42:03 --> Total execution time: 0.0570
ERROR - 2023-07-18 08:42:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:42:14 --> Config Class Initialized
INFO - 2023-07-18 08:42:14 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:42:14 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:42:14 --> Utf8 Class Initialized
INFO - 2023-07-18 08:42:14 --> URI Class Initialized
INFO - 2023-07-18 08:42:14 --> Router Class Initialized
INFO - 2023-07-18 08:42:14 --> Output Class Initialized
INFO - 2023-07-18 08:42:14 --> Security Class Initialized
DEBUG - 2023-07-18 08:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:42:14 --> Input Class Initialized
INFO - 2023-07-18 08:42:14 --> Language Class Initialized
INFO - 2023-07-18 08:42:14 --> Loader Class Initialized
INFO - 2023-07-18 08:42:14 --> Helper loaded: url_helper
INFO - 2023-07-18 08:42:14 --> Helper loaded: file_helper
INFO - 2023-07-18 08:42:14 --> Helper loaded: html_helper
INFO - 2023-07-18 08:42:14 --> Helper loaded: text_helper
INFO - 2023-07-18 08:42:14 --> Helper loaded: form_helper
INFO - 2023-07-18 08:42:14 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:42:14 --> Helper loaded: security_helper
INFO - 2023-07-18 08:42:14 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:42:14 --> Database Driver Class Initialized
INFO - 2023-07-18 08:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:42:14 --> Parser Class Initialized
INFO - 2023-07-18 08:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:42:14 --> Pagination Class Initialized
INFO - 2023-07-18 08:42:14 --> Form Validation Class Initialized
INFO - 2023-07-18 08:42:14 --> Controller Class Initialized
INFO - 2023-07-18 08:42:14 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:14 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:14 --> Model Class Initialized
INFO - 2023-07-18 08:42:14 --> Final output sent to browser
DEBUG - 2023-07-18 08:42:14 --> Total execution time: 0.0575
ERROR - 2023-07-18 08:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:42:20 --> Config Class Initialized
INFO - 2023-07-18 08:42:20 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:42:20 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:42:20 --> Utf8 Class Initialized
INFO - 2023-07-18 08:42:20 --> URI Class Initialized
INFO - 2023-07-18 08:42:20 --> Router Class Initialized
INFO - 2023-07-18 08:42:20 --> Output Class Initialized
INFO - 2023-07-18 08:42:20 --> Security Class Initialized
DEBUG - 2023-07-18 08:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:42:20 --> Input Class Initialized
INFO - 2023-07-18 08:42:20 --> Language Class Initialized
INFO - 2023-07-18 08:42:20 --> Loader Class Initialized
INFO - 2023-07-18 08:42:20 --> Helper loaded: url_helper
INFO - 2023-07-18 08:42:20 --> Helper loaded: file_helper
INFO - 2023-07-18 08:42:20 --> Helper loaded: html_helper
INFO - 2023-07-18 08:42:20 --> Helper loaded: text_helper
INFO - 2023-07-18 08:42:20 --> Helper loaded: form_helper
INFO - 2023-07-18 08:42:20 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:42:20 --> Helper loaded: security_helper
INFO - 2023-07-18 08:42:20 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:42:20 --> Database Driver Class Initialized
INFO - 2023-07-18 08:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:42:20 --> Parser Class Initialized
INFO - 2023-07-18 08:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:42:20 --> Pagination Class Initialized
INFO - 2023-07-18 08:42:20 --> Form Validation Class Initialized
INFO - 2023-07-18 08:42:20 --> Controller Class Initialized
INFO - 2023-07-18 08:42:20 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:20 --> Model Class Initialized
DEBUG - 2023-07-18 08:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:42:20 --> Model Class Initialized
INFO - 2023-07-18 08:42:20 --> Final output sent to browser
DEBUG - 2023-07-18 08:42:20 --> Total execution time: 0.3632
ERROR - 2023-07-18 08:47:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:47:54 --> Config Class Initialized
INFO - 2023-07-18 08:47:54 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:47:54 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:47:54 --> Utf8 Class Initialized
INFO - 2023-07-18 08:47:54 --> URI Class Initialized
DEBUG - 2023-07-18 08:47:54 --> No URI present. Default controller set.
INFO - 2023-07-18 08:47:54 --> Router Class Initialized
INFO - 2023-07-18 08:47:54 --> Output Class Initialized
INFO - 2023-07-18 08:47:54 --> Security Class Initialized
DEBUG - 2023-07-18 08:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:47:54 --> Input Class Initialized
INFO - 2023-07-18 08:47:54 --> Language Class Initialized
INFO - 2023-07-18 08:47:54 --> Loader Class Initialized
INFO - 2023-07-18 08:47:54 --> Helper loaded: url_helper
INFO - 2023-07-18 08:47:54 --> Helper loaded: file_helper
INFO - 2023-07-18 08:47:54 --> Helper loaded: html_helper
INFO - 2023-07-18 08:47:54 --> Helper loaded: text_helper
INFO - 2023-07-18 08:47:54 --> Helper loaded: form_helper
INFO - 2023-07-18 08:47:54 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:47:54 --> Helper loaded: security_helper
INFO - 2023-07-18 08:47:54 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:47:54 --> Database Driver Class Initialized
INFO - 2023-07-18 08:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:47:54 --> Parser Class Initialized
INFO - 2023-07-18 08:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:47:54 --> Pagination Class Initialized
INFO - 2023-07-18 08:47:54 --> Form Validation Class Initialized
INFO - 2023-07-18 08:47:54 --> Controller Class Initialized
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
DEBUG - 2023-07-18 08:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
DEBUG - 2023-07-18 08:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
DEBUG - 2023-07-18 08:47:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 08:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
INFO - 2023-07-18 08:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 08:47:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:47:54 --> Model Class Initialized
INFO - 2023-07-18 08:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:47:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:47:54 --> Final output sent to browser
DEBUG - 2023-07-18 08:47:54 --> Total execution time: 0.2063
ERROR - 2023-07-18 08:48:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:48:16 --> Config Class Initialized
INFO - 2023-07-18 08:48:16 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:48:16 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:48:16 --> Utf8 Class Initialized
INFO - 2023-07-18 08:48:16 --> URI Class Initialized
DEBUG - 2023-07-18 08:48:16 --> No URI present. Default controller set.
INFO - 2023-07-18 08:48:16 --> Router Class Initialized
INFO - 2023-07-18 08:48:16 --> Output Class Initialized
INFO - 2023-07-18 08:48:16 --> Security Class Initialized
DEBUG - 2023-07-18 08:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:48:16 --> Input Class Initialized
INFO - 2023-07-18 08:48:16 --> Language Class Initialized
INFO - 2023-07-18 08:48:16 --> Loader Class Initialized
INFO - 2023-07-18 08:48:16 --> Helper loaded: url_helper
INFO - 2023-07-18 08:48:16 --> Helper loaded: file_helper
INFO - 2023-07-18 08:48:16 --> Helper loaded: html_helper
INFO - 2023-07-18 08:48:16 --> Helper loaded: text_helper
INFO - 2023-07-18 08:48:16 --> Helper loaded: form_helper
INFO - 2023-07-18 08:48:16 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:48:16 --> Helper loaded: security_helper
INFO - 2023-07-18 08:48:16 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:48:16 --> Database Driver Class Initialized
INFO - 2023-07-18 08:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:48:16 --> Parser Class Initialized
INFO - 2023-07-18 08:48:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:48:16 --> Pagination Class Initialized
INFO - 2023-07-18 08:48:16 --> Form Validation Class Initialized
INFO - 2023-07-18 08:48:16 --> Controller Class Initialized
INFO - 2023-07-18 08:48:16 --> Model Class Initialized
DEBUG - 2023-07-18 08:48:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-18 08:49:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:49:56 --> Config Class Initialized
INFO - 2023-07-18 08:49:56 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:49:56 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:49:56 --> Utf8 Class Initialized
INFO - 2023-07-18 08:49:56 --> URI Class Initialized
INFO - 2023-07-18 08:49:56 --> Router Class Initialized
INFO - 2023-07-18 08:49:56 --> Output Class Initialized
INFO - 2023-07-18 08:49:56 --> Security Class Initialized
DEBUG - 2023-07-18 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:49:56 --> Input Class Initialized
INFO - 2023-07-18 08:49:56 --> Language Class Initialized
INFO - 2023-07-18 08:49:56 --> Loader Class Initialized
INFO - 2023-07-18 08:49:56 --> Helper loaded: url_helper
INFO - 2023-07-18 08:49:56 --> Helper loaded: file_helper
INFO - 2023-07-18 08:49:56 --> Helper loaded: html_helper
INFO - 2023-07-18 08:49:56 --> Helper loaded: text_helper
INFO - 2023-07-18 08:49:56 --> Helper loaded: form_helper
INFO - 2023-07-18 08:49:56 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:49:56 --> Helper loaded: security_helper
INFO - 2023-07-18 08:49:56 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:49:56 --> Database Driver Class Initialized
INFO - 2023-07-18 08:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:49:56 --> Parser Class Initialized
INFO - 2023-07-18 08:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:49:56 --> Pagination Class Initialized
INFO - 2023-07-18 08:49:56 --> Form Validation Class Initialized
INFO - 2023-07-18 08:49:56 --> Controller Class Initialized
INFO - 2023-07-18 08:49:56 --> Model Class Initialized
INFO - 2023-07-18 08:49:56 --> Model Class Initialized
INFO - 2023-07-18 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-18 08:49:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:49:56 --> Model Class Initialized
INFO - 2023-07-18 08:49:56 --> Model Class Initialized
INFO - 2023-07-18 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:49:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:49:56 --> Final output sent to browser
DEBUG - 2023-07-18 08:49:56 --> Total execution time: 0.1301
ERROR - 2023-07-18 08:49:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:49:57 --> Config Class Initialized
INFO - 2023-07-18 08:49:57 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:49:57 --> Utf8 Class Initialized
INFO - 2023-07-18 08:49:57 --> URI Class Initialized
INFO - 2023-07-18 08:49:57 --> Router Class Initialized
INFO - 2023-07-18 08:49:57 --> Output Class Initialized
INFO - 2023-07-18 08:49:57 --> Security Class Initialized
DEBUG - 2023-07-18 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:49:57 --> Input Class Initialized
INFO - 2023-07-18 08:49:57 --> Language Class Initialized
INFO - 2023-07-18 08:49:57 --> Loader Class Initialized
INFO - 2023-07-18 08:49:57 --> Helper loaded: url_helper
INFO - 2023-07-18 08:49:57 --> Helper loaded: file_helper
INFO - 2023-07-18 08:49:57 --> Helper loaded: html_helper
INFO - 2023-07-18 08:49:57 --> Helper loaded: text_helper
INFO - 2023-07-18 08:49:57 --> Helper loaded: form_helper
INFO - 2023-07-18 08:49:57 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:49:57 --> Helper loaded: security_helper
INFO - 2023-07-18 08:49:57 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:49:57 --> Database Driver Class Initialized
INFO - 2023-07-18 08:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:49:57 --> Parser Class Initialized
INFO - 2023-07-18 08:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:49:57 --> Pagination Class Initialized
INFO - 2023-07-18 08:49:57 --> Form Validation Class Initialized
INFO - 2023-07-18 08:49:57 --> Controller Class Initialized
INFO - 2023-07-18 08:49:57 --> Model Class Initialized
INFO - 2023-07-18 08:49:57 --> Model Class Initialized
INFO - 2023-07-18 08:49:57 --> Final output sent to browser
DEBUG - 2023-07-18 08:49:57 --> Total execution time: 0.0236
ERROR - 2023-07-18 08:50:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:50:03 --> Config Class Initialized
INFO - 2023-07-18 08:50:03 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:50:03 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:50:03 --> Utf8 Class Initialized
INFO - 2023-07-18 08:50:03 --> URI Class Initialized
INFO - 2023-07-18 08:50:03 --> Router Class Initialized
INFO - 2023-07-18 08:50:03 --> Output Class Initialized
INFO - 2023-07-18 08:50:03 --> Security Class Initialized
DEBUG - 2023-07-18 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:50:03 --> Input Class Initialized
INFO - 2023-07-18 08:50:03 --> Language Class Initialized
INFO - 2023-07-18 08:50:03 --> Loader Class Initialized
INFO - 2023-07-18 08:50:03 --> Helper loaded: url_helper
INFO - 2023-07-18 08:50:03 --> Helper loaded: file_helper
INFO - 2023-07-18 08:50:03 --> Helper loaded: html_helper
INFO - 2023-07-18 08:50:03 --> Helper loaded: text_helper
INFO - 2023-07-18 08:50:03 --> Helper loaded: form_helper
INFO - 2023-07-18 08:50:03 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:50:03 --> Helper loaded: security_helper
INFO - 2023-07-18 08:50:03 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:50:03 --> Database Driver Class Initialized
INFO - 2023-07-18 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:50:03 --> Parser Class Initialized
INFO - 2023-07-18 08:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:50:03 --> Pagination Class Initialized
INFO - 2023-07-18 08:50:03 --> Form Validation Class Initialized
INFO - 2023-07-18 08:50:03 --> Controller Class Initialized
INFO - 2023-07-18 08:50:03 --> Model Class Initialized
INFO - 2023-07-18 08:50:03 --> Model Class Initialized
INFO - 2023-07-18 08:50:03 --> Final output sent to browser
DEBUG - 2023-07-18 08:50:03 --> Total execution time: 0.0330
ERROR - 2023-07-18 08:50:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:50:42 --> Config Class Initialized
INFO - 2023-07-18 08:50:42 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:50:42 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:50:42 --> Utf8 Class Initialized
INFO - 2023-07-18 08:50:42 --> URI Class Initialized
INFO - 2023-07-18 08:50:42 --> Router Class Initialized
INFO - 2023-07-18 08:50:42 --> Output Class Initialized
INFO - 2023-07-18 08:50:42 --> Security Class Initialized
DEBUG - 2023-07-18 08:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:50:42 --> Input Class Initialized
INFO - 2023-07-18 08:50:42 --> Language Class Initialized
INFO - 2023-07-18 08:50:42 --> Loader Class Initialized
INFO - 2023-07-18 08:50:42 --> Helper loaded: url_helper
INFO - 2023-07-18 08:50:42 --> Helper loaded: file_helper
INFO - 2023-07-18 08:50:42 --> Helper loaded: html_helper
INFO - 2023-07-18 08:50:42 --> Helper loaded: text_helper
INFO - 2023-07-18 08:50:42 --> Helper loaded: form_helper
INFO - 2023-07-18 08:50:42 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:50:42 --> Helper loaded: security_helper
INFO - 2023-07-18 08:50:42 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:50:42 --> Database Driver Class Initialized
INFO - 2023-07-18 08:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:50:42 --> Parser Class Initialized
INFO - 2023-07-18 08:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:50:42 --> Pagination Class Initialized
INFO - 2023-07-18 08:50:42 --> Form Validation Class Initialized
INFO - 2023-07-18 08:50:42 --> Controller Class Initialized
DEBUG - 2023-07-18 08:50:42 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:50:42 --> Model Class Initialized
INFO - 2023-07-18 08:50:42 --> Model Class Initialized
INFO - 2023-07-18 08:50:42 --> Model Class Initialized
INFO - 2023-07-18 08:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-18 08:50:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:50:42 --> Model Class Initialized
INFO - 2023-07-18 08:50:42 --> Model Class Initialized
INFO - 2023-07-18 08:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:50:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:50:42 --> Final output sent to browser
DEBUG - 2023-07-18 08:50:42 --> Total execution time: 0.1742
ERROR - 2023-07-18 08:51:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:51:19 --> Config Class Initialized
INFO - 2023-07-18 08:51:19 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:51:19 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:51:19 --> Utf8 Class Initialized
INFO - 2023-07-18 08:51:19 --> URI Class Initialized
INFO - 2023-07-18 08:51:19 --> Router Class Initialized
INFO - 2023-07-18 08:51:19 --> Output Class Initialized
INFO - 2023-07-18 08:51:19 --> Security Class Initialized
DEBUG - 2023-07-18 08:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:51:19 --> Input Class Initialized
INFO - 2023-07-18 08:51:19 --> Language Class Initialized
INFO - 2023-07-18 08:51:19 --> Loader Class Initialized
INFO - 2023-07-18 08:51:19 --> Helper loaded: url_helper
INFO - 2023-07-18 08:51:19 --> Helper loaded: file_helper
INFO - 2023-07-18 08:51:19 --> Helper loaded: html_helper
INFO - 2023-07-18 08:51:19 --> Helper loaded: text_helper
INFO - 2023-07-18 08:51:19 --> Helper loaded: form_helper
INFO - 2023-07-18 08:51:19 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:51:19 --> Helper loaded: security_helper
INFO - 2023-07-18 08:51:19 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:51:19 --> Database Driver Class Initialized
INFO - 2023-07-18 08:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:51:19 --> Parser Class Initialized
INFO - 2023-07-18 08:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:51:19 --> Pagination Class Initialized
INFO - 2023-07-18 08:51:19 --> Form Validation Class Initialized
INFO - 2023-07-18 08:51:19 --> Controller Class Initialized
INFO - 2023-07-18 08:51:19 --> Model Class Initialized
INFO - 2023-07-18 08:51:19 --> Model Class Initialized
INFO - 2023-07-18 08:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-18 08:51:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:51:19 --> Model Class Initialized
INFO - 2023-07-18 08:51:19 --> Model Class Initialized
INFO - 2023-07-18 08:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:51:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:51:19 --> Final output sent to browser
DEBUG - 2023-07-18 08:51:19 --> Total execution time: 0.1565
ERROR - 2023-07-18 08:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:51:20 --> Config Class Initialized
INFO - 2023-07-18 08:51:20 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:51:20 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:51:20 --> Utf8 Class Initialized
INFO - 2023-07-18 08:51:20 --> URI Class Initialized
INFO - 2023-07-18 08:51:20 --> Router Class Initialized
INFO - 2023-07-18 08:51:20 --> Output Class Initialized
INFO - 2023-07-18 08:51:20 --> Security Class Initialized
DEBUG - 2023-07-18 08:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:51:20 --> Input Class Initialized
INFO - 2023-07-18 08:51:20 --> Language Class Initialized
INFO - 2023-07-18 08:51:20 --> Loader Class Initialized
INFO - 2023-07-18 08:51:20 --> Helper loaded: url_helper
INFO - 2023-07-18 08:51:20 --> Helper loaded: file_helper
INFO - 2023-07-18 08:51:20 --> Helper loaded: html_helper
INFO - 2023-07-18 08:51:20 --> Helper loaded: text_helper
INFO - 2023-07-18 08:51:20 --> Helper loaded: form_helper
INFO - 2023-07-18 08:51:20 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:51:20 --> Helper loaded: security_helper
INFO - 2023-07-18 08:51:20 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:51:20 --> Database Driver Class Initialized
INFO - 2023-07-18 08:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:51:20 --> Parser Class Initialized
INFO - 2023-07-18 08:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:51:20 --> Pagination Class Initialized
INFO - 2023-07-18 08:51:20 --> Form Validation Class Initialized
INFO - 2023-07-18 08:51:20 --> Controller Class Initialized
INFO - 2023-07-18 08:51:20 --> Model Class Initialized
INFO - 2023-07-18 08:51:20 --> Model Class Initialized
INFO - 2023-07-18 08:51:20 --> Final output sent to browser
DEBUG - 2023-07-18 08:51:20 --> Total execution time: 0.0249
ERROR - 2023-07-18 08:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 08:51:21 --> Config Class Initialized
INFO - 2023-07-18 08:51:21 --> Hooks Class Initialized
DEBUG - 2023-07-18 08:51:21 --> UTF-8 Support Enabled
INFO - 2023-07-18 08:51:21 --> Utf8 Class Initialized
INFO - 2023-07-18 08:51:21 --> URI Class Initialized
INFO - 2023-07-18 08:51:21 --> Router Class Initialized
INFO - 2023-07-18 08:51:21 --> Output Class Initialized
INFO - 2023-07-18 08:51:21 --> Security Class Initialized
DEBUG - 2023-07-18 08:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 08:51:21 --> Input Class Initialized
INFO - 2023-07-18 08:51:21 --> Language Class Initialized
INFO - 2023-07-18 08:51:21 --> Loader Class Initialized
INFO - 2023-07-18 08:51:21 --> Helper loaded: url_helper
INFO - 2023-07-18 08:51:21 --> Helper loaded: file_helper
INFO - 2023-07-18 08:51:21 --> Helper loaded: html_helper
INFO - 2023-07-18 08:51:21 --> Helper loaded: text_helper
INFO - 2023-07-18 08:51:21 --> Helper loaded: form_helper
INFO - 2023-07-18 08:51:21 --> Helper loaded: lang_helper
INFO - 2023-07-18 08:51:21 --> Helper loaded: security_helper
INFO - 2023-07-18 08:51:21 --> Helper loaded: cookie_helper
INFO - 2023-07-18 08:51:21 --> Database Driver Class Initialized
INFO - 2023-07-18 08:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 08:51:21 --> Parser Class Initialized
INFO - 2023-07-18 08:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 08:51:21 --> Pagination Class Initialized
INFO - 2023-07-18 08:51:21 --> Form Validation Class Initialized
INFO - 2023-07-18 08:51:21 --> Controller Class Initialized
DEBUG - 2023-07-18 08:51:21 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:51:21 --> Model Class Initialized
INFO - 2023-07-18 08:51:21 --> Model Class Initialized
INFO - 2023-07-18 08:51:21 --> Model Class Initialized
INFO - 2023-07-18 08:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-18 08:51:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 08:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 08:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 08:51:21 --> Model Class Initialized
INFO - 2023-07-18 08:51:21 --> Model Class Initialized
INFO - 2023-07-18 08:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 08:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 08:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 08:51:22 --> Final output sent to browser
DEBUG - 2023-07-18 08:51:22 --> Total execution time: 0.1879
ERROR - 2023-07-18 10:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 10:01:45 --> Config Class Initialized
INFO - 2023-07-18 10:01:45 --> Hooks Class Initialized
DEBUG - 2023-07-18 10:01:45 --> UTF-8 Support Enabled
INFO - 2023-07-18 10:01:45 --> Utf8 Class Initialized
INFO - 2023-07-18 10:01:45 --> URI Class Initialized
INFO - 2023-07-18 10:01:45 --> Router Class Initialized
INFO - 2023-07-18 10:01:45 --> Output Class Initialized
INFO - 2023-07-18 10:01:45 --> Security Class Initialized
DEBUG - 2023-07-18 10:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 10:01:45 --> Input Class Initialized
INFO - 2023-07-18 10:01:45 --> Language Class Initialized
INFO - 2023-07-18 10:01:45 --> Loader Class Initialized
INFO - 2023-07-18 10:01:45 --> Helper loaded: url_helper
INFO - 2023-07-18 10:01:45 --> Helper loaded: file_helper
INFO - 2023-07-18 10:01:45 --> Helper loaded: html_helper
INFO - 2023-07-18 10:01:45 --> Helper loaded: text_helper
INFO - 2023-07-18 10:01:45 --> Helper loaded: form_helper
INFO - 2023-07-18 10:01:45 --> Helper loaded: lang_helper
INFO - 2023-07-18 10:01:45 --> Helper loaded: security_helper
INFO - 2023-07-18 10:01:45 --> Helper loaded: cookie_helper
INFO - 2023-07-18 10:01:45 --> Database Driver Class Initialized
INFO - 2023-07-18 10:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 10:01:45 --> Parser Class Initialized
INFO - 2023-07-18 10:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 10:01:45 --> Pagination Class Initialized
INFO - 2023-07-18 10:01:45 --> Form Validation Class Initialized
INFO - 2023-07-18 10:01:45 --> Controller Class Initialized
INFO - 2023-07-18 10:01:45 --> Model Class Initialized
INFO - 2023-07-18 10:01:45 --> Model Class Initialized
INFO - 2023-07-18 10:01:45 --> Model Class Initialized
INFO - 2023-07-18 10:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-18 10:01:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 10:01:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 10:01:45 --> Model Class Initialized
INFO - 2023-07-18 10:01:45 --> Model Class Initialized
INFO - 2023-07-18 10:01:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 10:01:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 10:01:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 10:01:46 --> Final output sent to browser
DEBUG - 2023-07-18 10:01:46 --> Total execution time: 0.1672
ERROR - 2023-07-18 10:01:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 10:01:46 --> Config Class Initialized
INFO - 2023-07-18 10:01:46 --> Hooks Class Initialized
DEBUG - 2023-07-18 10:01:46 --> UTF-8 Support Enabled
INFO - 2023-07-18 10:01:46 --> Utf8 Class Initialized
INFO - 2023-07-18 10:01:46 --> URI Class Initialized
INFO - 2023-07-18 10:01:46 --> Router Class Initialized
INFO - 2023-07-18 10:01:46 --> Output Class Initialized
INFO - 2023-07-18 10:01:46 --> Security Class Initialized
DEBUG - 2023-07-18 10:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 10:01:46 --> Input Class Initialized
INFO - 2023-07-18 10:01:46 --> Language Class Initialized
INFO - 2023-07-18 10:01:46 --> Loader Class Initialized
INFO - 2023-07-18 10:01:46 --> Helper loaded: url_helper
INFO - 2023-07-18 10:01:46 --> Helper loaded: file_helper
INFO - 2023-07-18 10:01:46 --> Helper loaded: html_helper
INFO - 2023-07-18 10:01:46 --> Helper loaded: text_helper
INFO - 2023-07-18 10:01:46 --> Helper loaded: form_helper
INFO - 2023-07-18 10:01:46 --> Helper loaded: lang_helper
INFO - 2023-07-18 10:01:46 --> Helper loaded: security_helper
INFO - 2023-07-18 10:01:46 --> Helper loaded: cookie_helper
INFO - 2023-07-18 10:01:46 --> Database Driver Class Initialized
INFO - 2023-07-18 10:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 10:01:46 --> Parser Class Initialized
INFO - 2023-07-18 10:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 10:01:46 --> Pagination Class Initialized
INFO - 2023-07-18 10:01:46 --> Form Validation Class Initialized
INFO - 2023-07-18 10:01:46 --> Controller Class Initialized
INFO - 2023-07-18 10:01:46 --> Model Class Initialized
INFO - 2023-07-18 10:01:46 --> Model Class Initialized
INFO - 2023-07-18 10:01:46 --> Final output sent to browser
DEBUG - 2023-07-18 10:01:46 --> Total execution time: 0.0245
ERROR - 2023-07-18 10:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 10:03:44 --> Config Class Initialized
INFO - 2023-07-18 10:03:44 --> Hooks Class Initialized
DEBUG - 2023-07-18 10:03:44 --> UTF-8 Support Enabled
INFO - 2023-07-18 10:03:44 --> Utf8 Class Initialized
INFO - 2023-07-18 10:03:44 --> URI Class Initialized
INFO - 2023-07-18 10:03:44 --> Router Class Initialized
INFO - 2023-07-18 10:03:44 --> Output Class Initialized
INFO - 2023-07-18 10:03:44 --> Security Class Initialized
DEBUG - 2023-07-18 10:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 10:03:44 --> Input Class Initialized
INFO - 2023-07-18 10:03:44 --> Language Class Initialized
INFO - 2023-07-18 10:03:44 --> Loader Class Initialized
INFO - 2023-07-18 10:03:44 --> Helper loaded: url_helper
INFO - 2023-07-18 10:03:44 --> Helper loaded: file_helper
INFO - 2023-07-18 10:03:44 --> Helper loaded: html_helper
INFO - 2023-07-18 10:03:44 --> Helper loaded: text_helper
INFO - 2023-07-18 10:03:44 --> Helper loaded: form_helper
INFO - 2023-07-18 10:03:44 --> Helper loaded: lang_helper
INFO - 2023-07-18 10:03:44 --> Helper loaded: security_helper
INFO - 2023-07-18 10:03:44 --> Helper loaded: cookie_helper
INFO - 2023-07-18 10:03:44 --> Database Driver Class Initialized
INFO - 2023-07-18 10:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 10:03:44 --> Parser Class Initialized
INFO - 2023-07-18 10:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 10:03:44 --> Pagination Class Initialized
INFO - 2023-07-18 10:03:44 --> Form Validation Class Initialized
INFO - 2023-07-18 10:03:44 --> Controller Class Initialized
DEBUG - 2023-07-18 10:03:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 10:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:03:44 --> Model Class Initialized
DEBUG - 2023-07-18 10:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:03:44 --> Model Class Initialized
INFO - 2023-07-18 10:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-18 10:03:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 10:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 10:03:44 --> Model Class Initialized
INFO - 2023-07-18 10:03:44 --> Model Class Initialized
INFO - 2023-07-18 10:03:44 --> Model Class Initialized
INFO - 2023-07-18 10:03:44 --> Model Class Initialized
INFO - 2023-07-18 10:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 10:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 10:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 10:03:44 --> Final output sent to browser
DEBUG - 2023-07-18 10:03:44 --> Total execution time: 0.2019
ERROR - 2023-07-18 10:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 10:04:20 --> Config Class Initialized
INFO - 2023-07-18 10:04:20 --> Hooks Class Initialized
DEBUG - 2023-07-18 10:04:20 --> UTF-8 Support Enabled
INFO - 2023-07-18 10:04:20 --> Utf8 Class Initialized
INFO - 2023-07-18 10:04:20 --> URI Class Initialized
INFO - 2023-07-18 10:04:20 --> Router Class Initialized
INFO - 2023-07-18 10:04:20 --> Output Class Initialized
INFO - 2023-07-18 10:04:20 --> Security Class Initialized
DEBUG - 2023-07-18 10:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 10:04:20 --> Input Class Initialized
INFO - 2023-07-18 10:04:20 --> Language Class Initialized
INFO - 2023-07-18 10:04:20 --> Loader Class Initialized
INFO - 2023-07-18 10:04:20 --> Helper loaded: url_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: file_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: html_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: text_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: form_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: lang_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: security_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: cookie_helper
INFO - 2023-07-18 10:04:20 --> Database Driver Class Initialized
INFO - 2023-07-18 10:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 10:04:20 --> Parser Class Initialized
INFO - 2023-07-18 10:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 10:04:20 --> Pagination Class Initialized
INFO - 2023-07-18 10:04:20 --> Form Validation Class Initialized
INFO - 2023-07-18 10:04:20 --> Controller Class Initialized
DEBUG - 2023-07-18 10:04:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 10:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
DEBUG - 2023-07-18 10:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
DEBUG - 2023-07-18 10:04:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
INFO - 2023-07-18 10:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 10:04:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 10:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
INFO - 2023-07-18 10:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 10:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 10:04:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 10:04:20 --> Final output sent to browser
DEBUG - 2023-07-18 10:04:20 --> Total execution time: 0.1622
ERROR - 2023-07-18 10:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 10:04:20 --> Config Class Initialized
INFO - 2023-07-18 10:04:20 --> Hooks Class Initialized
DEBUG - 2023-07-18 10:04:20 --> UTF-8 Support Enabled
INFO - 2023-07-18 10:04:20 --> Utf8 Class Initialized
INFO - 2023-07-18 10:04:20 --> URI Class Initialized
INFO - 2023-07-18 10:04:20 --> Router Class Initialized
INFO - 2023-07-18 10:04:20 --> Output Class Initialized
INFO - 2023-07-18 10:04:20 --> Security Class Initialized
DEBUG - 2023-07-18 10:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 10:04:20 --> Input Class Initialized
INFO - 2023-07-18 10:04:20 --> Language Class Initialized
INFO - 2023-07-18 10:04:20 --> Loader Class Initialized
INFO - 2023-07-18 10:04:20 --> Helper loaded: url_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: file_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: html_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: text_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: form_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: lang_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: security_helper
INFO - 2023-07-18 10:04:20 --> Helper loaded: cookie_helper
INFO - 2023-07-18 10:04:20 --> Database Driver Class Initialized
INFO - 2023-07-18 10:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 10:04:20 --> Parser Class Initialized
INFO - 2023-07-18 10:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 10:04:20 --> Pagination Class Initialized
INFO - 2023-07-18 10:04:20 --> Form Validation Class Initialized
INFO - 2023-07-18 10:04:20 --> Controller Class Initialized
DEBUG - 2023-07-18 10:04:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 10:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
DEBUG - 2023-07-18 10:04:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:20 --> Model Class Initialized
INFO - 2023-07-18 10:04:20 --> Final output sent to browser
DEBUG - 2023-07-18 10:04:20 --> Total execution time: 0.0353
ERROR - 2023-07-18 10:04:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 10:04:55 --> Config Class Initialized
INFO - 2023-07-18 10:04:55 --> Hooks Class Initialized
DEBUG - 2023-07-18 10:04:55 --> UTF-8 Support Enabled
INFO - 2023-07-18 10:04:55 --> Utf8 Class Initialized
INFO - 2023-07-18 10:04:55 --> URI Class Initialized
INFO - 2023-07-18 10:04:55 --> Router Class Initialized
INFO - 2023-07-18 10:04:55 --> Output Class Initialized
INFO - 2023-07-18 10:04:55 --> Security Class Initialized
DEBUG - 2023-07-18 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 10:04:55 --> Input Class Initialized
INFO - 2023-07-18 10:04:55 --> Language Class Initialized
INFO - 2023-07-18 10:04:55 --> Loader Class Initialized
INFO - 2023-07-18 10:04:55 --> Helper loaded: url_helper
INFO - 2023-07-18 10:04:55 --> Helper loaded: file_helper
INFO - 2023-07-18 10:04:55 --> Helper loaded: html_helper
INFO - 2023-07-18 10:04:55 --> Helper loaded: text_helper
INFO - 2023-07-18 10:04:55 --> Helper loaded: form_helper
INFO - 2023-07-18 10:04:55 --> Helper loaded: lang_helper
INFO - 2023-07-18 10:04:55 --> Helper loaded: security_helper
INFO - 2023-07-18 10:04:55 --> Helper loaded: cookie_helper
INFO - 2023-07-18 10:04:55 --> Database Driver Class Initialized
INFO - 2023-07-18 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 10:04:55 --> Parser Class Initialized
INFO - 2023-07-18 10:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 10:04:55 --> Pagination Class Initialized
INFO - 2023-07-18 10:04:55 --> Form Validation Class Initialized
INFO - 2023-07-18 10:04:55 --> Controller Class Initialized
DEBUG - 2023-07-18 10:04:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 10:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:55 --> Model Class Initialized
DEBUG - 2023-07-18 10:04:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:55 --> Model Class Initialized
INFO - 2023-07-18 10:04:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-18 10:04:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 10:04:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 10:04:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 10:04:55 --> Model Class Initialized
INFO - 2023-07-18 10:04:55 --> Model Class Initialized
INFO - 2023-07-18 10:04:55 --> Model Class Initialized
INFO - 2023-07-18 10:04:55 --> Model Class Initialized
INFO - 2023-07-18 10:04:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 10:04:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 10:04:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 10:04:55 --> Final output sent to browser
DEBUG - 2023-07-18 10:04:55 --> Total execution time: 0.1797
ERROR - 2023-07-18 15:43:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:43:21 --> Config Class Initialized
INFO - 2023-07-18 15:43:21 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:43:21 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:43:21 --> Utf8 Class Initialized
INFO - 2023-07-18 15:43:21 --> URI Class Initialized
DEBUG - 2023-07-18 15:43:21 --> No URI present. Default controller set.
INFO - 2023-07-18 15:43:21 --> Router Class Initialized
INFO - 2023-07-18 15:43:21 --> Output Class Initialized
INFO - 2023-07-18 15:43:21 --> Security Class Initialized
DEBUG - 2023-07-18 15:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:43:21 --> Input Class Initialized
INFO - 2023-07-18 15:43:21 --> Language Class Initialized
INFO - 2023-07-18 15:43:21 --> Loader Class Initialized
INFO - 2023-07-18 15:43:21 --> Helper loaded: url_helper
INFO - 2023-07-18 15:43:21 --> Helper loaded: file_helper
INFO - 2023-07-18 15:43:21 --> Helper loaded: html_helper
INFO - 2023-07-18 15:43:21 --> Helper loaded: text_helper
INFO - 2023-07-18 15:43:21 --> Helper loaded: form_helper
INFO - 2023-07-18 15:43:21 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:43:21 --> Helper loaded: security_helper
INFO - 2023-07-18 15:43:21 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:43:21 --> Database Driver Class Initialized
INFO - 2023-07-18 15:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:43:21 --> Parser Class Initialized
INFO - 2023-07-18 15:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:43:21 --> Pagination Class Initialized
INFO - 2023-07-18 15:43:21 --> Form Validation Class Initialized
INFO - 2023-07-18 15:43:21 --> Controller Class Initialized
INFO - 2023-07-18 15:43:21 --> Model Class Initialized
DEBUG - 2023-07-18 15:43:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-18 15:43:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:43:22 --> Config Class Initialized
INFO - 2023-07-18 15:43:22 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:43:22 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:43:22 --> Utf8 Class Initialized
INFO - 2023-07-18 15:43:22 --> URI Class Initialized
INFO - 2023-07-18 15:43:22 --> Router Class Initialized
INFO - 2023-07-18 15:43:22 --> Output Class Initialized
INFO - 2023-07-18 15:43:22 --> Security Class Initialized
DEBUG - 2023-07-18 15:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:43:22 --> Input Class Initialized
INFO - 2023-07-18 15:43:22 --> Language Class Initialized
INFO - 2023-07-18 15:43:22 --> Loader Class Initialized
INFO - 2023-07-18 15:43:22 --> Helper loaded: url_helper
INFO - 2023-07-18 15:43:22 --> Helper loaded: file_helper
INFO - 2023-07-18 15:43:22 --> Helper loaded: html_helper
INFO - 2023-07-18 15:43:22 --> Helper loaded: text_helper
INFO - 2023-07-18 15:43:22 --> Helper loaded: form_helper
INFO - 2023-07-18 15:43:22 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:43:22 --> Helper loaded: security_helper
INFO - 2023-07-18 15:43:22 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:43:22 --> Database Driver Class Initialized
INFO - 2023-07-18 15:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:43:22 --> Parser Class Initialized
INFO - 2023-07-18 15:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:43:22 --> Pagination Class Initialized
INFO - 2023-07-18 15:43:22 --> Form Validation Class Initialized
INFO - 2023-07-18 15:43:22 --> Controller Class Initialized
INFO - 2023-07-18 15:43:22 --> Model Class Initialized
DEBUG - 2023-07-18 15:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-18 15:43:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:43:22 --> Model Class Initialized
INFO - 2023-07-18 15:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:43:22 --> Final output sent to browser
DEBUG - 2023-07-18 15:43:22 --> Total execution time: 0.0408
ERROR - 2023-07-18 15:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:07 --> Config Class Initialized
INFO - 2023-07-18 15:47:07 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:07 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:07 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:07 --> URI Class Initialized
DEBUG - 2023-07-18 15:47:07 --> No URI present. Default controller set.
INFO - 2023-07-18 15:47:07 --> Router Class Initialized
INFO - 2023-07-18 15:47:07 --> Output Class Initialized
INFO - 2023-07-18 15:47:07 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:07 --> Input Class Initialized
INFO - 2023-07-18 15:47:07 --> Language Class Initialized
INFO - 2023-07-18 15:47:07 --> Loader Class Initialized
INFO - 2023-07-18 15:47:07 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:07 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:07 --> Parser Class Initialized
INFO - 2023-07-18 15:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:07 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:07 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:07 --> Controller Class Initialized
INFO - 2023-07-18 15:47:07 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-18 15:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:07 --> Config Class Initialized
INFO - 2023-07-18 15:47:07 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:07 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:07 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:07 --> URI Class Initialized
INFO - 2023-07-18 15:47:07 --> Router Class Initialized
INFO - 2023-07-18 15:47:07 --> Output Class Initialized
INFO - 2023-07-18 15:47:07 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:07 --> Input Class Initialized
INFO - 2023-07-18 15:47:07 --> Language Class Initialized
INFO - 2023-07-18 15:47:07 --> Loader Class Initialized
INFO - 2023-07-18 15:47:07 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:07 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:07 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:07 --> Parser Class Initialized
INFO - 2023-07-18 15:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:07 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:07 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:07 --> Controller Class Initialized
INFO - 2023-07-18 15:47:07 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-18 15:47:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:47:07 --> Model Class Initialized
INFO - 2023-07-18 15:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:47:07 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:07 --> Total execution time: 0.0276
ERROR - 2023-07-18 15:47:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:10 --> Config Class Initialized
INFO - 2023-07-18 15:47:10 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:10 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:10 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:10 --> URI Class Initialized
INFO - 2023-07-18 15:47:10 --> Router Class Initialized
INFO - 2023-07-18 15:47:10 --> Output Class Initialized
INFO - 2023-07-18 15:47:10 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:10 --> Input Class Initialized
INFO - 2023-07-18 15:47:10 --> Language Class Initialized
INFO - 2023-07-18 15:47:10 --> Loader Class Initialized
INFO - 2023-07-18 15:47:10 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:10 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:10 --> Parser Class Initialized
INFO - 2023-07-18 15:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:10 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:10 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:10 --> Controller Class Initialized
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
INFO - 2023-07-18 15:47:10 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:10 --> Total execution time: 0.0187
ERROR - 2023-07-18 15:47:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:10 --> Config Class Initialized
INFO - 2023-07-18 15:47:10 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:10 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:10 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:10 --> URI Class Initialized
DEBUG - 2023-07-18 15:47:10 --> No URI present. Default controller set.
INFO - 2023-07-18 15:47:10 --> Router Class Initialized
INFO - 2023-07-18 15:47:10 --> Output Class Initialized
INFO - 2023-07-18 15:47:10 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:10 --> Input Class Initialized
INFO - 2023-07-18 15:47:10 --> Language Class Initialized
INFO - 2023-07-18 15:47:10 --> Loader Class Initialized
INFO - 2023-07-18 15:47:10 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:10 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:10 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:10 --> Parser Class Initialized
INFO - 2023-07-18 15:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:10 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:10 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:10 --> Controller Class Initialized
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
INFO - 2023-07-18 15:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 15:47:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:47:10 --> Model Class Initialized
INFO - 2023-07-18 15:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:47:11 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:11 --> Total execution time: 0.1773
ERROR - 2023-07-18 15:47:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:11 --> Config Class Initialized
INFO - 2023-07-18 15:47:11 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:11 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:11 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:11 --> URI Class Initialized
INFO - 2023-07-18 15:47:11 --> Router Class Initialized
INFO - 2023-07-18 15:47:11 --> Output Class Initialized
INFO - 2023-07-18 15:47:11 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:11 --> Input Class Initialized
INFO - 2023-07-18 15:47:11 --> Language Class Initialized
INFO - 2023-07-18 15:47:11 --> Loader Class Initialized
INFO - 2023-07-18 15:47:11 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:11 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:11 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:11 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:11 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:11 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:11 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:11 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:11 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:11 --> Parser Class Initialized
INFO - 2023-07-18 15:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:11 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:11 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:11 --> Controller Class Initialized
DEBUG - 2023-07-18 15:47:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:11 --> Model Class Initialized
INFO - 2023-07-18 15:47:11 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:11 --> Total execution time: 0.0124
ERROR - 2023-07-18 15:47:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:28 --> Config Class Initialized
INFO - 2023-07-18 15:47:28 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:28 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:28 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:28 --> URI Class Initialized
DEBUG - 2023-07-18 15:47:28 --> No URI present. Default controller set.
INFO - 2023-07-18 15:47:28 --> Router Class Initialized
INFO - 2023-07-18 15:47:28 --> Output Class Initialized
INFO - 2023-07-18 15:47:28 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:28 --> Input Class Initialized
INFO - 2023-07-18 15:47:28 --> Language Class Initialized
INFO - 2023-07-18 15:47:28 --> Loader Class Initialized
INFO - 2023-07-18 15:47:28 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:28 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:28 --> Parser Class Initialized
INFO - 2023-07-18 15:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:28 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:28 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:28 --> Controller Class Initialized
INFO - 2023-07-18 15:47:28 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-18 15:47:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:28 --> Config Class Initialized
INFO - 2023-07-18 15:47:28 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:28 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:28 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:28 --> URI Class Initialized
INFO - 2023-07-18 15:47:28 --> Router Class Initialized
INFO - 2023-07-18 15:47:28 --> Output Class Initialized
INFO - 2023-07-18 15:47:28 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:28 --> Input Class Initialized
INFO - 2023-07-18 15:47:28 --> Language Class Initialized
INFO - 2023-07-18 15:47:28 --> Loader Class Initialized
INFO - 2023-07-18 15:47:28 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:28 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:28 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:28 --> Parser Class Initialized
INFO - 2023-07-18 15:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:28 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:28 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:28 --> Controller Class Initialized
INFO - 2023-07-18 15:47:28 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-18 15:47:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:47:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:47:28 --> Model Class Initialized
INFO - 2023-07-18 15:47:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:47:28 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:28 --> Total execution time: 0.0325
ERROR - 2023-07-18 15:47:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:33 --> Config Class Initialized
INFO - 2023-07-18 15:47:33 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:33 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:33 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:33 --> URI Class Initialized
INFO - 2023-07-18 15:47:33 --> Router Class Initialized
INFO - 2023-07-18 15:47:33 --> Output Class Initialized
INFO - 2023-07-18 15:47:33 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:33 --> Input Class Initialized
INFO - 2023-07-18 15:47:33 --> Language Class Initialized
INFO - 2023-07-18 15:47:33 --> Loader Class Initialized
INFO - 2023-07-18 15:47:33 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:33 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:33 --> Parser Class Initialized
INFO - 2023-07-18 15:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:33 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:33 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:33 --> Controller Class Initialized
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
INFO - 2023-07-18 15:47:33 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:33 --> Total execution time: 0.0198
ERROR - 2023-07-18 15:47:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:33 --> Config Class Initialized
INFO - 2023-07-18 15:47:33 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:33 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:33 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:33 --> URI Class Initialized
DEBUG - 2023-07-18 15:47:33 --> No URI present. Default controller set.
INFO - 2023-07-18 15:47:33 --> Router Class Initialized
INFO - 2023-07-18 15:47:33 --> Output Class Initialized
INFO - 2023-07-18 15:47:33 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:33 --> Input Class Initialized
INFO - 2023-07-18 15:47:33 --> Language Class Initialized
INFO - 2023-07-18 15:47:33 --> Loader Class Initialized
INFO - 2023-07-18 15:47:33 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:33 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:33 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:33 --> Parser Class Initialized
INFO - 2023-07-18 15:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:33 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:33 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:33 --> Controller Class Initialized
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
INFO - 2023-07-18 15:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 15:47:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:47:33 --> Model Class Initialized
INFO - 2023-07-18 15:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:47:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:47:33 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:33 --> Total execution time: 0.0882
ERROR - 2023-07-18 15:47:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:47:38 --> Config Class Initialized
INFO - 2023-07-18 15:47:38 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:47:38 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:47:38 --> Utf8 Class Initialized
INFO - 2023-07-18 15:47:38 --> URI Class Initialized
INFO - 2023-07-18 15:47:38 --> Router Class Initialized
INFO - 2023-07-18 15:47:38 --> Output Class Initialized
INFO - 2023-07-18 15:47:38 --> Security Class Initialized
DEBUG - 2023-07-18 15:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:47:38 --> Input Class Initialized
INFO - 2023-07-18 15:47:38 --> Language Class Initialized
INFO - 2023-07-18 15:47:38 --> Loader Class Initialized
INFO - 2023-07-18 15:47:38 --> Helper loaded: url_helper
INFO - 2023-07-18 15:47:38 --> Helper loaded: file_helper
INFO - 2023-07-18 15:47:38 --> Helper loaded: html_helper
INFO - 2023-07-18 15:47:38 --> Helper loaded: text_helper
INFO - 2023-07-18 15:47:38 --> Helper loaded: form_helper
INFO - 2023-07-18 15:47:38 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:47:38 --> Helper loaded: security_helper
INFO - 2023-07-18 15:47:38 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:47:38 --> Database Driver Class Initialized
INFO - 2023-07-18 15:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:47:38 --> Parser Class Initialized
INFO - 2023-07-18 15:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:47:38 --> Pagination Class Initialized
INFO - 2023-07-18 15:47:38 --> Form Validation Class Initialized
INFO - 2023-07-18 15:47:38 --> Controller Class Initialized
DEBUG - 2023-07-18 15:47:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:38 --> Model Class Initialized
DEBUG - 2023-07-18 15:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:38 --> Model Class Initialized
INFO - 2023-07-18 15:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-18 15:47:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:47:38 --> Model Class Initialized
INFO - 2023-07-18 15:47:38 --> Model Class Initialized
INFO - 2023-07-18 15:47:38 --> Model Class Initialized
INFO - 2023-07-18 15:47:38 --> Model Class Initialized
INFO - 2023-07-18 15:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:47:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:47:38 --> Final output sent to browser
DEBUG - 2023-07-18 15:47:38 --> Total execution time: 0.0954
ERROR - 2023-07-18 15:49:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:49:36 --> Config Class Initialized
INFO - 2023-07-18 15:49:36 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:49:36 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:49:36 --> Utf8 Class Initialized
INFO - 2023-07-18 15:49:36 --> URI Class Initialized
INFO - 2023-07-18 15:49:36 --> Router Class Initialized
INFO - 2023-07-18 15:49:36 --> Output Class Initialized
INFO - 2023-07-18 15:49:36 --> Security Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:49:36 --> Input Class Initialized
INFO - 2023-07-18 15:49:36 --> Language Class Initialized
INFO - 2023-07-18 15:49:36 --> Loader Class Initialized
INFO - 2023-07-18 15:49:36 --> Helper loaded: url_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: file_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: html_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: text_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: form_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: security_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:49:36 --> Database Driver Class Initialized
INFO - 2023-07-18 15:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:49:36 --> Parser Class Initialized
INFO - 2023-07-18 15:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:49:36 --> Pagination Class Initialized
INFO - 2023-07-18 15:49:36 --> Form Validation Class Initialized
INFO - 2023-07-18 15:49:36 --> Controller Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:36 --> Email Class Initialized
INFO - 2023-07-18 15:49:36 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-07-18 15:49:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:49:36 --> Config Class Initialized
INFO - 2023-07-18 15:49:36 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:49:36 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:49:36 --> Utf8 Class Initialized
INFO - 2023-07-18 15:49:36 --> URI Class Initialized
INFO - 2023-07-18 15:49:36 --> Router Class Initialized
INFO - 2023-07-18 15:49:36 --> Output Class Initialized
INFO - 2023-07-18 15:49:36 --> Security Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:49:36 --> Input Class Initialized
INFO - 2023-07-18 15:49:36 --> Language Class Initialized
INFO - 2023-07-18 15:49:36 --> Loader Class Initialized
INFO - 2023-07-18 15:49:36 --> Helper loaded: url_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: file_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: html_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: text_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: form_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: security_helper
INFO - 2023-07-18 15:49:36 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:49:36 --> Database Driver Class Initialized
INFO - 2023-07-18 15:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:49:36 --> Parser Class Initialized
INFO - 2023-07-18 15:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:49:36 --> Pagination Class Initialized
INFO - 2023-07-18 15:49:36 --> Form Validation Class Initialized
INFO - 2023-07-18 15:49:36 --> Controller Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:36 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
INFO - 2023-07-18 15:49:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 15:49:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:49:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
INFO - 2023-07-18 15:49:36 --> Model Class Initialized
INFO - 2023-07-18 15:49:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:49:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:49:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:49:36 --> Final output sent to browser
DEBUG - 2023-07-18 15:49:36 --> Total execution time: 0.0789
ERROR - 2023-07-18 15:49:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:49:37 --> Config Class Initialized
INFO - 2023-07-18 15:49:37 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:49:37 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:49:37 --> Utf8 Class Initialized
INFO - 2023-07-18 15:49:37 --> URI Class Initialized
INFO - 2023-07-18 15:49:37 --> Router Class Initialized
INFO - 2023-07-18 15:49:37 --> Output Class Initialized
INFO - 2023-07-18 15:49:37 --> Security Class Initialized
DEBUG - 2023-07-18 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:49:37 --> Input Class Initialized
INFO - 2023-07-18 15:49:37 --> Language Class Initialized
INFO - 2023-07-18 15:49:37 --> Loader Class Initialized
INFO - 2023-07-18 15:49:37 --> Helper loaded: url_helper
INFO - 2023-07-18 15:49:37 --> Helper loaded: file_helper
INFO - 2023-07-18 15:49:37 --> Helper loaded: html_helper
INFO - 2023-07-18 15:49:37 --> Helper loaded: text_helper
INFO - 2023-07-18 15:49:37 --> Helper loaded: form_helper
INFO - 2023-07-18 15:49:37 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:49:37 --> Helper loaded: security_helper
INFO - 2023-07-18 15:49:37 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:49:37 --> Database Driver Class Initialized
INFO - 2023-07-18 15:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:49:37 --> Parser Class Initialized
INFO - 2023-07-18 15:49:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:49:37 --> Pagination Class Initialized
INFO - 2023-07-18 15:49:37 --> Form Validation Class Initialized
INFO - 2023-07-18 15:49:37 --> Controller Class Initialized
DEBUG - 2023-07-18 15:49:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:37 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:37 --> Model Class Initialized
INFO - 2023-07-18 15:49:37 --> Final output sent to browser
DEBUG - 2023-07-18 15:49:37 --> Total execution time: 0.0207
ERROR - 2023-07-18 15:49:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:49:49 --> Config Class Initialized
INFO - 2023-07-18 15:49:49 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:49:49 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:49:49 --> Utf8 Class Initialized
INFO - 2023-07-18 15:49:49 --> URI Class Initialized
INFO - 2023-07-18 15:49:49 --> Router Class Initialized
INFO - 2023-07-18 15:49:49 --> Output Class Initialized
INFO - 2023-07-18 15:49:49 --> Security Class Initialized
DEBUG - 2023-07-18 15:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:49:49 --> Input Class Initialized
INFO - 2023-07-18 15:49:49 --> Language Class Initialized
INFO - 2023-07-18 15:49:49 --> Loader Class Initialized
INFO - 2023-07-18 15:49:49 --> Helper loaded: url_helper
INFO - 2023-07-18 15:49:49 --> Helper loaded: file_helper
INFO - 2023-07-18 15:49:49 --> Helper loaded: html_helper
INFO - 2023-07-18 15:49:49 --> Helper loaded: text_helper
INFO - 2023-07-18 15:49:49 --> Helper loaded: form_helper
INFO - 2023-07-18 15:49:49 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:49:49 --> Helper loaded: security_helper
INFO - 2023-07-18 15:49:49 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:49:49 --> Database Driver Class Initialized
INFO - 2023-07-18 15:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:49:49 --> Parser Class Initialized
INFO - 2023-07-18 15:49:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:49:49 --> Pagination Class Initialized
INFO - 2023-07-18 15:49:49 --> Form Validation Class Initialized
INFO - 2023-07-18 15:49:49 --> Controller Class Initialized
DEBUG - 2023-07-18 15:49:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:49 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:49 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:49 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:49 --> Model Class Initialized
INFO - 2023-07-18 15:49:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 15:49:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:49:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:49:49 --> Model Class Initialized
INFO - 2023-07-18 15:49:49 --> Model Class Initialized
INFO - 2023-07-18 15:49:49 --> Model Class Initialized
INFO - 2023-07-18 15:49:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:49:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:49:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:49:49 --> Final output sent to browser
DEBUG - 2023-07-18 15:49:49 --> Total execution time: 0.1440
ERROR - 2023-07-18 15:49:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:49:50 --> Config Class Initialized
INFO - 2023-07-18 15:49:50 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:49:50 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:49:50 --> Utf8 Class Initialized
INFO - 2023-07-18 15:49:50 --> URI Class Initialized
INFO - 2023-07-18 15:49:50 --> Router Class Initialized
INFO - 2023-07-18 15:49:50 --> Output Class Initialized
INFO - 2023-07-18 15:49:50 --> Security Class Initialized
DEBUG - 2023-07-18 15:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:49:50 --> Input Class Initialized
INFO - 2023-07-18 15:49:50 --> Language Class Initialized
INFO - 2023-07-18 15:49:50 --> Loader Class Initialized
INFO - 2023-07-18 15:49:50 --> Helper loaded: url_helper
INFO - 2023-07-18 15:49:50 --> Helper loaded: file_helper
INFO - 2023-07-18 15:49:50 --> Helper loaded: html_helper
INFO - 2023-07-18 15:49:50 --> Helper loaded: text_helper
INFO - 2023-07-18 15:49:50 --> Helper loaded: form_helper
INFO - 2023-07-18 15:49:50 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:49:50 --> Helper loaded: security_helper
INFO - 2023-07-18 15:49:50 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:49:50 --> Database Driver Class Initialized
INFO - 2023-07-18 15:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:49:50 --> Parser Class Initialized
INFO - 2023-07-18 15:49:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:49:50 --> Pagination Class Initialized
INFO - 2023-07-18 15:49:50 --> Form Validation Class Initialized
INFO - 2023-07-18 15:49:50 --> Controller Class Initialized
DEBUG - 2023-07-18 15:49:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:50 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:50 --> Model Class Initialized
INFO - 2023-07-18 15:49:50 --> Final output sent to browser
DEBUG - 2023-07-18 15:49:50 --> Total execution time: 0.0299
ERROR - 2023-07-18 15:49:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:49:57 --> Config Class Initialized
INFO - 2023-07-18 15:49:57 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:49:57 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:49:57 --> Utf8 Class Initialized
INFO - 2023-07-18 15:49:57 --> URI Class Initialized
INFO - 2023-07-18 15:49:57 --> Router Class Initialized
INFO - 2023-07-18 15:49:57 --> Output Class Initialized
INFO - 2023-07-18 15:49:57 --> Security Class Initialized
DEBUG - 2023-07-18 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:49:57 --> Input Class Initialized
INFO - 2023-07-18 15:49:57 --> Language Class Initialized
INFO - 2023-07-18 15:49:57 --> Loader Class Initialized
INFO - 2023-07-18 15:49:57 --> Helper loaded: url_helper
INFO - 2023-07-18 15:49:57 --> Helper loaded: file_helper
INFO - 2023-07-18 15:49:57 --> Helper loaded: html_helper
INFO - 2023-07-18 15:49:57 --> Helper loaded: text_helper
INFO - 2023-07-18 15:49:57 --> Helper loaded: form_helper
INFO - 2023-07-18 15:49:57 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:49:57 --> Helper loaded: security_helper
INFO - 2023-07-18 15:49:57 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:49:57 --> Database Driver Class Initialized
INFO - 2023-07-18 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:49:57 --> Parser Class Initialized
INFO - 2023-07-18 15:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:49:57 --> Pagination Class Initialized
INFO - 2023-07-18 15:49:57 --> Form Validation Class Initialized
INFO - 2023-07-18 15:49:57 --> Controller Class Initialized
DEBUG - 2023-07-18 15:49:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:57 --> Model Class Initialized
DEBUG - 2023-07-18 15:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:49:57 --> Model Class Initialized
INFO - 2023-07-18 15:49:57 --> Final output sent to browser
DEBUG - 2023-07-18 15:49:57 --> Total execution time: 0.1213
ERROR - 2023-07-18 15:50:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:01 --> Config Class Initialized
INFO - 2023-07-18 15:50:01 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:01 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:01 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:01 --> URI Class Initialized
INFO - 2023-07-18 15:50:01 --> Router Class Initialized
INFO - 2023-07-18 15:50:01 --> Output Class Initialized
INFO - 2023-07-18 15:50:01 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:01 --> Input Class Initialized
INFO - 2023-07-18 15:50:01 --> Language Class Initialized
INFO - 2023-07-18 15:50:01 --> Loader Class Initialized
INFO - 2023-07-18 15:50:01 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:02 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:02 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:02 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:02 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:02 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:02 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:02 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:02 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:02 --> Parser Class Initialized
INFO - 2023-07-18 15:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:02 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:02 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:02 --> Controller Class Initialized
DEBUG - 2023-07-18 15:50:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:02 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:02 --> Model Class Initialized
INFO - 2023-07-18 15:50:02 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:02 --> Total execution time: 0.0196
ERROR - 2023-07-18 15:50:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:12 --> Config Class Initialized
INFO - 2023-07-18 15:50:12 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:12 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:12 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:12 --> URI Class Initialized
DEBUG - 2023-07-18 15:50:12 --> No URI present. Default controller set.
INFO - 2023-07-18 15:50:12 --> Router Class Initialized
INFO - 2023-07-18 15:50:12 --> Output Class Initialized
INFO - 2023-07-18 15:50:12 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:12 --> Input Class Initialized
INFO - 2023-07-18 15:50:12 --> Language Class Initialized
INFO - 2023-07-18 15:50:12 --> Loader Class Initialized
INFO - 2023-07-18 15:50:12 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:12 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:12 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:12 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:12 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:12 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:12 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:12 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:12 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:12 --> Parser Class Initialized
INFO - 2023-07-18 15:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:12 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:12 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:12 --> Controller Class Initialized
INFO - 2023-07-18 15:50:12 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:12 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:12 --> Model Class Initialized
INFO - 2023-07-18 15:50:12 --> Model Class Initialized
INFO - 2023-07-18 15:50:12 --> Model Class Initialized
INFO - 2023-07-18 15:50:12 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:12 --> Model Class Initialized
INFO - 2023-07-18 15:50:13 --> Model Class Initialized
INFO - 2023-07-18 15:50:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 15:50:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:50:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:50:13 --> Model Class Initialized
INFO - 2023-07-18 15:50:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:50:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:50:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:50:13 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:13 --> Total execution time: 0.0887
ERROR - 2023-07-18 15:50:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:16 --> Config Class Initialized
INFO - 2023-07-18 15:50:16 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:16 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:16 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:16 --> URI Class Initialized
INFO - 2023-07-18 15:50:16 --> Router Class Initialized
INFO - 2023-07-18 15:50:16 --> Output Class Initialized
INFO - 2023-07-18 15:50:16 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:16 --> Input Class Initialized
INFO - 2023-07-18 15:50:16 --> Language Class Initialized
INFO - 2023-07-18 15:50:16 --> Loader Class Initialized
INFO - 2023-07-18 15:50:16 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:16 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:16 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:16 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:16 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:16 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:16 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:16 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:16 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:16 --> Parser Class Initialized
INFO - 2023-07-18 15:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:16 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:16 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:16 --> Controller Class Initialized
INFO - 2023-07-18 15:50:16 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:16 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:16 --> Model Class Initialized
INFO - 2023-07-18 15:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-18 15:50:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:50:16 --> Model Class Initialized
INFO - 2023-07-18 15:50:16 --> Model Class Initialized
INFO - 2023-07-18 15:50:16 --> Model Class Initialized
INFO - 2023-07-18 15:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:50:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:50:16 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:16 --> Total execution time: 0.1063
ERROR - 2023-07-18 15:50:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:21 --> Config Class Initialized
INFO - 2023-07-18 15:50:21 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:21 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:21 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:21 --> URI Class Initialized
INFO - 2023-07-18 15:50:21 --> Router Class Initialized
INFO - 2023-07-18 15:50:21 --> Output Class Initialized
INFO - 2023-07-18 15:50:21 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:21 --> Input Class Initialized
INFO - 2023-07-18 15:50:21 --> Language Class Initialized
INFO - 2023-07-18 15:50:21 --> Loader Class Initialized
INFO - 2023-07-18 15:50:21 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:21 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:21 --> Parser Class Initialized
INFO - 2023-07-18 15:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:21 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:21 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:21 --> Controller Class Initialized
INFO - 2023-07-18 15:50:21 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:21 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:21 --> Total execution time: 0.0171
ERROR - 2023-07-18 15:50:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:21 --> Config Class Initialized
INFO - 2023-07-18 15:50:21 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:21 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:21 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:21 --> URI Class Initialized
INFO - 2023-07-18 15:50:21 --> Router Class Initialized
INFO - 2023-07-18 15:50:21 --> Output Class Initialized
INFO - 2023-07-18 15:50:21 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:21 --> Input Class Initialized
INFO - 2023-07-18 15:50:21 --> Language Class Initialized
INFO - 2023-07-18 15:50:21 --> Loader Class Initialized
INFO - 2023-07-18 15:50:21 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:21 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:21 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:21 --> Parser Class Initialized
INFO - 2023-07-18 15:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:21 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:21 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:21 --> Controller Class Initialized
INFO - 2023-07-18 15:50:21 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:21 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:21 --> Total execution time: 0.0166
ERROR - 2023-07-18 15:50:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:22 --> Config Class Initialized
INFO - 2023-07-18 15:50:22 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:22 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:22 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:22 --> URI Class Initialized
INFO - 2023-07-18 15:50:22 --> Router Class Initialized
INFO - 2023-07-18 15:50:22 --> Output Class Initialized
INFO - 2023-07-18 15:50:22 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:22 --> Input Class Initialized
INFO - 2023-07-18 15:50:22 --> Language Class Initialized
INFO - 2023-07-18 15:50:22 --> Loader Class Initialized
INFO - 2023-07-18 15:50:22 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:22 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:22 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:22 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:22 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:22 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:22 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:22 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:22 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:22 --> Parser Class Initialized
INFO - 2023-07-18 15:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:22 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:22 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:22 --> Controller Class Initialized
INFO - 2023-07-18 15:50:22 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-18 15:50:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-07-18 15:50:22 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:22 --> Total execution time: 0.0155
ERROR - 2023-07-18 15:50:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:52 --> Config Class Initialized
INFO - 2023-07-18 15:50:52 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:52 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:52 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:52 --> URI Class Initialized
INFO - 2023-07-18 15:50:52 --> Router Class Initialized
INFO - 2023-07-18 15:50:52 --> Output Class Initialized
INFO - 2023-07-18 15:50:52 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:52 --> Input Class Initialized
INFO - 2023-07-18 15:50:52 --> Language Class Initialized
INFO - 2023-07-18 15:50:52 --> Loader Class Initialized
INFO - 2023-07-18 15:50:52 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:52 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:52 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:52 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:52 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:52 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:52 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:52 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:52 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:52 --> Parser Class Initialized
INFO - 2023-07-18 15:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:52 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:52 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:52 --> Controller Class Initialized
INFO - 2023-07-18 15:50:52 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:52 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:52 --> Total execution time: 0.0184
ERROR - 2023-07-18 15:50:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:53 --> Config Class Initialized
INFO - 2023-07-18 15:50:53 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:53 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:53 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:53 --> URI Class Initialized
INFO - 2023-07-18 15:50:53 --> Router Class Initialized
INFO - 2023-07-18 15:50:53 --> Output Class Initialized
INFO - 2023-07-18 15:50:53 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:53 --> Input Class Initialized
INFO - 2023-07-18 15:50:53 --> Language Class Initialized
INFO - 2023-07-18 15:50:53 --> Loader Class Initialized
INFO - 2023-07-18 15:50:53 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:53 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:53 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:53 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:53 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:53 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:53 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:53 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:53 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:53 --> Parser Class Initialized
INFO - 2023-07-18 15:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:53 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:53 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:53 --> Controller Class Initialized
INFO - 2023-07-18 15:50:53 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:53 --> Total execution time: 0.0143
ERROR - 2023-07-18 15:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:56 --> Config Class Initialized
INFO - 2023-07-18 15:50:56 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:56 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:56 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:56 --> URI Class Initialized
INFO - 2023-07-18 15:50:56 --> Router Class Initialized
INFO - 2023-07-18 15:50:56 --> Output Class Initialized
INFO - 2023-07-18 15:50:56 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:56 --> Input Class Initialized
INFO - 2023-07-18 15:50:56 --> Language Class Initialized
INFO - 2023-07-18 15:50:56 --> Loader Class Initialized
INFO - 2023-07-18 15:50:56 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:56 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:56 --> Parser Class Initialized
INFO - 2023-07-18 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:56 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:56 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:56 --> Controller Class Initialized
INFO - 2023-07-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:56 --> Model Class Initialized
INFO - 2023-07-18 15:50:56 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:56 --> Total execution time: 0.0434
ERROR - 2023-07-18 15:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:56 --> Config Class Initialized
INFO - 2023-07-18 15:50:56 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:56 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:56 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:56 --> URI Class Initialized
INFO - 2023-07-18 15:50:56 --> Router Class Initialized
INFO - 2023-07-18 15:50:56 --> Output Class Initialized
INFO - 2023-07-18 15:50:56 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:56 --> Input Class Initialized
INFO - 2023-07-18 15:50:56 --> Language Class Initialized
INFO - 2023-07-18 15:50:56 --> Loader Class Initialized
INFO - 2023-07-18 15:50:56 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:56 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:56 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:56 --> Parser Class Initialized
INFO - 2023-07-18 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:56 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:56 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:56 --> Controller Class Initialized
INFO - 2023-07-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:56 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:56 --> Model Class Initialized
INFO - 2023-07-18 15:50:56 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:56 --> Total execution time: 0.0401
ERROR - 2023-07-18 15:50:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:50:59 --> Config Class Initialized
INFO - 2023-07-18 15:50:59 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:50:59 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:50:59 --> Utf8 Class Initialized
INFO - 2023-07-18 15:50:59 --> URI Class Initialized
INFO - 2023-07-18 15:50:59 --> Router Class Initialized
INFO - 2023-07-18 15:50:59 --> Output Class Initialized
INFO - 2023-07-18 15:50:59 --> Security Class Initialized
DEBUG - 2023-07-18 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:50:59 --> Input Class Initialized
INFO - 2023-07-18 15:50:59 --> Language Class Initialized
INFO - 2023-07-18 15:50:59 --> Loader Class Initialized
INFO - 2023-07-18 15:50:59 --> Helper loaded: url_helper
INFO - 2023-07-18 15:50:59 --> Helper loaded: file_helper
INFO - 2023-07-18 15:50:59 --> Helper loaded: html_helper
INFO - 2023-07-18 15:50:59 --> Helper loaded: text_helper
INFO - 2023-07-18 15:50:59 --> Helper loaded: form_helper
INFO - 2023-07-18 15:50:59 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:50:59 --> Helper loaded: security_helper
INFO - 2023-07-18 15:50:59 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:50:59 --> Database Driver Class Initialized
INFO - 2023-07-18 15:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:50:59 --> Parser Class Initialized
INFO - 2023-07-18 15:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:50:59 --> Pagination Class Initialized
INFO - 2023-07-18 15:50:59 --> Form Validation Class Initialized
INFO - 2023-07-18 15:50:59 --> Controller Class Initialized
INFO - 2023-07-18 15:50:59 --> Model Class Initialized
DEBUG - 2023-07-18 15:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:50:59 --> Model Class Initialized
INFO - 2023-07-18 15:50:59 --> Model Class Initialized
INFO - 2023-07-18 15:50:59 --> Final output sent to browser
DEBUG - 2023-07-18 15:50:59 --> Total execution time: 0.0192
ERROR - 2023-07-18 15:51:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:51:04 --> Config Class Initialized
INFO - 2023-07-18 15:51:04 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:51:04 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:51:04 --> Utf8 Class Initialized
INFO - 2023-07-18 15:51:04 --> URI Class Initialized
INFO - 2023-07-18 15:51:04 --> Router Class Initialized
INFO - 2023-07-18 15:51:04 --> Output Class Initialized
INFO - 2023-07-18 15:51:04 --> Security Class Initialized
DEBUG - 2023-07-18 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:51:04 --> Input Class Initialized
INFO - 2023-07-18 15:51:04 --> Language Class Initialized
INFO - 2023-07-18 15:51:04 --> Loader Class Initialized
INFO - 2023-07-18 15:51:04 --> Helper loaded: url_helper
INFO - 2023-07-18 15:51:04 --> Helper loaded: file_helper
INFO - 2023-07-18 15:51:04 --> Helper loaded: html_helper
INFO - 2023-07-18 15:51:04 --> Helper loaded: text_helper
INFO - 2023-07-18 15:51:04 --> Helper loaded: form_helper
INFO - 2023-07-18 15:51:04 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:51:04 --> Helper loaded: security_helper
INFO - 2023-07-18 15:51:04 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:51:04 --> Database Driver Class Initialized
INFO - 2023-07-18 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:51:04 --> Parser Class Initialized
INFO - 2023-07-18 15:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:51:04 --> Pagination Class Initialized
INFO - 2023-07-18 15:51:04 --> Form Validation Class Initialized
INFO - 2023-07-18 15:51:04 --> Controller Class Initialized
INFO - 2023-07-18 15:51:04 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:04 --> Model Class Initialized
INFO - 2023-07-18 15:51:04 --> Final output sent to browser
DEBUG - 2023-07-18 15:51:04 --> Total execution time: 0.0170
ERROR - 2023-07-18 15:51:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:51:18 --> Config Class Initialized
INFO - 2023-07-18 15:51:18 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:51:18 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:51:18 --> Utf8 Class Initialized
INFO - 2023-07-18 15:51:18 --> URI Class Initialized
INFO - 2023-07-18 15:51:18 --> Router Class Initialized
INFO - 2023-07-18 15:51:18 --> Output Class Initialized
INFO - 2023-07-18 15:51:18 --> Security Class Initialized
DEBUG - 2023-07-18 15:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:51:18 --> Input Class Initialized
INFO - 2023-07-18 15:51:18 --> Language Class Initialized
INFO - 2023-07-18 15:51:18 --> Loader Class Initialized
INFO - 2023-07-18 15:51:18 --> Helper loaded: url_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: file_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: html_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: text_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: form_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: security_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:51:18 --> Database Driver Class Initialized
INFO - 2023-07-18 15:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:51:18 --> Parser Class Initialized
INFO - 2023-07-18 15:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:51:18 --> Pagination Class Initialized
INFO - 2023-07-18 15:51:18 --> Form Validation Class Initialized
INFO - 2023-07-18 15:51:18 --> Controller Class Initialized
INFO - 2023-07-18 15:51:18 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:18 --> Final output sent to browser
DEBUG - 2023-07-18 15:51:18 --> Total execution time: 0.0152
ERROR - 2023-07-18 15:51:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:51:18 --> Config Class Initialized
INFO - 2023-07-18 15:51:18 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:51:18 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:51:18 --> Utf8 Class Initialized
INFO - 2023-07-18 15:51:18 --> URI Class Initialized
INFO - 2023-07-18 15:51:18 --> Router Class Initialized
INFO - 2023-07-18 15:51:18 --> Output Class Initialized
INFO - 2023-07-18 15:51:18 --> Security Class Initialized
DEBUG - 2023-07-18 15:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:51:18 --> Input Class Initialized
INFO - 2023-07-18 15:51:18 --> Language Class Initialized
INFO - 2023-07-18 15:51:18 --> Loader Class Initialized
INFO - 2023-07-18 15:51:18 --> Helper loaded: url_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: file_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: html_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: text_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: form_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: security_helper
INFO - 2023-07-18 15:51:18 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:51:18 --> Database Driver Class Initialized
INFO - 2023-07-18 15:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:51:18 --> Parser Class Initialized
INFO - 2023-07-18 15:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:51:18 --> Pagination Class Initialized
INFO - 2023-07-18 15:51:18 --> Form Validation Class Initialized
INFO - 2023-07-18 15:51:18 --> Controller Class Initialized
INFO - 2023-07-18 15:51:18 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-18 15:51:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:51:18 --> Model Class Initialized
INFO - 2023-07-18 15:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:51:18 --> Final output sent to browser
DEBUG - 2023-07-18 15:51:18 --> Total execution time: 0.0316
ERROR - 2023-07-18 15:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:51:24 --> Config Class Initialized
INFO - 2023-07-18 15:51:24 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:51:24 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:51:24 --> Utf8 Class Initialized
INFO - 2023-07-18 15:51:24 --> URI Class Initialized
INFO - 2023-07-18 15:51:24 --> Router Class Initialized
INFO - 2023-07-18 15:51:24 --> Output Class Initialized
INFO - 2023-07-18 15:51:24 --> Security Class Initialized
DEBUG - 2023-07-18 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:51:24 --> Input Class Initialized
INFO - 2023-07-18 15:51:24 --> Language Class Initialized
INFO - 2023-07-18 15:51:24 --> Loader Class Initialized
INFO - 2023-07-18 15:51:24 --> Helper loaded: url_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: file_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: html_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: text_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: form_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: security_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:51:24 --> Database Driver Class Initialized
INFO - 2023-07-18 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:51:24 --> Parser Class Initialized
INFO - 2023-07-18 15:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:51:24 --> Pagination Class Initialized
INFO - 2023-07-18 15:51:24 --> Form Validation Class Initialized
INFO - 2023-07-18 15:51:24 --> Controller Class Initialized
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
INFO - 2023-07-18 15:51:24 --> Final output sent to browser
DEBUG - 2023-07-18 15:51:24 --> Total execution time: 0.0180
ERROR - 2023-07-18 15:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:51:24 --> Config Class Initialized
INFO - 2023-07-18 15:51:24 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:51:24 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:51:24 --> Utf8 Class Initialized
INFO - 2023-07-18 15:51:24 --> URI Class Initialized
DEBUG - 2023-07-18 15:51:24 --> No URI present. Default controller set.
INFO - 2023-07-18 15:51:24 --> Router Class Initialized
INFO - 2023-07-18 15:51:24 --> Output Class Initialized
INFO - 2023-07-18 15:51:24 --> Security Class Initialized
DEBUG - 2023-07-18 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:51:24 --> Input Class Initialized
INFO - 2023-07-18 15:51:24 --> Language Class Initialized
INFO - 2023-07-18 15:51:24 --> Loader Class Initialized
INFO - 2023-07-18 15:51:24 --> Helper loaded: url_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: file_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: html_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: text_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: form_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: security_helper
INFO - 2023-07-18 15:51:24 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:51:24 --> Database Driver Class Initialized
INFO - 2023-07-18 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:51:24 --> Parser Class Initialized
INFO - 2023-07-18 15:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:51:24 --> Pagination Class Initialized
INFO - 2023-07-18 15:51:24 --> Form Validation Class Initialized
INFO - 2023-07-18 15:51:24 --> Controller Class Initialized
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
INFO - 2023-07-18 15:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 15:51:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:51:24 --> Model Class Initialized
INFO - 2023-07-18 15:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:51:24 --> Final output sent to browser
DEBUG - 2023-07-18 15:51:24 --> Total execution time: 0.0806
ERROR - 2023-07-18 15:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:51:28 --> Config Class Initialized
INFO - 2023-07-18 15:51:28 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:51:28 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:51:28 --> Utf8 Class Initialized
INFO - 2023-07-18 15:51:28 --> URI Class Initialized
INFO - 2023-07-18 15:51:28 --> Router Class Initialized
INFO - 2023-07-18 15:51:28 --> Output Class Initialized
INFO - 2023-07-18 15:51:28 --> Security Class Initialized
DEBUG - 2023-07-18 15:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:51:28 --> Input Class Initialized
INFO - 2023-07-18 15:51:28 --> Language Class Initialized
INFO - 2023-07-18 15:51:28 --> Loader Class Initialized
INFO - 2023-07-18 15:51:28 --> Helper loaded: url_helper
INFO - 2023-07-18 15:51:28 --> Helper loaded: file_helper
INFO - 2023-07-18 15:51:28 --> Helper loaded: html_helper
INFO - 2023-07-18 15:51:28 --> Helper loaded: text_helper
INFO - 2023-07-18 15:51:28 --> Helper loaded: form_helper
INFO - 2023-07-18 15:51:28 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:51:28 --> Helper loaded: security_helper
INFO - 2023-07-18 15:51:28 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:51:28 --> Database Driver Class Initialized
INFO - 2023-07-18 15:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:51:28 --> Parser Class Initialized
INFO - 2023-07-18 15:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:51:28 --> Pagination Class Initialized
INFO - 2023-07-18 15:51:28 --> Form Validation Class Initialized
INFO - 2023-07-18 15:51:28 --> Controller Class Initialized
DEBUG - 2023-07-18 15:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:28 --> Model Class Initialized
DEBUG - 2023-07-18 15:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:28 --> Model Class Initialized
INFO - 2023-07-18 15:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-07-18 15:51:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:51:28 --> Model Class Initialized
INFO - 2023-07-18 15:51:28 --> Model Class Initialized
INFO - 2023-07-18 15:51:28 --> Model Class Initialized
INFO - 2023-07-18 15:51:28 --> Model Class Initialized
INFO - 2023-07-18 15:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:51:28 --> Final output sent to browser
DEBUG - 2023-07-18 15:51:28 --> Total execution time: 0.1036
ERROR - 2023-07-18 15:52:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:52:52 --> Config Class Initialized
INFO - 2023-07-18 15:52:52 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:52:52 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:52:52 --> Utf8 Class Initialized
INFO - 2023-07-18 15:52:52 --> URI Class Initialized
INFO - 2023-07-18 15:52:52 --> Router Class Initialized
INFO - 2023-07-18 15:52:52 --> Output Class Initialized
INFO - 2023-07-18 15:52:52 --> Security Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:52:52 --> Input Class Initialized
INFO - 2023-07-18 15:52:52 --> Language Class Initialized
INFO - 2023-07-18 15:52:52 --> Loader Class Initialized
INFO - 2023-07-18 15:52:52 --> Helper loaded: url_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: file_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: html_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: text_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: form_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: security_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:52:52 --> Database Driver Class Initialized
INFO - 2023-07-18 15:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:52:52 --> Parser Class Initialized
INFO - 2023-07-18 15:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:52:52 --> Pagination Class Initialized
INFO - 2023-07-18 15:52:52 --> Form Validation Class Initialized
INFO - 2023-07-18 15:52:52 --> Controller Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:52 --> Email Class Initialized
INFO - 2023-07-18 15:52:52 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-07-18 15:52:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:52:52 --> Config Class Initialized
INFO - 2023-07-18 15:52:52 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:52:52 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:52:52 --> Utf8 Class Initialized
INFO - 2023-07-18 15:52:52 --> URI Class Initialized
INFO - 2023-07-18 15:52:52 --> Router Class Initialized
INFO - 2023-07-18 15:52:52 --> Output Class Initialized
INFO - 2023-07-18 15:52:52 --> Security Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:52:52 --> Input Class Initialized
INFO - 2023-07-18 15:52:52 --> Language Class Initialized
INFO - 2023-07-18 15:52:52 --> Loader Class Initialized
INFO - 2023-07-18 15:52:52 --> Helper loaded: url_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: file_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: html_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: text_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: form_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: security_helper
INFO - 2023-07-18 15:52:52 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:52:52 --> Database Driver Class Initialized
INFO - 2023-07-18 15:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:52:52 --> Parser Class Initialized
INFO - 2023-07-18 15:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:52:52 --> Pagination Class Initialized
INFO - 2023-07-18 15:52:52 --> Form Validation Class Initialized
INFO - 2023-07-18 15:52:52 --> Controller Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
DEBUG - 2023-07-18 15:52:52 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
INFO - 2023-07-18 15:52:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 15:52:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:52:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
INFO - 2023-07-18 15:52:52 --> Model Class Initialized
INFO - 2023-07-18 15:52:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:52:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:52:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:52:52 --> Final output sent to browser
DEBUG - 2023-07-18 15:52:52 --> Total execution time: 0.0741
ERROR - 2023-07-18 15:52:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:52:53 --> Config Class Initialized
INFO - 2023-07-18 15:52:53 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:52:53 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:52:53 --> Utf8 Class Initialized
INFO - 2023-07-18 15:52:53 --> URI Class Initialized
INFO - 2023-07-18 15:52:53 --> Router Class Initialized
INFO - 2023-07-18 15:52:53 --> Output Class Initialized
INFO - 2023-07-18 15:52:53 --> Security Class Initialized
DEBUG - 2023-07-18 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:52:53 --> Input Class Initialized
INFO - 2023-07-18 15:52:53 --> Language Class Initialized
INFO - 2023-07-18 15:52:53 --> Loader Class Initialized
INFO - 2023-07-18 15:52:53 --> Helper loaded: url_helper
INFO - 2023-07-18 15:52:53 --> Helper loaded: file_helper
INFO - 2023-07-18 15:52:53 --> Helper loaded: html_helper
INFO - 2023-07-18 15:52:53 --> Helper loaded: text_helper
INFO - 2023-07-18 15:52:53 --> Helper loaded: form_helper
INFO - 2023-07-18 15:52:53 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:52:53 --> Helper loaded: security_helper
INFO - 2023-07-18 15:52:53 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:52:53 --> Database Driver Class Initialized
INFO - 2023-07-18 15:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:52:53 --> Parser Class Initialized
INFO - 2023-07-18 15:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:52:53 --> Pagination Class Initialized
INFO - 2023-07-18 15:52:53 --> Form Validation Class Initialized
INFO - 2023-07-18 15:52:53 --> Controller Class Initialized
DEBUG - 2023-07-18 15:52:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:53 --> Model Class Initialized
DEBUG - 2023-07-18 15:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:52:53 --> Model Class Initialized
INFO - 2023-07-18 15:52:53 --> Final output sent to browser
DEBUG - 2023-07-18 15:52:53 --> Total execution time: 0.0205
ERROR - 2023-07-18 15:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:53:10 --> Config Class Initialized
INFO - 2023-07-18 15:53:10 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:53:10 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:53:10 --> Utf8 Class Initialized
INFO - 2023-07-18 15:53:10 --> URI Class Initialized
INFO - 2023-07-18 15:53:10 --> Router Class Initialized
INFO - 2023-07-18 15:53:10 --> Output Class Initialized
INFO - 2023-07-18 15:53:10 --> Security Class Initialized
DEBUG - 2023-07-18 15:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:53:10 --> Input Class Initialized
INFO - 2023-07-18 15:53:10 --> Language Class Initialized
INFO - 2023-07-18 15:53:10 --> Loader Class Initialized
INFO - 2023-07-18 15:53:10 --> Helper loaded: url_helper
INFO - 2023-07-18 15:53:10 --> Helper loaded: file_helper
INFO - 2023-07-18 15:53:10 --> Helper loaded: html_helper
INFO - 2023-07-18 15:53:10 --> Helper loaded: text_helper
INFO - 2023-07-18 15:53:10 --> Helper loaded: form_helper
INFO - 2023-07-18 15:53:10 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:53:10 --> Helper loaded: security_helper
INFO - 2023-07-18 15:53:10 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:53:10 --> Database Driver Class Initialized
INFO - 2023-07-18 15:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:53:10 --> Parser Class Initialized
INFO - 2023-07-18 15:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:53:10 --> Pagination Class Initialized
INFO - 2023-07-18 15:53:10 --> Form Validation Class Initialized
INFO - 2023-07-18 15:53:10 --> Controller Class Initialized
DEBUG - 2023-07-18 15:53:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:10 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:10 --> Model Class Initialized
INFO - 2023-07-18 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 15:53:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:53:10 --> Model Class Initialized
INFO - 2023-07-18 15:53:10 --> Model Class Initialized
INFO - 2023-07-18 15:53:10 --> Model Class Initialized
INFO - 2023-07-18 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:53:10 --> Final output sent to browser
DEBUG - 2023-07-18 15:53:10 --> Total execution time: 0.1330
ERROR - 2023-07-18 15:53:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:53:11 --> Config Class Initialized
INFO - 2023-07-18 15:53:11 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:53:11 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:53:11 --> Utf8 Class Initialized
INFO - 2023-07-18 15:53:11 --> URI Class Initialized
INFO - 2023-07-18 15:53:11 --> Router Class Initialized
INFO - 2023-07-18 15:53:11 --> Output Class Initialized
INFO - 2023-07-18 15:53:11 --> Security Class Initialized
DEBUG - 2023-07-18 15:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:53:11 --> Input Class Initialized
INFO - 2023-07-18 15:53:11 --> Language Class Initialized
INFO - 2023-07-18 15:53:11 --> Loader Class Initialized
INFO - 2023-07-18 15:53:11 --> Helper loaded: url_helper
INFO - 2023-07-18 15:53:11 --> Helper loaded: file_helper
INFO - 2023-07-18 15:53:11 --> Helper loaded: html_helper
INFO - 2023-07-18 15:53:11 --> Helper loaded: text_helper
INFO - 2023-07-18 15:53:11 --> Helper loaded: form_helper
INFO - 2023-07-18 15:53:11 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:53:11 --> Helper loaded: security_helper
INFO - 2023-07-18 15:53:11 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:53:11 --> Database Driver Class Initialized
INFO - 2023-07-18 15:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:53:11 --> Parser Class Initialized
INFO - 2023-07-18 15:53:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:53:11 --> Pagination Class Initialized
INFO - 2023-07-18 15:53:11 --> Form Validation Class Initialized
INFO - 2023-07-18 15:53:11 --> Controller Class Initialized
DEBUG - 2023-07-18 15:53:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:11 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:11 --> Model Class Initialized
INFO - 2023-07-18 15:53:11 --> Final output sent to browser
DEBUG - 2023-07-18 15:53:11 --> Total execution time: 0.0335
ERROR - 2023-07-18 15:53:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:53:17 --> Config Class Initialized
INFO - 2023-07-18 15:53:17 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:53:17 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:53:17 --> Utf8 Class Initialized
INFO - 2023-07-18 15:53:17 --> URI Class Initialized
INFO - 2023-07-18 15:53:17 --> Router Class Initialized
INFO - 2023-07-18 15:53:17 --> Output Class Initialized
INFO - 2023-07-18 15:53:17 --> Security Class Initialized
DEBUG - 2023-07-18 15:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:53:17 --> Input Class Initialized
INFO - 2023-07-18 15:53:17 --> Language Class Initialized
INFO - 2023-07-18 15:53:17 --> Loader Class Initialized
INFO - 2023-07-18 15:53:17 --> Helper loaded: url_helper
INFO - 2023-07-18 15:53:17 --> Helper loaded: file_helper
INFO - 2023-07-18 15:53:17 --> Helper loaded: html_helper
INFO - 2023-07-18 15:53:17 --> Helper loaded: text_helper
INFO - 2023-07-18 15:53:17 --> Helper loaded: form_helper
INFO - 2023-07-18 15:53:17 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:53:17 --> Helper loaded: security_helper
INFO - 2023-07-18 15:53:17 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:53:17 --> Database Driver Class Initialized
INFO - 2023-07-18 15:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:53:17 --> Parser Class Initialized
INFO - 2023-07-18 15:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:53:17 --> Pagination Class Initialized
INFO - 2023-07-18 15:53:17 --> Form Validation Class Initialized
INFO - 2023-07-18 15:53:17 --> Controller Class Initialized
DEBUG - 2023-07-18 15:53:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:17 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:17 --> Model Class Initialized
INFO - 2023-07-18 15:53:17 --> Final output sent to browser
DEBUG - 2023-07-18 15:53:17 --> Total execution time: 0.1144
ERROR - 2023-07-18 15:53:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:53:21 --> Config Class Initialized
INFO - 2023-07-18 15:53:21 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:53:21 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:53:21 --> Utf8 Class Initialized
INFO - 2023-07-18 15:53:21 --> URI Class Initialized
INFO - 2023-07-18 15:53:21 --> Router Class Initialized
INFO - 2023-07-18 15:53:21 --> Output Class Initialized
INFO - 2023-07-18 15:53:21 --> Security Class Initialized
DEBUG - 2023-07-18 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:53:21 --> Input Class Initialized
INFO - 2023-07-18 15:53:21 --> Language Class Initialized
INFO - 2023-07-18 15:53:21 --> Loader Class Initialized
INFO - 2023-07-18 15:53:21 --> Helper loaded: url_helper
INFO - 2023-07-18 15:53:21 --> Helper loaded: file_helper
INFO - 2023-07-18 15:53:21 --> Helper loaded: html_helper
INFO - 2023-07-18 15:53:21 --> Helper loaded: text_helper
INFO - 2023-07-18 15:53:21 --> Helper loaded: form_helper
INFO - 2023-07-18 15:53:21 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:53:21 --> Helper loaded: security_helper
INFO - 2023-07-18 15:53:21 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:53:21 --> Database Driver Class Initialized
INFO - 2023-07-18 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:53:21 --> Parser Class Initialized
INFO - 2023-07-18 15:53:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:53:21 --> Pagination Class Initialized
INFO - 2023-07-18 15:53:21 --> Form Validation Class Initialized
INFO - 2023-07-18 15:53:21 --> Controller Class Initialized
DEBUG - 2023-07-18 15:53:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:21 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:21 --> Model Class Initialized
INFO - 2023-07-18 15:53:21 --> Final output sent to browser
DEBUG - 2023-07-18 15:53:21 --> Total execution time: 0.0187
ERROR - 2023-07-18 15:53:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:53:28 --> Config Class Initialized
INFO - 2023-07-18 15:53:28 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:53:28 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:53:28 --> Utf8 Class Initialized
INFO - 2023-07-18 15:53:28 --> URI Class Initialized
DEBUG - 2023-07-18 15:53:28 --> No URI present. Default controller set.
INFO - 2023-07-18 15:53:28 --> Router Class Initialized
INFO - 2023-07-18 15:53:28 --> Output Class Initialized
INFO - 2023-07-18 15:53:28 --> Security Class Initialized
DEBUG - 2023-07-18 15:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:53:28 --> Input Class Initialized
INFO - 2023-07-18 15:53:28 --> Language Class Initialized
INFO - 2023-07-18 15:53:28 --> Loader Class Initialized
INFO - 2023-07-18 15:53:28 --> Helper loaded: url_helper
INFO - 2023-07-18 15:53:28 --> Helper loaded: file_helper
INFO - 2023-07-18 15:53:28 --> Helper loaded: html_helper
INFO - 2023-07-18 15:53:28 --> Helper loaded: text_helper
INFO - 2023-07-18 15:53:28 --> Helper loaded: form_helper
INFO - 2023-07-18 15:53:28 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:53:28 --> Helper loaded: security_helper
INFO - 2023-07-18 15:53:28 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:53:28 --> Database Driver Class Initialized
INFO - 2023-07-18 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:53:28 --> Parser Class Initialized
INFO - 2023-07-18 15:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:53:28 --> Pagination Class Initialized
INFO - 2023-07-18 15:53:28 --> Form Validation Class Initialized
INFO - 2023-07-18 15:53:28 --> Controller Class Initialized
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
INFO - 2023-07-18 15:53:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 15:53:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:53:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:53:28 --> Model Class Initialized
INFO - 2023-07-18 15:53:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:53:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:53:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:53:28 --> Final output sent to browser
DEBUG - 2023-07-18 15:53:28 --> Total execution time: 0.0819
ERROR - 2023-07-18 15:53:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:53:33 --> Config Class Initialized
INFO - 2023-07-18 15:53:33 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:53:33 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:53:33 --> Utf8 Class Initialized
INFO - 2023-07-18 15:53:33 --> URI Class Initialized
INFO - 2023-07-18 15:53:33 --> Router Class Initialized
INFO - 2023-07-18 15:53:33 --> Output Class Initialized
INFO - 2023-07-18 15:53:33 --> Security Class Initialized
DEBUG - 2023-07-18 15:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:53:33 --> Input Class Initialized
INFO - 2023-07-18 15:53:33 --> Language Class Initialized
INFO - 2023-07-18 15:53:33 --> Loader Class Initialized
INFO - 2023-07-18 15:53:33 --> Helper loaded: url_helper
INFO - 2023-07-18 15:53:33 --> Helper loaded: file_helper
INFO - 2023-07-18 15:53:33 --> Helper loaded: html_helper
INFO - 2023-07-18 15:53:33 --> Helper loaded: text_helper
INFO - 2023-07-18 15:53:33 --> Helper loaded: form_helper
INFO - 2023-07-18 15:53:33 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:53:33 --> Helper loaded: security_helper
INFO - 2023-07-18 15:53:33 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:53:33 --> Database Driver Class Initialized
INFO - 2023-07-18 15:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:53:33 --> Parser Class Initialized
INFO - 2023-07-18 15:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:53:33 --> Pagination Class Initialized
INFO - 2023-07-18 15:53:33 --> Form Validation Class Initialized
INFO - 2023-07-18 15:53:33 --> Controller Class Initialized
INFO - 2023-07-18 15:53:33 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:33 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:33 --> Model Class Initialized
INFO - 2023-07-18 15:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-18 15:53:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:53:33 --> Model Class Initialized
INFO - 2023-07-18 15:53:33 --> Model Class Initialized
INFO - 2023-07-18 15:53:33 --> Model Class Initialized
INFO - 2023-07-18 15:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:53:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:53:33 --> Final output sent to browser
DEBUG - 2023-07-18 15:53:33 --> Total execution time: 0.0937
ERROR - 2023-07-18 15:53:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:53:37 --> Config Class Initialized
INFO - 2023-07-18 15:53:37 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:53:37 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:53:37 --> Utf8 Class Initialized
INFO - 2023-07-18 15:53:37 --> URI Class Initialized
DEBUG - 2023-07-18 15:53:37 --> No URI present. Default controller set.
INFO - 2023-07-18 15:53:37 --> Router Class Initialized
INFO - 2023-07-18 15:53:37 --> Output Class Initialized
INFO - 2023-07-18 15:53:37 --> Security Class Initialized
DEBUG - 2023-07-18 15:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:53:37 --> Input Class Initialized
INFO - 2023-07-18 15:53:37 --> Language Class Initialized
INFO - 2023-07-18 15:53:37 --> Loader Class Initialized
INFO - 2023-07-18 15:53:37 --> Helper loaded: url_helper
INFO - 2023-07-18 15:53:37 --> Helper loaded: file_helper
INFO - 2023-07-18 15:53:37 --> Helper loaded: html_helper
INFO - 2023-07-18 15:53:37 --> Helper loaded: text_helper
INFO - 2023-07-18 15:53:37 --> Helper loaded: form_helper
INFO - 2023-07-18 15:53:37 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:53:37 --> Helper loaded: security_helper
INFO - 2023-07-18 15:53:37 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:53:37 --> Database Driver Class Initialized
INFO - 2023-07-18 15:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:53:37 --> Parser Class Initialized
INFO - 2023-07-18 15:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:53:37 --> Pagination Class Initialized
INFO - 2023-07-18 15:53:37 --> Form Validation Class Initialized
INFO - 2023-07-18 15:53:37 --> Controller Class Initialized
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
DEBUG - 2023-07-18 15:53:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
INFO - 2023-07-18 15:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 15:53:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:53:37 --> Model Class Initialized
INFO - 2023-07-18 15:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:53:37 --> Final output sent to browser
DEBUG - 2023-07-18 15:53:37 --> Total execution time: 0.0935
ERROR - 2023-07-18 15:55:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:55:47 --> Config Class Initialized
INFO - 2023-07-18 15:55:47 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:55:47 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:55:47 --> Utf8 Class Initialized
INFO - 2023-07-18 15:55:47 --> URI Class Initialized
INFO - 2023-07-18 15:55:47 --> Router Class Initialized
INFO - 2023-07-18 15:55:47 --> Output Class Initialized
INFO - 2023-07-18 15:55:47 --> Security Class Initialized
DEBUG - 2023-07-18 15:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:55:47 --> Input Class Initialized
INFO - 2023-07-18 15:55:47 --> Language Class Initialized
INFO - 2023-07-18 15:55:47 --> Loader Class Initialized
INFO - 2023-07-18 15:55:47 --> Helper loaded: url_helper
INFO - 2023-07-18 15:55:47 --> Helper loaded: file_helper
INFO - 2023-07-18 15:55:47 --> Helper loaded: html_helper
INFO - 2023-07-18 15:55:47 --> Helper loaded: text_helper
INFO - 2023-07-18 15:55:47 --> Helper loaded: form_helper
INFO - 2023-07-18 15:55:47 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:55:47 --> Helper loaded: security_helper
INFO - 2023-07-18 15:55:47 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:55:47 --> Database Driver Class Initialized
INFO - 2023-07-18 15:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:55:47 --> Parser Class Initialized
INFO - 2023-07-18 15:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:55:47 --> Pagination Class Initialized
INFO - 2023-07-18 15:55:47 --> Form Validation Class Initialized
INFO - 2023-07-18 15:55:47 --> Controller Class Initialized
DEBUG - 2023-07-18 15:55:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:47 --> Model Class Initialized
DEBUG - 2023-07-18 15:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:47 --> Model Class Initialized
DEBUG - 2023-07-18 15:55:47 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:47 --> Model Class Initialized
INFO - 2023-07-18 15:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 15:55:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:55:47 --> Model Class Initialized
INFO - 2023-07-18 15:55:47 --> Model Class Initialized
INFO - 2023-07-18 15:55:47 --> Model Class Initialized
INFO - 2023-07-18 15:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:55:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:55:47 --> Final output sent to browser
DEBUG - 2023-07-18 15:55:47 --> Total execution time: 0.1300
ERROR - 2023-07-18 15:55:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:55:48 --> Config Class Initialized
INFO - 2023-07-18 15:55:48 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:55:48 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:55:48 --> Utf8 Class Initialized
INFO - 2023-07-18 15:55:48 --> URI Class Initialized
INFO - 2023-07-18 15:55:48 --> Router Class Initialized
INFO - 2023-07-18 15:55:48 --> Output Class Initialized
INFO - 2023-07-18 15:55:48 --> Security Class Initialized
DEBUG - 2023-07-18 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:55:48 --> Input Class Initialized
INFO - 2023-07-18 15:55:48 --> Language Class Initialized
INFO - 2023-07-18 15:55:48 --> Loader Class Initialized
INFO - 2023-07-18 15:55:48 --> Helper loaded: url_helper
INFO - 2023-07-18 15:55:48 --> Helper loaded: file_helper
INFO - 2023-07-18 15:55:48 --> Helper loaded: html_helper
INFO - 2023-07-18 15:55:48 --> Helper loaded: text_helper
INFO - 2023-07-18 15:55:48 --> Helper loaded: form_helper
INFO - 2023-07-18 15:55:48 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:55:48 --> Helper loaded: security_helper
INFO - 2023-07-18 15:55:48 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:55:48 --> Database Driver Class Initialized
INFO - 2023-07-18 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:55:48 --> Parser Class Initialized
INFO - 2023-07-18 15:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:55:48 --> Pagination Class Initialized
INFO - 2023-07-18 15:55:48 --> Form Validation Class Initialized
INFO - 2023-07-18 15:55:48 --> Controller Class Initialized
DEBUG - 2023-07-18 15:55:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:48 --> Model Class Initialized
DEBUG - 2023-07-18 15:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:48 --> Model Class Initialized
INFO - 2023-07-18 15:55:48 --> Final output sent to browser
DEBUG - 2023-07-18 15:55:48 --> Total execution time: 0.0313
ERROR - 2023-07-18 15:55:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:55:52 --> Config Class Initialized
INFO - 2023-07-18 15:55:52 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:55:52 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:55:52 --> Utf8 Class Initialized
INFO - 2023-07-18 15:55:52 --> URI Class Initialized
INFO - 2023-07-18 15:55:52 --> Router Class Initialized
INFO - 2023-07-18 15:55:52 --> Output Class Initialized
INFO - 2023-07-18 15:55:52 --> Security Class Initialized
DEBUG - 2023-07-18 15:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:55:52 --> Input Class Initialized
INFO - 2023-07-18 15:55:52 --> Language Class Initialized
INFO - 2023-07-18 15:55:52 --> Loader Class Initialized
INFO - 2023-07-18 15:55:52 --> Helper loaded: url_helper
INFO - 2023-07-18 15:55:52 --> Helper loaded: file_helper
INFO - 2023-07-18 15:55:52 --> Helper loaded: html_helper
INFO - 2023-07-18 15:55:52 --> Helper loaded: text_helper
INFO - 2023-07-18 15:55:52 --> Helper loaded: form_helper
INFO - 2023-07-18 15:55:52 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:55:52 --> Helper loaded: security_helper
INFO - 2023-07-18 15:55:52 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:55:52 --> Database Driver Class Initialized
INFO - 2023-07-18 15:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:55:52 --> Parser Class Initialized
INFO - 2023-07-18 15:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:55:52 --> Pagination Class Initialized
INFO - 2023-07-18 15:55:52 --> Form Validation Class Initialized
INFO - 2023-07-18 15:55:52 --> Controller Class Initialized
DEBUG - 2023-07-18 15:55:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:52 --> Model Class Initialized
DEBUG - 2023-07-18 15:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:55:52 --> Model Class Initialized
INFO - 2023-07-18 15:55:52 --> Final output sent to browser
DEBUG - 2023-07-18 15:55:52 --> Total execution time: 0.1263
ERROR - 2023-07-18 15:56:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:56:09 --> Config Class Initialized
INFO - 2023-07-18 15:56:09 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:56:09 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:56:09 --> Utf8 Class Initialized
INFO - 2023-07-18 15:56:09 --> URI Class Initialized
INFO - 2023-07-18 15:56:09 --> Router Class Initialized
INFO - 2023-07-18 15:56:09 --> Output Class Initialized
INFO - 2023-07-18 15:56:09 --> Security Class Initialized
DEBUG - 2023-07-18 15:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:56:09 --> Input Class Initialized
INFO - 2023-07-18 15:56:09 --> Language Class Initialized
INFO - 2023-07-18 15:56:09 --> Loader Class Initialized
INFO - 2023-07-18 15:56:09 --> Helper loaded: url_helper
INFO - 2023-07-18 15:56:09 --> Helper loaded: file_helper
INFO - 2023-07-18 15:56:09 --> Helper loaded: html_helper
INFO - 2023-07-18 15:56:09 --> Helper loaded: text_helper
INFO - 2023-07-18 15:56:09 --> Helper loaded: form_helper
INFO - 2023-07-18 15:56:09 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:56:09 --> Helper loaded: security_helper
INFO - 2023-07-18 15:56:09 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:56:10 --> Database Driver Class Initialized
INFO - 2023-07-18 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:56:10 --> Parser Class Initialized
INFO - 2023-07-18 15:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:56:10 --> Pagination Class Initialized
INFO - 2023-07-18 15:56:10 --> Form Validation Class Initialized
INFO - 2023-07-18 15:56:10 --> Controller Class Initialized
INFO - 2023-07-18 15:56:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:10 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:10 --> Model Class Initialized
INFO - 2023-07-18 15:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-18 15:56:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:56:10 --> Model Class Initialized
INFO - 2023-07-18 15:56:10 --> Model Class Initialized
INFO - 2023-07-18 15:56:10 --> Model Class Initialized
INFO - 2023-07-18 15:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:56:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:56:10 --> Final output sent to browser
DEBUG - 2023-07-18 15:56:10 --> Total execution time: 0.1102
ERROR - 2023-07-18 15:56:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:56:13 --> Config Class Initialized
INFO - 2023-07-18 15:56:13 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:56:13 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:56:13 --> Utf8 Class Initialized
INFO - 2023-07-18 15:56:13 --> URI Class Initialized
INFO - 2023-07-18 15:56:13 --> Router Class Initialized
INFO - 2023-07-18 15:56:13 --> Output Class Initialized
INFO - 2023-07-18 15:56:13 --> Security Class Initialized
DEBUG - 2023-07-18 15:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:56:13 --> Input Class Initialized
INFO - 2023-07-18 15:56:13 --> Language Class Initialized
INFO - 2023-07-18 15:56:13 --> Loader Class Initialized
INFO - 2023-07-18 15:56:13 --> Helper loaded: url_helper
INFO - 2023-07-18 15:56:13 --> Helper loaded: file_helper
INFO - 2023-07-18 15:56:13 --> Helper loaded: html_helper
INFO - 2023-07-18 15:56:13 --> Helper loaded: text_helper
INFO - 2023-07-18 15:56:13 --> Helper loaded: form_helper
INFO - 2023-07-18 15:56:13 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:56:13 --> Helper loaded: security_helper
INFO - 2023-07-18 15:56:13 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:56:13 --> Database Driver Class Initialized
INFO - 2023-07-18 15:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:56:13 --> Parser Class Initialized
INFO - 2023-07-18 15:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:56:13 --> Pagination Class Initialized
INFO - 2023-07-18 15:56:13 --> Form Validation Class Initialized
INFO - 2023-07-18 15:56:13 --> Controller Class Initialized
INFO - 2023-07-18 15:56:13 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:13 --> Final output sent to browser
DEBUG - 2023-07-18 15:56:13 --> Total execution time: 0.0163
ERROR - 2023-07-18 15:56:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:56:14 --> Config Class Initialized
INFO - 2023-07-18 15:56:14 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:56:14 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:56:14 --> Utf8 Class Initialized
INFO - 2023-07-18 15:56:14 --> URI Class Initialized
INFO - 2023-07-18 15:56:14 --> Router Class Initialized
INFO - 2023-07-18 15:56:14 --> Output Class Initialized
INFO - 2023-07-18 15:56:14 --> Security Class Initialized
DEBUG - 2023-07-18 15:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:56:14 --> Input Class Initialized
INFO - 2023-07-18 15:56:14 --> Language Class Initialized
INFO - 2023-07-18 15:56:14 --> Loader Class Initialized
INFO - 2023-07-18 15:56:14 --> Helper loaded: url_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: file_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: html_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: text_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: form_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: security_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:56:14 --> Database Driver Class Initialized
INFO - 2023-07-18 15:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:56:14 --> Parser Class Initialized
INFO - 2023-07-18 15:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:56:14 --> Pagination Class Initialized
INFO - 2023-07-18 15:56:14 --> Form Validation Class Initialized
INFO - 2023-07-18 15:56:14 --> Controller Class Initialized
INFO - 2023-07-18 15:56:14 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:14 --> Final output sent to browser
DEBUG - 2023-07-18 15:56:14 --> Total execution time: 0.0154
ERROR - 2023-07-18 15:56:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:56:14 --> Config Class Initialized
INFO - 2023-07-18 15:56:14 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:56:14 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:56:14 --> Utf8 Class Initialized
INFO - 2023-07-18 15:56:14 --> URI Class Initialized
INFO - 2023-07-18 15:56:14 --> Router Class Initialized
INFO - 2023-07-18 15:56:14 --> Output Class Initialized
INFO - 2023-07-18 15:56:14 --> Security Class Initialized
DEBUG - 2023-07-18 15:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:56:14 --> Input Class Initialized
INFO - 2023-07-18 15:56:14 --> Language Class Initialized
INFO - 2023-07-18 15:56:14 --> Loader Class Initialized
INFO - 2023-07-18 15:56:14 --> Helper loaded: url_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: file_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: html_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: text_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: form_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: security_helper
INFO - 2023-07-18 15:56:14 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:56:14 --> Database Driver Class Initialized
INFO - 2023-07-18 15:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:56:14 --> Parser Class Initialized
INFO - 2023-07-18 15:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:56:14 --> Pagination Class Initialized
INFO - 2023-07-18 15:56:14 --> Form Validation Class Initialized
INFO - 2023-07-18 15:56:14 --> Controller Class Initialized
INFO - 2023-07-18 15:56:14 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:14 --> Final output sent to browser
DEBUG - 2023-07-18 15:56:14 --> Total execution time: 0.0157
ERROR - 2023-07-18 15:56:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:56:15 --> Config Class Initialized
INFO - 2023-07-18 15:56:15 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:56:15 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:56:15 --> Utf8 Class Initialized
INFO - 2023-07-18 15:56:15 --> URI Class Initialized
INFO - 2023-07-18 15:56:15 --> Router Class Initialized
INFO - 2023-07-18 15:56:15 --> Output Class Initialized
INFO - 2023-07-18 15:56:15 --> Security Class Initialized
DEBUG - 2023-07-18 15:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:56:15 --> Input Class Initialized
INFO - 2023-07-18 15:56:15 --> Language Class Initialized
INFO - 2023-07-18 15:56:15 --> Loader Class Initialized
INFO - 2023-07-18 15:56:15 --> Helper loaded: url_helper
INFO - 2023-07-18 15:56:15 --> Helper loaded: file_helper
INFO - 2023-07-18 15:56:15 --> Helper loaded: html_helper
INFO - 2023-07-18 15:56:15 --> Helper loaded: text_helper
INFO - 2023-07-18 15:56:15 --> Helper loaded: form_helper
INFO - 2023-07-18 15:56:15 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:56:15 --> Helper loaded: security_helper
INFO - 2023-07-18 15:56:15 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:56:15 --> Database Driver Class Initialized
INFO - 2023-07-18 15:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:56:15 --> Parser Class Initialized
INFO - 2023-07-18 15:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:56:15 --> Pagination Class Initialized
INFO - 2023-07-18 15:56:15 --> Form Validation Class Initialized
INFO - 2023-07-18 15:56:15 --> Controller Class Initialized
INFO - 2023-07-18 15:56:15 --> Final output sent to browser
DEBUG - 2023-07-18 15:56:15 --> Total execution time: 0.0156
ERROR - 2023-07-18 15:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:56:18 --> Config Class Initialized
INFO - 2023-07-18 15:56:18 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:56:18 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:56:18 --> Utf8 Class Initialized
INFO - 2023-07-18 15:56:18 --> URI Class Initialized
INFO - 2023-07-18 15:56:18 --> Router Class Initialized
INFO - 2023-07-18 15:56:18 --> Output Class Initialized
INFO - 2023-07-18 15:56:18 --> Security Class Initialized
DEBUG - 2023-07-18 15:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:56:18 --> Input Class Initialized
INFO - 2023-07-18 15:56:18 --> Language Class Initialized
INFO - 2023-07-18 15:56:18 --> Loader Class Initialized
INFO - 2023-07-18 15:56:18 --> Helper loaded: url_helper
INFO - 2023-07-18 15:56:18 --> Helper loaded: file_helper
INFO - 2023-07-18 15:56:18 --> Helper loaded: html_helper
INFO - 2023-07-18 15:56:18 --> Helper loaded: text_helper
INFO - 2023-07-18 15:56:18 --> Helper loaded: form_helper
INFO - 2023-07-18 15:56:18 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:56:18 --> Helper loaded: security_helper
INFO - 2023-07-18 15:56:18 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:56:18 --> Database Driver Class Initialized
INFO - 2023-07-18 15:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:56:18 --> Parser Class Initialized
INFO - 2023-07-18 15:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:56:18 --> Pagination Class Initialized
INFO - 2023-07-18 15:56:18 --> Form Validation Class Initialized
INFO - 2023-07-18 15:56:18 --> Controller Class Initialized
INFO - 2023-07-18 15:56:18 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:18 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:18 --> Model Class Initialized
INFO - 2023-07-18 15:56:18 --> Final output sent to browser
DEBUG - 2023-07-18 15:56:18 --> Total execution time: 0.0499
ERROR - 2023-07-18 15:56:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 15:56:22 --> Config Class Initialized
INFO - 2023-07-18 15:56:22 --> Hooks Class Initialized
DEBUG - 2023-07-18 15:56:22 --> UTF-8 Support Enabled
INFO - 2023-07-18 15:56:22 --> Utf8 Class Initialized
INFO - 2023-07-18 15:56:22 --> URI Class Initialized
DEBUG - 2023-07-18 15:56:22 --> No URI present. Default controller set.
INFO - 2023-07-18 15:56:22 --> Router Class Initialized
INFO - 2023-07-18 15:56:22 --> Output Class Initialized
INFO - 2023-07-18 15:56:22 --> Security Class Initialized
DEBUG - 2023-07-18 15:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 15:56:22 --> Input Class Initialized
INFO - 2023-07-18 15:56:22 --> Language Class Initialized
INFO - 2023-07-18 15:56:22 --> Loader Class Initialized
INFO - 2023-07-18 15:56:22 --> Helper loaded: url_helper
INFO - 2023-07-18 15:56:22 --> Helper loaded: file_helper
INFO - 2023-07-18 15:56:22 --> Helper loaded: html_helper
INFO - 2023-07-18 15:56:22 --> Helper loaded: text_helper
INFO - 2023-07-18 15:56:22 --> Helper loaded: form_helper
INFO - 2023-07-18 15:56:22 --> Helper loaded: lang_helper
INFO - 2023-07-18 15:56:22 --> Helper loaded: security_helper
INFO - 2023-07-18 15:56:22 --> Helper loaded: cookie_helper
INFO - 2023-07-18 15:56:22 --> Database Driver Class Initialized
INFO - 2023-07-18 15:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 15:56:22 --> Parser Class Initialized
INFO - 2023-07-18 15:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 15:56:22 --> Pagination Class Initialized
INFO - 2023-07-18 15:56:22 --> Form Validation Class Initialized
INFO - 2023-07-18 15:56:22 --> Controller Class Initialized
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
DEBUG - 2023-07-18 15:56:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 15:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
INFO - 2023-07-18 15:56:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 15:56:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 15:56:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 15:56:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 15:56:22 --> Model Class Initialized
INFO - 2023-07-18 15:56:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 15:56:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 15:56:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 15:56:22 --> Final output sent to browser
DEBUG - 2023-07-18 15:56:22 --> Total execution time: 0.0816
ERROR - 2023-07-18 16:03:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:03:52 --> Config Class Initialized
INFO - 2023-07-18 16:03:52 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:03:52 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:03:52 --> Utf8 Class Initialized
INFO - 2023-07-18 16:03:52 --> URI Class Initialized
DEBUG - 2023-07-18 16:03:52 --> No URI present. Default controller set.
INFO - 2023-07-18 16:03:52 --> Router Class Initialized
INFO - 2023-07-18 16:03:52 --> Output Class Initialized
INFO - 2023-07-18 16:03:52 --> Security Class Initialized
DEBUG - 2023-07-18 16:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:03:52 --> Input Class Initialized
INFO - 2023-07-18 16:03:52 --> Language Class Initialized
INFO - 2023-07-18 16:03:52 --> Loader Class Initialized
INFO - 2023-07-18 16:03:52 --> Helper loaded: url_helper
INFO - 2023-07-18 16:03:52 --> Helper loaded: file_helper
INFO - 2023-07-18 16:03:52 --> Helper loaded: html_helper
INFO - 2023-07-18 16:03:52 --> Helper loaded: text_helper
INFO - 2023-07-18 16:03:52 --> Helper loaded: form_helper
INFO - 2023-07-18 16:03:52 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:03:52 --> Helper loaded: security_helper
INFO - 2023-07-18 16:03:52 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:03:52 --> Database Driver Class Initialized
INFO - 2023-07-18 16:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:03:52 --> Parser Class Initialized
INFO - 2023-07-18 16:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:03:52 --> Pagination Class Initialized
INFO - 2023-07-18 16:03:52 --> Form Validation Class Initialized
INFO - 2023-07-18 16:03:52 --> Controller Class Initialized
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
DEBUG - 2023-07-18 16:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
DEBUG - 2023-07-18 16:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
DEBUG - 2023-07-18 16:03:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
INFO - 2023-07-18 16:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 16:03:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 16:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 16:03:52 --> Model Class Initialized
INFO - 2023-07-18 16:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 16:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 16:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 16:03:52 --> Final output sent to browser
DEBUG - 2023-07-18 16:03:52 --> Total execution time: 0.0961
ERROR - 2023-07-18 16:04:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:04:10 --> Config Class Initialized
INFO - 2023-07-18 16:04:10 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:04:10 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:04:10 --> Utf8 Class Initialized
INFO - 2023-07-18 16:04:10 --> URI Class Initialized
DEBUG - 2023-07-18 16:04:10 --> No URI present. Default controller set.
INFO - 2023-07-18 16:04:10 --> Router Class Initialized
INFO - 2023-07-18 16:04:10 --> Output Class Initialized
INFO - 2023-07-18 16:04:10 --> Security Class Initialized
DEBUG - 2023-07-18 16:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:04:10 --> Input Class Initialized
INFO - 2023-07-18 16:04:10 --> Language Class Initialized
INFO - 2023-07-18 16:04:10 --> Loader Class Initialized
INFO - 2023-07-18 16:04:10 --> Helper loaded: url_helper
INFO - 2023-07-18 16:04:10 --> Helper loaded: file_helper
INFO - 2023-07-18 16:04:10 --> Helper loaded: html_helper
INFO - 2023-07-18 16:04:10 --> Helper loaded: text_helper
INFO - 2023-07-18 16:04:10 --> Helper loaded: form_helper
INFO - 2023-07-18 16:04:10 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:04:10 --> Helper loaded: security_helper
INFO - 2023-07-18 16:04:10 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:04:10 --> Database Driver Class Initialized
INFO - 2023-07-18 16:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:04:10 --> Parser Class Initialized
INFO - 2023-07-18 16:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:04:10 --> Pagination Class Initialized
INFO - 2023-07-18 16:04:10 --> Form Validation Class Initialized
INFO - 2023-07-18 16:04:10 --> Controller Class Initialized
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
DEBUG - 2023-07-18 16:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
DEBUG - 2023-07-18 16:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
DEBUG - 2023-07-18 16:04:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:04:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
INFO - 2023-07-18 16:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 16:04:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 16:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 16:04:10 --> Model Class Initialized
INFO - 2023-07-18 16:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 16:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 16:04:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 16:04:10 --> Final output sent to browser
DEBUG - 2023-07-18 16:04:10 --> Total execution time: 0.1700
ERROR - 2023-07-18 16:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:04:21 --> Config Class Initialized
INFO - 2023-07-18 16:04:21 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:04:21 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:04:21 --> Utf8 Class Initialized
INFO - 2023-07-18 16:04:21 --> URI Class Initialized
INFO - 2023-07-18 16:04:21 --> Router Class Initialized
INFO - 2023-07-18 16:04:21 --> Output Class Initialized
INFO - 2023-07-18 16:04:21 --> Security Class Initialized
DEBUG - 2023-07-18 16:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:04:21 --> Input Class Initialized
INFO - 2023-07-18 16:04:21 --> Language Class Initialized
INFO - 2023-07-18 16:04:21 --> Loader Class Initialized
INFO - 2023-07-18 16:04:21 --> Helper loaded: url_helper
INFO - 2023-07-18 16:04:21 --> Helper loaded: file_helper
INFO - 2023-07-18 16:04:21 --> Helper loaded: html_helper
INFO - 2023-07-18 16:04:21 --> Helper loaded: text_helper
INFO - 2023-07-18 16:04:21 --> Helper loaded: form_helper
INFO - 2023-07-18 16:04:21 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:04:21 --> Helper loaded: security_helper
INFO - 2023-07-18 16:04:21 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:04:21 --> Database Driver Class Initialized
INFO - 2023-07-18 16:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:04:21 --> Parser Class Initialized
INFO - 2023-07-18 16:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:04:21 --> Pagination Class Initialized
INFO - 2023-07-18 16:04:21 --> Form Validation Class Initialized
INFO - 2023-07-18 16:04:21 --> Controller Class Initialized
DEBUG - 2023-07-18 16:04:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:21 --> Model Class Initialized
DEBUG - 2023-07-18 16:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:21 --> Model Class Initialized
DEBUG - 2023-07-18 16:04:21 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:21 --> Model Class Initialized
INFO - 2023-07-18 16:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 16:04:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 16:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 16:04:21 --> Model Class Initialized
INFO - 2023-07-18 16:04:21 --> Model Class Initialized
INFO - 2023-07-18 16:04:21 --> Model Class Initialized
INFO - 2023-07-18 16:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 16:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 16:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 16:04:21 --> Final output sent to browser
DEBUG - 2023-07-18 16:04:21 --> Total execution time: 0.1407
ERROR - 2023-07-18 16:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:04:22 --> Config Class Initialized
INFO - 2023-07-18 16:04:22 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:04:22 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:04:22 --> Utf8 Class Initialized
INFO - 2023-07-18 16:04:22 --> URI Class Initialized
INFO - 2023-07-18 16:04:22 --> Router Class Initialized
INFO - 2023-07-18 16:04:22 --> Output Class Initialized
INFO - 2023-07-18 16:04:22 --> Security Class Initialized
DEBUG - 2023-07-18 16:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:04:22 --> Input Class Initialized
INFO - 2023-07-18 16:04:22 --> Language Class Initialized
INFO - 2023-07-18 16:04:22 --> Loader Class Initialized
INFO - 2023-07-18 16:04:22 --> Helper loaded: url_helper
INFO - 2023-07-18 16:04:22 --> Helper loaded: file_helper
INFO - 2023-07-18 16:04:22 --> Helper loaded: html_helper
INFO - 2023-07-18 16:04:22 --> Helper loaded: text_helper
INFO - 2023-07-18 16:04:22 --> Helper loaded: form_helper
INFO - 2023-07-18 16:04:22 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:04:22 --> Helper loaded: security_helper
INFO - 2023-07-18 16:04:22 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:04:22 --> Database Driver Class Initialized
INFO - 2023-07-18 16:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:04:22 --> Parser Class Initialized
INFO - 2023-07-18 16:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:04:22 --> Pagination Class Initialized
INFO - 2023-07-18 16:04:22 --> Form Validation Class Initialized
INFO - 2023-07-18 16:04:22 --> Controller Class Initialized
DEBUG - 2023-07-18 16:04:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:22 --> Model Class Initialized
DEBUG - 2023-07-18 16:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:22 --> Model Class Initialized
INFO - 2023-07-18 16:04:22 --> Final output sent to browser
DEBUG - 2023-07-18 16:04:22 --> Total execution time: 0.0311
ERROR - 2023-07-18 16:04:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:04:27 --> Config Class Initialized
INFO - 2023-07-18 16:04:27 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:04:27 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:04:27 --> Utf8 Class Initialized
INFO - 2023-07-18 16:04:27 --> URI Class Initialized
INFO - 2023-07-18 16:04:27 --> Router Class Initialized
INFO - 2023-07-18 16:04:27 --> Output Class Initialized
INFO - 2023-07-18 16:04:27 --> Security Class Initialized
DEBUG - 2023-07-18 16:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:04:27 --> Input Class Initialized
INFO - 2023-07-18 16:04:27 --> Language Class Initialized
INFO - 2023-07-18 16:04:27 --> Loader Class Initialized
INFO - 2023-07-18 16:04:27 --> Helper loaded: url_helper
INFO - 2023-07-18 16:04:27 --> Helper loaded: file_helper
INFO - 2023-07-18 16:04:27 --> Helper loaded: html_helper
INFO - 2023-07-18 16:04:27 --> Helper loaded: text_helper
INFO - 2023-07-18 16:04:27 --> Helper loaded: form_helper
INFO - 2023-07-18 16:04:27 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:04:27 --> Helper loaded: security_helper
INFO - 2023-07-18 16:04:27 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:04:27 --> Database Driver Class Initialized
INFO - 2023-07-18 16:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:04:27 --> Parser Class Initialized
INFO - 2023-07-18 16:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:04:27 --> Pagination Class Initialized
INFO - 2023-07-18 16:04:27 --> Form Validation Class Initialized
INFO - 2023-07-18 16:04:27 --> Controller Class Initialized
DEBUG - 2023-07-18 16:04:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:27 --> Model Class Initialized
DEBUG - 2023-07-18 16:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:04:27 --> Model Class Initialized
INFO - 2023-07-18 16:04:27 --> Final output sent to browser
DEBUG - 2023-07-18 16:04:27 --> Total execution time: 0.1163
ERROR - 2023-07-18 16:06:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:06:44 --> Config Class Initialized
INFO - 2023-07-18 16:06:44 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:06:44 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:06:44 --> Utf8 Class Initialized
INFO - 2023-07-18 16:06:44 --> URI Class Initialized
INFO - 2023-07-18 16:06:44 --> Router Class Initialized
INFO - 2023-07-18 16:06:44 --> Output Class Initialized
INFO - 2023-07-18 16:06:44 --> Security Class Initialized
DEBUG - 2023-07-18 16:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:06:44 --> Input Class Initialized
INFO - 2023-07-18 16:06:44 --> Language Class Initialized
INFO - 2023-07-18 16:06:44 --> Loader Class Initialized
INFO - 2023-07-18 16:06:44 --> Helper loaded: url_helper
INFO - 2023-07-18 16:06:44 --> Helper loaded: file_helper
INFO - 2023-07-18 16:06:44 --> Helper loaded: html_helper
INFO - 2023-07-18 16:06:44 --> Helper loaded: text_helper
INFO - 2023-07-18 16:06:44 --> Helper loaded: form_helper
INFO - 2023-07-18 16:06:44 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:06:44 --> Helper loaded: security_helper
INFO - 2023-07-18 16:06:44 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:06:44 --> Database Driver Class Initialized
INFO - 2023-07-18 16:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:06:44 --> Parser Class Initialized
INFO - 2023-07-18 16:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:06:44 --> Pagination Class Initialized
INFO - 2023-07-18 16:06:44 --> Form Validation Class Initialized
INFO - 2023-07-18 16:06:44 --> Controller Class Initialized
DEBUG - 2023-07-18 16:06:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:44 --> Model Class Initialized
DEBUG - 2023-07-18 16:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:44 --> Model Class Initialized
DEBUG - 2023-07-18 16:06:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:44 --> Model Class Initialized
INFO - 2023-07-18 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-18 16:06:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 16:06:44 --> Model Class Initialized
INFO - 2023-07-18 16:06:44 --> Model Class Initialized
INFO - 2023-07-18 16:06:44 --> Model Class Initialized
INFO - 2023-07-18 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 16:06:44 --> Final output sent to browser
DEBUG - 2023-07-18 16:06:44 --> Total execution time: 0.1415
ERROR - 2023-07-18 16:06:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:06:45 --> Config Class Initialized
INFO - 2023-07-18 16:06:45 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:06:45 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:06:45 --> Utf8 Class Initialized
INFO - 2023-07-18 16:06:45 --> URI Class Initialized
INFO - 2023-07-18 16:06:45 --> Router Class Initialized
INFO - 2023-07-18 16:06:45 --> Output Class Initialized
INFO - 2023-07-18 16:06:45 --> Security Class Initialized
DEBUG - 2023-07-18 16:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:06:45 --> Input Class Initialized
INFO - 2023-07-18 16:06:45 --> Language Class Initialized
INFO - 2023-07-18 16:06:45 --> Loader Class Initialized
INFO - 2023-07-18 16:06:45 --> Helper loaded: url_helper
INFO - 2023-07-18 16:06:45 --> Helper loaded: file_helper
INFO - 2023-07-18 16:06:45 --> Helper loaded: html_helper
INFO - 2023-07-18 16:06:45 --> Helper loaded: text_helper
INFO - 2023-07-18 16:06:45 --> Helper loaded: form_helper
INFO - 2023-07-18 16:06:45 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:06:45 --> Helper loaded: security_helper
INFO - 2023-07-18 16:06:45 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:06:45 --> Database Driver Class Initialized
INFO - 2023-07-18 16:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:06:45 --> Parser Class Initialized
INFO - 2023-07-18 16:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:06:45 --> Pagination Class Initialized
INFO - 2023-07-18 16:06:45 --> Form Validation Class Initialized
INFO - 2023-07-18 16:06:45 --> Controller Class Initialized
DEBUG - 2023-07-18 16:06:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:45 --> Model Class Initialized
DEBUG - 2023-07-18 16:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:45 --> Model Class Initialized
INFO - 2023-07-18 16:06:45 --> Final output sent to browser
DEBUG - 2023-07-18 16:06:45 --> Total execution time: 0.0325
ERROR - 2023-07-18 16:06:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:06:49 --> Config Class Initialized
INFO - 2023-07-18 16:06:49 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:06:49 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:06:49 --> Utf8 Class Initialized
INFO - 2023-07-18 16:06:49 --> URI Class Initialized
INFO - 2023-07-18 16:06:49 --> Router Class Initialized
INFO - 2023-07-18 16:06:49 --> Output Class Initialized
INFO - 2023-07-18 16:06:49 --> Security Class Initialized
DEBUG - 2023-07-18 16:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:06:49 --> Input Class Initialized
INFO - 2023-07-18 16:06:49 --> Language Class Initialized
INFO - 2023-07-18 16:06:49 --> Loader Class Initialized
INFO - 2023-07-18 16:06:49 --> Helper loaded: url_helper
INFO - 2023-07-18 16:06:49 --> Helper loaded: file_helper
INFO - 2023-07-18 16:06:49 --> Helper loaded: html_helper
INFO - 2023-07-18 16:06:49 --> Helper loaded: text_helper
INFO - 2023-07-18 16:06:49 --> Helper loaded: form_helper
INFO - 2023-07-18 16:06:49 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:06:49 --> Helper loaded: security_helper
INFO - 2023-07-18 16:06:49 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:06:49 --> Database Driver Class Initialized
INFO - 2023-07-18 16:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:06:49 --> Parser Class Initialized
INFO - 2023-07-18 16:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:06:49 --> Pagination Class Initialized
INFO - 2023-07-18 16:06:49 --> Form Validation Class Initialized
INFO - 2023-07-18 16:06:49 --> Controller Class Initialized
DEBUG - 2023-07-18 16:06:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:49 --> Model Class Initialized
DEBUG - 2023-07-18 16:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:06:49 --> Model Class Initialized
INFO - 2023-07-18 16:06:49 --> Final output sent to browser
DEBUG - 2023-07-18 16:06:49 --> Total execution time: 0.1187
ERROR - 2023-07-18 16:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:08:02 --> Config Class Initialized
INFO - 2023-07-18 16:08:02 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:08:02 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:08:02 --> Utf8 Class Initialized
INFO - 2023-07-18 16:08:02 --> URI Class Initialized
DEBUG - 2023-07-18 16:08:02 --> No URI present. Default controller set.
INFO - 2023-07-18 16:08:02 --> Router Class Initialized
INFO - 2023-07-18 16:08:02 --> Output Class Initialized
INFO - 2023-07-18 16:08:02 --> Security Class Initialized
DEBUG - 2023-07-18 16:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:08:02 --> Input Class Initialized
INFO - 2023-07-18 16:08:02 --> Language Class Initialized
INFO - 2023-07-18 16:08:02 --> Loader Class Initialized
INFO - 2023-07-18 16:08:02 --> Helper loaded: url_helper
INFO - 2023-07-18 16:08:02 --> Helper loaded: file_helper
INFO - 2023-07-18 16:08:02 --> Helper loaded: html_helper
INFO - 2023-07-18 16:08:02 --> Helper loaded: text_helper
INFO - 2023-07-18 16:08:02 --> Helper loaded: form_helper
INFO - 2023-07-18 16:08:02 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:08:02 --> Helper loaded: security_helper
INFO - 2023-07-18 16:08:02 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:08:02 --> Database Driver Class Initialized
INFO - 2023-07-18 16:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:08:02 --> Parser Class Initialized
INFO - 2023-07-18 16:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:08:02 --> Pagination Class Initialized
INFO - 2023-07-18 16:08:02 --> Form Validation Class Initialized
INFO - 2023-07-18 16:08:02 --> Controller Class Initialized
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
DEBUG - 2023-07-18 16:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
DEBUG - 2023-07-18 16:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
DEBUG - 2023-07-18 16:08:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
INFO - 2023-07-18 16:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 16:08:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 16:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 16:08:02 --> Model Class Initialized
INFO - 2023-07-18 16:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 16:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 16:08:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 16:08:02 --> Final output sent to browser
DEBUG - 2023-07-18 16:08:02 --> Total execution time: 0.1996
ERROR - 2023-07-18 16:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:09:55 --> Config Class Initialized
INFO - 2023-07-18 16:09:55 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:09:55 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:09:55 --> Utf8 Class Initialized
INFO - 2023-07-18 16:09:55 --> URI Class Initialized
INFO - 2023-07-18 16:09:55 --> Router Class Initialized
INFO - 2023-07-18 16:09:55 --> Output Class Initialized
INFO - 2023-07-18 16:09:55 --> Security Class Initialized
DEBUG - 2023-07-18 16:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:09:55 --> Input Class Initialized
INFO - 2023-07-18 16:09:55 --> Language Class Initialized
INFO - 2023-07-18 16:09:55 --> Loader Class Initialized
INFO - 2023-07-18 16:09:55 --> Helper loaded: url_helper
INFO - 2023-07-18 16:09:55 --> Helper loaded: file_helper
INFO - 2023-07-18 16:09:55 --> Helper loaded: html_helper
INFO - 2023-07-18 16:09:55 --> Helper loaded: text_helper
INFO - 2023-07-18 16:09:55 --> Helper loaded: form_helper
INFO - 2023-07-18 16:09:55 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:09:55 --> Helper loaded: security_helper
INFO - 2023-07-18 16:09:55 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:09:55 --> Database Driver Class Initialized
INFO - 2023-07-18 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:09:55 --> Parser Class Initialized
INFO - 2023-07-18 16:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:09:55 --> Pagination Class Initialized
INFO - 2023-07-18 16:09:55 --> Form Validation Class Initialized
INFO - 2023-07-18 16:09:55 --> Controller Class Initialized
INFO - 2023-07-18 16:09:55 --> Model Class Initialized
DEBUG - 2023-07-18 16:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:55 --> Model Class Initialized
DEBUG - 2023-07-18 16:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:55 --> Model Class Initialized
INFO - 2023-07-18 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-18 16:09:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 16:09:55 --> Model Class Initialized
INFO - 2023-07-18 16:09:55 --> Model Class Initialized
INFO - 2023-07-18 16:09:55 --> Model Class Initialized
INFO - 2023-07-18 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 16:09:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 16:09:55 --> Final output sent to browser
DEBUG - 2023-07-18 16:09:55 --> Total execution time: 0.1359
ERROR - 2023-07-18 16:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:09:56 --> Config Class Initialized
INFO - 2023-07-18 16:09:56 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:09:56 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:09:56 --> Utf8 Class Initialized
INFO - 2023-07-18 16:09:56 --> URI Class Initialized
INFO - 2023-07-18 16:09:56 --> Router Class Initialized
INFO - 2023-07-18 16:09:56 --> Output Class Initialized
INFO - 2023-07-18 16:09:56 --> Security Class Initialized
DEBUG - 2023-07-18 16:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:09:56 --> Input Class Initialized
INFO - 2023-07-18 16:09:56 --> Language Class Initialized
INFO - 2023-07-18 16:09:56 --> Loader Class Initialized
INFO - 2023-07-18 16:09:56 --> Helper loaded: url_helper
INFO - 2023-07-18 16:09:56 --> Helper loaded: file_helper
INFO - 2023-07-18 16:09:56 --> Helper loaded: html_helper
INFO - 2023-07-18 16:09:56 --> Helper loaded: text_helper
INFO - 2023-07-18 16:09:56 --> Helper loaded: form_helper
INFO - 2023-07-18 16:09:56 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:09:56 --> Helper loaded: security_helper
INFO - 2023-07-18 16:09:56 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:09:56 --> Database Driver Class Initialized
INFO - 2023-07-18 16:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:09:56 --> Parser Class Initialized
INFO - 2023-07-18 16:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:09:56 --> Pagination Class Initialized
INFO - 2023-07-18 16:09:56 --> Form Validation Class Initialized
INFO - 2023-07-18 16:09:56 --> Controller Class Initialized
INFO - 2023-07-18 16:09:56 --> Model Class Initialized
DEBUG - 2023-07-18 16:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:56 --> Model Class Initialized
DEBUG - 2023-07-18 16:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:56 --> Model Class Initialized
INFO - 2023-07-18 16:09:56 --> Final output sent to browser
DEBUG - 2023-07-18 16:09:56 --> Total execution time: 0.0464
ERROR - 2023-07-18 16:09:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-18 16:09:58 --> Config Class Initialized
INFO - 2023-07-18 16:09:58 --> Hooks Class Initialized
DEBUG - 2023-07-18 16:09:58 --> UTF-8 Support Enabled
INFO - 2023-07-18 16:09:58 --> Utf8 Class Initialized
INFO - 2023-07-18 16:09:58 --> URI Class Initialized
DEBUG - 2023-07-18 16:09:58 --> No URI present. Default controller set.
INFO - 2023-07-18 16:09:58 --> Router Class Initialized
INFO - 2023-07-18 16:09:58 --> Output Class Initialized
INFO - 2023-07-18 16:09:58 --> Security Class Initialized
DEBUG - 2023-07-18 16:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 16:09:58 --> Input Class Initialized
INFO - 2023-07-18 16:09:58 --> Language Class Initialized
INFO - 2023-07-18 16:09:58 --> Loader Class Initialized
INFO - 2023-07-18 16:09:58 --> Helper loaded: url_helper
INFO - 2023-07-18 16:09:58 --> Helper loaded: file_helper
INFO - 2023-07-18 16:09:58 --> Helper loaded: html_helper
INFO - 2023-07-18 16:09:58 --> Helper loaded: text_helper
INFO - 2023-07-18 16:09:58 --> Helper loaded: form_helper
INFO - 2023-07-18 16:09:58 --> Helper loaded: lang_helper
INFO - 2023-07-18 16:09:58 --> Helper loaded: security_helper
INFO - 2023-07-18 16:09:58 --> Helper loaded: cookie_helper
INFO - 2023-07-18 16:09:58 --> Database Driver Class Initialized
INFO - 2023-07-18 16:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 16:09:58 --> Parser Class Initialized
INFO - 2023-07-18 16:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-18 16:09:58 --> Pagination Class Initialized
INFO - 2023-07-18 16:09:58 --> Form Validation Class Initialized
INFO - 2023-07-18 16:09:58 --> Controller Class Initialized
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
DEBUG - 2023-07-18 16:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
DEBUG - 2023-07-18 16:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
DEBUG - 2023-07-18 16:09:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 16:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
INFO - 2023-07-18 16:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-18 16:09:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-18 16:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-18 16:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-18 16:09:58 --> Model Class Initialized
INFO - 2023-07-18 16:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-18 16:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-18 16:09:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-18 16:09:58 --> Final output sent to browser
DEBUG - 2023-07-18 16:09:58 --> Total execution time: 0.1685
