<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-09 00:17:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 00:17:54 --> Config Class Initialized
INFO - 2024-03-09 00:17:54 --> Hooks Class Initialized
DEBUG - 2024-03-09 00:17:54 --> UTF-8 Support Enabled
INFO - 2024-03-09 00:17:54 --> Utf8 Class Initialized
INFO - 2024-03-09 00:17:54 --> URI Class Initialized
INFO - 2024-03-09 00:17:54 --> Router Class Initialized
INFO - 2024-03-09 00:17:54 --> Output Class Initialized
INFO - 2024-03-09 00:17:54 --> Security Class Initialized
DEBUG - 2024-03-09 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 00:17:54 --> Input Class Initialized
INFO - 2024-03-09 00:17:54 --> Language Class Initialized
ERROR - 2024-03-09 00:17:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-09 00:47:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 00:47:51 --> Config Class Initialized
INFO - 2024-03-09 00:47:51 --> Hooks Class Initialized
DEBUG - 2024-03-09 00:47:51 --> UTF-8 Support Enabled
INFO - 2024-03-09 00:47:51 --> Utf8 Class Initialized
INFO - 2024-03-09 00:47:51 --> URI Class Initialized
INFO - 2024-03-09 00:47:51 --> Router Class Initialized
INFO - 2024-03-09 00:47:51 --> Output Class Initialized
INFO - 2024-03-09 00:47:51 --> Security Class Initialized
DEBUG - 2024-03-09 00:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 00:47:51 --> Input Class Initialized
INFO - 2024-03-09 00:47:51 --> Language Class Initialized
ERROR - 2024-03-09 00:47:51 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-09 04:41:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:41:38 --> Config Class Initialized
INFO - 2024-03-09 04:41:38 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:41:38 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:41:38 --> Utf8 Class Initialized
INFO - 2024-03-09 04:41:38 --> URI Class Initialized
DEBUG - 2024-03-09 04:41:38 --> No URI present. Default controller set.
INFO - 2024-03-09 04:41:38 --> Router Class Initialized
INFO - 2024-03-09 04:41:38 --> Output Class Initialized
INFO - 2024-03-09 04:41:38 --> Security Class Initialized
DEBUG - 2024-03-09 04:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:41:38 --> Input Class Initialized
INFO - 2024-03-09 04:41:38 --> Language Class Initialized
INFO - 2024-03-09 04:41:38 --> Loader Class Initialized
INFO - 2024-03-09 04:41:38 --> Helper loaded: url_helper
INFO - 2024-03-09 04:41:38 --> Helper loaded: file_helper
INFO - 2024-03-09 04:41:38 --> Helper loaded: html_helper
INFO - 2024-03-09 04:41:38 --> Helper loaded: text_helper
INFO - 2024-03-09 04:41:38 --> Helper loaded: form_helper
INFO - 2024-03-09 04:41:38 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:41:38 --> Helper loaded: security_helper
INFO - 2024-03-09 04:41:38 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:41:38 --> Database Driver Class Initialized
INFO - 2024-03-09 04:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:41:38 --> Parser Class Initialized
INFO - 2024-03-09 04:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:41:38 --> Pagination Class Initialized
INFO - 2024-03-09 04:41:38 --> Form Validation Class Initialized
INFO - 2024-03-09 04:41:38 --> Controller Class Initialized
INFO - 2024-03-09 04:41:38 --> Model Class Initialized
DEBUG - 2024-03-09 04:41:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-09 04:41:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:41:40 --> Config Class Initialized
INFO - 2024-03-09 04:41:40 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:41:40 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:41:40 --> Utf8 Class Initialized
INFO - 2024-03-09 04:41:40 --> URI Class Initialized
INFO - 2024-03-09 04:41:40 --> Router Class Initialized
INFO - 2024-03-09 04:41:40 --> Output Class Initialized
INFO - 2024-03-09 04:41:40 --> Security Class Initialized
DEBUG - 2024-03-09 04:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:41:40 --> Input Class Initialized
INFO - 2024-03-09 04:41:40 --> Language Class Initialized
INFO - 2024-03-09 04:41:40 --> Loader Class Initialized
INFO - 2024-03-09 04:41:40 --> Helper loaded: url_helper
INFO - 2024-03-09 04:41:40 --> Helper loaded: file_helper
INFO - 2024-03-09 04:41:40 --> Helper loaded: html_helper
INFO - 2024-03-09 04:41:40 --> Helper loaded: text_helper
INFO - 2024-03-09 04:41:40 --> Helper loaded: form_helper
INFO - 2024-03-09 04:41:40 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:41:40 --> Helper loaded: security_helper
INFO - 2024-03-09 04:41:40 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:41:40 --> Database Driver Class Initialized
INFO - 2024-03-09 04:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:41:40 --> Parser Class Initialized
INFO - 2024-03-09 04:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:41:40 --> Pagination Class Initialized
INFO - 2024-03-09 04:41:40 --> Form Validation Class Initialized
INFO - 2024-03-09 04:41:40 --> Controller Class Initialized
INFO - 2024-03-09 04:41:40 --> Model Class Initialized
DEBUG - 2024-03-09 04:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:41:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 04:41:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:41:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 04:41:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 04:41:40 --> Model Class Initialized
INFO - 2024-03-09 04:41:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 04:41:40 --> Final output sent to browser
DEBUG - 2024-03-09 04:41:40 --> Total execution time: 0.0337
ERROR - 2024-03-09 04:41:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:41:54 --> Config Class Initialized
INFO - 2024-03-09 04:41:54 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:41:54 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:41:54 --> Utf8 Class Initialized
INFO - 2024-03-09 04:41:54 --> URI Class Initialized
INFO - 2024-03-09 04:41:54 --> Router Class Initialized
INFO - 2024-03-09 04:41:54 --> Output Class Initialized
INFO - 2024-03-09 04:41:54 --> Security Class Initialized
DEBUG - 2024-03-09 04:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:41:54 --> Input Class Initialized
INFO - 2024-03-09 04:41:54 --> Language Class Initialized
INFO - 2024-03-09 04:41:54 --> Loader Class Initialized
INFO - 2024-03-09 04:41:54 --> Helper loaded: url_helper
INFO - 2024-03-09 04:41:54 --> Helper loaded: file_helper
INFO - 2024-03-09 04:41:54 --> Helper loaded: html_helper
INFO - 2024-03-09 04:41:54 --> Helper loaded: text_helper
INFO - 2024-03-09 04:41:54 --> Helper loaded: form_helper
INFO - 2024-03-09 04:41:54 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:41:54 --> Helper loaded: security_helper
INFO - 2024-03-09 04:41:54 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:41:54 --> Database Driver Class Initialized
INFO - 2024-03-09 04:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:41:54 --> Parser Class Initialized
INFO - 2024-03-09 04:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:41:54 --> Pagination Class Initialized
INFO - 2024-03-09 04:41:54 --> Form Validation Class Initialized
INFO - 2024-03-09 04:41:54 --> Controller Class Initialized
INFO - 2024-03-09 04:41:54 --> Model Class Initialized
DEBUG - 2024-03-09 04:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:41:54 --> Model Class Initialized
INFO - 2024-03-09 04:41:54 --> Final output sent to browser
DEBUG - 2024-03-09 04:41:54 --> Total execution time: 0.0220
ERROR - 2024-03-09 04:41:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:41:55 --> Config Class Initialized
INFO - 2024-03-09 04:41:55 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:41:55 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:41:55 --> Utf8 Class Initialized
INFO - 2024-03-09 04:41:55 --> URI Class Initialized
DEBUG - 2024-03-09 04:41:55 --> No URI present. Default controller set.
INFO - 2024-03-09 04:41:55 --> Router Class Initialized
INFO - 2024-03-09 04:41:55 --> Output Class Initialized
INFO - 2024-03-09 04:41:55 --> Security Class Initialized
DEBUG - 2024-03-09 04:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:41:55 --> Input Class Initialized
INFO - 2024-03-09 04:41:55 --> Language Class Initialized
INFO - 2024-03-09 04:41:55 --> Loader Class Initialized
INFO - 2024-03-09 04:41:55 --> Helper loaded: url_helper
INFO - 2024-03-09 04:41:55 --> Helper loaded: file_helper
INFO - 2024-03-09 04:41:55 --> Helper loaded: html_helper
INFO - 2024-03-09 04:41:55 --> Helper loaded: text_helper
INFO - 2024-03-09 04:41:55 --> Helper loaded: form_helper
INFO - 2024-03-09 04:41:55 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:41:55 --> Helper loaded: security_helper
INFO - 2024-03-09 04:41:55 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:41:55 --> Database Driver Class Initialized
INFO - 2024-03-09 04:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:41:55 --> Parser Class Initialized
INFO - 2024-03-09 04:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:41:55 --> Pagination Class Initialized
INFO - 2024-03-09 04:41:55 --> Form Validation Class Initialized
INFO - 2024-03-09 04:41:55 --> Controller Class Initialized
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
DEBUG - 2024-03-09 04:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
DEBUG - 2024-03-09 04:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
DEBUG - 2024-03-09 04:41:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 04:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
INFO - 2024-03-09 04:41:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 04:41:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:41:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 04:41:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 04:41:55 --> Model Class Initialized
INFO - 2024-03-09 04:41:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 04:41:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 04:41:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 04:41:55 --> Final output sent to browser
DEBUG - 2024-03-09 04:41:55 --> Total execution time: 0.2564
ERROR - 2024-03-09 04:42:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:42:02 --> Config Class Initialized
INFO - 2024-03-09 04:42:02 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:42:02 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:42:02 --> Utf8 Class Initialized
INFO - 2024-03-09 04:42:02 --> URI Class Initialized
INFO - 2024-03-09 04:42:02 --> Router Class Initialized
INFO - 2024-03-09 04:42:02 --> Output Class Initialized
INFO - 2024-03-09 04:42:02 --> Security Class Initialized
DEBUG - 2024-03-09 04:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:42:02 --> Input Class Initialized
INFO - 2024-03-09 04:42:02 --> Language Class Initialized
INFO - 2024-03-09 04:42:02 --> Loader Class Initialized
INFO - 2024-03-09 04:42:02 --> Helper loaded: url_helper
INFO - 2024-03-09 04:42:02 --> Helper loaded: file_helper
INFO - 2024-03-09 04:42:02 --> Helper loaded: html_helper
INFO - 2024-03-09 04:42:02 --> Helper loaded: text_helper
INFO - 2024-03-09 04:42:02 --> Helper loaded: form_helper
INFO - 2024-03-09 04:42:02 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:42:02 --> Helper loaded: security_helper
INFO - 2024-03-09 04:42:02 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:42:02 --> Database Driver Class Initialized
INFO - 2024-03-09 04:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:42:02 --> Parser Class Initialized
INFO - 2024-03-09 04:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:42:02 --> Pagination Class Initialized
INFO - 2024-03-09 04:42:02 --> Form Validation Class Initialized
INFO - 2024-03-09 04:42:02 --> Controller Class Initialized
INFO - 2024-03-09 04:42:02 --> Model Class Initialized
DEBUG - 2024-03-09 04:42:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 04:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:42:02 --> Model Class Initialized
INFO - 2024-03-09 04:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-03-09 04:42:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 04:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 04:42:02 --> Model Class Initialized
INFO - 2024-03-09 04:42:02 --> Model Class Initialized
INFO - 2024-03-09 04:42:02 --> Model Class Initialized
INFO - 2024-03-09 04:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 04:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 04:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 04:42:02 --> Final output sent to browser
DEBUG - 2024-03-09 04:42:02 --> Total execution time: 0.1592
ERROR - 2024-03-09 04:42:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:42:04 --> Config Class Initialized
INFO - 2024-03-09 04:42:04 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:42:04 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:42:04 --> Utf8 Class Initialized
INFO - 2024-03-09 04:42:04 --> URI Class Initialized
INFO - 2024-03-09 04:42:04 --> Router Class Initialized
INFO - 2024-03-09 04:42:04 --> Output Class Initialized
INFO - 2024-03-09 04:42:04 --> Security Class Initialized
DEBUG - 2024-03-09 04:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:42:04 --> Input Class Initialized
INFO - 2024-03-09 04:42:04 --> Language Class Initialized
INFO - 2024-03-09 04:42:04 --> Loader Class Initialized
INFO - 2024-03-09 04:42:04 --> Helper loaded: url_helper
INFO - 2024-03-09 04:42:04 --> Helper loaded: file_helper
INFO - 2024-03-09 04:42:04 --> Helper loaded: html_helper
INFO - 2024-03-09 04:42:04 --> Helper loaded: text_helper
INFO - 2024-03-09 04:42:04 --> Helper loaded: form_helper
INFO - 2024-03-09 04:42:04 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:42:04 --> Helper loaded: security_helper
INFO - 2024-03-09 04:42:04 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:42:04 --> Database Driver Class Initialized
INFO - 2024-03-09 04:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:42:04 --> Parser Class Initialized
INFO - 2024-03-09 04:42:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:42:04 --> Pagination Class Initialized
INFO - 2024-03-09 04:42:04 --> Form Validation Class Initialized
INFO - 2024-03-09 04:42:04 --> Controller Class Initialized
INFO - 2024-03-09 04:42:04 --> Model Class Initialized
DEBUG - 2024-03-09 04:42:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 04:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:42:04 --> Model Class Initialized
INFO - 2024-03-09 04:42:04 --> Final output sent to browser
DEBUG - 2024-03-09 04:42:04 --> Total execution time: 0.2313
ERROR - 2024-03-09 04:42:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:42:34 --> Config Class Initialized
INFO - 2024-03-09 04:42:34 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:42:34 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:42:34 --> Utf8 Class Initialized
INFO - 2024-03-09 04:42:34 --> URI Class Initialized
INFO - 2024-03-09 04:42:34 --> Router Class Initialized
INFO - 2024-03-09 04:42:34 --> Output Class Initialized
INFO - 2024-03-09 04:42:34 --> Security Class Initialized
DEBUG - 2024-03-09 04:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:42:34 --> Input Class Initialized
INFO - 2024-03-09 04:42:34 --> Language Class Initialized
INFO - 2024-03-09 04:42:34 --> Loader Class Initialized
INFO - 2024-03-09 04:42:34 --> Helper loaded: url_helper
INFO - 2024-03-09 04:42:34 --> Helper loaded: file_helper
INFO - 2024-03-09 04:42:34 --> Helper loaded: html_helper
INFO - 2024-03-09 04:42:34 --> Helper loaded: text_helper
INFO - 2024-03-09 04:42:34 --> Helper loaded: form_helper
INFO - 2024-03-09 04:42:34 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:42:34 --> Helper loaded: security_helper
INFO - 2024-03-09 04:42:34 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:42:34 --> Database Driver Class Initialized
INFO - 2024-03-09 04:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:42:34 --> Parser Class Initialized
INFO - 2024-03-09 04:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:42:34 --> Pagination Class Initialized
INFO - 2024-03-09 04:42:34 --> Form Validation Class Initialized
INFO - 2024-03-09 04:42:34 --> Controller Class Initialized
INFO - 2024-03-09 04:42:34 --> Model Class Initialized
DEBUG - 2024-03-09 04:42:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 04:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:42:34 --> Model Class Initialized
INFO - 2024-03-09 04:42:34 --> Final output sent to browser
DEBUG - 2024-03-09 04:42:34 --> Total execution time: 0.2382
ERROR - 2024-03-09 04:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:44:26 --> Config Class Initialized
INFO - 2024-03-09 04:44:26 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:44:26 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:44:26 --> Utf8 Class Initialized
INFO - 2024-03-09 04:44:26 --> URI Class Initialized
DEBUG - 2024-03-09 04:44:26 --> No URI present. Default controller set.
INFO - 2024-03-09 04:44:26 --> Router Class Initialized
INFO - 2024-03-09 04:44:26 --> Output Class Initialized
INFO - 2024-03-09 04:44:26 --> Security Class Initialized
DEBUG - 2024-03-09 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:44:26 --> Input Class Initialized
INFO - 2024-03-09 04:44:26 --> Language Class Initialized
INFO - 2024-03-09 04:44:26 --> Loader Class Initialized
INFO - 2024-03-09 04:44:26 --> Helper loaded: url_helper
INFO - 2024-03-09 04:44:26 --> Helper loaded: file_helper
INFO - 2024-03-09 04:44:26 --> Helper loaded: html_helper
INFO - 2024-03-09 04:44:26 --> Helper loaded: text_helper
INFO - 2024-03-09 04:44:26 --> Helper loaded: form_helper
INFO - 2024-03-09 04:44:26 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:44:26 --> Helper loaded: security_helper
INFO - 2024-03-09 04:44:26 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:44:26 --> Database Driver Class Initialized
INFO - 2024-03-09 04:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:44:26 --> Parser Class Initialized
INFO - 2024-03-09 04:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:44:26 --> Pagination Class Initialized
INFO - 2024-03-09 04:44:26 --> Form Validation Class Initialized
INFO - 2024-03-09 04:44:26 --> Controller Class Initialized
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
DEBUG - 2024-03-09 04:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
DEBUG - 2024-03-09 04:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
DEBUG - 2024-03-09 04:44:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 04:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
INFO - 2024-03-09 04:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 04:44:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 04:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 04:44:26 --> Model Class Initialized
INFO - 2024-03-09 04:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 04:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 04:44:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 04:44:26 --> Final output sent to browser
DEBUG - 2024-03-09 04:44:26 --> Total execution time: 0.2503
ERROR - 2024-03-09 04:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:44:45 --> Config Class Initialized
INFO - 2024-03-09 04:44:45 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:44:45 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:44:45 --> Utf8 Class Initialized
INFO - 2024-03-09 04:44:45 --> URI Class Initialized
INFO - 2024-03-09 04:44:45 --> Router Class Initialized
INFO - 2024-03-09 04:44:45 --> Output Class Initialized
INFO - 2024-03-09 04:44:45 --> Security Class Initialized
DEBUG - 2024-03-09 04:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:44:45 --> Input Class Initialized
INFO - 2024-03-09 04:44:45 --> Language Class Initialized
INFO - 2024-03-09 04:44:45 --> Loader Class Initialized
INFO - 2024-03-09 04:44:45 --> Helper loaded: url_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: file_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: html_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: text_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: form_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: security_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:44:45 --> Database Driver Class Initialized
INFO - 2024-03-09 04:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:44:45 --> Parser Class Initialized
INFO - 2024-03-09 04:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:44:45 --> Pagination Class Initialized
INFO - 2024-03-09 04:44:45 --> Form Validation Class Initialized
INFO - 2024-03-09 04:44:45 --> Controller Class Initialized
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
DEBUG - 2024-03-09 04:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 04:44:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 04:44:45 --> Final output sent to browser
DEBUG - 2024-03-09 04:44:45 --> Total execution time: 0.0322
ERROR - 2024-03-09 04:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 04:44:45 --> Config Class Initialized
INFO - 2024-03-09 04:44:45 --> Hooks Class Initialized
DEBUG - 2024-03-09 04:44:45 --> UTF-8 Support Enabled
INFO - 2024-03-09 04:44:45 --> Utf8 Class Initialized
INFO - 2024-03-09 04:44:45 --> URI Class Initialized
INFO - 2024-03-09 04:44:45 --> Router Class Initialized
INFO - 2024-03-09 04:44:45 --> Output Class Initialized
INFO - 2024-03-09 04:44:45 --> Security Class Initialized
DEBUG - 2024-03-09 04:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 04:44:45 --> Input Class Initialized
INFO - 2024-03-09 04:44:45 --> Language Class Initialized
INFO - 2024-03-09 04:44:45 --> Loader Class Initialized
INFO - 2024-03-09 04:44:45 --> Helper loaded: url_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: file_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: html_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: text_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: form_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: lang_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: security_helper
INFO - 2024-03-09 04:44:45 --> Helper loaded: cookie_helper
INFO - 2024-03-09 04:44:45 --> Database Driver Class Initialized
INFO - 2024-03-09 04:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 04:44:45 --> Parser Class Initialized
INFO - 2024-03-09 04:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 04:44:45 --> Pagination Class Initialized
INFO - 2024-03-09 04:44:45 --> Form Validation Class Initialized
INFO - 2024-03-09 04:44:45 --> Controller Class Initialized
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
DEBUG - 2024-03-09 04:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
DEBUG - 2024-03-09 04:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
DEBUG - 2024-03-09 04:44:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 04:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 04:44:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 04:44:45 --> Model Class Initialized
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 04:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 04:44:45 --> Final output sent to browser
DEBUG - 2024-03-09 04:44:45 --> Total execution time: 0.2498
ERROR - 2024-03-09 05:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:10:57 --> Config Class Initialized
INFO - 2024-03-09 05:10:57 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:10:57 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:10:57 --> Utf8 Class Initialized
INFO - 2024-03-09 05:10:57 --> URI Class Initialized
DEBUG - 2024-03-09 05:10:57 --> No URI present. Default controller set.
INFO - 2024-03-09 05:10:57 --> Router Class Initialized
INFO - 2024-03-09 05:10:57 --> Output Class Initialized
INFO - 2024-03-09 05:10:57 --> Security Class Initialized
DEBUG - 2024-03-09 05:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:10:57 --> Input Class Initialized
INFO - 2024-03-09 05:10:57 --> Language Class Initialized
INFO - 2024-03-09 05:10:57 --> Loader Class Initialized
INFO - 2024-03-09 05:10:57 --> Helper loaded: url_helper
INFO - 2024-03-09 05:10:57 --> Helper loaded: file_helper
INFO - 2024-03-09 05:10:57 --> Helper loaded: html_helper
INFO - 2024-03-09 05:10:57 --> Helper loaded: text_helper
INFO - 2024-03-09 05:10:57 --> Helper loaded: form_helper
INFO - 2024-03-09 05:10:57 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:10:57 --> Helper loaded: security_helper
INFO - 2024-03-09 05:10:57 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:10:57 --> Database Driver Class Initialized
INFO - 2024-03-09 05:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:10:57 --> Parser Class Initialized
INFO - 2024-03-09 05:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:10:57 --> Pagination Class Initialized
INFO - 2024-03-09 05:10:57 --> Form Validation Class Initialized
INFO - 2024-03-09 05:10:57 --> Controller Class Initialized
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
DEBUG - 2024-03-09 05:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
DEBUG - 2024-03-09 05:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
DEBUG - 2024-03-09 05:10:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
INFO - 2024-03-09 05:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 05:10:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:10:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:10:57 --> Model Class Initialized
INFO - 2024-03-09 05:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:10:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:10:58 --> Final output sent to browser
DEBUG - 2024-03-09 05:10:58 --> Total execution time: 0.2461
ERROR - 2024-03-09 05:11:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:11:07 --> Config Class Initialized
INFO - 2024-03-09 05:11:07 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:11:07 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:11:07 --> Utf8 Class Initialized
INFO - 2024-03-09 05:11:07 --> URI Class Initialized
INFO - 2024-03-09 05:11:07 --> Router Class Initialized
INFO - 2024-03-09 05:11:07 --> Output Class Initialized
INFO - 2024-03-09 05:11:07 --> Security Class Initialized
DEBUG - 2024-03-09 05:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:11:07 --> Input Class Initialized
INFO - 2024-03-09 05:11:07 --> Language Class Initialized
INFO - 2024-03-09 05:11:07 --> Loader Class Initialized
INFO - 2024-03-09 05:11:07 --> Helper loaded: url_helper
INFO - 2024-03-09 05:11:07 --> Helper loaded: file_helper
INFO - 2024-03-09 05:11:07 --> Helper loaded: html_helper
INFO - 2024-03-09 05:11:07 --> Helper loaded: text_helper
INFO - 2024-03-09 05:11:07 --> Helper loaded: form_helper
INFO - 2024-03-09 05:11:07 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:11:07 --> Helper loaded: security_helper
INFO - 2024-03-09 05:11:07 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:11:07 --> Database Driver Class Initialized
INFO - 2024-03-09 05:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:11:07 --> Parser Class Initialized
INFO - 2024-03-09 05:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:11:07 --> Pagination Class Initialized
INFO - 2024-03-09 05:11:07 --> Form Validation Class Initialized
INFO - 2024-03-09 05:11:07 --> Controller Class Initialized
INFO - 2024-03-09 05:11:07 --> Model Class Initialized
DEBUG - 2024-03-09 05:11:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:07 --> Model Class Initialized
INFO - 2024-03-09 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-03-09 05:11:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:11:07 --> Model Class Initialized
INFO - 2024-03-09 05:11:07 --> Model Class Initialized
INFO - 2024-03-09 05:11:07 --> Model Class Initialized
INFO - 2024-03-09 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:11:07 --> Final output sent to browser
DEBUG - 2024-03-09 05:11:07 --> Total execution time: 0.1567
ERROR - 2024-03-09 05:11:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:11:08 --> Config Class Initialized
INFO - 2024-03-09 05:11:08 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:11:08 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:11:08 --> Utf8 Class Initialized
INFO - 2024-03-09 05:11:08 --> URI Class Initialized
INFO - 2024-03-09 05:11:08 --> Router Class Initialized
INFO - 2024-03-09 05:11:08 --> Output Class Initialized
INFO - 2024-03-09 05:11:08 --> Security Class Initialized
DEBUG - 2024-03-09 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:11:08 --> Input Class Initialized
INFO - 2024-03-09 05:11:08 --> Language Class Initialized
INFO - 2024-03-09 05:11:08 --> Loader Class Initialized
INFO - 2024-03-09 05:11:08 --> Helper loaded: url_helper
INFO - 2024-03-09 05:11:08 --> Helper loaded: file_helper
INFO - 2024-03-09 05:11:08 --> Helper loaded: html_helper
INFO - 2024-03-09 05:11:08 --> Helper loaded: text_helper
INFO - 2024-03-09 05:11:08 --> Helper loaded: form_helper
INFO - 2024-03-09 05:11:08 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:11:08 --> Helper loaded: security_helper
INFO - 2024-03-09 05:11:08 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:11:08 --> Database Driver Class Initialized
INFO - 2024-03-09 05:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:11:08 --> Parser Class Initialized
INFO - 2024-03-09 05:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:11:08 --> Pagination Class Initialized
INFO - 2024-03-09 05:11:08 --> Form Validation Class Initialized
INFO - 2024-03-09 05:11:08 --> Controller Class Initialized
INFO - 2024-03-09 05:11:08 --> Model Class Initialized
DEBUG - 2024-03-09 05:11:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:08 --> Model Class Initialized
INFO - 2024-03-09 05:11:08 --> Final output sent to browser
DEBUG - 2024-03-09 05:11:08 --> Total execution time: 0.0313
ERROR - 2024-03-09 05:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:11:38 --> Config Class Initialized
INFO - 2024-03-09 05:11:38 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:11:38 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:11:38 --> Utf8 Class Initialized
INFO - 2024-03-09 05:11:38 --> URI Class Initialized
INFO - 2024-03-09 05:11:38 --> Router Class Initialized
INFO - 2024-03-09 05:11:38 --> Output Class Initialized
INFO - 2024-03-09 05:11:38 --> Security Class Initialized
DEBUG - 2024-03-09 05:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:11:38 --> Input Class Initialized
INFO - 2024-03-09 05:11:38 --> Language Class Initialized
INFO - 2024-03-09 05:11:38 --> Loader Class Initialized
INFO - 2024-03-09 05:11:38 --> Helper loaded: url_helper
INFO - 2024-03-09 05:11:38 --> Helper loaded: file_helper
INFO - 2024-03-09 05:11:38 --> Helper loaded: html_helper
INFO - 2024-03-09 05:11:38 --> Helper loaded: text_helper
INFO - 2024-03-09 05:11:38 --> Helper loaded: form_helper
INFO - 2024-03-09 05:11:38 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:11:38 --> Helper loaded: security_helper
INFO - 2024-03-09 05:11:38 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:11:38 --> Database Driver Class Initialized
INFO - 2024-03-09 05:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:11:38 --> Parser Class Initialized
INFO - 2024-03-09 05:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:11:38 --> Pagination Class Initialized
INFO - 2024-03-09 05:11:38 --> Form Validation Class Initialized
INFO - 2024-03-09 05:11:38 --> Controller Class Initialized
INFO - 2024-03-09 05:11:38 --> Model Class Initialized
DEBUG - 2024-03-09 05:11:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:38 --> Model Class Initialized
DEBUG - 2024-03-09 05:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2024-03-09 05:11:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:11:38 --> Model Class Initialized
INFO - 2024-03-09 05:11:38 --> Model Class Initialized
INFO - 2024-03-09 05:11:38 --> Model Class Initialized
INFO - 2024-03-09 05:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:11:38 --> Final output sent to browser
DEBUG - 2024-03-09 05:11:38 --> Total execution time: 0.1588
ERROR - 2024-03-09 05:11:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:11:49 --> Config Class Initialized
INFO - 2024-03-09 05:11:49 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:11:49 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:11:49 --> Utf8 Class Initialized
INFO - 2024-03-09 05:11:49 --> URI Class Initialized
INFO - 2024-03-09 05:11:49 --> Router Class Initialized
INFO - 2024-03-09 05:11:49 --> Output Class Initialized
INFO - 2024-03-09 05:11:49 --> Security Class Initialized
DEBUG - 2024-03-09 05:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:11:49 --> Input Class Initialized
INFO - 2024-03-09 05:11:49 --> Language Class Initialized
INFO - 2024-03-09 05:11:49 --> Loader Class Initialized
INFO - 2024-03-09 05:11:49 --> Helper loaded: url_helper
INFO - 2024-03-09 05:11:49 --> Helper loaded: file_helper
INFO - 2024-03-09 05:11:49 --> Helper loaded: html_helper
INFO - 2024-03-09 05:11:49 --> Helper loaded: text_helper
INFO - 2024-03-09 05:11:49 --> Helper loaded: form_helper
INFO - 2024-03-09 05:11:49 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:11:49 --> Helper loaded: security_helper
INFO - 2024-03-09 05:11:49 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:11:49 --> Database Driver Class Initialized
INFO - 2024-03-09 05:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:11:49 --> Parser Class Initialized
INFO - 2024-03-09 05:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:11:49 --> Pagination Class Initialized
INFO - 2024-03-09 05:11:49 --> Form Validation Class Initialized
INFO - 2024-03-09 05:11:49 --> Controller Class Initialized
INFO - 2024-03-09 05:11:49 --> Model Class Initialized
DEBUG - 2024-03-09 05:11:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:49 --> Model Class Initialized
INFO - 2024-03-09 05:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-03-09 05:11:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:11:49 --> Model Class Initialized
INFO - 2024-03-09 05:11:49 --> Model Class Initialized
INFO - 2024-03-09 05:11:49 --> Model Class Initialized
INFO - 2024-03-09 05:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:11:49 --> Final output sent to browser
DEBUG - 2024-03-09 05:11:49 --> Total execution time: 0.1530
ERROR - 2024-03-09 05:11:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:11:51 --> Config Class Initialized
INFO - 2024-03-09 05:11:51 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:11:51 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:11:51 --> Utf8 Class Initialized
INFO - 2024-03-09 05:11:51 --> URI Class Initialized
INFO - 2024-03-09 05:11:51 --> Router Class Initialized
INFO - 2024-03-09 05:11:51 --> Output Class Initialized
INFO - 2024-03-09 05:11:51 --> Security Class Initialized
DEBUG - 2024-03-09 05:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:11:51 --> Input Class Initialized
INFO - 2024-03-09 05:11:51 --> Language Class Initialized
INFO - 2024-03-09 05:11:51 --> Loader Class Initialized
INFO - 2024-03-09 05:11:51 --> Helper loaded: url_helper
INFO - 2024-03-09 05:11:51 --> Helper loaded: file_helper
INFO - 2024-03-09 05:11:51 --> Helper loaded: html_helper
INFO - 2024-03-09 05:11:51 --> Helper loaded: text_helper
INFO - 2024-03-09 05:11:51 --> Helper loaded: form_helper
INFO - 2024-03-09 05:11:51 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:11:51 --> Helper loaded: security_helper
INFO - 2024-03-09 05:11:51 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:11:51 --> Database Driver Class Initialized
INFO - 2024-03-09 05:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:11:51 --> Parser Class Initialized
INFO - 2024-03-09 05:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:11:51 --> Pagination Class Initialized
INFO - 2024-03-09 05:11:51 --> Form Validation Class Initialized
INFO - 2024-03-09 05:11:51 --> Controller Class Initialized
INFO - 2024-03-09 05:11:51 --> Model Class Initialized
DEBUG - 2024-03-09 05:11:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:11:51 --> Model Class Initialized
INFO - 2024-03-09 05:11:51 --> Final output sent to browser
DEBUG - 2024-03-09 05:11:51 --> Total execution time: 0.0299
ERROR - 2024-03-09 05:12:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:12:07 --> Config Class Initialized
INFO - 2024-03-09 05:12:07 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:12:07 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:12:07 --> Utf8 Class Initialized
INFO - 2024-03-09 05:12:07 --> URI Class Initialized
INFO - 2024-03-09 05:12:07 --> Router Class Initialized
INFO - 2024-03-09 05:12:07 --> Output Class Initialized
INFO - 2024-03-09 05:12:07 --> Security Class Initialized
DEBUG - 2024-03-09 05:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:12:07 --> Input Class Initialized
INFO - 2024-03-09 05:12:07 --> Language Class Initialized
INFO - 2024-03-09 05:12:07 --> Loader Class Initialized
INFO - 2024-03-09 05:12:07 --> Helper loaded: url_helper
INFO - 2024-03-09 05:12:07 --> Helper loaded: file_helper
INFO - 2024-03-09 05:12:07 --> Helper loaded: html_helper
INFO - 2024-03-09 05:12:07 --> Helper loaded: text_helper
INFO - 2024-03-09 05:12:07 --> Helper loaded: form_helper
INFO - 2024-03-09 05:12:07 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:12:07 --> Helper loaded: security_helper
INFO - 2024-03-09 05:12:07 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:12:07 --> Database Driver Class Initialized
INFO - 2024-03-09 05:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:12:07 --> Parser Class Initialized
INFO - 2024-03-09 05:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:12:07 --> Pagination Class Initialized
INFO - 2024-03-09 05:12:07 --> Form Validation Class Initialized
INFO - 2024-03-09 05:12:07 --> Controller Class Initialized
INFO - 2024-03-09 05:12:07 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:07 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2024-03-09 05:12:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:12:07 --> Model Class Initialized
INFO - 2024-03-09 05:12:07 --> Model Class Initialized
INFO - 2024-03-09 05:12:07 --> Model Class Initialized
INFO - 2024-03-09 05:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:12:07 --> Final output sent to browser
DEBUG - 2024-03-09 05:12:07 --> Total execution time: 0.1826
ERROR - 2024-03-09 05:12:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:12:16 --> Config Class Initialized
INFO - 2024-03-09 05:12:16 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:12:16 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:12:16 --> Utf8 Class Initialized
INFO - 2024-03-09 05:12:16 --> URI Class Initialized
INFO - 2024-03-09 05:12:16 --> Router Class Initialized
INFO - 2024-03-09 05:12:16 --> Output Class Initialized
INFO - 2024-03-09 05:12:16 --> Security Class Initialized
DEBUG - 2024-03-09 05:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:12:16 --> Input Class Initialized
INFO - 2024-03-09 05:12:16 --> Language Class Initialized
INFO - 2024-03-09 05:12:16 --> Loader Class Initialized
INFO - 2024-03-09 05:12:16 --> Helper loaded: url_helper
INFO - 2024-03-09 05:12:16 --> Helper loaded: file_helper
INFO - 2024-03-09 05:12:16 --> Helper loaded: html_helper
INFO - 2024-03-09 05:12:16 --> Helper loaded: text_helper
INFO - 2024-03-09 05:12:16 --> Helper loaded: form_helper
INFO - 2024-03-09 05:12:16 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:12:16 --> Helper loaded: security_helper
INFO - 2024-03-09 05:12:16 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:12:16 --> Database Driver Class Initialized
INFO - 2024-03-09 05:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:12:16 --> Parser Class Initialized
INFO - 2024-03-09 05:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:12:16 --> Pagination Class Initialized
INFO - 2024-03-09 05:12:16 --> Form Validation Class Initialized
INFO - 2024-03-09 05:12:16 --> Controller Class Initialized
INFO - 2024-03-09 05:12:16 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:16 --> Model Class Initialized
INFO - 2024-03-09 05:12:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-03-09 05:12:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:12:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:12:16 --> Model Class Initialized
INFO - 2024-03-09 05:12:16 --> Model Class Initialized
INFO - 2024-03-09 05:12:16 --> Model Class Initialized
INFO - 2024-03-09 05:12:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:12:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:12:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:12:16 --> Final output sent to browser
DEBUG - 2024-03-09 05:12:16 --> Total execution time: 0.1636
ERROR - 2024-03-09 05:12:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:12:17 --> Config Class Initialized
INFO - 2024-03-09 05:12:17 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:12:17 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:12:17 --> Utf8 Class Initialized
INFO - 2024-03-09 05:12:17 --> URI Class Initialized
INFO - 2024-03-09 05:12:17 --> Router Class Initialized
INFO - 2024-03-09 05:12:17 --> Output Class Initialized
INFO - 2024-03-09 05:12:17 --> Security Class Initialized
DEBUG - 2024-03-09 05:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:12:17 --> Input Class Initialized
INFO - 2024-03-09 05:12:17 --> Language Class Initialized
INFO - 2024-03-09 05:12:17 --> Loader Class Initialized
INFO - 2024-03-09 05:12:17 --> Helper loaded: url_helper
INFO - 2024-03-09 05:12:17 --> Helper loaded: file_helper
INFO - 2024-03-09 05:12:17 --> Helper loaded: html_helper
INFO - 2024-03-09 05:12:17 --> Helper loaded: text_helper
INFO - 2024-03-09 05:12:17 --> Helper loaded: form_helper
INFO - 2024-03-09 05:12:17 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:12:17 --> Helper loaded: security_helper
INFO - 2024-03-09 05:12:17 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:12:17 --> Database Driver Class Initialized
INFO - 2024-03-09 05:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:12:17 --> Parser Class Initialized
INFO - 2024-03-09 05:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:12:17 --> Pagination Class Initialized
INFO - 2024-03-09 05:12:17 --> Form Validation Class Initialized
INFO - 2024-03-09 05:12:17 --> Controller Class Initialized
INFO - 2024-03-09 05:12:17 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:17 --> Model Class Initialized
INFO - 2024-03-09 05:12:17 --> Final output sent to browser
DEBUG - 2024-03-09 05:12:17 --> Total execution time: 0.0313
ERROR - 2024-03-09 05:12:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:12:25 --> Config Class Initialized
INFO - 2024-03-09 05:12:25 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:12:25 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:12:25 --> Utf8 Class Initialized
INFO - 2024-03-09 05:12:25 --> URI Class Initialized
INFO - 2024-03-09 05:12:25 --> Router Class Initialized
INFO - 2024-03-09 05:12:25 --> Output Class Initialized
INFO - 2024-03-09 05:12:25 --> Security Class Initialized
DEBUG - 2024-03-09 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:12:25 --> Input Class Initialized
INFO - 2024-03-09 05:12:25 --> Language Class Initialized
INFO - 2024-03-09 05:12:25 --> Loader Class Initialized
INFO - 2024-03-09 05:12:25 --> Helper loaded: url_helper
INFO - 2024-03-09 05:12:25 --> Helper loaded: file_helper
INFO - 2024-03-09 05:12:25 --> Helper loaded: html_helper
INFO - 2024-03-09 05:12:25 --> Helper loaded: text_helper
INFO - 2024-03-09 05:12:25 --> Helper loaded: form_helper
INFO - 2024-03-09 05:12:25 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:12:25 --> Helper loaded: security_helper
INFO - 2024-03-09 05:12:25 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:12:25 --> Database Driver Class Initialized
INFO - 2024-03-09 05:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:12:25 --> Parser Class Initialized
INFO - 2024-03-09 05:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:12:25 --> Pagination Class Initialized
INFO - 2024-03-09 05:12:25 --> Form Validation Class Initialized
INFO - 2024-03-09 05:12:25 --> Controller Class Initialized
INFO - 2024-03-09 05:12:25 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:25 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2024-03-09 05:12:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:12:25 --> Model Class Initialized
INFO - 2024-03-09 05:12:25 --> Model Class Initialized
INFO - 2024-03-09 05:12:25 --> Model Class Initialized
INFO - 2024-03-09 05:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:12:25 --> Final output sent to browser
DEBUG - 2024-03-09 05:12:25 --> Total execution time: 0.1656
ERROR - 2024-03-09 05:12:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:12:34 --> Config Class Initialized
INFO - 2024-03-09 05:12:34 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:12:34 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:12:34 --> Utf8 Class Initialized
INFO - 2024-03-09 05:12:34 --> URI Class Initialized
INFO - 2024-03-09 05:12:34 --> Router Class Initialized
INFO - 2024-03-09 05:12:34 --> Output Class Initialized
INFO - 2024-03-09 05:12:34 --> Security Class Initialized
DEBUG - 2024-03-09 05:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:12:34 --> Input Class Initialized
INFO - 2024-03-09 05:12:34 --> Language Class Initialized
INFO - 2024-03-09 05:12:34 --> Loader Class Initialized
INFO - 2024-03-09 05:12:34 --> Helper loaded: url_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: file_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: html_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: text_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: form_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: security_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:12:34 --> Database Driver Class Initialized
INFO - 2024-03-09 05:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:12:34 --> Parser Class Initialized
INFO - 2024-03-09 05:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:12:34 --> Pagination Class Initialized
INFO - 2024-03-09 05:12:34 --> Form Validation Class Initialized
INFO - 2024-03-09 05:12:34 --> Controller Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-03-09 05:12:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:12:34 --> Final output sent to browser
DEBUG - 2024-03-09 05:12:34 --> Total execution time: 0.1578
ERROR - 2024-03-09 05:12:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 05:12:34 --> Config Class Initialized
INFO - 2024-03-09 05:12:34 --> Hooks Class Initialized
DEBUG - 2024-03-09 05:12:34 --> UTF-8 Support Enabled
INFO - 2024-03-09 05:12:34 --> Utf8 Class Initialized
INFO - 2024-03-09 05:12:34 --> URI Class Initialized
DEBUG - 2024-03-09 05:12:34 --> No URI present. Default controller set.
INFO - 2024-03-09 05:12:34 --> Router Class Initialized
INFO - 2024-03-09 05:12:34 --> Output Class Initialized
INFO - 2024-03-09 05:12:34 --> Security Class Initialized
DEBUG - 2024-03-09 05:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 05:12:34 --> Input Class Initialized
INFO - 2024-03-09 05:12:34 --> Language Class Initialized
INFO - 2024-03-09 05:12:34 --> Loader Class Initialized
INFO - 2024-03-09 05:12:34 --> Helper loaded: url_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: file_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: html_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: text_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: form_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: lang_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: security_helper
INFO - 2024-03-09 05:12:34 --> Helper loaded: cookie_helper
INFO - 2024-03-09 05:12:34 --> Database Driver Class Initialized
INFO - 2024-03-09 05:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 05:12:34 --> Parser Class Initialized
INFO - 2024-03-09 05:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 05:12:34 --> Pagination Class Initialized
INFO - 2024-03-09 05:12:34 --> Form Validation Class Initialized
INFO - 2024-03-09 05:12:34 --> Controller Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
DEBUG - 2024-03-09 05:12:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 05:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 05:12:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 05:12:34 --> Model Class Initialized
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 05:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 05:12:34 --> Final output sent to browser
DEBUG - 2024-03-09 05:12:34 --> Total execution time: 0.2628
ERROR - 2024-03-09 06:22:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:22:17 --> Config Class Initialized
INFO - 2024-03-09 06:22:17 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:22:17 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:22:17 --> Utf8 Class Initialized
INFO - 2024-03-09 06:22:17 --> URI Class Initialized
DEBUG - 2024-03-09 06:22:17 --> No URI present. Default controller set.
INFO - 2024-03-09 06:22:17 --> Router Class Initialized
INFO - 2024-03-09 06:22:17 --> Output Class Initialized
INFO - 2024-03-09 06:22:17 --> Security Class Initialized
DEBUG - 2024-03-09 06:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:22:17 --> Input Class Initialized
INFO - 2024-03-09 06:22:17 --> Language Class Initialized
INFO - 2024-03-09 06:22:17 --> Loader Class Initialized
INFO - 2024-03-09 06:22:17 --> Helper loaded: url_helper
INFO - 2024-03-09 06:22:17 --> Helper loaded: file_helper
INFO - 2024-03-09 06:22:17 --> Helper loaded: html_helper
INFO - 2024-03-09 06:22:17 --> Helper loaded: text_helper
INFO - 2024-03-09 06:22:17 --> Helper loaded: form_helper
INFO - 2024-03-09 06:22:17 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:22:17 --> Helper loaded: security_helper
INFO - 2024-03-09 06:22:17 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:22:17 --> Database Driver Class Initialized
INFO - 2024-03-09 06:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:22:17 --> Parser Class Initialized
INFO - 2024-03-09 06:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:22:17 --> Pagination Class Initialized
INFO - 2024-03-09 06:22:17 --> Form Validation Class Initialized
INFO - 2024-03-09 06:22:17 --> Controller Class Initialized
INFO - 2024-03-09 06:22:17 --> Model Class Initialized
DEBUG - 2024-03-09 06:22:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-09 06:22:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:22:18 --> Config Class Initialized
INFO - 2024-03-09 06:22:18 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:22:18 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:22:18 --> Utf8 Class Initialized
INFO - 2024-03-09 06:22:18 --> URI Class Initialized
INFO - 2024-03-09 06:22:18 --> Router Class Initialized
INFO - 2024-03-09 06:22:18 --> Output Class Initialized
INFO - 2024-03-09 06:22:18 --> Security Class Initialized
DEBUG - 2024-03-09 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:22:18 --> Input Class Initialized
INFO - 2024-03-09 06:22:18 --> Language Class Initialized
INFO - 2024-03-09 06:22:18 --> Loader Class Initialized
INFO - 2024-03-09 06:22:18 --> Helper loaded: url_helper
INFO - 2024-03-09 06:22:18 --> Helper loaded: file_helper
INFO - 2024-03-09 06:22:18 --> Helper loaded: html_helper
INFO - 2024-03-09 06:22:18 --> Helper loaded: text_helper
INFO - 2024-03-09 06:22:18 --> Helper loaded: form_helper
INFO - 2024-03-09 06:22:18 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:22:18 --> Helper loaded: security_helper
INFO - 2024-03-09 06:22:18 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:22:18 --> Database Driver Class Initialized
INFO - 2024-03-09 06:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:22:18 --> Parser Class Initialized
INFO - 2024-03-09 06:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:22:18 --> Pagination Class Initialized
INFO - 2024-03-09 06:22:18 --> Form Validation Class Initialized
INFO - 2024-03-09 06:22:18 --> Controller Class Initialized
INFO - 2024-03-09 06:22:18 --> Model Class Initialized
DEBUG - 2024-03-09 06:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 06:22:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:22:18 --> Model Class Initialized
INFO - 2024-03-09 06:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:22:18 --> Final output sent to browser
DEBUG - 2024-03-09 06:22:18 --> Total execution time: 0.0303
ERROR - 2024-03-09 06:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:23:07 --> Config Class Initialized
INFO - 2024-03-09 06:23:07 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:23:07 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:23:07 --> Utf8 Class Initialized
INFO - 2024-03-09 06:23:07 --> URI Class Initialized
INFO - 2024-03-09 06:23:07 --> Router Class Initialized
INFO - 2024-03-09 06:23:07 --> Output Class Initialized
INFO - 2024-03-09 06:23:07 --> Security Class Initialized
DEBUG - 2024-03-09 06:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:23:07 --> Input Class Initialized
INFO - 2024-03-09 06:23:07 --> Language Class Initialized
INFO - 2024-03-09 06:23:07 --> Loader Class Initialized
INFO - 2024-03-09 06:23:07 --> Helper loaded: url_helper
INFO - 2024-03-09 06:23:07 --> Helper loaded: file_helper
INFO - 2024-03-09 06:23:07 --> Helper loaded: html_helper
INFO - 2024-03-09 06:23:07 --> Helper loaded: text_helper
INFO - 2024-03-09 06:23:07 --> Helper loaded: form_helper
INFO - 2024-03-09 06:23:07 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:23:07 --> Helper loaded: security_helper
INFO - 2024-03-09 06:23:07 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:23:07 --> Database Driver Class Initialized
INFO - 2024-03-09 06:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:23:07 --> Parser Class Initialized
INFO - 2024-03-09 06:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:23:07 --> Pagination Class Initialized
INFO - 2024-03-09 06:23:07 --> Form Validation Class Initialized
INFO - 2024-03-09 06:23:07 --> Controller Class Initialized
INFO - 2024-03-09 06:23:07 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:07 --> Model Class Initialized
INFO - 2024-03-09 06:23:07 --> Final output sent to browser
DEBUG - 2024-03-09 06:23:07 --> Total execution time: 0.0204
ERROR - 2024-03-09 06:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:23:08 --> Config Class Initialized
INFO - 2024-03-09 06:23:08 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:23:08 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:23:08 --> Utf8 Class Initialized
INFO - 2024-03-09 06:23:08 --> URI Class Initialized
DEBUG - 2024-03-09 06:23:08 --> No URI present. Default controller set.
INFO - 2024-03-09 06:23:08 --> Router Class Initialized
INFO - 2024-03-09 06:23:08 --> Output Class Initialized
INFO - 2024-03-09 06:23:08 --> Security Class Initialized
DEBUG - 2024-03-09 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:23:08 --> Input Class Initialized
INFO - 2024-03-09 06:23:08 --> Language Class Initialized
INFO - 2024-03-09 06:23:08 --> Loader Class Initialized
INFO - 2024-03-09 06:23:08 --> Helper loaded: url_helper
INFO - 2024-03-09 06:23:08 --> Helper loaded: file_helper
INFO - 2024-03-09 06:23:08 --> Helper loaded: html_helper
INFO - 2024-03-09 06:23:08 --> Helper loaded: text_helper
INFO - 2024-03-09 06:23:08 --> Helper loaded: form_helper
INFO - 2024-03-09 06:23:08 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:23:08 --> Helper loaded: security_helper
INFO - 2024-03-09 06:23:08 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:23:08 --> Database Driver Class Initialized
INFO - 2024-03-09 06:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:23:08 --> Parser Class Initialized
INFO - 2024-03-09 06:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:23:08 --> Pagination Class Initialized
INFO - 2024-03-09 06:23:08 --> Form Validation Class Initialized
INFO - 2024-03-09 06:23:08 --> Controller Class Initialized
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
INFO - 2024-03-09 06:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 06:23:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:23:08 --> Model Class Initialized
INFO - 2024-03-09 06:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:23:08 --> Final output sent to browser
DEBUG - 2024-03-09 06:23:08 --> Total execution time: 0.2363
ERROR - 2024-03-09 06:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:23:30 --> Config Class Initialized
INFO - 2024-03-09 06:23:30 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:23:30 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:23:30 --> Utf8 Class Initialized
INFO - 2024-03-09 06:23:30 --> URI Class Initialized
INFO - 2024-03-09 06:23:30 --> Router Class Initialized
INFO - 2024-03-09 06:23:30 --> Output Class Initialized
INFO - 2024-03-09 06:23:30 --> Security Class Initialized
DEBUG - 2024-03-09 06:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:23:30 --> Input Class Initialized
INFO - 2024-03-09 06:23:30 --> Language Class Initialized
INFO - 2024-03-09 06:23:30 --> Loader Class Initialized
INFO - 2024-03-09 06:23:30 --> Helper loaded: url_helper
INFO - 2024-03-09 06:23:30 --> Helper loaded: file_helper
INFO - 2024-03-09 06:23:30 --> Helper loaded: html_helper
INFO - 2024-03-09 06:23:30 --> Helper loaded: text_helper
INFO - 2024-03-09 06:23:30 --> Helper loaded: form_helper
INFO - 2024-03-09 06:23:30 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:23:30 --> Helper loaded: security_helper
INFO - 2024-03-09 06:23:30 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:23:30 --> Database Driver Class Initialized
INFO - 2024-03-09 06:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:23:30 --> Parser Class Initialized
INFO - 2024-03-09 06:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:23:30 --> Pagination Class Initialized
INFO - 2024-03-09 06:23:30 --> Form Validation Class Initialized
INFO - 2024-03-09 06:23:30 --> Controller Class Initialized
INFO - 2024-03-09 06:23:30 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:30 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:30 --> Model Class Initialized
INFO - 2024-03-09 06:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-03-09 06:23:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:23:30 --> Model Class Initialized
INFO - 2024-03-09 06:23:30 --> Model Class Initialized
INFO - 2024-03-09 06:23:30 --> Model Class Initialized
INFO - 2024-03-09 06:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:23:30 --> Final output sent to browser
DEBUG - 2024-03-09 06:23:30 --> Total execution time: 0.1480
ERROR - 2024-03-09 06:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:23:31 --> Config Class Initialized
INFO - 2024-03-09 06:23:31 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:23:31 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:23:31 --> Utf8 Class Initialized
INFO - 2024-03-09 06:23:31 --> URI Class Initialized
INFO - 2024-03-09 06:23:31 --> Router Class Initialized
INFO - 2024-03-09 06:23:31 --> Output Class Initialized
INFO - 2024-03-09 06:23:31 --> Security Class Initialized
DEBUG - 2024-03-09 06:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:23:31 --> Input Class Initialized
INFO - 2024-03-09 06:23:31 --> Language Class Initialized
INFO - 2024-03-09 06:23:31 --> Loader Class Initialized
INFO - 2024-03-09 06:23:31 --> Helper loaded: url_helper
INFO - 2024-03-09 06:23:31 --> Helper loaded: file_helper
INFO - 2024-03-09 06:23:31 --> Helper loaded: html_helper
INFO - 2024-03-09 06:23:31 --> Helper loaded: text_helper
INFO - 2024-03-09 06:23:31 --> Helper loaded: form_helper
INFO - 2024-03-09 06:23:31 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:23:31 --> Helper loaded: security_helper
INFO - 2024-03-09 06:23:31 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:23:31 --> Database Driver Class Initialized
INFO - 2024-03-09 06:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:23:31 --> Parser Class Initialized
INFO - 2024-03-09 06:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:23:31 --> Pagination Class Initialized
INFO - 2024-03-09 06:23:31 --> Form Validation Class Initialized
INFO - 2024-03-09 06:23:31 --> Controller Class Initialized
INFO - 2024-03-09 06:23:31 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:31 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:31 --> Model Class Initialized
INFO - 2024-03-09 06:23:31 --> Final output sent to browser
DEBUG - 2024-03-09 06:23:31 --> Total execution time: 0.0244
ERROR - 2024-03-09 06:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:23:43 --> Config Class Initialized
INFO - 2024-03-09 06:23:43 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:23:43 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:23:43 --> Utf8 Class Initialized
INFO - 2024-03-09 06:23:43 --> URI Class Initialized
INFO - 2024-03-09 06:23:43 --> Router Class Initialized
INFO - 2024-03-09 06:23:43 --> Output Class Initialized
INFO - 2024-03-09 06:23:43 --> Security Class Initialized
DEBUG - 2024-03-09 06:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:23:43 --> Input Class Initialized
INFO - 2024-03-09 06:23:43 --> Language Class Initialized
INFO - 2024-03-09 06:23:43 --> Loader Class Initialized
INFO - 2024-03-09 06:23:43 --> Helper loaded: url_helper
INFO - 2024-03-09 06:23:43 --> Helper loaded: file_helper
INFO - 2024-03-09 06:23:43 --> Helper loaded: html_helper
INFO - 2024-03-09 06:23:43 --> Helper loaded: text_helper
INFO - 2024-03-09 06:23:43 --> Helper loaded: form_helper
INFO - 2024-03-09 06:23:43 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:23:43 --> Helper loaded: security_helper
INFO - 2024-03-09 06:23:43 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:23:43 --> Database Driver Class Initialized
INFO - 2024-03-09 06:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:23:43 --> Parser Class Initialized
INFO - 2024-03-09 06:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:23:43 --> Pagination Class Initialized
INFO - 2024-03-09 06:23:43 --> Form Validation Class Initialized
INFO - 2024-03-09 06:23:43 --> Controller Class Initialized
INFO - 2024-03-09 06:23:43 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:43 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:43 --> Model Class Initialized
INFO - 2024-03-09 06:23:43 --> Final output sent to browser
DEBUG - 2024-03-09 06:23:43 --> Total execution time: 0.0263
ERROR - 2024-03-09 06:23:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:23:48 --> Config Class Initialized
INFO - 2024-03-09 06:23:48 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:23:48 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:23:48 --> Utf8 Class Initialized
INFO - 2024-03-09 06:23:48 --> URI Class Initialized
INFO - 2024-03-09 06:23:48 --> Router Class Initialized
INFO - 2024-03-09 06:23:48 --> Output Class Initialized
INFO - 2024-03-09 06:23:48 --> Security Class Initialized
DEBUG - 2024-03-09 06:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:23:48 --> Input Class Initialized
INFO - 2024-03-09 06:23:48 --> Language Class Initialized
INFO - 2024-03-09 06:23:48 --> Loader Class Initialized
INFO - 2024-03-09 06:23:48 --> Helper loaded: url_helper
INFO - 2024-03-09 06:23:48 --> Helper loaded: file_helper
INFO - 2024-03-09 06:23:48 --> Helper loaded: html_helper
INFO - 2024-03-09 06:23:48 --> Helper loaded: text_helper
INFO - 2024-03-09 06:23:48 --> Helper loaded: form_helper
INFO - 2024-03-09 06:23:48 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:23:48 --> Helper loaded: security_helper
INFO - 2024-03-09 06:23:48 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:23:48 --> Database Driver Class Initialized
INFO - 2024-03-09 06:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:23:48 --> Parser Class Initialized
INFO - 2024-03-09 06:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:23:48 --> Pagination Class Initialized
INFO - 2024-03-09 06:23:48 --> Form Validation Class Initialized
INFO - 2024-03-09 06:23:48 --> Controller Class Initialized
INFO - 2024-03-09 06:23:48 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:48 --> Model Class Initialized
DEBUG - 2024-03-09 06:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:23:48 --> Model Class Initialized
INFO - 2024-03-09 06:23:48 --> Final output sent to browser
DEBUG - 2024-03-09 06:23:48 --> Total execution time: 0.0240
ERROR - 2024-03-09 06:24:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:24:28 --> Config Class Initialized
INFO - 2024-03-09 06:24:28 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:24:28 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:24:28 --> Utf8 Class Initialized
INFO - 2024-03-09 06:24:28 --> URI Class Initialized
INFO - 2024-03-09 06:24:28 --> Router Class Initialized
INFO - 2024-03-09 06:24:28 --> Output Class Initialized
INFO - 2024-03-09 06:24:28 --> Security Class Initialized
DEBUG - 2024-03-09 06:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:24:28 --> Input Class Initialized
INFO - 2024-03-09 06:24:28 --> Language Class Initialized
INFO - 2024-03-09 06:24:28 --> Loader Class Initialized
INFO - 2024-03-09 06:24:28 --> Helper loaded: url_helper
INFO - 2024-03-09 06:24:28 --> Helper loaded: file_helper
INFO - 2024-03-09 06:24:28 --> Helper loaded: html_helper
INFO - 2024-03-09 06:24:28 --> Helper loaded: text_helper
INFO - 2024-03-09 06:24:28 --> Helper loaded: form_helper
INFO - 2024-03-09 06:24:28 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:24:28 --> Helper loaded: security_helper
INFO - 2024-03-09 06:24:28 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:24:28 --> Database Driver Class Initialized
INFO - 2024-03-09 06:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:24:28 --> Parser Class Initialized
INFO - 2024-03-09 06:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:24:28 --> Pagination Class Initialized
INFO - 2024-03-09 06:24:28 --> Form Validation Class Initialized
INFO - 2024-03-09 06:24:28 --> Controller Class Initialized
INFO - 2024-03-09 06:24:28 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:28 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:28 --> Model Class Initialized
INFO - 2024-03-09 06:24:28 --> Final output sent to browser
DEBUG - 2024-03-09 06:24:28 --> Total execution time: 0.0286
ERROR - 2024-03-09 06:24:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:24:40 --> Config Class Initialized
INFO - 2024-03-09 06:24:40 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:24:40 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:24:40 --> Utf8 Class Initialized
INFO - 2024-03-09 06:24:40 --> URI Class Initialized
INFO - 2024-03-09 06:24:40 --> Router Class Initialized
INFO - 2024-03-09 06:24:40 --> Output Class Initialized
INFO - 2024-03-09 06:24:40 --> Security Class Initialized
DEBUG - 2024-03-09 06:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:24:40 --> Input Class Initialized
INFO - 2024-03-09 06:24:40 --> Language Class Initialized
INFO - 2024-03-09 06:24:40 --> Loader Class Initialized
INFO - 2024-03-09 06:24:40 --> Helper loaded: url_helper
INFO - 2024-03-09 06:24:40 --> Helper loaded: file_helper
INFO - 2024-03-09 06:24:40 --> Helper loaded: html_helper
INFO - 2024-03-09 06:24:40 --> Helper loaded: text_helper
INFO - 2024-03-09 06:24:40 --> Helper loaded: form_helper
INFO - 2024-03-09 06:24:40 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:24:40 --> Helper loaded: security_helper
INFO - 2024-03-09 06:24:40 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:24:40 --> Database Driver Class Initialized
INFO - 2024-03-09 06:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:24:40 --> Parser Class Initialized
INFO - 2024-03-09 06:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:24:40 --> Pagination Class Initialized
INFO - 2024-03-09 06:24:40 --> Form Validation Class Initialized
INFO - 2024-03-09 06:24:40 --> Controller Class Initialized
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
INFO - 2024-03-09 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-03-09 06:24:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
INFO - 2024-03-09 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:24:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:24:41 --> Final output sent to browser
DEBUG - 2024-03-09 06:24:41 --> Total execution time: 0.1456
ERROR - 2024-03-09 06:24:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:24:41 --> Config Class Initialized
INFO - 2024-03-09 06:24:41 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:24:41 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:24:41 --> Utf8 Class Initialized
INFO - 2024-03-09 06:24:41 --> URI Class Initialized
INFO - 2024-03-09 06:24:41 --> Router Class Initialized
INFO - 2024-03-09 06:24:41 --> Output Class Initialized
INFO - 2024-03-09 06:24:41 --> Security Class Initialized
DEBUG - 2024-03-09 06:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:24:41 --> Input Class Initialized
INFO - 2024-03-09 06:24:41 --> Language Class Initialized
INFO - 2024-03-09 06:24:41 --> Loader Class Initialized
INFO - 2024-03-09 06:24:41 --> Helper loaded: url_helper
INFO - 2024-03-09 06:24:41 --> Helper loaded: file_helper
INFO - 2024-03-09 06:24:41 --> Helper loaded: html_helper
INFO - 2024-03-09 06:24:41 --> Helper loaded: text_helper
INFO - 2024-03-09 06:24:41 --> Helper loaded: form_helper
INFO - 2024-03-09 06:24:41 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:24:41 --> Helper loaded: security_helper
INFO - 2024-03-09 06:24:41 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:24:41 --> Database Driver Class Initialized
INFO - 2024-03-09 06:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:24:41 --> Parser Class Initialized
INFO - 2024-03-09 06:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:24:41 --> Pagination Class Initialized
INFO - 2024-03-09 06:24:41 --> Form Validation Class Initialized
INFO - 2024-03-09 06:24:41 --> Controller Class Initialized
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:41 --> Model Class Initialized
INFO - 2024-03-09 06:24:41 --> Final output sent to browser
DEBUG - 2024-03-09 06:24:41 --> Total execution time: 0.0285
ERROR - 2024-03-09 06:24:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:24:54 --> Config Class Initialized
INFO - 2024-03-09 06:24:54 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:24:54 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:24:54 --> Utf8 Class Initialized
INFO - 2024-03-09 06:24:54 --> URI Class Initialized
INFO - 2024-03-09 06:24:54 --> Router Class Initialized
INFO - 2024-03-09 06:24:54 --> Output Class Initialized
INFO - 2024-03-09 06:24:54 --> Security Class Initialized
DEBUG - 2024-03-09 06:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:24:54 --> Input Class Initialized
INFO - 2024-03-09 06:24:54 --> Language Class Initialized
INFO - 2024-03-09 06:24:54 --> Loader Class Initialized
INFO - 2024-03-09 06:24:54 --> Helper loaded: url_helper
INFO - 2024-03-09 06:24:54 --> Helper loaded: file_helper
INFO - 2024-03-09 06:24:54 --> Helper loaded: html_helper
INFO - 2024-03-09 06:24:54 --> Helper loaded: text_helper
INFO - 2024-03-09 06:24:54 --> Helper loaded: form_helper
INFO - 2024-03-09 06:24:54 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:24:54 --> Helper loaded: security_helper
INFO - 2024-03-09 06:24:54 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:24:54 --> Database Driver Class Initialized
INFO - 2024-03-09 06:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:24:54 --> Parser Class Initialized
INFO - 2024-03-09 06:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:24:54 --> Pagination Class Initialized
INFO - 2024-03-09 06:24:54 --> Form Validation Class Initialized
INFO - 2024-03-09 06:24:54 --> Controller Class Initialized
INFO - 2024-03-09 06:24:54 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:54 --> Model Class Initialized
DEBUG - 2024-03-09 06:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:24:54 --> Model Class Initialized
INFO - 2024-03-09 06:24:54 --> Final output sent to browser
DEBUG - 2024-03-09 06:24:54 --> Total execution time: 0.0295
ERROR - 2024-03-09 06:25:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:25:25 --> Config Class Initialized
INFO - 2024-03-09 06:25:25 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:25:25 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:25:25 --> Utf8 Class Initialized
INFO - 2024-03-09 06:25:25 --> URI Class Initialized
DEBUG - 2024-03-09 06:25:25 --> No URI present. Default controller set.
INFO - 2024-03-09 06:25:25 --> Router Class Initialized
INFO - 2024-03-09 06:25:25 --> Output Class Initialized
INFO - 2024-03-09 06:25:25 --> Security Class Initialized
DEBUG - 2024-03-09 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:25:25 --> Input Class Initialized
INFO - 2024-03-09 06:25:25 --> Language Class Initialized
INFO - 2024-03-09 06:25:25 --> Loader Class Initialized
INFO - 2024-03-09 06:25:25 --> Helper loaded: url_helper
INFO - 2024-03-09 06:25:25 --> Helper loaded: file_helper
INFO - 2024-03-09 06:25:25 --> Helper loaded: html_helper
INFO - 2024-03-09 06:25:25 --> Helper loaded: text_helper
INFO - 2024-03-09 06:25:25 --> Helper loaded: form_helper
INFO - 2024-03-09 06:25:25 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:25:25 --> Helper loaded: security_helper
INFO - 2024-03-09 06:25:25 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:25:25 --> Database Driver Class Initialized
INFO - 2024-03-09 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:25:25 --> Parser Class Initialized
INFO - 2024-03-09 06:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:25:25 --> Pagination Class Initialized
INFO - 2024-03-09 06:25:25 --> Form Validation Class Initialized
INFO - 2024-03-09 06:25:25 --> Controller Class Initialized
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
INFO - 2024-03-09 06:25:25 --> Model Class Initialized
INFO - 2024-03-09 06:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 06:25:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:25:26 --> Model Class Initialized
INFO - 2024-03-09 06:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:25:26 --> Final output sent to browser
DEBUG - 2024-03-09 06:25:26 --> Total execution time: 0.2441
ERROR - 2024-03-09 06:25:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:25:45 --> Config Class Initialized
INFO - 2024-03-09 06:25:45 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:25:45 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:25:45 --> Utf8 Class Initialized
INFO - 2024-03-09 06:25:45 --> URI Class Initialized
INFO - 2024-03-09 06:25:45 --> Router Class Initialized
INFO - 2024-03-09 06:25:45 --> Output Class Initialized
INFO - 2024-03-09 06:25:45 --> Security Class Initialized
DEBUG - 2024-03-09 06:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:25:45 --> Input Class Initialized
INFO - 2024-03-09 06:25:45 --> Language Class Initialized
INFO - 2024-03-09 06:25:45 --> Loader Class Initialized
INFO - 2024-03-09 06:25:45 --> Helper loaded: url_helper
INFO - 2024-03-09 06:25:45 --> Helper loaded: file_helper
INFO - 2024-03-09 06:25:45 --> Helper loaded: html_helper
INFO - 2024-03-09 06:25:45 --> Helper loaded: text_helper
INFO - 2024-03-09 06:25:45 --> Helper loaded: form_helper
INFO - 2024-03-09 06:25:45 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:25:45 --> Helper loaded: security_helper
INFO - 2024-03-09 06:25:45 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:25:45 --> Database Driver Class Initialized
INFO - 2024-03-09 06:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:25:45 --> Parser Class Initialized
INFO - 2024-03-09 06:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:25:45 --> Pagination Class Initialized
INFO - 2024-03-09 06:25:45 --> Form Validation Class Initialized
INFO - 2024-03-09 06:25:45 --> Controller Class Initialized
INFO - 2024-03-09 06:25:45 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:45 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:45 --> Model Class Initialized
INFO - 2024-03-09 06:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-03-09 06:25:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:25:45 --> Model Class Initialized
INFO - 2024-03-09 06:25:45 --> Model Class Initialized
INFO - 2024-03-09 06:25:45 --> Model Class Initialized
INFO - 2024-03-09 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:25:46 --> Final output sent to browser
DEBUG - 2024-03-09 06:25:46 --> Total execution time: 0.1548
ERROR - 2024-03-09 06:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:25:46 --> Config Class Initialized
INFO - 2024-03-09 06:25:46 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:25:46 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:25:46 --> Utf8 Class Initialized
INFO - 2024-03-09 06:25:46 --> URI Class Initialized
INFO - 2024-03-09 06:25:46 --> Router Class Initialized
INFO - 2024-03-09 06:25:46 --> Output Class Initialized
INFO - 2024-03-09 06:25:46 --> Security Class Initialized
DEBUG - 2024-03-09 06:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:25:46 --> Input Class Initialized
INFO - 2024-03-09 06:25:46 --> Language Class Initialized
INFO - 2024-03-09 06:25:46 --> Loader Class Initialized
INFO - 2024-03-09 06:25:46 --> Helper loaded: url_helper
INFO - 2024-03-09 06:25:46 --> Helper loaded: file_helper
INFO - 2024-03-09 06:25:46 --> Helper loaded: html_helper
INFO - 2024-03-09 06:25:46 --> Helper loaded: text_helper
INFO - 2024-03-09 06:25:46 --> Helper loaded: form_helper
INFO - 2024-03-09 06:25:46 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:25:46 --> Helper loaded: security_helper
INFO - 2024-03-09 06:25:46 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:25:46 --> Database Driver Class Initialized
INFO - 2024-03-09 06:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:25:46 --> Parser Class Initialized
INFO - 2024-03-09 06:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:25:46 --> Pagination Class Initialized
INFO - 2024-03-09 06:25:46 --> Form Validation Class Initialized
INFO - 2024-03-09 06:25:46 --> Controller Class Initialized
INFO - 2024-03-09 06:25:46 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:46 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:46 --> Model Class Initialized
INFO - 2024-03-09 06:25:46 --> Final output sent to browser
DEBUG - 2024-03-09 06:25:46 --> Total execution time: 0.0289
ERROR - 2024-03-09 06:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:25:51 --> Config Class Initialized
INFO - 2024-03-09 06:25:51 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:25:51 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:25:51 --> Utf8 Class Initialized
INFO - 2024-03-09 06:25:51 --> URI Class Initialized
INFO - 2024-03-09 06:25:51 --> Router Class Initialized
INFO - 2024-03-09 06:25:51 --> Output Class Initialized
INFO - 2024-03-09 06:25:51 --> Security Class Initialized
DEBUG - 2024-03-09 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:25:51 --> Input Class Initialized
INFO - 2024-03-09 06:25:51 --> Language Class Initialized
INFO - 2024-03-09 06:25:51 --> Loader Class Initialized
INFO - 2024-03-09 06:25:51 --> Helper loaded: url_helper
INFO - 2024-03-09 06:25:51 --> Helper loaded: file_helper
INFO - 2024-03-09 06:25:51 --> Helper loaded: html_helper
INFO - 2024-03-09 06:25:51 --> Helper loaded: text_helper
INFO - 2024-03-09 06:25:51 --> Helper loaded: form_helper
INFO - 2024-03-09 06:25:51 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:25:51 --> Helper loaded: security_helper
INFO - 2024-03-09 06:25:51 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:25:51 --> Database Driver Class Initialized
INFO - 2024-03-09 06:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:25:51 --> Parser Class Initialized
INFO - 2024-03-09 06:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:25:51 --> Pagination Class Initialized
INFO - 2024-03-09 06:25:51 --> Form Validation Class Initialized
INFO - 2024-03-09 06:25:51 --> Controller Class Initialized
INFO - 2024-03-09 06:25:51 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:51 --> Model Class Initialized
DEBUG - 2024-03-09 06:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:25:51 --> Model Class Initialized
INFO - 2024-03-09 06:25:51 --> Final output sent to browser
DEBUG - 2024-03-09 06:25:51 --> Total execution time: 0.0242
ERROR - 2024-03-09 06:26:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:26:41 --> Config Class Initialized
INFO - 2024-03-09 06:26:41 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:26:41 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:26:41 --> Utf8 Class Initialized
INFO - 2024-03-09 06:26:41 --> URI Class Initialized
INFO - 2024-03-09 06:26:41 --> Router Class Initialized
INFO - 2024-03-09 06:26:41 --> Output Class Initialized
INFO - 2024-03-09 06:26:41 --> Security Class Initialized
DEBUG - 2024-03-09 06:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:26:41 --> Input Class Initialized
INFO - 2024-03-09 06:26:41 --> Language Class Initialized
INFO - 2024-03-09 06:26:41 --> Loader Class Initialized
INFO - 2024-03-09 06:26:41 --> Helper loaded: url_helper
INFO - 2024-03-09 06:26:41 --> Helper loaded: file_helper
INFO - 2024-03-09 06:26:41 --> Helper loaded: html_helper
INFO - 2024-03-09 06:26:41 --> Helper loaded: text_helper
INFO - 2024-03-09 06:26:41 --> Helper loaded: form_helper
INFO - 2024-03-09 06:26:41 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:26:41 --> Helper loaded: security_helper
INFO - 2024-03-09 06:26:41 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:26:41 --> Database Driver Class Initialized
INFO - 2024-03-09 06:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:26:41 --> Parser Class Initialized
INFO - 2024-03-09 06:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:26:41 --> Pagination Class Initialized
INFO - 2024-03-09 06:26:41 --> Form Validation Class Initialized
INFO - 2024-03-09 06:26:41 --> Controller Class Initialized
INFO - 2024-03-09 06:26:41 --> Model Class Initialized
DEBUG - 2024-03-09 06:26:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:26:41 --> Model Class Initialized
DEBUG - 2024-03-09 06:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:26:41 --> Model Class Initialized
INFO - 2024-03-09 06:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-03-09 06:26:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:26:41 --> Model Class Initialized
INFO - 2024-03-09 06:26:41 --> Model Class Initialized
INFO - 2024-03-09 06:26:41 --> Model Class Initialized
INFO - 2024-03-09 06:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:26:41 --> Final output sent to browser
DEBUG - 2024-03-09 06:26:41 --> Total execution time: 0.1545
ERROR - 2024-03-09 06:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:27:03 --> Config Class Initialized
INFO - 2024-03-09 06:27:03 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:27:03 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:27:03 --> Utf8 Class Initialized
INFO - 2024-03-09 06:27:03 --> URI Class Initialized
INFO - 2024-03-09 06:27:03 --> Router Class Initialized
INFO - 2024-03-09 06:27:03 --> Output Class Initialized
INFO - 2024-03-09 06:27:03 --> Security Class Initialized
DEBUG - 2024-03-09 06:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:27:03 --> Input Class Initialized
INFO - 2024-03-09 06:27:03 --> Language Class Initialized
INFO - 2024-03-09 06:27:03 --> Loader Class Initialized
INFO - 2024-03-09 06:27:03 --> Helper loaded: url_helper
INFO - 2024-03-09 06:27:03 --> Helper loaded: file_helper
INFO - 2024-03-09 06:27:03 --> Helper loaded: html_helper
INFO - 2024-03-09 06:27:03 --> Helper loaded: text_helper
INFO - 2024-03-09 06:27:03 --> Helper loaded: form_helper
INFO - 2024-03-09 06:27:03 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:27:03 --> Helper loaded: security_helper
INFO - 2024-03-09 06:27:03 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:27:03 --> Database Driver Class Initialized
INFO - 2024-03-09 06:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:27:03 --> Parser Class Initialized
INFO - 2024-03-09 06:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:27:03 --> Pagination Class Initialized
INFO - 2024-03-09 06:27:03 --> Form Validation Class Initialized
INFO - 2024-03-09 06:27:03 --> Controller Class Initialized
INFO - 2024-03-09 06:27:03 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:03 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:03 --> Model Class Initialized
INFO - 2024-03-09 06:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-03-09 06:27:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:27:03 --> Model Class Initialized
INFO - 2024-03-09 06:27:03 --> Model Class Initialized
INFO - 2024-03-09 06:27:03 --> Model Class Initialized
INFO - 2024-03-09 06:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:27:04 --> Final output sent to browser
DEBUG - 2024-03-09 06:27:04 --> Total execution time: 0.1465
ERROR - 2024-03-09 06:27:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:27:04 --> Config Class Initialized
INFO - 2024-03-09 06:27:04 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:27:04 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:27:04 --> Utf8 Class Initialized
INFO - 2024-03-09 06:27:04 --> URI Class Initialized
INFO - 2024-03-09 06:27:04 --> Router Class Initialized
INFO - 2024-03-09 06:27:04 --> Output Class Initialized
INFO - 2024-03-09 06:27:04 --> Security Class Initialized
DEBUG - 2024-03-09 06:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:27:04 --> Input Class Initialized
INFO - 2024-03-09 06:27:04 --> Language Class Initialized
INFO - 2024-03-09 06:27:04 --> Loader Class Initialized
INFO - 2024-03-09 06:27:04 --> Helper loaded: url_helper
INFO - 2024-03-09 06:27:04 --> Helper loaded: file_helper
INFO - 2024-03-09 06:27:04 --> Helper loaded: html_helper
INFO - 2024-03-09 06:27:04 --> Helper loaded: text_helper
INFO - 2024-03-09 06:27:04 --> Helper loaded: form_helper
INFO - 2024-03-09 06:27:04 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:27:04 --> Helper loaded: security_helper
INFO - 2024-03-09 06:27:04 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:27:04 --> Database Driver Class Initialized
INFO - 2024-03-09 06:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:27:04 --> Parser Class Initialized
INFO - 2024-03-09 06:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:27:04 --> Pagination Class Initialized
INFO - 2024-03-09 06:27:04 --> Form Validation Class Initialized
INFO - 2024-03-09 06:27:04 --> Controller Class Initialized
INFO - 2024-03-09 06:27:04 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:04 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:04 --> Model Class Initialized
INFO - 2024-03-09 06:27:04 --> Final output sent to browser
DEBUG - 2024-03-09 06:27:04 --> Total execution time: 0.0266
ERROR - 2024-03-09 06:27:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:27:16 --> Config Class Initialized
INFO - 2024-03-09 06:27:16 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:27:16 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:27:16 --> Utf8 Class Initialized
INFO - 2024-03-09 06:27:16 --> URI Class Initialized
DEBUG - 2024-03-09 06:27:16 --> No URI present. Default controller set.
INFO - 2024-03-09 06:27:16 --> Router Class Initialized
INFO - 2024-03-09 06:27:16 --> Output Class Initialized
INFO - 2024-03-09 06:27:16 --> Security Class Initialized
DEBUG - 2024-03-09 06:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:27:16 --> Input Class Initialized
INFO - 2024-03-09 06:27:16 --> Language Class Initialized
INFO - 2024-03-09 06:27:16 --> Loader Class Initialized
INFO - 2024-03-09 06:27:16 --> Helper loaded: url_helper
INFO - 2024-03-09 06:27:16 --> Helper loaded: file_helper
INFO - 2024-03-09 06:27:16 --> Helper loaded: html_helper
INFO - 2024-03-09 06:27:16 --> Helper loaded: text_helper
INFO - 2024-03-09 06:27:16 --> Helper loaded: form_helper
INFO - 2024-03-09 06:27:16 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:27:16 --> Helper loaded: security_helper
INFO - 2024-03-09 06:27:16 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:27:16 --> Database Driver Class Initialized
INFO - 2024-03-09 06:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:27:16 --> Parser Class Initialized
INFO - 2024-03-09 06:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:27:16 --> Pagination Class Initialized
INFO - 2024-03-09 06:27:16 --> Form Validation Class Initialized
INFO - 2024-03-09 06:27:16 --> Controller Class Initialized
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
INFO - 2024-03-09 06:27:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 06:27:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:27:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:27:16 --> Model Class Initialized
INFO - 2024-03-09 06:27:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:27:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:27:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:27:16 --> Final output sent to browser
DEBUG - 2024-03-09 06:27:16 --> Total execution time: 0.2353
ERROR - 2024-03-09 06:27:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:27:21 --> Config Class Initialized
INFO - 2024-03-09 06:27:21 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:27:21 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:27:21 --> Utf8 Class Initialized
INFO - 2024-03-09 06:27:21 --> URI Class Initialized
INFO - 2024-03-09 06:27:21 --> Router Class Initialized
INFO - 2024-03-09 06:27:21 --> Output Class Initialized
INFO - 2024-03-09 06:27:21 --> Security Class Initialized
DEBUG - 2024-03-09 06:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:27:21 --> Input Class Initialized
INFO - 2024-03-09 06:27:21 --> Language Class Initialized
INFO - 2024-03-09 06:27:21 --> Loader Class Initialized
INFO - 2024-03-09 06:27:21 --> Helper loaded: url_helper
INFO - 2024-03-09 06:27:21 --> Helper loaded: file_helper
INFO - 2024-03-09 06:27:21 --> Helper loaded: html_helper
INFO - 2024-03-09 06:27:21 --> Helper loaded: text_helper
INFO - 2024-03-09 06:27:21 --> Helper loaded: form_helper
INFO - 2024-03-09 06:27:21 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:27:21 --> Helper loaded: security_helper
INFO - 2024-03-09 06:27:21 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:27:21 --> Database Driver Class Initialized
INFO - 2024-03-09 06:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:27:21 --> Parser Class Initialized
INFO - 2024-03-09 06:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:27:21 --> Pagination Class Initialized
INFO - 2024-03-09 06:27:21 --> Form Validation Class Initialized
INFO - 2024-03-09 06:27:21 --> Controller Class Initialized
INFO - 2024-03-09 06:27:21 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 06:27:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:27:21 --> Model Class Initialized
INFO - 2024-03-09 06:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:27:21 --> Final output sent to browser
DEBUG - 2024-03-09 06:27:21 --> Total execution time: 0.0312
ERROR - 2024-03-09 06:27:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 06:27:22 --> Config Class Initialized
INFO - 2024-03-09 06:27:22 --> Hooks Class Initialized
DEBUG - 2024-03-09 06:27:22 --> UTF-8 Support Enabled
INFO - 2024-03-09 06:27:22 --> Utf8 Class Initialized
INFO - 2024-03-09 06:27:22 --> URI Class Initialized
INFO - 2024-03-09 06:27:22 --> Router Class Initialized
INFO - 2024-03-09 06:27:22 --> Output Class Initialized
INFO - 2024-03-09 06:27:22 --> Security Class Initialized
DEBUG - 2024-03-09 06:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 06:27:22 --> Input Class Initialized
INFO - 2024-03-09 06:27:22 --> Language Class Initialized
INFO - 2024-03-09 06:27:22 --> Loader Class Initialized
INFO - 2024-03-09 06:27:22 --> Helper loaded: url_helper
INFO - 2024-03-09 06:27:22 --> Helper loaded: file_helper
INFO - 2024-03-09 06:27:22 --> Helper loaded: html_helper
INFO - 2024-03-09 06:27:22 --> Helper loaded: text_helper
INFO - 2024-03-09 06:27:22 --> Helper loaded: form_helper
INFO - 2024-03-09 06:27:22 --> Helper loaded: lang_helper
INFO - 2024-03-09 06:27:22 --> Helper loaded: security_helper
INFO - 2024-03-09 06:27:22 --> Helper loaded: cookie_helper
INFO - 2024-03-09 06:27:22 --> Database Driver Class Initialized
INFO - 2024-03-09 06:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 06:27:22 --> Parser Class Initialized
INFO - 2024-03-09 06:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 06:27:22 --> Pagination Class Initialized
INFO - 2024-03-09 06:27:22 --> Form Validation Class Initialized
INFO - 2024-03-09 06:27:22 --> Controller Class Initialized
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
DEBUG - 2024-03-09 06:27:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 06:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
INFO - 2024-03-09 06:27:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 06:27:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 06:27:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 06:27:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 06:27:22 --> Model Class Initialized
INFO - 2024-03-09 06:27:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 06:27:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 06:27:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 06:27:22 --> Final output sent to browser
DEBUG - 2024-03-09 06:27:22 --> Total execution time: 0.2347
ERROR - 2024-03-09 07:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 07:12:11 --> Config Class Initialized
INFO - 2024-03-09 07:12:11 --> Hooks Class Initialized
DEBUG - 2024-03-09 07:12:11 --> UTF-8 Support Enabled
INFO - 2024-03-09 07:12:11 --> Utf8 Class Initialized
INFO - 2024-03-09 07:12:11 --> URI Class Initialized
DEBUG - 2024-03-09 07:12:11 --> No URI present. Default controller set.
INFO - 2024-03-09 07:12:11 --> Router Class Initialized
INFO - 2024-03-09 07:12:11 --> Output Class Initialized
INFO - 2024-03-09 07:12:11 --> Security Class Initialized
DEBUG - 2024-03-09 07:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 07:12:11 --> Input Class Initialized
INFO - 2024-03-09 07:12:11 --> Language Class Initialized
INFO - 2024-03-09 07:12:11 --> Loader Class Initialized
INFO - 2024-03-09 07:12:11 --> Helper loaded: url_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: file_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: html_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: text_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: form_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: lang_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: security_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: cookie_helper
INFO - 2024-03-09 07:12:11 --> Database Driver Class Initialized
INFO - 2024-03-09 07:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 07:12:11 --> Parser Class Initialized
INFO - 2024-03-09 07:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 07:12:11 --> Pagination Class Initialized
INFO - 2024-03-09 07:12:11 --> Form Validation Class Initialized
INFO - 2024-03-09 07:12:11 --> Controller Class Initialized
INFO - 2024-03-09 07:12:11 --> Model Class Initialized
DEBUG - 2024-03-09 07:12:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-09 07:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 07:12:11 --> Config Class Initialized
INFO - 2024-03-09 07:12:11 --> Hooks Class Initialized
DEBUG - 2024-03-09 07:12:11 --> UTF-8 Support Enabled
INFO - 2024-03-09 07:12:11 --> Utf8 Class Initialized
INFO - 2024-03-09 07:12:11 --> URI Class Initialized
INFO - 2024-03-09 07:12:11 --> Router Class Initialized
INFO - 2024-03-09 07:12:11 --> Output Class Initialized
INFO - 2024-03-09 07:12:11 --> Security Class Initialized
DEBUG - 2024-03-09 07:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 07:12:11 --> Input Class Initialized
INFO - 2024-03-09 07:12:11 --> Language Class Initialized
INFO - 2024-03-09 07:12:11 --> Loader Class Initialized
INFO - 2024-03-09 07:12:11 --> Helper loaded: url_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: file_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: html_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: text_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: form_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: lang_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: security_helper
INFO - 2024-03-09 07:12:11 --> Helper loaded: cookie_helper
INFO - 2024-03-09 07:12:11 --> Database Driver Class Initialized
INFO - 2024-03-09 07:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 07:12:11 --> Parser Class Initialized
INFO - 2024-03-09 07:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 07:12:11 --> Pagination Class Initialized
INFO - 2024-03-09 07:12:11 --> Form Validation Class Initialized
INFO - 2024-03-09 07:12:11 --> Controller Class Initialized
INFO - 2024-03-09 07:12:11 --> Model Class Initialized
DEBUG - 2024-03-09 07:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 07:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 07:12:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 07:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 07:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 07:12:11 --> Model Class Initialized
INFO - 2024-03-09 07:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 07:12:11 --> Final output sent to browser
DEBUG - 2024-03-09 07:12:11 --> Total execution time: 0.0311
ERROR - 2024-03-09 15:39:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:25 --> Config Class Initialized
INFO - 2024-03-09 15:39:25 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:25 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:25 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:25 --> URI Class Initialized
DEBUG - 2024-03-09 15:39:25 --> No URI present. Default controller set.
INFO - 2024-03-09 15:39:25 --> Router Class Initialized
INFO - 2024-03-09 15:39:25 --> Output Class Initialized
INFO - 2024-03-09 15:39:25 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:25 --> Input Class Initialized
INFO - 2024-03-09 15:39:25 --> Language Class Initialized
INFO - 2024-03-09 15:39:25 --> Loader Class Initialized
INFO - 2024-03-09 15:39:25 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:25 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:25 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:25 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:25 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:25 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:25 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:25 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:25 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:25 --> Parser Class Initialized
INFO - 2024-03-09 15:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:25 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:25 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:25 --> Controller Class Initialized
INFO - 2024-03-09 15:39:25 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-09 15:39:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:26 --> Config Class Initialized
INFO - 2024-03-09 15:39:26 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:26 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:26 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:26 --> URI Class Initialized
INFO - 2024-03-09 15:39:26 --> Router Class Initialized
INFO - 2024-03-09 15:39:26 --> Output Class Initialized
INFO - 2024-03-09 15:39:26 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:26 --> Input Class Initialized
INFO - 2024-03-09 15:39:26 --> Language Class Initialized
INFO - 2024-03-09 15:39:26 --> Loader Class Initialized
INFO - 2024-03-09 15:39:26 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:26 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:26 --> Parser Class Initialized
INFO - 2024-03-09 15:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:26 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:26 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:26 --> Controller Class Initialized
INFO - 2024-03-09 15:39:26 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 15:39:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 15:39:26 --> Model Class Initialized
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 15:39:26 --> Final output sent to browser
DEBUG - 2024-03-09 15:39:26 --> Total execution time: 0.0348
ERROR - 2024-03-09 15:39:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:26 --> Config Class Initialized
INFO - 2024-03-09 15:39:26 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:26 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:26 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:26 --> URI Class Initialized
DEBUG - 2024-03-09 15:39:26 --> No URI present. Default controller set.
INFO - 2024-03-09 15:39:26 --> Router Class Initialized
INFO - 2024-03-09 15:39:26 --> Output Class Initialized
INFO - 2024-03-09 15:39:26 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:26 --> Input Class Initialized
INFO - 2024-03-09 15:39:26 --> Language Class Initialized
INFO - 2024-03-09 15:39:26 --> Loader Class Initialized
INFO - 2024-03-09 15:39:26 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:26 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:26 --> Parser Class Initialized
INFO - 2024-03-09 15:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:26 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:26 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:26 --> Controller Class Initialized
INFO - 2024-03-09 15:39:26 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-09 15:39:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:26 --> Config Class Initialized
INFO - 2024-03-09 15:39:26 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:26 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:26 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:26 --> URI Class Initialized
INFO - 2024-03-09 15:39:26 --> Router Class Initialized
INFO - 2024-03-09 15:39:26 --> Output Class Initialized
INFO - 2024-03-09 15:39:26 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:26 --> Input Class Initialized
INFO - 2024-03-09 15:39:26 --> Language Class Initialized
INFO - 2024-03-09 15:39:26 --> Loader Class Initialized
INFO - 2024-03-09 15:39:26 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:26 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:26 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:26 --> Parser Class Initialized
INFO - 2024-03-09 15:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:26 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:26 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:26 --> Controller Class Initialized
INFO - 2024-03-09 15:39:26 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 15:39:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 15:39:26 --> Model Class Initialized
INFO - 2024-03-09 15:39:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 15:39:26 --> Final output sent to browser
DEBUG - 2024-03-09 15:39:26 --> Total execution time: 0.0354
ERROR - 2024-03-09 15:39:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:38 --> Config Class Initialized
INFO - 2024-03-09 15:39:38 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:38 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:38 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:38 --> URI Class Initialized
INFO - 2024-03-09 15:39:38 --> Router Class Initialized
INFO - 2024-03-09 15:39:38 --> Output Class Initialized
INFO - 2024-03-09 15:39:38 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:38 --> Input Class Initialized
INFO - 2024-03-09 15:39:38 --> Language Class Initialized
INFO - 2024-03-09 15:39:38 --> Loader Class Initialized
INFO - 2024-03-09 15:39:38 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:38 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:38 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:38 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:38 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:38 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:38 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:38 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:38 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:38 --> Parser Class Initialized
INFO - 2024-03-09 15:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:38 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:38 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:38 --> Controller Class Initialized
INFO - 2024-03-09 15:39:38 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:38 --> Model Class Initialized
INFO - 2024-03-09 15:39:38 --> Final output sent to browser
DEBUG - 2024-03-09 15:39:38 --> Total execution time: 0.0201
ERROR - 2024-03-09 15:39:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:39 --> Config Class Initialized
INFO - 2024-03-09 15:39:39 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:39 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:39 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:39 --> URI Class Initialized
DEBUG - 2024-03-09 15:39:39 --> No URI present. Default controller set.
INFO - 2024-03-09 15:39:39 --> Router Class Initialized
INFO - 2024-03-09 15:39:39 --> Output Class Initialized
INFO - 2024-03-09 15:39:39 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:39 --> Input Class Initialized
INFO - 2024-03-09 15:39:39 --> Language Class Initialized
INFO - 2024-03-09 15:39:39 --> Loader Class Initialized
INFO - 2024-03-09 15:39:39 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:39 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:39 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:39 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:39 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:39 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:39 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:39 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:39 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:39 --> Parser Class Initialized
INFO - 2024-03-09 15:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:39 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:39 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:39 --> Controller Class Initialized
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 15:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
INFO - 2024-03-09 15:39:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 15:39:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 15:39:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 15:39:39 --> Model Class Initialized
INFO - 2024-03-09 15:39:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 15:39:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 15:39:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 15:39:39 --> Final output sent to browser
DEBUG - 2024-03-09 15:39:39 --> Total execution time: 0.4268
ERROR - 2024-03-09 15:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:41 --> Config Class Initialized
INFO - 2024-03-09 15:39:41 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:41 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:41 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:41 --> URI Class Initialized
INFO - 2024-03-09 15:39:41 --> Router Class Initialized
INFO - 2024-03-09 15:39:41 --> Output Class Initialized
INFO - 2024-03-09 15:39:41 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:41 --> Input Class Initialized
INFO - 2024-03-09 15:39:41 --> Language Class Initialized
INFO - 2024-03-09 15:39:41 --> Loader Class Initialized
INFO - 2024-03-09 15:39:41 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:41 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:41 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:41 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:41 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:41 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:41 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:41 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:41 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:41 --> Parser Class Initialized
INFO - 2024-03-09 15:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:41 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:41 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:41 --> Controller Class Initialized
DEBUG - 2024-03-09 15:39:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 15:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:41 --> Model Class Initialized
INFO - 2024-03-09 15:39:41 --> Final output sent to browser
DEBUG - 2024-03-09 15:39:41 --> Total execution time: 0.0134
ERROR - 2024-03-09 15:39:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:51 --> Config Class Initialized
INFO - 2024-03-09 15:39:51 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:51 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:51 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:51 --> URI Class Initialized
INFO - 2024-03-09 15:39:51 --> Router Class Initialized
INFO - 2024-03-09 15:39:51 --> Output Class Initialized
INFO - 2024-03-09 15:39:51 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:51 --> Input Class Initialized
INFO - 2024-03-09 15:39:51 --> Language Class Initialized
INFO - 2024-03-09 15:39:51 --> Loader Class Initialized
INFO - 2024-03-09 15:39:51 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:51 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:51 --> Parser Class Initialized
INFO - 2024-03-09 15:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:51 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:51 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:51 --> Controller Class Initialized
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-09 15:39:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
INFO - 2024-03-09 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 15:39:51 --> Final output sent to browser
DEBUG - 2024-03-09 15:39:51 --> Total execution time: 0.0298
ERROR - 2024-03-09 15:39:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-09 15:39:51 --> Config Class Initialized
INFO - 2024-03-09 15:39:51 --> Hooks Class Initialized
DEBUG - 2024-03-09 15:39:51 --> UTF-8 Support Enabled
INFO - 2024-03-09 15:39:51 --> Utf8 Class Initialized
INFO - 2024-03-09 15:39:51 --> URI Class Initialized
INFO - 2024-03-09 15:39:51 --> Router Class Initialized
INFO - 2024-03-09 15:39:51 --> Output Class Initialized
INFO - 2024-03-09 15:39:51 --> Security Class Initialized
DEBUG - 2024-03-09 15:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-09 15:39:51 --> Input Class Initialized
INFO - 2024-03-09 15:39:51 --> Language Class Initialized
INFO - 2024-03-09 15:39:51 --> Loader Class Initialized
INFO - 2024-03-09 15:39:51 --> Helper loaded: url_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: file_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: html_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: text_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: form_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: lang_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: security_helper
INFO - 2024-03-09 15:39:51 --> Helper loaded: cookie_helper
INFO - 2024-03-09 15:39:51 --> Database Driver Class Initialized
INFO - 2024-03-09 15:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-09 15:39:51 --> Parser Class Initialized
INFO - 2024-03-09 15:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-09 15:39:51 --> Pagination Class Initialized
INFO - 2024-03-09 15:39:51 --> Form Validation Class Initialized
INFO - 2024-03-09 15:39:51 --> Controller Class Initialized
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
DEBUG - 2024-03-09 15:39:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-09 15:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
INFO - 2024-03-09 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-09 15:39:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-09 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-09 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-09 15:39:51 --> Model Class Initialized
INFO - 2024-03-09 15:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-09 15:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-09 15:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-09 15:39:52 --> Final output sent to browser
DEBUG - 2024-03-09 15:39:52 --> Total execution time: 0.4190
