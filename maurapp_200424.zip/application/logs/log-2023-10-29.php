<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-29 04:02:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-29 04:02:42 --> Config Class Initialized
INFO - 2023-10-29 04:02:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 04:02:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 04:02:42 --> Utf8 Class Initialized
INFO - 2023-10-29 04:02:42 --> URI Class Initialized
INFO - 2023-10-29 04:02:42 --> Router Class Initialized
INFO - 2023-10-29 04:02:42 --> Output Class Initialized
INFO - 2023-10-29 04:02:42 --> Security Class Initialized
DEBUG - 2023-10-29 04:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 04:02:42 --> Input Class Initialized
INFO - 2023-10-29 04:02:42 --> Language Class Initialized
ERROR - 2023-10-29 04:02:42 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-29 06:42:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-29 06:42:07 --> Config Class Initialized
INFO - 2023-10-29 06:42:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 06:42:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 06:42:07 --> Utf8 Class Initialized
INFO - 2023-10-29 06:42:07 --> URI Class Initialized
DEBUG - 2023-10-29 06:42:07 --> No URI present. Default controller set.
INFO - 2023-10-29 06:42:07 --> Router Class Initialized
INFO - 2023-10-29 06:42:07 --> Output Class Initialized
INFO - 2023-10-29 06:42:07 --> Security Class Initialized
DEBUG - 2023-10-29 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 06:42:07 --> Input Class Initialized
INFO - 2023-10-29 06:42:07 --> Language Class Initialized
INFO - 2023-10-29 06:42:07 --> Loader Class Initialized
INFO - 2023-10-29 06:42:07 --> Helper loaded: url_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: file_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: html_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: text_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: form_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: lang_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: security_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: cookie_helper
INFO - 2023-10-29 06:42:07 --> Database Driver Class Initialized
INFO - 2023-10-29 06:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 06:42:07 --> Parser Class Initialized
INFO - 2023-10-29 06:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-29 06:42:07 --> Pagination Class Initialized
INFO - 2023-10-29 06:42:07 --> Form Validation Class Initialized
INFO - 2023-10-29 06:42:07 --> Controller Class Initialized
INFO - 2023-10-29 06:42:07 --> Model Class Initialized
DEBUG - 2023-10-29 06:42:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-29 06:42:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-29 06:42:07 --> Config Class Initialized
INFO - 2023-10-29 06:42:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 06:42:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 06:42:07 --> Utf8 Class Initialized
INFO - 2023-10-29 06:42:07 --> URI Class Initialized
INFO - 2023-10-29 06:42:07 --> Router Class Initialized
INFO - 2023-10-29 06:42:07 --> Output Class Initialized
INFO - 2023-10-29 06:42:07 --> Security Class Initialized
DEBUG - 2023-10-29 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 06:42:07 --> Input Class Initialized
INFO - 2023-10-29 06:42:07 --> Language Class Initialized
INFO - 2023-10-29 06:42:07 --> Loader Class Initialized
INFO - 2023-10-29 06:42:07 --> Helper loaded: url_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: file_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: html_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: text_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: form_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: lang_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: security_helper
INFO - 2023-10-29 06:42:07 --> Helper loaded: cookie_helper
INFO - 2023-10-29 06:42:07 --> Database Driver Class Initialized
INFO - 2023-10-29 06:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 06:42:07 --> Parser Class Initialized
INFO - 2023-10-29 06:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-29 06:42:07 --> Pagination Class Initialized
INFO - 2023-10-29 06:42:07 --> Form Validation Class Initialized
INFO - 2023-10-29 06:42:07 --> Controller Class Initialized
INFO - 2023-10-29 06:42:07 --> Model Class Initialized
DEBUG - 2023-10-29 06:42:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-29 06:42:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-29 06:42:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-29 06:42:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-29 06:42:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-29 06:42:07 --> Model Class Initialized
INFO - 2023-10-29 06:42:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-29 06:42:07 --> Final output sent to browser
DEBUG - 2023-10-29 06:42:07 --> Total execution time: 0.0370
ERROR - 2023-10-29 20:32:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-29 20:32:47 --> Config Class Initialized
INFO - 2023-10-29 20:32:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 20:32:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 20:32:47 --> Utf8 Class Initialized
INFO - 2023-10-29 20:32:47 --> URI Class Initialized
INFO - 2023-10-29 20:32:47 --> Router Class Initialized
INFO - 2023-10-29 20:32:47 --> Output Class Initialized
INFO - 2023-10-29 20:32:47 --> Security Class Initialized
DEBUG - 2023-10-29 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 20:32:47 --> Input Class Initialized
INFO - 2023-10-29 20:32:47 --> Language Class Initialized
ERROR - 2023-10-29 20:32:47 --> 404 Page Not Found: Well-known/assetlinks.json
