<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-24 04:50:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 04:50:52 --> Config Class Initialized
INFO - 2023-12-24 04:50:52 --> Hooks Class Initialized
DEBUG - 2023-12-24 04:50:52 --> UTF-8 Support Enabled
INFO - 2023-12-24 04:50:52 --> Utf8 Class Initialized
INFO - 2023-12-24 04:50:52 --> URI Class Initialized
INFO - 2023-12-24 04:50:52 --> Router Class Initialized
INFO - 2023-12-24 04:50:52 --> Output Class Initialized
INFO - 2023-12-24 04:50:52 --> Security Class Initialized
DEBUG - 2023-12-24 04:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 04:50:52 --> Input Class Initialized
INFO - 2023-12-24 04:50:52 --> Language Class Initialized
ERROR - 2023-12-24 04:50:52 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-24 08:48:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 08:48:42 --> Config Class Initialized
INFO - 2023-12-24 08:48:42 --> Hooks Class Initialized
DEBUG - 2023-12-24 08:48:42 --> UTF-8 Support Enabled
INFO - 2023-12-24 08:48:42 --> Utf8 Class Initialized
INFO - 2023-12-24 08:48:42 --> URI Class Initialized
DEBUG - 2023-12-24 08:48:42 --> No URI present. Default controller set.
INFO - 2023-12-24 08:48:42 --> Router Class Initialized
INFO - 2023-12-24 08:48:42 --> Output Class Initialized
INFO - 2023-12-24 08:48:42 --> Security Class Initialized
DEBUG - 2023-12-24 08:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 08:48:42 --> Input Class Initialized
INFO - 2023-12-24 08:48:42 --> Language Class Initialized
INFO - 2023-12-24 08:48:42 --> Loader Class Initialized
INFO - 2023-12-24 08:48:42 --> Helper loaded: url_helper
INFO - 2023-12-24 08:48:42 --> Helper loaded: file_helper
INFO - 2023-12-24 08:48:42 --> Helper loaded: html_helper
INFO - 2023-12-24 08:48:42 --> Helper loaded: text_helper
INFO - 2023-12-24 08:48:42 --> Helper loaded: form_helper
INFO - 2023-12-24 08:48:42 --> Helper loaded: lang_helper
INFO - 2023-12-24 08:48:42 --> Helper loaded: security_helper
INFO - 2023-12-24 08:48:42 --> Helper loaded: cookie_helper
INFO - 2023-12-24 08:48:42 --> Database Driver Class Initialized
ERROR - 2023-12-24 08:48:42 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:48:42 --> Unable to connect to the database
INFO - 2023-12-24 08:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 08:48:42 --> Parser Class Initialized
INFO - 2023-12-24 08:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 08:48:42 --> Pagination Class Initialized
INFO - 2023-12-24 08:48:42 --> Form Validation Class Initialized
INFO - 2023-12-24 08:48:42 --> Controller Class Initialized
INFO - 2023-12-24 08:48:42 --> Model Class Initialized
DEBUG - 2023-12-24 08:48:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-24 08:48:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 08:48:43 --> Config Class Initialized
INFO - 2023-12-24 08:48:43 --> Hooks Class Initialized
DEBUG - 2023-12-24 08:48:43 --> UTF-8 Support Enabled
INFO - 2023-12-24 08:48:43 --> Utf8 Class Initialized
INFO - 2023-12-24 08:48:43 --> URI Class Initialized
INFO - 2023-12-24 08:48:43 --> Router Class Initialized
INFO - 2023-12-24 08:48:43 --> Output Class Initialized
INFO - 2023-12-24 08:48:43 --> Security Class Initialized
DEBUG - 2023-12-24 08:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 08:48:43 --> Input Class Initialized
INFO - 2023-12-24 08:48:43 --> Language Class Initialized
INFO - 2023-12-24 08:48:43 --> Loader Class Initialized
INFO - 2023-12-24 08:48:43 --> Helper loaded: url_helper
INFO - 2023-12-24 08:48:43 --> Helper loaded: file_helper
INFO - 2023-12-24 08:48:43 --> Helper loaded: html_helper
INFO - 2023-12-24 08:48:43 --> Helper loaded: text_helper
INFO - 2023-12-24 08:48:43 --> Helper loaded: form_helper
INFO - 2023-12-24 08:48:43 --> Helper loaded: lang_helper
INFO - 2023-12-24 08:48:43 --> Helper loaded: security_helper
INFO - 2023-12-24 08:48:43 --> Helper loaded: cookie_helper
INFO - 2023-12-24 08:48:43 --> Database Driver Class Initialized
ERROR - 2023-12-24 08:48:43 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:48:43 --> Unable to connect to the database
INFO - 2023-12-24 08:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 08:48:43 --> Parser Class Initialized
INFO - 2023-12-24 08:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 08:48:43 --> Pagination Class Initialized
INFO - 2023-12-24 08:48:43 --> Form Validation Class Initialized
INFO - 2023-12-24 08:48:43 --> Controller Class Initialized
INFO - 2023-12-24 08:48:43 --> Model Class Initialized
DEBUG - 2023-12-24 08:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 08:48:43 --> Database Driver Class Initialized
ERROR - 2023-12-24 08:48:43 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:48:43 --> Unable to connect to the database
ERROR - 2023-12-24 08:48:43 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:48:43 --> Unable to connect to the database
ERROR - 2023-12-24 08:48:43 --> Query error: Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) - Invalid query: SELECT *
FROM `web_setting`
ERROR - 2023-12-24 08:48:43 --> Severity: error --> Exception: Call to a member function row() on bool /home/powera7m/app.maurnaturo.com/application/helpers/lang_helper.php 16
ERROR - 2023-12-24 08:48:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 08:48:47 --> Config Class Initialized
INFO - 2023-12-24 08:48:47 --> Hooks Class Initialized
DEBUG - 2023-12-24 08:48:47 --> UTF-8 Support Enabled
INFO - 2023-12-24 08:48:47 --> Utf8 Class Initialized
INFO - 2023-12-24 08:48:47 --> URI Class Initialized
INFO - 2023-12-24 08:48:47 --> Router Class Initialized
INFO - 2023-12-24 08:48:47 --> Output Class Initialized
INFO - 2023-12-24 08:48:47 --> Security Class Initialized
DEBUG - 2023-12-24 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 08:48:47 --> Input Class Initialized
INFO - 2023-12-24 08:48:47 --> Language Class Initialized
INFO - 2023-12-24 08:48:47 --> Loader Class Initialized
INFO - 2023-12-24 08:48:47 --> Helper loaded: url_helper
INFO - 2023-12-24 08:48:47 --> Helper loaded: file_helper
INFO - 2023-12-24 08:48:47 --> Helper loaded: html_helper
INFO - 2023-12-24 08:48:47 --> Helper loaded: text_helper
INFO - 2023-12-24 08:48:47 --> Helper loaded: form_helper
INFO - 2023-12-24 08:48:47 --> Helper loaded: lang_helper
INFO - 2023-12-24 08:48:47 --> Helper loaded: security_helper
INFO - 2023-12-24 08:48:47 --> Helper loaded: cookie_helper
INFO - 2023-12-24 08:48:48 --> Database Driver Class Initialized
ERROR - 2023-12-24 08:48:48 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:48:48 --> Unable to connect to the database
INFO - 2023-12-24 08:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 08:48:48 --> Parser Class Initialized
INFO - 2023-12-24 08:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 08:48:48 --> Pagination Class Initialized
INFO - 2023-12-24 08:48:48 --> Form Validation Class Initialized
INFO - 2023-12-24 08:48:48 --> Controller Class Initialized
INFO - 2023-12-24 08:48:48 --> Model Class Initialized
DEBUG - 2023-12-24 08:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 08:48:48 --> Database Driver Class Initialized
ERROR - 2023-12-24 08:48:48 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:48:48 --> Unable to connect to the database
ERROR - 2023-12-24 08:48:48 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:48:48 --> Unable to connect to the database
ERROR - 2023-12-24 08:48:48 --> Query error: Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) - Invalid query: SELECT *
FROM `web_setting`
ERROR - 2023-12-24 08:48:48 --> Severity: error --> Exception: Call to a member function row() on bool /home/powera7m/app.maurnaturo.com/application/helpers/lang_helper.php 16
ERROR - 2023-12-24 08:48:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 08:48:58 --> Config Class Initialized
INFO - 2023-12-24 08:48:58 --> Hooks Class Initialized
DEBUG - 2023-12-24 08:48:58 --> UTF-8 Support Enabled
INFO - 2023-12-24 08:48:58 --> Utf8 Class Initialized
INFO - 2023-12-24 08:48:58 --> URI Class Initialized
INFO - 2023-12-24 08:48:58 --> Router Class Initialized
INFO - 2023-12-24 08:48:58 --> Output Class Initialized
INFO - 2023-12-24 08:48:58 --> Security Class Initialized
DEBUG - 2023-12-24 08:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 08:48:58 --> Input Class Initialized
INFO - 2023-12-24 08:48:58 --> Language Class Initialized
INFO - 2023-12-24 08:48:58 --> Loader Class Initialized
INFO - 2023-12-24 08:48:58 --> Helper loaded: url_helper
INFO - 2023-12-24 08:48:58 --> Helper loaded: file_helper
INFO - 2023-12-24 08:48:58 --> Helper loaded: html_helper
INFO - 2023-12-24 08:48:58 --> Helper loaded: text_helper
INFO - 2023-12-24 08:48:58 --> Helper loaded: form_helper
INFO - 2023-12-24 08:48:58 --> Helper loaded: lang_helper
INFO - 2023-12-24 08:48:58 --> Helper loaded: security_helper
INFO - 2023-12-24 08:48:58 --> Helper loaded: cookie_helper
INFO - 2023-12-24 08:48:58 --> Database Driver Class Initialized
INFO - 2023-12-24 08:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 08:48:58 --> Parser Class Initialized
INFO - 2023-12-24 08:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 08:48:58 --> Pagination Class Initialized
INFO - 2023-12-24 08:48:58 --> Form Validation Class Initialized
INFO - 2023-12-24 08:48:58 --> Controller Class Initialized
INFO - 2023-12-24 08:48:58 --> Model Class Initialized
DEBUG - 2023-12-24 08:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 08:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-24 08:48:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 08:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 08:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 08:48:58 --> Model Class Initialized
INFO - 2023-12-24 08:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 08:48:58 --> Final output sent to browser
DEBUG - 2023-12-24 08:48:58 --> Total execution time: 0.0355
ERROR - 2023-12-24 08:49:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 08:49:19 --> Config Class Initialized
INFO - 2023-12-24 08:49:19 --> Hooks Class Initialized
DEBUG - 2023-12-24 08:49:19 --> UTF-8 Support Enabled
INFO - 2023-12-24 08:49:19 --> Utf8 Class Initialized
INFO - 2023-12-24 08:49:19 --> URI Class Initialized
INFO - 2023-12-24 08:49:19 --> Router Class Initialized
INFO - 2023-12-24 08:49:19 --> Output Class Initialized
INFO - 2023-12-24 08:49:19 --> Security Class Initialized
DEBUG - 2023-12-24 08:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 08:49:19 --> Input Class Initialized
INFO - 2023-12-24 08:49:19 --> Language Class Initialized
INFO - 2023-12-24 08:49:19 --> Loader Class Initialized
INFO - 2023-12-24 08:49:19 --> Helper loaded: url_helper
INFO - 2023-12-24 08:49:19 --> Helper loaded: file_helper
INFO - 2023-12-24 08:49:19 --> Helper loaded: html_helper
INFO - 2023-12-24 08:49:19 --> Helper loaded: text_helper
INFO - 2023-12-24 08:49:19 --> Helper loaded: form_helper
INFO - 2023-12-24 08:49:19 --> Helper loaded: lang_helper
INFO - 2023-12-24 08:49:19 --> Helper loaded: security_helper
INFO - 2023-12-24 08:49:19 --> Helper loaded: cookie_helper
INFO - 2023-12-24 08:49:19 --> Database Driver Class Initialized
ERROR - 2023-12-24 08:49:19 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:49:19 --> Unable to connect to the database
INFO - 2023-12-24 08:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 08:49:19 --> Parser Class Initialized
INFO - 2023-12-24 08:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 08:49:19 --> Pagination Class Initialized
INFO - 2023-12-24 08:49:19 --> Form Validation Class Initialized
INFO - 2023-12-24 08:49:19 --> Controller Class Initialized
INFO - 2023-12-24 08:49:19 --> Model Class Initialized
DEBUG - 2023-12-24 08:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 08:49:19 --> Database Driver Class Initialized
ERROR - 2023-12-24 08:49:19 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:49:19 --> Unable to connect to the database
ERROR - 2023-12-24 08:49:19 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) /home/powera7m/app.maurnaturo.com/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-12-24 08:49:19 --> Unable to connect to the database
ERROR - 2023-12-24 08:49:19 --> Query error: Access denied for user 'powera7m_medcalnew'@'localhost' (using password: YES) - Invalid query: SELECT *
FROM `web_setting`
ERROR - 2023-12-24 08:49:19 --> Severity: error --> Exception: Call to a member function row() on bool /home/powera7m/app.maurnaturo.com/application/helpers/lang_helper.php 16
ERROR - 2023-12-24 08:52:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 08:52:04 --> Config Class Initialized
INFO - 2023-12-24 08:52:04 --> Hooks Class Initialized
DEBUG - 2023-12-24 08:52:04 --> UTF-8 Support Enabled
INFO - 2023-12-24 08:52:04 --> Utf8 Class Initialized
INFO - 2023-12-24 08:52:04 --> URI Class Initialized
INFO - 2023-12-24 08:52:04 --> Router Class Initialized
INFO - 2023-12-24 08:52:04 --> Output Class Initialized
INFO - 2023-12-24 08:52:04 --> Security Class Initialized
DEBUG - 2023-12-24 08:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 08:52:04 --> Input Class Initialized
INFO - 2023-12-24 08:52:04 --> Language Class Initialized
INFO - 2023-12-24 08:52:04 --> Loader Class Initialized
INFO - 2023-12-24 08:52:04 --> Helper loaded: url_helper
INFO - 2023-12-24 08:52:04 --> Helper loaded: file_helper
INFO - 2023-12-24 08:52:04 --> Helper loaded: html_helper
INFO - 2023-12-24 08:52:04 --> Helper loaded: text_helper
INFO - 2023-12-24 08:52:04 --> Helper loaded: form_helper
INFO - 2023-12-24 08:52:04 --> Helper loaded: lang_helper
INFO - 2023-12-24 08:52:04 --> Helper loaded: security_helper
INFO - 2023-12-24 08:52:04 --> Helper loaded: cookie_helper
INFO - 2023-12-24 08:52:04 --> Database Driver Class Initialized
INFO - 2023-12-24 08:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 08:52:04 --> Parser Class Initialized
INFO - 2023-12-24 08:52:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 08:52:04 --> Pagination Class Initialized
INFO - 2023-12-24 08:52:04 --> Form Validation Class Initialized
INFO - 2023-12-24 08:52:04 --> Controller Class Initialized
INFO - 2023-12-24 08:52:04 --> Model Class Initialized
DEBUG - 2023-12-24 08:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 08:52:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-24 08:52:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 08:52:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 08:52:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 08:52:04 --> Model Class Initialized
INFO - 2023-12-24 08:52:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 08:52:04 --> Final output sent to browser
DEBUG - 2023-12-24 08:52:04 --> Total execution time: 0.0335
ERROR - 2023-12-24 09:21:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 09:21:01 --> Config Class Initialized
INFO - 2023-12-24 09:21:01 --> Hooks Class Initialized
DEBUG - 2023-12-24 09:21:01 --> UTF-8 Support Enabled
INFO - 2023-12-24 09:21:01 --> Utf8 Class Initialized
INFO - 2023-12-24 09:21:01 --> URI Class Initialized
INFO - 2023-12-24 09:21:01 --> Router Class Initialized
INFO - 2023-12-24 09:21:01 --> Output Class Initialized
INFO - 2023-12-24 09:21:01 --> Security Class Initialized
DEBUG - 2023-12-24 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 09:21:01 --> Input Class Initialized
INFO - 2023-12-24 09:21:01 --> Language Class Initialized
ERROR - 2023-12-24 09:21:01 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-24 13:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:15:13 --> Config Class Initialized
INFO - 2023-12-24 13:15:13 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:15:13 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:15:13 --> Utf8 Class Initialized
INFO - 2023-12-24 13:15:13 --> URI Class Initialized
DEBUG - 2023-12-24 13:15:13 --> No URI present. Default controller set.
INFO - 2023-12-24 13:15:13 --> Router Class Initialized
INFO - 2023-12-24 13:15:13 --> Output Class Initialized
INFO - 2023-12-24 13:15:13 --> Security Class Initialized
DEBUG - 2023-12-24 13:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:15:13 --> Input Class Initialized
INFO - 2023-12-24 13:15:13 --> Language Class Initialized
INFO - 2023-12-24 13:15:13 --> Loader Class Initialized
INFO - 2023-12-24 13:15:13 --> Helper loaded: url_helper
INFO - 2023-12-24 13:15:13 --> Helper loaded: file_helper
INFO - 2023-12-24 13:15:13 --> Helper loaded: html_helper
INFO - 2023-12-24 13:15:13 --> Helper loaded: text_helper
INFO - 2023-12-24 13:15:13 --> Helper loaded: form_helper
INFO - 2023-12-24 13:15:13 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:15:13 --> Helper loaded: security_helper
INFO - 2023-12-24 13:15:13 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:15:13 --> Database Driver Class Initialized
INFO - 2023-12-24 13:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:15:13 --> Parser Class Initialized
INFO - 2023-12-24 13:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:15:13 --> Pagination Class Initialized
INFO - 2023-12-24 13:15:13 --> Form Validation Class Initialized
INFO - 2023-12-24 13:15:13 --> Controller Class Initialized
INFO - 2023-12-24 13:15:13 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-24 13:15:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:15:14 --> Config Class Initialized
INFO - 2023-12-24 13:15:14 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:15:14 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:15:14 --> Utf8 Class Initialized
INFO - 2023-12-24 13:15:14 --> URI Class Initialized
INFO - 2023-12-24 13:15:14 --> Router Class Initialized
INFO - 2023-12-24 13:15:14 --> Output Class Initialized
INFO - 2023-12-24 13:15:14 --> Security Class Initialized
DEBUG - 2023-12-24 13:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:15:14 --> Input Class Initialized
INFO - 2023-12-24 13:15:14 --> Language Class Initialized
INFO - 2023-12-24 13:15:14 --> Loader Class Initialized
INFO - 2023-12-24 13:15:14 --> Helper loaded: url_helper
INFO - 2023-12-24 13:15:14 --> Helper loaded: file_helper
INFO - 2023-12-24 13:15:14 --> Helper loaded: html_helper
INFO - 2023-12-24 13:15:14 --> Helper loaded: text_helper
INFO - 2023-12-24 13:15:14 --> Helper loaded: form_helper
INFO - 2023-12-24 13:15:14 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:15:14 --> Helper loaded: security_helper
INFO - 2023-12-24 13:15:14 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:15:14 --> Database Driver Class Initialized
INFO - 2023-12-24 13:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:15:14 --> Parser Class Initialized
INFO - 2023-12-24 13:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:15:14 --> Pagination Class Initialized
INFO - 2023-12-24 13:15:14 --> Form Validation Class Initialized
INFO - 2023-12-24 13:15:14 --> Controller Class Initialized
INFO - 2023-12-24 13:15:14 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-24 13:15:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:15:14 --> Model Class Initialized
INFO - 2023-12-24 13:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:15:14 --> Final output sent to browser
DEBUG - 2023-12-24 13:15:14 --> Total execution time: 0.0355
ERROR - 2023-12-24 13:15:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:15:19 --> Config Class Initialized
INFO - 2023-12-24 13:15:19 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:15:19 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:15:19 --> Utf8 Class Initialized
INFO - 2023-12-24 13:15:19 --> URI Class Initialized
INFO - 2023-12-24 13:15:19 --> Router Class Initialized
INFO - 2023-12-24 13:15:19 --> Output Class Initialized
INFO - 2023-12-24 13:15:19 --> Security Class Initialized
DEBUG - 2023-12-24 13:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:15:19 --> Input Class Initialized
INFO - 2023-12-24 13:15:19 --> Language Class Initialized
INFO - 2023-12-24 13:15:19 --> Loader Class Initialized
INFO - 2023-12-24 13:15:19 --> Helper loaded: url_helper
INFO - 2023-12-24 13:15:19 --> Helper loaded: file_helper
INFO - 2023-12-24 13:15:19 --> Helper loaded: html_helper
INFO - 2023-12-24 13:15:19 --> Helper loaded: text_helper
INFO - 2023-12-24 13:15:19 --> Helper loaded: form_helper
INFO - 2023-12-24 13:15:19 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:15:19 --> Helper loaded: security_helper
INFO - 2023-12-24 13:15:19 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:15:19 --> Database Driver Class Initialized
INFO - 2023-12-24 13:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:15:19 --> Parser Class Initialized
INFO - 2023-12-24 13:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:15:19 --> Pagination Class Initialized
INFO - 2023-12-24 13:15:19 --> Form Validation Class Initialized
INFO - 2023-12-24 13:15:19 --> Controller Class Initialized
INFO - 2023-12-24 13:15:19 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:19 --> Model Class Initialized
INFO - 2023-12-24 13:15:19 --> Final output sent to browser
DEBUG - 2023-12-24 13:15:19 --> Total execution time: 0.0211
ERROR - 2023-12-24 13:15:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:15:20 --> Config Class Initialized
INFO - 2023-12-24 13:15:20 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:15:20 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:15:20 --> Utf8 Class Initialized
INFO - 2023-12-24 13:15:20 --> URI Class Initialized
DEBUG - 2023-12-24 13:15:20 --> No URI present. Default controller set.
INFO - 2023-12-24 13:15:20 --> Router Class Initialized
INFO - 2023-12-24 13:15:20 --> Output Class Initialized
INFO - 2023-12-24 13:15:20 --> Security Class Initialized
DEBUG - 2023-12-24 13:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:15:20 --> Input Class Initialized
INFO - 2023-12-24 13:15:20 --> Language Class Initialized
INFO - 2023-12-24 13:15:20 --> Loader Class Initialized
INFO - 2023-12-24 13:15:20 --> Helper loaded: url_helper
INFO - 2023-12-24 13:15:20 --> Helper loaded: file_helper
INFO - 2023-12-24 13:15:20 --> Helper loaded: html_helper
INFO - 2023-12-24 13:15:20 --> Helper loaded: text_helper
INFO - 2023-12-24 13:15:20 --> Helper loaded: form_helper
INFO - 2023-12-24 13:15:20 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:15:20 --> Helper loaded: security_helper
INFO - 2023-12-24 13:15:20 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:15:20 --> Database Driver Class Initialized
INFO - 2023-12-24 13:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:15:20 --> Parser Class Initialized
INFO - 2023-12-24 13:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:15:20 --> Pagination Class Initialized
INFO - 2023-12-24 13:15:20 --> Form Validation Class Initialized
INFO - 2023-12-24 13:15:20 --> Controller Class Initialized
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
INFO - 2023-12-24 13:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 13:15:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:15:20 --> Model Class Initialized
INFO - 2023-12-24 13:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:15:20 --> Final output sent to browser
DEBUG - 2023-12-24 13:15:20 --> Total execution time: 0.4186
ERROR - 2023-12-24 13:15:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:15:21 --> Config Class Initialized
INFO - 2023-12-24 13:15:21 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:15:21 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:15:21 --> Utf8 Class Initialized
INFO - 2023-12-24 13:15:21 --> URI Class Initialized
INFO - 2023-12-24 13:15:21 --> Router Class Initialized
INFO - 2023-12-24 13:15:21 --> Output Class Initialized
INFO - 2023-12-24 13:15:21 --> Security Class Initialized
DEBUG - 2023-12-24 13:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:15:21 --> Input Class Initialized
INFO - 2023-12-24 13:15:21 --> Language Class Initialized
INFO - 2023-12-24 13:15:21 --> Loader Class Initialized
INFO - 2023-12-24 13:15:21 --> Helper loaded: url_helper
INFO - 2023-12-24 13:15:21 --> Helper loaded: file_helper
INFO - 2023-12-24 13:15:21 --> Helper loaded: html_helper
INFO - 2023-12-24 13:15:21 --> Helper loaded: text_helper
INFO - 2023-12-24 13:15:21 --> Helper loaded: form_helper
INFO - 2023-12-24 13:15:21 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:15:21 --> Helper loaded: security_helper
INFO - 2023-12-24 13:15:21 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:15:21 --> Database Driver Class Initialized
INFO - 2023-12-24 13:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:15:21 --> Parser Class Initialized
INFO - 2023-12-24 13:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:15:21 --> Pagination Class Initialized
INFO - 2023-12-24 13:15:21 --> Form Validation Class Initialized
INFO - 2023-12-24 13:15:21 --> Controller Class Initialized
DEBUG - 2023-12-24 13:15:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:21 --> Model Class Initialized
INFO - 2023-12-24 13:15:21 --> Final output sent to browser
DEBUG - 2023-12-24 13:15:21 --> Total execution time: 0.0137
ERROR - 2023-12-24 13:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:15:28 --> Config Class Initialized
INFO - 2023-12-24 13:15:28 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:15:28 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:15:28 --> Utf8 Class Initialized
INFO - 2023-12-24 13:15:28 --> URI Class Initialized
DEBUG - 2023-12-24 13:15:28 --> No URI present. Default controller set.
INFO - 2023-12-24 13:15:28 --> Router Class Initialized
INFO - 2023-12-24 13:15:28 --> Output Class Initialized
INFO - 2023-12-24 13:15:28 --> Security Class Initialized
DEBUG - 2023-12-24 13:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:15:28 --> Input Class Initialized
INFO - 2023-12-24 13:15:28 --> Language Class Initialized
INFO - 2023-12-24 13:15:28 --> Loader Class Initialized
INFO - 2023-12-24 13:15:28 --> Helper loaded: url_helper
INFO - 2023-12-24 13:15:28 --> Helper loaded: file_helper
INFO - 2023-12-24 13:15:28 --> Helper loaded: html_helper
INFO - 2023-12-24 13:15:28 --> Helper loaded: text_helper
INFO - 2023-12-24 13:15:28 --> Helper loaded: form_helper
INFO - 2023-12-24 13:15:28 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:15:28 --> Helper loaded: security_helper
INFO - 2023-12-24 13:15:28 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:15:28 --> Database Driver Class Initialized
INFO - 2023-12-24 13:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:15:28 --> Parser Class Initialized
INFO - 2023-12-24 13:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:15:28 --> Pagination Class Initialized
INFO - 2023-12-24 13:15:28 --> Form Validation Class Initialized
INFO - 2023-12-24 13:15:28 --> Controller Class Initialized
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
DEBUG - 2023-12-24 13:15:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
INFO - 2023-12-24 13:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 13:15:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:15:28 --> Model Class Initialized
INFO - 2023-12-24 13:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:15:28 --> Final output sent to browser
DEBUG - 2023-12-24 13:15:28 --> Total execution time: 0.4113
ERROR - 2023-12-24 13:19:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:19:34 --> Config Class Initialized
INFO - 2023-12-24 13:19:34 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:19:34 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:19:34 --> Utf8 Class Initialized
INFO - 2023-12-24 13:19:34 --> URI Class Initialized
DEBUG - 2023-12-24 13:19:34 --> No URI present. Default controller set.
INFO - 2023-12-24 13:19:34 --> Router Class Initialized
INFO - 2023-12-24 13:19:34 --> Output Class Initialized
INFO - 2023-12-24 13:19:34 --> Security Class Initialized
DEBUG - 2023-12-24 13:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:19:34 --> Input Class Initialized
INFO - 2023-12-24 13:19:34 --> Language Class Initialized
INFO - 2023-12-24 13:19:34 --> Loader Class Initialized
INFO - 2023-12-24 13:19:34 --> Helper loaded: url_helper
INFO - 2023-12-24 13:19:34 --> Helper loaded: file_helper
INFO - 2023-12-24 13:19:34 --> Helper loaded: html_helper
INFO - 2023-12-24 13:19:34 --> Helper loaded: text_helper
INFO - 2023-12-24 13:19:34 --> Helper loaded: form_helper
INFO - 2023-12-24 13:19:34 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:19:34 --> Helper loaded: security_helper
INFO - 2023-12-24 13:19:34 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:19:34 --> Database Driver Class Initialized
INFO - 2023-12-24 13:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:19:34 --> Parser Class Initialized
INFO - 2023-12-24 13:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:19:34 --> Pagination Class Initialized
INFO - 2023-12-24 13:19:34 --> Form Validation Class Initialized
INFO - 2023-12-24 13:19:34 --> Controller Class Initialized
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
DEBUG - 2023-12-24 13:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
DEBUG - 2023-12-24 13:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
DEBUG - 2023-12-24 13:19:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
INFO - 2023-12-24 13:19:34 --> Model Class Initialized
INFO - 2023-12-24 13:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 13:19:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:19:35 --> Model Class Initialized
INFO - 2023-12-24 13:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:19:35 --> Final output sent to browser
DEBUG - 2023-12-24 13:19:35 --> Total execution time: 0.4380
ERROR - 2023-12-24 13:21:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:21:17 --> Config Class Initialized
INFO - 2023-12-24 13:21:17 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:21:17 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:21:17 --> Utf8 Class Initialized
INFO - 2023-12-24 13:21:17 --> URI Class Initialized
DEBUG - 2023-12-24 13:21:17 --> No URI present. Default controller set.
INFO - 2023-12-24 13:21:17 --> Router Class Initialized
INFO - 2023-12-24 13:21:17 --> Output Class Initialized
INFO - 2023-12-24 13:21:17 --> Security Class Initialized
DEBUG - 2023-12-24 13:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:21:17 --> Input Class Initialized
INFO - 2023-12-24 13:21:17 --> Language Class Initialized
INFO - 2023-12-24 13:21:17 --> Loader Class Initialized
INFO - 2023-12-24 13:21:17 --> Helper loaded: url_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: file_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: html_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: text_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: form_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: security_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:21:17 --> Database Driver Class Initialized
INFO - 2023-12-24 13:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:21:17 --> Parser Class Initialized
INFO - 2023-12-24 13:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:21:17 --> Pagination Class Initialized
INFO - 2023-12-24 13:21:17 --> Form Validation Class Initialized
INFO - 2023-12-24 13:21:17 --> Controller Class Initialized
INFO - 2023-12-24 13:21:17 --> Model Class Initialized
DEBUG - 2023-12-24 13:21:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-24 13:21:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:21:17 --> Config Class Initialized
INFO - 2023-12-24 13:21:17 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:21:17 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:21:17 --> Utf8 Class Initialized
INFO - 2023-12-24 13:21:17 --> URI Class Initialized
INFO - 2023-12-24 13:21:17 --> Router Class Initialized
INFO - 2023-12-24 13:21:17 --> Output Class Initialized
INFO - 2023-12-24 13:21:17 --> Security Class Initialized
DEBUG - 2023-12-24 13:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:21:17 --> Input Class Initialized
INFO - 2023-12-24 13:21:17 --> Language Class Initialized
INFO - 2023-12-24 13:21:17 --> Loader Class Initialized
INFO - 2023-12-24 13:21:17 --> Helper loaded: url_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: file_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: html_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: text_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: form_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: security_helper
INFO - 2023-12-24 13:21:17 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:21:17 --> Database Driver Class Initialized
INFO - 2023-12-24 13:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:21:17 --> Parser Class Initialized
INFO - 2023-12-24 13:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:21:17 --> Pagination Class Initialized
INFO - 2023-12-24 13:21:17 --> Form Validation Class Initialized
INFO - 2023-12-24 13:21:17 --> Controller Class Initialized
INFO - 2023-12-24 13:21:17 --> Model Class Initialized
DEBUG - 2023-12-24 13:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-24 13:21:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:21:17 --> Model Class Initialized
INFO - 2023-12-24 13:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:21:17 --> Final output sent to browser
DEBUG - 2023-12-24 13:21:17 --> Total execution time: 0.0354
ERROR - 2023-12-24 13:53:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:53:34 --> Config Class Initialized
INFO - 2023-12-24 13:53:34 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:53:34 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:53:34 --> Utf8 Class Initialized
INFO - 2023-12-24 13:53:34 --> URI Class Initialized
DEBUG - 2023-12-24 13:53:34 --> No URI present. Default controller set.
INFO - 2023-12-24 13:53:34 --> Router Class Initialized
INFO - 2023-12-24 13:53:34 --> Output Class Initialized
INFO - 2023-12-24 13:53:34 --> Security Class Initialized
DEBUG - 2023-12-24 13:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:53:34 --> Input Class Initialized
INFO - 2023-12-24 13:53:34 --> Language Class Initialized
INFO - 2023-12-24 13:53:34 --> Loader Class Initialized
INFO - 2023-12-24 13:53:34 --> Helper loaded: url_helper
INFO - 2023-12-24 13:53:34 --> Helper loaded: file_helper
INFO - 2023-12-24 13:53:34 --> Helper loaded: html_helper
INFO - 2023-12-24 13:53:34 --> Helper loaded: text_helper
INFO - 2023-12-24 13:53:34 --> Helper loaded: form_helper
INFO - 2023-12-24 13:53:34 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:53:34 --> Helper loaded: security_helper
INFO - 2023-12-24 13:53:34 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:53:34 --> Database Driver Class Initialized
INFO - 2023-12-24 13:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:53:34 --> Parser Class Initialized
INFO - 2023-12-24 13:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:53:34 --> Pagination Class Initialized
INFO - 2023-12-24 13:53:34 --> Form Validation Class Initialized
INFO - 2023-12-24 13:53:34 --> Controller Class Initialized
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
INFO - 2023-12-24 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 13:53:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:53:34 --> Model Class Initialized
INFO - 2023-12-24 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:53:34 --> Final output sent to browser
DEBUG - 2023-12-24 13:53:34 --> Total execution time: 0.4870
ERROR - 2023-12-24 13:53:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:53:38 --> Config Class Initialized
INFO - 2023-12-24 13:53:38 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:53:38 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:53:38 --> Utf8 Class Initialized
INFO - 2023-12-24 13:53:38 --> URI Class Initialized
DEBUG - 2023-12-24 13:53:38 --> No URI present. Default controller set.
INFO - 2023-12-24 13:53:38 --> Router Class Initialized
INFO - 2023-12-24 13:53:38 --> Output Class Initialized
INFO - 2023-12-24 13:53:38 --> Security Class Initialized
DEBUG - 2023-12-24 13:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:53:38 --> Input Class Initialized
INFO - 2023-12-24 13:53:38 --> Language Class Initialized
INFO - 2023-12-24 13:53:38 --> Loader Class Initialized
INFO - 2023-12-24 13:53:38 --> Helper loaded: url_helper
INFO - 2023-12-24 13:53:38 --> Helper loaded: file_helper
INFO - 2023-12-24 13:53:38 --> Helper loaded: html_helper
INFO - 2023-12-24 13:53:38 --> Helper loaded: text_helper
INFO - 2023-12-24 13:53:38 --> Helper loaded: form_helper
INFO - 2023-12-24 13:53:38 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:53:38 --> Helper loaded: security_helper
INFO - 2023-12-24 13:53:38 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:53:38 --> Database Driver Class Initialized
INFO - 2023-12-24 13:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:53:38 --> Parser Class Initialized
INFO - 2023-12-24 13:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:53:38 --> Pagination Class Initialized
INFO - 2023-12-24 13:53:38 --> Form Validation Class Initialized
INFO - 2023-12-24 13:53:38 --> Controller Class Initialized
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
INFO - 2023-12-24 13:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 13:53:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:53:38 --> Model Class Initialized
INFO - 2023-12-24 13:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:53:38 --> Final output sent to browser
DEBUG - 2023-12-24 13:53:38 --> Total execution time: 0.4290
ERROR - 2023-12-24 13:53:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:53:49 --> Config Class Initialized
INFO - 2023-12-24 13:53:49 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:53:49 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:53:49 --> Utf8 Class Initialized
INFO - 2023-12-24 13:53:49 --> URI Class Initialized
INFO - 2023-12-24 13:53:49 --> Router Class Initialized
INFO - 2023-12-24 13:53:49 --> Output Class Initialized
INFO - 2023-12-24 13:53:49 --> Security Class Initialized
DEBUG - 2023-12-24 13:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:53:49 --> Input Class Initialized
INFO - 2023-12-24 13:53:49 --> Language Class Initialized
INFO - 2023-12-24 13:53:49 --> Loader Class Initialized
INFO - 2023-12-24 13:53:49 --> Helper loaded: url_helper
INFO - 2023-12-24 13:53:49 --> Helper loaded: file_helper
INFO - 2023-12-24 13:53:49 --> Helper loaded: html_helper
INFO - 2023-12-24 13:53:49 --> Helper loaded: text_helper
INFO - 2023-12-24 13:53:49 --> Helper loaded: form_helper
INFO - 2023-12-24 13:53:49 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:53:49 --> Helper loaded: security_helper
INFO - 2023-12-24 13:53:49 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:53:49 --> Database Driver Class Initialized
INFO - 2023-12-24 13:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:53:49 --> Parser Class Initialized
INFO - 2023-12-24 13:53:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:53:49 --> Pagination Class Initialized
INFO - 2023-12-24 13:53:49 --> Form Validation Class Initialized
INFO - 2023-12-24 13:53:49 --> Controller Class Initialized
INFO - 2023-12-24 13:53:49 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:49 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:49 --> Model Class Initialized
INFO - 2023-12-24 13:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-24 13:53:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:53:49 --> Model Class Initialized
INFO - 2023-12-24 13:53:49 --> Model Class Initialized
INFO - 2023-12-24 13:53:49 --> Model Class Initialized
INFO - 2023-12-24 13:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:53:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:53:49 --> Final output sent to browser
DEBUG - 2023-12-24 13:53:49 --> Total execution time: 0.2669
ERROR - 2023-12-24 13:53:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:53:50 --> Config Class Initialized
INFO - 2023-12-24 13:53:50 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:53:50 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:53:50 --> Utf8 Class Initialized
INFO - 2023-12-24 13:53:50 --> URI Class Initialized
INFO - 2023-12-24 13:53:50 --> Router Class Initialized
INFO - 2023-12-24 13:53:50 --> Output Class Initialized
INFO - 2023-12-24 13:53:50 --> Security Class Initialized
DEBUG - 2023-12-24 13:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:53:50 --> Input Class Initialized
INFO - 2023-12-24 13:53:50 --> Language Class Initialized
INFO - 2023-12-24 13:53:50 --> Loader Class Initialized
INFO - 2023-12-24 13:53:50 --> Helper loaded: url_helper
INFO - 2023-12-24 13:53:50 --> Helper loaded: file_helper
INFO - 2023-12-24 13:53:50 --> Helper loaded: html_helper
INFO - 2023-12-24 13:53:50 --> Helper loaded: text_helper
INFO - 2023-12-24 13:53:50 --> Helper loaded: form_helper
INFO - 2023-12-24 13:53:50 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:53:50 --> Helper loaded: security_helper
INFO - 2023-12-24 13:53:50 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:53:50 --> Database Driver Class Initialized
INFO - 2023-12-24 13:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:53:50 --> Parser Class Initialized
INFO - 2023-12-24 13:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:53:50 --> Pagination Class Initialized
INFO - 2023-12-24 13:53:50 --> Form Validation Class Initialized
INFO - 2023-12-24 13:53:50 --> Controller Class Initialized
INFO - 2023-12-24 13:53:50 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:50 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:50 --> Model Class Initialized
INFO - 2023-12-24 13:53:50 --> Final output sent to browser
DEBUG - 2023-12-24 13:53:50 --> Total execution time: 0.0724
ERROR - 2023-12-24 13:53:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:53:53 --> Config Class Initialized
INFO - 2023-12-24 13:53:53 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:53:53 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:53:53 --> Utf8 Class Initialized
INFO - 2023-12-24 13:53:53 --> URI Class Initialized
INFO - 2023-12-24 13:53:53 --> Router Class Initialized
INFO - 2023-12-24 13:53:53 --> Output Class Initialized
INFO - 2023-12-24 13:53:53 --> Security Class Initialized
DEBUG - 2023-12-24 13:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:53:53 --> Input Class Initialized
INFO - 2023-12-24 13:53:53 --> Language Class Initialized
INFO - 2023-12-24 13:53:53 --> Loader Class Initialized
INFO - 2023-12-24 13:53:53 --> Helper loaded: url_helper
INFO - 2023-12-24 13:53:53 --> Helper loaded: file_helper
INFO - 2023-12-24 13:53:53 --> Helper loaded: html_helper
INFO - 2023-12-24 13:53:53 --> Helper loaded: text_helper
INFO - 2023-12-24 13:53:53 --> Helper loaded: form_helper
INFO - 2023-12-24 13:53:53 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:53:53 --> Helper loaded: security_helper
INFO - 2023-12-24 13:53:53 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:53:53 --> Database Driver Class Initialized
INFO - 2023-12-24 13:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:53:53 --> Parser Class Initialized
INFO - 2023-12-24 13:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:53:53 --> Pagination Class Initialized
INFO - 2023-12-24 13:53:53 --> Form Validation Class Initialized
INFO - 2023-12-24 13:53:53 --> Controller Class Initialized
INFO - 2023-12-24 13:53:53 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:53 --> Model Class Initialized
DEBUG - 2023-12-24 13:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:53:53 --> Model Class Initialized
INFO - 2023-12-24 13:53:54 --> Final output sent to browser
DEBUG - 2023-12-24 13:53:54 --> Total execution time: 1.0925
ERROR - 2023-12-24 13:54:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:54:02 --> Config Class Initialized
INFO - 2023-12-24 13:54:02 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:54:02 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:54:02 --> Utf8 Class Initialized
INFO - 2023-12-24 13:54:02 --> URI Class Initialized
INFO - 2023-12-24 13:54:02 --> Router Class Initialized
INFO - 2023-12-24 13:54:02 --> Output Class Initialized
INFO - 2023-12-24 13:54:02 --> Security Class Initialized
DEBUG - 2023-12-24 13:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:54:02 --> Input Class Initialized
INFO - 2023-12-24 13:54:02 --> Language Class Initialized
INFO - 2023-12-24 13:54:02 --> Loader Class Initialized
INFO - 2023-12-24 13:54:02 --> Helper loaded: url_helper
INFO - 2023-12-24 13:54:02 --> Helper loaded: file_helper
INFO - 2023-12-24 13:54:02 --> Helper loaded: html_helper
INFO - 2023-12-24 13:54:02 --> Helper loaded: text_helper
INFO - 2023-12-24 13:54:02 --> Helper loaded: form_helper
INFO - 2023-12-24 13:54:02 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:54:02 --> Helper loaded: security_helper
INFO - 2023-12-24 13:54:02 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:54:02 --> Database Driver Class Initialized
INFO - 2023-12-24 13:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:54:02 --> Parser Class Initialized
INFO - 2023-12-24 13:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:54:02 --> Pagination Class Initialized
INFO - 2023-12-24 13:54:02 --> Form Validation Class Initialized
INFO - 2023-12-24 13:54:02 --> Controller Class Initialized
INFO - 2023-12-24 13:54:02 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:02 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:02 --> Model Class Initialized
INFO - 2023-12-24 13:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-12-24 13:54:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:54:02 --> Model Class Initialized
INFO - 2023-12-24 13:54:02 --> Model Class Initialized
INFO - 2023-12-24 13:54:02 --> Model Class Initialized
INFO - 2023-12-24 13:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:54:02 --> Final output sent to browser
DEBUG - 2023-12-24 13:54:02 --> Total execution time: 0.2539
ERROR - 2023-12-24 13:54:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:54:03 --> Config Class Initialized
INFO - 2023-12-24 13:54:03 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:54:03 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:54:03 --> Utf8 Class Initialized
INFO - 2023-12-24 13:54:03 --> URI Class Initialized
INFO - 2023-12-24 13:54:03 --> Router Class Initialized
INFO - 2023-12-24 13:54:03 --> Output Class Initialized
INFO - 2023-12-24 13:54:03 --> Security Class Initialized
DEBUG - 2023-12-24 13:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:54:03 --> Input Class Initialized
INFO - 2023-12-24 13:54:03 --> Language Class Initialized
INFO - 2023-12-24 13:54:03 --> Loader Class Initialized
INFO - 2023-12-24 13:54:03 --> Helper loaded: url_helper
INFO - 2023-12-24 13:54:03 --> Helper loaded: file_helper
INFO - 2023-12-24 13:54:03 --> Helper loaded: html_helper
INFO - 2023-12-24 13:54:03 --> Helper loaded: text_helper
INFO - 2023-12-24 13:54:03 --> Helper loaded: form_helper
INFO - 2023-12-24 13:54:03 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:54:03 --> Helper loaded: security_helper
INFO - 2023-12-24 13:54:03 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:54:03 --> Database Driver Class Initialized
INFO - 2023-12-24 13:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:54:03 --> Parser Class Initialized
INFO - 2023-12-24 13:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:54:03 --> Pagination Class Initialized
INFO - 2023-12-24 13:54:03 --> Form Validation Class Initialized
INFO - 2023-12-24 13:54:03 --> Controller Class Initialized
INFO - 2023-12-24 13:54:03 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:03 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:03 --> Model Class Initialized
INFO - 2023-12-24 13:54:03 --> Final output sent to browser
DEBUG - 2023-12-24 13:54:03 --> Total execution time: 0.0557
ERROR - 2023-12-24 13:54:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:54:06 --> Config Class Initialized
INFO - 2023-12-24 13:54:06 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:54:06 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:54:06 --> Utf8 Class Initialized
INFO - 2023-12-24 13:54:06 --> URI Class Initialized
INFO - 2023-12-24 13:54:06 --> Router Class Initialized
INFO - 2023-12-24 13:54:06 --> Output Class Initialized
INFO - 2023-12-24 13:54:06 --> Security Class Initialized
DEBUG - 2023-12-24 13:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:54:06 --> Input Class Initialized
INFO - 2023-12-24 13:54:06 --> Language Class Initialized
INFO - 2023-12-24 13:54:06 --> Loader Class Initialized
INFO - 2023-12-24 13:54:06 --> Helper loaded: url_helper
INFO - 2023-12-24 13:54:06 --> Helper loaded: file_helper
INFO - 2023-12-24 13:54:06 --> Helper loaded: html_helper
INFO - 2023-12-24 13:54:06 --> Helper loaded: text_helper
INFO - 2023-12-24 13:54:06 --> Helper loaded: form_helper
INFO - 2023-12-24 13:54:06 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:54:06 --> Helper loaded: security_helper
INFO - 2023-12-24 13:54:06 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:54:06 --> Database Driver Class Initialized
INFO - 2023-12-24 13:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:54:06 --> Parser Class Initialized
INFO - 2023-12-24 13:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:54:06 --> Pagination Class Initialized
INFO - 2023-12-24 13:54:06 --> Form Validation Class Initialized
INFO - 2023-12-24 13:54:06 --> Controller Class Initialized
INFO - 2023-12-24 13:54:06 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:06 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:06 --> Model Class Initialized
INFO - 2023-12-24 13:54:06 --> Final output sent to browser
DEBUG - 2023-12-24 13:54:06 --> Total execution time: 0.3163
ERROR - 2023-12-24 13:54:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:54:23 --> Config Class Initialized
INFO - 2023-12-24 13:54:23 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:54:23 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:54:23 --> Utf8 Class Initialized
INFO - 2023-12-24 13:54:23 --> URI Class Initialized
DEBUG - 2023-12-24 13:54:23 --> No URI present. Default controller set.
INFO - 2023-12-24 13:54:23 --> Router Class Initialized
INFO - 2023-12-24 13:54:23 --> Output Class Initialized
INFO - 2023-12-24 13:54:23 --> Security Class Initialized
DEBUG - 2023-12-24 13:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:54:23 --> Input Class Initialized
INFO - 2023-12-24 13:54:23 --> Language Class Initialized
INFO - 2023-12-24 13:54:23 --> Loader Class Initialized
INFO - 2023-12-24 13:54:23 --> Helper loaded: url_helper
INFO - 2023-12-24 13:54:23 --> Helper loaded: file_helper
INFO - 2023-12-24 13:54:23 --> Helper loaded: html_helper
INFO - 2023-12-24 13:54:23 --> Helper loaded: text_helper
INFO - 2023-12-24 13:54:23 --> Helper loaded: form_helper
INFO - 2023-12-24 13:54:23 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:54:23 --> Helper loaded: security_helper
INFO - 2023-12-24 13:54:23 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:54:23 --> Database Driver Class Initialized
INFO - 2023-12-24 13:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:54:23 --> Parser Class Initialized
INFO - 2023-12-24 13:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:54:23 --> Pagination Class Initialized
INFO - 2023-12-24 13:54:23 --> Form Validation Class Initialized
INFO - 2023-12-24 13:54:23 --> Controller Class Initialized
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
DEBUG - 2023-12-24 13:54:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
INFO - 2023-12-24 13:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 13:54:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:54:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:54:23 --> Model Class Initialized
INFO - 2023-12-24 13:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:54:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:54:24 --> Final output sent to browser
DEBUG - 2023-12-24 13:54:24 --> Total execution time: 0.4342
ERROR - 2023-12-24 13:55:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 13:55:28 --> Config Class Initialized
INFO - 2023-12-24 13:55:28 --> Hooks Class Initialized
DEBUG - 2023-12-24 13:55:28 --> UTF-8 Support Enabled
INFO - 2023-12-24 13:55:28 --> Utf8 Class Initialized
INFO - 2023-12-24 13:55:28 --> URI Class Initialized
DEBUG - 2023-12-24 13:55:28 --> No URI present. Default controller set.
INFO - 2023-12-24 13:55:28 --> Router Class Initialized
INFO - 2023-12-24 13:55:28 --> Output Class Initialized
INFO - 2023-12-24 13:55:28 --> Security Class Initialized
DEBUG - 2023-12-24 13:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 13:55:28 --> Input Class Initialized
INFO - 2023-12-24 13:55:28 --> Language Class Initialized
INFO - 2023-12-24 13:55:28 --> Loader Class Initialized
INFO - 2023-12-24 13:55:28 --> Helper loaded: url_helper
INFO - 2023-12-24 13:55:28 --> Helper loaded: file_helper
INFO - 2023-12-24 13:55:28 --> Helper loaded: html_helper
INFO - 2023-12-24 13:55:28 --> Helper loaded: text_helper
INFO - 2023-12-24 13:55:28 --> Helper loaded: form_helper
INFO - 2023-12-24 13:55:28 --> Helper loaded: lang_helper
INFO - 2023-12-24 13:55:28 --> Helper loaded: security_helper
INFO - 2023-12-24 13:55:28 --> Helper loaded: cookie_helper
INFO - 2023-12-24 13:55:28 --> Database Driver Class Initialized
INFO - 2023-12-24 13:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 13:55:28 --> Parser Class Initialized
INFO - 2023-12-24 13:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 13:55:28 --> Pagination Class Initialized
INFO - 2023-12-24 13:55:28 --> Form Validation Class Initialized
INFO - 2023-12-24 13:55:28 --> Controller Class Initialized
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
DEBUG - 2023-12-24 13:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
DEBUG - 2023-12-24 13:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
DEBUG - 2023-12-24 13:55:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 13:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
INFO - 2023-12-24 13:55:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 13:55:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 13:55:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 13:55:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 13:55:28 --> Model Class Initialized
INFO - 2023-12-24 13:55:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 13:55:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 13:55:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 13:55:28 --> Final output sent to browser
DEBUG - 2023-12-24 13:55:28 --> Total execution time: 0.4132
ERROR - 2023-12-24 15:10:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:10:39 --> Config Class Initialized
INFO - 2023-12-24 15:10:39 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:10:39 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:10:39 --> Utf8 Class Initialized
INFO - 2023-12-24 15:10:39 --> URI Class Initialized
DEBUG - 2023-12-24 15:10:39 --> No URI present. Default controller set.
INFO - 2023-12-24 15:10:39 --> Router Class Initialized
INFO - 2023-12-24 15:10:39 --> Output Class Initialized
INFO - 2023-12-24 15:10:39 --> Security Class Initialized
DEBUG - 2023-12-24 15:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:10:39 --> Input Class Initialized
INFO - 2023-12-24 15:10:39 --> Language Class Initialized
INFO - 2023-12-24 15:10:39 --> Loader Class Initialized
INFO - 2023-12-24 15:10:39 --> Helper loaded: url_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: file_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: html_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: text_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: form_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: security_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:10:39 --> Database Driver Class Initialized
INFO - 2023-12-24 15:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:10:39 --> Parser Class Initialized
INFO - 2023-12-24 15:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:10:39 --> Pagination Class Initialized
INFO - 2023-12-24 15:10:39 --> Form Validation Class Initialized
INFO - 2023-12-24 15:10:39 --> Controller Class Initialized
INFO - 2023-12-24 15:10:39 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-24 15:10:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:10:39 --> Config Class Initialized
INFO - 2023-12-24 15:10:39 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:10:39 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:10:39 --> Utf8 Class Initialized
INFO - 2023-12-24 15:10:39 --> URI Class Initialized
INFO - 2023-12-24 15:10:39 --> Router Class Initialized
INFO - 2023-12-24 15:10:39 --> Output Class Initialized
INFO - 2023-12-24 15:10:39 --> Security Class Initialized
DEBUG - 2023-12-24 15:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:10:39 --> Input Class Initialized
INFO - 2023-12-24 15:10:39 --> Language Class Initialized
INFO - 2023-12-24 15:10:39 --> Loader Class Initialized
INFO - 2023-12-24 15:10:39 --> Helper loaded: url_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: file_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: html_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: text_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: form_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: security_helper
INFO - 2023-12-24 15:10:39 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:10:39 --> Database Driver Class Initialized
INFO - 2023-12-24 15:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:10:39 --> Parser Class Initialized
INFO - 2023-12-24 15:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:10:39 --> Pagination Class Initialized
INFO - 2023-12-24 15:10:39 --> Form Validation Class Initialized
INFO - 2023-12-24 15:10:39 --> Controller Class Initialized
INFO - 2023-12-24 15:10:39 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-24 15:10:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 15:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 15:10:39 --> Model Class Initialized
INFO - 2023-12-24 15:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 15:10:39 --> Final output sent to browser
DEBUG - 2023-12-24 15:10:39 --> Total execution time: 0.0379
ERROR - 2023-12-24 15:10:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:10:49 --> Config Class Initialized
INFO - 2023-12-24 15:10:49 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:10:49 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:10:49 --> Utf8 Class Initialized
INFO - 2023-12-24 15:10:49 --> URI Class Initialized
INFO - 2023-12-24 15:10:49 --> Router Class Initialized
INFO - 2023-12-24 15:10:49 --> Output Class Initialized
INFO - 2023-12-24 15:10:49 --> Security Class Initialized
DEBUG - 2023-12-24 15:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:10:49 --> Input Class Initialized
INFO - 2023-12-24 15:10:49 --> Language Class Initialized
INFO - 2023-12-24 15:10:49 --> Loader Class Initialized
INFO - 2023-12-24 15:10:49 --> Helper loaded: url_helper
INFO - 2023-12-24 15:10:49 --> Helper loaded: file_helper
INFO - 2023-12-24 15:10:49 --> Helper loaded: html_helper
INFO - 2023-12-24 15:10:49 --> Helper loaded: text_helper
INFO - 2023-12-24 15:10:49 --> Helper loaded: form_helper
INFO - 2023-12-24 15:10:49 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:10:49 --> Helper loaded: security_helper
INFO - 2023-12-24 15:10:49 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:10:49 --> Database Driver Class Initialized
INFO - 2023-12-24 15:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:10:49 --> Parser Class Initialized
INFO - 2023-12-24 15:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:10:49 --> Pagination Class Initialized
INFO - 2023-12-24 15:10:49 --> Form Validation Class Initialized
INFO - 2023-12-24 15:10:49 --> Controller Class Initialized
INFO - 2023-12-24 15:10:49 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:49 --> Model Class Initialized
INFO - 2023-12-24 15:10:49 --> Final output sent to browser
DEBUG - 2023-12-24 15:10:49 --> Total execution time: 0.0188
ERROR - 2023-12-24 15:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:10:50 --> Config Class Initialized
INFO - 2023-12-24 15:10:50 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:10:50 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:10:50 --> Utf8 Class Initialized
INFO - 2023-12-24 15:10:50 --> URI Class Initialized
DEBUG - 2023-12-24 15:10:50 --> No URI present. Default controller set.
INFO - 2023-12-24 15:10:50 --> Router Class Initialized
INFO - 2023-12-24 15:10:50 --> Output Class Initialized
INFO - 2023-12-24 15:10:50 --> Security Class Initialized
DEBUG - 2023-12-24 15:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:10:50 --> Input Class Initialized
INFO - 2023-12-24 15:10:50 --> Language Class Initialized
INFO - 2023-12-24 15:10:50 --> Loader Class Initialized
INFO - 2023-12-24 15:10:50 --> Helper loaded: url_helper
INFO - 2023-12-24 15:10:50 --> Helper loaded: file_helper
INFO - 2023-12-24 15:10:50 --> Helper loaded: html_helper
INFO - 2023-12-24 15:10:50 --> Helper loaded: text_helper
INFO - 2023-12-24 15:10:50 --> Helper loaded: form_helper
INFO - 2023-12-24 15:10:50 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:10:50 --> Helper loaded: security_helper
INFO - 2023-12-24 15:10:50 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:10:50 --> Database Driver Class Initialized
INFO - 2023-12-24 15:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:10:50 --> Parser Class Initialized
INFO - 2023-12-24 15:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:10:50 --> Pagination Class Initialized
INFO - 2023-12-24 15:10:50 --> Form Validation Class Initialized
INFO - 2023-12-24 15:10:50 --> Controller Class Initialized
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 15:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
INFO - 2023-12-24 15:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-24 15:10:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 15:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 15:10:50 --> Model Class Initialized
INFO - 2023-12-24 15:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 15:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 15:10:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 15:10:50 --> Final output sent to browser
DEBUG - 2023-12-24 15:10:50 --> Total execution time: 0.4418
ERROR - 2023-12-24 15:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:10:51 --> Config Class Initialized
INFO - 2023-12-24 15:10:51 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:10:51 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:10:51 --> Utf8 Class Initialized
INFO - 2023-12-24 15:10:51 --> URI Class Initialized
INFO - 2023-12-24 15:10:51 --> Router Class Initialized
INFO - 2023-12-24 15:10:51 --> Output Class Initialized
INFO - 2023-12-24 15:10:51 --> Security Class Initialized
DEBUG - 2023-12-24 15:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:10:51 --> Input Class Initialized
INFO - 2023-12-24 15:10:51 --> Language Class Initialized
INFO - 2023-12-24 15:10:51 --> Loader Class Initialized
INFO - 2023-12-24 15:10:51 --> Helper loaded: url_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: file_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: html_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: text_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: form_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: security_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:10:51 --> Database Driver Class Initialized
INFO - 2023-12-24 15:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:10:51 --> Parser Class Initialized
INFO - 2023-12-24 15:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:10:51 --> Pagination Class Initialized
INFO - 2023-12-24 15:10:51 --> Form Validation Class Initialized
INFO - 2023-12-24 15:10:51 --> Controller Class Initialized
DEBUG - 2023-12-24 15:10:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 15:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:51 --> Model Class Initialized
INFO - 2023-12-24 15:10:51 --> Final output sent to browser
DEBUG - 2023-12-24 15:10:51 --> Total execution time: 0.0134
ERROR - 2023-12-24 15:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:10:51 --> Config Class Initialized
INFO - 2023-12-24 15:10:51 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:10:51 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:10:51 --> Utf8 Class Initialized
INFO - 2023-12-24 15:10:51 --> URI Class Initialized
DEBUG - 2023-12-24 15:10:51 --> No URI present. Default controller set.
INFO - 2023-12-24 15:10:51 --> Router Class Initialized
INFO - 2023-12-24 15:10:51 --> Output Class Initialized
INFO - 2023-12-24 15:10:51 --> Security Class Initialized
DEBUG - 2023-12-24 15:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:10:51 --> Input Class Initialized
INFO - 2023-12-24 15:10:51 --> Language Class Initialized
INFO - 2023-12-24 15:10:51 --> Loader Class Initialized
INFO - 2023-12-24 15:10:51 --> Helper loaded: url_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: file_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: html_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: text_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: form_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: security_helper
INFO - 2023-12-24 15:10:51 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:10:51 --> Database Driver Class Initialized
INFO - 2023-12-24 15:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:10:51 --> Parser Class Initialized
INFO - 2023-12-24 15:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:10:51 --> Pagination Class Initialized
INFO - 2023-12-24 15:10:51 --> Form Validation Class Initialized
INFO - 2023-12-24 15:10:51 --> Controller Class Initialized
INFO - 2023-12-24 15:10:51 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-24 15:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:10:52 --> Config Class Initialized
INFO - 2023-12-24 15:10:52 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:10:52 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:10:52 --> Utf8 Class Initialized
INFO - 2023-12-24 15:10:52 --> URI Class Initialized
INFO - 2023-12-24 15:10:52 --> Router Class Initialized
INFO - 2023-12-24 15:10:52 --> Output Class Initialized
INFO - 2023-12-24 15:10:52 --> Security Class Initialized
DEBUG - 2023-12-24 15:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:10:52 --> Input Class Initialized
INFO - 2023-12-24 15:10:52 --> Language Class Initialized
INFO - 2023-12-24 15:10:52 --> Loader Class Initialized
INFO - 2023-12-24 15:10:52 --> Helper loaded: url_helper
INFO - 2023-12-24 15:10:52 --> Helper loaded: file_helper
INFO - 2023-12-24 15:10:52 --> Helper loaded: html_helper
INFO - 2023-12-24 15:10:52 --> Helper loaded: text_helper
INFO - 2023-12-24 15:10:52 --> Helper loaded: form_helper
INFO - 2023-12-24 15:10:52 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:10:52 --> Helper loaded: security_helper
INFO - 2023-12-24 15:10:52 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:10:52 --> Database Driver Class Initialized
INFO - 2023-12-24 15:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:10:52 --> Parser Class Initialized
INFO - 2023-12-24 15:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:10:52 --> Pagination Class Initialized
INFO - 2023-12-24 15:10:52 --> Form Validation Class Initialized
INFO - 2023-12-24 15:10:52 --> Controller Class Initialized
INFO - 2023-12-24 15:10:52 --> Model Class Initialized
DEBUG - 2023-12-24 15:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-24 15:10:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 15:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 15:10:52 --> Model Class Initialized
INFO - 2023-12-24 15:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 15:10:52 --> Final output sent to browser
DEBUG - 2023-12-24 15:10:52 --> Total execution time: 0.0319
ERROR - 2023-12-24 15:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:11:06 --> Config Class Initialized
INFO - 2023-12-24 15:11:06 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:11:06 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:11:06 --> Utf8 Class Initialized
INFO - 2023-12-24 15:11:06 --> URI Class Initialized
INFO - 2023-12-24 15:11:06 --> Router Class Initialized
INFO - 2023-12-24 15:11:06 --> Output Class Initialized
INFO - 2023-12-24 15:11:06 --> Security Class Initialized
DEBUG - 2023-12-24 15:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:11:06 --> Input Class Initialized
INFO - 2023-12-24 15:11:06 --> Language Class Initialized
INFO - 2023-12-24 15:11:06 --> Loader Class Initialized
INFO - 2023-12-24 15:11:06 --> Helper loaded: url_helper
INFO - 2023-12-24 15:11:06 --> Helper loaded: file_helper
INFO - 2023-12-24 15:11:06 --> Helper loaded: html_helper
INFO - 2023-12-24 15:11:06 --> Helper loaded: text_helper
INFO - 2023-12-24 15:11:06 --> Helper loaded: form_helper
INFO - 2023-12-24 15:11:06 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:11:06 --> Helper loaded: security_helper
INFO - 2023-12-24 15:11:06 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:11:06 --> Database Driver Class Initialized
INFO - 2023-12-24 15:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:11:06 --> Parser Class Initialized
INFO - 2023-12-24 15:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:11:06 --> Pagination Class Initialized
INFO - 2023-12-24 15:11:06 --> Form Validation Class Initialized
INFO - 2023-12-24 15:11:06 --> Controller Class Initialized
INFO - 2023-12-24 15:11:06 --> Model Class Initialized
DEBUG - 2023-12-24 15:11:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 15:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:11:06 --> Model Class Initialized
DEBUG - 2023-12-24 15:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:11:06 --> Model Class Initialized
INFO - 2023-12-24 15:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-24 15:11:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-24 15:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-24 15:11:06 --> Model Class Initialized
INFO - 2023-12-24 15:11:06 --> Model Class Initialized
INFO - 2023-12-24 15:11:06 --> Model Class Initialized
INFO - 2023-12-24 15:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-24 15:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-24 15:11:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-24 15:11:06 --> Final output sent to browser
DEBUG - 2023-12-24 15:11:06 --> Total execution time: 0.2393
ERROR - 2023-12-24 15:11:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-24 15:11:07 --> Config Class Initialized
INFO - 2023-12-24 15:11:07 --> Hooks Class Initialized
DEBUG - 2023-12-24 15:11:07 --> UTF-8 Support Enabled
INFO - 2023-12-24 15:11:07 --> Utf8 Class Initialized
INFO - 2023-12-24 15:11:07 --> URI Class Initialized
INFO - 2023-12-24 15:11:07 --> Router Class Initialized
INFO - 2023-12-24 15:11:07 --> Output Class Initialized
INFO - 2023-12-24 15:11:07 --> Security Class Initialized
DEBUG - 2023-12-24 15:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-24 15:11:07 --> Input Class Initialized
INFO - 2023-12-24 15:11:07 --> Language Class Initialized
INFO - 2023-12-24 15:11:07 --> Loader Class Initialized
INFO - 2023-12-24 15:11:07 --> Helper loaded: url_helper
INFO - 2023-12-24 15:11:07 --> Helper loaded: file_helper
INFO - 2023-12-24 15:11:07 --> Helper loaded: html_helper
INFO - 2023-12-24 15:11:07 --> Helper loaded: text_helper
INFO - 2023-12-24 15:11:07 --> Helper loaded: form_helper
INFO - 2023-12-24 15:11:07 --> Helper loaded: lang_helper
INFO - 2023-12-24 15:11:07 --> Helper loaded: security_helper
INFO - 2023-12-24 15:11:07 --> Helper loaded: cookie_helper
INFO - 2023-12-24 15:11:07 --> Database Driver Class Initialized
INFO - 2023-12-24 15:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-24 15:11:07 --> Parser Class Initialized
INFO - 2023-12-24 15:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-24 15:11:07 --> Pagination Class Initialized
INFO - 2023-12-24 15:11:07 --> Form Validation Class Initialized
INFO - 2023-12-24 15:11:07 --> Controller Class Initialized
INFO - 2023-12-24 15:11:07 --> Model Class Initialized
DEBUG - 2023-12-24 15:11:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-24 15:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:11:07 --> Model Class Initialized
DEBUG - 2023-12-24 15:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-24 15:11:07 --> Model Class Initialized
INFO - 2023-12-24 15:11:07 --> Final output sent to browser
DEBUG - 2023-12-24 15:11:07 --> Total execution time: 0.0648
