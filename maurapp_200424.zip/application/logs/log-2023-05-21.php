<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-21 06:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 06:25:26 --> Config Class Initialized
INFO - 2023-05-21 06:25:26 --> Hooks Class Initialized
DEBUG - 2023-05-21 06:25:26 --> UTF-8 Support Enabled
INFO - 2023-05-21 06:25:26 --> Utf8 Class Initialized
INFO - 2023-05-21 06:25:26 --> URI Class Initialized
DEBUG - 2023-05-21 06:25:26 --> No URI present. Default controller set.
INFO - 2023-05-21 06:25:26 --> Router Class Initialized
INFO - 2023-05-21 06:25:26 --> Output Class Initialized
INFO - 2023-05-21 06:25:26 --> Security Class Initialized
DEBUG - 2023-05-21 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 06:25:26 --> Input Class Initialized
INFO - 2023-05-21 06:25:26 --> Language Class Initialized
INFO - 2023-05-21 06:25:26 --> Loader Class Initialized
INFO - 2023-05-21 06:25:26 --> Helper loaded: url_helper
INFO - 2023-05-21 06:25:26 --> Helper loaded: file_helper
INFO - 2023-05-21 06:25:26 --> Helper loaded: html_helper
INFO - 2023-05-21 06:25:26 --> Helper loaded: text_helper
INFO - 2023-05-21 06:25:26 --> Helper loaded: form_helper
INFO - 2023-05-21 06:25:26 --> Helper loaded: lang_helper
INFO - 2023-05-21 06:25:26 --> Helper loaded: security_helper
INFO - 2023-05-21 06:25:26 --> Helper loaded: cookie_helper
INFO - 2023-05-21 06:25:26 --> Database Driver Class Initialized
INFO - 2023-05-21 06:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 06:25:26 --> Parser Class Initialized
INFO - 2023-05-21 06:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 06:25:26 --> Pagination Class Initialized
INFO - 2023-05-21 06:25:26 --> Form Validation Class Initialized
INFO - 2023-05-21 06:25:26 --> Controller Class Initialized
INFO - 2023-05-21 06:25:26 --> Model Class Initialized
DEBUG - 2023-05-21 06:25:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-21 06:59:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 06:59:38 --> Config Class Initialized
INFO - 2023-05-21 06:59:38 --> Hooks Class Initialized
DEBUG - 2023-05-21 06:59:38 --> UTF-8 Support Enabled
INFO - 2023-05-21 06:59:38 --> Utf8 Class Initialized
INFO - 2023-05-21 06:59:38 --> URI Class Initialized
DEBUG - 2023-05-21 06:59:38 --> No URI present. Default controller set.
INFO - 2023-05-21 06:59:38 --> Router Class Initialized
INFO - 2023-05-21 06:59:38 --> Output Class Initialized
INFO - 2023-05-21 06:59:38 --> Security Class Initialized
DEBUG - 2023-05-21 06:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 06:59:38 --> Input Class Initialized
INFO - 2023-05-21 06:59:38 --> Language Class Initialized
INFO - 2023-05-21 06:59:38 --> Loader Class Initialized
INFO - 2023-05-21 06:59:38 --> Helper loaded: url_helper
INFO - 2023-05-21 06:59:38 --> Helper loaded: file_helper
INFO - 2023-05-21 06:59:38 --> Helper loaded: html_helper
INFO - 2023-05-21 06:59:38 --> Helper loaded: text_helper
INFO - 2023-05-21 06:59:38 --> Helper loaded: form_helper
INFO - 2023-05-21 06:59:38 --> Helper loaded: lang_helper
INFO - 2023-05-21 06:59:38 --> Helper loaded: security_helper
INFO - 2023-05-21 06:59:38 --> Helper loaded: cookie_helper
INFO - 2023-05-21 06:59:38 --> Database Driver Class Initialized
INFO - 2023-05-21 06:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 06:59:38 --> Parser Class Initialized
INFO - 2023-05-21 06:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 06:59:38 --> Pagination Class Initialized
INFO - 2023-05-21 06:59:38 --> Form Validation Class Initialized
INFO - 2023-05-21 06:59:38 --> Controller Class Initialized
INFO - 2023-05-21 06:59:38 --> Model Class Initialized
DEBUG - 2023-05-21 06:59:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-21 06:59:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 06:59:39 --> Config Class Initialized
INFO - 2023-05-21 06:59:39 --> Hooks Class Initialized
DEBUG - 2023-05-21 06:59:39 --> UTF-8 Support Enabled
INFO - 2023-05-21 06:59:39 --> Utf8 Class Initialized
INFO - 2023-05-21 06:59:39 --> URI Class Initialized
INFO - 2023-05-21 06:59:39 --> Router Class Initialized
INFO - 2023-05-21 06:59:39 --> Output Class Initialized
INFO - 2023-05-21 06:59:39 --> Security Class Initialized
DEBUG - 2023-05-21 06:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 06:59:39 --> Input Class Initialized
INFO - 2023-05-21 06:59:39 --> Language Class Initialized
INFO - 2023-05-21 06:59:39 --> Loader Class Initialized
INFO - 2023-05-21 06:59:39 --> Helper loaded: url_helper
INFO - 2023-05-21 06:59:39 --> Helper loaded: file_helper
INFO - 2023-05-21 06:59:39 --> Helper loaded: html_helper
INFO - 2023-05-21 06:59:39 --> Helper loaded: text_helper
INFO - 2023-05-21 06:59:39 --> Helper loaded: form_helper
INFO - 2023-05-21 06:59:39 --> Helper loaded: lang_helper
INFO - 2023-05-21 06:59:39 --> Helper loaded: security_helper
INFO - 2023-05-21 06:59:39 --> Helper loaded: cookie_helper
INFO - 2023-05-21 06:59:39 --> Database Driver Class Initialized
INFO - 2023-05-21 06:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 06:59:39 --> Parser Class Initialized
INFO - 2023-05-21 06:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 06:59:39 --> Pagination Class Initialized
INFO - 2023-05-21 06:59:39 --> Form Validation Class Initialized
INFO - 2023-05-21 06:59:39 --> Controller Class Initialized
INFO - 2023-05-21 06:59:39 --> Model Class Initialized
DEBUG - 2023-05-21 06:59:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 06:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 06:59:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 06:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 06:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 06:59:39 --> Model Class Initialized
INFO - 2023-05-21 06:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 06:59:39 --> Final output sent to browser
DEBUG - 2023-05-21 06:59:39 --> Total execution time: 0.0317
ERROR - 2023-05-21 07:00:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:00:27 --> Config Class Initialized
INFO - 2023-05-21 07:00:27 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:00:27 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:00:27 --> Utf8 Class Initialized
INFO - 2023-05-21 07:00:27 --> URI Class Initialized
INFO - 2023-05-21 07:00:27 --> Router Class Initialized
INFO - 2023-05-21 07:00:27 --> Output Class Initialized
INFO - 2023-05-21 07:00:27 --> Security Class Initialized
DEBUG - 2023-05-21 07:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:00:27 --> Input Class Initialized
INFO - 2023-05-21 07:00:27 --> Language Class Initialized
INFO - 2023-05-21 07:00:27 --> Loader Class Initialized
INFO - 2023-05-21 07:00:27 --> Helper loaded: url_helper
INFO - 2023-05-21 07:00:27 --> Helper loaded: file_helper
INFO - 2023-05-21 07:00:27 --> Helper loaded: html_helper
INFO - 2023-05-21 07:00:27 --> Helper loaded: text_helper
INFO - 2023-05-21 07:00:27 --> Helper loaded: form_helper
INFO - 2023-05-21 07:00:27 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:00:27 --> Helper loaded: security_helper
INFO - 2023-05-21 07:00:27 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:00:27 --> Database Driver Class Initialized
INFO - 2023-05-21 07:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:00:27 --> Parser Class Initialized
INFO - 2023-05-21 07:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:00:27 --> Pagination Class Initialized
INFO - 2023-05-21 07:00:27 --> Form Validation Class Initialized
INFO - 2023-05-21 07:00:27 --> Controller Class Initialized
INFO - 2023-05-21 07:00:27 --> Model Class Initialized
DEBUG - 2023-05-21 07:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:00:27 --> Model Class Initialized
INFO - 2023-05-21 07:00:27 --> Final output sent to browser
DEBUG - 2023-05-21 07:00:27 --> Total execution time: 0.0206
ERROR - 2023-05-21 07:00:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:00:28 --> Config Class Initialized
INFO - 2023-05-21 07:00:28 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:00:28 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:00:28 --> Utf8 Class Initialized
INFO - 2023-05-21 07:00:28 --> URI Class Initialized
INFO - 2023-05-21 07:00:28 --> Router Class Initialized
INFO - 2023-05-21 07:00:28 --> Output Class Initialized
INFO - 2023-05-21 07:00:28 --> Security Class Initialized
DEBUG - 2023-05-21 07:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:00:28 --> Input Class Initialized
INFO - 2023-05-21 07:00:28 --> Language Class Initialized
INFO - 2023-05-21 07:00:28 --> Loader Class Initialized
INFO - 2023-05-21 07:00:28 --> Helper loaded: url_helper
INFO - 2023-05-21 07:00:28 --> Helper loaded: file_helper
INFO - 2023-05-21 07:00:28 --> Helper loaded: html_helper
INFO - 2023-05-21 07:00:28 --> Helper loaded: text_helper
INFO - 2023-05-21 07:00:28 --> Helper loaded: form_helper
INFO - 2023-05-21 07:00:28 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:00:28 --> Helper loaded: security_helper
INFO - 2023-05-21 07:00:28 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:00:28 --> Database Driver Class Initialized
INFO - 2023-05-21 07:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:00:28 --> Parser Class Initialized
INFO - 2023-05-21 07:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:00:28 --> Pagination Class Initialized
INFO - 2023-05-21 07:00:28 --> Form Validation Class Initialized
INFO - 2023-05-21 07:00:28 --> Controller Class Initialized
INFO - 2023-05-21 07:00:28 --> Model Class Initialized
DEBUG - 2023-05-21 07:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 07:00:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 07:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 07:00:28 --> Model Class Initialized
INFO - 2023-05-21 07:00:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 07:00:28 --> Final output sent to browser
DEBUG - 2023-05-21 07:00:28 --> Total execution time: 0.0297
ERROR - 2023-05-21 07:06:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:06:16 --> Config Class Initialized
INFO - 2023-05-21 07:06:16 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:06:16 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:06:16 --> Utf8 Class Initialized
INFO - 2023-05-21 07:06:16 --> URI Class Initialized
DEBUG - 2023-05-21 07:06:16 --> No URI present. Default controller set.
INFO - 2023-05-21 07:06:16 --> Router Class Initialized
INFO - 2023-05-21 07:06:16 --> Output Class Initialized
INFO - 2023-05-21 07:06:16 --> Security Class Initialized
DEBUG - 2023-05-21 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:06:16 --> Input Class Initialized
INFO - 2023-05-21 07:06:16 --> Language Class Initialized
INFO - 2023-05-21 07:06:16 --> Loader Class Initialized
INFO - 2023-05-21 07:06:16 --> Helper loaded: url_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: file_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: html_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: text_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: form_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: security_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:06:16 --> Database Driver Class Initialized
INFO - 2023-05-21 07:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:06:16 --> Parser Class Initialized
INFO - 2023-05-21 07:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:06:16 --> Pagination Class Initialized
INFO - 2023-05-21 07:06:16 --> Form Validation Class Initialized
INFO - 2023-05-21 07:06:16 --> Controller Class Initialized
INFO - 2023-05-21 07:06:16 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-21 07:06:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:06:16 --> Config Class Initialized
INFO - 2023-05-21 07:06:16 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:06:16 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:06:16 --> Utf8 Class Initialized
INFO - 2023-05-21 07:06:16 --> URI Class Initialized
INFO - 2023-05-21 07:06:16 --> Router Class Initialized
INFO - 2023-05-21 07:06:16 --> Output Class Initialized
INFO - 2023-05-21 07:06:16 --> Security Class Initialized
DEBUG - 2023-05-21 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:06:16 --> Input Class Initialized
INFO - 2023-05-21 07:06:16 --> Language Class Initialized
INFO - 2023-05-21 07:06:16 --> Loader Class Initialized
INFO - 2023-05-21 07:06:16 --> Helper loaded: url_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: file_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: html_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: text_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: form_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: security_helper
INFO - 2023-05-21 07:06:16 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:06:16 --> Database Driver Class Initialized
INFO - 2023-05-21 07:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:06:16 --> Parser Class Initialized
INFO - 2023-05-21 07:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:06:16 --> Pagination Class Initialized
INFO - 2023-05-21 07:06:16 --> Form Validation Class Initialized
INFO - 2023-05-21 07:06:16 --> Controller Class Initialized
INFO - 2023-05-21 07:06:16 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 07:06:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 07:06:16 --> Model Class Initialized
INFO - 2023-05-21 07:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 07:06:16 --> Final output sent to browser
DEBUG - 2023-05-21 07:06:16 --> Total execution time: 0.0315
ERROR - 2023-05-21 07:06:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:06:38 --> Config Class Initialized
INFO - 2023-05-21 07:06:38 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:06:38 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:06:38 --> Utf8 Class Initialized
INFO - 2023-05-21 07:06:38 --> URI Class Initialized
INFO - 2023-05-21 07:06:38 --> Router Class Initialized
INFO - 2023-05-21 07:06:38 --> Output Class Initialized
INFO - 2023-05-21 07:06:38 --> Security Class Initialized
DEBUG - 2023-05-21 07:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:06:38 --> Input Class Initialized
INFO - 2023-05-21 07:06:38 --> Language Class Initialized
INFO - 2023-05-21 07:06:38 --> Loader Class Initialized
INFO - 2023-05-21 07:06:38 --> Helper loaded: url_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: file_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: html_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: text_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: form_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: security_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:06:38 --> Database Driver Class Initialized
INFO - 2023-05-21 07:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:06:38 --> Parser Class Initialized
INFO - 2023-05-21 07:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:06:38 --> Pagination Class Initialized
INFO - 2023-05-21 07:06:38 --> Form Validation Class Initialized
INFO - 2023-05-21 07:06:38 --> Controller Class Initialized
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
INFO - 2023-05-21 07:06:38 --> Final output sent to browser
DEBUG - 2023-05-21 07:06:38 --> Total execution time: 0.0194
ERROR - 2023-05-21 07:06:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:06:38 --> Config Class Initialized
INFO - 2023-05-21 07:06:38 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:06:38 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:06:38 --> Utf8 Class Initialized
INFO - 2023-05-21 07:06:38 --> URI Class Initialized
DEBUG - 2023-05-21 07:06:38 --> No URI present. Default controller set.
INFO - 2023-05-21 07:06:38 --> Router Class Initialized
INFO - 2023-05-21 07:06:38 --> Output Class Initialized
INFO - 2023-05-21 07:06:38 --> Security Class Initialized
DEBUG - 2023-05-21 07:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:06:38 --> Input Class Initialized
INFO - 2023-05-21 07:06:38 --> Language Class Initialized
INFO - 2023-05-21 07:06:38 --> Loader Class Initialized
INFO - 2023-05-21 07:06:38 --> Helper loaded: url_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: file_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: html_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: text_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: form_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: security_helper
INFO - 2023-05-21 07:06:38 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:06:38 --> Database Driver Class Initialized
INFO - 2023-05-21 07:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:06:38 --> Parser Class Initialized
INFO - 2023-05-21 07:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:06:38 --> Pagination Class Initialized
INFO - 2023-05-21 07:06:38 --> Form Validation Class Initialized
INFO - 2023-05-21 07:06:38 --> Controller Class Initialized
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 07:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
INFO - 2023-05-21 07:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-21 07:06:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 07:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 07:06:38 --> Model Class Initialized
INFO - 2023-05-21 07:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 07:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 07:06:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 07:06:38 --> Final output sent to browser
DEBUG - 2023-05-21 07:06:38 --> Total execution time: 0.1764
ERROR - 2023-05-21 07:06:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:06:40 --> Config Class Initialized
INFO - 2023-05-21 07:06:40 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:06:40 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:06:40 --> Utf8 Class Initialized
INFO - 2023-05-21 07:06:40 --> URI Class Initialized
INFO - 2023-05-21 07:06:40 --> Router Class Initialized
INFO - 2023-05-21 07:06:40 --> Output Class Initialized
INFO - 2023-05-21 07:06:40 --> Security Class Initialized
DEBUG - 2023-05-21 07:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:06:40 --> Input Class Initialized
INFO - 2023-05-21 07:06:40 --> Language Class Initialized
INFO - 2023-05-21 07:06:40 --> Loader Class Initialized
INFO - 2023-05-21 07:06:40 --> Helper loaded: url_helper
INFO - 2023-05-21 07:06:40 --> Helper loaded: file_helper
INFO - 2023-05-21 07:06:40 --> Helper loaded: html_helper
INFO - 2023-05-21 07:06:40 --> Helper loaded: text_helper
INFO - 2023-05-21 07:06:40 --> Helper loaded: form_helper
INFO - 2023-05-21 07:06:40 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:06:40 --> Helper loaded: security_helper
INFO - 2023-05-21 07:06:40 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:06:40 --> Database Driver Class Initialized
INFO - 2023-05-21 07:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:06:40 --> Parser Class Initialized
INFO - 2023-05-21 07:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:06:40 --> Pagination Class Initialized
INFO - 2023-05-21 07:06:40 --> Form Validation Class Initialized
INFO - 2023-05-21 07:06:40 --> Controller Class Initialized
DEBUG - 2023-05-21 07:06:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 07:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:40 --> Model Class Initialized
INFO - 2023-05-21 07:06:40 --> Final output sent to browser
DEBUG - 2023-05-21 07:06:40 --> Total execution time: 0.0141
ERROR - 2023-05-21 07:06:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:06:49 --> Config Class Initialized
INFO - 2023-05-21 07:06:49 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:06:49 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:06:49 --> Utf8 Class Initialized
INFO - 2023-05-21 07:06:49 --> URI Class Initialized
DEBUG - 2023-05-21 07:06:49 --> No URI present. Default controller set.
INFO - 2023-05-21 07:06:49 --> Router Class Initialized
INFO - 2023-05-21 07:06:49 --> Output Class Initialized
INFO - 2023-05-21 07:06:49 --> Security Class Initialized
DEBUG - 2023-05-21 07:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:06:49 --> Input Class Initialized
INFO - 2023-05-21 07:06:49 --> Language Class Initialized
INFO - 2023-05-21 07:06:49 --> Loader Class Initialized
INFO - 2023-05-21 07:06:49 --> Helper loaded: url_helper
INFO - 2023-05-21 07:06:49 --> Helper loaded: file_helper
INFO - 2023-05-21 07:06:49 --> Helper loaded: html_helper
INFO - 2023-05-21 07:06:49 --> Helper loaded: text_helper
INFO - 2023-05-21 07:06:49 --> Helper loaded: form_helper
INFO - 2023-05-21 07:06:49 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:06:49 --> Helper loaded: security_helper
INFO - 2023-05-21 07:06:49 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:06:49 --> Database Driver Class Initialized
INFO - 2023-05-21 07:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:06:49 --> Parser Class Initialized
INFO - 2023-05-21 07:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:06:49 --> Pagination Class Initialized
INFO - 2023-05-21 07:06:49 --> Form Validation Class Initialized
INFO - 2023-05-21 07:06:49 --> Controller Class Initialized
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
DEBUG - 2023-05-21 07:06:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 07:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
INFO - 2023-05-21 07:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-21 07:06:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 07:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 07:06:49 --> Model Class Initialized
INFO - 2023-05-21 07:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 07:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 07:06:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 07:06:49 --> Final output sent to browser
DEBUG - 2023-05-21 07:06:49 --> Total execution time: 0.1670
ERROR - 2023-05-21 07:08:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:08:47 --> Config Class Initialized
INFO - 2023-05-21 07:08:47 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:08:47 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:08:47 --> Utf8 Class Initialized
INFO - 2023-05-21 07:08:47 --> URI Class Initialized
INFO - 2023-05-21 07:08:47 --> Router Class Initialized
INFO - 2023-05-21 07:08:47 --> Output Class Initialized
INFO - 2023-05-21 07:08:47 --> Security Class Initialized
DEBUG - 2023-05-21 07:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:08:47 --> Input Class Initialized
INFO - 2023-05-21 07:08:47 --> Language Class Initialized
INFO - 2023-05-21 07:08:47 --> Loader Class Initialized
INFO - 2023-05-21 07:08:47 --> Helper loaded: url_helper
INFO - 2023-05-21 07:08:47 --> Helper loaded: file_helper
INFO - 2023-05-21 07:08:47 --> Helper loaded: html_helper
INFO - 2023-05-21 07:08:47 --> Helper loaded: text_helper
INFO - 2023-05-21 07:08:47 --> Helper loaded: form_helper
INFO - 2023-05-21 07:08:47 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:08:47 --> Helper loaded: security_helper
INFO - 2023-05-21 07:08:47 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:08:47 --> Database Driver Class Initialized
INFO - 2023-05-21 07:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:08:47 --> Parser Class Initialized
INFO - 2023-05-21 07:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:08:47 --> Pagination Class Initialized
INFO - 2023-05-21 07:08:47 --> Form Validation Class Initialized
INFO - 2023-05-21 07:08:47 --> Controller Class Initialized
INFO - 2023-05-21 07:08:47 --> Model Class Initialized
DEBUG - 2023-05-21 07:08:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 07:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:47 --> Model Class Initialized
DEBUG - 2023-05-21 07:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:47 --> Model Class Initialized
INFO - 2023-05-21 07:08:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-21 07:08:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 07:08:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 07:08:47 --> Model Class Initialized
INFO - 2023-05-21 07:08:47 --> Model Class Initialized
INFO - 2023-05-21 07:08:47 --> Model Class Initialized
INFO - 2023-05-21 07:08:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 07:08:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 07:08:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 07:08:47 --> Final output sent to browser
DEBUG - 2023-05-21 07:08:47 --> Total execution time: 0.1430
ERROR - 2023-05-21 07:08:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:08:48 --> Config Class Initialized
INFO - 2023-05-21 07:08:48 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:08:48 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:08:48 --> Utf8 Class Initialized
INFO - 2023-05-21 07:08:48 --> URI Class Initialized
INFO - 2023-05-21 07:08:48 --> Router Class Initialized
INFO - 2023-05-21 07:08:48 --> Output Class Initialized
INFO - 2023-05-21 07:08:48 --> Security Class Initialized
DEBUG - 2023-05-21 07:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:08:48 --> Input Class Initialized
INFO - 2023-05-21 07:08:48 --> Language Class Initialized
INFO - 2023-05-21 07:08:48 --> Loader Class Initialized
INFO - 2023-05-21 07:08:48 --> Helper loaded: url_helper
INFO - 2023-05-21 07:08:48 --> Helper loaded: file_helper
INFO - 2023-05-21 07:08:48 --> Helper loaded: html_helper
INFO - 2023-05-21 07:08:48 --> Helper loaded: text_helper
INFO - 2023-05-21 07:08:48 --> Helper loaded: form_helper
INFO - 2023-05-21 07:08:48 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:08:48 --> Helper loaded: security_helper
INFO - 2023-05-21 07:08:48 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:08:48 --> Database Driver Class Initialized
INFO - 2023-05-21 07:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:08:48 --> Parser Class Initialized
INFO - 2023-05-21 07:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:08:48 --> Pagination Class Initialized
INFO - 2023-05-21 07:08:48 --> Form Validation Class Initialized
INFO - 2023-05-21 07:08:48 --> Controller Class Initialized
INFO - 2023-05-21 07:08:48 --> Model Class Initialized
DEBUG - 2023-05-21 07:08:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 07:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:48 --> Model Class Initialized
DEBUG - 2023-05-21 07:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:48 --> Model Class Initialized
INFO - 2023-05-21 07:08:48 --> Final output sent to browser
DEBUG - 2023-05-21 07:08:48 --> Total execution time: 0.0530
ERROR - 2023-05-21 07:08:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 07:08:54 --> Config Class Initialized
INFO - 2023-05-21 07:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-21 07:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-21 07:08:54 --> Utf8 Class Initialized
INFO - 2023-05-21 07:08:54 --> URI Class Initialized
INFO - 2023-05-21 07:08:54 --> Router Class Initialized
INFO - 2023-05-21 07:08:54 --> Output Class Initialized
INFO - 2023-05-21 07:08:54 --> Security Class Initialized
DEBUG - 2023-05-21 07:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 07:08:54 --> Input Class Initialized
INFO - 2023-05-21 07:08:54 --> Language Class Initialized
INFO - 2023-05-21 07:08:54 --> Loader Class Initialized
INFO - 2023-05-21 07:08:54 --> Helper loaded: url_helper
INFO - 2023-05-21 07:08:54 --> Helper loaded: file_helper
INFO - 2023-05-21 07:08:54 --> Helper loaded: html_helper
INFO - 2023-05-21 07:08:54 --> Helper loaded: text_helper
INFO - 2023-05-21 07:08:54 --> Helper loaded: form_helper
INFO - 2023-05-21 07:08:54 --> Helper loaded: lang_helper
INFO - 2023-05-21 07:08:54 --> Helper loaded: security_helper
INFO - 2023-05-21 07:08:54 --> Helper loaded: cookie_helper
INFO - 2023-05-21 07:08:54 --> Database Driver Class Initialized
INFO - 2023-05-21 07:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 07:08:54 --> Parser Class Initialized
INFO - 2023-05-21 07:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 07:08:54 --> Pagination Class Initialized
INFO - 2023-05-21 07:08:54 --> Form Validation Class Initialized
INFO - 2023-05-21 07:08:54 --> Controller Class Initialized
INFO - 2023-05-21 07:08:54 --> Model Class Initialized
DEBUG - 2023-05-21 07:08:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 07:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:54 --> Model Class Initialized
DEBUG - 2023-05-21 07:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:54 --> Model Class Initialized
DEBUG - 2023-05-21 07:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-05-21 07:08:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 07:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 07:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 07:08:54 --> Model Class Initialized
INFO - 2023-05-21 07:08:54 --> Model Class Initialized
INFO - 2023-05-21 07:08:54 --> Model Class Initialized
INFO - 2023-05-21 07:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 07:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 07:08:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 07:08:54 --> Final output sent to browser
DEBUG - 2023-05-21 07:08:54 --> Total execution time: 0.1489
ERROR - 2023-05-21 08:06:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:06:14 --> Config Class Initialized
INFO - 2023-05-21 08:06:14 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:06:14 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:06:14 --> Utf8 Class Initialized
INFO - 2023-05-21 08:06:14 --> URI Class Initialized
DEBUG - 2023-05-21 08:06:14 --> No URI present. Default controller set.
INFO - 2023-05-21 08:06:14 --> Router Class Initialized
INFO - 2023-05-21 08:06:14 --> Output Class Initialized
INFO - 2023-05-21 08:06:14 --> Security Class Initialized
DEBUG - 2023-05-21 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:06:14 --> Input Class Initialized
INFO - 2023-05-21 08:06:14 --> Language Class Initialized
INFO - 2023-05-21 08:06:14 --> Loader Class Initialized
INFO - 2023-05-21 08:06:14 --> Helper loaded: url_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: file_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: html_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: text_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: form_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: security_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:06:14 --> Database Driver Class Initialized
INFO - 2023-05-21 08:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:06:14 --> Parser Class Initialized
INFO - 2023-05-21 08:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:06:14 --> Pagination Class Initialized
INFO - 2023-05-21 08:06:14 --> Form Validation Class Initialized
INFO - 2023-05-21 08:06:14 --> Controller Class Initialized
INFO - 2023-05-21 08:06:14 --> Model Class Initialized
DEBUG - 2023-05-21 08:06:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-21 08:06:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:06:14 --> Config Class Initialized
INFO - 2023-05-21 08:06:14 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:06:14 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:06:14 --> Utf8 Class Initialized
INFO - 2023-05-21 08:06:14 --> URI Class Initialized
INFO - 2023-05-21 08:06:14 --> Router Class Initialized
INFO - 2023-05-21 08:06:14 --> Output Class Initialized
INFO - 2023-05-21 08:06:14 --> Security Class Initialized
DEBUG - 2023-05-21 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:06:14 --> Input Class Initialized
INFO - 2023-05-21 08:06:14 --> Language Class Initialized
INFO - 2023-05-21 08:06:14 --> Loader Class Initialized
INFO - 2023-05-21 08:06:14 --> Helper loaded: url_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: file_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: html_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: text_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: form_helper
INFO - 2023-05-21 08:06:14 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:06:15 --> Helper loaded: security_helper
INFO - 2023-05-21 08:06:15 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:06:15 --> Database Driver Class Initialized
INFO - 2023-05-21 08:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:06:15 --> Parser Class Initialized
INFO - 2023-05-21 08:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:06:15 --> Pagination Class Initialized
INFO - 2023-05-21 08:06:15 --> Form Validation Class Initialized
INFO - 2023-05-21 08:06:15 --> Controller Class Initialized
INFO - 2023-05-21 08:06:15 --> Model Class Initialized
DEBUG - 2023-05-21 08:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:06:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 08:06:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:06:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:06:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:06:15 --> Model Class Initialized
INFO - 2023-05-21 08:06:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:06:15 --> Final output sent to browser
DEBUG - 2023-05-21 08:06:15 --> Total execution time: 0.0309
ERROR - 2023-05-21 08:06:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:06:21 --> Config Class Initialized
INFO - 2023-05-21 08:06:21 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:06:21 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:06:21 --> Utf8 Class Initialized
INFO - 2023-05-21 08:06:21 --> URI Class Initialized
INFO - 2023-05-21 08:06:21 --> Router Class Initialized
INFO - 2023-05-21 08:06:21 --> Output Class Initialized
INFO - 2023-05-21 08:06:21 --> Security Class Initialized
DEBUG - 2023-05-21 08:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:06:21 --> Input Class Initialized
INFO - 2023-05-21 08:06:21 --> Language Class Initialized
INFO - 2023-05-21 08:06:21 --> Loader Class Initialized
INFO - 2023-05-21 08:06:21 --> Helper loaded: url_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: file_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: html_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: text_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: form_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: security_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:06:21 --> Database Driver Class Initialized
INFO - 2023-05-21 08:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:06:21 --> Parser Class Initialized
INFO - 2023-05-21 08:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:06:21 --> Pagination Class Initialized
INFO - 2023-05-21 08:06:21 --> Form Validation Class Initialized
INFO - 2023-05-21 08:06:21 --> Controller Class Initialized
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
DEBUG - 2023-05-21 08:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
INFO - 2023-05-21 08:06:21 --> Final output sent to browser
DEBUG - 2023-05-21 08:06:21 --> Total execution time: 0.0174
ERROR - 2023-05-21 08:06:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:06:21 --> Config Class Initialized
INFO - 2023-05-21 08:06:21 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:06:21 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:06:21 --> Utf8 Class Initialized
INFO - 2023-05-21 08:06:21 --> URI Class Initialized
DEBUG - 2023-05-21 08:06:21 --> No URI present. Default controller set.
INFO - 2023-05-21 08:06:21 --> Router Class Initialized
INFO - 2023-05-21 08:06:21 --> Output Class Initialized
INFO - 2023-05-21 08:06:21 --> Security Class Initialized
DEBUG - 2023-05-21 08:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:06:21 --> Input Class Initialized
INFO - 2023-05-21 08:06:21 --> Language Class Initialized
INFO - 2023-05-21 08:06:21 --> Loader Class Initialized
INFO - 2023-05-21 08:06:21 --> Helper loaded: url_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: file_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: html_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: text_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: form_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: security_helper
INFO - 2023-05-21 08:06:21 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:06:21 --> Database Driver Class Initialized
INFO - 2023-05-21 08:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:06:21 --> Parser Class Initialized
INFO - 2023-05-21 08:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:06:21 --> Pagination Class Initialized
INFO - 2023-05-21 08:06:21 --> Form Validation Class Initialized
INFO - 2023-05-21 08:06:21 --> Controller Class Initialized
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
DEBUG - 2023-05-21 08:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
DEBUG - 2023-05-21 08:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
DEBUG - 2023-05-21 08:06:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 08:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
INFO - 2023-05-21 08:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-21 08:06:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:06:21 --> Model Class Initialized
INFO - 2023-05-21 08:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 08:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 08:06:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:06:21 --> Final output sent to browser
DEBUG - 2023-05-21 08:06:21 --> Total execution time: 0.0595
ERROR - 2023-05-21 08:07:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:07:04 --> Config Class Initialized
INFO - 2023-05-21 08:07:04 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:07:04 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:07:04 --> Utf8 Class Initialized
INFO - 2023-05-21 08:07:04 --> URI Class Initialized
INFO - 2023-05-21 08:07:04 --> Router Class Initialized
INFO - 2023-05-21 08:07:04 --> Output Class Initialized
INFO - 2023-05-21 08:07:04 --> Security Class Initialized
DEBUG - 2023-05-21 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:07:04 --> Input Class Initialized
INFO - 2023-05-21 08:07:04 --> Language Class Initialized
INFO - 2023-05-21 08:07:04 --> Loader Class Initialized
INFO - 2023-05-21 08:07:04 --> Helper loaded: url_helper
INFO - 2023-05-21 08:07:04 --> Helper loaded: file_helper
INFO - 2023-05-21 08:07:04 --> Helper loaded: html_helper
INFO - 2023-05-21 08:07:04 --> Helper loaded: text_helper
INFO - 2023-05-21 08:07:04 --> Helper loaded: form_helper
INFO - 2023-05-21 08:07:04 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:07:04 --> Helper loaded: security_helper
INFO - 2023-05-21 08:07:04 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:07:04 --> Database Driver Class Initialized
INFO - 2023-05-21 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:07:04 --> Parser Class Initialized
INFO - 2023-05-21 08:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:07:04 --> Pagination Class Initialized
INFO - 2023-05-21 08:07:04 --> Form Validation Class Initialized
INFO - 2023-05-21 08:07:04 --> Controller Class Initialized
INFO - 2023-05-21 08:07:04 --> Model Class Initialized
INFO - 2023-05-21 08:07:04 --> Model Class Initialized
INFO - 2023-05-21 08:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-05-21 08:07:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:07:04 --> Model Class Initialized
INFO - 2023-05-21 08:07:04 --> Model Class Initialized
INFO - 2023-05-21 08:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 08:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 08:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:07:04 --> Final output sent to browser
DEBUG - 2023-05-21 08:07:04 --> Total execution time: 0.0559
ERROR - 2023-05-21 08:07:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:07:05 --> Config Class Initialized
INFO - 2023-05-21 08:07:05 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:07:05 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:07:05 --> Utf8 Class Initialized
INFO - 2023-05-21 08:07:05 --> URI Class Initialized
INFO - 2023-05-21 08:07:05 --> Router Class Initialized
INFO - 2023-05-21 08:07:05 --> Output Class Initialized
INFO - 2023-05-21 08:07:05 --> Security Class Initialized
DEBUG - 2023-05-21 08:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:07:05 --> Input Class Initialized
INFO - 2023-05-21 08:07:05 --> Language Class Initialized
INFO - 2023-05-21 08:07:05 --> Loader Class Initialized
INFO - 2023-05-21 08:07:05 --> Helper loaded: url_helper
INFO - 2023-05-21 08:07:05 --> Helper loaded: file_helper
INFO - 2023-05-21 08:07:05 --> Helper loaded: html_helper
INFO - 2023-05-21 08:07:05 --> Helper loaded: text_helper
INFO - 2023-05-21 08:07:05 --> Helper loaded: form_helper
INFO - 2023-05-21 08:07:05 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:07:05 --> Helper loaded: security_helper
INFO - 2023-05-21 08:07:05 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:07:05 --> Database Driver Class Initialized
INFO - 2023-05-21 08:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:07:05 --> Parser Class Initialized
INFO - 2023-05-21 08:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:07:05 --> Pagination Class Initialized
INFO - 2023-05-21 08:07:05 --> Form Validation Class Initialized
INFO - 2023-05-21 08:07:05 --> Controller Class Initialized
INFO - 2023-05-21 08:07:05 --> Model Class Initialized
INFO - 2023-05-21 08:07:05 --> Model Class Initialized
INFO - 2023-05-21 08:07:05 --> Final output sent to browser
DEBUG - 2023-05-21 08:07:05 --> Total execution time: 0.0209
ERROR - 2023-05-21 08:27:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:27:40 --> Config Class Initialized
INFO - 2023-05-21 08:27:40 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:27:40 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:27:40 --> Utf8 Class Initialized
INFO - 2023-05-21 08:27:40 --> URI Class Initialized
DEBUG - 2023-05-21 08:27:40 --> No URI present. Default controller set.
INFO - 2023-05-21 08:27:40 --> Router Class Initialized
INFO - 2023-05-21 08:27:40 --> Output Class Initialized
INFO - 2023-05-21 08:27:40 --> Security Class Initialized
DEBUG - 2023-05-21 08:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:27:40 --> Input Class Initialized
INFO - 2023-05-21 08:27:40 --> Language Class Initialized
INFO - 2023-05-21 08:27:40 --> Loader Class Initialized
INFO - 2023-05-21 08:27:40 --> Helper loaded: url_helper
INFO - 2023-05-21 08:27:40 --> Helper loaded: file_helper
INFO - 2023-05-21 08:27:40 --> Helper loaded: html_helper
INFO - 2023-05-21 08:27:40 --> Helper loaded: text_helper
INFO - 2023-05-21 08:27:40 --> Helper loaded: form_helper
INFO - 2023-05-21 08:27:40 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:27:40 --> Helper loaded: security_helper
INFO - 2023-05-21 08:27:40 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:27:40 --> Database Driver Class Initialized
INFO - 2023-05-21 08:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:27:40 --> Parser Class Initialized
INFO - 2023-05-21 08:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:27:40 --> Pagination Class Initialized
INFO - 2023-05-21 08:27:40 --> Form Validation Class Initialized
INFO - 2023-05-21 08:27:40 --> Controller Class Initialized
INFO - 2023-05-21 08:27:40 --> Model Class Initialized
DEBUG - 2023-05-21 08:27:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-21 08:27:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:27:42 --> Config Class Initialized
INFO - 2023-05-21 08:27:42 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:27:42 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:27:42 --> Utf8 Class Initialized
INFO - 2023-05-21 08:27:42 --> URI Class Initialized
INFO - 2023-05-21 08:27:42 --> Router Class Initialized
INFO - 2023-05-21 08:27:42 --> Output Class Initialized
INFO - 2023-05-21 08:27:42 --> Security Class Initialized
DEBUG - 2023-05-21 08:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:27:42 --> Input Class Initialized
INFO - 2023-05-21 08:27:42 --> Language Class Initialized
INFO - 2023-05-21 08:27:42 --> Loader Class Initialized
INFO - 2023-05-21 08:27:42 --> Helper loaded: url_helper
INFO - 2023-05-21 08:27:42 --> Helper loaded: file_helper
INFO - 2023-05-21 08:27:42 --> Helper loaded: html_helper
INFO - 2023-05-21 08:27:42 --> Helper loaded: text_helper
INFO - 2023-05-21 08:27:42 --> Helper loaded: form_helper
INFO - 2023-05-21 08:27:42 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:27:42 --> Helper loaded: security_helper
INFO - 2023-05-21 08:27:42 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:27:42 --> Database Driver Class Initialized
INFO - 2023-05-21 08:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:27:42 --> Parser Class Initialized
INFO - 2023-05-21 08:27:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:27:42 --> Pagination Class Initialized
INFO - 2023-05-21 08:27:42 --> Form Validation Class Initialized
INFO - 2023-05-21 08:27:42 --> Controller Class Initialized
INFO - 2023-05-21 08:27:42 --> Model Class Initialized
DEBUG - 2023-05-21 08:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 08:27:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:27:42 --> Model Class Initialized
INFO - 2023-05-21 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:27:42 --> Final output sent to browser
DEBUG - 2023-05-21 08:27:42 --> Total execution time: 0.0312
ERROR - 2023-05-21 08:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:40:09 --> Config Class Initialized
INFO - 2023-05-21 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:40:09 --> Utf8 Class Initialized
INFO - 2023-05-21 08:40:09 --> URI Class Initialized
INFO - 2023-05-21 08:40:09 --> Router Class Initialized
INFO - 2023-05-21 08:40:09 --> Output Class Initialized
INFO - 2023-05-21 08:40:09 --> Security Class Initialized
DEBUG - 2023-05-21 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:40:09 --> Input Class Initialized
INFO - 2023-05-21 08:40:09 --> Language Class Initialized
INFO - 2023-05-21 08:40:09 --> Loader Class Initialized
INFO - 2023-05-21 08:40:09 --> Helper loaded: url_helper
INFO - 2023-05-21 08:40:09 --> Helper loaded: file_helper
INFO - 2023-05-21 08:40:09 --> Helper loaded: html_helper
INFO - 2023-05-21 08:40:09 --> Helper loaded: text_helper
INFO - 2023-05-21 08:40:09 --> Helper loaded: form_helper
INFO - 2023-05-21 08:40:09 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:40:09 --> Helper loaded: security_helper
INFO - 2023-05-21 08:40:09 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:40:09 --> Database Driver Class Initialized
INFO - 2023-05-21 08:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:40:09 --> Parser Class Initialized
INFO - 2023-05-21 08:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:40:09 --> Pagination Class Initialized
INFO - 2023-05-21 08:40:09 --> Form Validation Class Initialized
INFO - 2023-05-21 08:40:09 --> Controller Class Initialized
INFO - 2023-05-21 08:40:09 --> Model Class Initialized
DEBUG - 2023-05-21 08:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 08:40:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:40:09 --> Model Class Initialized
INFO - 2023-05-21 08:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:40:09 --> Final output sent to browser
DEBUG - 2023-05-21 08:40:09 --> Total execution time: 0.0307
ERROR - 2023-05-21 08:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:48:08 --> Config Class Initialized
INFO - 2023-05-21 08:48:08 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:48:08 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:48:08 --> Utf8 Class Initialized
INFO - 2023-05-21 08:48:08 --> URI Class Initialized
DEBUG - 2023-05-21 08:48:08 --> No URI present. Default controller set.
INFO - 2023-05-21 08:48:08 --> Router Class Initialized
INFO - 2023-05-21 08:48:08 --> Output Class Initialized
INFO - 2023-05-21 08:48:08 --> Security Class Initialized
DEBUG - 2023-05-21 08:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:48:08 --> Input Class Initialized
INFO - 2023-05-21 08:48:08 --> Language Class Initialized
INFO - 2023-05-21 08:48:08 --> Loader Class Initialized
INFO - 2023-05-21 08:48:08 --> Helper loaded: url_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: file_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: html_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: text_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: form_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: security_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:48:08 --> Database Driver Class Initialized
INFO - 2023-05-21 08:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:48:08 --> Parser Class Initialized
INFO - 2023-05-21 08:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:48:08 --> Pagination Class Initialized
INFO - 2023-05-21 08:48:08 --> Form Validation Class Initialized
INFO - 2023-05-21 08:48:08 --> Controller Class Initialized
INFO - 2023-05-21 08:48:08 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-21 08:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:48:08 --> Config Class Initialized
INFO - 2023-05-21 08:48:08 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:48:08 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:48:08 --> Utf8 Class Initialized
INFO - 2023-05-21 08:48:08 --> URI Class Initialized
INFO - 2023-05-21 08:48:08 --> Router Class Initialized
INFO - 2023-05-21 08:48:08 --> Output Class Initialized
INFO - 2023-05-21 08:48:08 --> Security Class Initialized
DEBUG - 2023-05-21 08:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:48:08 --> Input Class Initialized
INFO - 2023-05-21 08:48:08 --> Language Class Initialized
INFO - 2023-05-21 08:48:08 --> Loader Class Initialized
INFO - 2023-05-21 08:48:08 --> Helper loaded: url_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: file_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: html_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: text_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: form_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: security_helper
INFO - 2023-05-21 08:48:08 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:48:08 --> Database Driver Class Initialized
INFO - 2023-05-21 08:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:48:08 --> Parser Class Initialized
INFO - 2023-05-21 08:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:48:08 --> Pagination Class Initialized
INFO - 2023-05-21 08:48:08 --> Form Validation Class Initialized
INFO - 2023-05-21 08:48:08 --> Controller Class Initialized
INFO - 2023-05-21 08:48:08 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 08:48:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:48:08 --> Model Class Initialized
INFO - 2023-05-21 08:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:48:08 --> Final output sent to browser
DEBUG - 2023-05-21 08:48:08 --> Total execution time: 0.0345
ERROR - 2023-05-21 08:48:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:48:12 --> Config Class Initialized
INFO - 2023-05-21 08:48:12 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:48:12 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:48:12 --> Utf8 Class Initialized
INFO - 2023-05-21 08:48:12 --> URI Class Initialized
INFO - 2023-05-21 08:48:12 --> Router Class Initialized
INFO - 2023-05-21 08:48:12 --> Output Class Initialized
INFO - 2023-05-21 08:48:12 --> Security Class Initialized
DEBUG - 2023-05-21 08:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:48:12 --> Input Class Initialized
INFO - 2023-05-21 08:48:12 --> Language Class Initialized
INFO - 2023-05-21 08:48:12 --> Loader Class Initialized
INFO - 2023-05-21 08:48:12 --> Helper loaded: url_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: file_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: html_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: text_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: form_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: security_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:48:12 --> Database Driver Class Initialized
INFO - 2023-05-21 08:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:48:12 --> Parser Class Initialized
INFO - 2023-05-21 08:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:48:12 --> Pagination Class Initialized
INFO - 2023-05-21 08:48:12 --> Form Validation Class Initialized
INFO - 2023-05-21 08:48:12 --> Controller Class Initialized
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
INFO - 2023-05-21 08:48:12 --> Final output sent to browser
DEBUG - 2023-05-21 08:48:12 --> Total execution time: 0.0167
ERROR - 2023-05-21 08:48:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:48:12 --> Config Class Initialized
INFO - 2023-05-21 08:48:12 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:48:12 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:48:12 --> Utf8 Class Initialized
INFO - 2023-05-21 08:48:12 --> URI Class Initialized
DEBUG - 2023-05-21 08:48:12 --> No URI present. Default controller set.
INFO - 2023-05-21 08:48:12 --> Router Class Initialized
INFO - 2023-05-21 08:48:12 --> Output Class Initialized
INFO - 2023-05-21 08:48:12 --> Security Class Initialized
DEBUG - 2023-05-21 08:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:48:12 --> Input Class Initialized
INFO - 2023-05-21 08:48:12 --> Language Class Initialized
INFO - 2023-05-21 08:48:12 --> Loader Class Initialized
INFO - 2023-05-21 08:48:12 --> Helper loaded: url_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: file_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: html_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: text_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: form_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: security_helper
INFO - 2023-05-21 08:48:12 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:48:12 --> Database Driver Class Initialized
INFO - 2023-05-21 08:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:48:12 --> Parser Class Initialized
INFO - 2023-05-21 08:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:48:12 --> Pagination Class Initialized
INFO - 2023-05-21 08:48:12 --> Form Validation Class Initialized
INFO - 2023-05-21 08:48:12 --> Controller Class Initialized
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 08:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
INFO - 2023-05-21 08:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-21 08:48:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:48:12 --> Model Class Initialized
INFO - 2023-05-21 08:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 08:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 08:48:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:48:12 --> Final output sent to browser
DEBUG - 2023-05-21 08:48:12 --> Total execution time: 0.1728
ERROR - 2023-05-21 08:48:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:48:13 --> Config Class Initialized
INFO - 2023-05-21 08:48:13 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:48:13 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:48:13 --> Utf8 Class Initialized
INFO - 2023-05-21 08:48:13 --> URI Class Initialized
INFO - 2023-05-21 08:48:13 --> Router Class Initialized
INFO - 2023-05-21 08:48:13 --> Output Class Initialized
INFO - 2023-05-21 08:48:13 --> Security Class Initialized
DEBUG - 2023-05-21 08:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:48:13 --> Input Class Initialized
INFO - 2023-05-21 08:48:13 --> Language Class Initialized
INFO - 2023-05-21 08:48:13 --> Loader Class Initialized
INFO - 2023-05-21 08:48:13 --> Helper loaded: url_helper
INFO - 2023-05-21 08:48:13 --> Helper loaded: file_helper
INFO - 2023-05-21 08:48:13 --> Helper loaded: html_helper
INFO - 2023-05-21 08:48:13 --> Helper loaded: text_helper
INFO - 2023-05-21 08:48:13 --> Helper loaded: form_helper
INFO - 2023-05-21 08:48:13 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:48:13 --> Helper loaded: security_helper
INFO - 2023-05-21 08:48:13 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:48:13 --> Database Driver Class Initialized
INFO - 2023-05-21 08:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:48:13 --> Parser Class Initialized
INFO - 2023-05-21 08:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:48:13 --> Pagination Class Initialized
INFO - 2023-05-21 08:48:13 --> Form Validation Class Initialized
INFO - 2023-05-21 08:48:13 --> Controller Class Initialized
DEBUG - 2023-05-21 08:48:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 08:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:13 --> Model Class Initialized
INFO - 2023-05-21 08:48:13 --> Final output sent to browser
DEBUG - 2023-05-21 08:48:13 --> Total execution time: 0.0130
ERROR - 2023-05-21 08:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 08:48:27 --> Config Class Initialized
INFO - 2023-05-21 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-05-21 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-05-21 08:48:27 --> Utf8 Class Initialized
INFO - 2023-05-21 08:48:27 --> URI Class Initialized
DEBUG - 2023-05-21 08:48:27 --> No URI present. Default controller set.
INFO - 2023-05-21 08:48:27 --> Router Class Initialized
INFO - 2023-05-21 08:48:27 --> Output Class Initialized
INFO - 2023-05-21 08:48:27 --> Security Class Initialized
DEBUG - 2023-05-21 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 08:48:27 --> Input Class Initialized
INFO - 2023-05-21 08:48:27 --> Language Class Initialized
INFO - 2023-05-21 08:48:27 --> Loader Class Initialized
INFO - 2023-05-21 08:48:27 --> Helper loaded: url_helper
INFO - 2023-05-21 08:48:27 --> Helper loaded: file_helper
INFO - 2023-05-21 08:48:27 --> Helper loaded: html_helper
INFO - 2023-05-21 08:48:27 --> Helper loaded: text_helper
INFO - 2023-05-21 08:48:27 --> Helper loaded: form_helper
INFO - 2023-05-21 08:48:27 --> Helper loaded: lang_helper
INFO - 2023-05-21 08:48:27 --> Helper loaded: security_helper
INFO - 2023-05-21 08:48:27 --> Helper loaded: cookie_helper
INFO - 2023-05-21 08:48:27 --> Database Driver Class Initialized
INFO - 2023-05-21 08:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 08:48:27 --> Parser Class Initialized
INFO - 2023-05-21 08:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 08:48:27 --> Pagination Class Initialized
INFO - 2023-05-21 08:48:27 --> Form Validation Class Initialized
INFO - 2023-05-21 08:48:27 --> Controller Class Initialized
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
DEBUG - 2023-05-21 08:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
INFO - 2023-05-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-21 08:48:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 08:48:27 --> Model Class Initialized
INFO - 2023-05-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 08:48:27 --> Final output sent to browser
DEBUG - 2023-05-21 08:48:27 --> Total execution time: 0.1909
ERROR - 2023-05-21 16:45:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 16:45:36 --> Config Class Initialized
INFO - 2023-05-21 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-05-21 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-05-21 16:45:36 --> Utf8 Class Initialized
INFO - 2023-05-21 16:45:36 --> URI Class Initialized
DEBUG - 2023-05-21 16:45:36 --> No URI present. Default controller set.
INFO - 2023-05-21 16:45:36 --> Router Class Initialized
INFO - 2023-05-21 16:45:36 --> Output Class Initialized
INFO - 2023-05-21 16:45:36 --> Security Class Initialized
DEBUG - 2023-05-21 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 16:45:36 --> Input Class Initialized
INFO - 2023-05-21 16:45:36 --> Language Class Initialized
INFO - 2023-05-21 16:45:36 --> Loader Class Initialized
INFO - 2023-05-21 16:45:36 --> Helper loaded: url_helper
INFO - 2023-05-21 16:45:36 --> Helper loaded: file_helper
INFO - 2023-05-21 16:45:36 --> Helper loaded: html_helper
INFO - 2023-05-21 16:45:36 --> Helper loaded: text_helper
INFO - 2023-05-21 16:45:36 --> Helper loaded: form_helper
INFO - 2023-05-21 16:45:36 --> Helper loaded: lang_helper
INFO - 2023-05-21 16:45:36 --> Helper loaded: security_helper
INFO - 2023-05-21 16:45:36 --> Helper loaded: cookie_helper
INFO - 2023-05-21 16:45:36 --> Database Driver Class Initialized
INFO - 2023-05-21 16:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 16:45:36 --> Parser Class Initialized
INFO - 2023-05-21 16:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 16:45:36 --> Pagination Class Initialized
INFO - 2023-05-21 16:45:36 --> Form Validation Class Initialized
INFO - 2023-05-21 16:45:36 --> Controller Class Initialized
INFO - 2023-05-21 16:45:36 --> Model Class Initialized
DEBUG - 2023-05-21 16:45:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-21 16:45:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 16:45:38 --> Config Class Initialized
INFO - 2023-05-21 16:45:38 --> Hooks Class Initialized
DEBUG - 2023-05-21 16:45:38 --> UTF-8 Support Enabled
INFO - 2023-05-21 16:45:38 --> Utf8 Class Initialized
INFO - 2023-05-21 16:45:38 --> URI Class Initialized
INFO - 2023-05-21 16:45:38 --> Router Class Initialized
INFO - 2023-05-21 16:45:38 --> Output Class Initialized
INFO - 2023-05-21 16:45:38 --> Security Class Initialized
DEBUG - 2023-05-21 16:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 16:45:38 --> Input Class Initialized
INFO - 2023-05-21 16:45:38 --> Language Class Initialized
INFO - 2023-05-21 16:45:38 --> Loader Class Initialized
INFO - 2023-05-21 16:45:38 --> Helper loaded: url_helper
INFO - 2023-05-21 16:45:38 --> Helper loaded: file_helper
INFO - 2023-05-21 16:45:38 --> Helper loaded: html_helper
INFO - 2023-05-21 16:45:38 --> Helper loaded: text_helper
INFO - 2023-05-21 16:45:38 --> Helper loaded: form_helper
INFO - 2023-05-21 16:45:38 --> Helper loaded: lang_helper
INFO - 2023-05-21 16:45:38 --> Helper loaded: security_helper
INFO - 2023-05-21 16:45:38 --> Helper loaded: cookie_helper
INFO - 2023-05-21 16:45:38 --> Database Driver Class Initialized
INFO - 2023-05-21 16:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 16:45:38 --> Parser Class Initialized
INFO - 2023-05-21 16:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 16:45:38 --> Pagination Class Initialized
INFO - 2023-05-21 16:45:38 --> Form Validation Class Initialized
INFO - 2023-05-21 16:45:38 --> Controller Class Initialized
INFO - 2023-05-21 16:45:38 --> Model Class Initialized
DEBUG - 2023-05-21 16:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-21 16:45:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 16:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 16:45:38 --> Model Class Initialized
INFO - 2023-05-21 16:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 16:45:38 --> Final output sent to browser
DEBUG - 2023-05-21 16:45:38 --> Total execution time: 0.0318
ERROR - 2023-05-21 16:45:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 16:45:42 --> Config Class Initialized
INFO - 2023-05-21 16:45:42 --> Hooks Class Initialized
DEBUG - 2023-05-21 16:45:42 --> UTF-8 Support Enabled
INFO - 2023-05-21 16:45:42 --> Utf8 Class Initialized
INFO - 2023-05-21 16:45:42 --> URI Class Initialized
INFO - 2023-05-21 16:45:42 --> Router Class Initialized
INFO - 2023-05-21 16:45:42 --> Output Class Initialized
INFO - 2023-05-21 16:45:42 --> Security Class Initialized
DEBUG - 2023-05-21 16:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 16:45:42 --> Input Class Initialized
INFO - 2023-05-21 16:45:42 --> Language Class Initialized
INFO - 2023-05-21 16:45:42 --> Loader Class Initialized
INFO - 2023-05-21 16:45:42 --> Helper loaded: url_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: file_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: html_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: text_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: form_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: lang_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: security_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: cookie_helper
INFO - 2023-05-21 16:45:42 --> Database Driver Class Initialized
INFO - 2023-05-21 16:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 16:45:42 --> Parser Class Initialized
INFO - 2023-05-21 16:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 16:45:42 --> Pagination Class Initialized
INFO - 2023-05-21 16:45:42 --> Form Validation Class Initialized
INFO - 2023-05-21 16:45:42 --> Controller Class Initialized
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
DEBUG - 2023-05-21 16:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
INFO - 2023-05-21 16:45:42 --> Final output sent to browser
DEBUG - 2023-05-21 16:45:42 --> Total execution time: 0.0171
ERROR - 2023-05-21 16:45:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 16:45:42 --> Config Class Initialized
INFO - 2023-05-21 16:45:42 --> Hooks Class Initialized
DEBUG - 2023-05-21 16:45:42 --> UTF-8 Support Enabled
INFO - 2023-05-21 16:45:42 --> Utf8 Class Initialized
INFO - 2023-05-21 16:45:42 --> URI Class Initialized
DEBUG - 2023-05-21 16:45:42 --> No URI present. Default controller set.
INFO - 2023-05-21 16:45:42 --> Router Class Initialized
INFO - 2023-05-21 16:45:42 --> Output Class Initialized
INFO - 2023-05-21 16:45:42 --> Security Class Initialized
DEBUG - 2023-05-21 16:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 16:45:42 --> Input Class Initialized
INFO - 2023-05-21 16:45:42 --> Language Class Initialized
INFO - 2023-05-21 16:45:42 --> Loader Class Initialized
INFO - 2023-05-21 16:45:42 --> Helper loaded: url_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: file_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: html_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: text_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: form_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: lang_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: security_helper
INFO - 2023-05-21 16:45:42 --> Helper loaded: cookie_helper
INFO - 2023-05-21 16:45:42 --> Database Driver Class Initialized
INFO - 2023-05-21 16:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 16:45:42 --> Parser Class Initialized
INFO - 2023-05-21 16:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 16:45:42 --> Pagination Class Initialized
INFO - 2023-05-21 16:45:42 --> Form Validation Class Initialized
INFO - 2023-05-21 16:45:42 --> Controller Class Initialized
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
DEBUG - 2023-05-21 16:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
DEBUG - 2023-05-21 16:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
DEBUG - 2023-05-21 16:45:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 16:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
INFO - 2023-05-21 16:45:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-21 16:45:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-21 16:45:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-21 16:45:42 --> Model Class Initialized
INFO - 2023-05-21 16:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-21 16:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-21 16:45:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-21 16:45:43 --> Final output sent to browser
DEBUG - 2023-05-21 16:45:43 --> Total execution time: 0.1742
ERROR - 2023-05-21 16:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-21 16:45:44 --> Config Class Initialized
INFO - 2023-05-21 16:45:44 --> Hooks Class Initialized
DEBUG - 2023-05-21 16:45:44 --> UTF-8 Support Enabled
INFO - 2023-05-21 16:45:44 --> Utf8 Class Initialized
INFO - 2023-05-21 16:45:44 --> URI Class Initialized
INFO - 2023-05-21 16:45:44 --> Router Class Initialized
INFO - 2023-05-21 16:45:44 --> Output Class Initialized
INFO - 2023-05-21 16:45:44 --> Security Class Initialized
DEBUG - 2023-05-21 16:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-21 16:45:44 --> Input Class Initialized
INFO - 2023-05-21 16:45:44 --> Language Class Initialized
INFO - 2023-05-21 16:45:44 --> Loader Class Initialized
INFO - 2023-05-21 16:45:44 --> Helper loaded: url_helper
INFO - 2023-05-21 16:45:44 --> Helper loaded: file_helper
INFO - 2023-05-21 16:45:44 --> Helper loaded: html_helper
INFO - 2023-05-21 16:45:44 --> Helper loaded: text_helper
INFO - 2023-05-21 16:45:44 --> Helper loaded: form_helper
INFO - 2023-05-21 16:45:44 --> Helper loaded: lang_helper
INFO - 2023-05-21 16:45:44 --> Helper loaded: security_helper
INFO - 2023-05-21 16:45:44 --> Helper loaded: cookie_helper
INFO - 2023-05-21 16:45:44 --> Database Driver Class Initialized
INFO - 2023-05-21 16:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-21 16:45:44 --> Parser Class Initialized
INFO - 2023-05-21 16:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-21 16:45:44 --> Pagination Class Initialized
INFO - 2023-05-21 16:45:44 --> Form Validation Class Initialized
INFO - 2023-05-21 16:45:44 --> Controller Class Initialized
DEBUG - 2023-05-21 16:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-21 16:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-21 16:45:44 --> Model Class Initialized
INFO - 2023-05-21 16:45:44 --> Final output sent to browser
DEBUG - 2023-05-21 16:45:44 --> Total execution time: 0.0129
