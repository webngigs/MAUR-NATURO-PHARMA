<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-27 03:02:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 03:02:20 --> Config Class Initialized
INFO - 2024-01-27 03:02:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 03:02:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 03:02:20 --> Utf8 Class Initialized
INFO - 2024-01-27 03:02:20 --> URI Class Initialized
INFO - 2024-01-27 03:02:20 --> Router Class Initialized
INFO - 2024-01-27 03:02:20 --> Output Class Initialized
INFO - 2024-01-27 03:02:20 --> Security Class Initialized
DEBUG - 2024-01-27 03:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 03:02:20 --> Input Class Initialized
INFO - 2024-01-27 03:02:20 --> Language Class Initialized
ERROR - 2024-01-27 03:02:20 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-27 03:33:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 03:33:07 --> Config Class Initialized
INFO - 2024-01-27 03:33:07 --> Hooks Class Initialized
DEBUG - 2024-01-27 03:33:07 --> UTF-8 Support Enabled
INFO - 2024-01-27 03:33:07 --> Utf8 Class Initialized
INFO - 2024-01-27 03:33:07 --> URI Class Initialized
DEBUG - 2024-01-27 03:33:07 --> No URI present. Default controller set.
INFO - 2024-01-27 03:33:07 --> Router Class Initialized
INFO - 2024-01-27 03:33:07 --> Output Class Initialized
INFO - 2024-01-27 03:33:07 --> Security Class Initialized
DEBUG - 2024-01-27 03:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 03:33:07 --> Input Class Initialized
INFO - 2024-01-27 03:33:07 --> Language Class Initialized
INFO - 2024-01-27 03:33:07 --> Loader Class Initialized
INFO - 2024-01-27 03:33:07 --> Helper loaded: url_helper
INFO - 2024-01-27 03:33:07 --> Helper loaded: file_helper
INFO - 2024-01-27 03:33:07 --> Helper loaded: html_helper
INFO - 2024-01-27 03:33:07 --> Helper loaded: text_helper
INFO - 2024-01-27 03:33:07 --> Helper loaded: form_helper
INFO - 2024-01-27 03:33:07 --> Helper loaded: lang_helper
INFO - 2024-01-27 03:33:07 --> Helper loaded: security_helper
INFO - 2024-01-27 03:33:07 --> Helper loaded: cookie_helper
INFO - 2024-01-27 03:33:07 --> Database Driver Class Initialized
INFO - 2024-01-27 03:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 03:33:07 --> Parser Class Initialized
INFO - 2024-01-27 03:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 03:33:07 --> Pagination Class Initialized
INFO - 2024-01-27 03:33:07 --> Form Validation Class Initialized
INFO - 2024-01-27 03:33:07 --> Controller Class Initialized
INFO - 2024-01-27 03:33:07 --> Model Class Initialized
DEBUG - 2024-01-27 03:33:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 03:33:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 03:33:08 --> Config Class Initialized
INFO - 2024-01-27 03:33:08 --> Hooks Class Initialized
DEBUG - 2024-01-27 03:33:08 --> UTF-8 Support Enabled
INFO - 2024-01-27 03:33:08 --> Utf8 Class Initialized
INFO - 2024-01-27 03:33:08 --> URI Class Initialized
INFO - 2024-01-27 03:33:08 --> Router Class Initialized
INFO - 2024-01-27 03:33:08 --> Output Class Initialized
INFO - 2024-01-27 03:33:08 --> Security Class Initialized
DEBUG - 2024-01-27 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 03:33:08 --> Input Class Initialized
INFO - 2024-01-27 03:33:08 --> Language Class Initialized
INFO - 2024-01-27 03:33:08 --> Loader Class Initialized
INFO - 2024-01-27 03:33:08 --> Helper loaded: url_helper
INFO - 2024-01-27 03:33:08 --> Helper loaded: file_helper
INFO - 2024-01-27 03:33:08 --> Helper loaded: html_helper
INFO - 2024-01-27 03:33:08 --> Helper loaded: text_helper
INFO - 2024-01-27 03:33:08 --> Helper loaded: form_helper
INFO - 2024-01-27 03:33:08 --> Helper loaded: lang_helper
INFO - 2024-01-27 03:33:08 --> Helper loaded: security_helper
INFO - 2024-01-27 03:33:08 --> Helper loaded: cookie_helper
INFO - 2024-01-27 03:33:08 --> Database Driver Class Initialized
INFO - 2024-01-27 03:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 03:33:08 --> Parser Class Initialized
INFO - 2024-01-27 03:33:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 03:33:08 --> Pagination Class Initialized
INFO - 2024-01-27 03:33:08 --> Form Validation Class Initialized
INFO - 2024-01-27 03:33:08 --> Controller Class Initialized
INFO - 2024-01-27 03:33:08 --> Model Class Initialized
DEBUG - 2024-01-27 03:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 03:33:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 03:33:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 03:33:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 03:33:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 03:33:08 --> Model Class Initialized
INFO - 2024-01-27 03:33:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 03:33:08 --> Final output sent to browser
DEBUG - 2024-01-27 03:33:08 --> Total execution time: 0.0416
ERROR - 2024-01-27 03:52:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 03:52:35 --> Config Class Initialized
INFO - 2024-01-27 03:52:35 --> Hooks Class Initialized
DEBUG - 2024-01-27 03:52:35 --> UTF-8 Support Enabled
INFO - 2024-01-27 03:52:35 --> Utf8 Class Initialized
INFO - 2024-01-27 03:52:35 --> URI Class Initialized
DEBUG - 2024-01-27 03:52:35 --> No URI present. Default controller set.
INFO - 2024-01-27 03:52:35 --> Router Class Initialized
INFO - 2024-01-27 03:52:35 --> Output Class Initialized
INFO - 2024-01-27 03:52:35 --> Security Class Initialized
DEBUG - 2024-01-27 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 03:52:35 --> Input Class Initialized
INFO - 2024-01-27 03:52:35 --> Language Class Initialized
INFO - 2024-01-27 03:52:35 --> Loader Class Initialized
INFO - 2024-01-27 03:52:35 --> Helper loaded: url_helper
INFO - 2024-01-27 03:52:35 --> Helper loaded: file_helper
INFO - 2024-01-27 03:52:35 --> Helper loaded: html_helper
INFO - 2024-01-27 03:52:35 --> Helper loaded: text_helper
INFO - 2024-01-27 03:52:35 --> Helper loaded: form_helper
INFO - 2024-01-27 03:52:35 --> Helper loaded: lang_helper
INFO - 2024-01-27 03:52:35 --> Helper loaded: security_helper
INFO - 2024-01-27 03:52:35 --> Helper loaded: cookie_helper
INFO - 2024-01-27 03:52:35 --> Database Driver Class Initialized
INFO - 2024-01-27 03:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 03:52:35 --> Parser Class Initialized
INFO - 2024-01-27 03:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 03:52:35 --> Pagination Class Initialized
INFO - 2024-01-27 03:52:35 --> Form Validation Class Initialized
INFO - 2024-01-27 03:52:35 --> Controller Class Initialized
INFO - 2024-01-27 03:52:35 --> Model Class Initialized
DEBUG - 2024-01-27 03:52:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 05:07:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:12 --> Config Class Initialized
INFO - 2024-01-27 05:07:12 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:12 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:12 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:12 --> URI Class Initialized
DEBUG - 2024-01-27 05:07:12 --> No URI present. Default controller set.
INFO - 2024-01-27 05:07:12 --> Router Class Initialized
INFO - 2024-01-27 05:07:12 --> Output Class Initialized
INFO - 2024-01-27 05:07:12 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:12 --> Input Class Initialized
INFO - 2024-01-27 05:07:12 --> Language Class Initialized
INFO - 2024-01-27 05:07:12 --> Loader Class Initialized
INFO - 2024-01-27 05:07:12 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:12 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:12 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:12 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:12 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:12 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:12 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:12 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:12 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:12 --> Parser Class Initialized
INFO - 2024-01-27 05:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:12 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:12 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:12 --> Controller Class Initialized
INFO - 2024-01-27 05:07:12 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 05:07:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:13 --> Config Class Initialized
INFO - 2024-01-27 05:07:13 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:13 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:13 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:13 --> URI Class Initialized
INFO - 2024-01-27 05:07:13 --> Router Class Initialized
INFO - 2024-01-27 05:07:13 --> Output Class Initialized
INFO - 2024-01-27 05:07:13 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:13 --> Input Class Initialized
INFO - 2024-01-27 05:07:13 --> Language Class Initialized
INFO - 2024-01-27 05:07:13 --> Loader Class Initialized
INFO - 2024-01-27 05:07:13 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:13 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:13 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:13 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:13 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:13 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:13 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:13 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:13 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:13 --> Parser Class Initialized
INFO - 2024-01-27 05:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:13 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:13 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:13 --> Controller Class Initialized
INFO - 2024-01-27 05:07:13 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 05:07:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:07:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:07:13 --> Model Class Initialized
INFO - 2024-01-27 05:07:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:07:13 --> Final output sent to browser
DEBUG - 2024-01-27 05:07:13 --> Total execution time: 0.0345
ERROR - 2024-01-27 05:07:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:20 --> Config Class Initialized
INFO - 2024-01-27 05:07:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:20 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:20 --> URI Class Initialized
INFO - 2024-01-27 05:07:20 --> Router Class Initialized
INFO - 2024-01-27 05:07:20 --> Output Class Initialized
INFO - 2024-01-27 05:07:20 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:20 --> Input Class Initialized
INFO - 2024-01-27 05:07:20 --> Language Class Initialized
INFO - 2024-01-27 05:07:20 --> Loader Class Initialized
INFO - 2024-01-27 05:07:20 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:20 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:20 --> Parser Class Initialized
INFO - 2024-01-27 05:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:20 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:20 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:20 --> Controller Class Initialized
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
INFO - 2024-01-27 05:07:20 --> Final output sent to browser
DEBUG - 2024-01-27 05:07:20 --> Total execution time: 0.0182
ERROR - 2024-01-27 05:07:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:20 --> Config Class Initialized
INFO - 2024-01-27 05:07:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:20 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:20 --> URI Class Initialized
DEBUG - 2024-01-27 05:07:20 --> No URI present. Default controller set.
INFO - 2024-01-27 05:07:20 --> Router Class Initialized
INFO - 2024-01-27 05:07:20 --> Output Class Initialized
INFO - 2024-01-27 05:07:20 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:20 --> Input Class Initialized
INFO - 2024-01-27 05:07:20 --> Language Class Initialized
INFO - 2024-01-27 05:07:20 --> Loader Class Initialized
INFO - 2024-01-27 05:07:20 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:20 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:20 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:20 --> Parser Class Initialized
INFO - 2024-01-27 05:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:20 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:20 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:20 --> Controller Class Initialized
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
INFO - 2024-01-27 05:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 05:07:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:07:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:07:20 --> Model Class Initialized
INFO - 2024-01-27 05:07:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 05:07:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 05:07:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:07:21 --> Final output sent to browser
DEBUG - 2024-01-27 05:07:21 --> Total execution time: 0.4216
ERROR - 2024-01-27 05:07:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:21 --> Config Class Initialized
INFO - 2024-01-27 05:07:21 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:21 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:21 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:21 --> URI Class Initialized
INFO - 2024-01-27 05:07:21 --> Router Class Initialized
INFO - 2024-01-27 05:07:21 --> Output Class Initialized
INFO - 2024-01-27 05:07:21 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:21 --> Input Class Initialized
INFO - 2024-01-27 05:07:21 --> Language Class Initialized
INFO - 2024-01-27 05:07:21 --> Loader Class Initialized
INFO - 2024-01-27 05:07:21 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:21 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:21 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:21 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:21 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:21 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:21 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:21 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:21 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:21 --> Parser Class Initialized
INFO - 2024-01-27 05:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:21 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:21 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:21 --> Controller Class Initialized
DEBUG - 2024-01-27 05:07:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:21 --> Model Class Initialized
INFO - 2024-01-27 05:07:21 --> Final output sent to browser
DEBUG - 2024-01-27 05:07:21 --> Total execution time: 0.0133
ERROR - 2024-01-27 05:07:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:27 --> Config Class Initialized
INFO - 2024-01-27 05:07:27 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:27 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:27 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:27 --> URI Class Initialized
INFO - 2024-01-27 05:07:27 --> Router Class Initialized
INFO - 2024-01-27 05:07:27 --> Output Class Initialized
INFO - 2024-01-27 05:07:27 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:27 --> Input Class Initialized
INFO - 2024-01-27 05:07:27 --> Language Class Initialized
INFO - 2024-01-27 05:07:27 --> Loader Class Initialized
INFO - 2024-01-27 05:07:27 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:27 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:27 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:27 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:27 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:27 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:27 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:27 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:27 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:27 --> Parser Class Initialized
INFO - 2024-01-27 05:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:27 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:27 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:27 --> Controller Class Initialized
INFO - 2024-01-27 05:07:27 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:27 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:27 --> Model Class Initialized
INFO - 2024-01-27 05:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-27 05:07:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:07:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:07:27 --> Model Class Initialized
INFO - 2024-01-27 05:07:27 --> Model Class Initialized
INFO - 2024-01-27 05:07:27 --> Model Class Initialized
INFO - 2024-01-27 05:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 05:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 05:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:07:28 --> Final output sent to browser
DEBUG - 2024-01-27 05:07:28 --> Total execution time: 0.2233
ERROR - 2024-01-27 05:07:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:28 --> Config Class Initialized
INFO - 2024-01-27 05:07:28 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:28 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:28 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:28 --> URI Class Initialized
INFO - 2024-01-27 05:07:28 --> Router Class Initialized
INFO - 2024-01-27 05:07:28 --> Output Class Initialized
INFO - 2024-01-27 05:07:28 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:28 --> Input Class Initialized
INFO - 2024-01-27 05:07:28 --> Language Class Initialized
INFO - 2024-01-27 05:07:28 --> Loader Class Initialized
INFO - 2024-01-27 05:07:28 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:28 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:28 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:28 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:28 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:28 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:28 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:28 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:28 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:28 --> Parser Class Initialized
INFO - 2024-01-27 05:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:28 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:28 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:28 --> Controller Class Initialized
INFO - 2024-01-27 05:07:28 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:28 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:28 --> Model Class Initialized
INFO - 2024-01-27 05:07:28 --> Final output sent to browser
DEBUG - 2024-01-27 05:07:28 --> Total execution time: 0.0625
ERROR - 2024-01-27 05:07:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:07:56 --> Config Class Initialized
INFO - 2024-01-27 05:07:56 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:07:56 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:07:56 --> Utf8 Class Initialized
INFO - 2024-01-27 05:07:56 --> URI Class Initialized
DEBUG - 2024-01-27 05:07:56 --> No URI present. Default controller set.
INFO - 2024-01-27 05:07:56 --> Router Class Initialized
INFO - 2024-01-27 05:07:56 --> Output Class Initialized
INFO - 2024-01-27 05:07:56 --> Security Class Initialized
DEBUG - 2024-01-27 05:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:07:56 --> Input Class Initialized
INFO - 2024-01-27 05:07:56 --> Language Class Initialized
INFO - 2024-01-27 05:07:56 --> Loader Class Initialized
INFO - 2024-01-27 05:07:56 --> Helper loaded: url_helper
INFO - 2024-01-27 05:07:56 --> Helper loaded: file_helper
INFO - 2024-01-27 05:07:56 --> Helper loaded: html_helper
INFO - 2024-01-27 05:07:56 --> Helper loaded: text_helper
INFO - 2024-01-27 05:07:56 --> Helper loaded: form_helper
INFO - 2024-01-27 05:07:56 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:07:56 --> Helper loaded: security_helper
INFO - 2024-01-27 05:07:56 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:07:56 --> Database Driver Class Initialized
INFO - 2024-01-27 05:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:07:56 --> Parser Class Initialized
INFO - 2024-01-27 05:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:07:56 --> Pagination Class Initialized
INFO - 2024-01-27 05:07:56 --> Form Validation Class Initialized
INFO - 2024-01-27 05:07:56 --> Controller Class Initialized
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
DEBUG - 2024-01-27 05:07:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
INFO - 2024-01-27 05:07:56 --> Model Class Initialized
INFO - 2024-01-27 05:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 05:07:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:07:57 --> Model Class Initialized
INFO - 2024-01-27 05:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 05:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 05:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:07:57 --> Final output sent to browser
DEBUG - 2024-01-27 05:07:57 --> Total execution time: 0.4147
ERROR - 2024-01-27 05:11:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:11:50 --> Config Class Initialized
INFO - 2024-01-27 05:11:50 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:11:50 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:11:50 --> Utf8 Class Initialized
INFO - 2024-01-27 05:11:50 --> URI Class Initialized
INFO - 2024-01-27 05:11:50 --> Router Class Initialized
INFO - 2024-01-27 05:11:50 --> Output Class Initialized
INFO - 2024-01-27 05:11:50 --> Security Class Initialized
DEBUG - 2024-01-27 05:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:11:50 --> Input Class Initialized
INFO - 2024-01-27 05:11:50 --> Language Class Initialized
INFO - 2024-01-27 05:11:50 --> Loader Class Initialized
INFO - 2024-01-27 05:11:50 --> Helper loaded: url_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: file_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: html_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: text_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: form_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: security_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:11:50 --> Database Driver Class Initialized
INFO - 2024-01-27 05:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:11:50 --> Parser Class Initialized
INFO - 2024-01-27 05:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:11:50 --> Pagination Class Initialized
INFO - 2024-01-27 05:11:50 --> Form Validation Class Initialized
INFO - 2024-01-27 05:11:50 --> Controller Class Initialized
INFO - 2024-01-27 05:11:50 --> Model Class Initialized
DEBUG - 2024-01-27 05:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:11:50 --> Final output sent to browser
DEBUG - 2024-01-27 05:11:50 --> Total execution time: 0.0154
ERROR - 2024-01-27 05:11:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:11:50 --> Config Class Initialized
INFO - 2024-01-27 05:11:50 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:11:50 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:11:50 --> Utf8 Class Initialized
INFO - 2024-01-27 05:11:50 --> URI Class Initialized
INFO - 2024-01-27 05:11:50 --> Router Class Initialized
INFO - 2024-01-27 05:11:50 --> Output Class Initialized
INFO - 2024-01-27 05:11:50 --> Security Class Initialized
DEBUG - 2024-01-27 05:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:11:50 --> Input Class Initialized
INFO - 2024-01-27 05:11:50 --> Language Class Initialized
INFO - 2024-01-27 05:11:50 --> Loader Class Initialized
INFO - 2024-01-27 05:11:50 --> Helper loaded: url_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: file_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: html_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: text_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: form_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: security_helper
INFO - 2024-01-27 05:11:50 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:11:50 --> Database Driver Class Initialized
INFO - 2024-01-27 05:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:11:50 --> Parser Class Initialized
INFO - 2024-01-27 05:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:11:50 --> Pagination Class Initialized
INFO - 2024-01-27 05:11:50 --> Form Validation Class Initialized
INFO - 2024-01-27 05:11:50 --> Controller Class Initialized
INFO - 2024-01-27 05:11:50 --> Model Class Initialized
DEBUG - 2024-01-27 05:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 05:11:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:11:50 --> Model Class Initialized
INFO - 2024-01-27 05:11:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:11:50 --> Final output sent to browser
DEBUG - 2024-01-27 05:11:50 --> Total execution time: 0.0317
ERROR - 2024-01-27 05:12:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:12:12 --> Config Class Initialized
INFO - 2024-01-27 05:12:12 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:12:12 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:12:12 --> Utf8 Class Initialized
INFO - 2024-01-27 05:12:12 --> URI Class Initialized
INFO - 2024-01-27 05:12:12 --> Router Class Initialized
INFO - 2024-01-27 05:12:12 --> Output Class Initialized
INFO - 2024-01-27 05:12:12 --> Security Class Initialized
DEBUG - 2024-01-27 05:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:12:12 --> Input Class Initialized
INFO - 2024-01-27 05:12:12 --> Language Class Initialized
INFO - 2024-01-27 05:12:12 --> Loader Class Initialized
INFO - 2024-01-27 05:12:12 --> Helper loaded: url_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: file_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: html_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: text_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: form_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: security_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:12:12 --> Database Driver Class Initialized
INFO - 2024-01-27 05:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:12:12 --> Parser Class Initialized
INFO - 2024-01-27 05:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:12:12 --> Pagination Class Initialized
INFO - 2024-01-27 05:12:12 --> Form Validation Class Initialized
INFO - 2024-01-27 05:12:12 --> Controller Class Initialized
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
INFO - 2024-01-27 05:12:12 --> Final output sent to browser
DEBUG - 2024-01-27 05:12:12 --> Total execution time: 0.0183
ERROR - 2024-01-27 05:12:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:12:12 --> Config Class Initialized
INFO - 2024-01-27 05:12:12 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:12:12 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:12:12 --> Utf8 Class Initialized
INFO - 2024-01-27 05:12:12 --> URI Class Initialized
DEBUG - 2024-01-27 05:12:12 --> No URI present. Default controller set.
INFO - 2024-01-27 05:12:12 --> Router Class Initialized
INFO - 2024-01-27 05:12:12 --> Output Class Initialized
INFO - 2024-01-27 05:12:12 --> Security Class Initialized
DEBUG - 2024-01-27 05:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:12:12 --> Input Class Initialized
INFO - 2024-01-27 05:12:12 --> Language Class Initialized
INFO - 2024-01-27 05:12:12 --> Loader Class Initialized
INFO - 2024-01-27 05:12:12 --> Helper loaded: url_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: file_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: html_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: text_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: form_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: security_helper
INFO - 2024-01-27 05:12:12 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:12:12 --> Database Driver Class Initialized
INFO - 2024-01-27 05:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:12:12 --> Parser Class Initialized
INFO - 2024-01-27 05:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:12:12 --> Pagination Class Initialized
INFO - 2024-01-27 05:12:12 --> Form Validation Class Initialized
INFO - 2024-01-27 05:12:12 --> Controller Class Initialized
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
INFO - 2024-01-27 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 05:12:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:12:12 --> Model Class Initialized
INFO - 2024-01-27 05:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 05:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 05:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:12:13 --> Final output sent to browser
DEBUG - 2024-01-27 05:12:13 --> Total execution time: 0.4199
ERROR - 2024-01-27 05:12:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:12:13 --> Config Class Initialized
INFO - 2024-01-27 05:12:13 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:12:13 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:12:13 --> Utf8 Class Initialized
INFO - 2024-01-27 05:12:13 --> URI Class Initialized
INFO - 2024-01-27 05:12:13 --> Router Class Initialized
INFO - 2024-01-27 05:12:13 --> Output Class Initialized
INFO - 2024-01-27 05:12:13 --> Security Class Initialized
DEBUG - 2024-01-27 05:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:12:13 --> Input Class Initialized
INFO - 2024-01-27 05:12:13 --> Language Class Initialized
INFO - 2024-01-27 05:12:13 --> Loader Class Initialized
INFO - 2024-01-27 05:12:13 --> Helper loaded: url_helper
INFO - 2024-01-27 05:12:13 --> Helper loaded: file_helper
INFO - 2024-01-27 05:12:13 --> Helper loaded: html_helper
INFO - 2024-01-27 05:12:13 --> Helper loaded: text_helper
INFO - 2024-01-27 05:12:13 --> Helper loaded: form_helper
INFO - 2024-01-27 05:12:13 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:12:13 --> Helper loaded: security_helper
INFO - 2024-01-27 05:12:13 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:12:13 --> Database Driver Class Initialized
INFO - 2024-01-27 05:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:12:13 --> Parser Class Initialized
INFO - 2024-01-27 05:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:12:13 --> Pagination Class Initialized
INFO - 2024-01-27 05:12:13 --> Form Validation Class Initialized
INFO - 2024-01-27 05:12:13 --> Controller Class Initialized
DEBUG - 2024-01-27 05:12:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:13 --> Model Class Initialized
INFO - 2024-01-27 05:12:13 --> Final output sent to browser
DEBUG - 2024-01-27 05:12:13 --> Total execution time: 0.0126
ERROR - 2024-01-27 05:12:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:12:29 --> Config Class Initialized
INFO - 2024-01-27 05:12:29 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:12:29 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:12:29 --> Utf8 Class Initialized
INFO - 2024-01-27 05:12:29 --> URI Class Initialized
INFO - 2024-01-27 05:12:29 --> Router Class Initialized
INFO - 2024-01-27 05:12:29 --> Output Class Initialized
INFO - 2024-01-27 05:12:29 --> Security Class Initialized
DEBUG - 2024-01-27 05:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:12:29 --> Input Class Initialized
INFO - 2024-01-27 05:12:29 --> Language Class Initialized
INFO - 2024-01-27 05:12:29 --> Loader Class Initialized
INFO - 2024-01-27 05:12:29 --> Helper loaded: url_helper
INFO - 2024-01-27 05:12:29 --> Helper loaded: file_helper
INFO - 2024-01-27 05:12:29 --> Helper loaded: html_helper
INFO - 2024-01-27 05:12:29 --> Helper loaded: text_helper
INFO - 2024-01-27 05:12:29 --> Helper loaded: form_helper
INFO - 2024-01-27 05:12:29 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:12:29 --> Helper loaded: security_helper
INFO - 2024-01-27 05:12:29 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:12:29 --> Database Driver Class Initialized
INFO - 2024-01-27 05:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:12:29 --> Parser Class Initialized
INFO - 2024-01-27 05:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:12:29 --> Pagination Class Initialized
INFO - 2024-01-27 05:12:29 --> Form Validation Class Initialized
INFO - 2024-01-27 05:12:29 --> Controller Class Initialized
INFO - 2024-01-27 05:12:29 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:29 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:29 --> Model Class Initialized
INFO - 2024-01-27 05:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-27 05:12:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:12:29 --> Model Class Initialized
INFO - 2024-01-27 05:12:29 --> Model Class Initialized
INFO - 2024-01-27 05:12:29 --> Model Class Initialized
INFO - 2024-01-27 05:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 05:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 05:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:12:29 --> Final output sent to browser
DEBUG - 2024-01-27 05:12:29 --> Total execution time: 0.2421
ERROR - 2024-01-27 05:12:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:12:30 --> Config Class Initialized
INFO - 2024-01-27 05:12:30 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:12:30 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:12:30 --> Utf8 Class Initialized
INFO - 2024-01-27 05:12:30 --> URI Class Initialized
INFO - 2024-01-27 05:12:30 --> Router Class Initialized
INFO - 2024-01-27 05:12:30 --> Output Class Initialized
INFO - 2024-01-27 05:12:30 --> Security Class Initialized
DEBUG - 2024-01-27 05:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:12:30 --> Input Class Initialized
INFO - 2024-01-27 05:12:30 --> Language Class Initialized
INFO - 2024-01-27 05:12:30 --> Loader Class Initialized
INFO - 2024-01-27 05:12:30 --> Helper loaded: url_helper
INFO - 2024-01-27 05:12:30 --> Helper loaded: file_helper
INFO - 2024-01-27 05:12:30 --> Helper loaded: html_helper
INFO - 2024-01-27 05:12:30 --> Helper loaded: text_helper
INFO - 2024-01-27 05:12:30 --> Helper loaded: form_helper
INFO - 2024-01-27 05:12:30 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:12:30 --> Helper loaded: security_helper
INFO - 2024-01-27 05:12:30 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:12:30 --> Database Driver Class Initialized
INFO - 2024-01-27 05:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:12:30 --> Parser Class Initialized
INFO - 2024-01-27 05:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:12:30 --> Pagination Class Initialized
INFO - 2024-01-27 05:12:30 --> Form Validation Class Initialized
INFO - 2024-01-27 05:12:30 --> Controller Class Initialized
INFO - 2024-01-27 05:12:30 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:30 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:30 --> Model Class Initialized
INFO - 2024-01-27 05:12:30 --> Final output sent to browser
DEBUG - 2024-01-27 05:12:30 --> Total execution time: 0.0639
ERROR - 2024-01-27 05:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:12:35 --> Config Class Initialized
INFO - 2024-01-27 05:12:35 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:12:35 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:12:35 --> Utf8 Class Initialized
INFO - 2024-01-27 05:12:35 --> URI Class Initialized
INFO - 2024-01-27 05:12:35 --> Router Class Initialized
INFO - 2024-01-27 05:12:35 --> Output Class Initialized
INFO - 2024-01-27 05:12:35 --> Security Class Initialized
DEBUG - 2024-01-27 05:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:12:35 --> Input Class Initialized
INFO - 2024-01-27 05:12:35 --> Language Class Initialized
INFO - 2024-01-27 05:12:35 --> Loader Class Initialized
INFO - 2024-01-27 05:12:35 --> Helper loaded: url_helper
INFO - 2024-01-27 05:12:35 --> Helper loaded: file_helper
INFO - 2024-01-27 05:12:35 --> Helper loaded: html_helper
INFO - 2024-01-27 05:12:35 --> Helper loaded: text_helper
INFO - 2024-01-27 05:12:35 --> Helper loaded: form_helper
INFO - 2024-01-27 05:12:35 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:12:35 --> Helper loaded: security_helper
INFO - 2024-01-27 05:12:35 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:12:35 --> Database Driver Class Initialized
INFO - 2024-01-27 05:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:12:35 --> Parser Class Initialized
INFO - 2024-01-27 05:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:12:35 --> Pagination Class Initialized
INFO - 2024-01-27 05:12:35 --> Form Validation Class Initialized
INFO - 2024-01-27 05:12:35 --> Controller Class Initialized
INFO - 2024-01-27 05:12:35 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:35 --> Model Class Initialized
DEBUG - 2024-01-27 05:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:12:35 --> Model Class Initialized
INFO - 2024-01-27 05:12:36 --> Final output sent to browser
DEBUG - 2024-01-27 05:12:36 --> Total execution time: 0.9449
ERROR - 2024-01-27 05:14:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 05:14:10 --> Config Class Initialized
INFO - 2024-01-27 05:14:10 --> Hooks Class Initialized
DEBUG - 2024-01-27 05:14:10 --> UTF-8 Support Enabled
INFO - 2024-01-27 05:14:10 --> Utf8 Class Initialized
INFO - 2024-01-27 05:14:10 --> URI Class Initialized
DEBUG - 2024-01-27 05:14:10 --> No URI present. Default controller set.
INFO - 2024-01-27 05:14:10 --> Router Class Initialized
INFO - 2024-01-27 05:14:10 --> Output Class Initialized
INFO - 2024-01-27 05:14:10 --> Security Class Initialized
DEBUG - 2024-01-27 05:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 05:14:10 --> Input Class Initialized
INFO - 2024-01-27 05:14:10 --> Language Class Initialized
INFO - 2024-01-27 05:14:10 --> Loader Class Initialized
INFO - 2024-01-27 05:14:10 --> Helper loaded: url_helper
INFO - 2024-01-27 05:14:10 --> Helper loaded: file_helper
INFO - 2024-01-27 05:14:10 --> Helper loaded: html_helper
INFO - 2024-01-27 05:14:10 --> Helper loaded: text_helper
INFO - 2024-01-27 05:14:10 --> Helper loaded: form_helper
INFO - 2024-01-27 05:14:10 --> Helper loaded: lang_helper
INFO - 2024-01-27 05:14:10 --> Helper loaded: security_helper
INFO - 2024-01-27 05:14:10 --> Helper loaded: cookie_helper
INFO - 2024-01-27 05:14:10 --> Database Driver Class Initialized
INFO - 2024-01-27 05:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 05:14:10 --> Parser Class Initialized
INFO - 2024-01-27 05:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 05:14:10 --> Pagination Class Initialized
INFO - 2024-01-27 05:14:10 --> Form Validation Class Initialized
INFO - 2024-01-27 05:14:10 --> Controller Class Initialized
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
DEBUG - 2024-01-27 05:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
DEBUG - 2024-01-27 05:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
DEBUG - 2024-01-27 05:14:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 05:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
INFO - 2024-01-27 05:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 05:14:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 05:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 05:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 05:14:10 --> Model Class Initialized
INFO - 2024-01-27 05:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 05:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 05:14:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 05:14:10 --> Final output sent to browser
DEBUG - 2024-01-27 05:14:10 --> Total execution time: 0.4313
ERROR - 2024-01-27 06:05:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:05 --> Config Class Initialized
INFO - 2024-01-27 06:05:05 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:05 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:05 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:05 --> URI Class Initialized
DEBUG - 2024-01-27 06:05:05 --> No URI present. Default controller set.
INFO - 2024-01-27 06:05:05 --> Router Class Initialized
INFO - 2024-01-27 06:05:05 --> Output Class Initialized
INFO - 2024-01-27 06:05:05 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:05 --> Input Class Initialized
INFO - 2024-01-27 06:05:05 --> Language Class Initialized
INFO - 2024-01-27 06:05:05 --> Loader Class Initialized
INFO - 2024-01-27 06:05:05 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:05 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:05 --> Parser Class Initialized
INFO - 2024-01-27 06:05:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:05 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:05 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:05 --> Controller Class Initialized
INFO - 2024-01-27 06:05:05 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 06:05:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:05 --> Config Class Initialized
INFO - 2024-01-27 06:05:05 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:05 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:05 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:05 --> URI Class Initialized
INFO - 2024-01-27 06:05:05 --> Router Class Initialized
INFO - 2024-01-27 06:05:05 --> Output Class Initialized
INFO - 2024-01-27 06:05:05 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:05 --> Input Class Initialized
INFO - 2024-01-27 06:05:05 --> Language Class Initialized
INFO - 2024-01-27 06:05:05 --> Loader Class Initialized
INFO - 2024-01-27 06:05:05 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:05 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:05 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:05 --> Parser Class Initialized
INFO - 2024-01-27 06:05:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:05 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:05 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:05 --> Controller Class Initialized
INFO - 2024-01-27 06:05:05 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 06:05:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 06:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 06:05:05 --> Model Class Initialized
INFO - 2024-01-27 06:05:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 06:05:05 --> Final output sent to browser
DEBUG - 2024-01-27 06:05:05 --> Total execution time: 0.0318
ERROR - 2024-01-27 06:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:17 --> Config Class Initialized
INFO - 2024-01-27 06:05:17 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:17 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:17 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:17 --> URI Class Initialized
INFO - 2024-01-27 06:05:17 --> Router Class Initialized
INFO - 2024-01-27 06:05:17 --> Output Class Initialized
INFO - 2024-01-27 06:05:17 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:17 --> Input Class Initialized
INFO - 2024-01-27 06:05:17 --> Language Class Initialized
INFO - 2024-01-27 06:05:17 --> Loader Class Initialized
INFO - 2024-01-27 06:05:17 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:17 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:17 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:17 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:17 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:17 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:17 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:17 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:17 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:17 --> Parser Class Initialized
INFO - 2024-01-27 06:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:17 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:17 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:17 --> Controller Class Initialized
INFO - 2024-01-27 06:05:17 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:17 --> Model Class Initialized
INFO - 2024-01-27 06:05:17 --> Final output sent to browser
DEBUG - 2024-01-27 06:05:17 --> Total execution time: 0.0191
ERROR - 2024-01-27 06:05:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:18 --> Config Class Initialized
INFO - 2024-01-27 06:05:18 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:18 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:18 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:18 --> URI Class Initialized
DEBUG - 2024-01-27 06:05:18 --> No URI present. Default controller set.
INFO - 2024-01-27 06:05:18 --> Router Class Initialized
INFO - 2024-01-27 06:05:18 --> Output Class Initialized
INFO - 2024-01-27 06:05:18 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:18 --> Input Class Initialized
INFO - 2024-01-27 06:05:18 --> Language Class Initialized
INFO - 2024-01-27 06:05:18 --> Loader Class Initialized
INFO - 2024-01-27 06:05:18 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:18 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:18 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:18 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:18 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:18 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:18 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:18 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:18 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:18 --> Parser Class Initialized
INFO - 2024-01-27 06:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:18 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:18 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:18 --> Controller Class Initialized
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
INFO - 2024-01-27 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 06:05:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 06:05:18 --> Model Class Initialized
INFO - 2024-01-27 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 06:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 06:05:18 --> Final output sent to browser
DEBUG - 2024-01-27 06:05:18 --> Total execution time: 0.3979
ERROR - 2024-01-27 06:05:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:19 --> Config Class Initialized
INFO - 2024-01-27 06:05:19 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:19 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:19 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:19 --> URI Class Initialized
INFO - 2024-01-27 06:05:19 --> Router Class Initialized
INFO - 2024-01-27 06:05:19 --> Output Class Initialized
INFO - 2024-01-27 06:05:19 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:19 --> Input Class Initialized
INFO - 2024-01-27 06:05:19 --> Language Class Initialized
INFO - 2024-01-27 06:05:19 --> Loader Class Initialized
INFO - 2024-01-27 06:05:19 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:19 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:19 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:19 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:19 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:19 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:19 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:19 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:19 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:19 --> Parser Class Initialized
INFO - 2024-01-27 06:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:19 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:19 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:19 --> Controller Class Initialized
DEBUG - 2024-01-27 06:05:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:19 --> Model Class Initialized
INFO - 2024-01-27 06:05:19 --> Final output sent to browser
DEBUG - 2024-01-27 06:05:19 --> Total execution time: 0.0119
ERROR - 2024-01-27 06:05:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:31 --> Config Class Initialized
INFO - 2024-01-27 06:05:31 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:31 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:31 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:31 --> URI Class Initialized
INFO - 2024-01-27 06:05:31 --> Router Class Initialized
INFO - 2024-01-27 06:05:31 --> Output Class Initialized
INFO - 2024-01-27 06:05:31 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:31 --> Input Class Initialized
INFO - 2024-01-27 06:05:31 --> Language Class Initialized
INFO - 2024-01-27 06:05:31 --> Loader Class Initialized
INFO - 2024-01-27 06:05:31 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:31 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:31 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:31 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:31 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:31 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:31 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:31 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:31 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:31 --> Parser Class Initialized
INFO - 2024-01-27 06:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:31 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:31 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:31 --> Controller Class Initialized
DEBUG - 2024-01-27 06:05:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:31 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:31 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:31 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:31 --> Model Class Initialized
INFO - 2024-01-27 06:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-27 06:05:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 06:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 06:05:31 --> Model Class Initialized
INFO - 2024-01-27 06:05:31 --> Model Class Initialized
INFO - 2024-01-27 06:05:31 --> Model Class Initialized
INFO - 2024-01-27 06:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 06:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 06:05:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 06:05:31 --> Final output sent to browser
DEBUG - 2024-01-27 06:05:31 --> Total execution time: 0.2069
ERROR - 2024-01-27 06:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:32 --> Config Class Initialized
INFO - 2024-01-27 06:05:32 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:32 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:32 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:32 --> URI Class Initialized
INFO - 2024-01-27 06:05:32 --> Router Class Initialized
INFO - 2024-01-27 06:05:32 --> Output Class Initialized
INFO - 2024-01-27 06:05:32 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:32 --> Input Class Initialized
INFO - 2024-01-27 06:05:32 --> Language Class Initialized
INFO - 2024-01-27 06:05:32 --> Loader Class Initialized
INFO - 2024-01-27 06:05:32 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:32 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:32 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:32 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:32 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:32 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:32 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:32 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:32 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:32 --> Parser Class Initialized
INFO - 2024-01-27 06:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:32 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:32 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:32 --> Controller Class Initialized
DEBUG - 2024-01-27 06:05:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:32 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:32 --> Model Class Initialized
INFO - 2024-01-27 06:05:32 --> Final output sent to browser
DEBUG - 2024-01-27 06:05:32 --> Total execution time: 0.0299
ERROR - 2024-01-27 06:05:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:05:41 --> Config Class Initialized
INFO - 2024-01-27 06:05:41 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:05:41 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:05:41 --> Utf8 Class Initialized
INFO - 2024-01-27 06:05:41 --> URI Class Initialized
INFO - 2024-01-27 06:05:41 --> Router Class Initialized
INFO - 2024-01-27 06:05:41 --> Output Class Initialized
INFO - 2024-01-27 06:05:41 --> Security Class Initialized
DEBUG - 2024-01-27 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:05:41 --> Input Class Initialized
INFO - 2024-01-27 06:05:41 --> Language Class Initialized
INFO - 2024-01-27 06:05:41 --> Loader Class Initialized
INFO - 2024-01-27 06:05:41 --> Helper loaded: url_helper
INFO - 2024-01-27 06:05:41 --> Helper loaded: file_helper
INFO - 2024-01-27 06:05:41 --> Helper loaded: html_helper
INFO - 2024-01-27 06:05:41 --> Helper loaded: text_helper
INFO - 2024-01-27 06:05:41 --> Helper loaded: form_helper
INFO - 2024-01-27 06:05:41 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:05:41 --> Helper loaded: security_helper
INFO - 2024-01-27 06:05:41 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:05:41 --> Database Driver Class Initialized
INFO - 2024-01-27 06:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:05:41 --> Parser Class Initialized
INFO - 2024-01-27 06:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:05:41 --> Pagination Class Initialized
INFO - 2024-01-27 06:05:41 --> Form Validation Class Initialized
INFO - 2024-01-27 06:05:41 --> Controller Class Initialized
DEBUG - 2024-01-27 06:05:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:41 --> Model Class Initialized
DEBUG - 2024-01-27 06:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:05:41 --> Model Class Initialized
INFO - 2024-01-27 06:05:42 --> Final output sent to browser
DEBUG - 2024-01-27 06:05:42 --> Total execution time: 0.2151
ERROR - 2024-01-27 06:06:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:06:04 --> Config Class Initialized
INFO - 2024-01-27 06:06:04 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:06:04 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:06:04 --> Utf8 Class Initialized
INFO - 2024-01-27 06:06:04 --> URI Class Initialized
INFO - 2024-01-27 06:06:04 --> Router Class Initialized
INFO - 2024-01-27 06:06:04 --> Output Class Initialized
INFO - 2024-01-27 06:06:04 --> Security Class Initialized
DEBUG - 2024-01-27 06:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:06:04 --> Input Class Initialized
INFO - 2024-01-27 06:06:04 --> Language Class Initialized
INFO - 2024-01-27 06:06:04 --> Loader Class Initialized
INFO - 2024-01-27 06:06:04 --> Helper loaded: url_helper
INFO - 2024-01-27 06:06:04 --> Helper loaded: file_helper
INFO - 2024-01-27 06:06:04 --> Helper loaded: html_helper
INFO - 2024-01-27 06:06:04 --> Helper loaded: text_helper
INFO - 2024-01-27 06:06:04 --> Helper loaded: form_helper
INFO - 2024-01-27 06:06:04 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:06:04 --> Helper loaded: security_helper
INFO - 2024-01-27 06:06:04 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:06:04 --> Database Driver Class Initialized
INFO - 2024-01-27 06:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:06:04 --> Parser Class Initialized
INFO - 2024-01-27 06:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:06:04 --> Pagination Class Initialized
INFO - 2024-01-27 06:06:04 --> Form Validation Class Initialized
INFO - 2024-01-27 06:06:04 --> Controller Class Initialized
INFO - 2024-01-27 06:06:04 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:04 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:04 --> Model Class Initialized
INFO - 2024-01-27 06:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-27 06:06:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 06:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 06:06:04 --> Model Class Initialized
INFO - 2024-01-27 06:06:04 --> Model Class Initialized
INFO - 2024-01-27 06:06:04 --> Model Class Initialized
INFO - 2024-01-27 06:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 06:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 06:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 06:06:04 --> Final output sent to browser
DEBUG - 2024-01-27 06:06:04 --> Total execution time: 0.2067
ERROR - 2024-01-27 06:06:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:06:05 --> Config Class Initialized
INFO - 2024-01-27 06:06:05 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:06:05 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:06:05 --> Utf8 Class Initialized
INFO - 2024-01-27 06:06:05 --> URI Class Initialized
INFO - 2024-01-27 06:06:05 --> Router Class Initialized
INFO - 2024-01-27 06:06:05 --> Output Class Initialized
INFO - 2024-01-27 06:06:05 --> Security Class Initialized
DEBUG - 2024-01-27 06:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:06:05 --> Input Class Initialized
INFO - 2024-01-27 06:06:05 --> Language Class Initialized
INFO - 2024-01-27 06:06:05 --> Loader Class Initialized
INFO - 2024-01-27 06:06:05 --> Helper loaded: url_helper
INFO - 2024-01-27 06:06:05 --> Helper loaded: file_helper
INFO - 2024-01-27 06:06:05 --> Helper loaded: html_helper
INFO - 2024-01-27 06:06:05 --> Helper loaded: text_helper
INFO - 2024-01-27 06:06:05 --> Helper loaded: form_helper
INFO - 2024-01-27 06:06:05 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:06:05 --> Helper loaded: security_helper
INFO - 2024-01-27 06:06:05 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:06:05 --> Database Driver Class Initialized
INFO - 2024-01-27 06:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:06:05 --> Parser Class Initialized
INFO - 2024-01-27 06:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:06:05 --> Pagination Class Initialized
INFO - 2024-01-27 06:06:05 --> Form Validation Class Initialized
INFO - 2024-01-27 06:06:05 --> Controller Class Initialized
INFO - 2024-01-27 06:06:05 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:05 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:05 --> Model Class Initialized
INFO - 2024-01-27 06:06:05 --> Final output sent to browser
DEBUG - 2024-01-27 06:06:05 --> Total execution time: 0.0561
ERROR - 2024-01-27 06:06:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:06:09 --> Config Class Initialized
INFO - 2024-01-27 06:06:09 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:06:09 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:06:09 --> Utf8 Class Initialized
INFO - 2024-01-27 06:06:09 --> URI Class Initialized
INFO - 2024-01-27 06:06:09 --> Router Class Initialized
INFO - 2024-01-27 06:06:09 --> Output Class Initialized
INFO - 2024-01-27 06:06:09 --> Security Class Initialized
DEBUG - 2024-01-27 06:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:06:09 --> Input Class Initialized
INFO - 2024-01-27 06:06:09 --> Language Class Initialized
INFO - 2024-01-27 06:06:09 --> Loader Class Initialized
INFO - 2024-01-27 06:06:09 --> Helper loaded: url_helper
INFO - 2024-01-27 06:06:09 --> Helper loaded: file_helper
INFO - 2024-01-27 06:06:09 --> Helper loaded: html_helper
INFO - 2024-01-27 06:06:09 --> Helper loaded: text_helper
INFO - 2024-01-27 06:06:09 --> Helper loaded: form_helper
INFO - 2024-01-27 06:06:09 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:06:09 --> Helper loaded: security_helper
INFO - 2024-01-27 06:06:09 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:06:09 --> Database Driver Class Initialized
INFO - 2024-01-27 06:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:06:09 --> Parser Class Initialized
INFO - 2024-01-27 06:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:06:09 --> Pagination Class Initialized
INFO - 2024-01-27 06:06:09 --> Form Validation Class Initialized
INFO - 2024-01-27 06:06:09 --> Controller Class Initialized
DEBUG - 2024-01-27 06:06:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:09 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:09 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:09 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:09 --> Model Class Initialized
INFO - 2024-01-27 06:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-27 06:06:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 06:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 06:06:09 --> Model Class Initialized
INFO - 2024-01-27 06:06:09 --> Model Class Initialized
INFO - 2024-01-27 06:06:09 --> Model Class Initialized
INFO - 2024-01-27 06:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 06:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 06:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 06:06:09 --> Final output sent to browser
DEBUG - 2024-01-27 06:06:09 --> Total execution time: 0.1987
ERROR - 2024-01-27 06:06:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:06:11 --> Config Class Initialized
INFO - 2024-01-27 06:06:11 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:06:11 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:06:11 --> Utf8 Class Initialized
INFO - 2024-01-27 06:06:11 --> URI Class Initialized
INFO - 2024-01-27 06:06:11 --> Router Class Initialized
INFO - 2024-01-27 06:06:11 --> Output Class Initialized
INFO - 2024-01-27 06:06:11 --> Security Class Initialized
DEBUG - 2024-01-27 06:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:06:11 --> Input Class Initialized
INFO - 2024-01-27 06:06:11 --> Language Class Initialized
INFO - 2024-01-27 06:06:11 --> Loader Class Initialized
INFO - 2024-01-27 06:06:11 --> Helper loaded: url_helper
INFO - 2024-01-27 06:06:11 --> Helper loaded: file_helper
INFO - 2024-01-27 06:06:11 --> Helper loaded: html_helper
INFO - 2024-01-27 06:06:11 --> Helper loaded: text_helper
INFO - 2024-01-27 06:06:11 --> Helper loaded: form_helper
INFO - 2024-01-27 06:06:11 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:06:11 --> Helper loaded: security_helper
INFO - 2024-01-27 06:06:11 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:06:11 --> Database Driver Class Initialized
INFO - 2024-01-27 06:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:06:11 --> Parser Class Initialized
INFO - 2024-01-27 06:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:06:11 --> Pagination Class Initialized
INFO - 2024-01-27 06:06:11 --> Form Validation Class Initialized
INFO - 2024-01-27 06:06:11 --> Controller Class Initialized
DEBUG - 2024-01-27 06:06:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:11 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:11 --> Model Class Initialized
INFO - 2024-01-27 06:06:11 --> Final output sent to browser
DEBUG - 2024-01-27 06:06:11 --> Total execution time: 0.0296
ERROR - 2024-01-27 06:06:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 06:06:12 --> Config Class Initialized
INFO - 2024-01-27 06:06:12 --> Hooks Class Initialized
DEBUG - 2024-01-27 06:06:12 --> UTF-8 Support Enabled
INFO - 2024-01-27 06:06:12 --> Utf8 Class Initialized
INFO - 2024-01-27 06:06:12 --> URI Class Initialized
DEBUG - 2024-01-27 06:06:12 --> No URI present. Default controller set.
INFO - 2024-01-27 06:06:12 --> Router Class Initialized
INFO - 2024-01-27 06:06:12 --> Output Class Initialized
INFO - 2024-01-27 06:06:12 --> Security Class Initialized
DEBUG - 2024-01-27 06:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 06:06:12 --> Input Class Initialized
INFO - 2024-01-27 06:06:12 --> Language Class Initialized
INFO - 2024-01-27 06:06:12 --> Loader Class Initialized
INFO - 2024-01-27 06:06:12 --> Helper loaded: url_helper
INFO - 2024-01-27 06:06:12 --> Helper loaded: file_helper
INFO - 2024-01-27 06:06:12 --> Helper loaded: html_helper
INFO - 2024-01-27 06:06:12 --> Helper loaded: text_helper
INFO - 2024-01-27 06:06:12 --> Helper loaded: form_helper
INFO - 2024-01-27 06:06:12 --> Helper loaded: lang_helper
INFO - 2024-01-27 06:06:12 --> Helper loaded: security_helper
INFO - 2024-01-27 06:06:12 --> Helper loaded: cookie_helper
INFO - 2024-01-27 06:06:12 --> Database Driver Class Initialized
INFO - 2024-01-27 06:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 06:06:12 --> Parser Class Initialized
INFO - 2024-01-27 06:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 06:06:12 --> Pagination Class Initialized
INFO - 2024-01-27 06:06:12 --> Form Validation Class Initialized
INFO - 2024-01-27 06:06:12 --> Controller Class Initialized
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
DEBUG - 2024-01-27 06:06:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 06:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
INFO - 2024-01-27 06:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 06:06:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 06:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 06:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 06:06:12 --> Model Class Initialized
INFO - 2024-01-27 06:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 06:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 06:06:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 06:06:12 --> Final output sent to browser
DEBUG - 2024-01-27 06:06:12 --> Total execution time: 0.3807
ERROR - 2024-01-27 07:11:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 07:11:03 --> Config Class Initialized
INFO - 2024-01-27 07:11:03 --> Hooks Class Initialized
DEBUG - 2024-01-27 07:11:03 --> UTF-8 Support Enabled
INFO - 2024-01-27 07:11:03 --> Utf8 Class Initialized
INFO - 2024-01-27 07:11:03 --> URI Class Initialized
DEBUG - 2024-01-27 07:11:03 --> No URI present. Default controller set.
INFO - 2024-01-27 07:11:03 --> Router Class Initialized
INFO - 2024-01-27 07:11:03 --> Output Class Initialized
INFO - 2024-01-27 07:11:03 --> Security Class Initialized
DEBUG - 2024-01-27 07:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 07:11:03 --> Input Class Initialized
INFO - 2024-01-27 07:11:03 --> Language Class Initialized
INFO - 2024-01-27 07:11:03 --> Loader Class Initialized
INFO - 2024-01-27 07:11:03 --> Helper loaded: url_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: file_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: html_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: text_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: form_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: lang_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: security_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: cookie_helper
INFO - 2024-01-27 07:11:03 --> Database Driver Class Initialized
INFO - 2024-01-27 07:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 07:11:03 --> Parser Class Initialized
INFO - 2024-01-27 07:11:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 07:11:03 --> Pagination Class Initialized
INFO - 2024-01-27 07:11:03 --> Form Validation Class Initialized
INFO - 2024-01-27 07:11:03 --> Controller Class Initialized
INFO - 2024-01-27 07:11:03 --> Model Class Initialized
DEBUG - 2024-01-27 07:11:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 07:11:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 07:11:03 --> Config Class Initialized
INFO - 2024-01-27 07:11:03 --> Hooks Class Initialized
DEBUG - 2024-01-27 07:11:03 --> UTF-8 Support Enabled
INFO - 2024-01-27 07:11:03 --> Utf8 Class Initialized
INFO - 2024-01-27 07:11:03 --> URI Class Initialized
INFO - 2024-01-27 07:11:03 --> Router Class Initialized
INFO - 2024-01-27 07:11:03 --> Output Class Initialized
INFO - 2024-01-27 07:11:03 --> Security Class Initialized
DEBUG - 2024-01-27 07:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 07:11:03 --> Input Class Initialized
INFO - 2024-01-27 07:11:03 --> Language Class Initialized
INFO - 2024-01-27 07:11:03 --> Loader Class Initialized
INFO - 2024-01-27 07:11:03 --> Helper loaded: url_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: file_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: html_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: text_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: form_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: lang_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: security_helper
INFO - 2024-01-27 07:11:03 --> Helper loaded: cookie_helper
INFO - 2024-01-27 07:11:03 --> Database Driver Class Initialized
INFO - 2024-01-27 07:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 07:11:03 --> Parser Class Initialized
INFO - 2024-01-27 07:11:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 07:11:03 --> Pagination Class Initialized
INFO - 2024-01-27 07:11:03 --> Form Validation Class Initialized
INFO - 2024-01-27 07:11:03 --> Controller Class Initialized
INFO - 2024-01-27 07:11:03 --> Model Class Initialized
DEBUG - 2024-01-27 07:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 07:11:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 07:11:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 07:11:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 07:11:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 07:11:03 --> Model Class Initialized
INFO - 2024-01-27 07:11:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 07:11:03 --> Final output sent to browser
DEBUG - 2024-01-27 07:11:03 --> Total execution time: 0.0289
ERROR - 2024-01-27 07:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 07:11:20 --> Config Class Initialized
INFO - 2024-01-27 07:11:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 07:11:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 07:11:20 --> Utf8 Class Initialized
INFO - 2024-01-27 07:11:20 --> URI Class Initialized
INFO - 2024-01-27 07:11:20 --> Router Class Initialized
INFO - 2024-01-27 07:11:20 --> Output Class Initialized
INFO - 2024-01-27 07:11:20 --> Security Class Initialized
DEBUG - 2024-01-27 07:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 07:11:20 --> Input Class Initialized
INFO - 2024-01-27 07:11:20 --> Language Class Initialized
INFO - 2024-01-27 07:11:20 --> Loader Class Initialized
INFO - 2024-01-27 07:11:20 --> Helper loaded: url_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: file_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: html_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: text_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: form_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: lang_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: security_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: cookie_helper
INFO - 2024-01-27 07:11:20 --> Database Driver Class Initialized
INFO - 2024-01-27 07:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 07:11:20 --> Parser Class Initialized
INFO - 2024-01-27 07:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 07:11:20 --> Pagination Class Initialized
INFO - 2024-01-27 07:11:20 --> Form Validation Class Initialized
INFO - 2024-01-27 07:11:20 --> Controller Class Initialized
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
DEBUG - 2024-01-27 07:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
INFO - 2024-01-27 07:11:20 --> Final output sent to browser
DEBUG - 2024-01-27 07:11:20 --> Total execution time: 0.0195
ERROR - 2024-01-27 07:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 07:11:20 --> Config Class Initialized
INFO - 2024-01-27 07:11:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 07:11:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 07:11:20 --> Utf8 Class Initialized
INFO - 2024-01-27 07:11:20 --> URI Class Initialized
DEBUG - 2024-01-27 07:11:20 --> No URI present. Default controller set.
INFO - 2024-01-27 07:11:20 --> Router Class Initialized
INFO - 2024-01-27 07:11:20 --> Output Class Initialized
INFO - 2024-01-27 07:11:20 --> Security Class Initialized
DEBUG - 2024-01-27 07:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 07:11:20 --> Input Class Initialized
INFO - 2024-01-27 07:11:20 --> Language Class Initialized
INFO - 2024-01-27 07:11:20 --> Loader Class Initialized
INFO - 2024-01-27 07:11:20 --> Helper loaded: url_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: file_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: html_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: text_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: form_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: lang_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: security_helper
INFO - 2024-01-27 07:11:20 --> Helper loaded: cookie_helper
INFO - 2024-01-27 07:11:20 --> Database Driver Class Initialized
INFO - 2024-01-27 07:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 07:11:20 --> Parser Class Initialized
INFO - 2024-01-27 07:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 07:11:20 --> Pagination Class Initialized
INFO - 2024-01-27 07:11:20 --> Form Validation Class Initialized
INFO - 2024-01-27 07:11:20 --> Controller Class Initialized
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
DEBUG - 2024-01-27 07:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
DEBUG - 2024-01-27 07:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
DEBUG - 2024-01-27 07:11:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 07:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
INFO - 2024-01-27 07:11:20 --> Model Class Initialized
INFO - 2024-01-27 07:11:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 07:11:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 07:11:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 07:11:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 07:11:21 --> Model Class Initialized
INFO - 2024-01-27 07:11:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 07:11:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 07:11:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 07:11:21 --> Final output sent to browser
DEBUG - 2024-01-27 07:11:21 --> Total execution time: 0.2402
ERROR - 2024-01-27 14:22:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 14:22:20 --> Config Class Initialized
INFO - 2024-01-27 14:22:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 14:22:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 14:22:20 --> Utf8 Class Initialized
INFO - 2024-01-27 14:22:20 --> URI Class Initialized
DEBUG - 2024-01-27 14:22:20 --> No URI present. Default controller set.
INFO - 2024-01-27 14:22:20 --> Router Class Initialized
INFO - 2024-01-27 14:22:20 --> Output Class Initialized
INFO - 2024-01-27 14:22:20 --> Security Class Initialized
DEBUG - 2024-01-27 14:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 14:22:20 --> Input Class Initialized
INFO - 2024-01-27 14:22:20 --> Language Class Initialized
INFO - 2024-01-27 14:22:20 --> Loader Class Initialized
INFO - 2024-01-27 14:22:20 --> Helper loaded: url_helper
INFO - 2024-01-27 14:22:20 --> Helper loaded: file_helper
INFO - 2024-01-27 14:22:20 --> Helper loaded: html_helper
INFO - 2024-01-27 14:22:20 --> Helper loaded: text_helper
INFO - 2024-01-27 14:22:20 --> Helper loaded: form_helper
INFO - 2024-01-27 14:22:20 --> Helper loaded: lang_helper
INFO - 2024-01-27 14:22:20 --> Helper loaded: security_helper
INFO - 2024-01-27 14:22:20 --> Helper loaded: cookie_helper
INFO - 2024-01-27 14:22:20 --> Database Driver Class Initialized
INFO - 2024-01-27 14:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 14:22:20 --> Parser Class Initialized
INFO - 2024-01-27 14:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 14:22:20 --> Pagination Class Initialized
INFO - 2024-01-27 14:22:20 --> Form Validation Class Initialized
INFO - 2024-01-27 14:22:20 --> Controller Class Initialized
INFO - 2024-01-27 14:22:20 --> Model Class Initialized
DEBUG - 2024-01-27 14:22:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 14:22:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 14:22:21 --> Config Class Initialized
INFO - 2024-01-27 14:22:21 --> Hooks Class Initialized
DEBUG - 2024-01-27 14:22:21 --> UTF-8 Support Enabled
INFO - 2024-01-27 14:22:21 --> Utf8 Class Initialized
INFO - 2024-01-27 14:22:21 --> URI Class Initialized
INFO - 2024-01-27 14:22:21 --> Router Class Initialized
INFO - 2024-01-27 14:22:21 --> Output Class Initialized
INFO - 2024-01-27 14:22:21 --> Security Class Initialized
DEBUG - 2024-01-27 14:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 14:22:21 --> Input Class Initialized
INFO - 2024-01-27 14:22:21 --> Language Class Initialized
INFO - 2024-01-27 14:22:21 --> Loader Class Initialized
INFO - 2024-01-27 14:22:21 --> Helper loaded: url_helper
INFO - 2024-01-27 14:22:21 --> Helper loaded: file_helper
INFO - 2024-01-27 14:22:21 --> Helper loaded: html_helper
INFO - 2024-01-27 14:22:21 --> Helper loaded: text_helper
INFO - 2024-01-27 14:22:21 --> Helper loaded: form_helper
INFO - 2024-01-27 14:22:21 --> Helper loaded: lang_helper
INFO - 2024-01-27 14:22:21 --> Helper loaded: security_helper
INFO - 2024-01-27 14:22:21 --> Helper loaded: cookie_helper
INFO - 2024-01-27 14:22:21 --> Database Driver Class Initialized
INFO - 2024-01-27 14:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 14:22:21 --> Parser Class Initialized
INFO - 2024-01-27 14:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 14:22:21 --> Pagination Class Initialized
INFO - 2024-01-27 14:22:21 --> Form Validation Class Initialized
INFO - 2024-01-27 14:22:21 --> Controller Class Initialized
INFO - 2024-01-27 14:22:21 --> Model Class Initialized
DEBUG - 2024-01-27 14:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 14:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 14:22:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 14:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 14:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 14:22:21 --> Model Class Initialized
INFO - 2024-01-27 14:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 14:22:21 --> Final output sent to browser
DEBUG - 2024-01-27 14:22:21 --> Total execution time: 0.0324
ERROR - 2024-01-27 15:05:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:05:36 --> Config Class Initialized
INFO - 2024-01-27 15:05:36 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:05:36 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:05:36 --> Utf8 Class Initialized
INFO - 2024-01-27 15:05:36 --> URI Class Initialized
DEBUG - 2024-01-27 15:05:36 --> No URI present. Default controller set.
INFO - 2024-01-27 15:05:36 --> Router Class Initialized
INFO - 2024-01-27 15:05:36 --> Output Class Initialized
INFO - 2024-01-27 15:05:36 --> Security Class Initialized
DEBUG - 2024-01-27 15:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:05:36 --> Input Class Initialized
INFO - 2024-01-27 15:05:36 --> Language Class Initialized
INFO - 2024-01-27 15:05:36 --> Loader Class Initialized
INFO - 2024-01-27 15:05:36 --> Helper loaded: url_helper
INFO - 2024-01-27 15:05:36 --> Helper loaded: file_helper
INFO - 2024-01-27 15:05:36 --> Helper loaded: html_helper
INFO - 2024-01-27 15:05:36 --> Helper loaded: text_helper
INFO - 2024-01-27 15:05:36 --> Helper loaded: form_helper
INFO - 2024-01-27 15:05:36 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:05:36 --> Helper loaded: security_helper
INFO - 2024-01-27 15:05:36 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:05:36 --> Database Driver Class Initialized
INFO - 2024-01-27 15:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:05:36 --> Parser Class Initialized
INFO - 2024-01-27 15:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:05:36 --> Pagination Class Initialized
INFO - 2024-01-27 15:05:36 --> Form Validation Class Initialized
INFO - 2024-01-27 15:05:36 --> Controller Class Initialized
INFO - 2024-01-27 15:05:36 --> Model Class Initialized
DEBUG - 2024-01-27 15:05:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 15:05:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:05:37 --> Config Class Initialized
INFO - 2024-01-27 15:05:37 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:05:37 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:05:37 --> Utf8 Class Initialized
INFO - 2024-01-27 15:05:37 --> URI Class Initialized
INFO - 2024-01-27 15:05:37 --> Router Class Initialized
INFO - 2024-01-27 15:05:37 --> Output Class Initialized
INFO - 2024-01-27 15:05:37 --> Security Class Initialized
DEBUG - 2024-01-27 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:05:37 --> Input Class Initialized
INFO - 2024-01-27 15:05:37 --> Language Class Initialized
INFO - 2024-01-27 15:05:37 --> Loader Class Initialized
INFO - 2024-01-27 15:05:37 --> Helper loaded: url_helper
INFO - 2024-01-27 15:05:37 --> Helper loaded: file_helper
INFO - 2024-01-27 15:05:37 --> Helper loaded: html_helper
INFO - 2024-01-27 15:05:37 --> Helper loaded: text_helper
INFO - 2024-01-27 15:05:37 --> Helper loaded: form_helper
INFO - 2024-01-27 15:05:37 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:05:37 --> Helper loaded: security_helper
INFO - 2024-01-27 15:05:37 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:05:37 --> Database Driver Class Initialized
INFO - 2024-01-27 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:05:37 --> Parser Class Initialized
INFO - 2024-01-27 15:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:05:37 --> Pagination Class Initialized
INFO - 2024-01-27 15:05:37 --> Form Validation Class Initialized
INFO - 2024-01-27 15:05:37 --> Controller Class Initialized
INFO - 2024-01-27 15:05:37 --> Model Class Initialized
DEBUG - 2024-01-27 15:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 15:05:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 15:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 15:05:37 --> Model Class Initialized
INFO - 2024-01-27 15:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 15:05:37 --> Final output sent to browser
DEBUG - 2024-01-27 15:05:37 --> Total execution time: 0.0331
ERROR - 2024-01-27 15:06:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:06:10 --> Config Class Initialized
INFO - 2024-01-27 15:06:10 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:06:10 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:06:10 --> Utf8 Class Initialized
INFO - 2024-01-27 15:06:10 --> URI Class Initialized
DEBUG - 2024-01-27 15:06:10 --> No URI present. Default controller set.
INFO - 2024-01-27 15:06:10 --> Router Class Initialized
INFO - 2024-01-27 15:06:10 --> Output Class Initialized
INFO - 2024-01-27 15:06:10 --> Security Class Initialized
DEBUG - 2024-01-27 15:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:06:10 --> Input Class Initialized
INFO - 2024-01-27 15:06:10 --> Language Class Initialized
INFO - 2024-01-27 15:06:10 --> Loader Class Initialized
INFO - 2024-01-27 15:06:10 --> Helper loaded: url_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: file_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: html_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: text_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: form_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: security_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:06:10 --> Database Driver Class Initialized
INFO - 2024-01-27 15:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:06:10 --> Parser Class Initialized
INFO - 2024-01-27 15:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:06:10 --> Pagination Class Initialized
INFO - 2024-01-27 15:06:10 --> Form Validation Class Initialized
INFO - 2024-01-27 15:06:10 --> Controller Class Initialized
INFO - 2024-01-27 15:06:10 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 15:06:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:06:10 --> Config Class Initialized
INFO - 2024-01-27 15:06:10 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:06:10 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:06:10 --> Utf8 Class Initialized
INFO - 2024-01-27 15:06:10 --> URI Class Initialized
INFO - 2024-01-27 15:06:10 --> Router Class Initialized
INFO - 2024-01-27 15:06:10 --> Output Class Initialized
INFO - 2024-01-27 15:06:10 --> Security Class Initialized
DEBUG - 2024-01-27 15:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:06:10 --> Input Class Initialized
INFO - 2024-01-27 15:06:10 --> Language Class Initialized
INFO - 2024-01-27 15:06:10 --> Loader Class Initialized
INFO - 2024-01-27 15:06:10 --> Helper loaded: url_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: file_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: html_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: text_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: form_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: security_helper
INFO - 2024-01-27 15:06:10 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:06:10 --> Database Driver Class Initialized
INFO - 2024-01-27 15:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:06:10 --> Parser Class Initialized
INFO - 2024-01-27 15:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:06:10 --> Pagination Class Initialized
INFO - 2024-01-27 15:06:10 --> Form Validation Class Initialized
INFO - 2024-01-27 15:06:10 --> Controller Class Initialized
INFO - 2024-01-27 15:06:10 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 15:06:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 15:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 15:06:10 --> Model Class Initialized
INFO - 2024-01-27 15:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 15:06:10 --> Final output sent to browser
DEBUG - 2024-01-27 15:06:10 --> Total execution time: 0.0318
ERROR - 2024-01-27 15:06:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:06:20 --> Config Class Initialized
INFO - 2024-01-27 15:06:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:06:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:06:20 --> Utf8 Class Initialized
INFO - 2024-01-27 15:06:20 --> URI Class Initialized
INFO - 2024-01-27 15:06:20 --> Router Class Initialized
INFO - 2024-01-27 15:06:20 --> Output Class Initialized
INFO - 2024-01-27 15:06:20 --> Security Class Initialized
DEBUG - 2024-01-27 15:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:06:20 --> Input Class Initialized
INFO - 2024-01-27 15:06:20 --> Language Class Initialized
INFO - 2024-01-27 15:06:20 --> Loader Class Initialized
INFO - 2024-01-27 15:06:20 --> Helper loaded: url_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: file_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: html_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: text_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: form_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: security_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:06:20 --> Database Driver Class Initialized
INFO - 2024-01-27 15:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:06:20 --> Parser Class Initialized
INFO - 2024-01-27 15:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:06:20 --> Pagination Class Initialized
INFO - 2024-01-27 15:06:20 --> Form Validation Class Initialized
INFO - 2024-01-27 15:06:20 --> Controller Class Initialized
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
INFO - 2024-01-27 15:06:20 --> Final output sent to browser
DEBUG - 2024-01-27 15:06:20 --> Total execution time: 0.0181
ERROR - 2024-01-27 15:06:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:06:20 --> Config Class Initialized
INFO - 2024-01-27 15:06:20 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:06:20 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:06:20 --> Utf8 Class Initialized
INFO - 2024-01-27 15:06:20 --> URI Class Initialized
DEBUG - 2024-01-27 15:06:20 --> No URI present. Default controller set.
INFO - 2024-01-27 15:06:20 --> Router Class Initialized
INFO - 2024-01-27 15:06:20 --> Output Class Initialized
INFO - 2024-01-27 15:06:20 --> Security Class Initialized
DEBUG - 2024-01-27 15:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:06:20 --> Input Class Initialized
INFO - 2024-01-27 15:06:20 --> Language Class Initialized
INFO - 2024-01-27 15:06:20 --> Loader Class Initialized
INFO - 2024-01-27 15:06:20 --> Helper loaded: url_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: file_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: html_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: text_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: form_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: security_helper
INFO - 2024-01-27 15:06:20 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:06:20 --> Database Driver Class Initialized
INFO - 2024-01-27 15:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:06:20 --> Parser Class Initialized
INFO - 2024-01-27 15:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:06:20 --> Pagination Class Initialized
INFO - 2024-01-27 15:06:20 --> Form Validation Class Initialized
INFO - 2024-01-27 15:06:20 --> Controller Class Initialized
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 15:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
INFO - 2024-01-27 15:06:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 15:06:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 15:06:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 15:06:20 --> Model Class Initialized
INFO - 2024-01-27 15:06:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 15:06:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 15:06:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 15:06:20 --> Final output sent to browser
DEBUG - 2024-01-27 15:06:20 --> Total execution time: 0.4329
ERROR - 2024-01-27 15:06:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:06:21 --> Config Class Initialized
INFO - 2024-01-27 15:06:21 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:06:21 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:06:21 --> Utf8 Class Initialized
INFO - 2024-01-27 15:06:21 --> URI Class Initialized
INFO - 2024-01-27 15:06:21 --> Router Class Initialized
INFO - 2024-01-27 15:06:21 --> Output Class Initialized
INFO - 2024-01-27 15:06:21 --> Security Class Initialized
DEBUG - 2024-01-27 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:06:21 --> Input Class Initialized
INFO - 2024-01-27 15:06:21 --> Language Class Initialized
INFO - 2024-01-27 15:06:21 --> Loader Class Initialized
INFO - 2024-01-27 15:06:21 --> Helper loaded: url_helper
INFO - 2024-01-27 15:06:21 --> Helper loaded: file_helper
INFO - 2024-01-27 15:06:21 --> Helper loaded: html_helper
INFO - 2024-01-27 15:06:21 --> Helper loaded: text_helper
INFO - 2024-01-27 15:06:21 --> Helper loaded: form_helper
INFO - 2024-01-27 15:06:21 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:06:21 --> Helper loaded: security_helper
INFO - 2024-01-27 15:06:21 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:06:21 --> Database Driver Class Initialized
INFO - 2024-01-27 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:06:21 --> Parser Class Initialized
INFO - 2024-01-27 15:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:06:21 --> Pagination Class Initialized
INFO - 2024-01-27 15:06:21 --> Form Validation Class Initialized
INFO - 2024-01-27 15:06:21 --> Controller Class Initialized
DEBUG - 2024-01-27 15:06:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 15:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:21 --> Model Class Initialized
INFO - 2024-01-27 15:06:21 --> Final output sent to browser
DEBUG - 2024-01-27 15:06:21 --> Total execution time: 0.0128
ERROR - 2024-01-27 15:06:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:06:42 --> Config Class Initialized
INFO - 2024-01-27 15:06:42 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:06:42 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:06:42 --> Utf8 Class Initialized
INFO - 2024-01-27 15:06:42 --> URI Class Initialized
INFO - 2024-01-27 15:06:42 --> Router Class Initialized
INFO - 2024-01-27 15:06:42 --> Output Class Initialized
INFO - 2024-01-27 15:06:42 --> Security Class Initialized
DEBUG - 2024-01-27 15:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:06:42 --> Input Class Initialized
INFO - 2024-01-27 15:06:42 --> Language Class Initialized
INFO - 2024-01-27 15:06:42 --> Loader Class Initialized
INFO - 2024-01-27 15:06:42 --> Helper loaded: url_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: file_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: html_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: text_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: form_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: security_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:06:42 --> Database Driver Class Initialized
INFO - 2024-01-27 15:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:06:42 --> Parser Class Initialized
INFO - 2024-01-27 15:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:06:42 --> Pagination Class Initialized
INFO - 2024-01-27 15:06:42 --> Form Validation Class Initialized
INFO - 2024-01-27 15:06:42 --> Controller Class Initialized
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 15:06:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 15:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
INFO - 2024-01-27 15:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 15:06:42 --> Final output sent to browser
DEBUG - 2024-01-27 15:06:42 --> Total execution time: 0.0321
ERROR - 2024-01-27 15:06:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:06:42 --> Config Class Initialized
INFO - 2024-01-27 15:06:42 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:06:42 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:06:42 --> Utf8 Class Initialized
INFO - 2024-01-27 15:06:42 --> URI Class Initialized
INFO - 2024-01-27 15:06:42 --> Router Class Initialized
INFO - 2024-01-27 15:06:42 --> Output Class Initialized
INFO - 2024-01-27 15:06:42 --> Security Class Initialized
DEBUG - 2024-01-27 15:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:06:42 --> Input Class Initialized
INFO - 2024-01-27 15:06:42 --> Language Class Initialized
INFO - 2024-01-27 15:06:42 --> Loader Class Initialized
INFO - 2024-01-27 15:06:42 --> Helper loaded: url_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: file_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: html_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: text_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: form_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: security_helper
INFO - 2024-01-27 15:06:42 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:06:42 --> Database Driver Class Initialized
INFO - 2024-01-27 15:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:06:42 --> Parser Class Initialized
INFO - 2024-01-27 15:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:06:42 --> Pagination Class Initialized
INFO - 2024-01-27 15:06:42 --> Form Validation Class Initialized
INFO - 2024-01-27 15:06:42 --> Controller Class Initialized
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
DEBUG - 2024-01-27 15:06:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 15:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
INFO - 2024-01-27 15:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 15:06:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 15:06:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 15:06:42 --> Model Class Initialized
INFO - 2024-01-27 15:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 15:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 15:06:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 15:06:43 --> Final output sent to browser
DEBUG - 2024-01-27 15:06:43 --> Total execution time: 0.4133
ERROR - 2024-01-27 15:07:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:07:06 --> Config Class Initialized
INFO - 2024-01-27 15:07:06 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:07:06 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:07:06 --> Utf8 Class Initialized
INFO - 2024-01-27 15:07:06 --> URI Class Initialized
INFO - 2024-01-27 15:07:06 --> Router Class Initialized
INFO - 2024-01-27 15:07:06 --> Output Class Initialized
INFO - 2024-01-27 15:07:06 --> Security Class Initialized
DEBUG - 2024-01-27 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:07:06 --> Input Class Initialized
INFO - 2024-01-27 15:07:06 --> Language Class Initialized
INFO - 2024-01-27 15:07:06 --> Loader Class Initialized
INFO - 2024-01-27 15:07:06 --> Helper loaded: url_helper
INFO - 2024-01-27 15:07:06 --> Helper loaded: file_helper
INFO - 2024-01-27 15:07:06 --> Helper loaded: html_helper
INFO - 2024-01-27 15:07:06 --> Helper loaded: text_helper
INFO - 2024-01-27 15:07:06 --> Helper loaded: form_helper
INFO - 2024-01-27 15:07:06 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:07:06 --> Helper loaded: security_helper
INFO - 2024-01-27 15:07:06 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:07:06 --> Database Driver Class Initialized
INFO - 2024-01-27 15:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:07:06 --> Parser Class Initialized
INFO - 2024-01-27 15:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:07:06 --> Pagination Class Initialized
INFO - 2024-01-27 15:07:06 --> Form Validation Class Initialized
INFO - 2024-01-27 15:07:06 --> Controller Class Initialized
INFO - 2024-01-27 15:07:06 --> Model Class Initialized
DEBUG - 2024-01-27 15:07:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 15:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:06 --> Model Class Initialized
DEBUG - 2024-01-27 15:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:06 --> Model Class Initialized
INFO - 2024-01-27 15:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-27 15:07:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 15:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 15:07:06 --> Model Class Initialized
INFO - 2024-01-27 15:07:06 --> Model Class Initialized
INFO - 2024-01-27 15:07:06 --> Model Class Initialized
INFO - 2024-01-27 15:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 15:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 15:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 15:07:06 --> Final output sent to browser
DEBUG - 2024-01-27 15:07:06 --> Total execution time: 0.2256
ERROR - 2024-01-27 15:07:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:07:07 --> Config Class Initialized
INFO - 2024-01-27 15:07:07 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:07:07 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:07:07 --> Utf8 Class Initialized
INFO - 2024-01-27 15:07:07 --> URI Class Initialized
INFO - 2024-01-27 15:07:07 --> Router Class Initialized
INFO - 2024-01-27 15:07:07 --> Output Class Initialized
INFO - 2024-01-27 15:07:07 --> Security Class Initialized
DEBUG - 2024-01-27 15:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:07:07 --> Input Class Initialized
INFO - 2024-01-27 15:07:07 --> Language Class Initialized
INFO - 2024-01-27 15:07:07 --> Loader Class Initialized
INFO - 2024-01-27 15:07:07 --> Helper loaded: url_helper
INFO - 2024-01-27 15:07:07 --> Helper loaded: file_helper
INFO - 2024-01-27 15:07:07 --> Helper loaded: html_helper
INFO - 2024-01-27 15:07:07 --> Helper loaded: text_helper
INFO - 2024-01-27 15:07:07 --> Helper loaded: form_helper
INFO - 2024-01-27 15:07:07 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:07:07 --> Helper loaded: security_helper
INFO - 2024-01-27 15:07:07 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:07:07 --> Database Driver Class Initialized
INFO - 2024-01-27 15:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:07:07 --> Parser Class Initialized
INFO - 2024-01-27 15:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:07:07 --> Pagination Class Initialized
INFO - 2024-01-27 15:07:07 --> Form Validation Class Initialized
INFO - 2024-01-27 15:07:07 --> Controller Class Initialized
INFO - 2024-01-27 15:07:07 --> Model Class Initialized
DEBUG - 2024-01-27 15:07:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 15:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:07 --> Model Class Initialized
DEBUG - 2024-01-27 15:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:07 --> Model Class Initialized
INFO - 2024-01-27 15:07:07 --> Final output sent to browser
DEBUG - 2024-01-27 15:07:07 --> Total execution time: 0.0606
ERROR - 2024-01-27 15:07:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 15:07:28 --> Config Class Initialized
INFO - 2024-01-27 15:07:28 --> Hooks Class Initialized
DEBUG - 2024-01-27 15:07:28 --> UTF-8 Support Enabled
INFO - 2024-01-27 15:07:28 --> Utf8 Class Initialized
INFO - 2024-01-27 15:07:28 --> URI Class Initialized
INFO - 2024-01-27 15:07:28 --> Router Class Initialized
INFO - 2024-01-27 15:07:28 --> Output Class Initialized
INFO - 2024-01-27 15:07:28 --> Security Class Initialized
DEBUG - 2024-01-27 15:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 15:07:28 --> Input Class Initialized
INFO - 2024-01-27 15:07:28 --> Language Class Initialized
INFO - 2024-01-27 15:07:28 --> Loader Class Initialized
INFO - 2024-01-27 15:07:28 --> Helper loaded: url_helper
INFO - 2024-01-27 15:07:28 --> Helper loaded: file_helper
INFO - 2024-01-27 15:07:28 --> Helper loaded: html_helper
INFO - 2024-01-27 15:07:28 --> Helper loaded: text_helper
INFO - 2024-01-27 15:07:28 --> Helper loaded: form_helper
INFO - 2024-01-27 15:07:28 --> Helper loaded: lang_helper
INFO - 2024-01-27 15:07:28 --> Helper loaded: security_helper
INFO - 2024-01-27 15:07:28 --> Helper loaded: cookie_helper
INFO - 2024-01-27 15:07:28 --> Database Driver Class Initialized
INFO - 2024-01-27 15:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 15:07:28 --> Parser Class Initialized
INFO - 2024-01-27 15:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 15:07:28 --> Pagination Class Initialized
INFO - 2024-01-27 15:07:28 --> Form Validation Class Initialized
INFO - 2024-01-27 15:07:28 --> Controller Class Initialized
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
DEBUG - 2024-01-27 15:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
DEBUG - 2024-01-27 15:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
DEBUG - 2024-01-27 15:07:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-27 15:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
INFO - 2024-01-27 15:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-27 15:07:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 15:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 15:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 15:07:28 --> Model Class Initialized
INFO - 2024-01-27 15:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-27 15:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-27 15:07:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 15:07:28 --> Final output sent to browser
DEBUG - 2024-01-27 15:07:28 --> Total execution time: 0.4132
ERROR - 2024-01-27 17:32:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 17:32:41 --> Config Class Initialized
INFO - 2024-01-27 17:32:41 --> Hooks Class Initialized
DEBUG - 2024-01-27 17:32:41 --> UTF-8 Support Enabled
INFO - 2024-01-27 17:32:41 --> Utf8 Class Initialized
INFO - 2024-01-27 17:32:41 --> URI Class Initialized
INFO - 2024-01-27 17:32:41 --> Router Class Initialized
INFO - 2024-01-27 17:32:41 --> Output Class Initialized
INFO - 2024-01-27 17:32:41 --> Security Class Initialized
DEBUG - 2024-01-27 17:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 17:32:41 --> Input Class Initialized
INFO - 2024-01-27 17:32:41 --> Language Class Initialized
ERROR - 2024-01-27 17:32:41 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-27 18:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 18:39:05 --> Config Class Initialized
INFO - 2024-01-27 18:39:05 --> Hooks Class Initialized
DEBUG - 2024-01-27 18:39:05 --> UTF-8 Support Enabled
INFO - 2024-01-27 18:39:05 --> Utf8 Class Initialized
INFO - 2024-01-27 18:39:05 --> URI Class Initialized
DEBUG - 2024-01-27 18:39:05 --> No URI present. Default controller set.
INFO - 2024-01-27 18:39:05 --> Router Class Initialized
INFO - 2024-01-27 18:39:05 --> Output Class Initialized
INFO - 2024-01-27 18:39:05 --> Security Class Initialized
DEBUG - 2024-01-27 18:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 18:39:05 --> Input Class Initialized
INFO - 2024-01-27 18:39:05 --> Language Class Initialized
INFO - 2024-01-27 18:39:05 --> Loader Class Initialized
INFO - 2024-01-27 18:39:05 --> Helper loaded: url_helper
INFO - 2024-01-27 18:39:05 --> Helper loaded: file_helper
INFO - 2024-01-27 18:39:05 --> Helper loaded: html_helper
INFO - 2024-01-27 18:39:05 --> Helper loaded: text_helper
INFO - 2024-01-27 18:39:05 --> Helper loaded: form_helper
INFO - 2024-01-27 18:39:05 --> Helper loaded: lang_helper
INFO - 2024-01-27 18:39:05 --> Helper loaded: security_helper
INFO - 2024-01-27 18:39:05 --> Helper loaded: cookie_helper
INFO - 2024-01-27 18:39:05 --> Database Driver Class Initialized
INFO - 2024-01-27 18:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 18:39:05 --> Parser Class Initialized
INFO - 2024-01-27 18:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 18:39:05 --> Pagination Class Initialized
INFO - 2024-01-27 18:39:05 --> Form Validation Class Initialized
INFO - 2024-01-27 18:39:05 --> Controller Class Initialized
INFO - 2024-01-27 18:39:05 --> Model Class Initialized
DEBUG - 2024-01-27 18:39:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-27 18:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-27 18:39:06 --> Config Class Initialized
INFO - 2024-01-27 18:39:06 --> Hooks Class Initialized
DEBUG - 2024-01-27 18:39:06 --> UTF-8 Support Enabled
INFO - 2024-01-27 18:39:06 --> Utf8 Class Initialized
INFO - 2024-01-27 18:39:06 --> URI Class Initialized
INFO - 2024-01-27 18:39:06 --> Router Class Initialized
INFO - 2024-01-27 18:39:06 --> Output Class Initialized
INFO - 2024-01-27 18:39:06 --> Security Class Initialized
DEBUG - 2024-01-27 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-27 18:39:06 --> Input Class Initialized
INFO - 2024-01-27 18:39:06 --> Language Class Initialized
INFO - 2024-01-27 18:39:06 --> Loader Class Initialized
INFO - 2024-01-27 18:39:06 --> Helper loaded: url_helper
INFO - 2024-01-27 18:39:06 --> Helper loaded: file_helper
INFO - 2024-01-27 18:39:06 --> Helper loaded: html_helper
INFO - 2024-01-27 18:39:06 --> Helper loaded: text_helper
INFO - 2024-01-27 18:39:06 --> Helper loaded: form_helper
INFO - 2024-01-27 18:39:06 --> Helper loaded: lang_helper
INFO - 2024-01-27 18:39:06 --> Helper loaded: security_helper
INFO - 2024-01-27 18:39:06 --> Helper loaded: cookie_helper
INFO - 2024-01-27 18:39:06 --> Database Driver Class Initialized
INFO - 2024-01-27 18:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-27 18:39:06 --> Parser Class Initialized
INFO - 2024-01-27 18:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-27 18:39:06 --> Pagination Class Initialized
INFO - 2024-01-27 18:39:06 --> Form Validation Class Initialized
INFO - 2024-01-27 18:39:06 --> Controller Class Initialized
INFO - 2024-01-27 18:39:06 --> Model Class Initialized
DEBUG - 2024-01-27 18:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-27 18:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-27 18:39:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-27 18:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-27 18:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-27 18:39:06 --> Model Class Initialized
INFO - 2024-01-27 18:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-27 18:39:06 --> Final output sent to browser
DEBUG - 2024-01-27 18:39:06 --> Total execution time: 0.0389
