<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-23 10:15:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:15:33 --> Config Class Initialized
INFO - 2024-01-23 10:15:33 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:15:33 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:15:33 --> Utf8 Class Initialized
INFO - 2024-01-23 10:15:33 --> URI Class Initialized
DEBUG - 2024-01-23 10:15:33 --> No URI present. Default controller set.
INFO - 2024-01-23 10:15:33 --> Router Class Initialized
INFO - 2024-01-23 10:15:33 --> Output Class Initialized
INFO - 2024-01-23 10:15:33 --> Security Class Initialized
DEBUG - 2024-01-23 10:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:15:33 --> Input Class Initialized
INFO - 2024-01-23 10:15:33 --> Language Class Initialized
INFO - 2024-01-23 10:15:33 --> Loader Class Initialized
INFO - 2024-01-23 10:15:33 --> Helper loaded: url_helper
INFO - 2024-01-23 10:15:33 --> Helper loaded: file_helper
INFO - 2024-01-23 10:15:33 --> Helper loaded: html_helper
INFO - 2024-01-23 10:15:33 --> Helper loaded: text_helper
INFO - 2024-01-23 10:15:33 --> Helper loaded: form_helper
INFO - 2024-01-23 10:15:33 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:15:33 --> Helper loaded: security_helper
INFO - 2024-01-23 10:15:33 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:15:33 --> Database Driver Class Initialized
INFO - 2024-01-23 10:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:15:33 --> Parser Class Initialized
INFO - 2024-01-23 10:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:15:33 --> Pagination Class Initialized
INFO - 2024-01-23 10:15:33 --> Form Validation Class Initialized
INFO - 2024-01-23 10:15:33 --> Controller Class Initialized
INFO - 2024-01-23 10:15:33 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-23 10:15:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:15:34 --> Config Class Initialized
INFO - 2024-01-23 10:15:34 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:15:34 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:15:34 --> Utf8 Class Initialized
INFO - 2024-01-23 10:15:34 --> URI Class Initialized
INFO - 2024-01-23 10:15:34 --> Router Class Initialized
INFO - 2024-01-23 10:15:34 --> Output Class Initialized
INFO - 2024-01-23 10:15:34 --> Security Class Initialized
DEBUG - 2024-01-23 10:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:15:34 --> Input Class Initialized
INFO - 2024-01-23 10:15:34 --> Language Class Initialized
INFO - 2024-01-23 10:15:34 --> Loader Class Initialized
INFO - 2024-01-23 10:15:34 --> Helper loaded: url_helper
INFO - 2024-01-23 10:15:34 --> Helper loaded: file_helper
INFO - 2024-01-23 10:15:34 --> Helper loaded: html_helper
INFO - 2024-01-23 10:15:34 --> Helper loaded: text_helper
INFO - 2024-01-23 10:15:34 --> Helper loaded: form_helper
INFO - 2024-01-23 10:15:34 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:15:34 --> Helper loaded: security_helper
INFO - 2024-01-23 10:15:34 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:15:34 --> Database Driver Class Initialized
INFO - 2024-01-23 10:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:15:34 --> Parser Class Initialized
INFO - 2024-01-23 10:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:15:34 --> Pagination Class Initialized
INFO - 2024-01-23 10:15:34 --> Form Validation Class Initialized
INFO - 2024-01-23 10:15:34 --> Controller Class Initialized
INFO - 2024-01-23 10:15:34 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 10:15:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:15:34 --> Model Class Initialized
INFO - 2024-01-23 10:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:15:34 --> Final output sent to browser
DEBUG - 2024-01-23 10:15:34 --> Total execution time: 0.0352
ERROR - 2024-01-23 10:15:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:15:47 --> Config Class Initialized
INFO - 2024-01-23 10:15:47 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:15:47 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:15:47 --> Utf8 Class Initialized
INFO - 2024-01-23 10:15:47 --> URI Class Initialized
INFO - 2024-01-23 10:15:47 --> Router Class Initialized
INFO - 2024-01-23 10:15:47 --> Output Class Initialized
INFO - 2024-01-23 10:15:47 --> Security Class Initialized
DEBUG - 2024-01-23 10:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:15:47 --> Input Class Initialized
INFO - 2024-01-23 10:15:47 --> Language Class Initialized
INFO - 2024-01-23 10:15:47 --> Loader Class Initialized
INFO - 2024-01-23 10:15:47 --> Helper loaded: url_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: file_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: html_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: text_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: form_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: security_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:15:47 --> Database Driver Class Initialized
INFO - 2024-01-23 10:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:15:47 --> Parser Class Initialized
INFO - 2024-01-23 10:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:15:47 --> Pagination Class Initialized
INFO - 2024-01-23 10:15:47 --> Form Validation Class Initialized
INFO - 2024-01-23 10:15:47 --> Controller Class Initialized
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
INFO - 2024-01-23 10:15:47 --> Final output sent to browser
DEBUG - 2024-01-23 10:15:47 --> Total execution time: 0.0237
ERROR - 2024-01-23 10:15:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:15:47 --> Config Class Initialized
INFO - 2024-01-23 10:15:47 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:15:47 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:15:47 --> Utf8 Class Initialized
INFO - 2024-01-23 10:15:47 --> URI Class Initialized
DEBUG - 2024-01-23 10:15:47 --> No URI present. Default controller set.
INFO - 2024-01-23 10:15:47 --> Router Class Initialized
INFO - 2024-01-23 10:15:47 --> Output Class Initialized
INFO - 2024-01-23 10:15:47 --> Security Class Initialized
DEBUG - 2024-01-23 10:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:15:47 --> Input Class Initialized
INFO - 2024-01-23 10:15:47 --> Language Class Initialized
INFO - 2024-01-23 10:15:47 --> Loader Class Initialized
INFO - 2024-01-23 10:15:47 --> Helper loaded: url_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: file_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: html_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: text_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: form_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: security_helper
INFO - 2024-01-23 10:15:47 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:15:47 --> Database Driver Class Initialized
INFO - 2024-01-23 10:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:15:47 --> Parser Class Initialized
INFO - 2024-01-23 10:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:15:47 --> Pagination Class Initialized
INFO - 2024-01-23 10:15:47 --> Form Validation Class Initialized
INFO - 2024-01-23 10:15:47 --> Controller Class Initialized
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
INFO - 2024-01-23 10:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 10:15:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:15:47 --> Model Class Initialized
INFO - 2024-01-23 10:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:15:47 --> Final output sent to browser
DEBUG - 2024-01-23 10:15:47 --> Total execution time: 0.2365
ERROR - 2024-01-23 10:15:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:15:52 --> Config Class Initialized
INFO - 2024-01-23 10:15:52 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:15:52 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:15:52 --> Utf8 Class Initialized
INFO - 2024-01-23 10:15:52 --> URI Class Initialized
INFO - 2024-01-23 10:15:52 --> Router Class Initialized
INFO - 2024-01-23 10:15:52 --> Output Class Initialized
INFO - 2024-01-23 10:15:52 --> Security Class Initialized
DEBUG - 2024-01-23 10:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:15:52 --> Input Class Initialized
INFO - 2024-01-23 10:15:52 --> Language Class Initialized
INFO - 2024-01-23 10:15:52 --> Loader Class Initialized
INFO - 2024-01-23 10:15:52 --> Helper loaded: url_helper
INFO - 2024-01-23 10:15:52 --> Helper loaded: file_helper
INFO - 2024-01-23 10:15:52 --> Helper loaded: html_helper
INFO - 2024-01-23 10:15:52 --> Helper loaded: text_helper
INFO - 2024-01-23 10:15:52 --> Helper loaded: form_helper
INFO - 2024-01-23 10:15:52 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:15:52 --> Helper loaded: security_helper
INFO - 2024-01-23 10:15:52 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:15:52 --> Database Driver Class Initialized
INFO - 2024-01-23 10:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:15:52 --> Parser Class Initialized
INFO - 2024-01-23 10:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:15:52 --> Pagination Class Initialized
INFO - 2024-01-23 10:15:52 --> Form Validation Class Initialized
INFO - 2024-01-23 10:15:52 --> Controller Class Initialized
INFO - 2024-01-23 10:15:52 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:52 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:52 --> Model Class Initialized
INFO - 2024-01-23 10:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 10:15:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:15:52 --> Model Class Initialized
INFO - 2024-01-23 10:15:52 --> Model Class Initialized
INFO - 2024-01-23 10:15:52 --> Model Class Initialized
INFO - 2024-01-23 10:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:15:52 --> Final output sent to browser
DEBUG - 2024-01-23 10:15:52 --> Total execution time: 0.1444
ERROR - 2024-01-23 10:15:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:15:53 --> Config Class Initialized
INFO - 2024-01-23 10:15:53 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:15:53 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:15:53 --> Utf8 Class Initialized
INFO - 2024-01-23 10:15:53 --> URI Class Initialized
INFO - 2024-01-23 10:15:53 --> Router Class Initialized
INFO - 2024-01-23 10:15:53 --> Output Class Initialized
INFO - 2024-01-23 10:15:53 --> Security Class Initialized
DEBUG - 2024-01-23 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:15:53 --> Input Class Initialized
INFO - 2024-01-23 10:15:53 --> Language Class Initialized
INFO - 2024-01-23 10:15:53 --> Loader Class Initialized
INFO - 2024-01-23 10:15:53 --> Helper loaded: url_helper
INFO - 2024-01-23 10:15:53 --> Helper loaded: file_helper
INFO - 2024-01-23 10:15:53 --> Helper loaded: html_helper
INFO - 2024-01-23 10:15:53 --> Helper loaded: text_helper
INFO - 2024-01-23 10:15:53 --> Helper loaded: form_helper
INFO - 2024-01-23 10:15:53 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:15:53 --> Helper loaded: security_helper
INFO - 2024-01-23 10:15:53 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:15:53 --> Database Driver Class Initialized
INFO - 2024-01-23 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:15:53 --> Parser Class Initialized
INFO - 2024-01-23 10:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:15:53 --> Pagination Class Initialized
INFO - 2024-01-23 10:15:53 --> Form Validation Class Initialized
INFO - 2024-01-23 10:15:53 --> Controller Class Initialized
INFO - 2024-01-23 10:15:53 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:53 --> Model Class Initialized
DEBUG - 2024-01-23 10:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:15:53 --> Model Class Initialized
INFO - 2024-01-23 10:15:53 --> Final output sent to browser
DEBUG - 2024-01-23 10:15:53 --> Total execution time: 0.0419
ERROR - 2024-01-23 10:16:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:16:01 --> Config Class Initialized
INFO - 2024-01-23 10:16:01 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:16:01 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:16:01 --> Utf8 Class Initialized
INFO - 2024-01-23 10:16:01 --> URI Class Initialized
INFO - 2024-01-23 10:16:01 --> Router Class Initialized
INFO - 2024-01-23 10:16:01 --> Output Class Initialized
INFO - 2024-01-23 10:16:01 --> Security Class Initialized
DEBUG - 2024-01-23 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:16:01 --> Input Class Initialized
INFO - 2024-01-23 10:16:01 --> Language Class Initialized
INFO - 2024-01-23 10:16:01 --> Loader Class Initialized
INFO - 2024-01-23 10:16:01 --> Helper loaded: url_helper
INFO - 2024-01-23 10:16:01 --> Helper loaded: file_helper
INFO - 2024-01-23 10:16:01 --> Helper loaded: html_helper
INFO - 2024-01-23 10:16:01 --> Helper loaded: text_helper
INFO - 2024-01-23 10:16:01 --> Helper loaded: form_helper
INFO - 2024-01-23 10:16:01 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:16:01 --> Helper loaded: security_helper
INFO - 2024-01-23 10:16:01 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:16:01 --> Database Driver Class Initialized
INFO - 2024-01-23 10:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:16:01 --> Parser Class Initialized
INFO - 2024-01-23 10:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:16:01 --> Pagination Class Initialized
INFO - 2024-01-23 10:16:01 --> Form Validation Class Initialized
INFO - 2024-01-23 10:16:01 --> Controller Class Initialized
INFO - 2024-01-23 10:16:01 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:01 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:01 --> Model Class Initialized
INFO - 2024-01-23 10:16:01 --> Final output sent to browser
DEBUG - 2024-01-23 10:16:01 --> Total execution time: 0.1132
ERROR - 2024-01-23 10:16:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:16:21 --> Config Class Initialized
INFO - 2024-01-23 10:16:21 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:16:21 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:16:21 --> Utf8 Class Initialized
INFO - 2024-01-23 10:16:21 --> URI Class Initialized
INFO - 2024-01-23 10:16:21 --> Router Class Initialized
INFO - 2024-01-23 10:16:21 --> Output Class Initialized
INFO - 2024-01-23 10:16:21 --> Security Class Initialized
DEBUG - 2024-01-23 10:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:16:21 --> Input Class Initialized
INFO - 2024-01-23 10:16:21 --> Language Class Initialized
INFO - 2024-01-23 10:16:21 --> Loader Class Initialized
INFO - 2024-01-23 10:16:21 --> Helper loaded: url_helper
INFO - 2024-01-23 10:16:21 --> Helper loaded: file_helper
INFO - 2024-01-23 10:16:21 --> Helper loaded: html_helper
INFO - 2024-01-23 10:16:21 --> Helper loaded: text_helper
INFO - 2024-01-23 10:16:21 --> Helper loaded: form_helper
INFO - 2024-01-23 10:16:21 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:16:21 --> Helper loaded: security_helper
INFO - 2024-01-23 10:16:21 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:16:21 --> Database Driver Class Initialized
INFO - 2024-01-23 10:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:16:21 --> Parser Class Initialized
INFO - 2024-01-23 10:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:16:21 --> Pagination Class Initialized
INFO - 2024-01-23 10:16:21 --> Form Validation Class Initialized
INFO - 2024-01-23 10:16:21 --> Controller Class Initialized
INFO - 2024-01-23 10:16:21 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:21 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:21 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-23 10:16:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:16:21 --> Model Class Initialized
INFO - 2024-01-23 10:16:21 --> Model Class Initialized
INFO - 2024-01-23 10:16:21 --> Model Class Initialized
INFO - 2024-01-23 10:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:16:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:16:21 --> Final output sent to browser
DEBUG - 2024-01-23 10:16:21 --> Total execution time: 0.1560
ERROR - 2024-01-23 10:16:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:16:43 --> Config Class Initialized
INFO - 2024-01-23 10:16:43 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:16:43 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:16:43 --> Utf8 Class Initialized
INFO - 2024-01-23 10:16:43 --> URI Class Initialized
INFO - 2024-01-23 10:16:43 --> Router Class Initialized
INFO - 2024-01-23 10:16:43 --> Output Class Initialized
INFO - 2024-01-23 10:16:43 --> Security Class Initialized
DEBUG - 2024-01-23 10:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:16:43 --> Input Class Initialized
INFO - 2024-01-23 10:16:43 --> Language Class Initialized
INFO - 2024-01-23 10:16:43 --> Loader Class Initialized
INFO - 2024-01-23 10:16:43 --> Helper loaded: url_helper
INFO - 2024-01-23 10:16:43 --> Helper loaded: file_helper
INFO - 2024-01-23 10:16:43 --> Helper loaded: html_helper
INFO - 2024-01-23 10:16:43 --> Helper loaded: text_helper
INFO - 2024-01-23 10:16:43 --> Helper loaded: form_helper
INFO - 2024-01-23 10:16:43 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:16:43 --> Helper loaded: security_helper
INFO - 2024-01-23 10:16:43 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:16:43 --> Database Driver Class Initialized
INFO - 2024-01-23 10:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:16:43 --> Parser Class Initialized
INFO - 2024-01-23 10:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:16:43 --> Pagination Class Initialized
INFO - 2024-01-23 10:16:43 --> Form Validation Class Initialized
INFO - 2024-01-23 10:16:43 --> Controller Class Initialized
INFO - 2024-01-23 10:16:43 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:43 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:43 --> Model Class Initialized
INFO - 2024-01-23 10:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 10:16:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:16:43 --> Model Class Initialized
INFO - 2024-01-23 10:16:43 --> Model Class Initialized
INFO - 2024-01-23 10:16:43 --> Model Class Initialized
INFO - 2024-01-23 10:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:16:43 --> Final output sent to browser
DEBUG - 2024-01-23 10:16:43 --> Total execution time: 0.1667
ERROR - 2024-01-23 10:16:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:16:44 --> Config Class Initialized
INFO - 2024-01-23 10:16:44 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:16:44 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:16:44 --> Utf8 Class Initialized
INFO - 2024-01-23 10:16:44 --> URI Class Initialized
INFO - 2024-01-23 10:16:44 --> Router Class Initialized
INFO - 2024-01-23 10:16:44 --> Output Class Initialized
INFO - 2024-01-23 10:16:44 --> Security Class Initialized
DEBUG - 2024-01-23 10:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:16:44 --> Input Class Initialized
INFO - 2024-01-23 10:16:44 --> Language Class Initialized
INFO - 2024-01-23 10:16:44 --> Loader Class Initialized
INFO - 2024-01-23 10:16:44 --> Helper loaded: url_helper
INFO - 2024-01-23 10:16:44 --> Helper loaded: file_helper
INFO - 2024-01-23 10:16:44 --> Helper loaded: html_helper
INFO - 2024-01-23 10:16:44 --> Helper loaded: text_helper
INFO - 2024-01-23 10:16:44 --> Helper loaded: form_helper
INFO - 2024-01-23 10:16:44 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:16:44 --> Helper loaded: security_helper
INFO - 2024-01-23 10:16:44 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:16:44 --> Database Driver Class Initialized
INFO - 2024-01-23 10:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:16:44 --> Parser Class Initialized
INFO - 2024-01-23 10:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:16:44 --> Pagination Class Initialized
INFO - 2024-01-23 10:16:44 --> Form Validation Class Initialized
INFO - 2024-01-23 10:16:44 --> Controller Class Initialized
INFO - 2024-01-23 10:16:44 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:44 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:44 --> Model Class Initialized
INFO - 2024-01-23 10:16:44 --> Final output sent to browser
DEBUG - 2024-01-23 10:16:44 --> Total execution time: 0.0402
ERROR - 2024-01-23 10:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:16:52 --> Config Class Initialized
INFO - 2024-01-23 10:16:52 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:16:52 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:16:52 --> Utf8 Class Initialized
INFO - 2024-01-23 10:16:52 --> URI Class Initialized
INFO - 2024-01-23 10:16:52 --> Router Class Initialized
INFO - 2024-01-23 10:16:52 --> Output Class Initialized
INFO - 2024-01-23 10:16:52 --> Security Class Initialized
DEBUG - 2024-01-23 10:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:16:52 --> Input Class Initialized
INFO - 2024-01-23 10:16:52 --> Language Class Initialized
INFO - 2024-01-23 10:16:52 --> Loader Class Initialized
INFO - 2024-01-23 10:16:52 --> Helper loaded: url_helper
INFO - 2024-01-23 10:16:52 --> Helper loaded: file_helper
INFO - 2024-01-23 10:16:52 --> Helper loaded: html_helper
INFO - 2024-01-23 10:16:52 --> Helper loaded: text_helper
INFO - 2024-01-23 10:16:52 --> Helper loaded: form_helper
INFO - 2024-01-23 10:16:52 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:16:52 --> Helper loaded: security_helper
INFO - 2024-01-23 10:16:52 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:16:52 --> Database Driver Class Initialized
INFO - 2024-01-23 10:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:16:52 --> Parser Class Initialized
INFO - 2024-01-23 10:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:16:52 --> Pagination Class Initialized
INFO - 2024-01-23 10:16:52 --> Form Validation Class Initialized
INFO - 2024-01-23 10:16:52 --> Controller Class Initialized
INFO - 2024-01-23 10:16:52 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:52 --> Model Class Initialized
DEBUG - 2024-01-23 10:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:16:52 --> Model Class Initialized
INFO - 2024-01-23 10:16:53 --> Final output sent to browser
DEBUG - 2024-01-23 10:16:53 --> Total execution time: 0.1096
ERROR - 2024-01-23 10:17:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:17:00 --> Config Class Initialized
INFO - 2024-01-23 10:17:00 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:17:00 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:17:00 --> Utf8 Class Initialized
INFO - 2024-01-23 10:17:00 --> URI Class Initialized
INFO - 2024-01-23 10:17:00 --> Router Class Initialized
INFO - 2024-01-23 10:17:00 --> Output Class Initialized
INFO - 2024-01-23 10:17:00 --> Security Class Initialized
DEBUG - 2024-01-23 10:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:17:00 --> Input Class Initialized
INFO - 2024-01-23 10:17:00 --> Language Class Initialized
INFO - 2024-01-23 10:17:00 --> Loader Class Initialized
INFO - 2024-01-23 10:17:00 --> Helper loaded: url_helper
INFO - 2024-01-23 10:17:00 --> Helper loaded: file_helper
INFO - 2024-01-23 10:17:00 --> Helper loaded: html_helper
INFO - 2024-01-23 10:17:00 --> Helper loaded: text_helper
INFO - 2024-01-23 10:17:00 --> Helper loaded: form_helper
INFO - 2024-01-23 10:17:00 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:17:00 --> Helper loaded: security_helper
INFO - 2024-01-23 10:17:00 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:17:00 --> Database Driver Class Initialized
INFO - 2024-01-23 10:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:17:00 --> Parser Class Initialized
INFO - 2024-01-23 10:17:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:17:00 --> Pagination Class Initialized
INFO - 2024-01-23 10:17:00 --> Form Validation Class Initialized
INFO - 2024-01-23 10:17:00 --> Controller Class Initialized
INFO - 2024-01-23 10:17:00 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:00 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:00 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-23 10:17:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:17:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:17:00 --> Model Class Initialized
INFO - 2024-01-23 10:17:00 --> Model Class Initialized
INFO - 2024-01-23 10:17:00 --> Model Class Initialized
INFO - 2024-01-23 10:17:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:17:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:17:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:17:00 --> Final output sent to browser
DEBUG - 2024-01-23 10:17:00 --> Total execution time: 0.1454
ERROR - 2024-01-23 10:17:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:17:16 --> Config Class Initialized
INFO - 2024-01-23 10:17:16 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:17:16 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:17:16 --> Utf8 Class Initialized
INFO - 2024-01-23 10:17:16 --> URI Class Initialized
INFO - 2024-01-23 10:17:16 --> Router Class Initialized
INFO - 2024-01-23 10:17:16 --> Output Class Initialized
INFO - 2024-01-23 10:17:16 --> Security Class Initialized
DEBUG - 2024-01-23 10:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:17:16 --> Input Class Initialized
INFO - 2024-01-23 10:17:16 --> Language Class Initialized
INFO - 2024-01-23 10:17:16 --> Loader Class Initialized
INFO - 2024-01-23 10:17:16 --> Helper loaded: url_helper
INFO - 2024-01-23 10:17:16 --> Helper loaded: file_helper
INFO - 2024-01-23 10:17:16 --> Helper loaded: html_helper
INFO - 2024-01-23 10:17:16 --> Helper loaded: text_helper
INFO - 2024-01-23 10:17:16 --> Helper loaded: form_helper
INFO - 2024-01-23 10:17:16 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:17:16 --> Helper loaded: security_helper
INFO - 2024-01-23 10:17:16 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:17:16 --> Database Driver Class Initialized
INFO - 2024-01-23 10:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:17:16 --> Parser Class Initialized
INFO - 2024-01-23 10:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:17:16 --> Pagination Class Initialized
INFO - 2024-01-23 10:17:16 --> Form Validation Class Initialized
INFO - 2024-01-23 10:17:16 --> Controller Class Initialized
INFO - 2024-01-23 10:17:16 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:16 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:16 --> Model Class Initialized
INFO - 2024-01-23 10:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 10:17:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:17:16 --> Model Class Initialized
INFO - 2024-01-23 10:17:16 --> Model Class Initialized
INFO - 2024-01-23 10:17:16 --> Model Class Initialized
INFO - 2024-01-23 10:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:17:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:17:17 --> Final output sent to browser
DEBUG - 2024-01-23 10:17:17 --> Total execution time: 0.1479
ERROR - 2024-01-23 10:17:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:17:17 --> Config Class Initialized
INFO - 2024-01-23 10:17:17 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:17:17 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:17:17 --> Utf8 Class Initialized
INFO - 2024-01-23 10:17:17 --> URI Class Initialized
INFO - 2024-01-23 10:17:17 --> Router Class Initialized
INFO - 2024-01-23 10:17:17 --> Output Class Initialized
INFO - 2024-01-23 10:17:17 --> Security Class Initialized
DEBUG - 2024-01-23 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:17:17 --> Input Class Initialized
INFO - 2024-01-23 10:17:17 --> Language Class Initialized
INFO - 2024-01-23 10:17:17 --> Loader Class Initialized
INFO - 2024-01-23 10:17:17 --> Helper loaded: url_helper
INFO - 2024-01-23 10:17:17 --> Helper loaded: file_helper
INFO - 2024-01-23 10:17:17 --> Helper loaded: html_helper
INFO - 2024-01-23 10:17:17 --> Helper loaded: text_helper
INFO - 2024-01-23 10:17:17 --> Helper loaded: form_helper
INFO - 2024-01-23 10:17:17 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:17:17 --> Helper loaded: security_helper
INFO - 2024-01-23 10:17:17 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:17:17 --> Database Driver Class Initialized
INFO - 2024-01-23 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:17:17 --> Parser Class Initialized
INFO - 2024-01-23 10:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:17:17 --> Pagination Class Initialized
INFO - 2024-01-23 10:17:17 --> Form Validation Class Initialized
INFO - 2024-01-23 10:17:17 --> Controller Class Initialized
INFO - 2024-01-23 10:17:17 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:17 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:17 --> Model Class Initialized
INFO - 2024-01-23 10:17:17 --> Final output sent to browser
DEBUG - 2024-01-23 10:17:17 --> Total execution time: 0.0416
ERROR - 2024-01-23 10:17:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:17:27 --> Config Class Initialized
INFO - 2024-01-23 10:17:27 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:17:27 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:17:27 --> Utf8 Class Initialized
INFO - 2024-01-23 10:17:27 --> URI Class Initialized
INFO - 2024-01-23 10:17:27 --> Router Class Initialized
INFO - 2024-01-23 10:17:27 --> Output Class Initialized
INFO - 2024-01-23 10:17:27 --> Security Class Initialized
DEBUG - 2024-01-23 10:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:17:27 --> Input Class Initialized
INFO - 2024-01-23 10:17:27 --> Language Class Initialized
INFO - 2024-01-23 10:17:27 --> Loader Class Initialized
INFO - 2024-01-23 10:17:27 --> Helper loaded: url_helper
INFO - 2024-01-23 10:17:27 --> Helper loaded: file_helper
INFO - 2024-01-23 10:17:27 --> Helper loaded: html_helper
INFO - 2024-01-23 10:17:27 --> Helper loaded: text_helper
INFO - 2024-01-23 10:17:27 --> Helper loaded: form_helper
INFO - 2024-01-23 10:17:27 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:17:27 --> Helper loaded: security_helper
INFO - 2024-01-23 10:17:27 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:17:27 --> Database Driver Class Initialized
INFO - 2024-01-23 10:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:17:27 --> Parser Class Initialized
INFO - 2024-01-23 10:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:17:27 --> Pagination Class Initialized
INFO - 2024-01-23 10:17:27 --> Form Validation Class Initialized
INFO - 2024-01-23 10:17:27 --> Controller Class Initialized
INFO - 2024-01-23 10:17:27 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:27 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:27 --> Model Class Initialized
DEBUG - 2024-01-23 10:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-23 10:17:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:17:27 --> Model Class Initialized
INFO - 2024-01-23 10:17:27 --> Model Class Initialized
INFO - 2024-01-23 10:17:27 --> Model Class Initialized
INFO - 2024-01-23 10:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:17:27 --> Final output sent to browser
DEBUG - 2024-01-23 10:17:27 --> Total execution time: 0.1653
ERROR - 2024-01-23 10:18:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:18:07 --> Config Class Initialized
INFO - 2024-01-23 10:18:07 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:18:07 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:18:07 --> Utf8 Class Initialized
INFO - 2024-01-23 10:18:07 --> URI Class Initialized
INFO - 2024-01-23 10:18:07 --> Router Class Initialized
INFO - 2024-01-23 10:18:07 --> Output Class Initialized
INFO - 2024-01-23 10:18:07 --> Security Class Initialized
DEBUG - 2024-01-23 10:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:18:07 --> Input Class Initialized
INFO - 2024-01-23 10:18:07 --> Language Class Initialized
INFO - 2024-01-23 10:18:07 --> Loader Class Initialized
INFO - 2024-01-23 10:18:07 --> Helper loaded: url_helper
INFO - 2024-01-23 10:18:07 --> Helper loaded: file_helper
INFO - 2024-01-23 10:18:07 --> Helper loaded: html_helper
INFO - 2024-01-23 10:18:07 --> Helper loaded: text_helper
INFO - 2024-01-23 10:18:07 --> Helper loaded: form_helper
INFO - 2024-01-23 10:18:07 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:18:07 --> Helper loaded: security_helper
INFO - 2024-01-23 10:18:07 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:18:07 --> Database Driver Class Initialized
INFO - 2024-01-23 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:18:07 --> Parser Class Initialized
INFO - 2024-01-23 10:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:18:07 --> Pagination Class Initialized
INFO - 2024-01-23 10:18:07 --> Form Validation Class Initialized
INFO - 2024-01-23 10:18:07 --> Controller Class Initialized
INFO - 2024-01-23 10:18:07 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:07 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:07 --> Model Class Initialized
INFO - 2024-01-23 10:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 10:18:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:18:07 --> Model Class Initialized
INFO - 2024-01-23 10:18:07 --> Model Class Initialized
INFO - 2024-01-23 10:18:07 --> Model Class Initialized
INFO - 2024-01-23 10:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:18:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:18:07 --> Final output sent to browser
DEBUG - 2024-01-23 10:18:07 --> Total execution time: 0.1440
ERROR - 2024-01-23 10:18:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:18:08 --> Config Class Initialized
INFO - 2024-01-23 10:18:08 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:18:08 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:18:08 --> Utf8 Class Initialized
INFO - 2024-01-23 10:18:08 --> URI Class Initialized
INFO - 2024-01-23 10:18:08 --> Router Class Initialized
INFO - 2024-01-23 10:18:08 --> Output Class Initialized
INFO - 2024-01-23 10:18:08 --> Security Class Initialized
DEBUG - 2024-01-23 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:18:08 --> Input Class Initialized
INFO - 2024-01-23 10:18:08 --> Language Class Initialized
INFO - 2024-01-23 10:18:08 --> Loader Class Initialized
INFO - 2024-01-23 10:18:08 --> Helper loaded: url_helper
INFO - 2024-01-23 10:18:08 --> Helper loaded: file_helper
INFO - 2024-01-23 10:18:08 --> Helper loaded: html_helper
INFO - 2024-01-23 10:18:08 --> Helper loaded: text_helper
INFO - 2024-01-23 10:18:08 --> Helper loaded: form_helper
INFO - 2024-01-23 10:18:08 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:18:08 --> Helper loaded: security_helper
INFO - 2024-01-23 10:18:08 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:18:08 --> Database Driver Class Initialized
INFO - 2024-01-23 10:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:18:08 --> Parser Class Initialized
INFO - 2024-01-23 10:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:18:08 --> Pagination Class Initialized
INFO - 2024-01-23 10:18:08 --> Form Validation Class Initialized
INFO - 2024-01-23 10:18:08 --> Controller Class Initialized
INFO - 2024-01-23 10:18:08 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:08 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:08 --> Model Class Initialized
INFO - 2024-01-23 10:18:08 --> Final output sent to browser
DEBUG - 2024-01-23 10:18:08 --> Total execution time: 0.0391
ERROR - 2024-01-23 10:18:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:18:17 --> Config Class Initialized
INFO - 2024-01-23 10:18:17 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:18:17 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:18:17 --> Utf8 Class Initialized
INFO - 2024-01-23 10:18:17 --> URI Class Initialized
INFO - 2024-01-23 10:18:17 --> Router Class Initialized
INFO - 2024-01-23 10:18:17 --> Output Class Initialized
INFO - 2024-01-23 10:18:17 --> Security Class Initialized
DEBUG - 2024-01-23 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:18:17 --> Input Class Initialized
INFO - 2024-01-23 10:18:17 --> Language Class Initialized
INFO - 2024-01-23 10:18:17 --> Loader Class Initialized
INFO - 2024-01-23 10:18:17 --> Helper loaded: url_helper
INFO - 2024-01-23 10:18:17 --> Helper loaded: file_helper
INFO - 2024-01-23 10:18:17 --> Helper loaded: html_helper
INFO - 2024-01-23 10:18:17 --> Helper loaded: text_helper
INFO - 2024-01-23 10:18:17 --> Helper loaded: form_helper
INFO - 2024-01-23 10:18:17 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:18:17 --> Helper loaded: security_helper
INFO - 2024-01-23 10:18:17 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:18:17 --> Database Driver Class Initialized
INFO - 2024-01-23 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:18:17 --> Parser Class Initialized
INFO - 2024-01-23 10:18:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:18:17 --> Pagination Class Initialized
INFO - 2024-01-23 10:18:17 --> Form Validation Class Initialized
INFO - 2024-01-23 10:18:17 --> Controller Class Initialized
INFO - 2024-01-23 10:18:17 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:17 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:17 --> Model Class Initialized
INFO - 2024-01-23 10:18:17 --> Final output sent to browser
DEBUG - 2024-01-23 10:18:17 --> Total execution time: 0.0816
ERROR - 2024-01-23 10:18:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:18:32 --> Config Class Initialized
INFO - 2024-01-23 10:18:32 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:18:32 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:18:32 --> Utf8 Class Initialized
INFO - 2024-01-23 10:18:32 --> URI Class Initialized
INFO - 2024-01-23 10:18:32 --> Router Class Initialized
INFO - 2024-01-23 10:18:32 --> Output Class Initialized
INFO - 2024-01-23 10:18:32 --> Security Class Initialized
DEBUG - 2024-01-23 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:18:32 --> Input Class Initialized
INFO - 2024-01-23 10:18:32 --> Language Class Initialized
INFO - 2024-01-23 10:18:32 --> Loader Class Initialized
INFO - 2024-01-23 10:18:32 --> Helper loaded: url_helper
INFO - 2024-01-23 10:18:32 --> Helper loaded: file_helper
INFO - 2024-01-23 10:18:32 --> Helper loaded: html_helper
INFO - 2024-01-23 10:18:32 --> Helper loaded: text_helper
INFO - 2024-01-23 10:18:32 --> Helper loaded: form_helper
INFO - 2024-01-23 10:18:32 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:18:32 --> Helper loaded: security_helper
INFO - 2024-01-23 10:18:32 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:18:32 --> Database Driver Class Initialized
INFO - 2024-01-23 10:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:18:32 --> Parser Class Initialized
INFO - 2024-01-23 10:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:18:32 --> Pagination Class Initialized
INFO - 2024-01-23 10:18:32 --> Form Validation Class Initialized
INFO - 2024-01-23 10:18:32 --> Controller Class Initialized
INFO - 2024-01-23 10:18:32 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:32 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:32 --> Model Class Initialized
INFO - 2024-01-23 10:18:32 --> Final output sent to browser
DEBUG - 2024-01-23 10:18:32 --> Total execution time: 0.1049
ERROR - 2024-01-23 10:18:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:18:48 --> Config Class Initialized
INFO - 2024-01-23 10:18:48 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:18:48 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:18:48 --> Utf8 Class Initialized
INFO - 2024-01-23 10:18:48 --> URI Class Initialized
INFO - 2024-01-23 10:18:48 --> Router Class Initialized
INFO - 2024-01-23 10:18:48 --> Output Class Initialized
INFO - 2024-01-23 10:18:48 --> Security Class Initialized
DEBUG - 2024-01-23 10:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:18:48 --> Input Class Initialized
INFO - 2024-01-23 10:18:48 --> Language Class Initialized
INFO - 2024-01-23 10:18:48 --> Loader Class Initialized
INFO - 2024-01-23 10:18:48 --> Helper loaded: url_helper
INFO - 2024-01-23 10:18:48 --> Helper loaded: file_helper
INFO - 2024-01-23 10:18:48 --> Helper loaded: html_helper
INFO - 2024-01-23 10:18:48 --> Helper loaded: text_helper
INFO - 2024-01-23 10:18:48 --> Helper loaded: form_helper
INFO - 2024-01-23 10:18:48 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:18:48 --> Helper loaded: security_helper
INFO - 2024-01-23 10:18:48 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:18:48 --> Database Driver Class Initialized
INFO - 2024-01-23 10:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:18:48 --> Parser Class Initialized
INFO - 2024-01-23 10:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:18:48 --> Pagination Class Initialized
INFO - 2024-01-23 10:18:48 --> Form Validation Class Initialized
INFO - 2024-01-23 10:18:48 --> Controller Class Initialized
INFO - 2024-01-23 10:18:48 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:48 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:48 --> Model Class Initialized
DEBUG - 2024-01-23 10:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-23 10:18:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:18:48 --> Model Class Initialized
INFO - 2024-01-23 10:18:48 --> Model Class Initialized
INFO - 2024-01-23 10:18:48 --> Model Class Initialized
INFO - 2024-01-23 10:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:18:48 --> Final output sent to browser
DEBUG - 2024-01-23 10:18:48 --> Total execution time: 0.1542
ERROR - 2024-01-23 10:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:19:28 --> Config Class Initialized
INFO - 2024-01-23 10:19:28 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:19:28 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:19:28 --> Utf8 Class Initialized
INFO - 2024-01-23 10:19:28 --> URI Class Initialized
INFO - 2024-01-23 10:19:28 --> Router Class Initialized
INFO - 2024-01-23 10:19:28 --> Output Class Initialized
INFO - 2024-01-23 10:19:28 --> Security Class Initialized
DEBUG - 2024-01-23 10:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:19:28 --> Input Class Initialized
INFO - 2024-01-23 10:19:28 --> Language Class Initialized
INFO - 2024-01-23 10:19:28 --> Loader Class Initialized
INFO - 2024-01-23 10:19:28 --> Helper loaded: url_helper
INFO - 2024-01-23 10:19:28 --> Helper loaded: file_helper
INFO - 2024-01-23 10:19:28 --> Helper loaded: html_helper
INFO - 2024-01-23 10:19:28 --> Helper loaded: text_helper
INFO - 2024-01-23 10:19:28 --> Helper loaded: form_helper
INFO - 2024-01-23 10:19:28 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:19:28 --> Helper loaded: security_helper
INFO - 2024-01-23 10:19:28 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:19:28 --> Database Driver Class Initialized
INFO - 2024-01-23 10:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:19:28 --> Parser Class Initialized
INFO - 2024-01-23 10:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:19:28 --> Pagination Class Initialized
INFO - 2024-01-23 10:19:28 --> Form Validation Class Initialized
INFO - 2024-01-23 10:19:28 --> Controller Class Initialized
INFO - 2024-01-23 10:19:28 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:28 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:28 --> Model Class Initialized
INFO - 2024-01-23 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 10:19:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:19:28 --> Model Class Initialized
INFO - 2024-01-23 10:19:28 --> Model Class Initialized
INFO - 2024-01-23 10:19:28 --> Model Class Initialized
INFO - 2024-01-23 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:19:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:19:28 --> Final output sent to browser
DEBUG - 2024-01-23 10:19:28 --> Total execution time: 0.1520
ERROR - 2024-01-23 10:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:19:29 --> Config Class Initialized
INFO - 2024-01-23 10:19:29 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:19:29 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:19:29 --> Utf8 Class Initialized
INFO - 2024-01-23 10:19:29 --> URI Class Initialized
DEBUG - 2024-01-23 10:19:29 --> No URI present. Default controller set.
INFO - 2024-01-23 10:19:29 --> Router Class Initialized
INFO - 2024-01-23 10:19:29 --> Output Class Initialized
INFO - 2024-01-23 10:19:29 --> Security Class Initialized
DEBUG - 2024-01-23 10:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:19:29 --> Input Class Initialized
INFO - 2024-01-23 10:19:29 --> Language Class Initialized
INFO - 2024-01-23 10:19:29 --> Loader Class Initialized
INFO - 2024-01-23 10:19:29 --> Helper loaded: url_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: file_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: html_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: text_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: form_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: security_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:19:29 --> Database Driver Class Initialized
INFO - 2024-01-23 10:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:19:29 --> Parser Class Initialized
INFO - 2024-01-23 10:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:19:29 --> Pagination Class Initialized
INFO - 2024-01-23 10:19:29 --> Form Validation Class Initialized
INFO - 2024-01-23 10:19:29 --> Controller Class Initialized
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 10:19:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:19:29 --> Final output sent to browser
DEBUG - 2024-01-23 10:19:29 --> Total execution time: 0.2396
ERROR - 2024-01-23 10:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:19:29 --> Config Class Initialized
INFO - 2024-01-23 10:19:29 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:19:29 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:19:29 --> Utf8 Class Initialized
INFO - 2024-01-23 10:19:29 --> URI Class Initialized
INFO - 2024-01-23 10:19:29 --> Router Class Initialized
INFO - 2024-01-23 10:19:29 --> Output Class Initialized
INFO - 2024-01-23 10:19:29 --> Security Class Initialized
DEBUG - 2024-01-23 10:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:19:29 --> Input Class Initialized
INFO - 2024-01-23 10:19:29 --> Language Class Initialized
INFO - 2024-01-23 10:19:29 --> Loader Class Initialized
INFO - 2024-01-23 10:19:29 --> Helper loaded: url_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: file_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: html_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: text_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: form_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: security_helper
INFO - 2024-01-23 10:19:29 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:19:29 --> Database Driver Class Initialized
INFO - 2024-01-23 10:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:19:29 --> Parser Class Initialized
INFO - 2024-01-23 10:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:19:29 --> Pagination Class Initialized
INFO - 2024-01-23 10:19:29 --> Form Validation Class Initialized
INFO - 2024-01-23 10:19:29 --> Controller Class Initialized
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 10:19:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:19:29 --> Model Class Initialized
INFO - 2024-01-23 10:19:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:19:29 --> Final output sent to browser
DEBUG - 2024-01-23 10:19:29 --> Total execution time: 0.0313
ERROR - 2024-01-23 10:19:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:19:30 --> Config Class Initialized
INFO - 2024-01-23 10:19:30 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:19:30 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:19:30 --> Utf8 Class Initialized
INFO - 2024-01-23 10:19:30 --> URI Class Initialized
INFO - 2024-01-23 10:19:30 --> Router Class Initialized
INFO - 2024-01-23 10:19:30 --> Output Class Initialized
INFO - 2024-01-23 10:19:30 --> Security Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:19:30 --> Input Class Initialized
INFO - 2024-01-23 10:19:30 --> Language Class Initialized
INFO - 2024-01-23 10:19:30 --> Loader Class Initialized
INFO - 2024-01-23 10:19:30 --> Helper loaded: url_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: file_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: html_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: text_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: form_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: security_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:19:30 --> Database Driver Class Initialized
INFO - 2024-01-23 10:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:19:30 --> Parser Class Initialized
INFO - 2024-01-23 10:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:19:30 --> Pagination Class Initialized
INFO - 2024-01-23 10:19:30 --> Form Validation Class Initialized
INFO - 2024-01-23 10:19:30 --> Controller Class Initialized
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
ERROR - 2024-01-23 10:19:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:30 --> Config Class Initialized
INFO - 2024-01-23 10:19:30 --> Hooks Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:19:30 --> UTF-8 Support Enabled
INFO - 2024-01-23 10:19:30 --> Utf8 Class Initialized
INFO - 2024-01-23 10:19:30 --> URI Class Initialized
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
INFO - 2024-01-23 10:19:30 --> Router Class Initialized
INFO - 2024-01-23 10:19:30 --> Output Class Initialized
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
INFO - 2024-01-23 10:19:30 --> Security Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 10:19:30 --> Input Class Initialized
INFO - 2024-01-23 10:19:30 --> Language Class Initialized
INFO - 2024-01-23 10:19:30 --> Loader Class Initialized
INFO - 2024-01-23 10:19:30 --> Helper loaded: url_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: file_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: html_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: text_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: form_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: lang_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: security_helper
INFO - 2024-01-23 10:19:30 --> Helper loaded: cookie_helper
INFO - 2024-01-23 10:19:30 --> Database Driver Class Initialized
INFO - 2024-01-23 10:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 10:19:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 10:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
INFO - 2024-01-23 10:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 10:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 10:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 10:19:30 --> Final output sent to browser
DEBUG - 2024-01-23 10:19:30 --> Total execution time: 0.3209
INFO - 2024-01-23 10:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 10:19:30 --> Parser Class Initialized
INFO - 2024-01-23 10:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 10:19:30 --> Pagination Class Initialized
INFO - 2024-01-23 10:19:30 --> Form Validation Class Initialized
INFO - 2024-01-23 10:19:30 --> Controller Class Initialized
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 10:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
DEBUG - 2024-01-23 10:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 10:19:30 --> Model Class Initialized
INFO - 2024-01-23 10:19:30 --> Final output sent to browser
DEBUG - 2024-01-23 10:19:30 --> Total execution time: 0.2667
ERROR - 2024-01-23 11:08:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:08:19 --> Config Class Initialized
INFO - 2024-01-23 11:08:19 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:08:19 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:08:19 --> Utf8 Class Initialized
INFO - 2024-01-23 11:08:19 --> URI Class Initialized
DEBUG - 2024-01-23 11:08:19 --> No URI present. Default controller set.
INFO - 2024-01-23 11:08:19 --> Router Class Initialized
INFO - 2024-01-23 11:08:19 --> Output Class Initialized
INFO - 2024-01-23 11:08:19 --> Security Class Initialized
DEBUG - 2024-01-23 11:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:08:19 --> Input Class Initialized
INFO - 2024-01-23 11:08:19 --> Language Class Initialized
INFO - 2024-01-23 11:08:19 --> Loader Class Initialized
INFO - 2024-01-23 11:08:19 --> Helper loaded: url_helper
INFO - 2024-01-23 11:08:19 --> Helper loaded: file_helper
INFO - 2024-01-23 11:08:19 --> Helper loaded: html_helper
INFO - 2024-01-23 11:08:19 --> Helper loaded: text_helper
INFO - 2024-01-23 11:08:19 --> Helper loaded: form_helper
INFO - 2024-01-23 11:08:19 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:08:19 --> Helper loaded: security_helper
INFO - 2024-01-23 11:08:19 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:08:19 --> Database Driver Class Initialized
INFO - 2024-01-23 11:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:08:19 --> Parser Class Initialized
INFO - 2024-01-23 11:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:08:19 --> Pagination Class Initialized
INFO - 2024-01-23 11:08:19 --> Form Validation Class Initialized
INFO - 2024-01-23 11:08:19 --> Controller Class Initialized
INFO - 2024-01-23 11:08:19 --> Model Class Initialized
DEBUG - 2024-01-23 11:08:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-23 11:21:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:21:41 --> Config Class Initialized
INFO - 2024-01-23 11:21:41 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:21:41 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:21:41 --> Utf8 Class Initialized
INFO - 2024-01-23 11:21:41 --> URI Class Initialized
DEBUG - 2024-01-23 11:21:41 --> No URI present. Default controller set.
INFO - 2024-01-23 11:21:41 --> Router Class Initialized
INFO - 2024-01-23 11:21:41 --> Output Class Initialized
INFO - 2024-01-23 11:21:41 --> Security Class Initialized
DEBUG - 2024-01-23 11:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:21:41 --> Input Class Initialized
INFO - 2024-01-23 11:21:41 --> Language Class Initialized
INFO - 2024-01-23 11:21:41 --> Loader Class Initialized
INFO - 2024-01-23 11:21:41 --> Helper loaded: url_helper
INFO - 2024-01-23 11:21:41 --> Helper loaded: file_helper
INFO - 2024-01-23 11:21:41 --> Helper loaded: html_helper
INFO - 2024-01-23 11:21:41 --> Helper loaded: text_helper
INFO - 2024-01-23 11:21:41 --> Helper loaded: form_helper
INFO - 2024-01-23 11:21:41 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:21:41 --> Helper loaded: security_helper
INFO - 2024-01-23 11:21:41 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:21:41 --> Database Driver Class Initialized
INFO - 2024-01-23 11:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:21:41 --> Parser Class Initialized
INFO - 2024-01-23 11:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:21:41 --> Pagination Class Initialized
INFO - 2024-01-23 11:21:41 --> Form Validation Class Initialized
INFO - 2024-01-23 11:21:41 --> Controller Class Initialized
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
DEBUG - 2024-01-23 11:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
DEBUG - 2024-01-23 11:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
DEBUG - 2024-01-23 11:21:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
INFO - 2024-01-23 11:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 11:21:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 11:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 11:21:41 --> Model Class Initialized
INFO - 2024-01-23 11:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 11:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 11:21:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 11:21:41 --> Final output sent to browser
DEBUG - 2024-01-23 11:21:41 --> Total execution time: 0.2273
ERROR - 2024-01-23 11:21:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:21:48 --> Config Class Initialized
INFO - 2024-01-23 11:21:48 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:21:48 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:21:48 --> Utf8 Class Initialized
INFO - 2024-01-23 11:21:48 --> URI Class Initialized
INFO - 2024-01-23 11:21:48 --> Router Class Initialized
INFO - 2024-01-23 11:21:48 --> Output Class Initialized
INFO - 2024-01-23 11:21:48 --> Security Class Initialized
DEBUG - 2024-01-23 11:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:21:48 --> Input Class Initialized
INFO - 2024-01-23 11:21:48 --> Language Class Initialized
INFO - 2024-01-23 11:21:48 --> Loader Class Initialized
INFO - 2024-01-23 11:21:48 --> Helper loaded: url_helper
INFO - 2024-01-23 11:21:48 --> Helper loaded: file_helper
INFO - 2024-01-23 11:21:48 --> Helper loaded: html_helper
INFO - 2024-01-23 11:21:48 --> Helper loaded: text_helper
INFO - 2024-01-23 11:21:48 --> Helper loaded: form_helper
INFO - 2024-01-23 11:21:48 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:21:48 --> Helper loaded: security_helper
INFO - 2024-01-23 11:21:48 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:21:48 --> Database Driver Class Initialized
INFO - 2024-01-23 11:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:21:48 --> Parser Class Initialized
INFO - 2024-01-23 11:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:21:48 --> Pagination Class Initialized
INFO - 2024-01-23 11:21:48 --> Form Validation Class Initialized
INFO - 2024-01-23 11:21:48 --> Controller Class Initialized
INFO - 2024-01-23 11:21:48 --> Model Class Initialized
DEBUG - 2024-01-23 11:21:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:48 --> Model Class Initialized
DEBUG - 2024-01-23 11:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:48 --> Model Class Initialized
INFO - 2024-01-23 11:21:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 11:21:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 11:21:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 11:21:48 --> Model Class Initialized
INFO - 2024-01-23 11:21:48 --> Model Class Initialized
INFO - 2024-01-23 11:21:48 --> Model Class Initialized
INFO - 2024-01-23 11:21:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 11:21:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 11:21:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 11:21:48 --> Final output sent to browser
DEBUG - 2024-01-23 11:21:48 --> Total execution time: 0.1454
ERROR - 2024-01-23 11:21:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:21:49 --> Config Class Initialized
INFO - 2024-01-23 11:21:49 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:21:49 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:21:49 --> Utf8 Class Initialized
INFO - 2024-01-23 11:21:49 --> URI Class Initialized
INFO - 2024-01-23 11:21:49 --> Router Class Initialized
INFO - 2024-01-23 11:21:49 --> Output Class Initialized
INFO - 2024-01-23 11:21:49 --> Security Class Initialized
DEBUG - 2024-01-23 11:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:21:49 --> Input Class Initialized
INFO - 2024-01-23 11:21:49 --> Language Class Initialized
INFO - 2024-01-23 11:21:49 --> Loader Class Initialized
INFO - 2024-01-23 11:21:49 --> Helper loaded: url_helper
INFO - 2024-01-23 11:21:49 --> Helper loaded: file_helper
INFO - 2024-01-23 11:21:49 --> Helper loaded: html_helper
INFO - 2024-01-23 11:21:49 --> Helper loaded: text_helper
INFO - 2024-01-23 11:21:49 --> Helper loaded: form_helper
INFO - 2024-01-23 11:21:49 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:21:49 --> Helper loaded: security_helper
INFO - 2024-01-23 11:21:49 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:21:49 --> Database Driver Class Initialized
INFO - 2024-01-23 11:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:21:49 --> Parser Class Initialized
INFO - 2024-01-23 11:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:21:49 --> Pagination Class Initialized
INFO - 2024-01-23 11:21:49 --> Form Validation Class Initialized
INFO - 2024-01-23 11:21:49 --> Controller Class Initialized
INFO - 2024-01-23 11:21:49 --> Model Class Initialized
DEBUG - 2024-01-23 11:21:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:49 --> Model Class Initialized
DEBUG - 2024-01-23 11:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:21:49 --> Model Class Initialized
INFO - 2024-01-23 11:21:49 --> Final output sent to browser
DEBUG - 2024-01-23 11:21:49 --> Total execution time: 0.0413
ERROR - 2024-01-23 11:22:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:22:01 --> Config Class Initialized
INFO - 2024-01-23 11:22:01 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:22:01 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:22:01 --> Utf8 Class Initialized
INFO - 2024-01-23 11:22:01 --> URI Class Initialized
INFO - 2024-01-23 11:22:01 --> Router Class Initialized
INFO - 2024-01-23 11:22:01 --> Output Class Initialized
INFO - 2024-01-23 11:22:01 --> Security Class Initialized
DEBUG - 2024-01-23 11:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:22:01 --> Input Class Initialized
INFO - 2024-01-23 11:22:01 --> Language Class Initialized
INFO - 2024-01-23 11:22:01 --> Loader Class Initialized
INFO - 2024-01-23 11:22:01 --> Helper loaded: url_helper
INFO - 2024-01-23 11:22:01 --> Helper loaded: file_helper
INFO - 2024-01-23 11:22:01 --> Helper loaded: html_helper
INFO - 2024-01-23 11:22:01 --> Helper loaded: text_helper
INFO - 2024-01-23 11:22:01 --> Helper loaded: form_helper
INFO - 2024-01-23 11:22:01 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:22:01 --> Helper loaded: security_helper
INFO - 2024-01-23 11:22:01 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:22:01 --> Database Driver Class Initialized
INFO - 2024-01-23 11:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:22:01 --> Parser Class Initialized
INFO - 2024-01-23 11:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:22:01 --> Pagination Class Initialized
INFO - 2024-01-23 11:22:01 --> Form Validation Class Initialized
INFO - 2024-01-23 11:22:01 --> Controller Class Initialized
INFO - 2024-01-23 11:22:01 --> Model Class Initialized
DEBUG - 2024-01-23 11:22:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:22:01 --> Model Class Initialized
DEBUG - 2024-01-23 11:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:22:01 --> Model Class Initialized
INFO - 2024-01-23 11:22:01 --> Final output sent to browser
DEBUG - 2024-01-23 11:22:01 --> Total execution time: 0.1113
ERROR - 2024-01-23 11:23:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:23:14 --> Config Class Initialized
INFO - 2024-01-23 11:23:14 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:23:14 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:23:14 --> Utf8 Class Initialized
INFO - 2024-01-23 11:23:14 --> URI Class Initialized
INFO - 2024-01-23 11:23:14 --> Router Class Initialized
INFO - 2024-01-23 11:23:14 --> Output Class Initialized
INFO - 2024-01-23 11:23:14 --> Security Class Initialized
DEBUG - 2024-01-23 11:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:23:14 --> Input Class Initialized
INFO - 2024-01-23 11:23:14 --> Language Class Initialized
INFO - 2024-01-23 11:23:14 --> Loader Class Initialized
INFO - 2024-01-23 11:23:14 --> Helper loaded: url_helper
INFO - 2024-01-23 11:23:14 --> Helper loaded: file_helper
INFO - 2024-01-23 11:23:14 --> Helper loaded: html_helper
INFO - 2024-01-23 11:23:14 --> Helper loaded: text_helper
INFO - 2024-01-23 11:23:14 --> Helper loaded: form_helper
INFO - 2024-01-23 11:23:14 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:23:14 --> Helper loaded: security_helper
INFO - 2024-01-23 11:23:14 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:23:14 --> Database Driver Class Initialized
INFO - 2024-01-23 11:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:23:14 --> Parser Class Initialized
INFO - 2024-01-23 11:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:23:14 --> Pagination Class Initialized
INFO - 2024-01-23 11:23:14 --> Form Validation Class Initialized
INFO - 2024-01-23 11:23:14 --> Controller Class Initialized
INFO - 2024-01-23 11:23:14 --> Model Class Initialized
DEBUG - 2024-01-23 11:23:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:23:14 --> Model Class Initialized
DEBUG - 2024-01-23 11:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:23:14 --> Model Class Initialized
DEBUG - 2024-01-23 11:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-23 11:23:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 11:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 11:23:14 --> Model Class Initialized
INFO - 2024-01-23 11:23:14 --> Model Class Initialized
INFO - 2024-01-23 11:23:14 --> Model Class Initialized
INFO - 2024-01-23 11:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 11:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 11:23:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 11:23:14 --> Final output sent to browser
DEBUG - 2024-01-23 11:23:14 --> Total execution time: 0.1583
ERROR - 2024-01-23 11:59:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:59:40 --> Config Class Initialized
INFO - 2024-01-23 11:59:40 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:59:40 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:59:40 --> Utf8 Class Initialized
INFO - 2024-01-23 11:59:40 --> URI Class Initialized
DEBUG - 2024-01-23 11:59:40 --> No URI present. Default controller set.
INFO - 2024-01-23 11:59:40 --> Router Class Initialized
INFO - 2024-01-23 11:59:40 --> Output Class Initialized
INFO - 2024-01-23 11:59:40 --> Security Class Initialized
DEBUG - 2024-01-23 11:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:59:40 --> Input Class Initialized
INFO - 2024-01-23 11:59:40 --> Language Class Initialized
INFO - 2024-01-23 11:59:40 --> Loader Class Initialized
INFO - 2024-01-23 11:59:40 --> Helper loaded: url_helper
INFO - 2024-01-23 11:59:40 --> Helper loaded: file_helper
INFO - 2024-01-23 11:59:40 --> Helper loaded: html_helper
INFO - 2024-01-23 11:59:40 --> Helper loaded: text_helper
INFO - 2024-01-23 11:59:40 --> Helper loaded: form_helper
INFO - 2024-01-23 11:59:40 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:59:40 --> Helper loaded: security_helper
INFO - 2024-01-23 11:59:40 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:59:40 --> Database Driver Class Initialized
INFO - 2024-01-23 11:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:59:40 --> Parser Class Initialized
INFO - 2024-01-23 11:59:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:59:40 --> Pagination Class Initialized
INFO - 2024-01-23 11:59:40 --> Form Validation Class Initialized
INFO - 2024-01-23 11:59:40 --> Controller Class Initialized
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
INFO - 2024-01-23 11:59:40 --> Model Class Initialized
INFO - 2024-01-23 11:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 11:59:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 11:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 11:59:41 --> Model Class Initialized
INFO - 2024-01-23 11:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 11:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 11:59:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 11:59:41 --> Final output sent to browser
DEBUG - 2024-01-23 11:59:41 --> Total execution time: 0.2343
ERROR - 2024-01-23 11:59:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:59:52 --> Config Class Initialized
INFO - 2024-01-23 11:59:52 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:59:52 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:59:52 --> Utf8 Class Initialized
INFO - 2024-01-23 11:59:52 --> URI Class Initialized
INFO - 2024-01-23 11:59:52 --> Router Class Initialized
INFO - 2024-01-23 11:59:52 --> Output Class Initialized
INFO - 2024-01-23 11:59:52 --> Security Class Initialized
DEBUG - 2024-01-23 11:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:59:52 --> Input Class Initialized
INFO - 2024-01-23 11:59:52 --> Language Class Initialized
INFO - 2024-01-23 11:59:52 --> Loader Class Initialized
INFO - 2024-01-23 11:59:52 --> Helper loaded: url_helper
INFO - 2024-01-23 11:59:52 --> Helper loaded: file_helper
INFO - 2024-01-23 11:59:52 --> Helper loaded: html_helper
INFO - 2024-01-23 11:59:52 --> Helper loaded: text_helper
INFO - 2024-01-23 11:59:52 --> Helper loaded: form_helper
INFO - 2024-01-23 11:59:52 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:59:52 --> Helper loaded: security_helper
INFO - 2024-01-23 11:59:52 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:59:52 --> Database Driver Class Initialized
INFO - 2024-01-23 11:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:59:52 --> Parser Class Initialized
INFO - 2024-01-23 11:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:59:52 --> Pagination Class Initialized
INFO - 2024-01-23 11:59:52 --> Form Validation Class Initialized
INFO - 2024-01-23 11:59:52 --> Controller Class Initialized
INFO - 2024-01-23 11:59:52 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:52 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:52 --> Model Class Initialized
INFO - 2024-01-23 11:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 11:59:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 11:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 11:59:52 --> Model Class Initialized
INFO - 2024-01-23 11:59:52 --> Model Class Initialized
INFO - 2024-01-23 11:59:52 --> Model Class Initialized
INFO - 2024-01-23 11:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 11:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 11:59:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 11:59:52 --> Final output sent to browser
DEBUG - 2024-01-23 11:59:52 --> Total execution time: 0.1480
ERROR - 2024-01-23 11:59:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:59:53 --> Config Class Initialized
INFO - 2024-01-23 11:59:53 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:59:53 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:59:53 --> Utf8 Class Initialized
INFO - 2024-01-23 11:59:53 --> URI Class Initialized
INFO - 2024-01-23 11:59:53 --> Router Class Initialized
INFO - 2024-01-23 11:59:53 --> Output Class Initialized
INFO - 2024-01-23 11:59:53 --> Security Class Initialized
DEBUG - 2024-01-23 11:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:59:53 --> Input Class Initialized
INFO - 2024-01-23 11:59:53 --> Language Class Initialized
INFO - 2024-01-23 11:59:53 --> Loader Class Initialized
INFO - 2024-01-23 11:59:53 --> Helper loaded: url_helper
INFO - 2024-01-23 11:59:53 --> Helper loaded: file_helper
INFO - 2024-01-23 11:59:53 --> Helper loaded: html_helper
INFO - 2024-01-23 11:59:53 --> Helper loaded: text_helper
INFO - 2024-01-23 11:59:53 --> Helper loaded: form_helper
INFO - 2024-01-23 11:59:53 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:59:53 --> Helper loaded: security_helper
INFO - 2024-01-23 11:59:53 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:59:53 --> Database Driver Class Initialized
INFO - 2024-01-23 11:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:59:53 --> Parser Class Initialized
INFO - 2024-01-23 11:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:59:53 --> Pagination Class Initialized
INFO - 2024-01-23 11:59:53 --> Form Validation Class Initialized
INFO - 2024-01-23 11:59:53 --> Controller Class Initialized
INFO - 2024-01-23 11:59:53 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:53 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:53 --> Model Class Initialized
INFO - 2024-01-23 11:59:53 --> Final output sent to browser
DEBUG - 2024-01-23 11:59:53 --> Total execution time: 0.0451
ERROR - 2024-01-23 11:59:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 11:59:58 --> Config Class Initialized
INFO - 2024-01-23 11:59:58 --> Hooks Class Initialized
DEBUG - 2024-01-23 11:59:58 --> UTF-8 Support Enabled
INFO - 2024-01-23 11:59:58 --> Utf8 Class Initialized
INFO - 2024-01-23 11:59:58 --> URI Class Initialized
INFO - 2024-01-23 11:59:58 --> Router Class Initialized
INFO - 2024-01-23 11:59:58 --> Output Class Initialized
INFO - 2024-01-23 11:59:58 --> Security Class Initialized
DEBUG - 2024-01-23 11:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 11:59:58 --> Input Class Initialized
INFO - 2024-01-23 11:59:58 --> Language Class Initialized
INFO - 2024-01-23 11:59:58 --> Loader Class Initialized
INFO - 2024-01-23 11:59:58 --> Helper loaded: url_helper
INFO - 2024-01-23 11:59:58 --> Helper loaded: file_helper
INFO - 2024-01-23 11:59:58 --> Helper loaded: html_helper
INFO - 2024-01-23 11:59:58 --> Helper loaded: text_helper
INFO - 2024-01-23 11:59:58 --> Helper loaded: form_helper
INFO - 2024-01-23 11:59:58 --> Helper loaded: lang_helper
INFO - 2024-01-23 11:59:58 --> Helper loaded: security_helper
INFO - 2024-01-23 11:59:58 --> Helper loaded: cookie_helper
INFO - 2024-01-23 11:59:58 --> Database Driver Class Initialized
INFO - 2024-01-23 11:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 11:59:58 --> Parser Class Initialized
INFO - 2024-01-23 11:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 11:59:58 --> Pagination Class Initialized
INFO - 2024-01-23 11:59:58 --> Form Validation Class Initialized
INFO - 2024-01-23 11:59:58 --> Controller Class Initialized
INFO - 2024-01-23 11:59:58 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 11:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:58 --> Model Class Initialized
DEBUG - 2024-01-23 11:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 11:59:58 --> Model Class Initialized
INFO - 2024-01-23 11:59:58 --> Final output sent to browser
DEBUG - 2024-01-23 11:59:58 --> Total execution time: 0.0762
ERROR - 2024-01-23 12:00:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:00:01 --> Config Class Initialized
INFO - 2024-01-23 12:00:01 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:00:01 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:00:01 --> Utf8 Class Initialized
INFO - 2024-01-23 12:00:01 --> URI Class Initialized
INFO - 2024-01-23 12:00:01 --> Router Class Initialized
INFO - 2024-01-23 12:00:01 --> Output Class Initialized
INFO - 2024-01-23 12:00:01 --> Security Class Initialized
DEBUG - 2024-01-23 12:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:00:01 --> Input Class Initialized
INFO - 2024-01-23 12:00:01 --> Language Class Initialized
INFO - 2024-01-23 12:00:01 --> Loader Class Initialized
INFO - 2024-01-23 12:00:01 --> Helper loaded: url_helper
INFO - 2024-01-23 12:00:01 --> Helper loaded: file_helper
INFO - 2024-01-23 12:00:01 --> Helper loaded: html_helper
INFO - 2024-01-23 12:00:01 --> Helper loaded: text_helper
INFO - 2024-01-23 12:00:01 --> Helper loaded: form_helper
INFO - 2024-01-23 12:00:01 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:00:01 --> Helper loaded: security_helper
INFO - 2024-01-23 12:00:01 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:00:01 --> Database Driver Class Initialized
INFO - 2024-01-23 12:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:00:01 --> Parser Class Initialized
INFO - 2024-01-23 12:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:00:01 --> Pagination Class Initialized
INFO - 2024-01-23 12:00:01 --> Form Validation Class Initialized
INFO - 2024-01-23 12:00:01 --> Controller Class Initialized
INFO - 2024-01-23 12:00:01 --> Model Class Initialized
DEBUG - 2024-01-23 12:00:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 12:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:00:01 --> Model Class Initialized
DEBUG - 2024-01-23 12:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:00:01 --> Model Class Initialized
INFO - 2024-01-23 12:00:01 --> Final output sent to browser
DEBUG - 2024-01-23 12:00:01 --> Total execution time: 0.1165
ERROR - 2024-01-23 12:00:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:00:59 --> Config Class Initialized
INFO - 2024-01-23 12:00:59 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:00:59 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:00:59 --> Utf8 Class Initialized
INFO - 2024-01-23 12:00:59 --> URI Class Initialized
INFO - 2024-01-23 12:00:59 --> Router Class Initialized
INFO - 2024-01-23 12:00:59 --> Output Class Initialized
INFO - 2024-01-23 12:00:59 --> Security Class Initialized
DEBUG - 2024-01-23 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:00:59 --> Input Class Initialized
INFO - 2024-01-23 12:00:59 --> Language Class Initialized
INFO - 2024-01-23 12:00:59 --> Loader Class Initialized
INFO - 2024-01-23 12:00:59 --> Helper loaded: url_helper
INFO - 2024-01-23 12:00:59 --> Helper loaded: file_helper
INFO - 2024-01-23 12:00:59 --> Helper loaded: html_helper
INFO - 2024-01-23 12:00:59 --> Helper loaded: text_helper
INFO - 2024-01-23 12:00:59 --> Helper loaded: form_helper
INFO - 2024-01-23 12:00:59 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:00:59 --> Helper loaded: security_helper
INFO - 2024-01-23 12:00:59 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:00:59 --> Database Driver Class Initialized
INFO - 2024-01-23 12:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:00:59 --> Parser Class Initialized
INFO - 2024-01-23 12:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:00:59 --> Pagination Class Initialized
INFO - 2024-01-23 12:00:59 --> Form Validation Class Initialized
INFO - 2024-01-23 12:00:59 --> Controller Class Initialized
INFO - 2024-01-23 12:00:59 --> Model Class Initialized
DEBUG - 2024-01-23 12:00:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 12:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:00:59 --> Model Class Initialized
DEBUG - 2024-01-23 12:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:00:59 --> Model Class Initialized
DEBUG - 2024-01-23 12:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-23 12:00:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 12:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 12:00:59 --> Model Class Initialized
INFO - 2024-01-23 12:00:59 --> Model Class Initialized
INFO - 2024-01-23 12:00:59 --> Model Class Initialized
INFO - 2024-01-23 12:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 12:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 12:00:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 12:00:59 --> Final output sent to browser
DEBUG - 2024-01-23 12:00:59 --> Total execution time: 0.1662
ERROR - 2024-01-23 12:01:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:01:54 --> Config Class Initialized
INFO - 2024-01-23 12:01:54 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:01:54 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:01:54 --> Utf8 Class Initialized
INFO - 2024-01-23 12:01:54 --> URI Class Initialized
DEBUG - 2024-01-23 12:01:54 --> No URI present. Default controller set.
INFO - 2024-01-23 12:01:54 --> Router Class Initialized
INFO - 2024-01-23 12:01:54 --> Output Class Initialized
INFO - 2024-01-23 12:01:54 --> Security Class Initialized
DEBUG - 2024-01-23 12:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:01:54 --> Input Class Initialized
INFO - 2024-01-23 12:01:54 --> Language Class Initialized
INFO - 2024-01-23 12:01:54 --> Loader Class Initialized
INFO - 2024-01-23 12:01:54 --> Helper loaded: url_helper
INFO - 2024-01-23 12:01:54 --> Helper loaded: file_helper
INFO - 2024-01-23 12:01:54 --> Helper loaded: html_helper
INFO - 2024-01-23 12:01:54 --> Helper loaded: text_helper
INFO - 2024-01-23 12:01:54 --> Helper loaded: form_helper
INFO - 2024-01-23 12:01:54 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:01:54 --> Helper loaded: security_helper
INFO - 2024-01-23 12:01:54 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:01:54 --> Database Driver Class Initialized
INFO - 2024-01-23 12:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:01:54 --> Parser Class Initialized
INFO - 2024-01-23 12:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:01:54 --> Pagination Class Initialized
INFO - 2024-01-23 12:01:54 --> Form Validation Class Initialized
INFO - 2024-01-23 12:01:54 --> Controller Class Initialized
INFO - 2024-01-23 12:01:54 --> Model Class Initialized
DEBUG - 2024-01-23 12:01:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-23 12:01:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:01:55 --> Config Class Initialized
INFO - 2024-01-23 12:01:55 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:01:55 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:01:55 --> Utf8 Class Initialized
INFO - 2024-01-23 12:01:55 --> URI Class Initialized
INFO - 2024-01-23 12:01:55 --> Router Class Initialized
INFO - 2024-01-23 12:01:55 --> Output Class Initialized
INFO - 2024-01-23 12:01:55 --> Security Class Initialized
DEBUG - 2024-01-23 12:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:01:55 --> Input Class Initialized
INFO - 2024-01-23 12:01:55 --> Language Class Initialized
INFO - 2024-01-23 12:01:55 --> Loader Class Initialized
INFO - 2024-01-23 12:01:55 --> Helper loaded: url_helper
INFO - 2024-01-23 12:01:55 --> Helper loaded: file_helper
INFO - 2024-01-23 12:01:55 --> Helper loaded: html_helper
INFO - 2024-01-23 12:01:55 --> Helper loaded: text_helper
INFO - 2024-01-23 12:01:55 --> Helper loaded: form_helper
INFO - 2024-01-23 12:01:55 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:01:55 --> Helper loaded: security_helper
INFO - 2024-01-23 12:01:55 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:01:55 --> Database Driver Class Initialized
INFO - 2024-01-23 12:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:01:55 --> Parser Class Initialized
INFO - 2024-01-23 12:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:01:55 --> Pagination Class Initialized
INFO - 2024-01-23 12:01:55 --> Form Validation Class Initialized
INFO - 2024-01-23 12:01:55 --> Controller Class Initialized
INFO - 2024-01-23 12:01:55 --> Model Class Initialized
DEBUG - 2024-01-23 12:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:01:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 12:01:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:01:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 12:01:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 12:01:55 --> Model Class Initialized
INFO - 2024-01-23 12:01:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 12:01:55 --> Final output sent to browser
DEBUG - 2024-01-23 12:01:55 --> Total execution time: 0.0352
ERROR - 2024-01-23 12:02:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:02:13 --> Config Class Initialized
INFO - 2024-01-23 12:02:13 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:02:13 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:02:13 --> Utf8 Class Initialized
INFO - 2024-01-23 12:02:13 --> URI Class Initialized
INFO - 2024-01-23 12:02:13 --> Router Class Initialized
INFO - 2024-01-23 12:02:13 --> Output Class Initialized
INFO - 2024-01-23 12:02:13 --> Security Class Initialized
DEBUG - 2024-01-23 12:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:02:13 --> Input Class Initialized
INFO - 2024-01-23 12:02:13 --> Language Class Initialized
INFO - 2024-01-23 12:02:13 --> Loader Class Initialized
INFO - 2024-01-23 12:02:13 --> Helper loaded: url_helper
INFO - 2024-01-23 12:02:13 --> Helper loaded: file_helper
INFO - 2024-01-23 12:02:13 --> Helper loaded: html_helper
INFO - 2024-01-23 12:02:13 --> Helper loaded: text_helper
INFO - 2024-01-23 12:02:13 --> Helper loaded: form_helper
INFO - 2024-01-23 12:02:13 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:02:13 --> Helper loaded: security_helper
INFO - 2024-01-23 12:02:13 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:02:13 --> Database Driver Class Initialized
INFO - 2024-01-23 12:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:02:13 --> Parser Class Initialized
INFO - 2024-01-23 12:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:02:13 --> Pagination Class Initialized
INFO - 2024-01-23 12:02:13 --> Form Validation Class Initialized
INFO - 2024-01-23 12:02:13 --> Controller Class Initialized
INFO - 2024-01-23 12:02:13 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 12:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:13 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:13 --> Model Class Initialized
INFO - 2024-01-23 12:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 12:02:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 12:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 12:02:13 --> Model Class Initialized
INFO - 2024-01-23 12:02:13 --> Model Class Initialized
INFO - 2024-01-23 12:02:13 --> Model Class Initialized
INFO - 2024-01-23 12:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 12:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 12:02:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 12:02:13 --> Final output sent to browser
DEBUG - 2024-01-23 12:02:13 --> Total execution time: 0.1626
ERROR - 2024-01-23 12:02:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:02:14 --> Config Class Initialized
INFO - 2024-01-23 12:02:14 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:02:14 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:02:14 --> Utf8 Class Initialized
INFO - 2024-01-23 12:02:14 --> URI Class Initialized
INFO - 2024-01-23 12:02:14 --> Router Class Initialized
INFO - 2024-01-23 12:02:14 --> Output Class Initialized
INFO - 2024-01-23 12:02:14 --> Security Class Initialized
DEBUG - 2024-01-23 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:02:14 --> Input Class Initialized
INFO - 2024-01-23 12:02:14 --> Language Class Initialized
INFO - 2024-01-23 12:02:14 --> Loader Class Initialized
INFO - 2024-01-23 12:02:14 --> Helper loaded: url_helper
INFO - 2024-01-23 12:02:14 --> Helper loaded: file_helper
INFO - 2024-01-23 12:02:14 --> Helper loaded: html_helper
INFO - 2024-01-23 12:02:14 --> Helper loaded: text_helper
INFO - 2024-01-23 12:02:14 --> Helper loaded: form_helper
INFO - 2024-01-23 12:02:14 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:02:14 --> Helper loaded: security_helper
INFO - 2024-01-23 12:02:14 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:02:14 --> Database Driver Class Initialized
INFO - 2024-01-23 12:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:02:14 --> Parser Class Initialized
INFO - 2024-01-23 12:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:02:14 --> Pagination Class Initialized
INFO - 2024-01-23 12:02:14 --> Form Validation Class Initialized
INFO - 2024-01-23 12:02:14 --> Controller Class Initialized
INFO - 2024-01-23 12:02:14 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 12:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:14 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:14 --> Model Class Initialized
INFO - 2024-01-23 12:02:14 --> Final output sent to browser
DEBUG - 2024-01-23 12:02:14 --> Total execution time: 0.0400
ERROR - 2024-01-23 12:02:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:02:15 --> Config Class Initialized
INFO - 2024-01-23 12:02:15 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:02:15 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:02:15 --> Utf8 Class Initialized
INFO - 2024-01-23 12:02:15 --> URI Class Initialized
DEBUG - 2024-01-23 12:02:15 --> No URI present. Default controller set.
INFO - 2024-01-23 12:02:15 --> Router Class Initialized
INFO - 2024-01-23 12:02:15 --> Output Class Initialized
INFO - 2024-01-23 12:02:15 --> Security Class Initialized
DEBUG - 2024-01-23 12:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:02:15 --> Input Class Initialized
INFO - 2024-01-23 12:02:15 --> Language Class Initialized
INFO - 2024-01-23 12:02:15 --> Loader Class Initialized
INFO - 2024-01-23 12:02:15 --> Helper loaded: url_helper
INFO - 2024-01-23 12:02:15 --> Helper loaded: file_helper
INFO - 2024-01-23 12:02:15 --> Helper loaded: html_helper
INFO - 2024-01-23 12:02:15 --> Helper loaded: text_helper
INFO - 2024-01-23 12:02:15 --> Helper loaded: form_helper
INFO - 2024-01-23 12:02:15 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:02:15 --> Helper loaded: security_helper
INFO - 2024-01-23 12:02:15 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:02:15 --> Database Driver Class Initialized
INFO - 2024-01-23 12:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:02:15 --> Parser Class Initialized
INFO - 2024-01-23 12:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:02:15 --> Pagination Class Initialized
INFO - 2024-01-23 12:02:15 --> Form Validation Class Initialized
INFO - 2024-01-23 12:02:15 --> Controller Class Initialized
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 12:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
INFO - 2024-01-23 12:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 12:02:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 12:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 12:02:15 --> Model Class Initialized
INFO - 2024-01-23 12:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 12:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 12:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 12:02:15 --> Final output sent to browser
DEBUG - 2024-01-23 12:02:15 --> Total execution time: 0.2323
ERROR - 2024-01-23 12:02:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:02:33 --> Config Class Initialized
INFO - 2024-01-23 12:02:33 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:02:33 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:02:33 --> Utf8 Class Initialized
INFO - 2024-01-23 12:02:33 --> URI Class Initialized
INFO - 2024-01-23 12:02:33 --> Router Class Initialized
INFO - 2024-01-23 12:02:33 --> Output Class Initialized
INFO - 2024-01-23 12:02:33 --> Security Class Initialized
DEBUG - 2024-01-23 12:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:02:33 --> Input Class Initialized
INFO - 2024-01-23 12:02:33 --> Language Class Initialized
INFO - 2024-01-23 12:02:33 --> Loader Class Initialized
INFO - 2024-01-23 12:02:33 --> Helper loaded: url_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: file_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: html_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: text_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: form_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: security_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:02:33 --> Database Driver Class Initialized
INFO - 2024-01-23 12:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:02:33 --> Parser Class Initialized
INFO - 2024-01-23 12:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:02:33 --> Pagination Class Initialized
INFO - 2024-01-23 12:02:33 --> Form Validation Class Initialized
INFO - 2024-01-23 12:02:33 --> Controller Class Initialized
INFO - 2024-01-23 12:02:33 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:33 --> Model Class Initialized
INFO - 2024-01-23 12:02:33 --> Final output sent to browser
DEBUG - 2024-01-23 12:02:33 --> Total execution time: 0.0180
ERROR - 2024-01-23 12:02:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:02:33 --> Config Class Initialized
INFO - 2024-01-23 12:02:33 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:02:33 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:02:33 --> Utf8 Class Initialized
INFO - 2024-01-23 12:02:33 --> URI Class Initialized
INFO - 2024-01-23 12:02:33 --> Router Class Initialized
INFO - 2024-01-23 12:02:33 --> Output Class Initialized
INFO - 2024-01-23 12:02:33 --> Security Class Initialized
DEBUG - 2024-01-23 12:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:02:33 --> Input Class Initialized
INFO - 2024-01-23 12:02:33 --> Language Class Initialized
INFO - 2024-01-23 12:02:33 --> Loader Class Initialized
INFO - 2024-01-23 12:02:33 --> Helper loaded: url_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: file_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: html_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: text_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: form_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: security_helper
INFO - 2024-01-23 12:02:33 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:02:33 --> Database Driver Class Initialized
INFO - 2024-01-23 12:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:02:33 --> Parser Class Initialized
INFO - 2024-01-23 12:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:02:33 --> Pagination Class Initialized
INFO - 2024-01-23 12:02:33 --> Form Validation Class Initialized
INFO - 2024-01-23 12:02:33 --> Controller Class Initialized
INFO - 2024-01-23 12:02:33 --> Model Class Initialized
DEBUG - 2024-01-23 12:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 12:02:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:02:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 12:02:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 12:02:33 --> Model Class Initialized
INFO - 2024-01-23 12:02:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 12:02:33 --> Final output sent to browser
DEBUG - 2024-01-23 12:02:33 --> Total execution time: 0.0299
ERROR - 2024-01-23 12:03:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:03:03 --> Config Class Initialized
INFO - 2024-01-23 12:03:03 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:03:03 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:03:03 --> Utf8 Class Initialized
INFO - 2024-01-23 12:03:03 --> URI Class Initialized
INFO - 2024-01-23 12:03:03 --> Router Class Initialized
INFO - 2024-01-23 12:03:03 --> Output Class Initialized
INFO - 2024-01-23 12:03:03 --> Security Class Initialized
DEBUG - 2024-01-23 12:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:03:03 --> Input Class Initialized
INFO - 2024-01-23 12:03:03 --> Language Class Initialized
INFO - 2024-01-23 12:03:03 --> Loader Class Initialized
INFO - 2024-01-23 12:03:03 --> Helper loaded: url_helper
INFO - 2024-01-23 12:03:03 --> Helper loaded: file_helper
INFO - 2024-01-23 12:03:03 --> Helper loaded: html_helper
INFO - 2024-01-23 12:03:03 --> Helper loaded: text_helper
INFO - 2024-01-23 12:03:03 --> Helper loaded: form_helper
INFO - 2024-01-23 12:03:03 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:03:03 --> Helper loaded: security_helper
INFO - 2024-01-23 12:03:03 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:03:03 --> Database Driver Class Initialized
INFO - 2024-01-23 12:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:03:03 --> Parser Class Initialized
INFO - 2024-01-23 12:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:03:03 --> Pagination Class Initialized
INFO - 2024-01-23 12:03:03 --> Form Validation Class Initialized
INFO - 2024-01-23 12:03:03 --> Controller Class Initialized
INFO - 2024-01-23 12:03:03 --> Model Class Initialized
DEBUG - 2024-01-23 12:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 12:03:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 12:03:03 --> Model Class Initialized
INFO - 2024-01-23 12:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 12:03:03 --> Final output sent to browser
DEBUG - 2024-01-23 12:03:03 --> Total execution time: 0.0299
ERROR - 2024-01-23 12:17:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:17:58 --> Config Class Initialized
INFO - 2024-01-23 12:17:58 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:17:58 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:17:58 --> Utf8 Class Initialized
INFO - 2024-01-23 12:17:58 --> URI Class Initialized
DEBUG - 2024-01-23 12:17:58 --> No URI present. Default controller set.
INFO - 2024-01-23 12:17:58 --> Router Class Initialized
INFO - 2024-01-23 12:17:58 --> Output Class Initialized
INFO - 2024-01-23 12:17:58 --> Security Class Initialized
DEBUG - 2024-01-23 12:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:17:58 --> Input Class Initialized
INFO - 2024-01-23 12:17:58 --> Language Class Initialized
INFO - 2024-01-23 12:17:58 --> Loader Class Initialized
INFO - 2024-01-23 12:17:58 --> Helper loaded: url_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: file_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: html_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: text_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: form_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: security_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:17:58 --> Database Driver Class Initialized
INFO - 2024-01-23 12:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:17:58 --> Parser Class Initialized
INFO - 2024-01-23 12:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:17:58 --> Pagination Class Initialized
INFO - 2024-01-23 12:17:58 --> Form Validation Class Initialized
INFO - 2024-01-23 12:17:58 --> Controller Class Initialized
INFO - 2024-01-23 12:17:58 --> Model Class Initialized
DEBUG - 2024-01-23 12:17:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-23 12:17:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 12:17:58 --> Config Class Initialized
INFO - 2024-01-23 12:17:58 --> Hooks Class Initialized
DEBUG - 2024-01-23 12:17:58 --> UTF-8 Support Enabled
INFO - 2024-01-23 12:17:58 --> Utf8 Class Initialized
INFO - 2024-01-23 12:17:58 --> URI Class Initialized
INFO - 2024-01-23 12:17:58 --> Router Class Initialized
INFO - 2024-01-23 12:17:58 --> Output Class Initialized
INFO - 2024-01-23 12:17:58 --> Security Class Initialized
DEBUG - 2024-01-23 12:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 12:17:58 --> Input Class Initialized
INFO - 2024-01-23 12:17:58 --> Language Class Initialized
INFO - 2024-01-23 12:17:58 --> Loader Class Initialized
INFO - 2024-01-23 12:17:58 --> Helper loaded: url_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: file_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: html_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: text_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: form_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: lang_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: security_helper
INFO - 2024-01-23 12:17:58 --> Helper loaded: cookie_helper
INFO - 2024-01-23 12:17:58 --> Database Driver Class Initialized
INFO - 2024-01-23 12:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 12:17:58 --> Parser Class Initialized
INFO - 2024-01-23 12:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 12:17:58 --> Pagination Class Initialized
INFO - 2024-01-23 12:17:58 --> Form Validation Class Initialized
INFO - 2024-01-23 12:17:58 --> Controller Class Initialized
INFO - 2024-01-23 12:17:58 --> Model Class Initialized
DEBUG - 2024-01-23 12:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 12:17:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 12:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 12:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 12:17:58 --> Model Class Initialized
INFO - 2024-01-23 12:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 12:17:58 --> Final output sent to browser
DEBUG - 2024-01-23 12:17:58 --> Total execution time: 0.0310
ERROR - 2024-01-23 15:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:19:59 --> Config Class Initialized
INFO - 2024-01-23 15:19:59 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:19:59 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:19:59 --> Utf8 Class Initialized
INFO - 2024-01-23 15:19:59 --> URI Class Initialized
DEBUG - 2024-01-23 15:19:59 --> No URI present. Default controller set.
INFO - 2024-01-23 15:19:59 --> Router Class Initialized
INFO - 2024-01-23 15:19:59 --> Output Class Initialized
INFO - 2024-01-23 15:19:59 --> Security Class Initialized
DEBUG - 2024-01-23 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:19:59 --> Input Class Initialized
INFO - 2024-01-23 15:19:59 --> Language Class Initialized
INFO - 2024-01-23 15:19:59 --> Loader Class Initialized
INFO - 2024-01-23 15:19:59 --> Helper loaded: url_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: file_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: html_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: text_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: form_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: security_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:19:59 --> Database Driver Class Initialized
INFO - 2024-01-23 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:19:59 --> Parser Class Initialized
INFO - 2024-01-23 15:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:19:59 --> Pagination Class Initialized
INFO - 2024-01-23 15:19:59 --> Form Validation Class Initialized
INFO - 2024-01-23 15:19:59 --> Controller Class Initialized
INFO - 2024-01-23 15:19:59 --> Model Class Initialized
DEBUG - 2024-01-23 15:19:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-23 15:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:19:59 --> Config Class Initialized
INFO - 2024-01-23 15:19:59 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:19:59 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:19:59 --> Utf8 Class Initialized
INFO - 2024-01-23 15:19:59 --> URI Class Initialized
INFO - 2024-01-23 15:19:59 --> Router Class Initialized
INFO - 2024-01-23 15:19:59 --> Output Class Initialized
INFO - 2024-01-23 15:19:59 --> Security Class Initialized
DEBUG - 2024-01-23 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:19:59 --> Input Class Initialized
INFO - 2024-01-23 15:19:59 --> Language Class Initialized
INFO - 2024-01-23 15:19:59 --> Loader Class Initialized
INFO - 2024-01-23 15:19:59 --> Helper loaded: url_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: file_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: html_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: text_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: form_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: security_helper
INFO - 2024-01-23 15:19:59 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:19:59 --> Database Driver Class Initialized
INFO - 2024-01-23 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:19:59 --> Parser Class Initialized
INFO - 2024-01-23 15:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:19:59 --> Pagination Class Initialized
INFO - 2024-01-23 15:19:59 --> Form Validation Class Initialized
INFO - 2024-01-23 15:19:59 --> Controller Class Initialized
INFO - 2024-01-23 15:19:59 --> Model Class Initialized
DEBUG - 2024-01-23 15:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 15:19:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:19:59 --> Model Class Initialized
INFO - 2024-01-23 15:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:19:59 --> Final output sent to browser
DEBUG - 2024-01-23 15:19:59 --> Total execution time: 0.0336
ERROR - 2024-01-23 15:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:20:06 --> Config Class Initialized
INFO - 2024-01-23 15:20:06 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:20:06 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:20:06 --> Utf8 Class Initialized
INFO - 2024-01-23 15:20:06 --> URI Class Initialized
DEBUG - 2024-01-23 15:20:06 --> No URI present. Default controller set.
INFO - 2024-01-23 15:20:06 --> Router Class Initialized
INFO - 2024-01-23 15:20:06 --> Output Class Initialized
INFO - 2024-01-23 15:20:06 --> Security Class Initialized
DEBUG - 2024-01-23 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:20:06 --> Input Class Initialized
INFO - 2024-01-23 15:20:06 --> Language Class Initialized
INFO - 2024-01-23 15:20:06 --> Loader Class Initialized
INFO - 2024-01-23 15:20:06 --> Helper loaded: url_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: file_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: html_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: text_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: form_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: security_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:20:06 --> Database Driver Class Initialized
INFO - 2024-01-23 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:20:06 --> Parser Class Initialized
INFO - 2024-01-23 15:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:20:06 --> Pagination Class Initialized
INFO - 2024-01-23 15:20:06 --> Form Validation Class Initialized
INFO - 2024-01-23 15:20:06 --> Controller Class Initialized
INFO - 2024-01-23 15:20:06 --> Model Class Initialized
DEBUG - 2024-01-23 15:20:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-23 15:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:20:06 --> Config Class Initialized
INFO - 2024-01-23 15:20:06 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:20:06 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:20:06 --> Utf8 Class Initialized
INFO - 2024-01-23 15:20:06 --> URI Class Initialized
INFO - 2024-01-23 15:20:06 --> Router Class Initialized
INFO - 2024-01-23 15:20:06 --> Output Class Initialized
INFO - 2024-01-23 15:20:06 --> Security Class Initialized
DEBUG - 2024-01-23 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:20:06 --> Input Class Initialized
INFO - 2024-01-23 15:20:06 --> Language Class Initialized
INFO - 2024-01-23 15:20:06 --> Loader Class Initialized
INFO - 2024-01-23 15:20:06 --> Helper loaded: url_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: file_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: html_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: text_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: form_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: security_helper
INFO - 2024-01-23 15:20:06 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:20:06 --> Database Driver Class Initialized
INFO - 2024-01-23 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:20:06 --> Parser Class Initialized
INFO - 2024-01-23 15:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:20:06 --> Pagination Class Initialized
INFO - 2024-01-23 15:20:06 --> Form Validation Class Initialized
INFO - 2024-01-23 15:20:06 --> Controller Class Initialized
INFO - 2024-01-23 15:20:06 --> Model Class Initialized
DEBUG - 2024-01-23 15:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-23 15:20:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:20:06 --> Model Class Initialized
INFO - 2024-01-23 15:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:20:06 --> Final output sent to browser
DEBUG - 2024-01-23 15:20:06 --> Total execution time: 0.0372
ERROR - 2024-01-23 15:20:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:20:19 --> Config Class Initialized
INFO - 2024-01-23 15:20:19 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:20:19 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:20:19 --> Utf8 Class Initialized
INFO - 2024-01-23 15:20:19 --> URI Class Initialized
INFO - 2024-01-23 15:20:19 --> Router Class Initialized
INFO - 2024-01-23 15:20:19 --> Output Class Initialized
INFO - 2024-01-23 15:20:19 --> Security Class Initialized
DEBUG - 2024-01-23 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:20:19 --> Input Class Initialized
INFO - 2024-01-23 15:20:19 --> Language Class Initialized
INFO - 2024-01-23 15:20:19 --> Loader Class Initialized
INFO - 2024-01-23 15:20:19 --> Helper loaded: url_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: file_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: html_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: text_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: form_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: security_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:20:19 --> Database Driver Class Initialized
INFO - 2024-01-23 15:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:20:19 --> Parser Class Initialized
INFO - 2024-01-23 15:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:20:19 --> Pagination Class Initialized
INFO - 2024-01-23 15:20:19 --> Form Validation Class Initialized
INFO - 2024-01-23 15:20:19 --> Controller Class Initialized
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
DEBUG - 2024-01-23 15:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
INFO - 2024-01-23 15:20:19 --> Final output sent to browser
DEBUG - 2024-01-23 15:20:19 --> Total execution time: 0.0205
ERROR - 2024-01-23 15:20:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:20:19 --> Config Class Initialized
INFO - 2024-01-23 15:20:19 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:20:19 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:20:19 --> Utf8 Class Initialized
INFO - 2024-01-23 15:20:19 --> URI Class Initialized
DEBUG - 2024-01-23 15:20:19 --> No URI present. Default controller set.
INFO - 2024-01-23 15:20:19 --> Router Class Initialized
INFO - 2024-01-23 15:20:19 --> Output Class Initialized
INFO - 2024-01-23 15:20:19 --> Security Class Initialized
DEBUG - 2024-01-23 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:20:19 --> Input Class Initialized
INFO - 2024-01-23 15:20:19 --> Language Class Initialized
INFO - 2024-01-23 15:20:19 --> Loader Class Initialized
INFO - 2024-01-23 15:20:19 --> Helper loaded: url_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: file_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: html_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: text_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: form_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: security_helper
INFO - 2024-01-23 15:20:19 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:20:19 --> Database Driver Class Initialized
INFO - 2024-01-23 15:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:20:19 --> Parser Class Initialized
INFO - 2024-01-23 15:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:20:19 --> Pagination Class Initialized
INFO - 2024-01-23 15:20:19 --> Form Validation Class Initialized
INFO - 2024-01-23 15:20:19 --> Controller Class Initialized
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
DEBUG - 2024-01-23 15:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
DEBUG - 2024-01-23 15:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
DEBUG - 2024-01-23 15:20:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
INFO - 2024-01-23 15:20:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 15:20:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:20:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:20:19 --> Model Class Initialized
INFO - 2024-01-23 15:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 15:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 15:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:20:20 --> Final output sent to browser
DEBUG - 2024-01-23 15:20:20 --> Total execution time: 0.4267
ERROR - 2024-01-23 15:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:20:40 --> Config Class Initialized
INFO - 2024-01-23 15:20:40 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:20:40 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:20:40 --> Utf8 Class Initialized
INFO - 2024-01-23 15:20:40 --> URI Class Initialized
INFO - 2024-01-23 15:20:40 --> Router Class Initialized
INFO - 2024-01-23 15:20:40 --> Output Class Initialized
INFO - 2024-01-23 15:20:40 --> Security Class Initialized
DEBUG - 2024-01-23 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:20:40 --> Input Class Initialized
INFO - 2024-01-23 15:20:40 --> Language Class Initialized
INFO - 2024-01-23 15:20:40 --> Loader Class Initialized
INFO - 2024-01-23 15:20:40 --> Helper loaded: url_helper
INFO - 2024-01-23 15:20:40 --> Helper loaded: file_helper
INFO - 2024-01-23 15:20:40 --> Helper loaded: html_helper
INFO - 2024-01-23 15:20:40 --> Helper loaded: text_helper
INFO - 2024-01-23 15:20:40 --> Helper loaded: form_helper
INFO - 2024-01-23 15:20:40 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:20:40 --> Helper loaded: security_helper
INFO - 2024-01-23 15:20:40 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:20:40 --> Database Driver Class Initialized
INFO - 2024-01-23 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:20:40 --> Parser Class Initialized
INFO - 2024-01-23 15:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:20:40 --> Pagination Class Initialized
INFO - 2024-01-23 15:20:40 --> Form Validation Class Initialized
INFO - 2024-01-23 15:20:40 --> Controller Class Initialized
DEBUG - 2024-01-23 15:20:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:20:40 --> Model Class Initialized
INFO - 2024-01-23 15:20:40 --> Final output sent to browser
DEBUG - 2024-01-23 15:20:40 --> Total execution time: 0.0170
ERROR - 2024-01-23 15:26:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:26:40 --> Config Class Initialized
INFO - 2024-01-23 15:26:40 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:26:40 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:26:40 --> Utf8 Class Initialized
INFO - 2024-01-23 15:26:40 --> URI Class Initialized
DEBUG - 2024-01-23 15:26:40 --> No URI present. Default controller set.
INFO - 2024-01-23 15:26:40 --> Router Class Initialized
INFO - 2024-01-23 15:26:40 --> Output Class Initialized
INFO - 2024-01-23 15:26:40 --> Security Class Initialized
DEBUG - 2024-01-23 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:26:40 --> Input Class Initialized
INFO - 2024-01-23 15:26:40 --> Language Class Initialized
INFO - 2024-01-23 15:26:40 --> Loader Class Initialized
INFO - 2024-01-23 15:26:40 --> Helper loaded: url_helper
INFO - 2024-01-23 15:26:40 --> Helper loaded: file_helper
INFO - 2024-01-23 15:26:40 --> Helper loaded: html_helper
INFO - 2024-01-23 15:26:40 --> Helper loaded: text_helper
INFO - 2024-01-23 15:26:40 --> Helper loaded: form_helper
INFO - 2024-01-23 15:26:40 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:26:40 --> Helper loaded: security_helper
INFO - 2024-01-23 15:26:40 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:26:40 --> Database Driver Class Initialized
INFO - 2024-01-23 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:26:40 --> Parser Class Initialized
INFO - 2024-01-23 15:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:26:40 --> Pagination Class Initialized
INFO - 2024-01-23 15:26:40 --> Form Validation Class Initialized
INFO - 2024-01-23 15:26:40 --> Controller Class Initialized
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
DEBUG - 2024-01-23 15:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
DEBUG - 2024-01-23 15:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
DEBUG - 2024-01-23 15:26:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
INFO - 2024-01-23 15:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 15:26:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:26:40 --> Model Class Initialized
INFO - 2024-01-23 15:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 15:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 15:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:26:40 --> Final output sent to browser
DEBUG - 2024-01-23 15:26:40 --> Total execution time: 0.4105
ERROR - 2024-01-23 15:26:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:26:52 --> Config Class Initialized
INFO - 2024-01-23 15:26:52 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:26:52 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:26:52 --> Utf8 Class Initialized
INFO - 2024-01-23 15:26:52 --> URI Class Initialized
INFO - 2024-01-23 15:26:52 --> Router Class Initialized
INFO - 2024-01-23 15:26:52 --> Output Class Initialized
INFO - 2024-01-23 15:26:52 --> Security Class Initialized
DEBUG - 2024-01-23 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:26:52 --> Input Class Initialized
INFO - 2024-01-23 15:26:52 --> Language Class Initialized
INFO - 2024-01-23 15:26:52 --> Loader Class Initialized
INFO - 2024-01-23 15:26:52 --> Helper loaded: url_helper
INFO - 2024-01-23 15:26:52 --> Helper loaded: file_helper
INFO - 2024-01-23 15:26:52 --> Helper loaded: html_helper
INFO - 2024-01-23 15:26:52 --> Helper loaded: text_helper
INFO - 2024-01-23 15:26:52 --> Helper loaded: form_helper
INFO - 2024-01-23 15:26:52 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:26:52 --> Helper loaded: security_helper
INFO - 2024-01-23 15:26:52 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:26:52 --> Database Driver Class Initialized
INFO - 2024-01-23 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:26:52 --> Parser Class Initialized
INFO - 2024-01-23 15:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:26:52 --> Pagination Class Initialized
INFO - 2024-01-23 15:26:52 --> Form Validation Class Initialized
INFO - 2024-01-23 15:26:52 --> Controller Class Initialized
DEBUG - 2024-01-23 15:26:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:52 --> Model Class Initialized
DEBUG - 2024-01-23 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:52 --> Model Class Initialized
DEBUG - 2024-01-23 15:26:52 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:52 --> Model Class Initialized
INFO - 2024-01-23 15:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-23 15:26:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:26:53 --> Model Class Initialized
INFO - 2024-01-23 15:26:53 --> Model Class Initialized
INFO - 2024-01-23 15:26:53 --> Model Class Initialized
INFO - 2024-01-23 15:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 15:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 15:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:26:53 --> Final output sent to browser
DEBUG - 2024-01-23 15:26:53 --> Total execution time: 0.2113
ERROR - 2024-01-23 15:26:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:26:54 --> Config Class Initialized
INFO - 2024-01-23 15:26:54 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:26:54 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:26:54 --> Utf8 Class Initialized
INFO - 2024-01-23 15:26:54 --> URI Class Initialized
INFO - 2024-01-23 15:26:54 --> Router Class Initialized
INFO - 2024-01-23 15:26:54 --> Output Class Initialized
INFO - 2024-01-23 15:26:54 --> Security Class Initialized
DEBUG - 2024-01-23 15:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:26:54 --> Input Class Initialized
INFO - 2024-01-23 15:26:54 --> Language Class Initialized
INFO - 2024-01-23 15:26:54 --> Loader Class Initialized
INFO - 2024-01-23 15:26:54 --> Helper loaded: url_helper
INFO - 2024-01-23 15:26:54 --> Helper loaded: file_helper
INFO - 2024-01-23 15:26:54 --> Helper loaded: html_helper
INFO - 2024-01-23 15:26:54 --> Helper loaded: text_helper
INFO - 2024-01-23 15:26:54 --> Helper loaded: form_helper
INFO - 2024-01-23 15:26:54 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:26:54 --> Helper loaded: security_helper
INFO - 2024-01-23 15:26:54 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:26:54 --> Database Driver Class Initialized
INFO - 2024-01-23 15:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:26:54 --> Parser Class Initialized
INFO - 2024-01-23 15:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:26:54 --> Pagination Class Initialized
INFO - 2024-01-23 15:26:54 --> Form Validation Class Initialized
INFO - 2024-01-23 15:26:54 --> Controller Class Initialized
DEBUG - 2024-01-23 15:26:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:54 --> Model Class Initialized
DEBUG - 2024-01-23 15:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:26:54 --> Model Class Initialized
INFO - 2024-01-23 15:26:54 --> Final output sent to browser
DEBUG - 2024-01-23 15:26:54 --> Total execution time: 0.0332
ERROR - 2024-01-23 15:27:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:27:04 --> Config Class Initialized
INFO - 2024-01-23 15:27:04 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:27:04 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:27:04 --> Utf8 Class Initialized
INFO - 2024-01-23 15:27:04 --> URI Class Initialized
INFO - 2024-01-23 15:27:04 --> Router Class Initialized
INFO - 2024-01-23 15:27:04 --> Output Class Initialized
INFO - 2024-01-23 15:27:04 --> Security Class Initialized
DEBUG - 2024-01-23 15:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:27:04 --> Input Class Initialized
INFO - 2024-01-23 15:27:04 --> Language Class Initialized
INFO - 2024-01-23 15:27:04 --> Loader Class Initialized
INFO - 2024-01-23 15:27:04 --> Helper loaded: url_helper
INFO - 2024-01-23 15:27:04 --> Helper loaded: file_helper
INFO - 2024-01-23 15:27:04 --> Helper loaded: html_helper
INFO - 2024-01-23 15:27:04 --> Helper loaded: text_helper
INFO - 2024-01-23 15:27:04 --> Helper loaded: form_helper
INFO - 2024-01-23 15:27:04 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:27:04 --> Helper loaded: security_helper
INFO - 2024-01-23 15:27:04 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:27:04 --> Database Driver Class Initialized
INFO - 2024-01-23 15:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:27:04 --> Parser Class Initialized
INFO - 2024-01-23 15:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:27:04 --> Pagination Class Initialized
INFO - 2024-01-23 15:27:04 --> Form Validation Class Initialized
INFO - 2024-01-23 15:27:04 --> Controller Class Initialized
INFO - 2024-01-23 15:27:04 --> Model Class Initialized
DEBUG - 2024-01-23 15:27:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:04 --> Model Class Initialized
DEBUG - 2024-01-23 15:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:04 --> Model Class Initialized
INFO - 2024-01-23 15:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-23 15:27:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:27:04 --> Model Class Initialized
INFO - 2024-01-23 15:27:04 --> Model Class Initialized
INFO - 2024-01-23 15:27:04 --> Model Class Initialized
INFO - 2024-01-23 15:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 15:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 15:27:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:27:04 --> Final output sent to browser
DEBUG - 2024-01-23 15:27:04 --> Total execution time: 0.2298
ERROR - 2024-01-23 15:27:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:27:05 --> Config Class Initialized
INFO - 2024-01-23 15:27:05 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:27:05 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:27:05 --> Utf8 Class Initialized
INFO - 2024-01-23 15:27:05 --> URI Class Initialized
INFO - 2024-01-23 15:27:05 --> Router Class Initialized
INFO - 2024-01-23 15:27:05 --> Output Class Initialized
INFO - 2024-01-23 15:27:05 --> Security Class Initialized
DEBUG - 2024-01-23 15:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:27:05 --> Input Class Initialized
INFO - 2024-01-23 15:27:05 --> Language Class Initialized
INFO - 2024-01-23 15:27:05 --> Loader Class Initialized
INFO - 2024-01-23 15:27:05 --> Helper loaded: url_helper
INFO - 2024-01-23 15:27:05 --> Helper loaded: file_helper
INFO - 2024-01-23 15:27:05 --> Helper loaded: html_helper
INFO - 2024-01-23 15:27:05 --> Helper loaded: text_helper
INFO - 2024-01-23 15:27:05 --> Helper loaded: form_helper
INFO - 2024-01-23 15:27:05 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:27:05 --> Helper loaded: security_helper
INFO - 2024-01-23 15:27:05 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:27:05 --> Database Driver Class Initialized
INFO - 2024-01-23 15:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:27:05 --> Parser Class Initialized
INFO - 2024-01-23 15:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:27:05 --> Pagination Class Initialized
INFO - 2024-01-23 15:27:05 --> Form Validation Class Initialized
INFO - 2024-01-23 15:27:05 --> Controller Class Initialized
INFO - 2024-01-23 15:27:05 --> Model Class Initialized
DEBUG - 2024-01-23 15:27:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:05 --> Model Class Initialized
DEBUG - 2024-01-23 15:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:05 --> Model Class Initialized
INFO - 2024-01-23 15:27:05 --> Final output sent to browser
DEBUG - 2024-01-23 15:27:05 --> Total execution time: 0.0684
ERROR - 2024-01-23 15:27:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:27:45 --> Config Class Initialized
INFO - 2024-01-23 15:27:45 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:27:45 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:27:45 --> Utf8 Class Initialized
INFO - 2024-01-23 15:27:45 --> URI Class Initialized
INFO - 2024-01-23 15:27:45 --> Router Class Initialized
INFO - 2024-01-23 15:27:45 --> Output Class Initialized
INFO - 2024-01-23 15:27:45 --> Security Class Initialized
DEBUG - 2024-01-23 15:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:27:45 --> Input Class Initialized
INFO - 2024-01-23 15:27:45 --> Language Class Initialized
INFO - 2024-01-23 15:27:45 --> Loader Class Initialized
INFO - 2024-01-23 15:27:45 --> Helper loaded: url_helper
INFO - 2024-01-23 15:27:45 --> Helper loaded: file_helper
INFO - 2024-01-23 15:27:45 --> Helper loaded: html_helper
INFO - 2024-01-23 15:27:45 --> Helper loaded: text_helper
INFO - 2024-01-23 15:27:45 --> Helper loaded: form_helper
INFO - 2024-01-23 15:27:45 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:27:45 --> Helper loaded: security_helper
INFO - 2024-01-23 15:27:45 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:27:45 --> Database Driver Class Initialized
INFO - 2024-01-23 15:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:27:45 --> Parser Class Initialized
INFO - 2024-01-23 15:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:27:45 --> Pagination Class Initialized
INFO - 2024-01-23 15:27:45 --> Form Validation Class Initialized
INFO - 2024-01-23 15:27:45 --> Controller Class Initialized
INFO - 2024-01-23 15:27:45 --> Model Class Initialized
DEBUG - 2024-01-23 15:27:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:45 --> Model Class Initialized
DEBUG - 2024-01-23 15:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:45 --> Model Class Initialized
DEBUG - 2024-01-23 15:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-23 15:27:45 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-01-23 15:27:45 --> Final output sent to browser
DEBUG - 2024-01-23 15:27:45 --> Total execution time: 0.2039
ERROR - 2024-01-23 15:28:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:28:02 --> Config Class Initialized
INFO - 2024-01-23 15:28:02 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:28:02 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:28:02 --> Utf8 Class Initialized
INFO - 2024-01-23 15:28:02 --> URI Class Initialized
INFO - 2024-01-23 15:28:02 --> Router Class Initialized
INFO - 2024-01-23 15:28:02 --> Output Class Initialized
INFO - 2024-01-23 15:28:02 --> Security Class Initialized
DEBUG - 2024-01-23 15:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:28:02 --> Input Class Initialized
INFO - 2024-01-23 15:28:02 --> Language Class Initialized
INFO - 2024-01-23 15:28:02 --> Loader Class Initialized
INFO - 2024-01-23 15:28:02 --> Helper loaded: url_helper
INFO - 2024-01-23 15:28:02 --> Helper loaded: file_helper
INFO - 2024-01-23 15:28:02 --> Helper loaded: html_helper
INFO - 2024-01-23 15:28:02 --> Helper loaded: text_helper
INFO - 2024-01-23 15:28:02 --> Helper loaded: form_helper
INFO - 2024-01-23 15:28:02 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:28:02 --> Helper loaded: security_helper
INFO - 2024-01-23 15:28:02 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:28:02 --> Database Driver Class Initialized
INFO - 2024-01-23 15:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:28:02 --> Parser Class Initialized
INFO - 2024-01-23 15:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:28:02 --> Pagination Class Initialized
INFO - 2024-01-23 15:28:02 --> Form Validation Class Initialized
INFO - 2024-01-23 15:28:02 --> Controller Class Initialized
DEBUG - 2024-01-23 15:28:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:02 --> Model Class Initialized
DEBUG - 2024-01-23 15:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:02 --> Model Class Initialized
DEBUG - 2024-01-23 15:28:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:02 --> Model Class Initialized
INFO - 2024-01-23 15:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-23 15:28:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:28:02 --> Model Class Initialized
INFO - 2024-01-23 15:28:02 --> Model Class Initialized
INFO - 2024-01-23 15:28:02 --> Model Class Initialized
INFO - 2024-01-23 15:28:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 15:28:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 15:28:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:28:03 --> Final output sent to browser
DEBUG - 2024-01-23 15:28:03 --> Total execution time: 0.2406
ERROR - 2024-01-23 15:28:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:28:04 --> Config Class Initialized
INFO - 2024-01-23 15:28:04 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:28:04 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:28:04 --> Utf8 Class Initialized
INFO - 2024-01-23 15:28:04 --> URI Class Initialized
INFO - 2024-01-23 15:28:04 --> Router Class Initialized
INFO - 2024-01-23 15:28:04 --> Output Class Initialized
INFO - 2024-01-23 15:28:04 --> Security Class Initialized
DEBUG - 2024-01-23 15:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:28:04 --> Input Class Initialized
INFO - 2024-01-23 15:28:04 --> Language Class Initialized
INFO - 2024-01-23 15:28:04 --> Loader Class Initialized
INFO - 2024-01-23 15:28:04 --> Helper loaded: url_helper
INFO - 2024-01-23 15:28:04 --> Helper loaded: file_helper
INFO - 2024-01-23 15:28:04 --> Helper loaded: html_helper
INFO - 2024-01-23 15:28:04 --> Helper loaded: text_helper
INFO - 2024-01-23 15:28:04 --> Helper loaded: form_helper
INFO - 2024-01-23 15:28:04 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:28:04 --> Helper loaded: security_helper
INFO - 2024-01-23 15:28:04 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:28:04 --> Database Driver Class Initialized
INFO - 2024-01-23 15:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:28:04 --> Parser Class Initialized
INFO - 2024-01-23 15:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:28:04 --> Pagination Class Initialized
INFO - 2024-01-23 15:28:04 --> Form Validation Class Initialized
INFO - 2024-01-23 15:28:04 --> Controller Class Initialized
DEBUG - 2024-01-23 15:28:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:04 --> Model Class Initialized
DEBUG - 2024-01-23 15:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:04 --> Model Class Initialized
INFO - 2024-01-23 15:28:04 --> Final output sent to browser
DEBUG - 2024-01-23 15:28:04 --> Total execution time: 0.0390
ERROR - 2024-01-23 15:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 15:28:58 --> Config Class Initialized
INFO - 2024-01-23 15:28:58 --> Hooks Class Initialized
DEBUG - 2024-01-23 15:28:58 --> UTF-8 Support Enabled
INFO - 2024-01-23 15:28:58 --> Utf8 Class Initialized
INFO - 2024-01-23 15:28:58 --> URI Class Initialized
DEBUG - 2024-01-23 15:28:58 --> No URI present. Default controller set.
INFO - 2024-01-23 15:28:58 --> Router Class Initialized
INFO - 2024-01-23 15:28:58 --> Output Class Initialized
INFO - 2024-01-23 15:28:58 --> Security Class Initialized
DEBUG - 2024-01-23 15:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 15:28:58 --> Input Class Initialized
INFO - 2024-01-23 15:28:58 --> Language Class Initialized
INFO - 2024-01-23 15:28:58 --> Loader Class Initialized
INFO - 2024-01-23 15:28:58 --> Helper loaded: url_helper
INFO - 2024-01-23 15:28:58 --> Helper loaded: file_helper
INFO - 2024-01-23 15:28:58 --> Helper loaded: html_helper
INFO - 2024-01-23 15:28:58 --> Helper loaded: text_helper
INFO - 2024-01-23 15:28:58 --> Helper loaded: form_helper
INFO - 2024-01-23 15:28:58 --> Helper loaded: lang_helper
INFO - 2024-01-23 15:28:58 --> Helper loaded: security_helper
INFO - 2024-01-23 15:28:58 --> Helper loaded: cookie_helper
INFO - 2024-01-23 15:28:58 --> Database Driver Class Initialized
INFO - 2024-01-23 15:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-23 15:28:58 --> Parser Class Initialized
INFO - 2024-01-23 15:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-23 15:28:58 --> Pagination Class Initialized
INFO - 2024-01-23 15:28:58 --> Form Validation Class Initialized
INFO - 2024-01-23 15:28:58 --> Controller Class Initialized
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
DEBUG - 2024-01-23 15:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
DEBUG - 2024-01-23 15:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
DEBUG - 2024-01-23 15:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-23 15:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
INFO - 2024-01-23 15:28:58 --> Model Class Initialized
INFO - 2024-01-23 15:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-23 15:28:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-23 15:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-23 15:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-23 15:28:59 --> Model Class Initialized
INFO - 2024-01-23 15:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-23 15:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-23 15:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-23 15:28:59 --> Final output sent to browser
DEBUG - 2024-01-23 15:28:59 --> Total execution time: 0.4189
ERROR - 2024-01-23 19:30:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 19:30:23 --> Config Class Initialized
INFO - 2024-01-23 19:30:23 --> Hooks Class Initialized
DEBUG - 2024-01-23 19:30:23 --> UTF-8 Support Enabled
INFO - 2024-01-23 19:30:23 --> Utf8 Class Initialized
INFO - 2024-01-23 19:30:23 --> URI Class Initialized
INFO - 2024-01-23 19:30:23 --> Router Class Initialized
INFO - 2024-01-23 19:30:23 --> Output Class Initialized
INFO - 2024-01-23 19:30:23 --> Security Class Initialized
DEBUG - 2024-01-23 19:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 19:30:23 --> Input Class Initialized
INFO - 2024-01-23 19:30:23 --> Language Class Initialized
ERROR - 2024-01-23 19:30:23 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-23 22:57:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-23 22:57:56 --> Config Class Initialized
INFO - 2024-01-23 22:57:56 --> Hooks Class Initialized
DEBUG - 2024-01-23 22:57:56 --> UTF-8 Support Enabled
INFO - 2024-01-23 22:57:56 --> Utf8 Class Initialized
INFO - 2024-01-23 22:57:56 --> URI Class Initialized
INFO - 2024-01-23 22:57:56 --> Router Class Initialized
INFO - 2024-01-23 22:57:56 --> Output Class Initialized
INFO - 2024-01-23 22:57:56 --> Security Class Initialized
DEBUG - 2024-01-23 22:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-23 22:57:56 --> Input Class Initialized
INFO - 2024-01-23 22:57:56 --> Language Class Initialized
ERROR - 2024-01-23 22:57:56 --> 404 Page Not Found: Well-known/assetlinks.json
