<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-28 05:09:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 05:09:24 --> Config Class Initialized
INFO - 2023-09-28 05:09:24 --> Hooks Class Initialized
DEBUG - 2023-09-28 05:09:24 --> UTF-8 Support Enabled
INFO - 2023-09-28 05:09:24 --> Utf8 Class Initialized
INFO - 2023-09-28 05:09:24 --> URI Class Initialized
DEBUG - 2023-09-28 05:09:24 --> No URI present. Default controller set.
INFO - 2023-09-28 05:09:24 --> Router Class Initialized
INFO - 2023-09-28 05:09:24 --> Output Class Initialized
INFO - 2023-09-28 05:09:24 --> Security Class Initialized
DEBUG - 2023-09-28 05:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 05:09:24 --> Input Class Initialized
INFO - 2023-09-28 05:09:24 --> Language Class Initialized
INFO - 2023-09-28 05:09:24 --> Loader Class Initialized
INFO - 2023-09-28 05:09:24 --> Helper loaded: url_helper
INFO - 2023-09-28 05:09:24 --> Helper loaded: file_helper
INFO - 2023-09-28 05:09:24 --> Helper loaded: html_helper
INFO - 2023-09-28 05:09:24 --> Helper loaded: text_helper
INFO - 2023-09-28 05:09:24 --> Helper loaded: form_helper
INFO - 2023-09-28 05:09:24 --> Helper loaded: lang_helper
INFO - 2023-09-28 05:09:24 --> Helper loaded: security_helper
INFO - 2023-09-28 05:09:24 --> Helper loaded: cookie_helper
INFO - 2023-09-28 05:09:24 --> Database Driver Class Initialized
INFO - 2023-09-28 05:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 05:09:24 --> Parser Class Initialized
INFO - 2023-09-28 05:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 05:09:24 --> Pagination Class Initialized
INFO - 2023-09-28 05:09:24 --> Form Validation Class Initialized
INFO - 2023-09-28 05:09:24 --> Controller Class Initialized
INFO - 2023-09-28 05:09:24 --> Model Class Initialized
DEBUG - 2023-09-28 05:09:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 05:09:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 05:09:25 --> Config Class Initialized
INFO - 2023-09-28 05:09:25 --> Hooks Class Initialized
DEBUG - 2023-09-28 05:09:25 --> UTF-8 Support Enabled
INFO - 2023-09-28 05:09:25 --> Utf8 Class Initialized
INFO - 2023-09-28 05:09:25 --> URI Class Initialized
INFO - 2023-09-28 05:09:25 --> Router Class Initialized
INFO - 2023-09-28 05:09:25 --> Output Class Initialized
INFO - 2023-09-28 05:09:25 --> Security Class Initialized
DEBUG - 2023-09-28 05:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 05:09:25 --> Input Class Initialized
INFO - 2023-09-28 05:09:25 --> Language Class Initialized
INFO - 2023-09-28 05:09:25 --> Loader Class Initialized
INFO - 2023-09-28 05:09:25 --> Helper loaded: url_helper
INFO - 2023-09-28 05:09:25 --> Helper loaded: file_helper
INFO - 2023-09-28 05:09:25 --> Helper loaded: html_helper
INFO - 2023-09-28 05:09:25 --> Helper loaded: text_helper
INFO - 2023-09-28 05:09:25 --> Helper loaded: form_helper
INFO - 2023-09-28 05:09:25 --> Helper loaded: lang_helper
INFO - 2023-09-28 05:09:25 --> Helper loaded: security_helper
INFO - 2023-09-28 05:09:25 --> Helper loaded: cookie_helper
INFO - 2023-09-28 05:09:25 --> Database Driver Class Initialized
INFO - 2023-09-28 05:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 05:09:25 --> Parser Class Initialized
INFO - 2023-09-28 05:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 05:09:25 --> Pagination Class Initialized
INFO - 2023-09-28 05:09:25 --> Form Validation Class Initialized
INFO - 2023-09-28 05:09:25 --> Controller Class Initialized
INFO - 2023-09-28 05:09:25 --> Model Class Initialized
DEBUG - 2023-09-28 05:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 05:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-28 05:09:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 05:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 05:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 05:09:25 --> Model Class Initialized
INFO - 2023-09-28 05:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 05:09:25 --> Final output sent to browser
DEBUG - 2023-09-28 05:09:25 --> Total execution time: 0.0338
ERROR - 2023-09-28 07:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 07:25:26 --> Config Class Initialized
INFO - 2023-09-28 07:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-28 07:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-28 07:25:26 --> Utf8 Class Initialized
INFO - 2023-09-28 07:25:26 --> URI Class Initialized
DEBUG - 2023-09-28 07:25:26 --> No URI present. Default controller set.
INFO - 2023-09-28 07:25:26 --> Router Class Initialized
INFO - 2023-09-28 07:25:26 --> Output Class Initialized
INFO - 2023-09-28 07:25:26 --> Security Class Initialized
DEBUG - 2023-09-28 07:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 07:25:26 --> Input Class Initialized
INFO - 2023-09-28 07:25:26 --> Language Class Initialized
INFO - 2023-09-28 07:25:26 --> Loader Class Initialized
INFO - 2023-09-28 07:25:26 --> Helper loaded: url_helper
INFO - 2023-09-28 07:25:26 --> Helper loaded: file_helper
INFO - 2023-09-28 07:25:26 --> Helper loaded: html_helper
INFO - 2023-09-28 07:25:26 --> Helper loaded: text_helper
INFO - 2023-09-28 07:25:26 --> Helper loaded: form_helper
INFO - 2023-09-28 07:25:26 --> Helper loaded: lang_helper
INFO - 2023-09-28 07:25:26 --> Helper loaded: security_helper
INFO - 2023-09-28 07:25:26 --> Helper loaded: cookie_helper
INFO - 2023-09-28 07:25:26 --> Database Driver Class Initialized
INFO - 2023-09-28 07:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 07:25:26 --> Parser Class Initialized
INFO - 2023-09-28 07:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 07:25:26 --> Pagination Class Initialized
INFO - 2023-09-28 07:25:26 --> Form Validation Class Initialized
INFO - 2023-09-28 07:25:26 --> Controller Class Initialized
INFO - 2023-09-28 07:25:26 --> Model Class Initialized
DEBUG - 2023-09-28 07:25:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 08:21:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:21:00 --> Config Class Initialized
INFO - 2023-09-28 08:21:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:21:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:21:00 --> Utf8 Class Initialized
INFO - 2023-09-28 08:21:00 --> URI Class Initialized
DEBUG - 2023-09-28 08:21:00 --> No URI present. Default controller set.
INFO - 2023-09-28 08:21:00 --> Router Class Initialized
INFO - 2023-09-28 08:21:00 --> Output Class Initialized
INFO - 2023-09-28 08:21:00 --> Security Class Initialized
DEBUG - 2023-09-28 08:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:21:00 --> Input Class Initialized
INFO - 2023-09-28 08:21:00 --> Language Class Initialized
INFO - 2023-09-28 08:21:00 --> Loader Class Initialized
INFO - 2023-09-28 08:21:00 --> Helper loaded: url_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: file_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: html_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: text_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: form_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: security_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:21:00 --> Database Driver Class Initialized
INFO - 2023-09-28 08:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:21:00 --> Parser Class Initialized
INFO - 2023-09-28 08:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:21:00 --> Pagination Class Initialized
INFO - 2023-09-28 08:21:00 --> Form Validation Class Initialized
INFO - 2023-09-28 08:21:00 --> Controller Class Initialized
INFO - 2023-09-28 08:21:00 --> Model Class Initialized
DEBUG - 2023-09-28 08:21:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 08:21:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:21:00 --> Config Class Initialized
INFO - 2023-09-28 08:21:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:21:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:21:00 --> Utf8 Class Initialized
INFO - 2023-09-28 08:21:00 --> URI Class Initialized
INFO - 2023-09-28 08:21:00 --> Router Class Initialized
INFO - 2023-09-28 08:21:00 --> Output Class Initialized
INFO - 2023-09-28 08:21:00 --> Security Class Initialized
DEBUG - 2023-09-28 08:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:21:00 --> Input Class Initialized
INFO - 2023-09-28 08:21:00 --> Language Class Initialized
INFO - 2023-09-28 08:21:00 --> Loader Class Initialized
INFO - 2023-09-28 08:21:00 --> Helper loaded: url_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: file_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: html_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: text_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: form_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: security_helper
INFO - 2023-09-28 08:21:00 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:21:00 --> Database Driver Class Initialized
INFO - 2023-09-28 08:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:21:00 --> Parser Class Initialized
INFO - 2023-09-28 08:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:21:00 --> Pagination Class Initialized
INFO - 2023-09-28 08:21:00 --> Form Validation Class Initialized
INFO - 2023-09-28 08:21:00 --> Controller Class Initialized
INFO - 2023-09-28 08:21:00 --> Model Class Initialized
DEBUG - 2023-09-28 08:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:21:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-28 08:21:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:21:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:21:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:21:00 --> Model Class Initialized
INFO - 2023-09-28 08:21:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:21:00 --> Final output sent to browser
DEBUG - 2023-09-28 08:21:00 --> Total execution time: 0.0315
ERROR - 2023-09-28 08:21:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:21:35 --> Config Class Initialized
INFO - 2023-09-28 08:21:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:21:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:21:35 --> Utf8 Class Initialized
INFO - 2023-09-28 08:21:35 --> URI Class Initialized
INFO - 2023-09-28 08:21:35 --> Router Class Initialized
INFO - 2023-09-28 08:21:35 --> Output Class Initialized
INFO - 2023-09-28 08:21:35 --> Security Class Initialized
DEBUG - 2023-09-28 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:21:35 --> Input Class Initialized
INFO - 2023-09-28 08:21:35 --> Language Class Initialized
INFO - 2023-09-28 08:21:35 --> Loader Class Initialized
INFO - 2023-09-28 08:21:35 --> Helper loaded: url_helper
INFO - 2023-09-28 08:21:35 --> Helper loaded: file_helper
INFO - 2023-09-28 08:21:35 --> Helper loaded: html_helper
INFO - 2023-09-28 08:21:35 --> Helper loaded: text_helper
INFO - 2023-09-28 08:21:35 --> Helper loaded: form_helper
INFO - 2023-09-28 08:21:35 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:21:35 --> Helper loaded: security_helper
INFO - 2023-09-28 08:21:35 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:21:35 --> Database Driver Class Initialized
INFO - 2023-09-28 08:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:21:35 --> Parser Class Initialized
INFO - 2023-09-28 08:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:21:35 --> Pagination Class Initialized
INFO - 2023-09-28 08:21:35 --> Form Validation Class Initialized
INFO - 2023-09-28 08:21:35 --> Controller Class Initialized
INFO - 2023-09-28 08:21:35 --> Model Class Initialized
DEBUG - 2023-09-28 08:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:21:35 --> Model Class Initialized
INFO - 2023-09-28 08:21:35 --> Final output sent to browser
DEBUG - 2023-09-28 08:21:35 --> Total execution time: 0.0206
ERROR - 2023-09-28 08:21:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:21:36 --> Config Class Initialized
INFO - 2023-09-28 08:21:36 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:21:36 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:21:36 --> Utf8 Class Initialized
INFO - 2023-09-28 08:21:36 --> URI Class Initialized
INFO - 2023-09-28 08:21:36 --> Router Class Initialized
INFO - 2023-09-28 08:21:36 --> Output Class Initialized
INFO - 2023-09-28 08:21:36 --> Security Class Initialized
DEBUG - 2023-09-28 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:21:36 --> Input Class Initialized
INFO - 2023-09-28 08:21:36 --> Language Class Initialized
INFO - 2023-09-28 08:21:36 --> Loader Class Initialized
INFO - 2023-09-28 08:21:36 --> Helper loaded: url_helper
INFO - 2023-09-28 08:21:36 --> Helper loaded: file_helper
INFO - 2023-09-28 08:21:36 --> Helper loaded: html_helper
INFO - 2023-09-28 08:21:36 --> Helper loaded: text_helper
INFO - 2023-09-28 08:21:36 --> Helper loaded: form_helper
INFO - 2023-09-28 08:21:36 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:21:36 --> Helper loaded: security_helper
INFO - 2023-09-28 08:21:36 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:21:36 --> Database Driver Class Initialized
INFO - 2023-09-28 08:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:21:36 --> Parser Class Initialized
INFO - 2023-09-28 08:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:21:36 --> Pagination Class Initialized
INFO - 2023-09-28 08:21:36 --> Form Validation Class Initialized
INFO - 2023-09-28 08:21:36 --> Controller Class Initialized
INFO - 2023-09-28 08:21:36 --> Model Class Initialized
DEBUG - 2023-09-28 08:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:21:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-28 08:21:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:21:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:21:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:21:36 --> Model Class Initialized
INFO - 2023-09-28 08:21:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:21:36 --> Final output sent to browser
DEBUG - 2023-09-28 08:21:36 --> Total execution time: 0.0294
ERROR - 2023-09-28 08:22:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:22:17 --> Config Class Initialized
INFO - 2023-09-28 08:22:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:22:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:22:17 --> Utf8 Class Initialized
INFO - 2023-09-28 08:22:17 --> URI Class Initialized
INFO - 2023-09-28 08:22:17 --> Router Class Initialized
INFO - 2023-09-28 08:22:17 --> Output Class Initialized
INFO - 2023-09-28 08:22:17 --> Security Class Initialized
DEBUG - 2023-09-28 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:22:17 --> Input Class Initialized
INFO - 2023-09-28 08:22:17 --> Language Class Initialized
INFO - 2023-09-28 08:22:17 --> Loader Class Initialized
INFO - 2023-09-28 08:22:17 --> Helper loaded: url_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: file_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: html_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: text_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: form_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: security_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:22:17 --> Database Driver Class Initialized
INFO - 2023-09-28 08:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:22:17 --> Parser Class Initialized
INFO - 2023-09-28 08:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:22:17 --> Pagination Class Initialized
INFO - 2023-09-28 08:22:17 --> Form Validation Class Initialized
INFO - 2023-09-28 08:22:17 --> Controller Class Initialized
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
INFO - 2023-09-28 08:22:17 --> Final output sent to browser
DEBUG - 2023-09-28 08:22:17 --> Total execution time: 0.0211
ERROR - 2023-09-28 08:22:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:22:17 --> Config Class Initialized
INFO - 2023-09-28 08:22:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:22:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:22:17 --> Utf8 Class Initialized
INFO - 2023-09-28 08:22:17 --> URI Class Initialized
DEBUG - 2023-09-28 08:22:17 --> No URI present. Default controller set.
INFO - 2023-09-28 08:22:17 --> Router Class Initialized
INFO - 2023-09-28 08:22:17 --> Output Class Initialized
INFO - 2023-09-28 08:22:17 --> Security Class Initialized
DEBUG - 2023-09-28 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:22:17 --> Input Class Initialized
INFO - 2023-09-28 08:22:17 --> Language Class Initialized
INFO - 2023-09-28 08:22:17 --> Loader Class Initialized
INFO - 2023-09-28 08:22:17 --> Helper loaded: url_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: file_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: html_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: text_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: form_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: security_helper
INFO - 2023-09-28 08:22:17 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:22:17 --> Database Driver Class Initialized
INFO - 2023-09-28 08:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:22:17 --> Parser Class Initialized
INFO - 2023-09-28 08:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:22:17 --> Pagination Class Initialized
INFO - 2023-09-28 08:22:17 --> Form Validation Class Initialized
INFO - 2023-09-28 08:22:17 --> Controller Class Initialized
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
INFO - 2023-09-28 08:22:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 08:22:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:22:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:22:17 --> Model Class Initialized
INFO - 2023-09-28 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:22:18 --> Final output sent to browser
DEBUG - 2023-09-28 08:22:18 --> Total execution time: 0.2144
ERROR - 2023-09-28 08:22:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:22:19 --> Config Class Initialized
INFO - 2023-09-28 08:22:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:22:19 --> Utf8 Class Initialized
INFO - 2023-09-28 08:22:19 --> URI Class Initialized
INFO - 2023-09-28 08:22:19 --> Router Class Initialized
INFO - 2023-09-28 08:22:19 --> Output Class Initialized
INFO - 2023-09-28 08:22:19 --> Security Class Initialized
DEBUG - 2023-09-28 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:22:19 --> Input Class Initialized
INFO - 2023-09-28 08:22:19 --> Language Class Initialized
INFO - 2023-09-28 08:22:19 --> Loader Class Initialized
INFO - 2023-09-28 08:22:19 --> Helper loaded: url_helper
INFO - 2023-09-28 08:22:19 --> Helper loaded: file_helper
INFO - 2023-09-28 08:22:19 --> Helper loaded: html_helper
INFO - 2023-09-28 08:22:19 --> Helper loaded: text_helper
INFO - 2023-09-28 08:22:19 --> Helper loaded: form_helper
INFO - 2023-09-28 08:22:19 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:22:19 --> Helper loaded: security_helper
INFO - 2023-09-28 08:22:19 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:22:19 --> Database Driver Class Initialized
INFO - 2023-09-28 08:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:22:19 --> Parser Class Initialized
INFO - 2023-09-28 08:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:22:19 --> Pagination Class Initialized
INFO - 2023-09-28 08:22:19 --> Form Validation Class Initialized
INFO - 2023-09-28 08:22:19 --> Controller Class Initialized
DEBUG - 2023-09-28 08:22:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:19 --> Model Class Initialized
INFO - 2023-09-28 08:22:19 --> Final output sent to browser
DEBUG - 2023-09-28 08:22:19 --> Total execution time: 0.0135
ERROR - 2023-09-28 08:22:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:22:30 --> Config Class Initialized
INFO - 2023-09-28 08:22:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:22:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:22:30 --> Utf8 Class Initialized
INFO - 2023-09-28 08:22:30 --> URI Class Initialized
INFO - 2023-09-28 08:22:30 --> Router Class Initialized
INFO - 2023-09-28 08:22:30 --> Output Class Initialized
INFO - 2023-09-28 08:22:30 --> Security Class Initialized
DEBUG - 2023-09-28 08:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:22:30 --> Input Class Initialized
INFO - 2023-09-28 08:22:30 --> Language Class Initialized
INFO - 2023-09-28 08:22:30 --> Loader Class Initialized
INFO - 2023-09-28 08:22:30 --> Helper loaded: url_helper
INFO - 2023-09-28 08:22:30 --> Helper loaded: file_helper
INFO - 2023-09-28 08:22:30 --> Helper loaded: html_helper
INFO - 2023-09-28 08:22:30 --> Helper loaded: text_helper
INFO - 2023-09-28 08:22:30 --> Helper loaded: form_helper
INFO - 2023-09-28 08:22:30 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:22:30 --> Helper loaded: security_helper
INFO - 2023-09-28 08:22:30 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:22:30 --> Database Driver Class Initialized
INFO - 2023-09-28 08:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:22:30 --> Parser Class Initialized
INFO - 2023-09-28 08:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:22:30 --> Pagination Class Initialized
INFO - 2023-09-28 08:22:30 --> Form Validation Class Initialized
INFO - 2023-09-28 08:22:30 --> Controller Class Initialized
INFO - 2023-09-28 08:22:30 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:30 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:30 --> Model Class Initialized
INFO - 2023-09-28 08:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 08:22:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:22:30 --> Model Class Initialized
INFO - 2023-09-28 08:22:30 --> Model Class Initialized
INFO - 2023-09-28 08:22:30 --> Model Class Initialized
INFO - 2023-09-28 08:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 08:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 08:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:22:30 --> Final output sent to browser
DEBUG - 2023-09-28 08:22:30 --> Total execution time: 0.1614
ERROR - 2023-09-28 08:22:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:22:31 --> Config Class Initialized
INFO - 2023-09-28 08:22:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:22:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:22:31 --> Utf8 Class Initialized
INFO - 2023-09-28 08:22:31 --> URI Class Initialized
INFO - 2023-09-28 08:22:31 --> Router Class Initialized
INFO - 2023-09-28 08:22:31 --> Output Class Initialized
INFO - 2023-09-28 08:22:31 --> Security Class Initialized
DEBUG - 2023-09-28 08:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:22:31 --> Input Class Initialized
INFO - 2023-09-28 08:22:31 --> Language Class Initialized
INFO - 2023-09-28 08:22:31 --> Loader Class Initialized
INFO - 2023-09-28 08:22:31 --> Helper loaded: url_helper
INFO - 2023-09-28 08:22:31 --> Helper loaded: file_helper
INFO - 2023-09-28 08:22:31 --> Helper loaded: html_helper
INFO - 2023-09-28 08:22:31 --> Helper loaded: text_helper
INFO - 2023-09-28 08:22:31 --> Helper loaded: form_helper
INFO - 2023-09-28 08:22:31 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:22:31 --> Helper loaded: security_helper
INFO - 2023-09-28 08:22:31 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:22:31 --> Database Driver Class Initialized
INFO - 2023-09-28 08:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:22:31 --> Parser Class Initialized
INFO - 2023-09-28 08:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:22:31 --> Pagination Class Initialized
INFO - 2023-09-28 08:22:31 --> Form Validation Class Initialized
INFO - 2023-09-28 08:22:31 --> Controller Class Initialized
INFO - 2023-09-28 08:22:31 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:31 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:31 --> Model Class Initialized
INFO - 2023-09-28 08:22:31 --> Final output sent to browser
DEBUG - 2023-09-28 08:22:31 --> Total execution time: 0.0624
ERROR - 2023-09-28 08:22:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:22:41 --> Config Class Initialized
INFO - 2023-09-28 08:22:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:22:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:22:41 --> Utf8 Class Initialized
INFO - 2023-09-28 08:22:41 --> URI Class Initialized
INFO - 2023-09-28 08:22:41 --> Router Class Initialized
INFO - 2023-09-28 08:22:41 --> Output Class Initialized
INFO - 2023-09-28 08:22:41 --> Security Class Initialized
DEBUG - 2023-09-28 08:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:22:41 --> Input Class Initialized
INFO - 2023-09-28 08:22:41 --> Language Class Initialized
INFO - 2023-09-28 08:22:41 --> Loader Class Initialized
INFO - 2023-09-28 08:22:41 --> Helper loaded: url_helper
INFO - 2023-09-28 08:22:41 --> Helper loaded: file_helper
INFO - 2023-09-28 08:22:41 --> Helper loaded: html_helper
INFO - 2023-09-28 08:22:41 --> Helper loaded: text_helper
INFO - 2023-09-28 08:22:41 --> Helper loaded: form_helper
INFO - 2023-09-28 08:22:41 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:22:41 --> Helper loaded: security_helper
INFO - 2023-09-28 08:22:41 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:22:41 --> Database Driver Class Initialized
INFO - 2023-09-28 08:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:22:41 --> Parser Class Initialized
INFO - 2023-09-28 08:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:22:41 --> Pagination Class Initialized
INFO - 2023-09-28 08:22:41 --> Form Validation Class Initialized
INFO - 2023-09-28 08:22:41 --> Controller Class Initialized
INFO - 2023-09-28 08:22:41 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:41 --> Model Class Initialized
DEBUG - 2023-09-28 08:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:22:41 --> Model Class Initialized
INFO - 2023-09-28 08:22:42 --> Final output sent to browser
DEBUG - 2023-09-28 08:22:42 --> Total execution time: 0.7356
ERROR - 2023-09-28 08:23:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:23:19 --> Config Class Initialized
INFO - 2023-09-28 08:23:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:23:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:23:19 --> Utf8 Class Initialized
INFO - 2023-09-28 08:23:19 --> URI Class Initialized
DEBUG - 2023-09-28 08:23:19 --> No URI present. Default controller set.
INFO - 2023-09-28 08:23:19 --> Router Class Initialized
INFO - 2023-09-28 08:23:19 --> Output Class Initialized
INFO - 2023-09-28 08:23:19 --> Security Class Initialized
DEBUG - 2023-09-28 08:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:23:19 --> Input Class Initialized
INFO - 2023-09-28 08:23:19 --> Language Class Initialized
INFO - 2023-09-28 08:23:19 --> Loader Class Initialized
INFO - 2023-09-28 08:23:19 --> Helper loaded: url_helper
INFO - 2023-09-28 08:23:19 --> Helper loaded: file_helper
INFO - 2023-09-28 08:23:19 --> Helper loaded: html_helper
INFO - 2023-09-28 08:23:19 --> Helper loaded: text_helper
INFO - 2023-09-28 08:23:19 --> Helper loaded: form_helper
INFO - 2023-09-28 08:23:19 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:23:19 --> Helper loaded: security_helper
INFO - 2023-09-28 08:23:19 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:23:19 --> Database Driver Class Initialized
INFO - 2023-09-28 08:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:23:19 --> Parser Class Initialized
INFO - 2023-09-28 08:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:23:19 --> Pagination Class Initialized
INFO - 2023-09-28 08:23:19 --> Form Validation Class Initialized
INFO - 2023-09-28 08:23:19 --> Controller Class Initialized
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
INFO - 2023-09-28 08:23:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 08:23:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:23:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:23:19 --> Model Class Initialized
INFO - 2023-09-28 08:23:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 08:23:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 08:23:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:23:19 --> Final output sent to browser
DEBUG - 2023-09-28 08:23:19 --> Total execution time: 0.2129
ERROR - 2023-09-28 08:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:23:31 --> Config Class Initialized
INFO - 2023-09-28 08:23:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:23:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:23:31 --> Utf8 Class Initialized
INFO - 2023-09-28 08:23:31 --> URI Class Initialized
INFO - 2023-09-28 08:23:31 --> Router Class Initialized
INFO - 2023-09-28 08:23:31 --> Output Class Initialized
INFO - 2023-09-28 08:23:31 --> Security Class Initialized
DEBUG - 2023-09-28 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:23:31 --> Input Class Initialized
INFO - 2023-09-28 08:23:31 --> Language Class Initialized
INFO - 2023-09-28 08:23:31 --> Loader Class Initialized
INFO - 2023-09-28 08:23:31 --> Helper loaded: url_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: file_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: html_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: text_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: form_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: security_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:23:31 --> Database Driver Class Initialized
INFO - 2023-09-28 08:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:23:31 --> Parser Class Initialized
INFO - 2023-09-28 08:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:23:31 --> Pagination Class Initialized
INFO - 2023-09-28 08:23:31 --> Form Validation Class Initialized
INFO - 2023-09-28 08:23:31 --> Controller Class Initialized
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
INFO - 2023-09-28 08:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 08:23:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
INFO - 2023-09-28 08:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 08:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 08:23:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:23:31 --> Final output sent to browser
DEBUG - 2023-09-28 08:23:31 --> Total execution time: 0.1761
ERROR - 2023-09-28 08:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:23:31 --> Config Class Initialized
INFO - 2023-09-28 08:23:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:23:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:23:31 --> Utf8 Class Initialized
INFO - 2023-09-28 08:23:31 --> URI Class Initialized
INFO - 2023-09-28 08:23:31 --> Router Class Initialized
INFO - 2023-09-28 08:23:31 --> Output Class Initialized
INFO - 2023-09-28 08:23:31 --> Security Class Initialized
DEBUG - 2023-09-28 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:23:31 --> Input Class Initialized
INFO - 2023-09-28 08:23:31 --> Language Class Initialized
INFO - 2023-09-28 08:23:31 --> Loader Class Initialized
INFO - 2023-09-28 08:23:31 --> Helper loaded: url_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: file_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: html_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: text_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: form_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: security_helper
INFO - 2023-09-28 08:23:31 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:23:31 --> Database Driver Class Initialized
INFO - 2023-09-28 08:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:23:31 --> Parser Class Initialized
INFO - 2023-09-28 08:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:23:31 --> Pagination Class Initialized
INFO - 2023-09-28 08:23:31 --> Form Validation Class Initialized
INFO - 2023-09-28 08:23:31 --> Controller Class Initialized
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:31 --> Model Class Initialized
INFO - 2023-09-28 08:23:32 --> Final output sent to browser
DEBUG - 2023-09-28 08:23:32 --> Total execution time: 0.0563
ERROR - 2023-09-28 08:23:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:23:37 --> Config Class Initialized
INFO - 2023-09-28 08:23:37 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:23:37 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:23:37 --> Utf8 Class Initialized
INFO - 2023-09-28 08:23:37 --> URI Class Initialized
INFO - 2023-09-28 08:23:37 --> Router Class Initialized
INFO - 2023-09-28 08:23:37 --> Output Class Initialized
INFO - 2023-09-28 08:23:37 --> Security Class Initialized
DEBUG - 2023-09-28 08:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:23:37 --> Input Class Initialized
INFO - 2023-09-28 08:23:37 --> Language Class Initialized
INFO - 2023-09-28 08:23:37 --> Loader Class Initialized
INFO - 2023-09-28 08:23:37 --> Helper loaded: url_helper
INFO - 2023-09-28 08:23:37 --> Helper loaded: file_helper
INFO - 2023-09-28 08:23:37 --> Helper loaded: html_helper
INFO - 2023-09-28 08:23:37 --> Helper loaded: text_helper
INFO - 2023-09-28 08:23:37 --> Helper loaded: form_helper
INFO - 2023-09-28 08:23:37 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:23:37 --> Helper loaded: security_helper
INFO - 2023-09-28 08:23:37 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:23:37 --> Database Driver Class Initialized
INFO - 2023-09-28 08:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:23:37 --> Parser Class Initialized
INFO - 2023-09-28 08:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:23:37 --> Pagination Class Initialized
INFO - 2023-09-28 08:23:37 --> Form Validation Class Initialized
INFO - 2023-09-28 08:23:37 --> Controller Class Initialized
INFO - 2023-09-28 08:23:37 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:37 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:37 --> Model Class Initialized
INFO - 2023-09-28 08:23:38 --> Final output sent to browser
DEBUG - 2023-09-28 08:23:38 --> Total execution time: 0.1608
ERROR - 2023-09-28 08:23:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:23:48 --> Config Class Initialized
INFO - 2023-09-28 08:23:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:23:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:23:48 --> Utf8 Class Initialized
INFO - 2023-09-28 08:23:48 --> URI Class Initialized
INFO - 2023-09-28 08:23:48 --> Router Class Initialized
INFO - 2023-09-28 08:23:48 --> Output Class Initialized
INFO - 2023-09-28 08:23:48 --> Security Class Initialized
DEBUG - 2023-09-28 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:23:48 --> Input Class Initialized
INFO - 2023-09-28 08:23:48 --> Language Class Initialized
INFO - 2023-09-28 08:23:48 --> Loader Class Initialized
INFO - 2023-09-28 08:23:48 --> Helper loaded: url_helper
INFO - 2023-09-28 08:23:48 --> Helper loaded: file_helper
INFO - 2023-09-28 08:23:48 --> Helper loaded: html_helper
INFO - 2023-09-28 08:23:48 --> Helper loaded: text_helper
INFO - 2023-09-28 08:23:48 --> Helper loaded: form_helper
INFO - 2023-09-28 08:23:48 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:23:48 --> Helper loaded: security_helper
INFO - 2023-09-28 08:23:48 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:23:48 --> Database Driver Class Initialized
INFO - 2023-09-28 08:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:23:48 --> Parser Class Initialized
INFO - 2023-09-28 08:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:23:48 --> Pagination Class Initialized
INFO - 2023-09-28 08:23:48 --> Form Validation Class Initialized
INFO - 2023-09-28 08:23:48 --> Controller Class Initialized
INFO - 2023-09-28 08:23:48 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:48 --> Model Class Initialized
DEBUG - 2023-09-28 08:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:23:48 --> Model Class Initialized
INFO - 2023-09-28 08:23:48 --> Final output sent to browser
DEBUG - 2023-09-28 08:23:48 --> Total execution time: 0.1698
ERROR - 2023-09-28 08:24:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:24:38 --> Config Class Initialized
INFO - 2023-09-28 08:24:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:24:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:24:38 --> Utf8 Class Initialized
INFO - 2023-09-28 08:24:38 --> URI Class Initialized
DEBUG - 2023-09-28 08:24:38 --> No URI present. Default controller set.
INFO - 2023-09-28 08:24:38 --> Router Class Initialized
INFO - 2023-09-28 08:24:38 --> Output Class Initialized
INFO - 2023-09-28 08:24:38 --> Security Class Initialized
DEBUG - 2023-09-28 08:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:24:38 --> Input Class Initialized
INFO - 2023-09-28 08:24:38 --> Language Class Initialized
INFO - 2023-09-28 08:24:38 --> Loader Class Initialized
INFO - 2023-09-28 08:24:38 --> Helper loaded: url_helper
INFO - 2023-09-28 08:24:38 --> Helper loaded: file_helper
INFO - 2023-09-28 08:24:38 --> Helper loaded: html_helper
INFO - 2023-09-28 08:24:38 --> Helper loaded: text_helper
INFO - 2023-09-28 08:24:38 --> Helper loaded: form_helper
INFO - 2023-09-28 08:24:38 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:24:38 --> Helper loaded: security_helper
INFO - 2023-09-28 08:24:38 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:24:38 --> Database Driver Class Initialized
INFO - 2023-09-28 08:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:24:38 --> Parser Class Initialized
INFO - 2023-09-28 08:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:24:38 --> Pagination Class Initialized
INFO - 2023-09-28 08:24:38 --> Form Validation Class Initialized
INFO - 2023-09-28 08:24:38 --> Controller Class Initialized
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
DEBUG - 2023-09-28 08:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
DEBUG - 2023-09-28 08:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
DEBUG - 2023-09-28 08:24:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
INFO - 2023-09-28 08:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 08:24:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:24:38 --> Model Class Initialized
INFO - 2023-09-28 08:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 08:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 08:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:24:38 --> Final output sent to browser
DEBUG - 2023-09-28 08:24:38 --> Total execution time: 0.2066
ERROR - 2023-09-28 08:24:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 08:24:42 --> Config Class Initialized
INFO - 2023-09-28 08:24:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 08:24:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 08:24:42 --> Utf8 Class Initialized
INFO - 2023-09-28 08:24:42 --> URI Class Initialized
DEBUG - 2023-09-28 08:24:42 --> No URI present. Default controller set.
INFO - 2023-09-28 08:24:42 --> Router Class Initialized
INFO - 2023-09-28 08:24:42 --> Output Class Initialized
INFO - 2023-09-28 08:24:42 --> Security Class Initialized
DEBUG - 2023-09-28 08:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 08:24:42 --> Input Class Initialized
INFO - 2023-09-28 08:24:42 --> Language Class Initialized
INFO - 2023-09-28 08:24:42 --> Loader Class Initialized
INFO - 2023-09-28 08:24:42 --> Helper loaded: url_helper
INFO - 2023-09-28 08:24:42 --> Helper loaded: file_helper
INFO - 2023-09-28 08:24:42 --> Helper loaded: html_helper
INFO - 2023-09-28 08:24:42 --> Helper loaded: text_helper
INFO - 2023-09-28 08:24:42 --> Helper loaded: form_helper
INFO - 2023-09-28 08:24:42 --> Helper loaded: lang_helper
INFO - 2023-09-28 08:24:42 --> Helper loaded: security_helper
INFO - 2023-09-28 08:24:42 --> Helper loaded: cookie_helper
INFO - 2023-09-28 08:24:42 --> Database Driver Class Initialized
INFO - 2023-09-28 08:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 08:24:42 --> Parser Class Initialized
INFO - 2023-09-28 08:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 08:24:42 --> Pagination Class Initialized
INFO - 2023-09-28 08:24:42 --> Form Validation Class Initialized
INFO - 2023-09-28 08:24:42 --> Controller Class Initialized
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
DEBUG - 2023-09-28 08:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
DEBUG - 2023-09-28 08:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
DEBUG - 2023-09-28 08:24:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 08:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
INFO - 2023-09-28 08:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 08:24:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 08:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 08:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 08:24:42 --> Model Class Initialized
INFO - 2023-09-28 08:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 08:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 08:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 08:24:42 --> Final output sent to browser
DEBUG - 2023-09-28 08:24:42 --> Total execution time: 0.2021
ERROR - 2023-09-28 16:43:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:14 --> Config Class Initialized
INFO - 2023-09-28 16:43:14 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:14 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:14 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:14 --> URI Class Initialized
DEBUG - 2023-09-28 16:43:14 --> No URI present. Default controller set.
INFO - 2023-09-28 16:43:14 --> Router Class Initialized
INFO - 2023-09-28 16:43:14 --> Output Class Initialized
INFO - 2023-09-28 16:43:14 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:14 --> Input Class Initialized
INFO - 2023-09-28 16:43:14 --> Language Class Initialized
INFO - 2023-09-28 16:43:14 --> Loader Class Initialized
INFO - 2023-09-28 16:43:14 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:14 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:14 --> Parser Class Initialized
INFO - 2023-09-28 16:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:14 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:14 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:14 --> Controller Class Initialized
INFO - 2023-09-28 16:43:14 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 16:43:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:14 --> Config Class Initialized
INFO - 2023-09-28 16:43:14 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:14 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:14 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:14 --> URI Class Initialized
DEBUG - 2023-09-28 16:43:14 --> No URI present. Default controller set.
INFO - 2023-09-28 16:43:14 --> Router Class Initialized
INFO - 2023-09-28 16:43:14 --> Output Class Initialized
INFO - 2023-09-28 16:43:14 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:14 --> Input Class Initialized
INFO - 2023-09-28 16:43:14 --> Language Class Initialized
INFO - 2023-09-28 16:43:14 --> Loader Class Initialized
INFO - 2023-09-28 16:43:14 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:14 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:14 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:14 --> Parser Class Initialized
INFO - 2023-09-28 16:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:14 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:14 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:14 --> Controller Class Initialized
INFO - 2023-09-28 16:43:14 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 16:43:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:15 --> Config Class Initialized
INFO - 2023-09-28 16:43:15 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:15 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:15 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:15 --> URI Class Initialized
INFO - 2023-09-28 16:43:15 --> Router Class Initialized
INFO - 2023-09-28 16:43:15 --> Output Class Initialized
INFO - 2023-09-28 16:43:15 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:15 --> Input Class Initialized
INFO - 2023-09-28 16:43:15 --> Language Class Initialized
INFO - 2023-09-28 16:43:15 --> Loader Class Initialized
INFO - 2023-09-28 16:43:15 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:15 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:15 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:15 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:15 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:15 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:15 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:15 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:15 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:15 --> Parser Class Initialized
INFO - 2023-09-28 16:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:15 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:15 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:15 --> Controller Class Initialized
INFO - 2023-09-28 16:43:15 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-28 16:43:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:43:15 --> Model Class Initialized
INFO - 2023-09-28 16:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:43:15 --> Final output sent to browser
DEBUG - 2023-09-28 16:43:15 --> Total execution time: 0.0343
ERROR - 2023-09-28 16:43:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:22 --> Config Class Initialized
INFO - 2023-09-28 16:43:22 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:22 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:22 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:22 --> URI Class Initialized
INFO - 2023-09-28 16:43:22 --> Router Class Initialized
INFO - 2023-09-28 16:43:22 --> Output Class Initialized
INFO - 2023-09-28 16:43:22 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:22 --> Input Class Initialized
INFO - 2023-09-28 16:43:22 --> Language Class Initialized
INFO - 2023-09-28 16:43:22 --> Loader Class Initialized
INFO - 2023-09-28 16:43:22 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:22 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:22 --> Parser Class Initialized
INFO - 2023-09-28 16:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:22 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:22 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:22 --> Controller Class Initialized
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
INFO - 2023-09-28 16:43:22 --> Final output sent to browser
DEBUG - 2023-09-28 16:43:22 --> Total execution time: 0.0185
ERROR - 2023-09-28 16:43:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:22 --> Config Class Initialized
INFO - 2023-09-28 16:43:22 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:22 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:22 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:22 --> URI Class Initialized
DEBUG - 2023-09-28 16:43:22 --> No URI present. Default controller set.
INFO - 2023-09-28 16:43:22 --> Router Class Initialized
INFO - 2023-09-28 16:43:22 --> Output Class Initialized
INFO - 2023-09-28 16:43:22 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:22 --> Input Class Initialized
INFO - 2023-09-28 16:43:22 --> Language Class Initialized
INFO - 2023-09-28 16:43:22 --> Loader Class Initialized
INFO - 2023-09-28 16:43:22 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:22 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:22 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:22 --> Parser Class Initialized
INFO - 2023-09-28 16:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:22 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:22 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:22 --> Controller Class Initialized
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
INFO - 2023-09-28 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 16:43:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:43:22 --> Model Class Initialized
INFO - 2023-09-28 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:43:22 --> Final output sent to browser
DEBUG - 2023-09-28 16:43:22 --> Total execution time: 0.1070
ERROR - 2023-09-28 16:43:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:38 --> Config Class Initialized
INFO - 2023-09-28 16:43:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:38 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:38 --> URI Class Initialized
DEBUG - 2023-09-28 16:43:38 --> No URI present. Default controller set.
INFO - 2023-09-28 16:43:38 --> Router Class Initialized
INFO - 2023-09-28 16:43:38 --> Output Class Initialized
INFO - 2023-09-28 16:43:38 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:38 --> Input Class Initialized
INFO - 2023-09-28 16:43:38 --> Language Class Initialized
INFO - 2023-09-28 16:43:38 --> Loader Class Initialized
INFO - 2023-09-28 16:43:38 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:38 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:38 --> Parser Class Initialized
INFO - 2023-09-28 16:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:38 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:38 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:38 --> Controller Class Initialized
INFO - 2023-09-28 16:43:38 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 16:43:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:38 --> Config Class Initialized
INFO - 2023-09-28 16:43:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:38 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:38 --> URI Class Initialized
INFO - 2023-09-28 16:43:38 --> Router Class Initialized
INFO - 2023-09-28 16:43:38 --> Output Class Initialized
INFO - 2023-09-28 16:43:38 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:38 --> Input Class Initialized
INFO - 2023-09-28 16:43:38 --> Language Class Initialized
INFO - 2023-09-28 16:43:38 --> Loader Class Initialized
INFO - 2023-09-28 16:43:38 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:38 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:38 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:38 --> Parser Class Initialized
INFO - 2023-09-28 16:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:38 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:38 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:38 --> Controller Class Initialized
INFO - 2023-09-28 16:43:38 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-28 16:43:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:43:38 --> Model Class Initialized
INFO - 2023-09-28 16:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:43:38 --> Final output sent to browser
DEBUG - 2023-09-28 16:43:38 --> Total execution time: 0.0304
ERROR - 2023-09-28 16:43:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:42 --> Config Class Initialized
INFO - 2023-09-28 16:43:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:42 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:42 --> URI Class Initialized
INFO - 2023-09-28 16:43:42 --> Router Class Initialized
INFO - 2023-09-28 16:43:42 --> Output Class Initialized
INFO - 2023-09-28 16:43:42 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:42 --> Input Class Initialized
INFO - 2023-09-28 16:43:42 --> Language Class Initialized
INFO - 2023-09-28 16:43:42 --> Loader Class Initialized
INFO - 2023-09-28 16:43:42 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:42 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:42 --> Parser Class Initialized
INFO - 2023-09-28 16:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:42 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:42 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:42 --> Controller Class Initialized
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
INFO - 2023-09-28 16:43:42 --> Final output sent to browser
DEBUG - 2023-09-28 16:43:42 --> Total execution time: 0.0156
ERROR - 2023-09-28 16:43:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:42 --> Config Class Initialized
INFO - 2023-09-28 16:43:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:42 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:42 --> URI Class Initialized
DEBUG - 2023-09-28 16:43:42 --> No URI present. Default controller set.
INFO - 2023-09-28 16:43:42 --> Router Class Initialized
INFO - 2023-09-28 16:43:42 --> Output Class Initialized
INFO - 2023-09-28 16:43:42 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:42 --> Input Class Initialized
INFO - 2023-09-28 16:43:42 --> Language Class Initialized
INFO - 2023-09-28 16:43:42 --> Loader Class Initialized
INFO - 2023-09-28 16:43:42 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:42 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:42 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:42 --> Parser Class Initialized
INFO - 2023-09-28 16:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:42 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:42 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:42 --> Controller Class Initialized
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
DEBUG - 2023-09-28 16:43:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
INFO - 2023-09-28 16:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 16:43:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:43:42 --> Model Class Initialized
INFO - 2023-09-28 16:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:43:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:43:42 --> Final output sent to browser
DEBUG - 2023-09-28 16:43:42 --> Total execution time: 0.2239
ERROR - 2023-09-28 16:43:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:43:43 --> Config Class Initialized
INFO - 2023-09-28 16:43:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:43:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:43:43 --> Utf8 Class Initialized
INFO - 2023-09-28 16:43:43 --> URI Class Initialized
INFO - 2023-09-28 16:43:43 --> Router Class Initialized
INFO - 2023-09-28 16:43:43 --> Output Class Initialized
INFO - 2023-09-28 16:43:43 --> Security Class Initialized
DEBUG - 2023-09-28 16:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:43:43 --> Input Class Initialized
INFO - 2023-09-28 16:43:43 --> Language Class Initialized
INFO - 2023-09-28 16:43:43 --> Loader Class Initialized
INFO - 2023-09-28 16:43:43 --> Helper loaded: url_helper
INFO - 2023-09-28 16:43:43 --> Helper loaded: file_helper
INFO - 2023-09-28 16:43:43 --> Helper loaded: html_helper
INFO - 2023-09-28 16:43:43 --> Helper loaded: text_helper
INFO - 2023-09-28 16:43:43 --> Helper loaded: form_helper
INFO - 2023-09-28 16:43:43 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:43:43 --> Helper loaded: security_helper
INFO - 2023-09-28 16:43:43 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:43:43 --> Database Driver Class Initialized
INFO - 2023-09-28 16:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:43:43 --> Parser Class Initialized
INFO - 2023-09-28 16:43:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:43:43 --> Pagination Class Initialized
INFO - 2023-09-28 16:43:43 --> Form Validation Class Initialized
INFO - 2023-09-28 16:43:43 --> Controller Class Initialized
DEBUG - 2023-09-28 16:43:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:43:43 --> Model Class Initialized
INFO - 2023-09-28 16:43:43 --> Final output sent to browser
DEBUG - 2023-09-28 16:43:43 --> Total execution time: 0.0142
ERROR - 2023-09-28 16:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:55:20 --> Config Class Initialized
INFO - 2023-09-28 16:55:20 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:55:20 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:55:20 --> Utf8 Class Initialized
INFO - 2023-09-28 16:55:20 --> URI Class Initialized
INFO - 2023-09-28 16:55:20 --> Router Class Initialized
INFO - 2023-09-28 16:55:20 --> Output Class Initialized
INFO - 2023-09-28 16:55:20 --> Security Class Initialized
DEBUG - 2023-09-28 16:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:55:20 --> Input Class Initialized
INFO - 2023-09-28 16:55:20 --> Language Class Initialized
INFO - 2023-09-28 16:55:20 --> Loader Class Initialized
INFO - 2023-09-28 16:55:20 --> Helper loaded: url_helper
INFO - 2023-09-28 16:55:20 --> Helper loaded: file_helper
INFO - 2023-09-28 16:55:20 --> Helper loaded: html_helper
INFO - 2023-09-28 16:55:20 --> Helper loaded: text_helper
INFO - 2023-09-28 16:55:20 --> Helper loaded: form_helper
INFO - 2023-09-28 16:55:20 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:55:20 --> Helper loaded: security_helper
INFO - 2023-09-28 16:55:20 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:55:20 --> Database Driver Class Initialized
INFO - 2023-09-28 16:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:55:20 --> Parser Class Initialized
INFO - 2023-09-28 16:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:55:20 --> Pagination Class Initialized
INFO - 2023-09-28 16:55:20 --> Form Validation Class Initialized
INFO - 2023-09-28 16:55:20 --> Controller Class Initialized
INFO - 2023-09-28 16:55:20 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:20 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:20 --> Model Class Initialized
INFO - 2023-09-28 16:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 16:55:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:55:20 --> Model Class Initialized
INFO - 2023-09-28 16:55:20 --> Model Class Initialized
INFO - 2023-09-28 16:55:20 --> Model Class Initialized
INFO - 2023-09-28 16:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:55:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:55:20 --> Final output sent to browser
DEBUG - 2023-09-28 16:55:20 --> Total execution time: 0.0938
ERROR - 2023-09-28 16:55:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:55:21 --> Config Class Initialized
INFO - 2023-09-28 16:55:21 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:55:21 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:55:21 --> Utf8 Class Initialized
INFO - 2023-09-28 16:55:21 --> URI Class Initialized
INFO - 2023-09-28 16:55:21 --> Router Class Initialized
INFO - 2023-09-28 16:55:21 --> Output Class Initialized
INFO - 2023-09-28 16:55:21 --> Security Class Initialized
DEBUG - 2023-09-28 16:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:55:21 --> Input Class Initialized
INFO - 2023-09-28 16:55:21 --> Language Class Initialized
INFO - 2023-09-28 16:55:21 --> Loader Class Initialized
INFO - 2023-09-28 16:55:21 --> Helper loaded: url_helper
INFO - 2023-09-28 16:55:21 --> Helper loaded: file_helper
INFO - 2023-09-28 16:55:21 --> Helper loaded: html_helper
INFO - 2023-09-28 16:55:21 --> Helper loaded: text_helper
INFO - 2023-09-28 16:55:21 --> Helper loaded: form_helper
INFO - 2023-09-28 16:55:21 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:55:21 --> Helper loaded: security_helper
INFO - 2023-09-28 16:55:21 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:55:21 --> Database Driver Class Initialized
INFO - 2023-09-28 16:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:55:21 --> Parser Class Initialized
INFO - 2023-09-28 16:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:55:21 --> Pagination Class Initialized
INFO - 2023-09-28 16:55:21 --> Form Validation Class Initialized
INFO - 2023-09-28 16:55:21 --> Controller Class Initialized
INFO - 2023-09-28 16:55:21 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:21 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:21 --> Model Class Initialized
INFO - 2023-09-28 16:55:21 --> Final output sent to browser
DEBUG - 2023-09-28 16:55:21 --> Total execution time: 0.0411
ERROR - 2023-09-28 16:55:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:55:25 --> Config Class Initialized
INFO - 2023-09-28 16:55:25 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:55:25 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:55:25 --> Utf8 Class Initialized
INFO - 2023-09-28 16:55:25 --> URI Class Initialized
INFO - 2023-09-28 16:55:25 --> Router Class Initialized
INFO - 2023-09-28 16:55:25 --> Output Class Initialized
INFO - 2023-09-28 16:55:25 --> Security Class Initialized
DEBUG - 2023-09-28 16:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:55:25 --> Input Class Initialized
INFO - 2023-09-28 16:55:25 --> Language Class Initialized
INFO - 2023-09-28 16:55:25 --> Loader Class Initialized
INFO - 2023-09-28 16:55:25 --> Helper loaded: url_helper
INFO - 2023-09-28 16:55:25 --> Helper loaded: file_helper
INFO - 2023-09-28 16:55:25 --> Helper loaded: html_helper
INFO - 2023-09-28 16:55:25 --> Helper loaded: text_helper
INFO - 2023-09-28 16:55:25 --> Helper loaded: form_helper
INFO - 2023-09-28 16:55:25 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:55:25 --> Helper loaded: security_helper
INFO - 2023-09-28 16:55:25 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:55:25 --> Database Driver Class Initialized
INFO - 2023-09-28 16:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:55:25 --> Parser Class Initialized
INFO - 2023-09-28 16:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:55:25 --> Pagination Class Initialized
INFO - 2023-09-28 16:55:25 --> Form Validation Class Initialized
INFO - 2023-09-28 16:55:25 --> Controller Class Initialized
INFO - 2023-09-28 16:55:25 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:25 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:25 --> Model Class Initialized
INFO - 2023-09-28 16:55:26 --> Final output sent to browser
DEBUG - 2023-09-28 16:55:26 --> Total execution time: 0.3405
ERROR - 2023-09-28 16:55:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:55:31 --> Config Class Initialized
INFO - 2023-09-28 16:55:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:55:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:55:31 --> Utf8 Class Initialized
INFO - 2023-09-28 16:55:31 --> URI Class Initialized
DEBUG - 2023-09-28 16:55:31 --> No URI present. Default controller set.
INFO - 2023-09-28 16:55:31 --> Router Class Initialized
INFO - 2023-09-28 16:55:31 --> Output Class Initialized
INFO - 2023-09-28 16:55:31 --> Security Class Initialized
DEBUG - 2023-09-28 16:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:55:31 --> Input Class Initialized
INFO - 2023-09-28 16:55:31 --> Language Class Initialized
INFO - 2023-09-28 16:55:31 --> Loader Class Initialized
INFO - 2023-09-28 16:55:31 --> Helper loaded: url_helper
INFO - 2023-09-28 16:55:31 --> Helper loaded: file_helper
INFO - 2023-09-28 16:55:31 --> Helper loaded: html_helper
INFO - 2023-09-28 16:55:31 --> Helper loaded: text_helper
INFO - 2023-09-28 16:55:31 --> Helper loaded: form_helper
INFO - 2023-09-28 16:55:31 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:55:31 --> Helper loaded: security_helper
INFO - 2023-09-28 16:55:31 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:55:31 --> Database Driver Class Initialized
INFO - 2023-09-28 16:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:55:31 --> Parser Class Initialized
INFO - 2023-09-28 16:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:55:31 --> Pagination Class Initialized
INFO - 2023-09-28 16:55:31 --> Form Validation Class Initialized
INFO - 2023-09-28 16:55:31 --> Controller Class Initialized
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
INFO - 2023-09-28 16:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 16:55:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:55:31 --> Model Class Initialized
INFO - 2023-09-28 16:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:55:31 --> Final output sent to browser
DEBUG - 2023-09-28 16:55:31 --> Total execution time: 0.0989
ERROR - 2023-09-28 16:55:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:55:40 --> Config Class Initialized
INFO - 2023-09-28 16:55:40 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:55:40 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:55:40 --> Utf8 Class Initialized
INFO - 2023-09-28 16:55:40 --> URI Class Initialized
DEBUG - 2023-09-28 16:55:40 --> No URI present. Default controller set.
INFO - 2023-09-28 16:55:40 --> Router Class Initialized
INFO - 2023-09-28 16:55:40 --> Output Class Initialized
INFO - 2023-09-28 16:55:40 --> Security Class Initialized
DEBUG - 2023-09-28 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:55:40 --> Input Class Initialized
INFO - 2023-09-28 16:55:40 --> Language Class Initialized
INFO - 2023-09-28 16:55:40 --> Loader Class Initialized
INFO - 2023-09-28 16:55:40 --> Helper loaded: url_helper
INFO - 2023-09-28 16:55:40 --> Helper loaded: file_helper
INFO - 2023-09-28 16:55:40 --> Helper loaded: html_helper
INFO - 2023-09-28 16:55:40 --> Helper loaded: text_helper
INFO - 2023-09-28 16:55:40 --> Helper loaded: form_helper
INFO - 2023-09-28 16:55:40 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:55:40 --> Helper loaded: security_helper
INFO - 2023-09-28 16:55:40 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:55:40 --> Database Driver Class Initialized
INFO - 2023-09-28 16:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:55:40 --> Parser Class Initialized
INFO - 2023-09-28 16:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:55:40 --> Pagination Class Initialized
INFO - 2023-09-28 16:55:40 --> Form Validation Class Initialized
INFO - 2023-09-28 16:55:40 --> Controller Class Initialized
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
DEBUG - 2023-09-28 16:55:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
INFO - 2023-09-28 16:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 16:55:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:55:40 --> Model Class Initialized
INFO - 2023-09-28 16:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:55:40 --> Final output sent to browser
DEBUG - 2023-09-28 16:55:40 --> Total execution time: 0.1173
ERROR - 2023-09-28 16:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:56:30 --> Config Class Initialized
INFO - 2023-09-28 16:56:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:56:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:56:30 --> Utf8 Class Initialized
INFO - 2023-09-28 16:56:30 --> URI Class Initialized
INFO - 2023-09-28 16:56:30 --> Router Class Initialized
INFO - 2023-09-28 16:56:30 --> Output Class Initialized
INFO - 2023-09-28 16:56:30 --> Security Class Initialized
DEBUG - 2023-09-28 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:56:30 --> Input Class Initialized
INFO - 2023-09-28 16:56:30 --> Language Class Initialized
INFO - 2023-09-28 16:56:30 --> Loader Class Initialized
INFO - 2023-09-28 16:56:30 --> Helper loaded: url_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: file_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: html_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: text_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: form_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: security_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:56:30 --> Database Driver Class Initialized
INFO - 2023-09-28 16:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:56:30 --> Parser Class Initialized
INFO - 2023-09-28 16:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:56:30 --> Pagination Class Initialized
INFO - 2023-09-28 16:56:30 --> Form Validation Class Initialized
INFO - 2023-09-28 16:56:30 --> Controller Class Initialized
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
DEBUG - 2023-09-28 16:56:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
DEBUG - 2023-09-28 16:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
INFO - 2023-09-28 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 16:56:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
INFO - 2023-09-28 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:56:30 --> Final output sent to browser
DEBUG - 2023-09-28 16:56:30 --> Total execution time: 0.0864
ERROR - 2023-09-28 16:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:56:30 --> Config Class Initialized
INFO - 2023-09-28 16:56:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:56:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:56:30 --> Utf8 Class Initialized
INFO - 2023-09-28 16:56:30 --> URI Class Initialized
INFO - 2023-09-28 16:56:30 --> Router Class Initialized
INFO - 2023-09-28 16:56:30 --> Output Class Initialized
INFO - 2023-09-28 16:56:30 --> Security Class Initialized
DEBUG - 2023-09-28 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:56:30 --> Input Class Initialized
INFO - 2023-09-28 16:56:30 --> Language Class Initialized
INFO - 2023-09-28 16:56:30 --> Loader Class Initialized
INFO - 2023-09-28 16:56:30 --> Helper loaded: url_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: file_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: html_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: text_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: form_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: security_helper
INFO - 2023-09-28 16:56:30 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:56:30 --> Database Driver Class Initialized
INFO - 2023-09-28 16:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:56:30 --> Parser Class Initialized
INFO - 2023-09-28 16:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:56:30 --> Pagination Class Initialized
INFO - 2023-09-28 16:56:30 --> Form Validation Class Initialized
INFO - 2023-09-28 16:56:30 --> Controller Class Initialized
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
DEBUG - 2023-09-28 16:56:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
DEBUG - 2023-09-28 16:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:56:30 --> Model Class Initialized
INFO - 2023-09-28 16:56:30 --> Final output sent to browser
DEBUG - 2023-09-28 16:56:30 --> Total execution time: 0.0396
ERROR - 2023-09-28 16:56:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:56:33 --> Config Class Initialized
INFO - 2023-09-28 16:56:33 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:56:33 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:56:33 --> Utf8 Class Initialized
INFO - 2023-09-28 16:56:33 --> URI Class Initialized
INFO - 2023-09-28 16:56:33 --> Router Class Initialized
INFO - 2023-09-28 16:56:33 --> Output Class Initialized
INFO - 2023-09-28 16:56:33 --> Security Class Initialized
DEBUG - 2023-09-28 16:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:56:33 --> Input Class Initialized
INFO - 2023-09-28 16:56:33 --> Language Class Initialized
INFO - 2023-09-28 16:56:33 --> Loader Class Initialized
INFO - 2023-09-28 16:56:33 --> Helper loaded: url_helper
INFO - 2023-09-28 16:56:33 --> Helper loaded: file_helper
INFO - 2023-09-28 16:56:33 --> Helper loaded: html_helper
INFO - 2023-09-28 16:56:33 --> Helper loaded: text_helper
INFO - 2023-09-28 16:56:33 --> Helper loaded: form_helper
INFO - 2023-09-28 16:56:33 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:56:33 --> Helper loaded: security_helper
INFO - 2023-09-28 16:56:33 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:56:33 --> Database Driver Class Initialized
INFO - 2023-09-28 16:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:56:33 --> Parser Class Initialized
INFO - 2023-09-28 16:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:56:33 --> Pagination Class Initialized
INFO - 2023-09-28 16:56:33 --> Form Validation Class Initialized
INFO - 2023-09-28 16:56:33 --> Controller Class Initialized
INFO - 2023-09-28 16:56:33 --> Model Class Initialized
DEBUG - 2023-09-28 16:56:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:56:33 --> Model Class Initialized
DEBUG - 2023-09-28 16:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:56:33 --> Model Class Initialized
INFO - 2023-09-28 16:56:34 --> Final output sent to browser
DEBUG - 2023-09-28 16:56:34 --> Total execution time: 0.3004
ERROR - 2023-09-28 16:57:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:57:59 --> Config Class Initialized
INFO - 2023-09-28 16:57:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:57:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:57:59 --> Utf8 Class Initialized
INFO - 2023-09-28 16:57:59 --> URI Class Initialized
INFO - 2023-09-28 16:57:59 --> Router Class Initialized
INFO - 2023-09-28 16:57:59 --> Output Class Initialized
INFO - 2023-09-28 16:57:59 --> Security Class Initialized
DEBUG - 2023-09-28 16:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:57:59 --> Input Class Initialized
INFO - 2023-09-28 16:57:59 --> Language Class Initialized
INFO - 2023-09-28 16:57:59 --> Loader Class Initialized
INFO - 2023-09-28 16:57:59 --> Helper loaded: url_helper
INFO - 2023-09-28 16:57:59 --> Helper loaded: file_helper
INFO - 2023-09-28 16:57:59 --> Helper loaded: html_helper
INFO - 2023-09-28 16:57:59 --> Helper loaded: text_helper
INFO - 2023-09-28 16:57:59 --> Helper loaded: form_helper
INFO - 2023-09-28 16:57:59 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:57:59 --> Helper loaded: security_helper
INFO - 2023-09-28 16:57:59 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:57:59 --> Database Driver Class Initialized
INFO - 2023-09-28 16:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:57:59 --> Parser Class Initialized
INFO - 2023-09-28 16:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:57:59 --> Pagination Class Initialized
INFO - 2023-09-28 16:57:59 --> Form Validation Class Initialized
INFO - 2023-09-28 16:57:59 --> Controller Class Initialized
INFO - 2023-09-28 16:57:59 --> Model Class Initialized
DEBUG - 2023-09-28 16:57:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:57:59 --> Model Class Initialized
DEBUG - 2023-09-28 16:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:57:59 --> Model Class Initialized
INFO - 2023-09-28 16:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 16:57:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:57:59 --> Model Class Initialized
INFO - 2023-09-28 16:57:59 --> Model Class Initialized
INFO - 2023-09-28 16:57:59 --> Model Class Initialized
INFO - 2023-09-28 16:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:57:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:57:59 --> Final output sent to browser
DEBUG - 2023-09-28 16:57:59 --> Total execution time: 0.0901
ERROR - 2023-09-28 16:58:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:58:00 --> Config Class Initialized
INFO - 2023-09-28 16:58:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:58:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:58:00 --> Utf8 Class Initialized
INFO - 2023-09-28 16:58:00 --> URI Class Initialized
INFO - 2023-09-28 16:58:00 --> Router Class Initialized
INFO - 2023-09-28 16:58:00 --> Output Class Initialized
INFO - 2023-09-28 16:58:00 --> Security Class Initialized
DEBUG - 2023-09-28 16:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:58:00 --> Input Class Initialized
INFO - 2023-09-28 16:58:00 --> Language Class Initialized
INFO - 2023-09-28 16:58:00 --> Loader Class Initialized
INFO - 2023-09-28 16:58:00 --> Helper loaded: url_helper
INFO - 2023-09-28 16:58:00 --> Helper loaded: file_helper
INFO - 2023-09-28 16:58:00 --> Helper loaded: html_helper
INFO - 2023-09-28 16:58:00 --> Helper loaded: text_helper
INFO - 2023-09-28 16:58:00 --> Helper loaded: form_helper
INFO - 2023-09-28 16:58:00 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:58:00 --> Helper loaded: security_helper
INFO - 2023-09-28 16:58:00 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:58:00 --> Database Driver Class Initialized
INFO - 2023-09-28 16:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:58:00 --> Parser Class Initialized
INFO - 2023-09-28 16:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:58:00 --> Pagination Class Initialized
INFO - 2023-09-28 16:58:00 --> Form Validation Class Initialized
INFO - 2023-09-28 16:58:00 --> Controller Class Initialized
INFO - 2023-09-28 16:58:00 --> Model Class Initialized
DEBUG - 2023-09-28 16:58:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:00 --> Model Class Initialized
DEBUG - 2023-09-28 16:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:00 --> Model Class Initialized
INFO - 2023-09-28 16:58:00 --> Final output sent to browser
DEBUG - 2023-09-28 16:58:00 --> Total execution time: 0.0424
ERROR - 2023-09-28 16:58:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:58:03 --> Config Class Initialized
INFO - 2023-09-28 16:58:03 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:58:03 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:58:03 --> Utf8 Class Initialized
INFO - 2023-09-28 16:58:03 --> URI Class Initialized
INFO - 2023-09-28 16:58:03 --> Router Class Initialized
INFO - 2023-09-28 16:58:03 --> Output Class Initialized
INFO - 2023-09-28 16:58:03 --> Security Class Initialized
DEBUG - 2023-09-28 16:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:58:03 --> Input Class Initialized
INFO - 2023-09-28 16:58:03 --> Language Class Initialized
INFO - 2023-09-28 16:58:03 --> Loader Class Initialized
INFO - 2023-09-28 16:58:03 --> Helper loaded: url_helper
INFO - 2023-09-28 16:58:03 --> Helper loaded: file_helper
INFO - 2023-09-28 16:58:03 --> Helper loaded: html_helper
INFO - 2023-09-28 16:58:03 --> Helper loaded: text_helper
INFO - 2023-09-28 16:58:03 --> Helper loaded: form_helper
INFO - 2023-09-28 16:58:03 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:58:03 --> Helper loaded: security_helper
INFO - 2023-09-28 16:58:03 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:58:03 --> Database Driver Class Initialized
INFO - 2023-09-28 16:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:58:03 --> Parser Class Initialized
INFO - 2023-09-28 16:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:58:03 --> Pagination Class Initialized
INFO - 2023-09-28 16:58:03 --> Form Validation Class Initialized
INFO - 2023-09-28 16:58:03 --> Controller Class Initialized
INFO - 2023-09-28 16:58:03 --> Model Class Initialized
DEBUG - 2023-09-28 16:58:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:58:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:03 --> Model Class Initialized
DEBUG - 2023-09-28 16:58:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:03 --> Model Class Initialized
INFO - 2023-09-28 16:58:04 --> Final output sent to browser
DEBUG - 2023-09-28 16:58:04 --> Total execution time: 0.3110
ERROR - 2023-09-28 16:58:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 16:58:23 --> Config Class Initialized
INFO - 2023-09-28 16:58:23 --> Hooks Class Initialized
DEBUG - 2023-09-28 16:58:23 --> UTF-8 Support Enabled
INFO - 2023-09-28 16:58:23 --> Utf8 Class Initialized
INFO - 2023-09-28 16:58:23 --> URI Class Initialized
DEBUG - 2023-09-28 16:58:23 --> No URI present. Default controller set.
INFO - 2023-09-28 16:58:23 --> Router Class Initialized
INFO - 2023-09-28 16:58:23 --> Output Class Initialized
INFO - 2023-09-28 16:58:23 --> Security Class Initialized
DEBUG - 2023-09-28 16:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 16:58:23 --> Input Class Initialized
INFO - 2023-09-28 16:58:23 --> Language Class Initialized
INFO - 2023-09-28 16:58:23 --> Loader Class Initialized
INFO - 2023-09-28 16:58:23 --> Helper loaded: url_helper
INFO - 2023-09-28 16:58:23 --> Helper loaded: file_helper
INFO - 2023-09-28 16:58:23 --> Helper loaded: html_helper
INFO - 2023-09-28 16:58:23 --> Helper loaded: text_helper
INFO - 2023-09-28 16:58:23 --> Helper loaded: form_helper
INFO - 2023-09-28 16:58:23 --> Helper loaded: lang_helper
INFO - 2023-09-28 16:58:23 --> Helper loaded: security_helper
INFO - 2023-09-28 16:58:23 --> Helper loaded: cookie_helper
INFO - 2023-09-28 16:58:23 --> Database Driver Class Initialized
INFO - 2023-09-28 16:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 16:58:23 --> Parser Class Initialized
INFO - 2023-09-28 16:58:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 16:58:23 --> Pagination Class Initialized
INFO - 2023-09-28 16:58:23 --> Form Validation Class Initialized
INFO - 2023-09-28 16:58:23 --> Controller Class Initialized
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
DEBUG - 2023-09-28 16:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
DEBUG - 2023-09-28 16:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
DEBUG - 2023-09-28 16:58:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 16:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
INFO - 2023-09-28 16:58:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 16:58:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 16:58:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 16:58:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 16:58:23 --> Model Class Initialized
INFO - 2023-09-28 16:58:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 16:58:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 16:58:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 16:58:23 --> Final output sent to browser
DEBUG - 2023-09-28 16:58:23 --> Total execution time: 0.1009
ERROR - 2023-09-28 17:01:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:01:19 --> Config Class Initialized
INFO - 2023-09-28 17:01:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:01:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:01:19 --> Utf8 Class Initialized
INFO - 2023-09-28 17:01:19 --> URI Class Initialized
DEBUG - 2023-09-28 17:01:19 --> No URI present. Default controller set.
INFO - 2023-09-28 17:01:19 --> Router Class Initialized
INFO - 2023-09-28 17:01:19 --> Output Class Initialized
INFO - 2023-09-28 17:01:19 --> Security Class Initialized
DEBUG - 2023-09-28 17:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:01:19 --> Input Class Initialized
INFO - 2023-09-28 17:01:19 --> Language Class Initialized
INFO - 2023-09-28 17:01:19 --> Loader Class Initialized
INFO - 2023-09-28 17:01:19 --> Helper loaded: url_helper
INFO - 2023-09-28 17:01:19 --> Helper loaded: file_helper
INFO - 2023-09-28 17:01:19 --> Helper loaded: html_helper
INFO - 2023-09-28 17:01:19 --> Helper loaded: text_helper
INFO - 2023-09-28 17:01:19 --> Helper loaded: form_helper
INFO - 2023-09-28 17:01:19 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:01:19 --> Helper loaded: security_helper
INFO - 2023-09-28 17:01:19 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:01:19 --> Database Driver Class Initialized
INFO - 2023-09-28 17:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:01:19 --> Parser Class Initialized
INFO - 2023-09-28 17:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:01:19 --> Pagination Class Initialized
INFO - 2023-09-28 17:01:19 --> Form Validation Class Initialized
INFO - 2023-09-28 17:01:19 --> Controller Class Initialized
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
INFO - 2023-09-28 17:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:01:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:01:19 --> Model Class Initialized
INFO - 2023-09-28 17:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:01:19 --> Final output sent to browser
DEBUG - 2023-09-28 17:01:19 --> Total execution time: 0.1047
ERROR - 2023-09-28 17:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:01:34 --> Config Class Initialized
INFO - 2023-09-28 17:01:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:01:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:01:34 --> Utf8 Class Initialized
INFO - 2023-09-28 17:01:34 --> URI Class Initialized
INFO - 2023-09-28 17:01:34 --> Router Class Initialized
INFO - 2023-09-28 17:01:34 --> Output Class Initialized
INFO - 2023-09-28 17:01:34 --> Security Class Initialized
DEBUG - 2023-09-28 17:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:01:34 --> Input Class Initialized
INFO - 2023-09-28 17:01:34 --> Language Class Initialized
INFO - 2023-09-28 17:01:34 --> Loader Class Initialized
INFO - 2023-09-28 17:01:34 --> Helper loaded: url_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: file_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: html_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: text_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: form_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: security_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:01:34 --> Database Driver Class Initialized
INFO - 2023-09-28 17:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:01:34 --> Parser Class Initialized
INFO - 2023-09-28 17:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:01:34 --> Pagination Class Initialized
INFO - 2023-09-28 17:01:34 --> Form Validation Class Initialized
INFO - 2023-09-28 17:01:34 --> Controller Class Initialized
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
INFO - 2023-09-28 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:01:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
INFO - 2023-09-28 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:01:34 --> Final output sent to browser
DEBUG - 2023-09-28 17:01:34 --> Total execution time: 0.1045
ERROR - 2023-09-28 17:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:01:34 --> Config Class Initialized
INFO - 2023-09-28 17:01:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:01:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:01:34 --> Utf8 Class Initialized
INFO - 2023-09-28 17:01:34 --> URI Class Initialized
INFO - 2023-09-28 17:01:34 --> Router Class Initialized
INFO - 2023-09-28 17:01:34 --> Output Class Initialized
INFO - 2023-09-28 17:01:34 --> Security Class Initialized
DEBUG - 2023-09-28 17:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:01:34 --> Input Class Initialized
INFO - 2023-09-28 17:01:34 --> Language Class Initialized
INFO - 2023-09-28 17:01:34 --> Loader Class Initialized
INFO - 2023-09-28 17:01:34 --> Helper loaded: url_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: file_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: html_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: text_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: form_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: security_helper
INFO - 2023-09-28 17:01:34 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:01:34 --> Database Driver Class Initialized
INFO - 2023-09-28 17:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:01:34 --> Parser Class Initialized
INFO - 2023-09-28 17:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:01:34 --> Pagination Class Initialized
INFO - 2023-09-28 17:01:34 --> Form Validation Class Initialized
INFO - 2023-09-28 17:01:34 --> Controller Class Initialized
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:34 --> Model Class Initialized
INFO - 2023-09-28 17:01:34 --> Final output sent to browser
DEBUG - 2023-09-28 17:01:34 --> Total execution time: 0.0418
ERROR - 2023-09-28 17:01:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:01:38 --> Config Class Initialized
INFO - 2023-09-28 17:01:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:01:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:01:38 --> Utf8 Class Initialized
INFO - 2023-09-28 17:01:38 --> URI Class Initialized
INFO - 2023-09-28 17:01:38 --> Router Class Initialized
INFO - 2023-09-28 17:01:38 --> Output Class Initialized
INFO - 2023-09-28 17:01:38 --> Security Class Initialized
DEBUG - 2023-09-28 17:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:01:38 --> Input Class Initialized
INFO - 2023-09-28 17:01:38 --> Language Class Initialized
INFO - 2023-09-28 17:01:38 --> Loader Class Initialized
INFO - 2023-09-28 17:01:38 --> Helper loaded: url_helper
INFO - 2023-09-28 17:01:38 --> Helper loaded: file_helper
INFO - 2023-09-28 17:01:38 --> Helper loaded: html_helper
INFO - 2023-09-28 17:01:38 --> Helper loaded: text_helper
INFO - 2023-09-28 17:01:38 --> Helper loaded: form_helper
INFO - 2023-09-28 17:01:38 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:01:38 --> Helper loaded: security_helper
INFO - 2023-09-28 17:01:38 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:01:38 --> Database Driver Class Initialized
INFO - 2023-09-28 17:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:01:38 --> Parser Class Initialized
INFO - 2023-09-28 17:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:01:38 --> Pagination Class Initialized
INFO - 2023-09-28 17:01:38 --> Form Validation Class Initialized
INFO - 2023-09-28 17:01:38 --> Controller Class Initialized
INFO - 2023-09-28 17:01:38 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:38 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:38 --> Model Class Initialized
INFO - 2023-09-28 17:01:38 --> Final output sent to browser
DEBUG - 2023-09-28 17:01:38 --> Total execution time: 0.3522
ERROR - 2023-09-28 17:01:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:01:44 --> Config Class Initialized
INFO - 2023-09-28 17:01:44 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:01:44 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:01:44 --> Utf8 Class Initialized
INFO - 2023-09-28 17:01:44 --> URI Class Initialized
INFO - 2023-09-28 17:01:44 --> Router Class Initialized
INFO - 2023-09-28 17:01:44 --> Output Class Initialized
INFO - 2023-09-28 17:01:44 --> Security Class Initialized
DEBUG - 2023-09-28 17:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:01:44 --> Input Class Initialized
INFO - 2023-09-28 17:01:44 --> Language Class Initialized
INFO - 2023-09-28 17:01:44 --> Loader Class Initialized
INFO - 2023-09-28 17:01:44 --> Helper loaded: url_helper
INFO - 2023-09-28 17:01:44 --> Helper loaded: file_helper
INFO - 2023-09-28 17:01:44 --> Helper loaded: html_helper
INFO - 2023-09-28 17:01:44 --> Helper loaded: text_helper
INFO - 2023-09-28 17:01:44 --> Helper loaded: form_helper
INFO - 2023-09-28 17:01:44 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:01:44 --> Helper loaded: security_helper
INFO - 2023-09-28 17:01:44 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:01:44 --> Database Driver Class Initialized
INFO - 2023-09-28 17:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:01:44 --> Parser Class Initialized
INFO - 2023-09-28 17:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:01:44 --> Pagination Class Initialized
INFO - 2023-09-28 17:01:44 --> Form Validation Class Initialized
INFO - 2023-09-28 17:01:44 --> Controller Class Initialized
INFO - 2023-09-28 17:01:44 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:44 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:44 --> Model Class Initialized
INFO - 2023-09-28 17:01:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:01:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:01:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:01:44 --> Model Class Initialized
INFO - 2023-09-28 17:01:44 --> Model Class Initialized
INFO - 2023-09-28 17:01:44 --> Model Class Initialized
INFO - 2023-09-28 17:01:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:01:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:01:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:01:44 --> Final output sent to browser
DEBUG - 2023-09-28 17:01:44 --> Total execution time: 0.0907
ERROR - 2023-09-28 17:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:01:45 --> Config Class Initialized
INFO - 2023-09-28 17:01:45 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:01:45 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:01:45 --> Utf8 Class Initialized
INFO - 2023-09-28 17:01:45 --> URI Class Initialized
INFO - 2023-09-28 17:01:45 --> Router Class Initialized
INFO - 2023-09-28 17:01:45 --> Output Class Initialized
INFO - 2023-09-28 17:01:45 --> Security Class Initialized
DEBUG - 2023-09-28 17:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:01:45 --> Input Class Initialized
INFO - 2023-09-28 17:01:45 --> Language Class Initialized
INFO - 2023-09-28 17:01:45 --> Loader Class Initialized
INFO - 2023-09-28 17:01:45 --> Helper loaded: url_helper
INFO - 2023-09-28 17:01:45 --> Helper loaded: file_helper
INFO - 2023-09-28 17:01:45 --> Helper loaded: html_helper
INFO - 2023-09-28 17:01:45 --> Helper loaded: text_helper
INFO - 2023-09-28 17:01:45 --> Helper loaded: form_helper
INFO - 2023-09-28 17:01:45 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:01:45 --> Helper loaded: security_helper
INFO - 2023-09-28 17:01:45 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:01:45 --> Database Driver Class Initialized
INFO - 2023-09-28 17:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:01:45 --> Parser Class Initialized
INFO - 2023-09-28 17:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:01:45 --> Pagination Class Initialized
INFO - 2023-09-28 17:01:45 --> Form Validation Class Initialized
INFO - 2023-09-28 17:01:45 --> Controller Class Initialized
INFO - 2023-09-28 17:01:45 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:45 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:45 --> Model Class Initialized
INFO - 2023-09-28 17:01:45 --> Final output sent to browser
DEBUG - 2023-09-28 17:01:45 --> Total execution time: 0.0402
ERROR - 2023-09-28 17:01:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:01:48 --> Config Class Initialized
INFO - 2023-09-28 17:01:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:01:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:01:48 --> Utf8 Class Initialized
INFO - 2023-09-28 17:01:48 --> URI Class Initialized
INFO - 2023-09-28 17:01:48 --> Router Class Initialized
INFO - 2023-09-28 17:01:48 --> Output Class Initialized
INFO - 2023-09-28 17:01:48 --> Security Class Initialized
DEBUG - 2023-09-28 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:01:48 --> Input Class Initialized
INFO - 2023-09-28 17:01:48 --> Language Class Initialized
INFO - 2023-09-28 17:01:48 --> Loader Class Initialized
INFO - 2023-09-28 17:01:48 --> Helper loaded: url_helper
INFO - 2023-09-28 17:01:48 --> Helper loaded: file_helper
INFO - 2023-09-28 17:01:48 --> Helper loaded: html_helper
INFO - 2023-09-28 17:01:48 --> Helper loaded: text_helper
INFO - 2023-09-28 17:01:48 --> Helper loaded: form_helper
INFO - 2023-09-28 17:01:48 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:01:48 --> Helper loaded: security_helper
INFO - 2023-09-28 17:01:48 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:01:48 --> Database Driver Class Initialized
INFO - 2023-09-28 17:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:01:48 --> Parser Class Initialized
INFO - 2023-09-28 17:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:01:48 --> Pagination Class Initialized
INFO - 2023-09-28 17:01:48 --> Form Validation Class Initialized
INFO - 2023-09-28 17:01:48 --> Controller Class Initialized
INFO - 2023-09-28 17:01:48 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:48 --> Model Class Initialized
DEBUG - 2023-09-28 17:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:01:48 --> Model Class Initialized
INFO - 2023-09-28 17:01:48 --> Final output sent to browser
DEBUG - 2023-09-28 17:01:48 --> Total execution time: 0.3476
ERROR - 2023-09-28 17:02:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:02:59 --> Config Class Initialized
INFO - 2023-09-28 17:02:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:02:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:02:59 --> Utf8 Class Initialized
INFO - 2023-09-28 17:02:59 --> URI Class Initialized
DEBUG - 2023-09-28 17:02:59 --> No URI present. Default controller set.
INFO - 2023-09-28 17:02:59 --> Router Class Initialized
INFO - 2023-09-28 17:02:59 --> Output Class Initialized
INFO - 2023-09-28 17:02:59 --> Security Class Initialized
DEBUG - 2023-09-28 17:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:02:59 --> Input Class Initialized
INFO - 2023-09-28 17:02:59 --> Language Class Initialized
INFO - 2023-09-28 17:02:59 --> Loader Class Initialized
INFO - 2023-09-28 17:02:59 --> Helper loaded: url_helper
INFO - 2023-09-28 17:02:59 --> Helper loaded: file_helper
INFO - 2023-09-28 17:02:59 --> Helper loaded: html_helper
INFO - 2023-09-28 17:02:59 --> Helper loaded: text_helper
INFO - 2023-09-28 17:02:59 --> Helper loaded: form_helper
INFO - 2023-09-28 17:02:59 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:02:59 --> Helper loaded: security_helper
INFO - 2023-09-28 17:02:59 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:02:59 --> Database Driver Class Initialized
INFO - 2023-09-28 17:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:02:59 --> Parser Class Initialized
INFO - 2023-09-28 17:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:02:59 --> Pagination Class Initialized
INFO - 2023-09-28 17:02:59 --> Form Validation Class Initialized
INFO - 2023-09-28 17:02:59 --> Controller Class Initialized
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:02:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
INFO - 2023-09-28 17:02:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:02:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:02:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:02:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:02:59 --> Model Class Initialized
INFO - 2023-09-28 17:03:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:03:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:03:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:03:00 --> Final output sent to browser
DEBUG - 2023-09-28 17:03:00 --> Total execution time: 0.1060
ERROR - 2023-09-28 17:03:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:03:07 --> Config Class Initialized
INFO - 2023-09-28 17:03:07 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:03:07 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:03:07 --> Utf8 Class Initialized
INFO - 2023-09-28 17:03:07 --> URI Class Initialized
DEBUG - 2023-09-28 17:03:07 --> No URI present. Default controller set.
INFO - 2023-09-28 17:03:07 --> Router Class Initialized
INFO - 2023-09-28 17:03:07 --> Output Class Initialized
INFO - 2023-09-28 17:03:07 --> Security Class Initialized
DEBUG - 2023-09-28 17:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:03:07 --> Input Class Initialized
INFO - 2023-09-28 17:03:07 --> Language Class Initialized
INFO - 2023-09-28 17:03:07 --> Loader Class Initialized
INFO - 2023-09-28 17:03:07 --> Helper loaded: url_helper
INFO - 2023-09-28 17:03:07 --> Helper loaded: file_helper
INFO - 2023-09-28 17:03:07 --> Helper loaded: html_helper
INFO - 2023-09-28 17:03:07 --> Helper loaded: text_helper
INFO - 2023-09-28 17:03:07 --> Helper loaded: form_helper
INFO - 2023-09-28 17:03:07 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:03:07 --> Helper loaded: security_helper
INFO - 2023-09-28 17:03:07 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:03:07 --> Database Driver Class Initialized
INFO - 2023-09-28 17:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:03:07 --> Parser Class Initialized
INFO - 2023-09-28 17:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:03:07 --> Pagination Class Initialized
INFO - 2023-09-28 17:03:07 --> Form Validation Class Initialized
INFO - 2023-09-28 17:03:07 --> Controller Class Initialized
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
INFO - 2023-09-28 17:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:03:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:03:07 --> Model Class Initialized
INFO - 2023-09-28 17:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:03:07 --> Final output sent to browser
DEBUG - 2023-09-28 17:03:07 --> Total execution time: 0.1013
ERROR - 2023-09-28 17:03:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:03:17 --> Config Class Initialized
INFO - 2023-09-28 17:03:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:03:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:03:17 --> Utf8 Class Initialized
INFO - 2023-09-28 17:03:17 --> URI Class Initialized
INFO - 2023-09-28 17:03:17 --> Router Class Initialized
INFO - 2023-09-28 17:03:17 --> Output Class Initialized
INFO - 2023-09-28 17:03:17 --> Security Class Initialized
DEBUG - 2023-09-28 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:03:17 --> Input Class Initialized
INFO - 2023-09-28 17:03:17 --> Language Class Initialized
INFO - 2023-09-28 17:03:17 --> Loader Class Initialized
INFO - 2023-09-28 17:03:17 --> Helper loaded: url_helper
INFO - 2023-09-28 17:03:17 --> Helper loaded: file_helper
INFO - 2023-09-28 17:03:17 --> Helper loaded: html_helper
INFO - 2023-09-28 17:03:17 --> Helper loaded: text_helper
INFO - 2023-09-28 17:03:17 --> Helper loaded: form_helper
INFO - 2023-09-28 17:03:17 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:03:17 --> Helper loaded: security_helper
INFO - 2023-09-28 17:03:17 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:03:17 --> Database Driver Class Initialized
INFO - 2023-09-28 17:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:03:17 --> Parser Class Initialized
INFO - 2023-09-28 17:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:03:17 --> Pagination Class Initialized
INFO - 2023-09-28 17:03:17 --> Form Validation Class Initialized
INFO - 2023-09-28 17:03:17 --> Controller Class Initialized
INFO - 2023-09-28 17:03:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:17 --> Model Class Initialized
INFO - 2023-09-28 17:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:03:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:03:17 --> Model Class Initialized
INFO - 2023-09-28 17:03:17 --> Model Class Initialized
INFO - 2023-09-28 17:03:17 --> Model Class Initialized
INFO - 2023-09-28 17:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:03:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:03:17 --> Final output sent to browser
DEBUG - 2023-09-28 17:03:17 --> Total execution time: 0.0835
ERROR - 2023-09-28 17:03:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:03:18 --> Config Class Initialized
INFO - 2023-09-28 17:03:18 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:03:18 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:03:18 --> Utf8 Class Initialized
INFO - 2023-09-28 17:03:18 --> URI Class Initialized
INFO - 2023-09-28 17:03:18 --> Router Class Initialized
INFO - 2023-09-28 17:03:18 --> Output Class Initialized
INFO - 2023-09-28 17:03:18 --> Security Class Initialized
DEBUG - 2023-09-28 17:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:03:18 --> Input Class Initialized
INFO - 2023-09-28 17:03:18 --> Language Class Initialized
INFO - 2023-09-28 17:03:18 --> Loader Class Initialized
INFO - 2023-09-28 17:03:18 --> Helper loaded: url_helper
INFO - 2023-09-28 17:03:18 --> Helper loaded: file_helper
INFO - 2023-09-28 17:03:18 --> Helper loaded: html_helper
INFO - 2023-09-28 17:03:18 --> Helper loaded: text_helper
INFO - 2023-09-28 17:03:18 --> Helper loaded: form_helper
INFO - 2023-09-28 17:03:18 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:03:18 --> Helper loaded: security_helper
INFO - 2023-09-28 17:03:18 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:03:18 --> Database Driver Class Initialized
INFO - 2023-09-28 17:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:03:18 --> Parser Class Initialized
INFO - 2023-09-28 17:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:03:18 --> Pagination Class Initialized
INFO - 2023-09-28 17:03:18 --> Form Validation Class Initialized
INFO - 2023-09-28 17:03:18 --> Controller Class Initialized
INFO - 2023-09-28 17:03:18 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:18 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:18 --> Model Class Initialized
INFO - 2023-09-28 17:03:18 --> Final output sent to browser
DEBUG - 2023-09-28 17:03:18 --> Total execution time: 0.0413
ERROR - 2023-09-28 17:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:03:20 --> Config Class Initialized
INFO - 2023-09-28 17:03:20 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:03:20 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:03:20 --> Utf8 Class Initialized
INFO - 2023-09-28 17:03:20 --> URI Class Initialized
DEBUG - 2023-09-28 17:03:20 --> No URI present. Default controller set.
INFO - 2023-09-28 17:03:20 --> Router Class Initialized
INFO - 2023-09-28 17:03:20 --> Output Class Initialized
INFO - 2023-09-28 17:03:20 --> Security Class Initialized
DEBUG - 2023-09-28 17:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:03:20 --> Input Class Initialized
INFO - 2023-09-28 17:03:20 --> Language Class Initialized
INFO - 2023-09-28 17:03:20 --> Loader Class Initialized
INFO - 2023-09-28 17:03:20 --> Helper loaded: url_helper
INFO - 2023-09-28 17:03:20 --> Helper loaded: file_helper
INFO - 2023-09-28 17:03:20 --> Helper loaded: html_helper
INFO - 2023-09-28 17:03:20 --> Helper loaded: text_helper
INFO - 2023-09-28 17:03:20 --> Helper loaded: form_helper
INFO - 2023-09-28 17:03:20 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:03:20 --> Helper loaded: security_helper
INFO - 2023-09-28 17:03:20 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:03:20 --> Database Driver Class Initialized
INFO - 2023-09-28 17:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:03:20 --> Parser Class Initialized
INFO - 2023-09-28 17:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:03:20 --> Pagination Class Initialized
INFO - 2023-09-28 17:03:20 --> Form Validation Class Initialized
INFO - 2023-09-28 17:03:20 --> Controller Class Initialized
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
INFO - 2023-09-28 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:03:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:03:20 --> Model Class Initialized
INFO - 2023-09-28 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:03:20 --> Final output sent to browser
DEBUG - 2023-09-28 17:03:20 --> Total execution time: 0.0971
ERROR - 2023-09-28 17:03:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:03:35 --> Config Class Initialized
INFO - 2023-09-28 17:03:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:03:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:03:35 --> Utf8 Class Initialized
INFO - 2023-09-28 17:03:35 --> URI Class Initialized
DEBUG - 2023-09-28 17:03:35 --> No URI present. Default controller set.
INFO - 2023-09-28 17:03:35 --> Router Class Initialized
INFO - 2023-09-28 17:03:35 --> Output Class Initialized
INFO - 2023-09-28 17:03:35 --> Security Class Initialized
DEBUG - 2023-09-28 17:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:03:35 --> Input Class Initialized
INFO - 2023-09-28 17:03:35 --> Language Class Initialized
INFO - 2023-09-28 17:03:35 --> Loader Class Initialized
INFO - 2023-09-28 17:03:35 --> Helper loaded: url_helper
INFO - 2023-09-28 17:03:35 --> Helper loaded: file_helper
INFO - 2023-09-28 17:03:35 --> Helper loaded: html_helper
INFO - 2023-09-28 17:03:35 --> Helper loaded: text_helper
INFO - 2023-09-28 17:03:35 --> Helper loaded: form_helper
INFO - 2023-09-28 17:03:35 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:03:35 --> Helper loaded: security_helper
INFO - 2023-09-28 17:03:35 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:03:35 --> Database Driver Class Initialized
INFO - 2023-09-28 17:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:03:35 --> Parser Class Initialized
INFO - 2023-09-28 17:03:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:03:35 --> Pagination Class Initialized
INFO - 2023-09-28 17:03:35 --> Form Validation Class Initialized
INFO - 2023-09-28 17:03:35 --> Controller Class Initialized
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:03:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
INFO - 2023-09-28 17:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:03:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:03:35 --> Model Class Initialized
INFO - 2023-09-28 17:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:03:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:03:35 --> Final output sent to browser
DEBUG - 2023-09-28 17:03:35 --> Total execution time: 0.1131
ERROR - 2023-09-28 17:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:04:03 --> Config Class Initialized
INFO - 2023-09-28 17:04:03 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:04:03 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:04:03 --> Utf8 Class Initialized
INFO - 2023-09-28 17:04:03 --> URI Class Initialized
DEBUG - 2023-09-28 17:04:03 --> No URI present. Default controller set.
INFO - 2023-09-28 17:04:03 --> Router Class Initialized
INFO - 2023-09-28 17:04:03 --> Output Class Initialized
INFO - 2023-09-28 17:04:03 --> Security Class Initialized
DEBUG - 2023-09-28 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:04:03 --> Input Class Initialized
INFO - 2023-09-28 17:04:03 --> Language Class Initialized
INFO - 2023-09-28 17:04:03 --> Loader Class Initialized
INFO - 2023-09-28 17:04:03 --> Helper loaded: url_helper
INFO - 2023-09-28 17:04:03 --> Helper loaded: file_helper
INFO - 2023-09-28 17:04:03 --> Helper loaded: html_helper
INFO - 2023-09-28 17:04:03 --> Helper loaded: text_helper
INFO - 2023-09-28 17:04:03 --> Helper loaded: form_helper
INFO - 2023-09-28 17:04:03 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:04:03 --> Helper loaded: security_helper
INFO - 2023-09-28 17:04:03 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:04:03 --> Database Driver Class Initialized
INFO - 2023-09-28 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:04:03 --> Parser Class Initialized
INFO - 2023-09-28 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:04:03 --> Pagination Class Initialized
INFO - 2023-09-28 17:04:03 --> Form Validation Class Initialized
INFO - 2023-09-28 17:04:03 --> Controller Class Initialized
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
INFO - 2023-09-28 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:04:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:04:03 --> Model Class Initialized
INFO - 2023-09-28 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:04:03 --> Final output sent to browser
DEBUG - 2023-09-28 17:04:03 --> Total execution time: 0.1379
ERROR - 2023-09-28 17:04:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:04:24 --> Config Class Initialized
INFO - 2023-09-28 17:04:24 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:04:24 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:04:24 --> Utf8 Class Initialized
INFO - 2023-09-28 17:04:24 --> URI Class Initialized
DEBUG - 2023-09-28 17:04:24 --> No URI present. Default controller set.
INFO - 2023-09-28 17:04:24 --> Router Class Initialized
INFO - 2023-09-28 17:04:24 --> Output Class Initialized
INFO - 2023-09-28 17:04:24 --> Security Class Initialized
DEBUG - 2023-09-28 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:04:24 --> Input Class Initialized
INFO - 2023-09-28 17:04:24 --> Language Class Initialized
INFO - 2023-09-28 17:04:24 --> Loader Class Initialized
INFO - 2023-09-28 17:04:24 --> Helper loaded: url_helper
INFO - 2023-09-28 17:04:24 --> Helper loaded: file_helper
INFO - 2023-09-28 17:04:24 --> Helper loaded: html_helper
INFO - 2023-09-28 17:04:24 --> Helper loaded: text_helper
INFO - 2023-09-28 17:04:24 --> Helper loaded: form_helper
INFO - 2023-09-28 17:04:24 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:04:24 --> Helper loaded: security_helper
INFO - 2023-09-28 17:04:24 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:04:24 --> Database Driver Class Initialized
INFO - 2023-09-28 17:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:04:24 --> Parser Class Initialized
INFO - 2023-09-28 17:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:04:24 --> Pagination Class Initialized
INFO - 2023-09-28 17:04:24 --> Form Validation Class Initialized
INFO - 2023-09-28 17:04:24 --> Controller Class Initialized
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
INFO - 2023-09-28 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:04:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:04:24 --> Model Class Initialized
INFO - 2023-09-28 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:04:24 --> Final output sent to browser
DEBUG - 2023-09-28 17:04:24 --> Total execution time: 0.2289
ERROR - 2023-09-28 17:04:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:04:35 --> Config Class Initialized
INFO - 2023-09-28 17:04:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:04:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:04:35 --> Utf8 Class Initialized
INFO - 2023-09-28 17:04:35 --> URI Class Initialized
INFO - 2023-09-28 17:04:35 --> Router Class Initialized
INFO - 2023-09-28 17:04:35 --> Output Class Initialized
INFO - 2023-09-28 17:04:35 --> Security Class Initialized
DEBUG - 2023-09-28 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:04:35 --> Input Class Initialized
INFO - 2023-09-28 17:04:35 --> Language Class Initialized
INFO - 2023-09-28 17:04:35 --> Loader Class Initialized
INFO - 2023-09-28 17:04:35 --> Helper loaded: url_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: file_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: html_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: text_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: form_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: security_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:04:35 --> Database Driver Class Initialized
INFO - 2023-09-28 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:04:35 --> Parser Class Initialized
INFO - 2023-09-28 17:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:04:35 --> Pagination Class Initialized
INFO - 2023-09-28 17:04:35 --> Form Validation Class Initialized
INFO - 2023-09-28 17:04:35 --> Controller Class Initialized
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
INFO - 2023-09-28 17:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:04:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
INFO - 2023-09-28 17:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:04:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:04:35 --> Final output sent to browser
DEBUG - 2023-09-28 17:04:35 --> Total execution time: 0.1468
ERROR - 2023-09-28 17:04:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:04:35 --> Config Class Initialized
INFO - 2023-09-28 17:04:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:04:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:04:35 --> Utf8 Class Initialized
INFO - 2023-09-28 17:04:35 --> URI Class Initialized
INFO - 2023-09-28 17:04:35 --> Router Class Initialized
INFO - 2023-09-28 17:04:35 --> Output Class Initialized
INFO - 2023-09-28 17:04:35 --> Security Class Initialized
DEBUG - 2023-09-28 17:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:04:35 --> Input Class Initialized
INFO - 2023-09-28 17:04:35 --> Language Class Initialized
INFO - 2023-09-28 17:04:35 --> Loader Class Initialized
INFO - 2023-09-28 17:04:35 --> Helper loaded: url_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: file_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: html_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: text_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: form_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: security_helper
INFO - 2023-09-28 17:04:35 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:04:35 --> Database Driver Class Initialized
INFO - 2023-09-28 17:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:04:35 --> Parser Class Initialized
INFO - 2023-09-28 17:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:04:35 --> Pagination Class Initialized
INFO - 2023-09-28 17:04:35 --> Form Validation Class Initialized
INFO - 2023-09-28 17:04:35 --> Controller Class Initialized
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:35 --> Model Class Initialized
INFO - 2023-09-28 17:04:35 --> Final output sent to browser
DEBUG - 2023-09-28 17:04:35 --> Total execution time: 0.0544
ERROR - 2023-09-28 17:04:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:04:39 --> Config Class Initialized
INFO - 2023-09-28 17:04:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:04:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:04:39 --> Utf8 Class Initialized
INFO - 2023-09-28 17:04:39 --> URI Class Initialized
INFO - 2023-09-28 17:04:39 --> Router Class Initialized
INFO - 2023-09-28 17:04:39 --> Output Class Initialized
INFO - 2023-09-28 17:04:39 --> Security Class Initialized
DEBUG - 2023-09-28 17:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:04:39 --> Input Class Initialized
INFO - 2023-09-28 17:04:39 --> Language Class Initialized
INFO - 2023-09-28 17:04:39 --> Loader Class Initialized
INFO - 2023-09-28 17:04:39 --> Helper loaded: url_helper
INFO - 2023-09-28 17:04:39 --> Helper loaded: file_helper
INFO - 2023-09-28 17:04:39 --> Helper loaded: html_helper
INFO - 2023-09-28 17:04:39 --> Helper loaded: text_helper
INFO - 2023-09-28 17:04:39 --> Helper loaded: form_helper
INFO - 2023-09-28 17:04:39 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:04:39 --> Helper loaded: security_helper
INFO - 2023-09-28 17:04:39 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:04:39 --> Database Driver Class Initialized
INFO - 2023-09-28 17:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:04:39 --> Parser Class Initialized
INFO - 2023-09-28 17:04:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:04:39 --> Pagination Class Initialized
INFO - 2023-09-28 17:04:39 --> Form Validation Class Initialized
INFO - 2023-09-28 17:04:39 --> Controller Class Initialized
INFO - 2023-09-28 17:04:39 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:39 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:39 --> Model Class Initialized
INFO - 2023-09-28 17:04:40 --> Final output sent to browser
DEBUG - 2023-09-28 17:04:40 --> Total execution time: 0.7914
ERROR - 2023-09-28 17:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:04:44 --> Config Class Initialized
INFO - 2023-09-28 17:04:44 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:04:44 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:04:44 --> Utf8 Class Initialized
INFO - 2023-09-28 17:04:44 --> URI Class Initialized
DEBUG - 2023-09-28 17:04:44 --> No URI present. Default controller set.
INFO - 2023-09-28 17:04:44 --> Router Class Initialized
INFO - 2023-09-28 17:04:44 --> Output Class Initialized
INFO - 2023-09-28 17:04:44 --> Security Class Initialized
DEBUG - 2023-09-28 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:04:44 --> Input Class Initialized
INFO - 2023-09-28 17:04:44 --> Language Class Initialized
INFO - 2023-09-28 17:04:44 --> Loader Class Initialized
INFO - 2023-09-28 17:04:44 --> Helper loaded: url_helper
INFO - 2023-09-28 17:04:44 --> Helper loaded: file_helper
INFO - 2023-09-28 17:04:44 --> Helper loaded: html_helper
INFO - 2023-09-28 17:04:44 --> Helper loaded: text_helper
INFO - 2023-09-28 17:04:44 --> Helper loaded: form_helper
INFO - 2023-09-28 17:04:44 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:04:44 --> Helper loaded: security_helper
INFO - 2023-09-28 17:04:44 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:04:44 --> Database Driver Class Initialized
INFO - 2023-09-28 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:04:44 --> Parser Class Initialized
INFO - 2023-09-28 17:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:04:44 --> Pagination Class Initialized
INFO - 2023-09-28 17:04:44 --> Form Validation Class Initialized
INFO - 2023-09-28 17:04:44 --> Controller Class Initialized
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
DEBUG - 2023-09-28 17:04:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
INFO - 2023-09-28 17:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:04:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:04:44 --> Model Class Initialized
INFO - 2023-09-28 17:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:04:44 --> Final output sent to browser
DEBUG - 2023-09-28 17:04:44 --> Total execution time: 0.2032
ERROR - 2023-09-28 17:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:17 --> Config Class Initialized
INFO - 2023-09-28 17:05:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:17 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:17 --> URI Class Initialized
INFO - 2023-09-28 17:05:17 --> Router Class Initialized
INFO - 2023-09-28 17:05:17 --> Output Class Initialized
INFO - 2023-09-28 17:05:17 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:17 --> Input Class Initialized
INFO - 2023-09-28 17:05:17 --> Language Class Initialized
INFO - 2023-09-28 17:05:17 --> Loader Class Initialized
INFO - 2023-09-28 17:05:17 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:17 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:17 --> Parser Class Initialized
INFO - 2023-09-28 17:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:17 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:17 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:17 --> Controller Class Initialized
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
INFO - 2023-09-28 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:05:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
INFO - 2023-09-28 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:05:17 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:17 --> Total execution time: 0.1461
ERROR - 2023-09-28 17:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:17 --> Config Class Initialized
INFO - 2023-09-28 17:05:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:17 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:17 --> URI Class Initialized
INFO - 2023-09-28 17:05:17 --> Router Class Initialized
INFO - 2023-09-28 17:05:17 --> Output Class Initialized
INFO - 2023-09-28 17:05:17 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:17 --> Input Class Initialized
INFO - 2023-09-28 17:05:17 --> Language Class Initialized
INFO - 2023-09-28 17:05:17 --> Loader Class Initialized
INFO - 2023-09-28 17:05:17 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:17 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:17 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:17 --> Parser Class Initialized
INFO - 2023-09-28 17:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:17 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:17 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:17 --> Controller Class Initialized
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:17 --> Model Class Initialized
INFO - 2023-09-28 17:05:17 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:17 --> Total execution time: 0.0514
ERROR - 2023-09-28 17:05:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:21 --> Config Class Initialized
INFO - 2023-09-28 17:05:21 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:21 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:21 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:21 --> URI Class Initialized
INFO - 2023-09-28 17:05:21 --> Router Class Initialized
INFO - 2023-09-28 17:05:21 --> Output Class Initialized
INFO - 2023-09-28 17:05:21 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:21 --> Input Class Initialized
INFO - 2023-09-28 17:05:21 --> Language Class Initialized
INFO - 2023-09-28 17:05:21 --> Loader Class Initialized
INFO - 2023-09-28 17:05:21 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:21 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:21 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:21 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:21 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:21 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:21 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:21 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:21 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:21 --> Parser Class Initialized
INFO - 2023-09-28 17:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:21 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:21 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:21 --> Controller Class Initialized
INFO - 2023-09-28 17:05:21 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:21 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:21 --> Model Class Initialized
INFO - 2023-09-28 17:05:22 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:22 --> Total execution time: 0.8807
ERROR - 2023-09-28 17:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:32 --> Config Class Initialized
INFO - 2023-09-28 17:05:32 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:32 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:32 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:32 --> URI Class Initialized
DEBUG - 2023-09-28 17:05:32 --> No URI present. Default controller set.
INFO - 2023-09-28 17:05:32 --> Router Class Initialized
INFO - 2023-09-28 17:05:32 --> Output Class Initialized
INFO - 2023-09-28 17:05:32 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:32 --> Input Class Initialized
INFO - 2023-09-28 17:05:32 --> Language Class Initialized
INFO - 2023-09-28 17:05:32 --> Loader Class Initialized
INFO - 2023-09-28 17:05:32 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:32 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:32 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:32 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:32 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:32 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:32 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:32 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:32 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:32 --> Parser Class Initialized
INFO - 2023-09-28 17:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:32 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:32 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:32 --> Controller Class Initialized
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
INFO - 2023-09-28 17:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:05:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:05:32 --> Model Class Initialized
INFO - 2023-09-28 17:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:05:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:05:32 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:32 --> Total execution time: 0.2148
ERROR - 2023-09-28 17:05:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:41 --> Config Class Initialized
INFO - 2023-09-28 17:05:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:41 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:41 --> URI Class Initialized
INFO - 2023-09-28 17:05:41 --> Router Class Initialized
INFO - 2023-09-28 17:05:41 --> Output Class Initialized
INFO - 2023-09-28 17:05:41 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:41 --> Input Class Initialized
INFO - 2023-09-28 17:05:41 --> Language Class Initialized
INFO - 2023-09-28 17:05:41 --> Loader Class Initialized
INFO - 2023-09-28 17:05:41 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:41 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:41 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:41 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:41 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:41 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:41 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:41 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:41 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:41 --> Parser Class Initialized
INFO - 2023-09-28 17:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:41 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:41 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:41 --> Controller Class Initialized
DEBUG - 2023-09-28 17:05:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:41 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:41 --> Model Class Initialized
INFO - 2023-09-28 17:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-28 17:05:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:05:41 --> Model Class Initialized
INFO - 2023-09-28 17:05:41 --> Model Class Initialized
INFO - 2023-09-28 17:05:41 --> Model Class Initialized
INFO - 2023-09-28 17:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:05:41 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:41 --> Total execution time: 0.1451
ERROR - 2023-09-28 17:05:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:42 --> Config Class Initialized
INFO - 2023-09-28 17:05:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:42 --> URI Class Initialized
INFO - 2023-09-28 17:05:42 --> Router Class Initialized
INFO - 2023-09-28 17:05:42 --> Output Class Initialized
INFO - 2023-09-28 17:05:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:42 --> Input Class Initialized
INFO - 2023-09-28 17:05:42 --> Language Class Initialized
INFO - 2023-09-28 17:05:42 --> Loader Class Initialized
INFO - 2023-09-28 17:05:42 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:42 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:42 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:42 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:42 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:42 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:42 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:42 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:42 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:42 --> Parser Class Initialized
INFO - 2023-09-28 17:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:42 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:42 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:42 --> Controller Class Initialized
DEBUG - 2023-09-28 17:05:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:42 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:42 --> Model Class Initialized
INFO - 2023-09-28 17:05:42 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:42 --> Total execution time: 0.0303
ERROR - 2023-09-28 17:05:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:45 --> Config Class Initialized
INFO - 2023-09-28 17:05:45 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:45 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:45 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:45 --> URI Class Initialized
INFO - 2023-09-28 17:05:45 --> Router Class Initialized
INFO - 2023-09-28 17:05:45 --> Output Class Initialized
INFO - 2023-09-28 17:05:45 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:45 --> Input Class Initialized
INFO - 2023-09-28 17:05:45 --> Language Class Initialized
INFO - 2023-09-28 17:05:45 --> Loader Class Initialized
INFO - 2023-09-28 17:05:45 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:45 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:45 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:45 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:45 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:45 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:45 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:45 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:45 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:45 --> Parser Class Initialized
INFO - 2023-09-28 17:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:45 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:45 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:45 --> Controller Class Initialized
DEBUG - 2023-09-28 17:05:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:45 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:45 --> Model Class Initialized
INFO - 2023-09-28 17:05:45 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:45 --> Total execution time: 0.1616
ERROR - 2023-09-28 17:05:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:05:59 --> Config Class Initialized
INFO - 2023-09-28 17:05:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:05:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:05:59 --> Utf8 Class Initialized
INFO - 2023-09-28 17:05:59 --> URI Class Initialized
DEBUG - 2023-09-28 17:05:59 --> No URI present. Default controller set.
INFO - 2023-09-28 17:05:59 --> Router Class Initialized
INFO - 2023-09-28 17:05:59 --> Output Class Initialized
INFO - 2023-09-28 17:05:59 --> Security Class Initialized
DEBUG - 2023-09-28 17:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:05:59 --> Input Class Initialized
INFO - 2023-09-28 17:05:59 --> Language Class Initialized
INFO - 2023-09-28 17:05:59 --> Loader Class Initialized
INFO - 2023-09-28 17:05:59 --> Helper loaded: url_helper
INFO - 2023-09-28 17:05:59 --> Helper loaded: file_helper
INFO - 2023-09-28 17:05:59 --> Helper loaded: html_helper
INFO - 2023-09-28 17:05:59 --> Helper loaded: text_helper
INFO - 2023-09-28 17:05:59 --> Helper loaded: form_helper
INFO - 2023-09-28 17:05:59 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:05:59 --> Helper loaded: security_helper
INFO - 2023-09-28 17:05:59 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:05:59 --> Database Driver Class Initialized
INFO - 2023-09-28 17:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:05:59 --> Parser Class Initialized
INFO - 2023-09-28 17:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:05:59 --> Pagination Class Initialized
INFO - 2023-09-28 17:05:59 --> Form Validation Class Initialized
INFO - 2023-09-28 17:05:59 --> Controller Class Initialized
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:05:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
INFO - 2023-09-28 17:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:05:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:05:59 --> Model Class Initialized
INFO - 2023-09-28 17:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:05:59 --> Final output sent to browser
DEBUG - 2023-09-28 17:05:59 --> Total execution time: 0.2194
ERROR - 2023-09-28 17:06:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:06:35 --> Config Class Initialized
INFO - 2023-09-28 17:06:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:06:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:06:35 --> Utf8 Class Initialized
INFO - 2023-09-28 17:06:35 --> URI Class Initialized
INFO - 2023-09-28 17:06:35 --> Router Class Initialized
INFO - 2023-09-28 17:06:35 --> Output Class Initialized
INFO - 2023-09-28 17:06:35 --> Security Class Initialized
DEBUG - 2023-09-28 17:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:06:35 --> Input Class Initialized
INFO - 2023-09-28 17:06:35 --> Language Class Initialized
INFO - 2023-09-28 17:06:35 --> Loader Class Initialized
INFO - 2023-09-28 17:06:35 --> Helper loaded: url_helper
INFO - 2023-09-28 17:06:35 --> Helper loaded: file_helper
INFO - 2023-09-28 17:06:35 --> Helper loaded: html_helper
INFO - 2023-09-28 17:06:35 --> Helper loaded: text_helper
INFO - 2023-09-28 17:06:35 --> Helper loaded: form_helper
INFO - 2023-09-28 17:06:35 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:06:35 --> Helper loaded: security_helper
INFO - 2023-09-28 17:06:35 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:06:35 --> Database Driver Class Initialized
INFO - 2023-09-28 17:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:06:35 --> Parser Class Initialized
INFO - 2023-09-28 17:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:06:35 --> Pagination Class Initialized
INFO - 2023-09-28 17:06:35 --> Form Validation Class Initialized
INFO - 2023-09-28 17:06:35 --> Controller Class Initialized
INFO - 2023-09-28 17:06:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:06:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:06:35 --> Model Class Initialized
DEBUG - 2023-09-28 17:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:06:35 --> Model Class Initialized
INFO - 2023-09-28 17:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-28 17:06:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:06:35 --> Model Class Initialized
INFO - 2023-09-28 17:06:35 --> Model Class Initialized
INFO - 2023-09-28 17:06:35 --> Model Class Initialized
INFO - 2023-09-28 17:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:06:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:06:35 --> Final output sent to browser
DEBUG - 2023-09-28 17:06:35 --> Total execution time: 0.1496
ERROR - 2023-09-28 17:06:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:06:36 --> Config Class Initialized
INFO - 2023-09-28 17:06:36 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:06:36 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:06:36 --> Utf8 Class Initialized
INFO - 2023-09-28 17:06:36 --> URI Class Initialized
INFO - 2023-09-28 17:06:36 --> Router Class Initialized
INFO - 2023-09-28 17:06:36 --> Output Class Initialized
INFO - 2023-09-28 17:06:36 --> Security Class Initialized
DEBUG - 2023-09-28 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:06:36 --> Input Class Initialized
INFO - 2023-09-28 17:06:36 --> Language Class Initialized
INFO - 2023-09-28 17:06:36 --> Loader Class Initialized
INFO - 2023-09-28 17:06:36 --> Helper loaded: url_helper
INFO - 2023-09-28 17:06:36 --> Helper loaded: file_helper
INFO - 2023-09-28 17:06:36 --> Helper loaded: html_helper
INFO - 2023-09-28 17:06:36 --> Helper loaded: text_helper
INFO - 2023-09-28 17:06:36 --> Helper loaded: form_helper
INFO - 2023-09-28 17:06:36 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:06:36 --> Helper loaded: security_helper
INFO - 2023-09-28 17:06:36 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:06:36 --> Database Driver Class Initialized
INFO - 2023-09-28 17:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:06:36 --> Parser Class Initialized
INFO - 2023-09-28 17:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:06:36 --> Pagination Class Initialized
INFO - 2023-09-28 17:06:36 --> Form Validation Class Initialized
INFO - 2023-09-28 17:06:36 --> Controller Class Initialized
INFO - 2023-09-28 17:06:36 --> Model Class Initialized
DEBUG - 2023-09-28 17:06:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:06:36 --> Model Class Initialized
DEBUG - 2023-09-28 17:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:06:36 --> Model Class Initialized
INFO - 2023-09-28 17:06:36 --> Final output sent to browser
DEBUG - 2023-09-28 17:06:36 --> Total execution time: 0.0464
ERROR - 2023-09-28 17:06:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:06:41 --> Config Class Initialized
INFO - 2023-09-28 17:06:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:06:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:06:41 --> Utf8 Class Initialized
INFO - 2023-09-28 17:06:41 --> URI Class Initialized
INFO - 2023-09-28 17:06:41 --> Router Class Initialized
INFO - 2023-09-28 17:06:41 --> Output Class Initialized
INFO - 2023-09-28 17:06:41 --> Security Class Initialized
DEBUG - 2023-09-28 17:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:06:41 --> Input Class Initialized
INFO - 2023-09-28 17:06:41 --> Language Class Initialized
INFO - 2023-09-28 17:06:41 --> Loader Class Initialized
INFO - 2023-09-28 17:06:41 --> Helper loaded: url_helper
INFO - 2023-09-28 17:06:41 --> Helper loaded: file_helper
INFO - 2023-09-28 17:06:41 --> Helper loaded: html_helper
INFO - 2023-09-28 17:06:41 --> Helper loaded: text_helper
INFO - 2023-09-28 17:06:41 --> Helper loaded: form_helper
INFO - 2023-09-28 17:06:41 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:06:41 --> Helper loaded: security_helper
INFO - 2023-09-28 17:06:41 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:06:41 --> Database Driver Class Initialized
INFO - 2023-09-28 17:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:06:41 --> Parser Class Initialized
INFO - 2023-09-28 17:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:06:41 --> Pagination Class Initialized
INFO - 2023-09-28 17:06:41 --> Form Validation Class Initialized
INFO - 2023-09-28 17:06:41 --> Controller Class Initialized
INFO - 2023-09-28 17:06:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:06:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:06:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:06:41 --> Model Class Initialized
INFO - 2023-09-28 17:06:41 --> Final output sent to browser
DEBUG - 2023-09-28 17:06:41 --> Total execution time: 0.1417
ERROR - 2023-09-28 17:07:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:07:17 --> Config Class Initialized
INFO - 2023-09-28 17:07:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:07:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:07:17 --> Utf8 Class Initialized
INFO - 2023-09-28 17:07:17 --> URI Class Initialized
INFO - 2023-09-28 17:07:17 --> Router Class Initialized
INFO - 2023-09-28 17:07:17 --> Output Class Initialized
INFO - 2023-09-28 17:07:17 --> Security Class Initialized
DEBUG - 2023-09-28 17:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:07:17 --> Input Class Initialized
INFO - 2023-09-28 17:07:17 --> Language Class Initialized
INFO - 2023-09-28 17:07:17 --> Loader Class Initialized
INFO - 2023-09-28 17:07:17 --> Helper loaded: url_helper
INFO - 2023-09-28 17:07:17 --> Helper loaded: file_helper
INFO - 2023-09-28 17:07:17 --> Helper loaded: html_helper
INFO - 2023-09-28 17:07:17 --> Helper loaded: text_helper
INFO - 2023-09-28 17:07:17 --> Helper loaded: form_helper
INFO - 2023-09-28 17:07:17 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:07:17 --> Helper loaded: security_helper
INFO - 2023-09-28 17:07:17 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:07:17 --> Database Driver Class Initialized
INFO - 2023-09-28 17:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:07:17 --> Parser Class Initialized
INFO - 2023-09-28 17:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:07:17 --> Pagination Class Initialized
INFO - 2023-09-28 17:07:17 --> Form Validation Class Initialized
INFO - 2023-09-28 17:07:17 --> Controller Class Initialized
INFO - 2023-09-28 17:07:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:07:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:07:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:07:17 --> Model Class Initialized
INFO - 2023-09-28 17:07:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:07:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:07:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:07:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:07:17 --> Model Class Initialized
INFO - 2023-09-28 17:07:17 --> Model Class Initialized
INFO - 2023-09-28 17:07:17 --> Model Class Initialized
INFO - 2023-09-28 17:07:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:07:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:07:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:07:18 --> Final output sent to browser
DEBUG - 2023-09-28 17:07:18 --> Total execution time: 0.1608
ERROR - 2023-09-28 17:07:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:07:18 --> Config Class Initialized
INFO - 2023-09-28 17:07:18 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:07:18 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:07:18 --> Utf8 Class Initialized
INFO - 2023-09-28 17:07:18 --> URI Class Initialized
INFO - 2023-09-28 17:07:18 --> Router Class Initialized
INFO - 2023-09-28 17:07:18 --> Output Class Initialized
INFO - 2023-09-28 17:07:18 --> Security Class Initialized
DEBUG - 2023-09-28 17:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:07:18 --> Input Class Initialized
INFO - 2023-09-28 17:07:18 --> Language Class Initialized
INFO - 2023-09-28 17:07:18 --> Loader Class Initialized
INFO - 2023-09-28 17:07:18 --> Helper loaded: url_helper
INFO - 2023-09-28 17:07:18 --> Helper loaded: file_helper
INFO - 2023-09-28 17:07:18 --> Helper loaded: html_helper
INFO - 2023-09-28 17:07:18 --> Helper loaded: text_helper
INFO - 2023-09-28 17:07:18 --> Helper loaded: form_helper
INFO - 2023-09-28 17:07:18 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:07:18 --> Helper loaded: security_helper
INFO - 2023-09-28 17:07:18 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:07:18 --> Database Driver Class Initialized
INFO - 2023-09-28 17:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:07:18 --> Parser Class Initialized
INFO - 2023-09-28 17:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:07:18 --> Pagination Class Initialized
INFO - 2023-09-28 17:07:18 --> Form Validation Class Initialized
INFO - 2023-09-28 17:07:18 --> Controller Class Initialized
INFO - 2023-09-28 17:07:18 --> Model Class Initialized
DEBUG - 2023-09-28 17:07:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:07:18 --> Model Class Initialized
DEBUG - 2023-09-28 17:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:07:18 --> Model Class Initialized
INFO - 2023-09-28 17:07:18 --> Final output sent to browser
DEBUG - 2023-09-28 17:07:18 --> Total execution time: 0.0521
ERROR - 2023-09-28 17:07:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:07:21 --> Config Class Initialized
INFO - 2023-09-28 17:07:21 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:07:21 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:07:21 --> Utf8 Class Initialized
INFO - 2023-09-28 17:07:21 --> URI Class Initialized
INFO - 2023-09-28 17:07:21 --> Router Class Initialized
INFO - 2023-09-28 17:07:21 --> Output Class Initialized
INFO - 2023-09-28 17:07:21 --> Security Class Initialized
DEBUG - 2023-09-28 17:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:07:21 --> Input Class Initialized
INFO - 2023-09-28 17:07:21 --> Language Class Initialized
INFO - 2023-09-28 17:07:21 --> Loader Class Initialized
INFO - 2023-09-28 17:07:21 --> Helper loaded: url_helper
INFO - 2023-09-28 17:07:21 --> Helper loaded: file_helper
INFO - 2023-09-28 17:07:21 --> Helper loaded: html_helper
INFO - 2023-09-28 17:07:21 --> Helper loaded: text_helper
INFO - 2023-09-28 17:07:21 --> Helper loaded: form_helper
INFO - 2023-09-28 17:07:21 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:07:21 --> Helper loaded: security_helper
INFO - 2023-09-28 17:07:21 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:07:21 --> Database Driver Class Initialized
INFO - 2023-09-28 17:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:07:21 --> Parser Class Initialized
INFO - 2023-09-28 17:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:07:21 --> Pagination Class Initialized
INFO - 2023-09-28 17:07:21 --> Form Validation Class Initialized
INFO - 2023-09-28 17:07:21 --> Controller Class Initialized
INFO - 2023-09-28 17:07:21 --> Model Class Initialized
DEBUG - 2023-09-28 17:07:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:07:21 --> Model Class Initialized
DEBUG - 2023-09-28 17:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:07:21 --> Model Class Initialized
INFO - 2023-09-28 17:07:22 --> Final output sent to browser
DEBUG - 2023-09-28 17:07:22 --> Total execution time: 0.7703
ERROR - 2023-09-28 17:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:11:48 --> Config Class Initialized
INFO - 2023-09-28 17:11:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:11:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:11:48 --> Utf8 Class Initialized
INFO - 2023-09-28 17:11:48 --> URI Class Initialized
DEBUG - 2023-09-28 17:11:48 --> No URI present. Default controller set.
INFO - 2023-09-28 17:11:48 --> Router Class Initialized
INFO - 2023-09-28 17:11:48 --> Output Class Initialized
INFO - 2023-09-28 17:11:48 --> Security Class Initialized
DEBUG - 2023-09-28 17:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:11:48 --> Input Class Initialized
INFO - 2023-09-28 17:11:48 --> Language Class Initialized
INFO - 2023-09-28 17:11:48 --> Loader Class Initialized
INFO - 2023-09-28 17:11:48 --> Helper loaded: url_helper
INFO - 2023-09-28 17:11:48 --> Helper loaded: file_helper
INFO - 2023-09-28 17:11:48 --> Helper loaded: html_helper
INFO - 2023-09-28 17:11:48 --> Helper loaded: text_helper
INFO - 2023-09-28 17:11:48 --> Helper loaded: form_helper
INFO - 2023-09-28 17:11:48 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:11:48 --> Helper loaded: security_helper
INFO - 2023-09-28 17:11:48 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:11:48 --> Database Driver Class Initialized
INFO - 2023-09-28 17:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:11:48 --> Parser Class Initialized
INFO - 2023-09-28 17:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:11:48 --> Pagination Class Initialized
INFO - 2023-09-28 17:11:48 --> Form Validation Class Initialized
INFO - 2023-09-28 17:11:48 --> Controller Class Initialized
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
DEBUG - 2023-09-28 17:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
DEBUG - 2023-09-28 17:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
DEBUG - 2023-09-28 17:11:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
INFO - 2023-09-28 17:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:11:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:11:48 --> Model Class Initialized
INFO - 2023-09-28 17:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:11:48 --> Final output sent to browser
DEBUG - 2023-09-28 17:11:48 --> Total execution time: 0.2289
ERROR - 2023-09-28 17:12:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:12:04 --> Config Class Initialized
INFO - 2023-09-28 17:12:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:12:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:12:04 --> Utf8 Class Initialized
INFO - 2023-09-28 17:12:04 --> URI Class Initialized
INFO - 2023-09-28 17:12:04 --> Router Class Initialized
INFO - 2023-09-28 17:12:04 --> Output Class Initialized
INFO - 2023-09-28 17:12:04 --> Security Class Initialized
DEBUG - 2023-09-28 17:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:12:04 --> Input Class Initialized
INFO - 2023-09-28 17:12:04 --> Language Class Initialized
INFO - 2023-09-28 17:12:04 --> Loader Class Initialized
INFO - 2023-09-28 17:12:04 --> Helper loaded: url_helper
INFO - 2023-09-28 17:12:04 --> Helper loaded: file_helper
INFO - 2023-09-28 17:12:04 --> Helper loaded: html_helper
INFO - 2023-09-28 17:12:04 --> Helper loaded: text_helper
INFO - 2023-09-28 17:12:04 --> Helper loaded: form_helper
INFO - 2023-09-28 17:12:04 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:12:04 --> Helper loaded: security_helper
INFO - 2023-09-28 17:12:04 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:12:04 --> Database Driver Class Initialized
INFO - 2023-09-28 17:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:12:04 --> Parser Class Initialized
INFO - 2023-09-28 17:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:12:04 --> Pagination Class Initialized
INFO - 2023-09-28 17:12:04 --> Form Validation Class Initialized
INFO - 2023-09-28 17:12:04 --> Controller Class Initialized
INFO - 2023-09-28 17:12:04 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:04 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:04 --> Model Class Initialized
INFO - 2023-09-28 17:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:12:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:12:04 --> Model Class Initialized
INFO - 2023-09-28 17:12:04 --> Model Class Initialized
INFO - 2023-09-28 17:12:04 --> Model Class Initialized
INFO - 2023-09-28 17:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:12:04 --> Final output sent to browser
DEBUG - 2023-09-28 17:12:04 --> Total execution time: 0.3261
ERROR - 2023-09-28 17:12:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:12:05 --> Config Class Initialized
INFO - 2023-09-28 17:12:05 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:12:05 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:12:05 --> Utf8 Class Initialized
INFO - 2023-09-28 17:12:05 --> URI Class Initialized
INFO - 2023-09-28 17:12:05 --> Router Class Initialized
INFO - 2023-09-28 17:12:05 --> Output Class Initialized
INFO - 2023-09-28 17:12:05 --> Security Class Initialized
DEBUG - 2023-09-28 17:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:12:05 --> Input Class Initialized
INFO - 2023-09-28 17:12:05 --> Language Class Initialized
INFO - 2023-09-28 17:12:05 --> Loader Class Initialized
INFO - 2023-09-28 17:12:05 --> Helper loaded: url_helper
INFO - 2023-09-28 17:12:05 --> Helper loaded: file_helper
INFO - 2023-09-28 17:12:05 --> Helper loaded: html_helper
INFO - 2023-09-28 17:12:05 --> Helper loaded: text_helper
INFO - 2023-09-28 17:12:05 --> Helper loaded: form_helper
INFO - 2023-09-28 17:12:05 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:12:05 --> Helper loaded: security_helper
INFO - 2023-09-28 17:12:05 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:12:05 --> Database Driver Class Initialized
INFO - 2023-09-28 17:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:12:05 --> Parser Class Initialized
INFO - 2023-09-28 17:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:12:05 --> Pagination Class Initialized
INFO - 2023-09-28 17:12:05 --> Form Validation Class Initialized
INFO - 2023-09-28 17:12:05 --> Controller Class Initialized
INFO - 2023-09-28 17:12:05 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:05 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:05 --> Model Class Initialized
INFO - 2023-09-28 17:12:05 --> Final output sent to browser
DEBUG - 2023-09-28 17:12:05 --> Total execution time: 0.0536
ERROR - 2023-09-28 17:12:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:12:09 --> Config Class Initialized
INFO - 2023-09-28 17:12:09 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:12:09 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:12:09 --> Utf8 Class Initialized
INFO - 2023-09-28 17:12:09 --> URI Class Initialized
INFO - 2023-09-28 17:12:09 --> Router Class Initialized
INFO - 2023-09-28 17:12:09 --> Output Class Initialized
INFO - 2023-09-28 17:12:09 --> Security Class Initialized
DEBUG - 2023-09-28 17:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:12:09 --> Input Class Initialized
INFO - 2023-09-28 17:12:09 --> Language Class Initialized
INFO - 2023-09-28 17:12:09 --> Loader Class Initialized
INFO - 2023-09-28 17:12:09 --> Helper loaded: url_helper
INFO - 2023-09-28 17:12:09 --> Helper loaded: file_helper
INFO - 2023-09-28 17:12:09 --> Helper loaded: html_helper
INFO - 2023-09-28 17:12:09 --> Helper loaded: text_helper
INFO - 2023-09-28 17:12:09 --> Helper loaded: form_helper
INFO - 2023-09-28 17:12:09 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:12:09 --> Helper loaded: security_helper
INFO - 2023-09-28 17:12:09 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:12:09 --> Database Driver Class Initialized
INFO - 2023-09-28 17:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:12:09 --> Parser Class Initialized
INFO - 2023-09-28 17:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:12:09 --> Pagination Class Initialized
INFO - 2023-09-28 17:12:09 --> Form Validation Class Initialized
INFO - 2023-09-28 17:12:09 --> Controller Class Initialized
INFO - 2023-09-28 17:12:09 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:09 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:09 --> Model Class Initialized
INFO - 2023-09-28 17:12:09 --> Final output sent to browser
DEBUG - 2023-09-28 17:12:09 --> Total execution time: 0.7819
ERROR - 2023-09-28 17:12:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:12:12 --> Config Class Initialized
INFO - 2023-09-28 17:12:12 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:12:12 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:12:12 --> Utf8 Class Initialized
INFO - 2023-09-28 17:12:12 --> URI Class Initialized
DEBUG - 2023-09-28 17:12:12 --> No URI present. Default controller set.
INFO - 2023-09-28 17:12:12 --> Router Class Initialized
INFO - 2023-09-28 17:12:12 --> Output Class Initialized
INFO - 2023-09-28 17:12:12 --> Security Class Initialized
DEBUG - 2023-09-28 17:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:12:12 --> Input Class Initialized
INFO - 2023-09-28 17:12:12 --> Language Class Initialized
INFO - 2023-09-28 17:12:12 --> Loader Class Initialized
INFO - 2023-09-28 17:12:12 --> Helper loaded: url_helper
INFO - 2023-09-28 17:12:12 --> Helper loaded: file_helper
INFO - 2023-09-28 17:12:12 --> Helper loaded: html_helper
INFO - 2023-09-28 17:12:12 --> Helper loaded: text_helper
INFO - 2023-09-28 17:12:12 --> Helper loaded: form_helper
INFO - 2023-09-28 17:12:12 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:12:12 --> Helper loaded: security_helper
INFO - 2023-09-28 17:12:12 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:12:12 --> Database Driver Class Initialized
INFO - 2023-09-28 17:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:12:12 --> Parser Class Initialized
INFO - 2023-09-28 17:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:12:12 --> Pagination Class Initialized
INFO - 2023-09-28 17:12:12 --> Form Validation Class Initialized
INFO - 2023-09-28 17:12:12 --> Controller Class Initialized
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
INFO - 2023-09-28 17:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:12:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:12:12 --> Model Class Initialized
INFO - 2023-09-28 17:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:12:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:12:13 --> Final output sent to browser
DEBUG - 2023-09-28 17:12:13 --> Total execution time: 0.2432
ERROR - 2023-09-28 17:12:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:12:16 --> Config Class Initialized
INFO - 2023-09-28 17:12:16 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:12:16 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:12:16 --> Utf8 Class Initialized
INFO - 2023-09-28 17:12:16 --> URI Class Initialized
INFO - 2023-09-28 17:12:16 --> Router Class Initialized
INFO - 2023-09-28 17:12:16 --> Output Class Initialized
INFO - 2023-09-28 17:12:16 --> Security Class Initialized
DEBUG - 2023-09-28 17:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:12:16 --> Input Class Initialized
INFO - 2023-09-28 17:12:16 --> Language Class Initialized
INFO - 2023-09-28 17:12:16 --> Loader Class Initialized
INFO - 2023-09-28 17:12:16 --> Helper loaded: url_helper
INFO - 2023-09-28 17:12:16 --> Helper loaded: file_helper
INFO - 2023-09-28 17:12:16 --> Helper loaded: html_helper
INFO - 2023-09-28 17:12:16 --> Helper loaded: text_helper
INFO - 2023-09-28 17:12:16 --> Helper loaded: form_helper
INFO - 2023-09-28 17:12:16 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:12:16 --> Helper loaded: security_helper
INFO - 2023-09-28 17:12:16 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:12:16 --> Database Driver Class Initialized
INFO - 2023-09-28 17:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:12:16 --> Parser Class Initialized
INFO - 2023-09-28 17:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:12:16 --> Pagination Class Initialized
INFO - 2023-09-28 17:12:16 --> Form Validation Class Initialized
INFO - 2023-09-28 17:12:16 --> Controller Class Initialized
INFO - 2023-09-28 17:12:16 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:16 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:16 --> Model Class Initialized
INFO - 2023-09-28 17:12:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:12:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:12:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:12:17 --> Model Class Initialized
INFO - 2023-09-28 17:12:17 --> Model Class Initialized
INFO - 2023-09-28 17:12:17 --> Model Class Initialized
INFO - 2023-09-28 17:12:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:12:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:12:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:12:17 --> Final output sent to browser
DEBUG - 2023-09-28 17:12:17 --> Total execution time: 0.1546
ERROR - 2023-09-28 17:12:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:12:17 --> Config Class Initialized
INFO - 2023-09-28 17:12:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:12:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:12:17 --> Utf8 Class Initialized
INFO - 2023-09-28 17:12:17 --> URI Class Initialized
INFO - 2023-09-28 17:12:17 --> Router Class Initialized
INFO - 2023-09-28 17:12:17 --> Output Class Initialized
INFO - 2023-09-28 17:12:17 --> Security Class Initialized
DEBUG - 2023-09-28 17:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:12:17 --> Input Class Initialized
INFO - 2023-09-28 17:12:17 --> Language Class Initialized
INFO - 2023-09-28 17:12:17 --> Loader Class Initialized
INFO - 2023-09-28 17:12:17 --> Helper loaded: url_helper
INFO - 2023-09-28 17:12:17 --> Helper loaded: file_helper
INFO - 2023-09-28 17:12:17 --> Helper loaded: html_helper
INFO - 2023-09-28 17:12:17 --> Helper loaded: text_helper
INFO - 2023-09-28 17:12:17 --> Helper loaded: form_helper
INFO - 2023-09-28 17:12:17 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:12:17 --> Helper loaded: security_helper
INFO - 2023-09-28 17:12:17 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:12:17 --> Database Driver Class Initialized
INFO - 2023-09-28 17:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:12:17 --> Parser Class Initialized
INFO - 2023-09-28 17:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:12:17 --> Pagination Class Initialized
INFO - 2023-09-28 17:12:17 --> Form Validation Class Initialized
INFO - 2023-09-28 17:12:17 --> Controller Class Initialized
INFO - 2023-09-28 17:12:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:17 --> Model Class Initialized
DEBUG - 2023-09-28 17:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:12:17 --> Model Class Initialized
INFO - 2023-09-28 17:12:17 --> Final output sent to browser
DEBUG - 2023-09-28 17:12:17 --> Total execution time: 0.0507
ERROR - 2023-09-28 17:16:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:16:47 --> Config Class Initialized
INFO - 2023-09-28 17:16:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:16:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:16:47 --> Utf8 Class Initialized
INFO - 2023-09-28 17:16:47 --> URI Class Initialized
INFO - 2023-09-28 17:16:47 --> Router Class Initialized
INFO - 2023-09-28 17:16:47 --> Output Class Initialized
INFO - 2023-09-28 17:16:47 --> Security Class Initialized
DEBUG - 2023-09-28 17:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:16:47 --> Input Class Initialized
INFO - 2023-09-28 17:16:47 --> Language Class Initialized
INFO - 2023-09-28 17:16:47 --> Loader Class Initialized
INFO - 2023-09-28 17:16:47 --> Helper loaded: url_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: file_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: html_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: text_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: form_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: security_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:16:47 --> Database Driver Class Initialized
INFO - 2023-09-28 17:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:16:47 --> Parser Class Initialized
INFO - 2023-09-28 17:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:16:47 --> Pagination Class Initialized
INFO - 2023-09-28 17:16:47 --> Form Validation Class Initialized
INFO - 2023-09-28 17:16:47 --> Controller Class Initialized
INFO - 2023-09-28 17:16:47 --> Model Class Initialized
DEBUG - 2023-09-28 17:16:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:16:47 --> Model Class Initialized
INFO - 2023-09-28 17:16:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-09-28 17:16:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:16:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:16:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:16:47 --> Model Class Initialized
INFO - 2023-09-28 17:16:47 --> Model Class Initialized
INFO - 2023-09-28 17:16:47 --> Model Class Initialized
INFO - 2023-09-28 17:16:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:16:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:16:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:16:47 --> Final output sent to browser
DEBUG - 2023-09-28 17:16:47 --> Total execution time: 0.0809
ERROR - 2023-09-28 17:16:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:16:47 --> Config Class Initialized
INFO - 2023-09-28 17:16:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:16:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:16:47 --> Utf8 Class Initialized
INFO - 2023-09-28 17:16:47 --> URI Class Initialized
INFO - 2023-09-28 17:16:47 --> Router Class Initialized
INFO - 2023-09-28 17:16:47 --> Output Class Initialized
INFO - 2023-09-28 17:16:47 --> Security Class Initialized
DEBUG - 2023-09-28 17:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:16:47 --> Input Class Initialized
INFO - 2023-09-28 17:16:47 --> Language Class Initialized
INFO - 2023-09-28 17:16:47 --> Loader Class Initialized
INFO - 2023-09-28 17:16:47 --> Helper loaded: url_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: file_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: html_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: text_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: form_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: security_helper
INFO - 2023-09-28 17:16:47 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:16:47 --> Database Driver Class Initialized
INFO - 2023-09-28 17:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:16:47 --> Parser Class Initialized
INFO - 2023-09-28 17:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:16:47 --> Pagination Class Initialized
INFO - 2023-09-28 17:16:47 --> Form Validation Class Initialized
INFO - 2023-09-28 17:16:47 --> Controller Class Initialized
INFO - 2023-09-28 17:16:47 --> Model Class Initialized
DEBUG - 2023-09-28 17:16:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:16:47 --> Model Class Initialized
INFO - 2023-09-28 17:16:47 --> Final output sent to browser
DEBUG - 2023-09-28 17:16:47 --> Total execution time: 0.0391
ERROR - 2023-09-28 17:16:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:16:54 --> Config Class Initialized
INFO - 2023-09-28 17:16:54 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:16:54 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:16:54 --> Utf8 Class Initialized
INFO - 2023-09-28 17:16:54 --> URI Class Initialized
INFO - 2023-09-28 17:16:54 --> Router Class Initialized
INFO - 2023-09-28 17:16:54 --> Output Class Initialized
INFO - 2023-09-28 17:16:54 --> Security Class Initialized
DEBUG - 2023-09-28 17:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:16:54 --> Input Class Initialized
INFO - 2023-09-28 17:16:54 --> Language Class Initialized
INFO - 2023-09-28 17:16:54 --> Loader Class Initialized
INFO - 2023-09-28 17:16:54 --> Helper loaded: url_helper
INFO - 2023-09-28 17:16:54 --> Helper loaded: file_helper
INFO - 2023-09-28 17:16:54 --> Helper loaded: html_helper
INFO - 2023-09-28 17:16:54 --> Helper loaded: text_helper
INFO - 2023-09-28 17:16:54 --> Helper loaded: form_helper
INFO - 2023-09-28 17:16:54 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:16:54 --> Helper loaded: security_helper
INFO - 2023-09-28 17:16:54 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:16:54 --> Database Driver Class Initialized
INFO - 2023-09-28 17:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:16:54 --> Parser Class Initialized
INFO - 2023-09-28 17:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:16:54 --> Pagination Class Initialized
INFO - 2023-09-28 17:16:54 --> Form Validation Class Initialized
INFO - 2023-09-28 17:16:54 --> Controller Class Initialized
INFO - 2023-09-28 17:16:54 --> Model Class Initialized
DEBUG - 2023-09-28 17:16:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:16:54 --> Model Class Initialized
INFO - 2023-09-28 17:16:54 --> Final output sent to browser
DEBUG - 2023-09-28 17:16:54 --> Total execution time: 0.0341
ERROR - 2023-09-28 17:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:41 --> Config Class Initialized
INFO - 2023-09-28 17:35:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:41 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:41 --> URI Class Initialized
DEBUG - 2023-09-28 17:35:41 --> No URI present. Default controller set.
INFO - 2023-09-28 17:35:41 --> Router Class Initialized
INFO - 2023-09-28 17:35:41 --> Output Class Initialized
INFO - 2023-09-28 17:35:41 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:41 --> Input Class Initialized
INFO - 2023-09-28 17:35:41 --> Language Class Initialized
INFO - 2023-09-28 17:35:41 --> Loader Class Initialized
INFO - 2023-09-28 17:35:41 --> Helper loaded: url_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: file_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: html_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: text_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: form_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: security_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:35:41 --> Database Driver Class Initialized
INFO - 2023-09-28 17:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:35:41 --> Parser Class Initialized
INFO - 2023-09-28 17:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:35:41 --> Pagination Class Initialized
INFO - 2023-09-28 17:35:41 --> Form Validation Class Initialized
INFO - 2023-09-28 17:35:41 --> Controller Class Initialized
INFO - 2023-09-28 17:35:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:35:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 17:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:41 --> Config Class Initialized
INFO - 2023-09-28 17:35:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:41 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:41 --> URI Class Initialized
INFO - 2023-09-28 17:35:41 --> Router Class Initialized
INFO - 2023-09-28 17:35:41 --> Output Class Initialized
INFO - 2023-09-28 17:35:41 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:41 --> Input Class Initialized
INFO - 2023-09-28 17:35:41 --> Language Class Initialized
ERROR - 2023-09-28 17:35:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-09-28 17:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:41 --> Config Class Initialized
INFO - 2023-09-28 17:35:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:41 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:41 --> URI Class Initialized
INFO - 2023-09-28 17:35:41 --> Router Class Initialized
INFO - 2023-09-28 17:35:41 --> Output Class Initialized
INFO - 2023-09-28 17:35:41 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:41 --> Input Class Initialized
INFO - 2023-09-28 17:35:41 --> Language Class Initialized
ERROR - 2023-09-28 17:35:41 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-28 17:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:41 --> Config Class Initialized
INFO - 2023-09-28 17:35:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:41 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:41 --> URI Class Initialized
DEBUG - 2023-09-28 17:35:41 --> No URI present. Default controller set.
INFO - 2023-09-28 17:35:41 --> Router Class Initialized
INFO - 2023-09-28 17:35:41 --> Output Class Initialized
INFO - 2023-09-28 17:35:41 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:41 --> Input Class Initialized
INFO - 2023-09-28 17:35:41 --> Language Class Initialized
INFO - 2023-09-28 17:35:41 --> Loader Class Initialized
INFO - 2023-09-28 17:35:41 --> Helper loaded: url_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: file_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: html_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: text_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: form_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: security_helper
INFO - 2023-09-28 17:35:41 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:35:41 --> Database Driver Class Initialized
INFO - 2023-09-28 17:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:35:41 --> Parser Class Initialized
INFO - 2023-09-28 17:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:35:41 --> Pagination Class Initialized
INFO - 2023-09-28 17:35:41 --> Form Validation Class Initialized
INFO - 2023-09-28 17:35:41 --> Controller Class Initialized
INFO - 2023-09-28 17:35:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:35:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-28 17:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:42 --> Config Class Initialized
INFO - 2023-09-28 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:42 --> URI Class Initialized
INFO - 2023-09-28 17:35:42 --> Router Class Initialized
INFO - 2023-09-28 17:35:42 --> Output Class Initialized
INFO - 2023-09-28 17:35:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:42 --> Input Class Initialized
INFO - 2023-09-28 17:35:42 --> Language Class Initialized
ERROR - 2023-09-28 17:35:42 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-09-28 17:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:42 --> Config Class Initialized
INFO - 2023-09-28 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:42 --> URI Class Initialized
INFO - 2023-09-28 17:35:42 --> Router Class Initialized
INFO - 2023-09-28 17:35:42 --> Output Class Initialized
INFO - 2023-09-28 17:35:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:42 --> Input Class Initialized
INFO - 2023-09-28 17:35:42 --> Language Class Initialized
ERROR - 2023-09-28 17:35:42 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-09-28 17:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:42 --> Config Class Initialized
INFO - 2023-09-28 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:42 --> URI Class Initialized
INFO - 2023-09-28 17:35:42 --> Router Class Initialized
INFO - 2023-09-28 17:35:42 --> Output Class Initialized
INFO - 2023-09-28 17:35:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:42 --> Input Class Initialized
INFO - 2023-09-28 17:35:42 --> Language Class Initialized
ERROR - 2023-09-28 17:35:42 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-09-28 17:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:42 --> Config Class Initialized
INFO - 2023-09-28 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:42 --> URI Class Initialized
INFO - 2023-09-28 17:35:42 --> Router Class Initialized
INFO - 2023-09-28 17:35:42 --> Output Class Initialized
INFO - 2023-09-28 17:35:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:42 --> Input Class Initialized
INFO - 2023-09-28 17:35:42 --> Language Class Initialized
ERROR - 2023-09-28 17:35:42 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-09-28 17:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:42 --> Config Class Initialized
INFO - 2023-09-28 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:42 --> URI Class Initialized
INFO - 2023-09-28 17:35:42 --> Router Class Initialized
INFO - 2023-09-28 17:35:42 --> Output Class Initialized
INFO - 2023-09-28 17:35:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:42 --> Input Class Initialized
INFO - 2023-09-28 17:35:42 --> Language Class Initialized
ERROR - 2023-09-28 17:35:42 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-09-28 17:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:42 --> Config Class Initialized
INFO - 2023-09-28 17:35:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:42 --> URI Class Initialized
INFO - 2023-09-28 17:35:42 --> Router Class Initialized
INFO - 2023-09-28 17:35:42 --> Output Class Initialized
INFO - 2023-09-28 17:35:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:42 --> Input Class Initialized
INFO - 2023-09-28 17:35:42 --> Language Class Initialized
ERROR - 2023-09-28 17:35:42 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-09-28 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:43 --> Config Class Initialized
INFO - 2023-09-28 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:43 --> URI Class Initialized
INFO - 2023-09-28 17:35:43 --> Router Class Initialized
INFO - 2023-09-28 17:35:43 --> Output Class Initialized
INFO - 2023-09-28 17:35:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:43 --> Input Class Initialized
INFO - 2023-09-28 17:35:43 --> Language Class Initialized
ERROR - 2023-09-28 17:35:43 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-09-28 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:43 --> Config Class Initialized
INFO - 2023-09-28 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:43 --> URI Class Initialized
INFO - 2023-09-28 17:35:43 --> Router Class Initialized
INFO - 2023-09-28 17:35:43 --> Output Class Initialized
INFO - 2023-09-28 17:35:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:43 --> Input Class Initialized
INFO - 2023-09-28 17:35:43 --> Language Class Initialized
ERROR - 2023-09-28 17:35:43 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-09-28 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:43 --> Config Class Initialized
INFO - 2023-09-28 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:43 --> URI Class Initialized
INFO - 2023-09-28 17:35:43 --> Router Class Initialized
INFO - 2023-09-28 17:35:43 --> Output Class Initialized
INFO - 2023-09-28 17:35:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:43 --> Input Class Initialized
INFO - 2023-09-28 17:35:43 --> Language Class Initialized
ERROR - 2023-09-28 17:35:43 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-09-28 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:43 --> Config Class Initialized
INFO - 2023-09-28 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:43 --> URI Class Initialized
INFO - 2023-09-28 17:35:43 --> Router Class Initialized
INFO - 2023-09-28 17:35:43 --> Output Class Initialized
INFO - 2023-09-28 17:35:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:43 --> Input Class Initialized
INFO - 2023-09-28 17:35:43 --> Language Class Initialized
ERROR - 2023-09-28 17:35:43 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-09-28 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:43 --> Config Class Initialized
INFO - 2023-09-28 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:43 --> URI Class Initialized
INFO - 2023-09-28 17:35:43 --> Router Class Initialized
INFO - 2023-09-28 17:35:43 --> Output Class Initialized
INFO - 2023-09-28 17:35:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:43 --> Input Class Initialized
INFO - 2023-09-28 17:35:43 --> Language Class Initialized
ERROR - 2023-09-28 17:35:43 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-09-28 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:43 --> Config Class Initialized
INFO - 2023-09-28 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:43 --> URI Class Initialized
INFO - 2023-09-28 17:35:43 --> Router Class Initialized
INFO - 2023-09-28 17:35:43 --> Output Class Initialized
INFO - 2023-09-28 17:35:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:43 --> Input Class Initialized
INFO - 2023-09-28 17:35:43 --> Language Class Initialized
ERROR - 2023-09-28 17:35:43 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-09-28 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:43 --> Config Class Initialized
INFO - 2023-09-28 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:43 --> URI Class Initialized
INFO - 2023-09-28 17:35:43 --> Router Class Initialized
INFO - 2023-09-28 17:35:43 --> Output Class Initialized
INFO - 2023-09-28 17:35:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:43 --> Input Class Initialized
INFO - 2023-09-28 17:35:43 --> Language Class Initialized
ERROR - 2023-09-28 17:35:43 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-09-28 17:35:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:44 --> Config Class Initialized
INFO - 2023-09-28 17:35:44 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:44 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:44 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:44 --> URI Class Initialized
INFO - 2023-09-28 17:35:44 --> Router Class Initialized
INFO - 2023-09-28 17:35:44 --> Output Class Initialized
INFO - 2023-09-28 17:35:44 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:44 --> Input Class Initialized
INFO - 2023-09-28 17:35:44 --> Language Class Initialized
ERROR - 2023-09-28 17:35:44 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-09-28 17:35:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:35:44 --> Config Class Initialized
INFO - 2023-09-28 17:35:44 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:35:44 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:35:44 --> Utf8 Class Initialized
INFO - 2023-09-28 17:35:44 --> URI Class Initialized
INFO - 2023-09-28 17:35:44 --> Router Class Initialized
INFO - 2023-09-28 17:35:44 --> Output Class Initialized
INFO - 2023-09-28 17:35:44 --> Security Class Initialized
DEBUG - 2023-09-28 17:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:35:44 --> Input Class Initialized
INFO - 2023-09-28 17:35:44 --> Language Class Initialized
ERROR - 2023-09-28 17:35:44 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-09-28 17:43:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:22 --> Config Class Initialized
INFO - 2023-09-28 17:43:22 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:22 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:22 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:22 --> URI Class Initialized
DEBUG - 2023-09-28 17:43:22 --> No URI present. Default controller set.
INFO - 2023-09-28 17:43:22 --> Router Class Initialized
INFO - 2023-09-28 17:43:22 --> Output Class Initialized
INFO - 2023-09-28 17:43:22 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:22 --> Input Class Initialized
INFO - 2023-09-28 17:43:22 --> Language Class Initialized
INFO - 2023-09-28 17:43:22 --> Loader Class Initialized
INFO - 2023-09-28 17:43:22 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:22 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:22 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:22 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:22 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:22 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:22 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:22 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:22 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:22 --> Parser Class Initialized
INFO - 2023-09-28 17:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:22 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:22 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:22 --> Controller Class Initialized
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
INFO - 2023-09-28 17:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:43:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:43:22 --> Model Class Initialized
INFO - 2023-09-28 17:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:43:22 --> Final output sent to browser
DEBUG - 2023-09-28 17:43:22 --> Total execution time: 0.1088
ERROR - 2023-09-28 17:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:30 --> Config Class Initialized
INFO - 2023-09-28 17:43:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:30 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:30 --> URI Class Initialized
DEBUG - 2023-09-28 17:43:30 --> No URI present. Default controller set.
INFO - 2023-09-28 17:43:30 --> Router Class Initialized
INFO - 2023-09-28 17:43:30 --> Output Class Initialized
INFO - 2023-09-28 17:43:30 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:30 --> Input Class Initialized
INFO - 2023-09-28 17:43:30 --> Language Class Initialized
INFO - 2023-09-28 17:43:30 --> Loader Class Initialized
INFO - 2023-09-28 17:43:30 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:30 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:30 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:30 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:30 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:30 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:30 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:30 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:30 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:30 --> Parser Class Initialized
INFO - 2023-09-28 17:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:30 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:30 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:30 --> Controller Class Initialized
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
INFO - 2023-09-28 17:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:43:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:43:30 --> Model Class Initialized
INFO - 2023-09-28 17:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:43:30 --> Final output sent to browser
DEBUG - 2023-09-28 17:43:30 --> Total execution time: 0.2112
ERROR - 2023-09-28 17:43:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:40 --> Config Class Initialized
INFO - 2023-09-28 17:43:40 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:40 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:40 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:40 --> URI Class Initialized
INFO - 2023-09-28 17:43:40 --> Router Class Initialized
INFO - 2023-09-28 17:43:40 --> Output Class Initialized
INFO - 2023-09-28 17:43:40 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:40 --> Input Class Initialized
INFO - 2023-09-28 17:43:40 --> Language Class Initialized
INFO - 2023-09-28 17:43:40 --> Loader Class Initialized
INFO - 2023-09-28 17:43:40 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:40 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:40 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:40 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:40 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:40 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:40 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:40 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:40 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:40 --> Parser Class Initialized
INFO - 2023-09-28 17:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:40 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:40 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:40 --> Controller Class Initialized
INFO - 2023-09-28 17:43:40 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:40 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:40 --> Model Class Initialized
INFO - 2023-09-28 17:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:43:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:43:40 --> Model Class Initialized
INFO - 2023-09-28 17:43:40 --> Model Class Initialized
INFO - 2023-09-28 17:43:40 --> Model Class Initialized
INFO - 2023-09-28 17:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:43:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:43:40 --> Final output sent to browser
DEBUG - 2023-09-28 17:43:40 --> Total execution time: 0.1395
ERROR - 2023-09-28 17:43:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:41 --> Config Class Initialized
INFO - 2023-09-28 17:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:41 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:41 --> URI Class Initialized
INFO - 2023-09-28 17:43:41 --> Router Class Initialized
INFO - 2023-09-28 17:43:41 --> Output Class Initialized
INFO - 2023-09-28 17:43:41 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:41 --> Input Class Initialized
INFO - 2023-09-28 17:43:41 --> Language Class Initialized
INFO - 2023-09-28 17:43:41 --> Loader Class Initialized
INFO - 2023-09-28 17:43:41 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:41 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:41 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:41 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:41 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:41 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:41 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:41 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:41 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:41 --> Parser Class Initialized
INFO - 2023-09-28 17:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:41 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:41 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:41 --> Controller Class Initialized
INFO - 2023-09-28 17:43:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:41 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:41 --> Model Class Initialized
INFO - 2023-09-28 17:43:41 --> Final output sent to browser
DEBUG - 2023-09-28 17:43:41 --> Total execution time: 0.0506
ERROR - 2023-09-28 17:43:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:45 --> Config Class Initialized
INFO - 2023-09-28 17:43:45 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:45 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:45 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:45 --> URI Class Initialized
INFO - 2023-09-28 17:43:45 --> Router Class Initialized
INFO - 2023-09-28 17:43:45 --> Output Class Initialized
INFO - 2023-09-28 17:43:45 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:45 --> Input Class Initialized
INFO - 2023-09-28 17:43:45 --> Language Class Initialized
INFO - 2023-09-28 17:43:45 --> Loader Class Initialized
INFO - 2023-09-28 17:43:45 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:45 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:45 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:45 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:45 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:45 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:45 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:45 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:45 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:45 --> Parser Class Initialized
INFO - 2023-09-28 17:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:45 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:45 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:45 --> Controller Class Initialized
INFO - 2023-09-28 17:43:45 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:45 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:45 --> Model Class Initialized
INFO - 2023-09-28 17:43:46 --> Final output sent to browser
DEBUG - 2023-09-28 17:43:46 --> Total execution time: 0.7723
ERROR - 2023-09-28 17:43:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:51 --> Config Class Initialized
INFO - 2023-09-28 17:43:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:51 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:51 --> URI Class Initialized
DEBUG - 2023-09-28 17:43:51 --> No URI present. Default controller set.
INFO - 2023-09-28 17:43:51 --> Router Class Initialized
INFO - 2023-09-28 17:43:51 --> Output Class Initialized
INFO - 2023-09-28 17:43:51 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:51 --> Input Class Initialized
INFO - 2023-09-28 17:43:51 --> Language Class Initialized
INFO - 2023-09-28 17:43:51 --> Loader Class Initialized
INFO - 2023-09-28 17:43:51 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:51 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:51 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:51 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:51 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:51 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:51 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:51 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:51 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:51 --> Parser Class Initialized
INFO - 2023-09-28 17:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:51 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:51 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:51 --> Controller Class Initialized
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
INFO - 2023-09-28 17:43:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 17:43:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:43:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:43:51 --> Model Class Initialized
INFO - 2023-09-28 17:43:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:43:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:43:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:43:51 --> Final output sent to browser
DEBUG - 2023-09-28 17:43:51 --> Total execution time: 0.2006
ERROR - 2023-09-28 17:43:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:59 --> Config Class Initialized
INFO - 2023-09-28 17:43:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:59 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:59 --> URI Class Initialized
INFO - 2023-09-28 17:43:59 --> Router Class Initialized
INFO - 2023-09-28 17:43:59 --> Output Class Initialized
INFO - 2023-09-28 17:43:59 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:59 --> Input Class Initialized
INFO - 2023-09-28 17:43:59 --> Language Class Initialized
INFO - 2023-09-28 17:43:59 --> Loader Class Initialized
INFO - 2023-09-28 17:43:59 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:59 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:59 --> Parser Class Initialized
INFO - 2023-09-28 17:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:59 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:59 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:59 --> Controller Class Initialized
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:43:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:43:59 --> Final output sent to browser
DEBUG - 2023-09-28 17:43:59 --> Total execution time: 0.1449
ERROR - 2023-09-28 17:43:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:43:59 --> Config Class Initialized
INFO - 2023-09-28 17:43:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:43:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:43:59 --> Utf8 Class Initialized
INFO - 2023-09-28 17:43:59 --> URI Class Initialized
INFO - 2023-09-28 17:43:59 --> Router Class Initialized
INFO - 2023-09-28 17:43:59 --> Output Class Initialized
INFO - 2023-09-28 17:43:59 --> Security Class Initialized
DEBUG - 2023-09-28 17:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:43:59 --> Input Class Initialized
INFO - 2023-09-28 17:43:59 --> Language Class Initialized
INFO - 2023-09-28 17:43:59 --> Loader Class Initialized
INFO - 2023-09-28 17:43:59 --> Helper loaded: url_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: file_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: html_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: text_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: form_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: security_helper
INFO - 2023-09-28 17:43:59 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:43:59 --> Database Driver Class Initialized
INFO - 2023-09-28 17:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:43:59 --> Parser Class Initialized
INFO - 2023-09-28 17:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:43:59 --> Pagination Class Initialized
INFO - 2023-09-28 17:43:59 --> Form Validation Class Initialized
INFO - 2023-09-28 17:43:59 --> Controller Class Initialized
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
DEBUG - 2023-09-28 17:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:59 --> Model Class Initialized
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:43:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:43:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:44:00 --> Model Class Initialized
INFO - 2023-09-28 17:44:00 --> Model Class Initialized
INFO - 2023-09-28 17:44:00 --> Model Class Initialized
INFO - 2023-09-28 17:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:44:00 --> Final output sent to browser
DEBUG - 2023-09-28 17:44:00 --> Total execution time: 0.1510
ERROR - 2023-09-28 17:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:44:00 --> Config Class Initialized
INFO - 2023-09-28 17:44:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:44:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:44:00 --> Utf8 Class Initialized
INFO - 2023-09-28 17:44:00 --> URI Class Initialized
INFO - 2023-09-28 17:44:00 --> Router Class Initialized
INFO - 2023-09-28 17:44:00 --> Output Class Initialized
INFO - 2023-09-28 17:44:00 --> Security Class Initialized
DEBUG - 2023-09-28 17:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:44:00 --> Input Class Initialized
INFO - 2023-09-28 17:44:00 --> Language Class Initialized
INFO - 2023-09-28 17:44:00 --> Loader Class Initialized
INFO - 2023-09-28 17:44:00 --> Helper loaded: url_helper
INFO - 2023-09-28 17:44:00 --> Helper loaded: file_helper
INFO - 2023-09-28 17:44:00 --> Helper loaded: html_helper
INFO - 2023-09-28 17:44:00 --> Helper loaded: text_helper
INFO - 2023-09-28 17:44:00 --> Helper loaded: form_helper
INFO - 2023-09-28 17:44:00 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:44:00 --> Helper loaded: security_helper
INFO - 2023-09-28 17:44:00 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:44:00 --> Database Driver Class Initialized
INFO - 2023-09-28 17:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:44:00 --> Parser Class Initialized
INFO - 2023-09-28 17:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:44:00 --> Pagination Class Initialized
INFO - 2023-09-28 17:44:00 --> Form Validation Class Initialized
INFO - 2023-09-28 17:44:00 --> Controller Class Initialized
INFO - 2023-09-28 17:44:00 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:00 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:00 --> Model Class Initialized
INFO - 2023-09-28 17:44:00 --> Final output sent to browser
DEBUG - 2023-09-28 17:44:00 --> Total execution time: 0.0503
ERROR - 2023-09-28 17:44:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:44:04 --> Config Class Initialized
INFO - 2023-09-28 17:44:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:44:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:44:04 --> Utf8 Class Initialized
INFO - 2023-09-28 17:44:04 --> URI Class Initialized
INFO - 2023-09-28 17:44:04 --> Router Class Initialized
INFO - 2023-09-28 17:44:04 --> Output Class Initialized
INFO - 2023-09-28 17:44:04 --> Security Class Initialized
DEBUG - 2023-09-28 17:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:44:04 --> Input Class Initialized
INFO - 2023-09-28 17:44:04 --> Language Class Initialized
INFO - 2023-09-28 17:44:04 --> Loader Class Initialized
INFO - 2023-09-28 17:44:04 --> Helper loaded: url_helper
INFO - 2023-09-28 17:44:04 --> Helper loaded: file_helper
INFO - 2023-09-28 17:44:04 --> Helper loaded: html_helper
INFO - 2023-09-28 17:44:04 --> Helper loaded: text_helper
INFO - 2023-09-28 17:44:04 --> Helper loaded: form_helper
INFO - 2023-09-28 17:44:04 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:44:04 --> Helper loaded: security_helper
INFO - 2023-09-28 17:44:04 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:44:04 --> Database Driver Class Initialized
INFO - 2023-09-28 17:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:44:04 --> Parser Class Initialized
INFO - 2023-09-28 17:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:44:04 --> Pagination Class Initialized
INFO - 2023-09-28 17:44:04 --> Form Validation Class Initialized
INFO - 2023-09-28 17:44:04 --> Controller Class Initialized
INFO - 2023-09-28 17:44:04 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:04 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:04 --> Model Class Initialized
INFO - 2023-09-28 17:44:05 --> Final output sent to browser
DEBUG - 2023-09-28 17:44:05 --> Total execution time: 0.8664
ERROR - 2023-09-28 17:44:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:44:42 --> Config Class Initialized
INFO - 2023-09-28 17:44:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:44:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:44:42 --> Utf8 Class Initialized
INFO - 2023-09-28 17:44:42 --> URI Class Initialized
INFO - 2023-09-28 17:44:42 --> Router Class Initialized
INFO - 2023-09-28 17:44:42 --> Output Class Initialized
INFO - 2023-09-28 17:44:42 --> Security Class Initialized
DEBUG - 2023-09-28 17:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:44:42 --> Input Class Initialized
INFO - 2023-09-28 17:44:42 --> Language Class Initialized
INFO - 2023-09-28 17:44:42 --> Loader Class Initialized
INFO - 2023-09-28 17:44:42 --> Helper loaded: url_helper
INFO - 2023-09-28 17:44:42 --> Helper loaded: file_helper
INFO - 2023-09-28 17:44:42 --> Helper loaded: html_helper
INFO - 2023-09-28 17:44:42 --> Helper loaded: text_helper
INFO - 2023-09-28 17:44:42 --> Helper loaded: form_helper
INFO - 2023-09-28 17:44:42 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:44:42 --> Helper loaded: security_helper
INFO - 2023-09-28 17:44:42 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:44:42 --> Database Driver Class Initialized
INFO - 2023-09-28 17:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:44:42 --> Parser Class Initialized
INFO - 2023-09-28 17:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:44:42 --> Pagination Class Initialized
INFO - 2023-09-28 17:44:42 --> Form Validation Class Initialized
INFO - 2023-09-28 17:44:42 --> Controller Class Initialized
INFO - 2023-09-28 17:44:42 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:42 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:42 --> Model Class Initialized
INFO - 2023-09-28 17:44:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-28 17:44:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 17:44:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 17:44:42 --> Model Class Initialized
INFO - 2023-09-28 17:44:42 --> Model Class Initialized
INFO - 2023-09-28 17:44:42 --> Model Class Initialized
INFO - 2023-09-28 17:44:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 17:44:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 17:44:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 17:44:42 --> Final output sent to browser
DEBUG - 2023-09-28 17:44:42 --> Total execution time: 0.1522
ERROR - 2023-09-28 17:44:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:44:43 --> Config Class Initialized
INFO - 2023-09-28 17:44:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:44:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:44:43 --> Utf8 Class Initialized
INFO - 2023-09-28 17:44:43 --> URI Class Initialized
INFO - 2023-09-28 17:44:43 --> Router Class Initialized
INFO - 2023-09-28 17:44:43 --> Output Class Initialized
INFO - 2023-09-28 17:44:43 --> Security Class Initialized
DEBUG - 2023-09-28 17:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:44:43 --> Input Class Initialized
INFO - 2023-09-28 17:44:43 --> Language Class Initialized
INFO - 2023-09-28 17:44:43 --> Loader Class Initialized
INFO - 2023-09-28 17:44:43 --> Helper loaded: url_helper
INFO - 2023-09-28 17:44:43 --> Helper loaded: file_helper
INFO - 2023-09-28 17:44:43 --> Helper loaded: html_helper
INFO - 2023-09-28 17:44:43 --> Helper loaded: text_helper
INFO - 2023-09-28 17:44:43 --> Helper loaded: form_helper
INFO - 2023-09-28 17:44:43 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:44:43 --> Helper loaded: security_helper
INFO - 2023-09-28 17:44:43 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:44:43 --> Database Driver Class Initialized
INFO - 2023-09-28 17:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:44:43 --> Parser Class Initialized
INFO - 2023-09-28 17:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:44:43 --> Pagination Class Initialized
INFO - 2023-09-28 17:44:43 --> Form Validation Class Initialized
INFO - 2023-09-28 17:44:43 --> Controller Class Initialized
INFO - 2023-09-28 17:44:43 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:43 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:43 --> Model Class Initialized
INFO - 2023-09-28 17:44:43 --> Final output sent to browser
DEBUG - 2023-09-28 17:44:43 --> Total execution time: 0.0518
ERROR - 2023-09-28 17:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 17:44:47 --> Config Class Initialized
INFO - 2023-09-28 17:44:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 17:44:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 17:44:47 --> Utf8 Class Initialized
INFO - 2023-09-28 17:44:47 --> URI Class Initialized
INFO - 2023-09-28 17:44:47 --> Router Class Initialized
INFO - 2023-09-28 17:44:47 --> Output Class Initialized
INFO - 2023-09-28 17:44:47 --> Security Class Initialized
DEBUG - 2023-09-28 17:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 17:44:47 --> Input Class Initialized
INFO - 2023-09-28 17:44:47 --> Language Class Initialized
INFO - 2023-09-28 17:44:47 --> Loader Class Initialized
INFO - 2023-09-28 17:44:47 --> Helper loaded: url_helper
INFO - 2023-09-28 17:44:47 --> Helper loaded: file_helper
INFO - 2023-09-28 17:44:47 --> Helper loaded: html_helper
INFO - 2023-09-28 17:44:47 --> Helper loaded: text_helper
INFO - 2023-09-28 17:44:47 --> Helper loaded: form_helper
INFO - 2023-09-28 17:44:47 --> Helper loaded: lang_helper
INFO - 2023-09-28 17:44:47 --> Helper loaded: security_helper
INFO - 2023-09-28 17:44:47 --> Helper loaded: cookie_helper
INFO - 2023-09-28 17:44:47 --> Database Driver Class Initialized
INFO - 2023-09-28 17:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 17:44:47 --> Parser Class Initialized
INFO - 2023-09-28 17:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 17:44:47 --> Pagination Class Initialized
INFO - 2023-09-28 17:44:47 --> Form Validation Class Initialized
INFO - 2023-09-28 17:44:47 --> Controller Class Initialized
INFO - 2023-09-28 17:44:47 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 17:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:47 --> Model Class Initialized
DEBUG - 2023-09-28 17:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 17:44:47 --> Model Class Initialized
INFO - 2023-09-28 17:44:48 --> Final output sent to browser
DEBUG - 2023-09-28 17:44:48 --> Total execution time: 0.7452
ERROR - 2023-09-28 18:14:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 18:14:32 --> Config Class Initialized
INFO - 2023-09-28 18:14:32 --> Hooks Class Initialized
DEBUG - 2023-09-28 18:14:32 --> UTF-8 Support Enabled
INFO - 2023-09-28 18:14:32 --> Utf8 Class Initialized
INFO - 2023-09-28 18:14:32 --> URI Class Initialized
DEBUG - 2023-09-28 18:14:32 --> No URI present. Default controller set.
INFO - 2023-09-28 18:14:32 --> Router Class Initialized
INFO - 2023-09-28 18:14:32 --> Output Class Initialized
INFO - 2023-09-28 18:14:32 --> Security Class Initialized
DEBUG - 2023-09-28 18:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 18:14:32 --> Input Class Initialized
INFO - 2023-09-28 18:14:32 --> Language Class Initialized
INFO - 2023-09-28 18:14:32 --> Loader Class Initialized
INFO - 2023-09-28 18:14:32 --> Helper loaded: url_helper
INFO - 2023-09-28 18:14:32 --> Helper loaded: file_helper
INFO - 2023-09-28 18:14:32 --> Helper loaded: html_helper
INFO - 2023-09-28 18:14:32 --> Helper loaded: text_helper
INFO - 2023-09-28 18:14:32 --> Helper loaded: form_helper
INFO - 2023-09-28 18:14:32 --> Helper loaded: lang_helper
INFO - 2023-09-28 18:14:32 --> Helper loaded: security_helper
INFO - 2023-09-28 18:14:32 --> Helper loaded: cookie_helper
INFO - 2023-09-28 18:14:32 --> Database Driver Class Initialized
INFO - 2023-09-28 18:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 18:14:32 --> Parser Class Initialized
INFO - 2023-09-28 18:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 18:14:32 --> Pagination Class Initialized
INFO - 2023-09-28 18:14:32 --> Form Validation Class Initialized
INFO - 2023-09-28 18:14:32 --> Controller Class Initialized
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
DEBUG - 2023-09-28 18:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
DEBUG - 2023-09-28 18:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
DEBUG - 2023-09-28 18:14:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 18:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
INFO - 2023-09-28 18:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-28 18:14:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 18:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 18:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 18:14:32 --> Model Class Initialized
INFO - 2023-09-28 18:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 18:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 18:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 18:14:32 --> Final output sent to browser
DEBUG - 2023-09-28 18:14:32 --> Total execution time: 0.2185
ERROR - 2023-09-28 19:31:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 19:31:38 --> Config Class Initialized
INFO - 2023-09-28 19:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 19:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 19:31:38 --> Utf8 Class Initialized
INFO - 2023-09-28 19:31:38 --> URI Class Initialized
INFO - 2023-09-28 19:31:38 --> Router Class Initialized
INFO - 2023-09-28 19:31:38 --> Output Class Initialized
INFO - 2023-09-28 19:31:38 --> Security Class Initialized
DEBUG - 2023-09-28 19:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 19:31:38 --> Input Class Initialized
INFO - 2023-09-28 19:31:38 --> Language Class Initialized
INFO - 2023-09-28 19:31:38 --> Loader Class Initialized
INFO - 2023-09-28 19:31:38 --> Helper loaded: url_helper
INFO - 2023-09-28 19:31:38 --> Helper loaded: file_helper
INFO - 2023-09-28 19:31:38 --> Helper loaded: html_helper
INFO - 2023-09-28 19:31:38 --> Helper loaded: text_helper
INFO - 2023-09-28 19:31:38 --> Helper loaded: form_helper
INFO - 2023-09-28 19:31:38 --> Helper loaded: lang_helper
INFO - 2023-09-28 19:31:38 --> Helper loaded: security_helper
INFO - 2023-09-28 19:31:38 --> Helper loaded: cookie_helper
INFO - 2023-09-28 19:31:38 --> Database Driver Class Initialized
INFO - 2023-09-28 19:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 19:31:38 --> Parser Class Initialized
INFO - 2023-09-28 19:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 19:31:38 --> Pagination Class Initialized
INFO - 2023-09-28 19:31:38 --> Form Validation Class Initialized
INFO - 2023-09-28 19:31:38 --> Controller Class Initialized
INFO - 2023-09-28 19:31:38 --> Model Class Initialized
DEBUG - 2023-09-28 19:31:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 19:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 19:31:38 --> Model Class Initialized
INFO - 2023-09-28 19:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-09-28 19:31:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-28 19:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-28 19:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-28 19:31:38 --> Model Class Initialized
INFO - 2023-09-28 19:31:38 --> Model Class Initialized
INFO - 2023-09-28 19:31:38 --> Model Class Initialized
INFO - 2023-09-28 19:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-28 19:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-28 19:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-28 19:31:38 --> Final output sent to browser
DEBUG - 2023-09-28 19:31:38 --> Total execution time: 0.0776
ERROR - 2023-09-28 19:31:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-28 19:31:39 --> Config Class Initialized
INFO - 2023-09-28 19:31:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 19:31:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 19:31:39 --> Utf8 Class Initialized
INFO - 2023-09-28 19:31:39 --> URI Class Initialized
INFO - 2023-09-28 19:31:39 --> Router Class Initialized
INFO - 2023-09-28 19:31:39 --> Output Class Initialized
INFO - 2023-09-28 19:31:39 --> Security Class Initialized
DEBUG - 2023-09-28 19:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 19:31:39 --> Input Class Initialized
INFO - 2023-09-28 19:31:39 --> Language Class Initialized
INFO - 2023-09-28 19:31:39 --> Loader Class Initialized
INFO - 2023-09-28 19:31:39 --> Helper loaded: url_helper
INFO - 2023-09-28 19:31:39 --> Helper loaded: file_helper
INFO - 2023-09-28 19:31:39 --> Helper loaded: html_helper
INFO - 2023-09-28 19:31:39 --> Helper loaded: text_helper
INFO - 2023-09-28 19:31:39 --> Helper loaded: form_helper
INFO - 2023-09-28 19:31:39 --> Helper loaded: lang_helper
INFO - 2023-09-28 19:31:39 --> Helper loaded: security_helper
INFO - 2023-09-28 19:31:39 --> Helper loaded: cookie_helper
INFO - 2023-09-28 19:31:39 --> Database Driver Class Initialized
INFO - 2023-09-28 19:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 19:31:39 --> Parser Class Initialized
INFO - 2023-09-28 19:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-28 19:31:39 --> Pagination Class Initialized
INFO - 2023-09-28 19:31:39 --> Form Validation Class Initialized
INFO - 2023-09-28 19:31:39 --> Controller Class Initialized
INFO - 2023-09-28 19:31:39 --> Model Class Initialized
DEBUG - 2023-09-28 19:31:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-28 19:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-28 19:31:39 --> Model Class Initialized
INFO - 2023-09-28 19:31:39 --> Final output sent to browser
DEBUG - 2023-09-28 19:31:39 --> Total execution time: 0.0344
