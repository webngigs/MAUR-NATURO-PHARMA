<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-02 00:18:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:18:46 --> Config Class Initialized
INFO - 2024-03-02 00:18:46 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:18:46 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:18:46 --> Utf8 Class Initialized
INFO - 2024-03-02 00:18:46 --> URI Class Initialized
DEBUG - 2024-03-02 00:18:46 --> No URI present. Default controller set.
INFO - 2024-03-02 00:18:46 --> Router Class Initialized
INFO - 2024-03-02 00:18:46 --> Output Class Initialized
INFO - 2024-03-02 00:18:46 --> Security Class Initialized
DEBUG - 2024-03-02 00:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:18:46 --> Input Class Initialized
INFO - 2024-03-02 00:18:46 --> Language Class Initialized
INFO - 2024-03-02 00:18:46 --> Loader Class Initialized
INFO - 2024-03-02 00:18:46 --> Helper loaded: url_helper
INFO - 2024-03-02 00:18:46 --> Helper loaded: file_helper
INFO - 2024-03-02 00:18:46 --> Helper loaded: html_helper
INFO - 2024-03-02 00:18:46 --> Helper loaded: text_helper
INFO - 2024-03-02 00:18:46 --> Helper loaded: form_helper
INFO - 2024-03-02 00:18:46 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:18:46 --> Helper loaded: security_helper
INFO - 2024-03-02 00:18:46 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:18:46 --> Database Driver Class Initialized
INFO - 2024-03-02 00:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:18:46 --> Parser Class Initialized
INFO - 2024-03-02 00:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:18:46 --> Pagination Class Initialized
INFO - 2024-03-02 00:18:46 --> Form Validation Class Initialized
INFO - 2024-03-02 00:18:46 --> Controller Class Initialized
INFO - 2024-03-02 00:18:46 --> Model Class Initialized
DEBUG - 2024-03-02 00:18:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 00:18:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:18:47 --> Config Class Initialized
INFO - 2024-03-02 00:18:47 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:18:47 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:18:47 --> Utf8 Class Initialized
INFO - 2024-03-02 00:18:47 --> URI Class Initialized
DEBUG - 2024-03-02 00:18:47 --> No URI present. Default controller set.
INFO - 2024-03-02 00:18:47 --> Router Class Initialized
INFO - 2024-03-02 00:18:47 --> Output Class Initialized
INFO - 2024-03-02 00:18:47 --> Security Class Initialized
DEBUG - 2024-03-02 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:18:47 --> Input Class Initialized
INFO - 2024-03-02 00:18:47 --> Language Class Initialized
INFO - 2024-03-02 00:18:47 --> Loader Class Initialized
INFO - 2024-03-02 00:18:47 --> Helper loaded: url_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: file_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: html_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: text_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: form_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: security_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:18:47 --> Database Driver Class Initialized
INFO - 2024-03-02 00:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:18:47 --> Parser Class Initialized
INFO - 2024-03-02 00:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:18:47 --> Pagination Class Initialized
INFO - 2024-03-02 00:18:47 --> Form Validation Class Initialized
INFO - 2024-03-02 00:18:47 --> Controller Class Initialized
INFO - 2024-03-02 00:18:47 --> Model Class Initialized
DEBUG - 2024-03-02 00:18:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 00:18:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:18:47 --> Config Class Initialized
INFO - 2024-03-02 00:18:47 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:18:47 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:18:47 --> Utf8 Class Initialized
INFO - 2024-03-02 00:18:47 --> URI Class Initialized
DEBUG - 2024-03-02 00:18:47 --> No URI present. Default controller set.
INFO - 2024-03-02 00:18:47 --> Router Class Initialized
INFO - 2024-03-02 00:18:47 --> Output Class Initialized
INFO - 2024-03-02 00:18:47 --> Security Class Initialized
DEBUG - 2024-03-02 00:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:18:47 --> Input Class Initialized
INFO - 2024-03-02 00:18:47 --> Language Class Initialized
INFO - 2024-03-02 00:18:47 --> Loader Class Initialized
INFO - 2024-03-02 00:18:47 --> Helper loaded: url_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: file_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: html_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: text_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: form_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: security_helper
INFO - 2024-03-02 00:18:47 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:18:47 --> Database Driver Class Initialized
INFO - 2024-03-02 00:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:18:47 --> Parser Class Initialized
INFO - 2024-03-02 00:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:18:47 --> Pagination Class Initialized
INFO - 2024-03-02 00:18:47 --> Form Validation Class Initialized
INFO - 2024-03-02 00:18:47 --> Controller Class Initialized
INFO - 2024-03-02 00:18:47 --> Model Class Initialized
DEBUG - 2024-03-02 00:18:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 00:18:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:18:48 --> Config Class Initialized
INFO - 2024-03-02 00:18:48 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:18:48 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:18:48 --> Utf8 Class Initialized
INFO - 2024-03-02 00:18:48 --> URI Class Initialized
DEBUG - 2024-03-02 00:18:48 --> No URI present. Default controller set.
INFO - 2024-03-02 00:18:48 --> Router Class Initialized
INFO - 2024-03-02 00:18:48 --> Output Class Initialized
INFO - 2024-03-02 00:18:48 --> Security Class Initialized
DEBUG - 2024-03-02 00:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:18:48 --> Input Class Initialized
INFO - 2024-03-02 00:18:48 --> Language Class Initialized
INFO - 2024-03-02 00:18:48 --> Loader Class Initialized
INFO - 2024-03-02 00:18:48 --> Helper loaded: url_helper
INFO - 2024-03-02 00:18:48 --> Helper loaded: file_helper
INFO - 2024-03-02 00:18:48 --> Helper loaded: html_helper
INFO - 2024-03-02 00:18:48 --> Helper loaded: text_helper
INFO - 2024-03-02 00:18:48 --> Helper loaded: form_helper
INFO - 2024-03-02 00:18:48 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:18:48 --> Helper loaded: security_helper
INFO - 2024-03-02 00:18:48 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:18:48 --> Database Driver Class Initialized
INFO - 2024-03-02 00:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:18:48 --> Parser Class Initialized
INFO - 2024-03-02 00:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:18:48 --> Pagination Class Initialized
INFO - 2024-03-02 00:18:48 --> Form Validation Class Initialized
INFO - 2024-03-02 00:18:48 --> Controller Class Initialized
INFO - 2024-03-02 00:18:48 --> Model Class Initialized
DEBUG - 2024-03-02 00:18:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 00:57:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:57:27 --> Config Class Initialized
INFO - 2024-03-02 00:57:27 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:57:27 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:57:27 --> Utf8 Class Initialized
INFO - 2024-03-02 00:57:27 --> URI Class Initialized
DEBUG - 2024-03-02 00:57:27 --> No URI present. Default controller set.
INFO - 2024-03-02 00:57:27 --> Router Class Initialized
INFO - 2024-03-02 00:57:27 --> Output Class Initialized
INFO - 2024-03-02 00:57:27 --> Security Class Initialized
DEBUG - 2024-03-02 00:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:57:27 --> Input Class Initialized
INFO - 2024-03-02 00:57:27 --> Language Class Initialized
INFO - 2024-03-02 00:57:27 --> Loader Class Initialized
INFO - 2024-03-02 00:57:27 --> Helper loaded: url_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: file_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: html_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: text_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: form_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: security_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:57:27 --> Database Driver Class Initialized
INFO - 2024-03-02 00:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:57:27 --> Parser Class Initialized
INFO - 2024-03-02 00:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:57:27 --> Pagination Class Initialized
INFO - 2024-03-02 00:57:27 --> Form Validation Class Initialized
INFO - 2024-03-02 00:57:27 --> Controller Class Initialized
INFO - 2024-03-02 00:57:27 --> Model Class Initialized
DEBUG - 2024-03-02 00:57:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 00:57:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:57:27 --> Config Class Initialized
INFO - 2024-03-02 00:57:27 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:57:27 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:57:27 --> Utf8 Class Initialized
INFO - 2024-03-02 00:57:27 --> URI Class Initialized
INFO - 2024-03-02 00:57:27 --> Router Class Initialized
INFO - 2024-03-02 00:57:27 --> Output Class Initialized
INFO - 2024-03-02 00:57:27 --> Security Class Initialized
DEBUG - 2024-03-02 00:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:57:27 --> Input Class Initialized
INFO - 2024-03-02 00:57:27 --> Language Class Initialized
INFO - 2024-03-02 00:57:27 --> Loader Class Initialized
INFO - 2024-03-02 00:57:27 --> Helper loaded: url_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: file_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: html_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: text_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: form_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: security_helper
INFO - 2024-03-02 00:57:27 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:57:27 --> Database Driver Class Initialized
INFO - 2024-03-02 00:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:57:27 --> Parser Class Initialized
INFO - 2024-03-02 00:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:57:27 --> Pagination Class Initialized
INFO - 2024-03-02 00:57:27 --> Form Validation Class Initialized
INFO - 2024-03-02 00:57:27 --> Controller Class Initialized
INFO - 2024-03-02 00:57:27 --> Model Class Initialized
DEBUG - 2024-03-02 00:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 00:57:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 00:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 00:57:27 --> Model Class Initialized
INFO - 2024-03-02 00:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 00:57:27 --> Final output sent to browser
DEBUG - 2024-03-02 00:57:27 --> Total execution time: 0.0350
ERROR - 2024-03-02 00:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:57:54 --> Config Class Initialized
INFO - 2024-03-02 00:57:54 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:57:54 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:57:54 --> Utf8 Class Initialized
INFO - 2024-03-02 00:57:54 --> URI Class Initialized
INFO - 2024-03-02 00:57:54 --> Router Class Initialized
INFO - 2024-03-02 00:57:54 --> Output Class Initialized
INFO - 2024-03-02 00:57:54 --> Security Class Initialized
DEBUG - 2024-03-02 00:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:57:54 --> Input Class Initialized
INFO - 2024-03-02 00:57:54 --> Language Class Initialized
INFO - 2024-03-02 00:57:54 --> Loader Class Initialized
INFO - 2024-03-02 00:57:54 --> Helper loaded: url_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: file_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: html_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: text_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: form_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: security_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:57:54 --> Database Driver Class Initialized
INFO - 2024-03-02 00:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:57:54 --> Parser Class Initialized
INFO - 2024-03-02 00:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:57:54 --> Pagination Class Initialized
INFO - 2024-03-02 00:57:54 --> Form Validation Class Initialized
INFO - 2024-03-02 00:57:54 --> Controller Class Initialized
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
DEBUG - 2024-03-02 00:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
INFO - 2024-03-02 00:57:54 --> Final output sent to browser
DEBUG - 2024-03-02 00:57:54 --> Total execution time: 0.0213
ERROR - 2024-03-02 00:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:57:54 --> Config Class Initialized
INFO - 2024-03-02 00:57:54 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:57:54 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:57:54 --> Utf8 Class Initialized
INFO - 2024-03-02 00:57:54 --> URI Class Initialized
DEBUG - 2024-03-02 00:57:54 --> No URI present. Default controller set.
INFO - 2024-03-02 00:57:54 --> Router Class Initialized
INFO - 2024-03-02 00:57:54 --> Output Class Initialized
INFO - 2024-03-02 00:57:54 --> Security Class Initialized
DEBUG - 2024-03-02 00:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:57:54 --> Input Class Initialized
INFO - 2024-03-02 00:57:54 --> Language Class Initialized
INFO - 2024-03-02 00:57:54 --> Loader Class Initialized
INFO - 2024-03-02 00:57:54 --> Helper loaded: url_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: file_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: html_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: text_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: form_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: security_helper
INFO - 2024-03-02 00:57:54 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:57:54 --> Database Driver Class Initialized
INFO - 2024-03-02 00:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:57:54 --> Parser Class Initialized
INFO - 2024-03-02 00:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:57:54 --> Pagination Class Initialized
INFO - 2024-03-02 00:57:54 --> Form Validation Class Initialized
INFO - 2024-03-02 00:57:54 --> Controller Class Initialized
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
DEBUG - 2024-03-02 00:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
DEBUG - 2024-03-02 00:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
DEBUG - 2024-03-02 00:57:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 00:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
INFO - 2024-03-02 00:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 00:57:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 00:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 00:57:54 --> Model Class Initialized
INFO - 2024-03-02 00:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 00:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 00:57:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 00:57:54 --> Final output sent to browser
DEBUG - 2024-03-02 00:57:54 --> Total execution time: 0.2545
ERROR - 2024-03-02 00:58:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:58:08 --> Config Class Initialized
INFO - 2024-03-02 00:58:08 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:58:08 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:58:08 --> Utf8 Class Initialized
INFO - 2024-03-02 00:58:08 --> URI Class Initialized
INFO - 2024-03-02 00:58:08 --> Router Class Initialized
INFO - 2024-03-02 00:58:08 --> Output Class Initialized
INFO - 2024-03-02 00:58:08 --> Security Class Initialized
DEBUG - 2024-03-02 00:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:58:08 --> Input Class Initialized
INFO - 2024-03-02 00:58:08 --> Language Class Initialized
INFO - 2024-03-02 00:58:08 --> Loader Class Initialized
INFO - 2024-03-02 00:58:08 --> Helper loaded: url_helper
INFO - 2024-03-02 00:58:08 --> Helper loaded: file_helper
INFO - 2024-03-02 00:58:08 --> Helper loaded: html_helper
INFO - 2024-03-02 00:58:08 --> Helper loaded: text_helper
INFO - 2024-03-02 00:58:08 --> Helper loaded: form_helper
INFO - 2024-03-02 00:58:08 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:58:08 --> Helper loaded: security_helper
INFO - 2024-03-02 00:58:08 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:58:08 --> Database Driver Class Initialized
INFO - 2024-03-02 00:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:58:08 --> Parser Class Initialized
INFO - 2024-03-02 00:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:58:08 --> Pagination Class Initialized
INFO - 2024-03-02 00:58:08 --> Form Validation Class Initialized
INFO - 2024-03-02 00:58:08 --> Controller Class Initialized
DEBUG - 2024-03-02 00:58:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 00:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:08 --> Model Class Initialized
DEBUG - 2024-03-02 00:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:08 --> Model Class Initialized
DEBUG - 2024-03-02 00:58:08 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:08 --> Model Class Initialized
INFO - 2024-03-02 00:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-02 00:58:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 00:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 00:58:08 --> Model Class Initialized
INFO - 2024-03-02 00:58:08 --> Model Class Initialized
INFO - 2024-03-02 00:58:08 --> Model Class Initialized
INFO - 2024-03-02 00:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 00:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 00:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 00:58:08 --> Final output sent to browser
DEBUG - 2024-03-02 00:58:08 --> Total execution time: 0.1573
ERROR - 2024-03-02 00:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:58:09 --> Config Class Initialized
INFO - 2024-03-02 00:58:09 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:58:09 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:58:09 --> Utf8 Class Initialized
INFO - 2024-03-02 00:58:09 --> URI Class Initialized
INFO - 2024-03-02 00:58:09 --> Router Class Initialized
INFO - 2024-03-02 00:58:09 --> Output Class Initialized
INFO - 2024-03-02 00:58:09 --> Security Class Initialized
DEBUG - 2024-03-02 00:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:58:09 --> Input Class Initialized
INFO - 2024-03-02 00:58:09 --> Language Class Initialized
INFO - 2024-03-02 00:58:09 --> Loader Class Initialized
INFO - 2024-03-02 00:58:09 --> Helper loaded: url_helper
INFO - 2024-03-02 00:58:09 --> Helper loaded: file_helper
INFO - 2024-03-02 00:58:09 --> Helper loaded: html_helper
INFO - 2024-03-02 00:58:09 --> Helper loaded: text_helper
INFO - 2024-03-02 00:58:09 --> Helper loaded: form_helper
INFO - 2024-03-02 00:58:09 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:58:09 --> Helper loaded: security_helper
INFO - 2024-03-02 00:58:09 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:58:09 --> Database Driver Class Initialized
INFO - 2024-03-02 00:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:58:09 --> Parser Class Initialized
INFO - 2024-03-02 00:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:58:09 --> Pagination Class Initialized
INFO - 2024-03-02 00:58:09 --> Form Validation Class Initialized
INFO - 2024-03-02 00:58:09 --> Controller Class Initialized
DEBUG - 2024-03-02 00:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 00:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:09 --> Model Class Initialized
DEBUG - 2024-03-02 00:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:09 --> Model Class Initialized
INFO - 2024-03-02 00:58:09 --> Final output sent to browser
DEBUG - 2024-03-02 00:58:09 --> Total execution time: 0.0241
ERROR - 2024-03-02 00:58:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 00:58:19 --> Config Class Initialized
INFO - 2024-03-02 00:58:19 --> Hooks Class Initialized
DEBUG - 2024-03-02 00:58:19 --> UTF-8 Support Enabled
INFO - 2024-03-02 00:58:19 --> Utf8 Class Initialized
INFO - 2024-03-02 00:58:19 --> URI Class Initialized
INFO - 2024-03-02 00:58:19 --> Router Class Initialized
INFO - 2024-03-02 00:58:19 --> Output Class Initialized
INFO - 2024-03-02 00:58:19 --> Security Class Initialized
DEBUG - 2024-03-02 00:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 00:58:19 --> Input Class Initialized
INFO - 2024-03-02 00:58:19 --> Language Class Initialized
INFO - 2024-03-02 00:58:19 --> Loader Class Initialized
INFO - 2024-03-02 00:58:19 --> Helper loaded: url_helper
INFO - 2024-03-02 00:58:19 --> Helper loaded: file_helper
INFO - 2024-03-02 00:58:19 --> Helper loaded: html_helper
INFO - 2024-03-02 00:58:19 --> Helper loaded: text_helper
INFO - 2024-03-02 00:58:19 --> Helper loaded: form_helper
INFO - 2024-03-02 00:58:19 --> Helper loaded: lang_helper
INFO - 2024-03-02 00:58:19 --> Helper loaded: security_helper
INFO - 2024-03-02 00:58:19 --> Helper loaded: cookie_helper
INFO - 2024-03-02 00:58:19 --> Database Driver Class Initialized
INFO - 2024-03-02 00:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 00:58:19 --> Parser Class Initialized
INFO - 2024-03-02 00:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 00:58:19 --> Pagination Class Initialized
INFO - 2024-03-02 00:58:19 --> Form Validation Class Initialized
INFO - 2024-03-02 00:58:19 --> Controller Class Initialized
DEBUG - 2024-03-02 00:58:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 00:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:19 --> Model Class Initialized
DEBUG - 2024-03-02 00:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 00:58:19 --> Model Class Initialized
INFO - 2024-03-02 00:58:19 --> Final output sent to browser
DEBUG - 2024-03-02 00:58:19 --> Total execution time: 0.0375
ERROR - 2024-03-02 01:07:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:07:23 --> Config Class Initialized
INFO - 2024-03-02 01:07:23 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:07:23 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:07:23 --> Utf8 Class Initialized
INFO - 2024-03-02 01:07:23 --> URI Class Initialized
DEBUG - 2024-03-02 01:07:23 --> No URI present. Default controller set.
INFO - 2024-03-02 01:07:23 --> Router Class Initialized
INFO - 2024-03-02 01:07:23 --> Output Class Initialized
INFO - 2024-03-02 01:07:23 --> Security Class Initialized
DEBUG - 2024-03-02 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:07:23 --> Input Class Initialized
INFO - 2024-03-02 01:07:23 --> Language Class Initialized
INFO - 2024-03-02 01:07:23 --> Loader Class Initialized
INFO - 2024-03-02 01:07:23 --> Helper loaded: url_helper
INFO - 2024-03-02 01:07:23 --> Helper loaded: file_helper
INFO - 2024-03-02 01:07:23 --> Helper loaded: html_helper
INFO - 2024-03-02 01:07:23 --> Helper loaded: text_helper
INFO - 2024-03-02 01:07:23 --> Helper loaded: form_helper
INFO - 2024-03-02 01:07:23 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:07:23 --> Helper loaded: security_helper
INFO - 2024-03-02 01:07:23 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:07:23 --> Database Driver Class Initialized
INFO - 2024-03-02 01:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:07:23 --> Parser Class Initialized
INFO - 2024-03-02 01:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:07:23 --> Pagination Class Initialized
INFO - 2024-03-02 01:07:23 --> Form Validation Class Initialized
INFO - 2024-03-02 01:07:23 --> Controller Class Initialized
INFO - 2024-03-02 01:07:23 --> Model Class Initialized
DEBUG - 2024-03-02 01:07:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 01:22:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:22:31 --> Config Class Initialized
INFO - 2024-03-02 01:22:31 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:22:31 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:22:31 --> Utf8 Class Initialized
INFO - 2024-03-02 01:22:31 --> URI Class Initialized
DEBUG - 2024-03-02 01:22:31 --> No URI present. Default controller set.
INFO - 2024-03-02 01:22:31 --> Router Class Initialized
INFO - 2024-03-02 01:22:31 --> Output Class Initialized
INFO - 2024-03-02 01:22:31 --> Security Class Initialized
DEBUG - 2024-03-02 01:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:22:31 --> Input Class Initialized
INFO - 2024-03-02 01:22:31 --> Language Class Initialized
INFO - 2024-03-02 01:22:31 --> Loader Class Initialized
INFO - 2024-03-02 01:22:31 --> Helper loaded: url_helper
INFO - 2024-03-02 01:22:31 --> Helper loaded: file_helper
INFO - 2024-03-02 01:22:31 --> Helper loaded: html_helper
INFO - 2024-03-02 01:22:31 --> Helper loaded: text_helper
INFO - 2024-03-02 01:22:31 --> Helper loaded: form_helper
INFO - 2024-03-02 01:22:31 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:22:31 --> Helper loaded: security_helper
INFO - 2024-03-02 01:22:31 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:22:31 --> Database Driver Class Initialized
INFO - 2024-03-02 01:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:22:31 --> Parser Class Initialized
INFO - 2024-03-02 01:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:22:31 --> Pagination Class Initialized
INFO - 2024-03-02 01:22:31 --> Form Validation Class Initialized
INFO - 2024-03-02 01:22:31 --> Controller Class Initialized
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
DEBUG - 2024-03-02 01:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
DEBUG - 2024-03-02 01:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
DEBUG - 2024-03-02 01:22:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
INFO - 2024-03-02 01:22:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 01:22:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 01:22:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 01:22:31 --> Model Class Initialized
INFO - 2024-03-02 01:22:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 01:22:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 01:22:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 01:22:31 --> Final output sent to browser
DEBUG - 2024-03-02 01:22:31 --> Total execution time: 0.2489
ERROR - 2024-03-02 01:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:22:49 --> Config Class Initialized
INFO - 2024-03-02 01:22:49 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:22:49 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:22:49 --> Utf8 Class Initialized
INFO - 2024-03-02 01:22:49 --> URI Class Initialized
INFO - 2024-03-02 01:22:49 --> Router Class Initialized
INFO - 2024-03-02 01:22:49 --> Output Class Initialized
INFO - 2024-03-02 01:22:49 --> Security Class Initialized
DEBUG - 2024-03-02 01:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:22:49 --> Input Class Initialized
INFO - 2024-03-02 01:22:49 --> Language Class Initialized
INFO - 2024-03-02 01:22:49 --> Loader Class Initialized
INFO - 2024-03-02 01:22:49 --> Helper loaded: url_helper
INFO - 2024-03-02 01:22:49 --> Helper loaded: file_helper
INFO - 2024-03-02 01:22:49 --> Helper loaded: html_helper
INFO - 2024-03-02 01:22:49 --> Helper loaded: text_helper
INFO - 2024-03-02 01:22:49 --> Helper loaded: form_helper
INFO - 2024-03-02 01:22:49 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:22:49 --> Helper loaded: security_helper
INFO - 2024-03-02 01:22:49 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:22:49 --> Database Driver Class Initialized
INFO - 2024-03-02 01:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:22:49 --> Parser Class Initialized
INFO - 2024-03-02 01:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:22:49 --> Pagination Class Initialized
INFO - 2024-03-02 01:22:49 --> Form Validation Class Initialized
INFO - 2024-03-02 01:22:49 --> Controller Class Initialized
DEBUG - 2024-03-02 01:22:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:49 --> Model Class Initialized
DEBUG - 2024-03-02 01:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:49 --> Model Class Initialized
DEBUG - 2024-03-02 01:22:49 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:49 --> Model Class Initialized
INFO - 2024-03-02 01:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-02 01:22:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 01:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 01:22:49 --> Model Class Initialized
INFO - 2024-03-02 01:22:49 --> Model Class Initialized
INFO - 2024-03-02 01:22:49 --> Model Class Initialized
INFO - 2024-03-02 01:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 01:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 01:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 01:22:49 --> Final output sent to browser
DEBUG - 2024-03-02 01:22:49 --> Total execution time: 0.1574
ERROR - 2024-03-02 01:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:22:50 --> Config Class Initialized
INFO - 2024-03-02 01:22:50 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:22:50 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:22:50 --> Utf8 Class Initialized
INFO - 2024-03-02 01:22:50 --> URI Class Initialized
INFO - 2024-03-02 01:22:50 --> Router Class Initialized
INFO - 2024-03-02 01:22:50 --> Output Class Initialized
INFO - 2024-03-02 01:22:50 --> Security Class Initialized
DEBUG - 2024-03-02 01:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:22:50 --> Input Class Initialized
INFO - 2024-03-02 01:22:50 --> Language Class Initialized
INFO - 2024-03-02 01:22:50 --> Loader Class Initialized
INFO - 2024-03-02 01:22:50 --> Helper loaded: url_helper
INFO - 2024-03-02 01:22:50 --> Helper loaded: file_helper
INFO - 2024-03-02 01:22:50 --> Helper loaded: html_helper
INFO - 2024-03-02 01:22:50 --> Helper loaded: text_helper
INFO - 2024-03-02 01:22:50 --> Helper loaded: form_helper
INFO - 2024-03-02 01:22:50 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:22:50 --> Helper loaded: security_helper
INFO - 2024-03-02 01:22:50 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:22:50 --> Database Driver Class Initialized
INFO - 2024-03-02 01:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:22:50 --> Parser Class Initialized
INFO - 2024-03-02 01:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:22:50 --> Pagination Class Initialized
INFO - 2024-03-02 01:22:50 --> Form Validation Class Initialized
INFO - 2024-03-02 01:22:50 --> Controller Class Initialized
DEBUG - 2024-03-02 01:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:50 --> Model Class Initialized
DEBUG - 2024-03-02 01:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:22:50 --> Model Class Initialized
INFO - 2024-03-02 01:22:50 --> Final output sent to browser
DEBUG - 2024-03-02 01:22:50 --> Total execution time: 0.0218
ERROR - 2024-03-02 01:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:23:00 --> Config Class Initialized
INFO - 2024-03-02 01:23:00 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:23:00 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:23:00 --> Utf8 Class Initialized
INFO - 2024-03-02 01:23:00 --> URI Class Initialized
INFO - 2024-03-02 01:23:00 --> Router Class Initialized
INFO - 2024-03-02 01:23:00 --> Output Class Initialized
INFO - 2024-03-02 01:23:00 --> Security Class Initialized
DEBUG - 2024-03-02 01:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:23:00 --> Input Class Initialized
INFO - 2024-03-02 01:23:00 --> Language Class Initialized
INFO - 2024-03-02 01:23:00 --> Loader Class Initialized
INFO - 2024-03-02 01:23:00 --> Helper loaded: url_helper
INFO - 2024-03-02 01:23:00 --> Helper loaded: file_helper
INFO - 2024-03-02 01:23:00 --> Helper loaded: html_helper
INFO - 2024-03-02 01:23:00 --> Helper loaded: text_helper
INFO - 2024-03-02 01:23:00 --> Helper loaded: form_helper
INFO - 2024-03-02 01:23:00 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:23:00 --> Helper loaded: security_helper
INFO - 2024-03-02 01:23:00 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:23:00 --> Database Driver Class Initialized
INFO - 2024-03-02 01:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:23:00 --> Parser Class Initialized
INFO - 2024-03-02 01:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:23:00 --> Pagination Class Initialized
INFO - 2024-03-02 01:23:00 --> Form Validation Class Initialized
INFO - 2024-03-02 01:23:00 --> Controller Class Initialized
DEBUG - 2024-03-02 01:23:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:23:00 --> Model Class Initialized
DEBUG - 2024-03-02 01:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:23:00 --> Model Class Initialized
INFO - 2024-03-02 01:23:00 --> Final output sent to browser
DEBUG - 2024-03-02 01:23:00 --> Total execution time: 0.0346
ERROR - 2024-03-02 01:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:55:16 --> Config Class Initialized
INFO - 2024-03-02 01:55:16 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:55:16 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:55:16 --> Utf8 Class Initialized
INFO - 2024-03-02 01:55:16 --> URI Class Initialized
DEBUG - 2024-03-02 01:55:16 --> No URI present. Default controller set.
INFO - 2024-03-02 01:55:16 --> Router Class Initialized
INFO - 2024-03-02 01:55:16 --> Output Class Initialized
INFO - 2024-03-02 01:55:16 --> Security Class Initialized
DEBUG - 2024-03-02 01:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:55:16 --> Input Class Initialized
INFO - 2024-03-02 01:55:16 --> Language Class Initialized
INFO - 2024-03-02 01:55:16 --> Loader Class Initialized
INFO - 2024-03-02 01:55:16 --> Helper loaded: url_helper
INFO - 2024-03-02 01:55:16 --> Helper loaded: file_helper
INFO - 2024-03-02 01:55:16 --> Helper loaded: html_helper
INFO - 2024-03-02 01:55:16 --> Helper loaded: text_helper
INFO - 2024-03-02 01:55:16 --> Helper loaded: form_helper
INFO - 2024-03-02 01:55:16 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:55:16 --> Helper loaded: security_helper
INFO - 2024-03-02 01:55:16 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:55:16 --> Database Driver Class Initialized
INFO - 2024-03-02 01:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:55:16 --> Parser Class Initialized
INFO - 2024-03-02 01:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:55:16 --> Pagination Class Initialized
INFO - 2024-03-02 01:55:16 --> Form Validation Class Initialized
INFO - 2024-03-02 01:55:16 --> Controller Class Initialized
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
DEBUG - 2024-03-02 01:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
DEBUG - 2024-03-02 01:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
DEBUG - 2024-03-02 01:55:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
INFO - 2024-03-02 01:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 01:55:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 01:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 01:55:16 --> Model Class Initialized
INFO - 2024-03-02 01:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 01:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 01:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 01:55:16 --> Final output sent to browser
DEBUG - 2024-03-02 01:55:16 --> Total execution time: 0.2553
ERROR - 2024-03-02 01:55:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:55:21 --> Config Class Initialized
INFO - 2024-03-02 01:55:21 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:55:21 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:55:21 --> Utf8 Class Initialized
INFO - 2024-03-02 01:55:21 --> URI Class Initialized
INFO - 2024-03-02 01:55:21 --> Router Class Initialized
INFO - 2024-03-02 01:55:21 --> Output Class Initialized
INFO - 2024-03-02 01:55:21 --> Security Class Initialized
DEBUG - 2024-03-02 01:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:55:21 --> Input Class Initialized
INFO - 2024-03-02 01:55:21 --> Language Class Initialized
INFO - 2024-03-02 01:55:21 --> Loader Class Initialized
INFO - 2024-03-02 01:55:21 --> Helper loaded: url_helper
INFO - 2024-03-02 01:55:21 --> Helper loaded: file_helper
INFO - 2024-03-02 01:55:21 --> Helper loaded: html_helper
INFO - 2024-03-02 01:55:21 --> Helper loaded: text_helper
INFO - 2024-03-02 01:55:21 --> Helper loaded: form_helper
INFO - 2024-03-02 01:55:21 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:55:21 --> Helper loaded: security_helper
INFO - 2024-03-02 01:55:21 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:55:21 --> Database Driver Class Initialized
INFO - 2024-03-02 01:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:55:21 --> Parser Class Initialized
INFO - 2024-03-02 01:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:55:21 --> Pagination Class Initialized
INFO - 2024-03-02 01:55:21 --> Form Validation Class Initialized
INFO - 2024-03-02 01:55:21 --> Controller Class Initialized
DEBUG - 2024-03-02 01:55:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:21 --> Model Class Initialized
DEBUG - 2024-03-02 01:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:21 --> Model Class Initialized
DEBUG - 2024-03-02 01:55:21 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:21 --> Model Class Initialized
INFO - 2024-03-02 01:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-02 01:55:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 01:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 01:55:21 --> Model Class Initialized
INFO - 2024-03-02 01:55:21 --> Model Class Initialized
INFO - 2024-03-02 01:55:21 --> Model Class Initialized
INFO - 2024-03-02 01:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 01:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 01:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 01:55:21 --> Final output sent to browser
DEBUG - 2024-03-02 01:55:21 --> Total execution time: 0.1568
ERROR - 2024-03-02 01:55:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:55:22 --> Config Class Initialized
INFO - 2024-03-02 01:55:22 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:55:22 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:55:22 --> Utf8 Class Initialized
INFO - 2024-03-02 01:55:22 --> URI Class Initialized
INFO - 2024-03-02 01:55:22 --> Router Class Initialized
INFO - 2024-03-02 01:55:22 --> Output Class Initialized
INFO - 2024-03-02 01:55:22 --> Security Class Initialized
DEBUG - 2024-03-02 01:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:55:22 --> Input Class Initialized
INFO - 2024-03-02 01:55:22 --> Language Class Initialized
INFO - 2024-03-02 01:55:22 --> Loader Class Initialized
INFO - 2024-03-02 01:55:22 --> Helper loaded: url_helper
INFO - 2024-03-02 01:55:22 --> Helper loaded: file_helper
INFO - 2024-03-02 01:55:22 --> Helper loaded: html_helper
INFO - 2024-03-02 01:55:22 --> Helper loaded: text_helper
INFO - 2024-03-02 01:55:22 --> Helper loaded: form_helper
INFO - 2024-03-02 01:55:22 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:55:22 --> Helper loaded: security_helper
INFO - 2024-03-02 01:55:22 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:55:22 --> Database Driver Class Initialized
INFO - 2024-03-02 01:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:55:22 --> Parser Class Initialized
INFO - 2024-03-02 01:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:55:22 --> Pagination Class Initialized
INFO - 2024-03-02 01:55:22 --> Form Validation Class Initialized
INFO - 2024-03-02 01:55:22 --> Controller Class Initialized
DEBUG - 2024-03-02 01:55:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:22 --> Model Class Initialized
DEBUG - 2024-03-02 01:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:22 --> Model Class Initialized
INFO - 2024-03-02 01:55:22 --> Final output sent to browser
DEBUG - 2024-03-02 01:55:22 --> Total execution time: 0.0217
ERROR - 2024-03-02 01:55:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 01:55:27 --> Config Class Initialized
INFO - 2024-03-02 01:55:27 --> Hooks Class Initialized
DEBUG - 2024-03-02 01:55:27 --> UTF-8 Support Enabled
INFO - 2024-03-02 01:55:27 --> Utf8 Class Initialized
INFO - 2024-03-02 01:55:27 --> URI Class Initialized
INFO - 2024-03-02 01:55:27 --> Router Class Initialized
INFO - 2024-03-02 01:55:27 --> Output Class Initialized
INFO - 2024-03-02 01:55:27 --> Security Class Initialized
DEBUG - 2024-03-02 01:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 01:55:27 --> Input Class Initialized
INFO - 2024-03-02 01:55:27 --> Language Class Initialized
INFO - 2024-03-02 01:55:27 --> Loader Class Initialized
INFO - 2024-03-02 01:55:27 --> Helper loaded: url_helper
INFO - 2024-03-02 01:55:27 --> Helper loaded: file_helper
INFO - 2024-03-02 01:55:27 --> Helper loaded: html_helper
INFO - 2024-03-02 01:55:27 --> Helper loaded: text_helper
INFO - 2024-03-02 01:55:27 --> Helper loaded: form_helper
INFO - 2024-03-02 01:55:27 --> Helper loaded: lang_helper
INFO - 2024-03-02 01:55:27 --> Helper loaded: security_helper
INFO - 2024-03-02 01:55:27 --> Helper loaded: cookie_helper
INFO - 2024-03-02 01:55:27 --> Database Driver Class Initialized
INFO - 2024-03-02 01:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 01:55:27 --> Parser Class Initialized
INFO - 2024-03-02 01:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 01:55:27 --> Pagination Class Initialized
INFO - 2024-03-02 01:55:27 --> Form Validation Class Initialized
INFO - 2024-03-02 01:55:27 --> Controller Class Initialized
DEBUG - 2024-03-02 01:55:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 01:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:27 --> Model Class Initialized
DEBUG - 2024-03-02 01:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 01:55:27 --> Model Class Initialized
INFO - 2024-03-02 01:55:27 --> Final output sent to browser
DEBUG - 2024-03-02 01:55:27 --> Total execution time: 0.0403
ERROR - 2024-03-02 02:45:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 02:45:03 --> Config Class Initialized
INFO - 2024-03-02 02:45:03 --> Hooks Class Initialized
DEBUG - 2024-03-02 02:45:03 --> UTF-8 Support Enabled
INFO - 2024-03-02 02:45:03 --> Utf8 Class Initialized
INFO - 2024-03-02 02:45:03 --> URI Class Initialized
INFO - 2024-03-02 02:45:03 --> Router Class Initialized
INFO - 2024-03-02 02:45:03 --> Output Class Initialized
INFO - 2024-03-02 02:45:03 --> Security Class Initialized
DEBUG - 2024-03-02 02:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 02:45:03 --> Input Class Initialized
INFO - 2024-03-02 02:45:03 --> Language Class Initialized
ERROR - 2024-03-02 02:45:03 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-02 04:15:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 04:15:09 --> Config Class Initialized
INFO - 2024-03-02 04:15:09 --> Hooks Class Initialized
DEBUG - 2024-03-02 04:15:09 --> UTF-8 Support Enabled
INFO - 2024-03-02 04:15:09 --> Utf8 Class Initialized
INFO - 2024-03-02 04:15:09 --> URI Class Initialized
INFO - 2024-03-02 04:15:09 --> Router Class Initialized
INFO - 2024-03-02 04:15:09 --> Output Class Initialized
INFO - 2024-03-02 04:15:09 --> Security Class Initialized
DEBUG - 2024-03-02 04:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 04:15:09 --> Input Class Initialized
INFO - 2024-03-02 04:15:09 --> Language Class Initialized
ERROR - 2024-03-02 04:15:09 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-02 05:00:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:00:06 --> Config Class Initialized
INFO - 2024-03-02 05:00:06 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:00:06 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:00:06 --> Utf8 Class Initialized
INFO - 2024-03-02 05:00:06 --> URI Class Initialized
DEBUG - 2024-03-02 05:00:06 --> No URI present. Default controller set.
INFO - 2024-03-02 05:00:06 --> Router Class Initialized
INFO - 2024-03-02 05:00:06 --> Output Class Initialized
INFO - 2024-03-02 05:00:06 --> Security Class Initialized
DEBUG - 2024-03-02 05:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:00:06 --> Input Class Initialized
INFO - 2024-03-02 05:00:06 --> Language Class Initialized
INFO - 2024-03-02 05:00:06 --> Loader Class Initialized
INFO - 2024-03-02 05:00:06 --> Helper loaded: url_helper
INFO - 2024-03-02 05:00:06 --> Helper loaded: file_helper
INFO - 2024-03-02 05:00:06 --> Helper loaded: html_helper
INFO - 2024-03-02 05:00:06 --> Helper loaded: text_helper
INFO - 2024-03-02 05:00:06 --> Helper loaded: form_helper
INFO - 2024-03-02 05:00:06 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:00:06 --> Helper loaded: security_helper
INFO - 2024-03-02 05:00:06 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:00:06 --> Database Driver Class Initialized
INFO - 2024-03-02 05:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:00:06 --> Parser Class Initialized
INFO - 2024-03-02 05:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:00:06 --> Pagination Class Initialized
INFO - 2024-03-02 05:00:06 --> Form Validation Class Initialized
INFO - 2024-03-02 05:00:06 --> Controller Class Initialized
INFO - 2024-03-02 05:00:06 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 05:00:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:00:07 --> Config Class Initialized
INFO - 2024-03-02 05:00:07 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:00:07 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:00:07 --> Utf8 Class Initialized
INFO - 2024-03-02 05:00:07 --> URI Class Initialized
INFO - 2024-03-02 05:00:07 --> Router Class Initialized
INFO - 2024-03-02 05:00:07 --> Output Class Initialized
INFO - 2024-03-02 05:00:07 --> Security Class Initialized
DEBUG - 2024-03-02 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:00:07 --> Input Class Initialized
INFO - 2024-03-02 05:00:07 --> Language Class Initialized
INFO - 2024-03-02 05:00:07 --> Loader Class Initialized
INFO - 2024-03-02 05:00:07 --> Helper loaded: url_helper
INFO - 2024-03-02 05:00:07 --> Helper loaded: file_helper
INFO - 2024-03-02 05:00:07 --> Helper loaded: html_helper
INFO - 2024-03-02 05:00:07 --> Helper loaded: text_helper
INFO - 2024-03-02 05:00:07 --> Helper loaded: form_helper
INFO - 2024-03-02 05:00:07 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:00:07 --> Helper loaded: security_helper
INFO - 2024-03-02 05:00:07 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:00:07 --> Database Driver Class Initialized
INFO - 2024-03-02 05:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:00:07 --> Parser Class Initialized
INFO - 2024-03-02 05:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:00:07 --> Pagination Class Initialized
INFO - 2024-03-02 05:00:07 --> Form Validation Class Initialized
INFO - 2024-03-02 05:00:07 --> Controller Class Initialized
INFO - 2024-03-02 05:00:07 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 05:00:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:00:07 --> Model Class Initialized
INFO - 2024-03-02 05:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:00:07 --> Final output sent to browser
DEBUG - 2024-03-02 05:00:07 --> Total execution time: 0.0328
ERROR - 2024-03-02 05:00:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:00:36 --> Config Class Initialized
INFO - 2024-03-02 05:00:36 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:00:36 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:00:36 --> Utf8 Class Initialized
INFO - 2024-03-02 05:00:36 --> URI Class Initialized
INFO - 2024-03-02 05:00:36 --> Router Class Initialized
INFO - 2024-03-02 05:00:36 --> Output Class Initialized
INFO - 2024-03-02 05:00:36 --> Security Class Initialized
DEBUG - 2024-03-02 05:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:00:36 --> Input Class Initialized
INFO - 2024-03-02 05:00:36 --> Language Class Initialized
INFO - 2024-03-02 05:00:36 --> Loader Class Initialized
INFO - 2024-03-02 05:00:36 --> Helper loaded: url_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: file_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: html_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: text_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: form_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: security_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:00:36 --> Database Driver Class Initialized
INFO - 2024-03-02 05:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:00:36 --> Parser Class Initialized
INFO - 2024-03-02 05:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:00:36 --> Pagination Class Initialized
INFO - 2024-03-02 05:00:36 --> Form Validation Class Initialized
INFO - 2024-03-02 05:00:36 --> Controller Class Initialized
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
INFO - 2024-03-02 05:00:36 --> Final output sent to browser
DEBUG - 2024-03-02 05:00:36 --> Total execution time: 0.0205
ERROR - 2024-03-02 05:00:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:00:36 --> Config Class Initialized
INFO - 2024-03-02 05:00:36 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:00:36 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:00:36 --> Utf8 Class Initialized
INFO - 2024-03-02 05:00:36 --> URI Class Initialized
DEBUG - 2024-03-02 05:00:36 --> No URI present. Default controller set.
INFO - 2024-03-02 05:00:36 --> Router Class Initialized
INFO - 2024-03-02 05:00:36 --> Output Class Initialized
INFO - 2024-03-02 05:00:36 --> Security Class Initialized
DEBUG - 2024-03-02 05:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:00:36 --> Input Class Initialized
INFO - 2024-03-02 05:00:36 --> Language Class Initialized
INFO - 2024-03-02 05:00:36 --> Loader Class Initialized
INFO - 2024-03-02 05:00:36 --> Helper loaded: url_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: file_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: html_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: text_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: form_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: security_helper
INFO - 2024-03-02 05:00:36 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:00:36 --> Database Driver Class Initialized
INFO - 2024-03-02 05:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:00:36 --> Parser Class Initialized
INFO - 2024-03-02 05:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:00:36 --> Pagination Class Initialized
INFO - 2024-03-02 05:00:36 --> Form Validation Class Initialized
INFO - 2024-03-02 05:00:36 --> Controller Class Initialized
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
INFO - 2024-03-02 05:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:00:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:00:36 --> Model Class Initialized
INFO - 2024-03-02 05:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:00:36 --> Final output sent to browser
DEBUG - 2024-03-02 05:00:36 --> Total execution time: 0.2747
ERROR - 2024-03-02 05:00:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:00:51 --> Config Class Initialized
INFO - 2024-03-02 05:00:51 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:00:51 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:00:51 --> Utf8 Class Initialized
INFO - 2024-03-02 05:00:51 --> URI Class Initialized
INFO - 2024-03-02 05:00:51 --> Router Class Initialized
INFO - 2024-03-02 05:00:51 --> Output Class Initialized
INFO - 2024-03-02 05:00:51 --> Security Class Initialized
DEBUG - 2024-03-02 05:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:00:51 --> Input Class Initialized
INFO - 2024-03-02 05:00:51 --> Language Class Initialized
INFO - 2024-03-02 05:00:51 --> Loader Class Initialized
INFO - 2024-03-02 05:00:51 --> Helper loaded: url_helper
INFO - 2024-03-02 05:00:51 --> Helper loaded: file_helper
INFO - 2024-03-02 05:00:51 --> Helper loaded: html_helper
INFO - 2024-03-02 05:00:51 --> Helper loaded: text_helper
INFO - 2024-03-02 05:00:51 --> Helper loaded: form_helper
INFO - 2024-03-02 05:00:51 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:00:51 --> Helper loaded: security_helper
INFO - 2024-03-02 05:00:51 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:00:51 --> Database Driver Class Initialized
INFO - 2024-03-02 05:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:00:51 --> Parser Class Initialized
INFO - 2024-03-02 05:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:00:51 --> Pagination Class Initialized
INFO - 2024-03-02 05:00:51 --> Form Validation Class Initialized
INFO - 2024-03-02 05:00:51 --> Controller Class Initialized
DEBUG - 2024-03-02 05:00:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:51 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:51 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:51 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:51 --> Model Class Initialized
INFO - 2024-03-02 05:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-02 05:00:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:00:51 --> Model Class Initialized
INFO - 2024-03-02 05:00:51 --> Model Class Initialized
INFO - 2024-03-02 05:00:51 --> Model Class Initialized
INFO - 2024-03-02 05:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:00:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:00:51 --> Final output sent to browser
DEBUG - 2024-03-02 05:00:51 --> Total execution time: 0.1590
ERROR - 2024-03-02 05:00:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:00:52 --> Config Class Initialized
INFO - 2024-03-02 05:00:52 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:00:52 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:00:52 --> Utf8 Class Initialized
INFO - 2024-03-02 05:00:52 --> URI Class Initialized
INFO - 2024-03-02 05:00:52 --> Router Class Initialized
INFO - 2024-03-02 05:00:52 --> Output Class Initialized
INFO - 2024-03-02 05:00:52 --> Security Class Initialized
DEBUG - 2024-03-02 05:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:00:52 --> Input Class Initialized
INFO - 2024-03-02 05:00:52 --> Language Class Initialized
INFO - 2024-03-02 05:00:52 --> Loader Class Initialized
INFO - 2024-03-02 05:00:52 --> Helper loaded: url_helper
INFO - 2024-03-02 05:00:52 --> Helper loaded: file_helper
INFO - 2024-03-02 05:00:52 --> Helper loaded: html_helper
INFO - 2024-03-02 05:00:52 --> Helper loaded: text_helper
INFO - 2024-03-02 05:00:52 --> Helper loaded: form_helper
INFO - 2024-03-02 05:00:52 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:00:52 --> Helper loaded: security_helper
INFO - 2024-03-02 05:00:52 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:00:52 --> Database Driver Class Initialized
INFO - 2024-03-02 05:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:00:52 --> Parser Class Initialized
INFO - 2024-03-02 05:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:00:52 --> Pagination Class Initialized
INFO - 2024-03-02 05:00:52 --> Form Validation Class Initialized
INFO - 2024-03-02 05:00:52 --> Controller Class Initialized
DEBUG - 2024-03-02 05:00:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:52 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:52 --> Model Class Initialized
INFO - 2024-03-02 05:00:52 --> Final output sent to browser
DEBUG - 2024-03-02 05:00:52 --> Total execution time: 0.0263
ERROR - 2024-03-02 05:00:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:00:57 --> Config Class Initialized
INFO - 2024-03-02 05:00:57 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:00:57 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:00:57 --> Utf8 Class Initialized
INFO - 2024-03-02 05:00:57 --> URI Class Initialized
INFO - 2024-03-02 05:00:57 --> Router Class Initialized
INFO - 2024-03-02 05:00:57 --> Output Class Initialized
INFO - 2024-03-02 05:00:57 --> Security Class Initialized
DEBUG - 2024-03-02 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:00:57 --> Input Class Initialized
INFO - 2024-03-02 05:00:57 --> Language Class Initialized
INFO - 2024-03-02 05:00:57 --> Loader Class Initialized
INFO - 2024-03-02 05:00:57 --> Helper loaded: url_helper
INFO - 2024-03-02 05:00:57 --> Helper loaded: file_helper
INFO - 2024-03-02 05:00:57 --> Helper loaded: html_helper
INFO - 2024-03-02 05:00:57 --> Helper loaded: text_helper
INFO - 2024-03-02 05:00:57 --> Helper loaded: form_helper
INFO - 2024-03-02 05:00:57 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:00:57 --> Helper loaded: security_helper
INFO - 2024-03-02 05:00:57 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:00:57 --> Database Driver Class Initialized
INFO - 2024-03-02 05:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:00:57 --> Parser Class Initialized
INFO - 2024-03-02 05:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:00:57 --> Pagination Class Initialized
INFO - 2024-03-02 05:00:57 --> Form Validation Class Initialized
INFO - 2024-03-02 05:00:57 --> Controller Class Initialized
DEBUG - 2024-03-02 05:00:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:57 --> Model Class Initialized
DEBUG - 2024-03-02 05:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:00:57 --> Model Class Initialized
INFO - 2024-03-02 05:00:57 --> Final output sent to browser
DEBUG - 2024-03-02 05:00:57 --> Total execution time: 0.0326
ERROR - 2024-03-02 05:01:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:01:50 --> Config Class Initialized
INFO - 2024-03-02 05:01:50 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:01:50 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:01:50 --> Utf8 Class Initialized
INFO - 2024-03-02 05:01:50 --> URI Class Initialized
DEBUG - 2024-03-02 05:01:50 --> No URI present. Default controller set.
INFO - 2024-03-02 05:01:50 --> Router Class Initialized
INFO - 2024-03-02 05:01:50 --> Output Class Initialized
INFO - 2024-03-02 05:01:50 --> Security Class Initialized
DEBUG - 2024-03-02 05:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:01:50 --> Input Class Initialized
INFO - 2024-03-02 05:01:50 --> Language Class Initialized
INFO - 2024-03-02 05:01:50 --> Loader Class Initialized
INFO - 2024-03-02 05:01:50 --> Helper loaded: url_helper
INFO - 2024-03-02 05:01:50 --> Helper loaded: file_helper
INFO - 2024-03-02 05:01:50 --> Helper loaded: html_helper
INFO - 2024-03-02 05:01:50 --> Helper loaded: text_helper
INFO - 2024-03-02 05:01:50 --> Helper loaded: form_helper
INFO - 2024-03-02 05:01:50 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:01:50 --> Helper loaded: security_helper
INFO - 2024-03-02 05:01:50 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:01:50 --> Database Driver Class Initialized
INFO - 2024-03-02 05:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:01:50 --> Parser Class Initialized
INFO - 2024-03-02 05:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:01:50 --> Pagination Class Initialized
INFO - 2024-03-02 05:01:50 --> Form Validation Class Initialized
INFO - 2024-03-02 05:01:50 --> Controller Class Initialized
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
DEBUG - 2024-03-02 05:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
DEBUG - 2024-03-02 05:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
DEBUG - 2024-03-02 05:01:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
INFO - 2024-03-02 05:01:50 --> Model Class Initialized
INFO - 2024-03-02 05:01:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:01:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:01:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:01:51 --> Model Class Initialized
INFO - 2024-03-02 05:01:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:01:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:01:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:01:51 --> Final output sent to browser
DEBUG - 2024-03-02 05:01:51 --> Total execution time: 0.2488
ERROR - 2024-03-02 05:01:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:01:56 --> Config Class Initialized
INFO - 2024-03-02 05:01:56 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:01:56 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:01:56 --> Utf8 Class Initialized
INFO - 2024-03-02 05:01:56 --> URI Class Initialized
INFO - 2024-03-02 05:01:56 --> Router Class Initialized
INFO - 2024-03-02 05:01:56 --> Output Class Initialized
INFO - 2024-03-02 05:01:56 --> Security Class Initialized
DEBUG - 2024-03-02 05:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:01:56 --> Input Class Initialized
INFO - 2024-03-02 05:01:56 --> Language Class Initialized
INFO - 2024-03-02 05:01:56 --> Loader Class Initialized
INFO - 2024-03-02 05:01:56 --> Helper loaded: url_helper
INFO - 2024-03-02 05:01:56 --> Helper loaded: file_helper
INFO - 2024-03-02 05:01:56 --> Helper loaded: html_helper
INFO - 2024-03-02 05:01:56 --> Helper loaded: text_helper
INFO - 2024-03-02 05:01:56 --> Helper loaded: form_helper
INFO - 2024-03-02 05:01:56 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:01:56 --> Helper loaded: security_helper
INFO - 2024-03-02 05:01:56 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:01:56 --> Database Driver Class Initialized
INFO - 2024-03-02 05:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:01:56 --> Parser Class Initialized
INFO - 2024-03-02 05:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:01:56 --> Pagination Class Initialized
INFO - 2024-03-02 05:01:56 --> Form Validation Class Initialized
INFO - 2024-03-02 05:01:56 --> Controller Class Initialized
INFO - 2024-03-02 05:01:56 --> Model Class Initialized
DEBUG - 2024-03-02 05:01:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:56 --> Model Class Initialized
DEBUG - 2024-03-02 05:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:56 --> Model Class Initialized
INFO - 2024-03-02 05:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:01:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:01:56 --> Model Class Initialized
INFO - 2024-03-02 05:01:56 --> Model Class Initialized
INFO - 2024-03-02 05:01:56 --> Model Class Initialized
INFO - 2024-03-02 05:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:01:56 --> Final output sent to browser
DEBUG - 2024-03-02 05:01:56 --> Total execution time: 0.1610
ERROR - 2024-03-02 05:01:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:01:57 --> Config Class Initialized
INFO - 2024-03-02 05:01:57 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:01:57 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:01:57 --> Utf8 Class Initialized
INFO - 2024-03-02 05:01:57 --> URI Class Initialized
INFO - 2024-03-02 05:01:57 --> Router Class Initialized
INFO - 2024-03-02 05:01:57 --> Output Class Initialized
INFO - 2024-03-02 05:01:57 --> Security Class Initialized
DEBUG - 2024-03-02 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:01:57 --> Input Class Initialized
INFO - 2024-03-02 05:01:57 --> Language Class Initialized
INFO - 2024-03-02 05:01:57 --> Loader Class Initialized
INFO - 2024-03-02 05:01:57 --> Helper loaded: url_helper
INFO - 2024-03-02 05:01:57 --> Helper loaded: file_helper
INFO - 2024-03-02 05:01:57 --> Helper loaded: html_helper
INFO - 2024-03-02 05:01:57 --> Helper loaded: text_helper
INFO - 2024-03-02 05:01:57 --> Helper loaded: form_helper
INFO - 2024-03-02 05:01:57 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:01:57 --> Helper loaded: security_helper
INFO - 2024-03-02 05:01:57 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:01:57 --> Database Driver Class Initialized
INFO - 2024-03-02 05:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:01:57 --> Parser Class Initialized
INFO - 2024-03-02 05:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:01:57 --> Pagination Class Initialized
INFO - 2024-03-02 05:01:57 --> Form Validation Class Initialized
INFO - 2024-03-02 05:01:57 --> Controller Class Initialized
INFO - 2024-03-02 05:01:57 --> Model Class Initialized
DEBUG - 2024-03-02 05:01:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:57 --> Model Class Initialized
DEBUG - 2024-03-02 05:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:01:57 --> Model Class Initialized
INFO - 2024-03-02 05:01:57 --> Final output sent to browser
DEBUG - 2024-03-02 05:01:57 --> Total execution time: 0.0442
ERROR - 2024-03-02 05:02:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:02 --> Config Class Initialized
INFO - 2024-03-02 05:02:02 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:02 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:02 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:02 --> URI Class Initialized
DEBUG - 2024-03-02 05:02:02 --> No URI present. Default controller set.
INFO - 2024-03-02 05:02:02 --> Router Class Initialized
INFO - 2024-03-02 05:02:02 --> Output Class Initialized
INFO - 2024-03-02 05:02:02 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:02 --> Input Class Initialized
INFO - 2024-03-02 05:02:02 --> Language Class Initialized
INFO - 2024-03-02 05:02:02 --> Loader Class Initialized
INFO - 2024-03-02 05:02:02 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:02 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:02 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:02 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:02 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:02 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:02 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:02 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:02 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:02 --> Parser Class Initialized
INFO - 2024-03-02 05:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:02 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:02 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:02 --> Controller Class Initialized
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
INFO - 2024-03-02 05:02:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:02:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:02:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:02:02 --> Model Class Initialized
INFO - 2024-03-02 05:02:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:02:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:02:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:02:03 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:03 --> Total execution time: 0.2725
ERROR - 2024-03-02 05:02:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:06 --> Config Class Initialized
INFO - 2024-03-02 05:02:06 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:06 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:06 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:06 --> URI Class Initialized
INFO - 2024-03-02 05:02:06 --> Router Class Initialized
INFO - 2024-03-02 05:02:06 --> Output Class Initialized
INFO - 2024-03-02 05:02:06 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:06 --> Input Class Initialized
INFO - 2024-03-02 05:02:06 --> Language Class Initialized
INFO - 2024-03-02 05:02:06 --> Loader Class Initialized
INFO - 2024-03-02 05:02:06 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:06 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:06 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:06 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:06 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:06 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:06 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:06 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:06 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:06 --> Parser Class Initialized
INFO - 2024-03-02 05:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:06 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:06 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:06 --> Controller Class Initialized
INFO - 2024-03-02 05:02:06 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:06 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:06 --> Model Class Initialized
INFO - 2024-03-02 05:02:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:02:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:02:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:02:06 --> Model Class Initialized
INFO - 2024-03-02 05:02:06 --> Model Class Initialized
INFO - 2024-03-02 05:02:06 --> Model Class Initialized
INFO - 2024-03-02 05:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:02:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:02:07 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:07 --> Total execution time: 0.1569
ERROR - 2024-03-02 05:02:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:07 --> Config Class Initialized
INFO - 2024-03-02 05:02:07 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:07 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:07 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:07 --> URI Class Initialized
INFO - 2024-03-02 05:02:07 --> Router Class Initialized
INFO - 2024-03-02 05:02:07 --> Output Class Initialized
INFO - 2024-03-02 05:02:07 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:07 --> Input Class Initialized
INFO - 2024-03-02 05:02:07 --> Language Class Initialized
INFO - 2024-03-02 05:02:07 --> Loader Class Initialized
INFO - 2024-03-02 05:02:07 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:07 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:07 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:07 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:07 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:07 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:07 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:07 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:07 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:07 --> Parser Class Initialized
INFO - 2024-03-02 05:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:07 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:07 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:07 --> Controller Class Initialized
INFO - 2024-03-02 05:02:07 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:07 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:07 --> Model Class Initialized
INFO - 2024-03-02 05:02:07 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:07 --> Total execution time: 0.0426
ERROR - 2024-03-02 05:02:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:20 --> Config Class Initialized
INFO - 2024-03-02 05:02:20 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:20 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:20 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:20 --> URI Class Initialized
DEBUG - 2024-03-02 05:02:20 --> No URI present. Default controller set.
INFO - 2024-03-02 05:02:20 --> Router Class Initialized
INFO - 2024-03-02 05:02:20 --> Output Class Initialized
INFO - 2024-03-02 05:02:20 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:20 --> Input Class Initialized
INFO - 2024-03-02 05:02:20 --> Language Class Initialized
INFO - 2024-03-02 05:02:20 --> Loader Class Initialized
INFO - 2024-03-02 05:02:20 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:20 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:20 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:20 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:20 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:20 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:20 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:20 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:20 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:20 --> Parser Class Initialized
INFO - 2024-03-02 05:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:20 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:20 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:20 --> Controller Class Initialized
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
INFO - 2024-03-02 05:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:02:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:02:20 --> Model Class Initialized
INFO - 2024-03-02 05:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:02:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:02:20 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:20 --> Total execution time: 0.2567
ERROR - 2024-03-02 05:02:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:27 --> Config Class Initialized
INFO - 2024-03-02 05:02:27 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:27 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:27 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:27 --> URI Class Initialized
INFO - 2024-03-02 05:02:27 --> Router Class Initialized
INFO - 2024-03-02 05:02:27 --> Output Class Initialized
INFO - 2024-03-02 05:02:27 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:27 --> Input Class Initialized
INFO - 2024-03-02 05:02:27 --> Language Class Initialized
INFO - 2024-03-02 05:02:27 --> Loader Class Initialized
INFO - 2024-03-02 05:02:27 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:27 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:27 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:27 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:27 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:27 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:27 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:27 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:27 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:27 --> Parser Class Initialized
INFO - 2024-03-02 05:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:27 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:27 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:27 --> Controller Class Initialized
INFO - 2024-03-02 05:02:27 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:27 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:27 --> Model Class Initialized
INFO - 2024-03-02 05:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-02 05:02:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:02:27 --> Model Class Initialized
INFO - 2024-03-02 05:02:27 --> Model Class Initialized
INFO - 2024-03-02 05:02:27 --> Model Class Initialized
INFO - 2024-03-02 05:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:02:27 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:27 --> Total execution time: 0.1791
ERROR - 2024-03-02 05:02:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:36 --> Config Class Initialized
INFO - 2024-03-02 05:02:36 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:36 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:36 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:36 --> URI Class Initialized
INFO - 2024-03-02 05:02:36 --> Router Class Initialized
INFO - 2024-03-02 05:02:36 --> Output Class Initialized
INFO - 2024-03-02 05:02:36 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:36 --> Input Class Initialized
INFO - 2024-03-02 05:02:36 --> Language Class Initialized
INFO - 2024-03-02 05:02:36 --> Loader Class Initialized
INFO - 2024-03-02 05:02:36 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:36 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:36 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:36 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:36 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:36 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:36 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:36 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:36 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:36 --> Parser Class Initialized
INFO - 2024-03-02 05:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:36 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:36 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:36 --> Controller Class Initialized
INFO - 2024-03-02 05:02:36 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:36 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:36 --> Total execution time: 0.0159
ERROR - 2024-03-02 05:02:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:40 --> Config Class Initialized
INFO - 2024-03-02 05:02:40 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:40 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:40 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:40 --> URI Class Initialized
INFO - 2024-03-02 05:02:40 --> Router Class Initialized
INFO - 2024-03-02 05:02:40 --> Output Class Initialized
INFO - 2024-03-02 05:02:40 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:40 --> Input Class Initialized
INFO - 2024-03-02 05:02:40 --> Language Class Initialized
INFO - 2024-03-02 05:02:40 --> Loader Class Initialized
INFO - 2024-03-02 05:02:40 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:40 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:40 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:40 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:40 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:40 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:40 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:40 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:40 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:40 --> Parser Class Initialized
INFO - 2024-03-02 05:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:40 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:40 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:40 --> Controller Class Initialized
INFO - 2024-03-02 05:02:40 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:40 --> Total execution time: 0.0134
ERROR - 2024-03-02 05:02:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:46 --> Config Class Initialized
INFO - 2024-03-02 05:02:46 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:46 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:46 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:46 --> URI Class Initialized
INFO - 2024-03-02 05:02:46 --> Router Class Initialized
INFO - 2024-03-02 05:02:46 --> Output Class Initialized
INFO - 2024-03-02 05:02:46 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:46 --> Input Class Initialized
INFO - 2024-03-02 05:02:46 --> Language Class Initialized
INFO - 2024-03-02 05:02:46 --> Loader Class Initialized
INFO - 2024-03-02 05:02:46 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:46 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:46 --> Parser Class Initialized
INFO - 2024-03-02 05:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:46 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:46 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:46 --> Controller Class Initialized
INFO - 2024-03-02 05:02:46 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:46 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:46 --> Model Class Initialized
INFO - 2024-03-02 05:02:46 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:46 --> Total execution time: 0.1301
ERROR - 2024-03-02 05:02:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:46 --> Config Class Initialized
INFO - 2024-03-02 05:02:46 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:46 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:46 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:46 --> URI Class Initialized
INFO - 2024-03-02 05:02:46 --> Router Class Initialized
INFO - 2024-03-02 05:02:46 --> Output Class Initialized
INFO - 2024-03-02 05:02:46 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:46 --> Input Class Initialized
INFO - 2024-03-02 05:02:46 --> Language Class Initialized
INFO - 2024-03-02 05:02:46 --> Loader Class Initialized
INFO - 2024-03-02 05:02:46 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:46 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:46 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:46 --> Parser Class Initialized
INFO - 2024-03-02 05:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:46 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:46 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:46 --> Controller Class Initialized
INFO - 2024-03-02 05:02:46 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:46 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:46 --> Model Class Initialized
INFO - 2024-03-02 05:02:47 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:47 --> Total execution time: 0.1313
ERROR - 2024-03-02 05:02:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:47 --> Config Class Initialized
INFO - 2024-03-02 05:02:47 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:47 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:47 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:47 --> URI Class Initialized
INFO - 2024-03-02 05:02:47 --> Router Class Initialized
INFO - 2024-03-02 05:02:47 --> Output Class Initialized
INFO - 2024-03-02 05:02:47 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:47 --> Input Class Initialized
INFO - 2024-03-02 05:02:47 --> Language Class Initialized
INFO - 2024-03-02 05:02:47 --> Loader Class Initialized
INFO - 2024-03-02 05:02:47 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:47 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:47 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:47 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:47 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:47 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:47 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:47 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:47 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:47 --> Parser Class Initialized
INFO - 2024-03-02 05:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:47 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:47 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:47 --> Controller Class Initialized
INFO - 2024-03-02 05:02:47 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:47 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:47 --> Model Class Initialized
INFO - 2024-03-02 05:02:47 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:47 --> Total execution time: 0.1323
ERROR - 2024-03-02 05:02:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:54 --> Config Class Initialized
INFO - 2024-03-02 05:02:54 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:54 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:54 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:54 --> URI Class Initialized
INFO - 2024-03-02 05:02:54 --> Router Class Initialized
INFO - 2024-03-02 05:02:54 --> Output Class Initialized
INFO - 2024-03-02 05:02:54 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:54 --> Input Class Initialized
INFO - 2024-03-02 05:02:54 --> Language Class Initialized
INFO - 2024-03-02 05:02:54 --> Loader Class Initialized
INFO - 2024-03-02 05:02:54 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:54 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:54 --> Parser Class Initialized
INFO - 2024-03-02 05:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:54 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:54 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:54 --> Controller Class Initialized
INFO - 2024-03-02 05:02:54 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:54 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:54 --> Model Class Initialized
INFO - 2024-03-02 05:02:54 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:54 --> Total execution time: 0.0455
ERROR - 2024-03-02 05:02:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:54 --> Config Class Initialized
INFO - 2024-03-02 05:02:54 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:54 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:54 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:54 --> URI Class Initialized
INFO - 2024-03-02 05:02:54 --> Router Class Initialized
INFO - 2024-03-02 05:02:54 --> Output Class Initialized
INFO - 2024-03-02 05:02:54 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:54 --> Input Class Initialized
INFO - 2024-03-02 05:02:54 --> Language Class Initialized
INFO - 2024-03-02 05:02:54 --> Loader Class Initialized
INFO - 2024-03-02 05:02:54 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:54 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:54 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:54 --> Parser Class Initialized
INFO - 2024-03-02 05:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:54 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:54 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:54 --> Controller Class Initialized
INFO - 2024-03-02 05:02:54 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:54 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:54 --> Model Class Initialized
INFO - 2024-03-02 05:02:54 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:54 --> Total execution time: 0.0261
ERROR - 2024-03-02 05:02:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:02:57 --> Config Class Initialized
INFO - 2024-03-02 05:02:57 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:02:57 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:02:57 --> Utf8 Class Initialized
INFO - 2024-03-02 05:02:57 --> URI Class Initialized
INFO - 2024-03-02 05:02:57 --> Router Class Initialized
INFO - 2024-03-02 05:02:57 --> Output Class Initialized
INFO - 2024-03-02 05:02:57 --> Security Class Initialized
DEBUG - 2024-03-02 05:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:02:57 --> Input Class Initialized
INFO - 2024-03-02 05:02:57 --> Language Class Initialized
INFO - 2024-03-02 05:02:57 --> Loader Class Initialized
INFO - 2024-03-02 05:02:57 --> Helper loaded: url_helper
INFO - 2024-03-02 05:02:57 --> Helper loaded: file_helper
INFO - 2024-03-02 05:02:57 --> Helper loaded: html_helper
INFO - 2024-03-02 05:02:57 --> Helper loaded: text_helper
INFO - 2024-03-02 05:02:57 --> Helper loaded: form_helper
INFO - 2024-03-02 05:02:57 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:02:57 --> Helper loaded: security_helper
INFO - 2024-03-02 05:02:57 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:02:57 --> Database Driver Class Initialized
INFO - 2024-03-02 05:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:02:57 --> Parser Class Initialized
INFO - 2024-03-02 05:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:02:57 --> Pagination Class Initialized
INFO - 2024-03-02 05:02:57 --> Form Validation Class Initialized
INFO - 2024-03-02 05:02:57 --> Controller Class Initialized
INFO - 2024-03-02 05:02:57 --> Model Class Initialized
DEBUG - 2024-03-02 05:02:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:02:57 --> Model Class Initialized
INFO - 2024-03-02 05:02:57 --> Model Class Initialized
INFO - 2024-03-02 05:02:57 --> Final output sent to browser
DEBUG - 2024-03-02 05:02:57 --> Total execution time: 0.0198
ERROR - 2024-03-02 05:03:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:03:06 --> Config Class Initialized
INFO - 2024-03-02 05:03:06 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:03:06 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:03:06 --> Utf8 Class Initialized
INFO - 2024-03-02 05:03:06 --> URI Class Initialized
INFO - 2024-03-02 05:03:06 --> Router Class Initialized
INFO - 2024-03-02 05:03:06 --> Output Class Initialized
INFO - 2024-03-02 05:03:06 --> Security Class Initialized
DEBUG - 2024-03-02 05:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:03:06 --> Input Class Initialized
INFO - 2024-03-02 05:03:06 --> Language Class Initialized
INFO - 2024-03-02 05:03:06 --> Loader Class Initialized
INFO - 2024-03-02 05:03:06 --> Helper loaded: url_helper
INFO - 2024-03-02 05:03:06 --> Helper loaded: file_helper
INFO - 2024-03-02 05:03:06 --> Helper loaded: html_helper
INFO - 2024-03-02 05:03:06 --> Helper loaded: text_helper
INFO - 2024-03-02 05:03:06 --> Helper loaded: form_helper
INFO - 2024-03-02 05:03:06 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:03:06 --> Helper loaded: security_helper
INFO - 2024-03-02 05:03:06 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:03:06 --> Database Driver Class Initialized
INFO - 2024-03-02 05:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:03:06 --> Parser Class Initialized
INFO - 2024-03-02 05:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:03:06 --> Pagination Class Initialized
INFO - 2024-03-02 05:03:06 --> Form Validation Class Initialized
INFO - 2024-03-02 05:03:06 --> Controller Class Initialized
INFO - 2024-03-02 05:03:06 --> Model Class Initialized
DEBUG - 2024-03-02 05:03:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:03:06 --> Model Class Initialized
INFO - 2024-03-02 05:03:06 --> Final output sent to browser
DEBUG - 2024-03-02 05:03:06 --> Total execution time: 0.0195
ERROR - 2024-03-02 05:03:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:03:07 --> Config Class Initialized
INFO - 2024-03-02 05:03:07 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:03:07 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:03:07 --> Utf8 Class Initialized
INFO - 2024-03-02 05:03:07 --> URI Class Initialized
INFO - 2024-03-02 05:03:07 --> Router Class Initialized
INFO - 2024-03-02 05:03:07 --> Output Class Initialized
INFO - 2024-03-02 05:03:07 --> Security Class Initialized
DEBUG - 2024-03-02 05:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:03:07 --> Input Class Initialized
INFO - 2024-03-02 05:03:07 --> Language Class Initialized
INFO - 2024-03-02 05:03:07 --> Loader Class Initialized
INFO - 2024-03-02 05:03:07 --> Helper loaded: url_helper
INFO - 2024-03-02 05:03:07 --> Helper loaded: file_helper
INFO - 2024-03-02 05:03:07 --> Helper loaded: html_helper
INFO - 2024-03-02 05:03:07 --> Helper loaded: text_helper
INFO - 2024-03-02 05:03:07 --> Helper loaded: form_helper
INFO - 2024-03-02 05:03:07 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:03:07 --> Helper loaded: security_helper
INFO - 2024-03-02 05:03:07 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:03:07 --> Database Driver Class Initialized
INFO - 2024-03-02 05:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:03:07 --> Parser Class Initialized
INFO - 2024-03-02 05:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:03:07 --> Pagination Class Initialized
INFO - 2024-03-02 05:03:07 --> Form Validation Class Initialized
INFO - 2024-03-02 05:03:07 --> Controller Class Initialized
INFO - 2024-03-02 05:03:07 --> Model Class Initialized
DEBUG - 2024-03-02 05:03:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:03:07 --> Model Class Initialized
INFO - 2024-03-02 05:03:07 --> Final output sent to browser
DEBUG - 2024-03-02 05:03:07 --> Total execution time: 0.0164
ERROR - 2024-03-02 05:03:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:03:10 --> Config Class Initialized
INFO - 2024-03-02 05:03:10 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:03:10 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:03:10 --> Utf8 Class Initialized
INFO - 2024-03-02 05:03:10 --> URI Class Initialized
INFO - 2024-03-02 05:03:10 --> Router Class Initialized
INFO - 2024-03-02 05:03:10 --> Output Class Initialized
INFO - 2024-03-02 05:03:10 --> Security Class Initialized
DEBUG - 2024-03-02 05:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:03:10 --> Input Class Initialized
INFO - 2024-03-02 05:03:10 --> Language Class Initialized
INFO - 2024-03-02 05:03:10 --> Loader Class Initialized
INFO - 2024-03-02 05:03:10 --> Helper loaded: url_helper
INFO - 2024-03-02 05:03:10 --> Helper loaded: file_helper
INFO - 2024-03-02 05:03:10 --> Helper loaded: html_helper
INFO - 2024-03-02 05:03:10 --> Helper loaded: text_helper
INFO - 2024-03-02 05:03:10 --> Helper loaded: form_helper
INFO - 2024-03-02 05:03:10 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:03:10 --> Helper loaded: security_helper
INFO - 2024-03-02 05:03:10 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:03:10 --> Database Driver Class Initialized
INFO - 2024-03-02 05:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:03:10 --> Parser Class Initialized
INFO - 2024-03-02 05:03:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:03:10 --> Pagination Class Initialized
INFO - 2024-03-02 05:03:10 --> Form Validation Class Initialized
INFO - 2024-03-02 05:03:10 --> Controller Class Initialized
INFO - 2024-03-02 05:03:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:03:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:03:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:03:10 --> Model Class Initialized
INFO - 2024-03-02 05:03:10 --> Final output sent to browser
DEBUG - 2024-03-02 05:03:10 --> Total execution time: 0.0190
ERROR - 2024-03-02 05:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:03:12 --> Config Class Initialized
INFO - 2024-03-02 05:03:12 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:03:12 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:03:12 --> Utf8 Class Initialized
INFO - 2024-03-02 05:03:12 --> URI Class Initialized
INFO - 2024-03-02 05:03:12 --> Router Class Initialized
INFO - 2024-03-02 05:03:12 --> Output Class Initialized
INFO - 2024-03-02 05:03:12 --> Security Class Initialized
DEBUG - 2024-03-02 05:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:03:12 --> Input Class Initialized
INFO - 2024-03-02 05:03:12 --> Language Class Initialized
INFO - 2024-03-02 05:03:12 --> Loader Class Initialized
INFO - 2024-03-02 05:03:12 --> Helper loaded: url_helper
INFO - 2024-03-02 05:03:12 --> Helper loaded: file_helper
INFO - 2024-03-02 05:03:12 --> Helper loaded: html_helper
INFO - 2024-03-02 05:03:12 --> Helper loaded: text_helper
INFO - 2024-03-02 05:03:12 --> Helper loaded: form_helper
INFO - 2024-03-02 05:03:12 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:03:12 --> Helper loaded: security_helper
INFO - 2024-03-02 05:03:12 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:03:12 --> Database Driver Class Initialized
INFO - 2024-03-02 05:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:03:12 --> Parser Class Initialized
INFO - 2024-03-02 05:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:03:12 --> Pagination Class Initialized
INFO - 2024-03-02 05:03:12 --> Form Validation Class Initialized
INFO - 2024-03-02 05:03:12 --> Controller Class Initialized
INFO - 2024-03-02 05:03:12 --> Model Class Initialized
DEBUG - 2024-03-02 05:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:03:12 --> Model Class Initialized
INFO - 2024-03-02 05:03:12 --> Final output sent to browser
DEBUG - 2024-03-02 05:03:12 --> Total execution time: 0.0179
ERROR - 2024-03-02 05:03:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:03:28 --> Config Class Initialized
INFO - 2024-03-02 05:03:28 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:03:28 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:03:28 --> Utf8 Class Initialized
INFO - 2024-03-02 05:03:28 --> URI Class Initialized
INFO - 2024-03-02 05:03:28 --> Router Class Initialized
INFO - 2024-03-02 05:03:28 --> Output Class Initialized
INFO - 2024-03-02 05:03:28 --> Security Class Initialized
DEBUG - 2024-03-02 05:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:03:28 --> Input Class Initialized
INFO - 2024-03-02 05:03:28 --> Language Class Initialized
INFO - 2024-03-02 05:03:28 --> Loader Class Initialized
INFO - 2024-03-02 05:03:28 --> Helper loaded: url_helper
INFO - 2024-03-02 05:03:28 --> Helper loaded: file_helper
INFO - 2024-03-02 05:03:28 --> Helper loaded: html_helper
INFO - 2024-03-02 05:03:28 --> Helper loaded: text_helper
INFO - 2024-03-02 05:03:28 --> Helper loaded: form_helper
INFO - 2024-03-02 05:03:28 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:03:28 --> Helper loaded: security_helper
INFO - 2024-03-02 05:03:28 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:03:28 --> Database Driver Class Initialized
INFO - 2024-03-02 05:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:03:28 --> Parser Class Initialized
INFO - 2024-03-02 05:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:03:28 --> Pagination Class Initialized
INFO - 2024-03-02 05:03:28 --> Form Validation Class Initialized
INFO - 2024-03-02 05:03:28 --> Controller Class Initialized
INFO - 2024-03-02 05:03:28 --> Model Class Initialized
DEBUG - 2024-03-02 05:03:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:03:28 --> Model Class Initialized
DEBUG - 2024-03-02 05:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:03:28 --> Model Class Initialized
INFO - 2024-03-02 05:03:28 --> Email Class Initialized
DEBUG - 2024-03-02 05:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:03:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:03:28 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-02 05:03:28 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-02 05:03:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-02 05:03:28 --> Final output sent to browser
DEBUG - 2024-03-02 05:03:28 --> Total execution time: 0.2332
ERROR - 2024-03-02 05:06:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:06:10 --> Config Class Initialized
INFO - 2024-03-02 05:06:10 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:06:10 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:06:10 --> Utf8 Class Initialized
INFO - 2024-03-02 05:06:10 --> URI Class Initialized
INFO - 2024-03-02 05:06:10 --> Router Class Initialized
INFO - 2024-03-02 05:06:10 --> Output Class Initialized
INFO - 2024-03-02 05:06:10 --> Security Class Initialized
DEBUG - 2024-03-02 05:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:06:10 --> Input Class Initialized
INFO - 2024-03-02 05:06:10 --> Language Class Initialized
INFO - 2024-03-02 05:06:10 --> Loader Class Initialized
INFO - 2024-03-02 05:06:10 --> Helper loaded: url_helper
INFO - 2024-03-02 05:06:10 --> Helper loaded: file_helper
INFO - 2024-03-02 05:06:10 --> Helper loaded: html_helper
INFO - 2024-03-02 05:06:10 --> Helper loaded: text_helper
INFO - 2024-03-02 05:06:10 --> Helper loaded: form_helper
INFO - 2024-03-02 05:06:10 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:06:10 --> Helper loaded: security_helper
INFO - 2024-03-02 05:06:10 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:06:10 --> Database Driver Class Initialized
INFO - 2024-03-02 05:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:06:10 --> Parser Class Initialized
INFO - 2024-03-02 05:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:06:10 --> Pagination Class Initialized
INFO - 2024-03-02 05:06:10 --> Form Validation Class Initialized
INFO - 2024-03-02 05:06:10 --> Controller Class Initialized
INFO - 2024-03-02 05:06:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:10 --> Model Class Initialized
INFO - 2024-03-02 05:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-02 05:06:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:06:10 --> Model Class Initialized
INFO - 2024-03-02 05:06:10 --> Model Class Initialized
INFO - 2024-03-02 05:06:10 --> Model Class Initialized
INFO - 2024-03-02 05:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:06:10 --> Final output sent to browser
DEBUG - 2024-03-02 05:06:10 --> Total execution time: 0.1865
ERROR - 2024-03-02 05:06:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:06:11 --> Config Class Initialized
INFO - 2024-03-02 05:06:11 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:06:11 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:06:11 --> Utf8 Class Initialized
INFO - 2024-03-02 05:06:11 --> URI Class Initialized
DEBUG - 2024-03-02 05:06:11 --> No URI present. Default controller set.
INFO - 2024-03-02 05:06:11 --> Router Class Initialized
INFO - 2024-03-02 05:06:11 --> Output Class Initialized
INFO - 2024-03-02 05:06:11 --> Security Class Initialized
DEBUG - 2024-03-02 05:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:06:11 --> Input Class Initialized
INFO - 2024-03-02 05:06:11 --> Language Class Initialized
INFO - 2024-03-02 05:06:11 --> Loader Class Initialized
INFO - 2024-03-02 05:06:11 --> Helper loaded: url_helper
INFO - 2024-03-02 05:06:11 --> Helper loaded: file_helper
INFO - 2024-03-02 05:06:11 --> Helper loaded: html_helper
INFO - 2024-03-02 05:06:11 --> Helper loaded: text_helper
INFO - 2024-03-02 05:06:11 --> Helper loaded: form_helper
INFO - 2024-03-02 05:06:11 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:06:11 --> Helper loaded: security_helper
INFO - 2024-03-02 05:06:11 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:06:11 --> Database Driver Class Initialized
INFO - 2024-03-02 05:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:06:11 --> Parser Class Initialized
INFO - 2024-03-02 05:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:06:11 --> Pagination Class Initialized
INFO - 2024-03-02 05:06:11 --> Form Validation Class Initialized
INFO - 2024-03-02 05:06:11 --> Controller Class Initialized
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
INFO - 2024-03-02 05:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:06:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:06:11 --> Model Class Initialized
INFO - 2024-03-02 05:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:06:11 --> Final output sent to browser
DEBUG - 2024-03-02 05:06:11 --> Total execution time: 0.2541
ERROR - 2024-03-02 05:06:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:06:22 --> Config Class Initialized
INFO - 2024-03-02 05:06:22 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:06:22 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:06:22 --> Utf8 Class Initialized
INFO - 2024-03-02 05:06:22 --> URI Class Initialized
INFO - 2024-03-02 05:06:22 --> Router Class Initialized
INFO - 2024-03-02 05:06:22 --> Output Class Initialized
INFO - 2024-03-02 05:06:22 --> Security Class Initialized
DEBUG - 2024-03-02 05:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:06:22 --> Input Class Initialized
INFO - 2024-03-02 05:06:22 --> Language Class Initialized
INFO - 2024-03-02 05:06:22 --> Loader Class Initialized
INFO - 2024-03-02 05:06:22 --> Helper loaded: url_helper
INFO - 2024-03-02 05:06:22 --> Helper loaded: file_helper
INFO - 2024-03-02 05:06:22 --> Helper loaded: html_helper
INFO - 2024-03-02 05:06:22 --> Helper loaded: text_helper
INFO - 2024-03-02 05:06:22 --> Helper loaded: form_helper
INFO - 2024-03-02 05:06:22 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:06:22 --> Helper loaded: security_helper
INFO - 2024-03-02 05:06:22 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:06:22 --> Database Driver Class Initialized
INFO - 2024-03-02 05:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:06:22 --> Parser Class Initialized
INFO - 2024-03-02 05:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:06:22 --> Pagination Class Initialized
INFO - 2024-03-02 05:06:22 --> Form Validation Class Initialized
INFO - 2024-03-02 05:06:22 --> Controller Class Initialized
INFO - 2024-03-02 05:06:22 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:22 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:22 --> Model Class Initialized
INFO - 2024-03-02 05:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:06:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:06:22 --> Model Class Initialized
INFO - 2024-03-02 05:06:22 --> Model Class Initialized
INFO - 2024-03-02 05:06:22 --> Model Class Initialized
INFO - 2024-03-02 05:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:06:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:06:22 --> Final output sent to browser
DEBUG - 2024-03-02 05:06:22 --> Total execution time: 0.1608
ERROR - 2024-03-02 05:06:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:06:23 --> Config Class Initialized
INFO - 2024-03-02 05:06:23 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:06:23 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:06:23 --> Utf8 Class Initialized
INFO - 2024-03-02 05:06:23 --> URI Class Initialized
INFO - 2024-03-02 05:06:23 --> Router Class Initialized
INFO - 2024-03-02 05:06:23 --> Output Class Initialized
INFO - 2024-03-02 05:06:23 --> Security Class Initialized
DEBUG - 2024-03-02 05:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:06:23 --> Input Class Initialized
INFO - 2024-03-02 05:06:23 --> Language Class Initialized
INFO - 2024-03-02 05:06:23 --> Loader Class Initialized
INFO - 2024-03-02 05:06:23 --> Helper loaded: url_helper
INFO - 2024-03-02 05:06:23 --> Helper loaded: file_helper
INFO - 2024-03-02 05:06:23 --> Helper loaded: html_helper
INFO - 2024-03-02 05:06:23 --> Helper loaded: text_helper
INFO - 2024-03-02 05:06:23 --> Helper loaded: form_helper
INFO - 2024-03-02 05:06:23 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:06:23 --> Helper loaded: security_helper
INFO - 2024-03-02 05:06:23 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:06:23 --> Database Driver Class Initialized
INFO - 2024-03-02 05:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:06:23 --> Parser Class Initialized
INFO - 2024-03-02 05:06:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:06:23 --> Pagination Class Initialized
INFO - 2024-03-02 05:06:23 --> Form Validation Class Initialized
INFO - 2024-03-02 05:06:23 --> Controller Class Initialized
INFO - 2024-03-02 05:06:23 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:23 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:23 --> Model Class Initialized
INFO - 2024-03-02 05:06:23 --> Final output sent to browser
DEBUG - 2024-03-02 05:06:23 --> Total execution time: 0.0483
ERROR - 2024-03-02 05:06:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:06:28 --> Config Class Initialized
INFO - 2024-03-02 05:06:28 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:06:28 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:06:28 --> Utf8 Class Initialized
INFO - 2024-03-02 05:06:28 --> URI Class Initialized
INFO - 2024-03-02 05:06:28 --> Router Class Initialized
INFO - 2024-03-02 05:06:28 --> Output Class Initialized
INFO - 2024-03-02 05:06:28 --> Security Class Initialized
DEBUG - 2024-03-02 05:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:06:28 --> Input Class Initialized
INFO - 2024-03-02 05:06:28 --> Language Class Initialized
INFO - 2024-03-02 05:06:28 --> Loader Class Initialized
INFO - 2024-03-02 05:06:28 --> Helper loaded: url_helper
INFO - 2024-03-02 05:06:28 --> Helper loaded: file_helper
INFO - 2024-03-02 05:06:28 --> Helper loaded: html_helper
INFO - 2024-03-02 05:06:28 --> Helper loaded: text_helper
INFO - 2024-03-02 05:06:28 --> Helper loaded: form_helper
INFO - 2024-03-02 05:06:28 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:06:28 --> Helper loaded: security_helper
INFO - 2024-03-02 05:06:28 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:06:28 --> Database Driver Class Initialized
INFO - 2024-03-02 05:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:06:28 --> Parser Class Initialized
INFO - 2024-03-02 05:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:06:28 --> Pagination Class Initialized
INFO - 2024-03-02 05:06:28 --> Form Validation Class Initialized
INFO - 2024-03-02 05:06:28 --> Controller Class Initialized
INFO - 2024-03-02 05:06:28 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:28 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:28 --> Model Class Initialized
DEBUG - 2024-03-02 05:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-02 05:06:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:06:28 --> Model Class Initialized
INFO - 2024-03-02 05:06:28 --> Model Class Initialized
INFO - 2024-03-02 05:06:28 --> Model Class Initialized
INFO - 2024-03-02 05:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:06:28 --> Final output sent to browser
DEBUG - 2024-03-02 05:06:28 --> Total execution time: 0.1677
ERROR - 2024-03-02 05:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:11:12 --> Config Class Initialized
INFO - 2024-03-02 05:11:12 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:11:12 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:11:12 --> Utf8 Class Initialized
INFO - 2024-03-02 05:11:12 --> URI Class Initialized
DEBUG - 2024-03-02 05:11:12 --> No URI present. Default controller set.
INFO - 2024-03-02 05:11:12 --> Router Class Initialized
INFO - 2024-03-02 05:11:12 --> Output Class Initialized
INFO - 2024-03-02 05:11:12 --> Security Class Initialized
DEBUG - 2024-03-02 05:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:11:12 --> Input Class Initialized
INFO - 2024-03-02 05:11:12 --> Language Class Initialized
INFO - 2024-03-02 05:11:12 --> Loader Class Initialized
INFO - 2024-03-02 05:11:12 --> Helper loaded: url_helper
INFO - 2024-03-02 05:11:12 --> Helper loaded: file_helper
INFO - 2024-03-02 05:11:12 --> Helper loaded: html_helper
INFO - 2024-03-02 05:11:12 --> Helper loaded: text_helper
INFO - 2024-03-02 05:11:12 --> Helper loaded: form_helper
INFO - 2024-03-02 05:11:12 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:11:12 --> Helper loaded: security_helper
INFO - 2024-03-02 05:11:12 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:11:12 --> Database Driver Class Initialized
INFO - 2024-03-02 05:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:11:12 --> Parser Class Initialized
INFO - 2024-03-02 05:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:11:12 --> Pagination Class Initialized
INFO - 2024-03-02 05:11:12 --> Form Validation Class Initialized
INFO - 2024-03-02 05:11:12 --> Controller Class Initialized
INFO - 2024-03-02 05:11:12 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 05:11:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:11:13 --> Config Class Initialized
INFO - 2024-03-02 05:11:13 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:11:13 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:11:13 --> Utf8 Class Initialized
INFO - 2024-03-02 05:11:13 --> URI Class Initialized
INFO - 2024-03-02 05:11:13 --> Router Class Initialized
INFO - 2024-03-02 05:11:13 --> Output Class Initialized
INFO - 2024-03-02 05:11:13 --> Security Class Initialized
DEBUG - 2024-03-02 05:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:11:13 --> Input Class Initialized
INFO - 2024-03-02 05:11:13 --> Language Class Initialized
INFO - 2024-03-02 05:11:13 --> Loader Class Initialized
INFO - 2024-03-02 05:11:13 --> Helper loaded: url_helper
INFO - 2024-03-02 05:11:13 --> Helper loaded: file_helper
INFO - 2024-03-02 05:11:13 --> Helper loaded: html_helper
INFO - 2024-03-02 05:11:13 --> Helper loaded: text_helper
INFO - 2024-03-02 05:11:13 --> Helper loaded: form_helper
INFO - 2024-03-02 05:11:13 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:11:13 --> Helper loaded: security_helper
INFO - 2024-03-02 05:11:13 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:11:13 --> Database Driver Class Initialized
INFO - 2024-03-02 05:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:11:13 --> Parser Class Initialized
INFO - 2024-03-02 05:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:11:13 --> Pagination Class Initialized
INFO - 2024-03-02 05:11:13 --> Form Validation Class Initialized
INFO - 2024-03-02 05:11:13 --> Controller Class Initialized
INFO - 2024-03-02 05:11:13 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 05:11:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:11:13 --> Model Class Initialized
INFO - 2024-03-02 05:11:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:11:13 --> Final output sent to browser
DEBUG - 2024-03-02 05:11:13 --> Total execution time: 0.0310
ERROR - 2024-03-02 05:11:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:11:21 --> Config Class Initialized
INFO - 2024-03-02 05:11:21 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:11:21 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:11:21 --> Utf8 Class Initialized
INFO - 2024-03-02 05:11:21 --> URI Class Initialized
INFO - 2024-03-02 05:11:21 --> Router Class Initialized
INFO - 2024-03-02 05:11:21 --> Output Class Initialized
INFO - 2024-03-02 05:11:21 --> Security Class Initialized
DEBUG - 2024-03-02 05:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:11:21 --> Input Class Initialized
INFO - 2024-03-02 05:11:21 --> Language Class Initialized
INFO - 2024-03-02 05:11:21 --> Loader Class Initialized
INFO - 2024-03-02 05:11:21 --> Helper loaded: url_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: file_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: html_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: text_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: form_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: security_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:11:21 --> Database Driver Class Initialized
INFO - 2024-03-02 05:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:11:21 --> Parser Class Initialized
INFO - 2024-03-02 05:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:11:21 --> Pagination Class Initialized
INFO - 2024-03-02 05:11:21 --> Form Validation Class Initialized
INFO - 2024-03-02 05:11:21 --> Controller Class Initialized
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
INFO - 2024-03-02 05:11:21 --> Final output sent to browser
DEBUG - 2024-03-02 05:11:21 --> Total execution time: 0.0203
ERROR - 2024-03-02 05:11:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:11:21 --> Config Class Initialized
INFO - 2024-03-02 05:11:21 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:11:21 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:11:21 --> Utf8 Class Initialized
INFO - 2024-03-02 05:11:21 --> URI Class Initialized
DEBUG - 2024-03-02 05:11:21 --> No URI present. Default controller set.
INFO - 2024-03-02 05:11:21 --> Router Class Initialized
INFO - 2024-03-02 05:11:21 --> Output Class Initialized
INFO - 2024-03-02 05:11:21 --> Security Class Initialized
DEBUG - 2024-03-02 05:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:11:21 --> Input Class Initialized
INFO - 2024-03-02 05:11:21 --> Language Class Initialized
INFO - 2024-03-02 05:11:21 --> Loader Class Initialized
INFO - 2024-03-02 05:11:21 --> Helper loaded: url_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: file_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: html_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: text_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: form_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: security_helper
INFO - 2024-03-02 05:11:21 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:11:21 --> Database Driver Class Initialized
INFO - 2024-03-02 05:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:11:21 --> Parser Class Initialized
INFO - 2024-03-02 05:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:11:21 --> Pagination Class Initialized
INFO - 2024-03-02 05:11:21 --> Form Validation Class Initialized
INFO - 2024-03-02 05:11:21 --> Controller Class Initialized
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
INFO - 2024-03-02 05:11:21 --> Model Class Initialized
INFO - 2024-03-02 05:11:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:11:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:11:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:11:22 --> Model Class Initialized
INFO - 2024-03-02 05:11:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:11:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:11:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:11:22 --> Final output sent to browser
DEBUG - 2024-03-02 05:11:22 --> Total execution time: 0.2286
ERROR - 2024-03-02 05:11:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:11:28 --> Config Class Initialized
INFO - 2024-03-02 05:11:28 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:11:28 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:11:28 --> Utf8 Class Initialized
INFO - 2024-03-02 05:11:28 --> URI Class Initialized
INFO - 2024-03-02 05:11:28 --> Router Class Initialized
INFO - 2024-03-02 05:11:28 --> Output Class Initialized
INFO - 2024-03-02 05:11:28 --> Security Class Initialized
DEBUG - 2024-03-02 05:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:11:28 --> Input Class Initialized
INFO - 2024-03-02 05:11:28 --> Language Class Initialized
INFO - 2024-03-02 05:11:28 --> Loader Class Initialized
INFO - 2024-03-02 05:11:28 --> Helper loaded: url_helper
INFO - 2024-03-02 05:11:28 --> Helper loaded: file_helper
INFO - 2024-03-02 05:11:28 --> Helper loaded: html_helper
INFO - 2024-03-02 05:11:28 --> Helper loaded: text_helper
INFO - 2024-03-02 05:11:28 --> Helper loaded: form_helper
INFO - 2024-03-02 05:11:28 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:11:28 --> Helper loaded: security_helper
INFO - 2024-03-02 05:11:28 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:11:28 --> Database Driver Class Initialized
INFO - 2024-03-02 05:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:11:28 --> Parser Class Initialized
INFO - 2024-03-02 05:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:11:28 --> Pagination Class Initialized
INFO - 2024-03-02 05:11:28 --> Form Validation Class Initialized
INFO - 2024-03-02 05:11:28 --> Controller Class Initialized
INFO - 2024-03-02 05:11:28 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:28 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:28 --> Model Class Initialized
INFO - 2024-03-02 05:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:11:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:11:28 --> Model Class Initialized
INFO - 2024-03-02 05:11:28 --> Model Class Initialized
INFO - 2024-03-02 05:11:28 --> Model Class Initialized
INFO - 2024-03-02 05:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:11:28 --> Final output sent to browser
DEBUG - 2024-03-02 05:11:28 --> Total execution time: 0.1485
ERROR - 2024-03-02 05:11:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:11:30 --> Config Class Initialized
INFO - 2024-03-02 05:11:30 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:11:30 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:11:30 --> Utf8 Class Initialized
INFO - 2024-03-02 05:11:30 --> URI Class Initialized
INFO - 2024-03-02 05:11:30 --> Router Class Initialized
INFO - 2024-03-02 05:11:30 --> Output Class Initialized
INFO - 2024-03-02 05:11:30 --> Security Class Initialized
DEBUG - 2024-03-02 05:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:11:30 --> Input Class Initialized
INFO - 2024-03-02 05:11:30 --> Language Class Initialized
INFO - 2024-03-02 05:11:30 --> Loader Class Initialized
INFO - 2024-03-02 05:11:30 --> Helper loaded: url_helper
INFO - 2024-03-02 05:11:30 --> Helper loaded: file_helper
INFO - 2024-03-02 05:11:30 --> Helper loaded: html_helper
INFO - 2024-03-02 05:11:30 --> Helper loaded: text_helper
INFO - 2024-03-02 05:11:30 --> Helper loaded: form_helper
INFO - 2024-03-02 05:11:30 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:11:30 --> Helper loaded: security_helper
INFO - 2024-03-02 05:11:30 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:11:30 --> Database Driver Class Initialized
INFO - 2024-03-02 05:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:11:30 --> Parser Class Initialized
INFO - 2024-03-02 05:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:11:30 --> Pagination Class Initialized
INFO - 2024-03-02 05:11:30 --> Form Validation Class Initialized
INFO - 2024-03-02 05:11:30 --> Controller Class Initialized
INFO - 2024-03-02 05:11:30 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:30 --> Model Class Initialized
DEBUG - 2024-03-02 05:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:11:30 --> Model Class Initialized
INFO - 2024-03-02 05:11:30 --> Final output sent to browser
DEBUG - 2024-03-02 05:11:30 --> Total execution time: 0.0294
ERROR - 2024-03-02 05:12:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:00 --> Config Class Initialized
INFO - 2024-03-02 05:12:00 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:00 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:00 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:00 --> URI Class Initialized
INFO - 2024-03-02 05:12:00 --> Router Class Initialized
INFO - 2024-03-02 05:12:00 --> Output Class Initialized
INFO - 2024-03-02 05:12:00 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:00 --> Input Class Initialized
INFO - 2024-03-02 05:12:00 --> Language Class Initialized
INFO - 2024-03-02 05:12:00 --> Loader Class Initialized
INFO - 2024-03-02 05:12:00 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:00 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:00 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:00 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:00 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:00 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:00 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:00 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:00 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:00 --> Parser Class Initialized
INFO - 2024-03-02 05:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:00 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:00 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:00 --> Controller Class Initialized
INFO - 2024-03-02 05:12:00 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:00 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:00 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-02 05:12:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:12:00 --> Model Class Initialized
INFO - 2024-03-02 05:12:00 --> Model Class Initialized
INFO - 2024-03-02 05:12:00 --> Model Class Initialized
INFO - 2024-03-02 05:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:12:00 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:00 --> Total execution time: 0.1602
ERROR - 2024-03-02 05:12:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:09 --> Config Class Initialized
INFO - 2024-03-02 05:12:09 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:09 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:09 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:09 --> URI Class Initialized
INFO - 2024-03-02 05:12:09 --> Router Class Initialized
INFO - 2024-03-02 05:12:09 --> Output Class Initialized
INFO - 2024-03-02 05:12:09 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:09 --> Input Class Initialized
INFO - 2024-03-02 05:12:09 --> Language Class Initialized
INFO - 2024-03-02 05:12:09 --> Loader Class Initialized
INFO - 2024-03-02 05:12:09 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:09 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:09 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:09 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:09 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:09 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:09 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:09 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:09 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:09 --> Parser Class Initialized
INFO - 2024-03-02 05:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:09 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:09 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:09 --> Controller Class Initialized
INFO - 2024-03-02 05:12:09 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:09 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:09 --> Model Class Initialized
INFO - 2024-03-02 05:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:12:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:12:09 --> Model Class Initialized
INFO - 2024-03-02 05:12:09 --> Model Class Initialized
INFO - 2024-03-02 05:12:09 --> Model Class Initialized
INFO - 2024-03-02 05:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:12:09 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:09 --> Total execution time: 0.1493
ERROR - 2024-03-02 05:12:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:10 --> Config Class Initialized
INFO - 2024-03-02 05:12:10 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:10 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:10 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:10 --> URI Class Initialized
INFO - 2024-03-02 05:12:10 --> Router Class Initialized
INFO - 2024-03-02 05:12:10 --> Output Class Initialized
INFO - 2024-03-02 05:12:10 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:10 --> Input Class Initialized
INFO - 2024-03-02 05:12:10 --> Language Class Initialized
INFO - 2024-03-02 05:12:10 --> Loader Class Initialized
INFO - 2024-03-02 05:12:10 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:10 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:10 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:10 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:10 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:10 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:10 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:10 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:10 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:10 --> Parser Class Initialized
INFO - 2024-03-02 05:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:10 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:10 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:10 --> Controller Class Initialized
INFO - 2024-03-02 05:12:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:10 --> Model Class Initialized
INFO - 2024-03-02 05:12:10 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:10 --> Total execution time: 0.0296
ERROR - 2024-03-02 05:12:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:12 --> Config Class Initialized
INFO - 2024-03-02 05:12:12 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:12 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:12 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:12 --> URI Class Initialized
INFO - 2024-03-02 05:12:12 --> Router Class Initialized
INFO - 2024-03-02 05:12:12 --> Output Class Initialized
INFO - 2024-03-02 05:12:12 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:12 --> Input Class Initialized
INFO - 2024-03-02 05:12:12 --> Language Class Initialized
INFO - 2024-03-02 05:12:12 --> Loader Class Initialized
INFO - 2024-03-02 05:12:12 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:12 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:12 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:12 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:12 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:12 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:12 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:12 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:12 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:12 --> Parser Class Initialized
INFO - 2024-03-02 05:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:12 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:12 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:12 --> Controller Class Initialized
INFO - 2024-03-02 05:12:12 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:12 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:12 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-02 05:12:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:12:12 --> Model Class Initialized
INFO - 2024-03-02 05:12:12 --> Model Class Initialized
INFO - 2024-03-02 05:12:12 --> Model Class Initialized
INFO - 2024-03-02 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:12:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:12:12 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:12 --> Total execution time: 0.1498
ERROR - 2024-03-02 05:12:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:24 --> Config Class Initialized
INFO - 2024-03-02 05:12:24 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:24 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:24 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:24 --> URI Class Initialized
INFO - 2024-03-02 05:12:24 --> Router Class Initialized
INFO - 2024-03-02 05:12:24 --> Output Class Initialized
INFO - 2024-03-02 05:12:24 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:24 --> Input Class Initialized
INFO - 2024-03-02 05:12:24 --> Language Class Initialized
INFO - 2024-03-02 05:12:24 --> Loader Class Initialized
INFO - 2024-03-02 05:12:24 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:24 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:24 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:24 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:24 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:24 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:24 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:24 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:24 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:24 --> Parser Class Initialized
INFO - 2024-03-02 05:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:24 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:24 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:24 --> Controller Class Initialized
INFO - 2024-03-02 05:12:24 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:24 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:24 --> Model Class Initialized
INFO - 2024-03-02 05:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:12:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:12:24 --> Model Class Initialized
INFO - 2024-03-02 05:12:24 --> Model Class Initialized
INFO - 2024-03-02 05:12:24 --> Model Class Initialized
INFO - 2024-03-02 05:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:12:24 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:24 --> Total execution time: 0.1648
ERROR - 2024-03-02 05:12:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:25 --> Config Class Initialized
INFO - 2024-03-02 05:12:25 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:25 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:25 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:25 --> URI Class Initialized
INFO - 2024-03-02 05:12:25 --> Router Class Initialized
INFO - 2024-03-02 05:12:25 --> Output Class Initialized
INFO - 2024-03-02 05:12:25 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:25 --> Input Class Initialized
INFO - 2024-03-02 05:12:25 --> Language Class Initialized
INFO - 2024-03-02 05:12:25 --> Loader Class Initialized
INFO - 2024-03-02 05:12:25 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:25 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:25 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:25 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:25 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:25 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:25 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:25 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:25 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:25 --> Parser Class Initialized
INFO - 2024-03-02 05:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:25 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:25 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:25 --> Controller Class Initialized
INFO - 2024-03-02 05:12:25 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:25 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:25 --> Model Class Initialized
INFO - 2024-03-02 05:12:25 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:25 --> Total execution time: 0.0273
ERROR - 2024-03-02 05:12:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:27 --> Config Class Initialized
INFO - 2024-03-02 05:12:27 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:27 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:27 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:27 --> URI Class Initialized
INFO - 2024-03-02 05:12:27 --> Router Class Initialized
INFO - 2024-03-02 05:12:27 --> Output Class Initialized
INFO - 2024-03-02 05:12:27 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:27 --> Input Class Initialized
INFO - 2024-03-02 05:12:27 --> Language Class Initialized
INFO - 2024-03-02 05:12:27 --> Loader Class Initialized
INFO - 2024-03-02 05:12:27 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:27 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:27 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:27 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:27 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:27 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:27 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:27 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:27 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:27 --> Parser Class Initialized
INFO - 2024-03-02 05:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:27 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:27 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:27 --> Controller Class Initialized
INFO - 2024-03-02 05:12:27 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:27 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:27 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-02 05:12:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:12:27 --> Model Class Initialized
INFO - 2024-03-02 05:12:27 --> Model Class Initialized
INFO - 2024-03-02 05:12:27 --> Model Class Initialized
INFO - 2024-03-02 05:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:12:27 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:27 --> Total execution time: 0.1740
ERROR - 2024-03-02 05:12:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:37 --> Config Class Initialized
INFO - 2024-03-02 05:12:37 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:37 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:37 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:37 --> URI Class Initialized
INFO - 2024-03-02 05:12:37 --> Router Class Initialized
INFO - 2024-03-02 05:12:37 --> Output Class Initialized
INFO - 2024-03-02 05:12:37 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:37 --> Input Class Initialized
INFO - 2024-03-02 05:12:37 --> Language Class Initialized
INFO - 2024-03-02 05:12:37 --> Loader Class Initialized
INFO - 2024-03-02 05:12:37 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:37 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:37 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:37 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:37 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:37 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:37 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:37 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:37 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:37 --> Parser Class Initialized
INFO - 2024-03-02 05:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:37 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:37 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:37 --> Controller Class Initialized
INFO - 2024-03-02 05:12:37 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:37 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:37 --> Model Class Initialized
INFO - 2024-03-02 05:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:12:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:12:37 --> Model Class Initialized
INFO - 2024-03-02 05:12:37 --> Model Class Initialized
INFO - 2024-03-02 05:12:37 --> Model Class Initialized
INFO - 2024-03-02 05:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:12:37 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:37 --> Total execution time: 0.1541
ERROR - 2024-03-02 05:12:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:39 --> Config Class Initialized
INFO - 2024-03-02 05:12:39 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:39 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:39 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:39 --> URI Class Initialized
INFO - 2024-03-02 05:12:39 --> Router Class Initialized
INFO - 2024-03-02 05:12:39 --> Output Class Initialized
INFO - 2024-03-02 05:12:39 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:39 --> Input Class Initialized
INFO - 2024-03-02 05:12:39 --> Language Class Initialized
INFO - 2024-03-02 05:12:39 --> Loader Class Initialized
INFO - 2024-03-02 05:12:39 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:39 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:39 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:39 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:39 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:39 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:39 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:39 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:39 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:39 --> Parser Class Initialized
INFO - 2024-03-02 05:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:39 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:39 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:39 --> Controller Class Initialized
INFO - 2024-03-02 05:12:39 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:39 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:39 --> Model Class Initialized
INFO - 2024-03-02 05:12:39 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:39 --> Total execution time: 0.0301
ERROR - 2024-03-02 05:12:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:12:51 --> Config Class Initialized
INFO - 2024-03-02 05:12:51 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:12:51 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:12:51 --> Utf8 Class Initialized
INFO - 2024-03-02 05:12:51 --> URI Class Initialized
DEBUG - 2024-03-02 05:12:51 --> No URI present. Default controller set.
INFO - 2024-03-02 05:12:51 --> Router Class Initialized
INFO - 2024-03-02 05:12:51 --> Output Class Initialized
INFO - 2024-03-02 05:12:51 --> Security Class Initialized
DEBUG - 2024-03-02 05:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:12:51 --> Input Class Initialized
INFO - 2024-03-02 05:12:51 --> Language Class Initialized
INFO - 2024-03-02 05:12:51 --> Loader Class Initialized
INFO - 2024-03-02 05:12:51 --> Helper loaded: url_helper
INFO - 2024-03-02 05:12:51 --> Helper loaded: file_helper
INFO - 2024-03-02 05:12:51 --> Helper loaded: html_helper
INFO - 2024-03-02 05:12:51 --> Helper loaded: text_helper
INFO - 2024-03-02 05:12:51 --> Helper loaded: form_helper
INFO - 2024-03-02 05:12:51 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:12:51 --> Helper loaded: security_helper
INFO - 2024-03-02 05:12:51 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:12:51 --> Database Driver Class Initialized
INFO - 2024-03-02 05:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:12:51 --> Parser Class Initialized
INFO - 2024-03-02 05:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:12:51 --> Pagination Class Initialized
INFO - 2024-03-02 05:12:51 --> Form Validation Class Initialized
INFO - 2024-03-02 05:12:51 --> Controller Class Initialized
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
DEBUG - 2024-03-02 05:12:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
INFO - 2024-03-02 05:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:12:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:12:51 --> Model Class Initialized
INFO - 2024-03-02 05:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:12:51 --> Final output sent to browser
DEBUG - 2024-03-02 05:12:51 --> Total execution time: 0.2560
ERROR - 2024-03-02 05:13:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:13:22 --> Config Class Initialized
INFO - 2024-03-02 05:13:22 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:13:22 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:13:22 --> Utf8 Class Initialized
INFO - 2024-03-02 05:13:22 --> URI Class Initialized
INFO - 2024-03-02 05:13:22 --> Router Class Initialized
INFO - 2024-03-02 05:13:22 --> Output Class Initialized
INFO - 2024-03-02 05:13:22 --> Security Class Initialized
DEBUG - 2024-03-02 05:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:13:22 --> Input Class Initialized
INFO - 2024-03-02 05:13:22 --> Language Class Initialized
INFO - 2024-03-02 05:13:22 --> Loader Class Initialized
INFO - 2024-03-02 05:13:22 --> Helper loaded: url_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: file_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: html_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: text_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: form_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: security_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:13:22 --> Database Driver Class Initialized
INFO - 2024-03-02 05:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:13:22 --> Parser Class Initialized
INFO - 2024-03-02 05:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:13:22 --> Pagination Class Initialized
INFO - 2024-03-02 05:13:22 --> Form Validation Class Initialized
INFO - 2024-03-02 05:13:22 --> Controller Class Initialized
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
DEBUG - 2024-03-02 05:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 05:13:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
INFO - 2024-03-02 05:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:13:22 --> Final output sent to browser
DEBUG - 2024-03-02 05:13:22 --> Total execution time: 0.0324
ERROR - 2024-03-02 05:13:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:13:22 --> Config Class Initialized
INFO - 2024-03-02 05:13:22 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:13:22 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:13:22 --> Utf8 Class Initialized
INFO - 2024-03-02 05:13:22 --> URI Class Initialized
INFO - 2024-03-02 05:13:22 --> Router Class Initialized
INFO - 2024-03-02 05:13:22 --> Output Class Initialized
INFO - 2024-03-02 05:13:22 --> Security Class Initialized
DEBUG - 2024-03-02 05:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:13:22 --> Input Class Initialized
INFO - 2024-03-02 05:13:22 --> Language Class Initialized
INFO - 2024-03-02 05:13:22 --> Loader Class Initialized
INFO - 2024-03-02 05:13:22 --> Helper loaded: url_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: file_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: html_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: text_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: form_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: security_helper
INFO - 2024-03-02 05:13:22 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:13:22 --> Database Driver Class Initialized
INFO - 2024-03-02 05:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:13:22 --> Parser Class Initialized
INFO - 2024-03-02 05:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:13:22 --> Pagination Class Initialized
INFO - 2024-03-02 05:13:22 --> Form Validation Class Initialized
INFO - 2024-03-02 05:13:22 --> Controller Class Initialized
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
DEBUG - 2024-03-02 05:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
DEBUG - 2024-03-02 05:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
DEBUG - 2024-03-02 05:13:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
INFO - 2024-03-02 05:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:13:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:13:22 --> Model Class Initialized
INFO - 2024-03-02 05:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:13:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:13:23 --> Final output sent to browser
DEBUG - 2024-03-02 05:13:23 --> Total execution time: 0.2364
ERROR - 2024-03-02 05:26:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:26:43 --> Config Class Initialized
INFO - 2024-03-02 05:26:43 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:26:43 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:26:43 --> Utf8 Class Initialized
INFO - 2024-03-02 05:26:43 --> URI Class Initialized
INFO - 2024-03-02 05:26:43 --> Router Class Initialized
INFO - 2024-03-02 05:26:43 --> Output Class Initialized
INFO - 2024-03-02 05:26:43 --> Security Class Initialized
DEBUG - 2024-03-02 05:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:26:43 --> Input Class Initialized
INFO - 2024-03-02 05:26:43 --> Language Class Initialized
INFO - 2024-03-02 05:26:43 --> Loader Class Initialized
INFO - 2024-03-02 05:26:43 --> Helper loaded: url_helper
INFO - 2024-03-02 05:26:43 --> Helper loaded: file_helper
INFO - 2024-03-02 05:26:43 --> Helper loaded: html_helper
INFO - 2024-03-02 05:26:43 --> Helper loaded: text_helper
INFO - 2024-03-02 05:26:43 --> Helper loaded: form_helper
INFO - 2024-03-02 05:26:43 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:26:43 --> Helper loaded: security_helper
INFO - 2024-03-02 05:26:43 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:26:43 --> Database Driver Class Initialized
INFO - 2024-03-02 05:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:26:43 --> Parser Class Initialized
INFO - 2024-03-02 05:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:26:43 --> Pagination Class Initialized
INFO - 2024-03-02 05:26:43 --> Form Validation Class Initialized
INFO - 2024-03-02 05:26:43 --> Controller Class Initialized
INFO - 2024-03-02 05:26:43 --> Model Class Initialized
DEBUG - 2024-03-02 05:26:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:26:43 --> Model Class Initialized
DEBUG - 2024-03-02 05:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:26:43 --> Model Class Initialized
INFO - 2024-03-02 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:26:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:26:43 --> Model Class Initialized
INFO - 2024-03-02 05:26:43 --> Model Class Initialized
INFO - 2024-03-02 05:26:43 --> Model Class Initialized
INFO - 2024-03-02 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:26:43 --> Final output sent to browser
DEBUG - 2024-03-02 05:26:43 --> Total execution time: 0.1708
ERROR - 2024-03-02 05:26:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:26:44 --> Config Class Initialized
INFO - 2024-03-02 05:26:44 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:26:44 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:26:44 --> Utf8 Class Initialized
INFO - 2024-03-02 05:26:44 --> URI Class Initialized
INFO - 2024-03-02 05:26:44 --> Router Class Initialized
INFO - 2024-03-02 05:26:44 --> Output Class Initialized
INFO - 2024-03-02 05:26:44 --> Security Class Initialized
DEBUG - 2024-03-02 05:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:26:44 --> Input Class Initialized
INFO - 2024-03-02 05:26:44 --> Language Class Initialized
INFO - 2024-03-02 05:26:44 --> Loader Class Initialized
INFO - 2024-03-02 05:26:44 --> Helper loaded: url_helper
INFO - 2024-03-02 05:26:44 --> Helper loaded: file_helper
INFO - 2024-03-02 05:26:44 --> Helper loaded: html_helper
INFO - 2024-03-02 05:26:44 --> Helper loaded: text_helper
INFO - 2024-03-02 05:26:44 --> Helper loaded: form_helper
INFO - 2024-03-02 05:26:44 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:26:44 --> Helper loaded: security_helper
INFO - 2024-03-02 05:26:44 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:26:44 --> Database Driver Class Initialized
INFO - 2024-03-02 05:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:26:44 --> Parser Class Initialized
INFO - 2024-03-02 05:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:26:44 --> Pagination Class Initialized
INFO - 2024-03-02 05:26:44 --> Form Validation Class Initialized
INFO - 2024-03-02 05:26:44 --> Controller Class Initialized
INFO - 2024-03-02 05:26:44 --> Model Class Initialized
DEBUG - 2024-03-02 05:26:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:26:44 --> Model Class Initialized
DEBUG - 2024-03-02 05:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:26:44 --> Model Class Initialized
INFO - 2024-03-02 05:26:44 --> Final output sent to browser
DEBUG - 2024-03-02 05:26:44 --> Total execution time: 0.0414
ERROR - 2024-03-02 05:26:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:26:54 --> Config Class Initialized
INFO - 2024-03-02 05:26:54 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:26:54 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:26:54 --> Utf8 Class Initialized
INFO - 2024-03-02 05:26:54 --> URI Class Initialized
INFO - 2024-03-02 05:26:54 --> Router Class Initialized
INFO - 2024-03-02 05:26:54 --> Output Class Initialized
INFO - 2024-03-02 05:26:54 --> Security Class Initialized
DEBUG - 2024-03-02 05:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:26:54 --> Input Class Initialized
INFO - 2024-03-02 05:26:54 --> Language Class Initialized
INFO - 2024-03-02 05:26:54 --> Loader Class Initialized
INFO - 2024-03-02 05:26:54 --> Helper loaded: url_helper
INFO - 2024-03-02 05:26:54 --> Helper loaded: file_helper
INFO - 2024-03-02 05:26:54 --> Helper loaded: html_helper
INFO - 2024-03-02 05:26:54 --> Helper loaded: text_helper
INFO - 2024-03-02 05:26:54 --> Helper loaded: form_helper
INFO - 2024-03-02 05:26:54 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:26:54 --> Helper loaded: security_helper
INFO - 2024-03-02 05:26:54 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:26:54 --> Database Driver Class Initialized
INFO - 2024-03-02 05:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:26:54 --> Parser Class Initialized
INFO - 2024-03-02 05:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:26:54 --> Pagination Class Initialized
INFO - 2024-03-02 05:26:54 --> Form Validation Class Initialized
INFO - 2024-03-02 05:26:54 --> Controller Class Initialized
INFO - 2024-03-02 05:26:54 --> Model Class Initialized
DEBUG - 2024-03-02 05:26:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:26:54 --> Model Class Initialized
DEBUG - 2024-03-02 05:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:26:54 --> Model Class Initialized
INFO - 2024-03-02 05:26:54 --> Final output sent to browser
DEBUG - 2024-03-02 05:26:54 --> Total execution time: 0.0698
ERROR - 2024-03-02 05:27:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:27:02 --> Config Class Initialized
INFO - 2024-03-02 05:27:02 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:27:02 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:27:02 --> Utf8 Class Initialized
INFO - 2024-03-02 05:27:02 --> URI Class Initialized
DEBUG - 2024-03-02 05:27:02 --> No URI present. Default controller set.
INFO - 2024-03-02 05:27:02 --> Router Class Initialized
INFO - 2024-03-02 05:27:02 --> Output Class Initialized
INFO - 2024-03-02 05:27:02 --> Security Class Initialized
DEBUG - 2024-03-02 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:27:02 --> Input Class Initialized
INFO - 2024-03-02 05:27:02 --> Language Class Initialized
INFO - 2024-03-02 05:27:02 --> Loader Class Initialized
INFO - 2024-03-02 05:27:02 --> Helper loaded: url_helper
INFO - 2024-03-02 05:27:02 --> Helper loaded: file_helper
INFO - 2024-03-02 05:27:02 --> Helper loaded: html_helper
INFO - 2024-03-02 05:27:02 --> Helper loaded: text_helper
INFO - 2024-03-02 05:27:02 --> Helper loaded: form_helper
INFO - 2024-03-02 05:27:02 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:27:02 --> Helper loaded: security_helper
INFO - 2024-03-02 05:27:02 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:27:02 --> Database Driver Class Initialized
INFO - 2024-03-02 05:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:27:02 --> Parser Class Initialized
INFO - 2024-03-02 05:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:27:02 --> Pagination Class Initialized
INFO - 2024-03-02 05:27:02 --> Form Validation Class Initialized
INFO - 2024-03-02 05:27:02 --> Controller Class Initialized
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
INFO - 2024-03-02 05:27:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:27:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:27:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:27:02 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:27:03 --> Final output sent to browser
DEBUG - 2024-03-02 05:27:03 --> Total execution time: 0.2450
ERROR - 2024-03-02 05:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:27:03 --> Config Class Initialized
INFO - 2024-03-02 05:27:03 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:27:03 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:27:03 --> Utf8 Class Initialized
INFO - 2024-03-02 05:27:03 --> URI Class Initialized
INFO - 2024-03-02 05:27:03 --> Router Class Initialized
INFO - 2024-03-02 05:27:03 --> Output Class Initialized
INFO - 2024-03-02 05:27:03 --> Security Class Initialized
DEBUG - 2024-03-02 05:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:27:03 --> Input Class Initialized
INFO - 2024-03-02 05:27:03 --> Language Class Initialized
INFO - 2024-03-02 05:27:03 --> Loader Class Initialized
INFO - 2024-03-02 05:27:03 --> Helper loaded: url_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: file_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: html_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: text_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: form_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: security_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:27:03 --> Database Driver Class Initialized
INFO - 2024-03-02 05:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:27:03 --> Parser Class Initialized
INFO - 2024-03-02 05:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:27:03 --> Pagination Class Initialized
INFO - 2024-03-02 05:27:03 --> Form Validation Class Initialized
INFO - 2024-03-02 05:27:03 --> Controller Class Initialized
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 05:27:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:27:03 --> Final output sent to browser
DEBUG - 2024-03-02 05:27:03 --> Total execution time: 0.0380
ERROR - 2024-03-02 05:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:27:03 --> Config Class Initialized
INFO - 2024-03-02 05:27:03 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:27:03 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:27:03 --> Utf8 Class Initialized
INFO - 2024-03-02 05:27:03 --> URI Class Initialized
INFO - 2024-03-02 05:27:03 --> Router Class Initialized
INFO - 2024-03-02 05:27:03 --> Output Class Initialized
INFO - 2024-03-02 05:27:03 --> Security Class Initialized
DEBUG - 2024-03-02 05:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:27:03 --> Input Class Initialized
INFO - 2024-03-02 05:27:03 --> Language Class Initialized
INFO - 2024-03-02 05:27:03 --> Loader Class Initialized
INFO - 2024-03-02 05:27:03 --> Helper loaded: url_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: file_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: html_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: text_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: form_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: security_helper
INFO - 2024-03-02 05:27:03 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:27:03 --> Database Driver Class Initialized
INFO - 2024-03-02 05:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:27:03 --> Parser Class Initialized
INFO - 2024-03-02 05:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:27:03 --> Pagination Class Initialized
INFO - 2024-03-02 05:27:03 --> Form Validation Class Initialized
INFO - 2024-03-02 05:27:03 --> Controller Class Initialized
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:27:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:27:03 --> Model Class Initialized
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:27:03 --> Final output sent to browser
DEBUG - 2024-03-02 05:27:03 --> Total execution time: 0.2559
ERROR - 2024-03-02 05:27:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:27:10 --> Config Class Initialized
INFO - 2024-03-02 05:27:10 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:27:10 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:27:10 --> Utf8 Class Initialized
INFO - 2024-03-02 05:27:10 --> URI Class Initialized
INFO - 2024-03-02 05:27:10 --> Router Class Initialized
INFO - 2024-03-02 05:27:10 --> Output Class Initialized
INFO - 2024-03-02 05:27:10 --> Security Class Initialized
DEBUG - 2024-03-02 05:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:27:10 --> Input Class Initialized
INFO - 2024-03-02 05:27:10 --> Language Class Initialized
INFO - 2024-03-02 05:27:10 --> Loader Class Initialized
INFO - 2024-03-02 05:27:10 --> Helper loaded: url_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: file_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: html_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: text_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: form_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: security_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:27:10 --> Database Driver Class Initialized
INFO - 2024-03-02 05:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:27:10 --> Parser Class Initialized
INFO - 2024-03-02 05:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:27:10 --> Pagination Class Initialized
INFO - 2024-03-02 05:27:10 --> Form Validation Class Initialized
INFO - 2024-03-02 05:27:10 --> Controller Class Initialized
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
INFO - 2024-03-02 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 05:27:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
INFO - 2024-03-02 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:27:10 --> Final output sent to browser
DEBUG - 2024-03-02 05:27:10 --> Total execution time: 0.1639
ERROR - 2024-03-02 05:27:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:27:10 --> Config Class Initialized
INFO - 2024-03-02 05:27:10 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:27:10 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:27:10 --> Utf8 Class Initialized
INFO - 2024-03-02 05:27:10 --> URI Class Initialized
INFO - 2024-03-02 05:27:10 --> Router Class Initialized
INFO - 2024-03-02 05:27:10 --> Output Class Initialized
INFO - 2024-03-02 05:27:10 --> Security Class Initialized
DEBUG - 2024-03-02 05:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:27:10 --> Input Class Initialized
INFO - 2024-03-02 05:27:10 --> Language Class Initialized
INFO - 2024-03-02 05:27:10 --> Loader Class Initialized
INFO - 2024-03-02 05:27:10 --> Helper loaded: url_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: file_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: html_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: text_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: form_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: security_helper
INFO - 2024-03-02 05:27:10 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:27:10 --> Database Driver Class Initialized
INFO - 2024-03-02 05:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:27:10 --> Parser Class Initialized
INFO - 2024-03-02 05:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:27:10 --> Pagination Class Initialized
INFO - 2024-03-02 05:27:10 --> Form Validation Class Initialized
INFO - 2024-03-02 05:27:10 --> Controller Class Initialized
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:10 --> Model Class Initialized
INFO - 2024-03-02 05:27:10 --> Final output sent to browser
DEBUG - 2024-03-02 05:27:10 --> Total execution time: 0.0442
ERROR - 2024-03-02 05:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:27:18 --> Config Class Initialized
INFO - 2024-03-02 05:27:18 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:27:18 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:27:18 --> Utf8 Class Initialized
INFO - 2024-03-02 05:27:18 --> URI Class Initialized
INFO - 2024-03-02 05:27:18 --> Router Class Initialized
INFO - 2024-03-02 05:27:18 --> Output Class Initialized
INFO - 2024-03-02 05:27:18 --> Security Class Initialized
DEBUG - 2024-03-02 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:27:18 --> Input Class Initialized
INFO - 2024-03-02 05:27:18 --> Language Class Initialized
INFO - 2024-03-02 05:27:18 --> Loader Class Initialized
INFO - 2024-03-02 05:27:18 --> Helper loaded: url_helper
INFO - 2024-03-02 05:27:18 --> Helper loaded: file_helper
INFO - 2024-03-02 05:27:18 --> Helper loaded: html_helper
INFO - 2024-03-02 05:27:18 --> Helper loaded: text_helper
INFO - 2024-03-02 05:27:18 --> Helper loaded: form_helper
INFO - 2024-03-02 05:27:18 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:27:18 --> Helper loaded: security_helper
INFO - 2024-03-02 05:27:18 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:27:18 --> Database Driver Class Initialized
INFO - 2024-03-02 05:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:27:18 --> Parser Class Initialized
INFO - 2024-03-02 05:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:27:18 --> Pagination Class Initialized
INFO - 2024-03-02 05:27:18 --> Form Validation Class Initialized
INFO - 2024-03-02 05:27:18 --> Controller Class Initialized
INFO - 2024-03-02 05:27:18 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:18 --> Model Class Initialized
DEBUG - 2024-03-02 05:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:27:18 --> Model Class Initialized
INFO - 2024-03-02 05:27:18 --> Final output sent to browser
DEBUG - 2024-03-02 05:27:18 --> Total execution time: 0.1387
ERROR - 2024-03-02 05:29:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:29:01 --> Config Class Initialized
INFO - 2024-03-02 05:29:01 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:29:01 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:29:01 --> Utf8 Class Initialized
INFO - 2024-03-02 05:29:01 --> URI Class Initialized
INFO - 2024-03-02 05:29:01 --> Router Class Initialized
INFO - 2024-03-02 05:29:01 --> Output Class Initialized
INFO - 2024-03-02 05:29:01 --> Security Class Initialized
DEBUG - 2024-03-02 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:29:01 --> Input Class Initialized
INFO - 2024-03-02 05:29:01 --> Language Class Initialized
INFO - 2024-03-02 05:29:01 --> Loader Class Initialized
INFO - 2024-03-02 05:29:01 --> Helper loaded: url_helper
INFO - 2024-03-02 05:29:01 --> Helper loaded: file_helper
INFO - 2024-03-02 05:29:01 --> Helper loaded: html_helper
INFO - 2024-03-02 05:29:01 --> Helper loaded: text_helper
INFO - 2024-03-02 05:29:01 --> Helper loaded: form_helper
INFO - 2024-03-02 05:29:01 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:29:01 --> Helper loaded: security_helper
INFO - 2024-03-02 05:29:01 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:29:01 --> Database Driver Class Initialized
INFO - 2024-03-02 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:29:01 --> Parser Class Initialized
INFO - 2024-03-02 05:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:29:01 --> Pagination Class Initialized
INFO - 2024-03-02 05:29:01 --> Form Validation Class Initialized
INFO - 2024-03-02 05:29:01 --> Controller Class Initialized
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
DEBUG - 2024-03-02 05:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
DEBUG - 2024-03-02 05:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
DEBUG - 2024-03-02 05:29:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
INFO - 2024-03-02 05:29:01 --> Model Class Initialized
INFO - 2024-03-02 05:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:29:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:29:02 --> Model Class Initialized
INFO - 2024-03-02 05:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:29:02 --> Final output sent to browser
DEBUG - 2024-03-02 05:29:02 --> Total execution time: 0.3073
ERROR - 2024-03-02 05:30:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:30:33 --> Config Class Initialized
INFO - 2024-03-02 05:30:33 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:30:33 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:30:33 --> Utf8 Class Initialized
INFO - 2024-03-02 05:30:33 --> URI Class Initialized
INFO - 2024-03-02 05:30:33 --> Router Class Initialized
INFO - 2024-03-02 05:30:33 --> Output Class Initialized
INFO - 2024-03-02 05:30:33 --> Security Class Initialized
DEBUG - 2024-03-02 05:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:30:33 --> Input Class Initialized
INFO - 2024-03-02 05:30:33 --> Language Class Initialized
INFO - 2024-03-02 05:30:33 --> Loader Class Initialized
INFO - 2024-03-02 05:30:33 --> Helper loaded: url_helper
INFO - 2024-03-02 05:30:33 --> Helper loaded: file_helper
INFO - 2024-03-02 05:30:33 --> Helper loaded: html_helper
INFO - 2024-03-02 05:30:33 --> Helper loaded: text_helper
INFO - 2024-03-02 05:30:33 --> Helper loaded: form_helper
INFO - 2024-03-02 05:30:33 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:30:33 --> Helper loaded: security_helper
INFO - 2024-03-02 05:30:33 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:30:33 --> Database Driver Class Initialized
INFO - 2024-03-02 05:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:30:33 --> Parser Class Initialized
INFO - 2024-03-02 05:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:30:33 --> Pagination Class Initialized
INFO - 2024-03-02 05:30:33 --> Form Validation Class Initialized
INFO - 2024-03-02 05:30:33 --> Controller Class Initialized
INFO - 2024-03-02 05:30:33 --> Model Class Initialized
DEBUG - 2024-03-02 05:30:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:30:33 --> Model Class Initialized
DEBUG - 2024-03-02 05:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:30:33 --> Model Class Initialized
INFO - 2024-03-02 05:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-02 05:30:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:30:33 --> Model Class Initialized
INFO - 2024-03-02 05:30:33 --> Model Class Initialized
INFO - 2024-03-02 05:30:33 --> Model Class Initialized
INFO - 2024-03-02 05:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:30:33 --> Final output sent to browser
DEBUG - 2024-03-02 05:30:33 --> Total execution time: 0.1978
ERROR - 2024-03-02 05:36:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:07 --> Config Class Initialized
INFO - 2024-03-02 05:36:07 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:07 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:07 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:07 --> URI Class Initialized
DEBUG - 2024-03-02 05:36:07 --> No URI present. Default controller set.
INFO - 2024-03-02 05:36:07 --> Router Class Initialized
INFO - 2024-03-02 05:36:07 --> Output Class Initialized
INFO - 2024-03-02 05:36:07 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:07 --> Input Class Initialized
INFO - 2024-03-02 05:36:07 --> Language Class Initialized
INFO - 2024-03-02 05:36:07 --> Loader Class Initialized
INFO - 2024-03-02 05:36:07 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:07 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:07 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:07 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:07 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:07 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:07 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:07 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:07 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:07 --> Parser Class Initialized
INFO - 2024-03-02 05:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:07 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:07 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:07 --> Controller Class Initialized
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
INFO - 2024-03-02 05:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 05:36:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:36:07 --> Model Class Initialized
INFO - 2024-03-02 05:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:36:07 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:07 --> Total execution time: 0.2621
ERROR - 2024-03-02 05:36:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:13 --> Config Class Initialized
INFO - 2024-03-02 05:36:13 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:13 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:13 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:13 --> URI Class Initialized
INFO - 2024-03-02 05:36:13 --> Router Class Initialized
INFO - 2024-03-02 05:36:13 --> Output Class Initialized
INFO - 2024-03-02 05:36:13 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:13 --> Input Class Initialized
INFO - 2024-03-02 05:36:13 --> Language Class Initialized
INFO - 2024-03-02 05:36:13 --> Loader Class Initialized
INFO - 2024-03-02 05:36:13 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:13 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:13 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:13 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:13 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:13 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:13 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:13 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:13 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:13 --> Parser Class Initialized
INFO - 2024-03-02 05:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:13 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:13 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:13 --> Controller Class Initialized
INFO - 2024-03-02 05:36:13 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:13 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:13 --> Model Class Initialized
INFO - 2024-03-02 05:36:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-02 05:36:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 05:36:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 05:36:13 --> Model Class Initialized
INFO - 2024-03-02 05:36:13 --> Model Class Initialized
INFO - 2024-03-02 05:36:13 --> Model Class Initialized
INFO - 2024-03-02 05:36:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 05:36:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 05:36:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 05:36:13 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:13 --> Total execution time: 0.2046
ERROR - 2024-03-02 05:36:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:24 --> Config Class Initialized
INFO - 2024-03-02 05:36:24 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:24 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:24 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:24 --> URI Class Initialized
INFO - 2024-03-02 05:36:24 --> Router Class Initialized
INFO - 2024-03-02 05:36:24 --> Output Class Initialized
INFO - 2024-03-02 05:36:24 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:24 --> Input Class Initialized
INFO - 2024-03-02 05:36:24 --> Language Class Initialized
INFO - 2024-03-02 05:36:24 --> Loader Class Initialized
INFO - 2024-03-02 05:36:24 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:24 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:24 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:24 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:24 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:24 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:24 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:24 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:24 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:24 --> Parser Class Initialized
INFO - 2024-03-02 05:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:24 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:24 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:24 --> Controller Class Initialized
INFO - 2024-03-02 05:36:24 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:24 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:24 --> Total execution time: 0.0162
ERROR - 2024-03-02 05:36:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:26 --> Config Class Initialized
INFO - 2024-03-02 05:36:26 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:26 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:26 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:26 --> URI Class Initialized
INFO - 2024-03-02 05:36:26 --> Router Class Initialized
INFO - 2024-03-02 05:36:26 --> Output Class Initialized
INFO - 2024-03-02 05:36:26 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:26 --> Input Class Initialized
INFO - 2024-03-02 05:36:26 --> Language Class Initialized
INFO - 2024-03-02 05:36:26 --> Loader Class Initialized
INFO - 2024-03-02 05:36:26 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:26 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:26 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:26 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:26 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:26 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:26 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:26 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:26 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:26 --> Parser Class Initialized
INFO - 2024-03-02 05:36:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:26 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:26 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:26 --> Controller Class Initialized
INFO - 2024-03-02 05:36:26 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:26 --> Total execution time: 0.0137
ERROR - 2024-03-02 05:36:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:30 --> Config Class Initialized
INFO - 2024-03-02 05:36:30 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:30 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:30 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:30 --> URI Class Initialized
INFO - 2024-03-02 05:36:30 --> Router Class Initialized
INFO - 2024-03-02 05:36:30 --> Output Class Initialized
INFO - 2024-03-02 05:36:30 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:30 --> Input Class Initialized
INFO - 2024-03-02 05:36:30 --> Language Class Initialized
INFO - 2024-03-02 05:36:30 --> Loader Class Initialized
INFO - 2024-03-02 05:36:30 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:30 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:30 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:30 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:30 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:30 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:30 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:30 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:30 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:30 --> Parser Class Initialized
INFO - 2024-03-02 05:36:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:30 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:30 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:30 --> Controller Class Initialized
INFO - 2024-03-02 05:36:30 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:30 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:30 --> Model Class Initialized
INFO - 2024-03-02 05:36:30 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:30 --> Total execution time: 0.1349
ERROR - 2024-03-02 05:36:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:31 --> Config Class Initialized
INFO - 2024-03-02 05:36:31 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:31 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:31 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:31 --> URI Class Initialized
INFO - 2024-03-02 05:36:31 --> Router Class Initialized
INFO - 2024-03-02 05:36:31 --> Output Class Initialized
INFO - 2024-03-02 05:36:31 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:31 --> Input Class Initialized
INFO - 2024-03-02 05:36:31 --> Language Class Initialized
INFO - 2024-03-02 05:36:31 --> Loader Class Initialized
INFO - 2024-03-02 05:36:31 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:31 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:31 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:31 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:31 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:31 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:31 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:31 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:31 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:31 --> Parser Class Initialized
INFO - 2024-03-02 05:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:31 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:31 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:31 --> Controller Class Initialized
INFO - 2024-03-02 05:36:31 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:31 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:31 --> Model Class Initialized
INFO - 2024-03-02 05:36:31 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:31 --> Total execution time: 0.1330
ERROR - 2024-03-02 05:36:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:32 --> Config Class Initialized
INFO - 2024-03-02 05:36:32 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:32 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:32 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:32 --> URI Class Initialized
INFO - 2024-03-02 05:36:32 --> Router Class Initialized
INFO - 2024-03-02 05:36:32 --> Output Class Initialized
INFO - 2024-03-02 05:36:32 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:32 --> Input Class Initialized
INFO - 2024-03-02 05:36:32 --> Language Class Initialized
INFO - 2024-03-02 05:36:32 --> Loader Class Initialized
INFO - 2024-03-02 05:36:32 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:32 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:32 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:32 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:32 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:32 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:32 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:32 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:32 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:32 --> Parser Class Initialized
INFO - 2024-03-02 05:36:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:32 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:32 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:32 --> Controller Class Initialized
INFO - 2024-03-02 05:36:32 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:32 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:32 --> Model Class Initialized
INFO - 2024-03-02 05:36:32 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:32 --> Total execution time: 0.1321
ERROR - 2024-03-02 05:36:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:35 --> Config Class Initialized
INFO - 2024-03-02 05:36:35 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:35 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:35 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:35 --> URI Class Initialized
INFO - 2024-03-02 05:36:35 --> Router Class Initialized
INFO - 2024-03-02 05:36:35 --> Output Class Initialized
INFO - 2024-03-02 05:36:35 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:35 --> Input Class Initialized
INFO - 2024-03-02 05:36:35 --> Language Class Initialized
INFO - 2024-03-02 05:36:35 --> Loader Class Initialized
INFO - 2024-03-02 05:36:35 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:35 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:35 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:35 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:35 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:35 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:35 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:35 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:35 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:35 --> Parser Class Initialized
INFO - 2024-03-02 05:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:35 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:35 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:35 --> Controller Class Initialized
INFO - 2024-03-02 05:36:35 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:35 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:35 --> Model Class Initialized
INFO - 2024-03-02 05:36:35 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:35 --> Total execution time: 0.0460
ERROR - 2024-03-02 05:36:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:36 --> Config Class Initialized
INFO - 2024-03-02 05:36:36 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:36 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:36 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:36 --> URI Class Initialized
INFO - 2024-03-02 05:36:36 --> Router Class Initialized
INFO - 2024-03-02 05:36:36 --> Output Class Initialized
INFO - 2024-03-02 05:36:36 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:36 --> Input Class Initialized
INFO - 2024-03-02 05:36:36 --> Language Class Initialized
INFO - 2024-03-02 05:36:36 --> Loader Class Initialized
INFO - 2024-03-02 05:36:36 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:36 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:36 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:36 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:36 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:36 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:36 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:36 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:36 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:36 --> Parser Class Initialized
INFO - 2024-03-02 05:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:36 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:36 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:36 --> Controller Class Initialized
INFO - 2024-03-02 05:36:36 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:36 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:36 --> Model Class Initialized
INFO - 2024-03-02 05:36:36 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:36 --> Total execution time: 0.0266
ERROR - 2024-03-02 05:36:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:37 --> Config Class Initialized
INFO - 2024-03-02 05:36:37 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:37 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:37 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:37 --> URI Class Initialized
INFO - 2024-03-02 05:36:37 --> Router Class Initialized
INFO - 2024-03-02 05:36:37 --> Output Class Initialized
INFO - 2024-03-02 05:36:37 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:37 --> Input Class Initialized
INFO - 2024-03-02 05:36:37 --> Language Class Initialized
INFO - 2024-03-02 05:36:37 --> Loader Class Initialized
INFO - 2024-03-02 05:36:37 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:37 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:37 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:37 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:37 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:37 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:37 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:37 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:37 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:37 --> Parser Class Initialized
INFO - 2024-03-02 05:36:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:37 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:37 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:37 --> Controller Class Initialized
INFO - 2024-03-02 05:36:37 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:37 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:37 --> Model Class Initialized
INFO - 2024-03-02 05:36:37 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:37 --> Total execution time: 0.0263
ERROR - 2024-03-02 05:36:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:38 --> Config Class Initialized
INFO - 2024-03-02 05:36:38 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:38 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:38 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:38 --> URI Class Initialized
INFO - 2024-03-02 05:36:38 --> Router Class Initialized
INFO - 2024-03-02 05:36:38 --> Output Class Initialized
INFO - 2024-03-02 05:36:38 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:38 --> Input Class Initialized
INFO - 2024-03-02 05:36:38 --> Language Class Initialized
INFO - 2024-03-02 05:36:38 --> Loader Class Initialized
INFO - 2024-03-02 05:36:38 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:38 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:38 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:38 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:38 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:38 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:38 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:38 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:38 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:38 --> Parser Class Initialized
INFO - 2024-03-02 05:36:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:38 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:38 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:38 --> Controller Class Initialized
INFO - 2024-03-02 05:36:38 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:38 --> Model Class Initialized
INFO - 2024-03-02 05:36:38 --> Model Class Initialized
INFO - 2024-03-02 05:36:38 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:38 --> Total execution time: 0.0201
ERROR - 2024-03-02 05:36:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:36:40 --> Config Class Initialized
INFO - 2024-03-02 05:36:40 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:36:40 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:36:40 --> Utf8 Class Initialized
INFO - 2024-03-02 05:36:40 --> URI Class Initialized
INFO - 2024-03-02 05:36:40 --> Router Class Initialized
INFO - 2024-03-02 05:36:40 --> Output Class Initialized
INFO - 2024-03-02 05:36:40 --> Security Class Initialized
DEBUG - 2024-03-02 05:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:36:40 --> Input Class Initialized
INFO - 2024-03-02 05:36:40 --> Language Class Initialized
INFO - 2024-03-02 05:36:40 --> Loader Class Initialized
INFO - 2024-03-02 05:36:40 --> Helper loaded: url_helper
INFO - 2024-03-02 05:36:40 --> Helper loaded: file_helper
INFO - 2024-03-02 05:36:40 --> Helper loaded: html_helper
INFO - 2024-03-02 05:36:40 --> Helper loaded: text_helper
INFO - 2024-03-02 05:36:40 --> Helper loaded: form_helper
INFO - 2024-03-02 05:36:40 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:36:40 --> Helper loaded: security_helper
INFO - 2024-03-02 05:36:40 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:36:40 --> Database Driver Class Initialized
INFO - 2024-03-02 05:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:36:40 --> Parser Class Initialized
INFO - 2024-03-02 05:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:36:40 --> Pagination Class Initialized
INFO - 2024-03-02 05:36:40 --> Form Validation Class Initialized
INFO - 2024-03-02 05:36:40 --> Controller Class Initialized
INFO - 2024-03-02 05:36:40 --> Model Class Initialized
DEBUG - 2024-03-02 05:36:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:36:40 --> Model Class Initialized
INFO - 2024-03-02 05:36:40 --> Final output sent to browser
DEBUG - 2024-03-02 05:36:40 --> Total execution time: 0.0202
ERROR - 2024-03-02 05:37:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 05:37:04 --> Config Class Initialized
INFO - 2024-03-02 05:37:04 --> Hooks Class Initialized
DEBUG - 2024-03-02 05:37:04 --> UTF-8 Support Enabled
INFO - 2024-03-02 05:37:04 --> Utf8 Class Initialized
INFO - 2024-03-02 05:37:04 --> URI Class Initialized
INFO - 2024-03-02 05:37:04 --> Router Class Initialized
INFO - 2024-03-02 05:37:04 --> Output Class Initialized
INFO - 2024-03-02 05:37:04 --> Security Class Initialized
DEBUG - 2024-03-02 05:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 05:37:04 --> Input Class Initialized
INFO - 2024-03-02 05:37:04 --> Language Class Initialized
INFO - 2024-03-02 05:37:04 --> Loader Class Initialized
INFO - 2024-03-02 05:37:04 --> Helper loaded: url_helper
INFO - 2024-03-02 05:37:04 --> Helper loaded: file_helper
INFO - 2024-03-02 05:37:04 --> Helper loaded: html_helper
INFO - 2024-03-02 05:37:04 --> Helper loaded: text_helper
INFO - 2024-03-02 05:37:04 --> Helper loaded: form_helper
INFO - 2024-03-02 05:37:04 --> Helper loaded: lang_helper
INFO - 2024-03-02 05:37:04 --> Helper loaded: security_helper
INFO - 2024-03-02 05:37:04 --> Helper loaded: cookie_helper
INFO - 2024-03-02 05:37:04 --> Database Driver Class Initialized
INFO - 2024-03-02 05:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 05:37:04 --> Parser Class Initialized
INFO - 2024-03-02 05:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 05:37:04 --> Pagination Class Initialized
INFO - 2024-03-02 05:37:04 --> Form Validation Class Initialized
INFO - 2024-03-02 05:37:04 --> Controller Class Initialized
INFO - 2024-03-02 05:37:04 --> Model Class Initialized
DEBUG - 2024-03-02 05:37:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 05:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:37:04 --> Model Class Initialized
DEBUG - 2024-03-02 05:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:37:04 --> Model Class Initialized
INFO - 2024-03-02 05:37:04 --> Email Class Initialized
DEBUG - 2024-03-02 05:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 05:37:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-02 05:37:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-02 05:37:04 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-02 05:37:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-02 05:37:04 --> Final output sent to browser
DEBUG - 2024-03-02 05:37:04 --> Total execution time: 0.2300
ERROR - 2024-03-02 07:15:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 07:15:45 --> Config Class Initialized
INFO - 2024-03-02 07:15:45 --> Hooks Class Initialized
DEBUG - 2024-03-02 07:15:45 --> UTF-8 Support Enabled
INFO - 2024-03-02 07:15:45 --> Utf8 Class Initialized
INFO - 2024-03-02 07:15:45 --> URI Class Initialized
DEBUG - 2024-03-02 07:15:45 --> No URI present. Default controller set.
INFO - 2024-03-02 07:15:45 --> Router Class Initialized
INFO - 2024-03-02 07:15:45 --> Output Class Initialized
INFO - 2024-03-02 07:15:45 --> Security Class Initialized
DEBUG - 2024-03-02 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 07:15:45 --> Input Class Initialized
INFO - 2024-03-02 07:15:45 --> Language Class Initialized
INFO - 2024-03-02 07:15:45 --> Loader Class Initialized
INFO - 2024-03-02 07:15:45 --> Helper loaded: url_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: file_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: html_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: text_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: form_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: lang_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: security_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: cookie_helper
INFO - 2024-03-02 07:15:45 --> Database Driver Class Initialized
INFO - 2024-03-02 07:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 07:15:45 --> Parser Class Initialized
INFO - 2024-03-02 07:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 07:15:45 --> Pagination Class Initialized
INFO - 2024-03-02 07:15:45 --> Form Validation Class Initialized
INFO - 2024-03-02 07:15:45 --> Controller Class Initialized
INFO - 2024-03-02 07:15:45 --> Model Class Initialized
DEBUG - 2024-03-02 07:15:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 07:15:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 07:15:45 --> Config Class Initialized
INFO - 2024-03-02 07:15:45 --> Hooks Class Initialized
DEBUG - 2024-03-02 07:15:45 --> UTF-8 Support Enabled
INFO - 2024-03-02 07:15:45 --> Utf8 Class Initialized
INFO - 2024-03-02 07:15:45 --> URI Class Initialized
INFO - 2024-03-02 07:15:45 --> Router Class Initialized
INFO - 2024-03-02 07:15:45 --> Output Class Initialized
INFO - 2024-03-02 07:15:45 --> Security Class Initialized
DEBUG - 2024-03-02 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 07:15:45 --> Input Class Initialized
INFO - 2024-03-02 07:15:45 --> Language Class Initialized
INFO - 2024-03-02 07:15:45 --> Loader Class Initialized
INFO - 2024-03-02 07:15:45 --> Helper loaded: url_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: file_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: html_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: text_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: form_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: lang_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: security_helper
INFO - 2024-03-02 07:15:45 --> Helper loaded: cookie_helper
INFO - 2024-03-02 07:15:45 --> Database Driver Class Initialized
INFO - 2024-03-02 07:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 07:15:45 --> Parser Class Initialized
INFO - 2024-03-02 07:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 07:15:45 --> Pagination Class Initialized
INFO - 2024-03-02 07:15:45 --> Form Validation Class Initialized
INFO - 2024-03-02 07:15:45 --> Controller Class Initialized
INFO - 2024-03-02 07:15:45 --> Model Class Initialized
DEBUG - 2024-03-02 07:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 07:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 07:15:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 07:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 07:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 07:15:45 --> Model Class Initialized
INFO - 2024-03-02 07:15:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 07:15:45 --> Final output sent to browser
DEBUG - 2024-03-02 07:15:45 --> Total execution time: 0.0438
ERROR - 2024-03-02 08:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 08:01:34 --> Config Class Initialized
INFO - 2024-03-02 08:01:34 --> Hooks Class Initialized
DEBUG - 2024-03-02 08:01:34 --> UTF-8 Support Enabled
INFO - 2024-03-02 08:01:34 --> Utf8 Class Initialized
INFO - 2024-03-02 08:01:34 --> URI Class Initialized
INFO - 2024-03-02 08:01:34 --> Router Class Initialized
INFO - 2024-03-02 08:01:34 --> Output Class Initialized
INFO - 2024-03-02 08:01:34 --> Security Class Initialized
DEBUG - 2024-03-02 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 08:01:34 --> Input Class Initialized
INFO - 2024-03-02 08:01:34 --> Language Class Initialized
INFO - 2024-03-02 08:01:34 --> Loader Class Initialized
INFO - 2024-03-02 08:01:34 --> Helper loaded: url_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: file_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: html_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: text_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: form_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: lang_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: security_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: cookie_helper
INFO - 2024-03-02 08:01:34 --> Database Driver Class Initialized
INFO - 2024-03-02 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 08:01:34 --> Parser Class Initialized
INFO - 2024-03-02 08:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 08:01:34 --> Pagination Class Initialized
INFO - 2024-03-02 08:01:34 --> Form Validation Class Initialized
INFO - 2024-03-02 08:01:34 --> Controller Class Initialized
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
INFO - 2024-03-02 08:01:34 --> Final output sent to browser
DEBUG - 2024-03-02 08:01:34 --> Total execution time: 0.0227
ERROR - 2024-03-02 08:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 08:01:34 --> Config Class Initialized
INFO - 2024-03-02 08:01:34 --> Hooks Class Initialized
DEBUG - 2024-03-02 08:01:34 --> UTF-8 Support Enabled
INFO - 2024-03-02 08:01:34 --> Utf8 Class Initialized
INFO - 2024-03-02 08:01:34 --> URI Class Initialized
DEBUG - 2024-03-02 08:01:34 --> No URI present. Default controller set.
INFO - 2024-03-02 08:01:34 --> Router Class Initialized
INFO - 2024-03-02 08:01:34 --> Output Class Initialized
INFO - 2024-03-02 08:01:34 --> Security Class Initialized
DEBUG - 2024-03-02 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 08:01:34 --> Input Class Initialized
INFO - 2024-03-02 08:01:34 --> Language Class Initialized
INFO - 2024-03-02 08:01:34 --> Loader Class Initialized
INFO - 2024-03-02 08:01:34 --> Helper loaded: url_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: file_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: html_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: text_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: form_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: lang_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: security_helper
INFO - 2024-03-02 08:01:34 --> Helper loaded: cookie_helper
INFO - 2024-03-02 08:01:34 --> Database Driver Class Initialized
INFO - 2024-03-02 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 08:01:34 --> Parser Class Initialized
INFO - 2024-03-02 08:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 08:01:34 --> Pagination Class Initialized
INFO - 2024-03-02 08:01:34 --> Form Validation Class Initialized
INFO - 2024-03-02 08:01:34 --> Controller Class Initialized
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 08:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
INFO - 2024-03-02 08:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 08:01:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 08:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 08:01:34 --> Model Class Initialized
INFO - 2024-03-02 08:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 08:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 08:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 08:01:34 --> Final output sent to browser
DEBUG - 2024-03-02 08:01:34 --> Total execution time: 0.2593
ERROR - 2024-03-02 08:01:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 08:01:50 --> Config Class Initialized
INFO - 2024-03-02 08:01:50 --> Hooks Class Initialized
DEBUG - 2024-03-02 08:01:50 --> UTF-8 Support Enabled
INFO - 2024-03-02 08:01:50 --> Utf8 Class Initialized
INFO - 2024-03-02 08:01:50 --> URI Class Initialized
INFO - 2024-03-02 08:01:50 --> Router Class Initialized
INFO - 2024-03-02 08:01:50 --> Output Class Initialized
INFO - 2024-03-02 08:01:50 --> Security Class Initialized
DEBUG - 2024-03-02 08:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 08:01:50 --> Input Class Initialized
INFO - 2024-03-02 08:01:50 --> Language Class Initialized
INFO - 2024-03-02 08:01:50 --> Loader Class Initialized
INFO - 2024-03-02 08:01:50 --> Helper loaded: url_helper
INFO - 2024-03-02 08:01:50 --> Helper loaded: file_helper
INFO - 2024-03-02 08:01:50 --> Helper loaded: html_helper
INFO - 2024-03-02 08:01:50 --> Helper loaded: text_helper
INFO - 2024-03-02 08:01:50 --> Helper loaded: form_helper
INFO - 2024-03-02 08:01:50 --> Helper loaded: lang_helper
INFO - 2024-03-02 08:01:50 --> Helper loaded: security_helper
INFO - 2024-03-02 08:01:50 --> Helper loaded: cookie_helper
INFO - 2024-03-02 08:01:50 --> Database Driver Class Initialized
INFO - 2024-03-02 08:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 08:01:50 --> Parser Class Initialized
INFO - 2024-03-02 08:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 08:01:50 --> Pagination Class Initialized
INFO - 2024-03-02 08:01:50 --> Form Validation Class Initialized
INFO - 2024-03-02 08:01:50 --> Controller Class Initialized
INFO - 2024-03-02 08:01:50 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 08:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:50 --> Model Class Initialized
INFO - 2024-03-02 08:01:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2024-03-02 08:01:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 08:01:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 08:01:50 --> Model Class Initialized
INFO - 2024-03-02 08:01:50 --> Model Class Initialized
INFO - 2024-03-02 08:01:50 --> Model Class Initialized
INFO - 2024-03-02 08:01:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 08:01:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 08:01:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 08:01:50 --> Final output sent to browser
DEBUG - 2024-03-02 08:01:50 --> Total execution time: 0.1716
ERROR - 2024-03-02 08:01:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 08:01:51 --> Config Class Initialized
INFO - 2024-03-02 08:01:51 --> Hooks Class Initialized
DEBUG - 2024-03-02 08:01:51 --> UTF-8 Support Enabled
INFO - 2024-03-02 08:01:51 --> Utf8 Class Initialized
INFO - 2024-03-02 08:01:51 --> URI Class Initialized
INFO - 2024-03-02 08:01:51 --> Router Class Initialized
INFO - 2024-03-02 08:01:51 --> Output Class Initialized
INFO - 2024-03-02 08:01:51 --> Security Class Initialized
DEBUG - 2024-03-02 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 08:01:51 --> Input Class Initialized
INFO - 2024-03-02 08:01:51 --> Language Class Initialized
INFO - 2024-03-02 08:01:51 --> Loader Class Initialized
INFO - 2024-03-02 08:01:51 --> Helper loaded: url_helper
INFO - 2024-03-02 08:01:51 --> Helper loaded: file_helper
INFO - 2024-03-02 08:01:51 --> Helper loaded: html_helper
INFO - 2024-03-02 08:01:51 --> Helper loaded: text_helper
INFO - 2024-03-02 08:01:51 --> Helper loaded: form_helper
INFO - 2024-03-02 08:01:51 --> Helper loaded: lang_helper
INFO - 2024-03-02 08:01:51 --> Helper loaded: security_helper
INFO - 2024-03-02 08:01:51 --> Helper loaded: cookie_helper
INFO - 2024-03-02 08:01:51 --> Database Driver Class Initialized
INFO - 2024-03-02 08:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 08:01:51 --> Parser Class Initialized
INFO - 2024-03-02 08:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 08:01:51 --> Pagination Class Initialized
INFO - 2024-03-02 08:01:51 --> Form Validation Class Initialized
INFO - 2024-03-02 08:01:51 --> Controller Class Initialized
INFO - 2024-03-02 08:01:51 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 08:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:51 --> Model Class Initialized
INFO - 2024-03-02 08:01:51 --> Final output sent to browser
DEBUG - 2024-03-02 08:01:51 --> Total execution time: 0.0169
ERROR - 2024-03-02 08:01:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 08:01:58 --> Config Class Initialized
INFO - 2024-03-02 08:01:58 --> Hooks Class Initialized
DEBUG - 2024-03-02 08:01:58 --> UTF-8 Support Enabled
INFO - 2024-03-02 08:01:58 --> Utf8 Class Initialized
INFO - 2024-03-02 08:01:58 --> URI Class Initialized
DEBUG - 2024-03-02 08:01:58 --> No URI present. Default controller set.
INFO - 2024-03-02 08:01:58 --> Router Class Initialized
INFO - 2024-03-02 08:01:58 --> Output Class Initialized
INFO - 2024-03-02 08:01:58 --> Security Class Initialized
DEBUG - 2024-03-02 08:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 08:01:58 --> Input Class Initialized
INFO - 2024-03-02 08:01:58 --> Language Class Initialized
INFO - 2024-03-02 08:01:58 --> Loader Class Initialized
INFO - 2024-03-02 08:01:58 --> Helper loaded: url_helper
INFO - 2024-03-02 08:01:58 --> Helper loaded: file_helper
INFO - 2024-03-02 08:01:58 --> Helper loaded: html_helper
INFO - 2024-03-02 08:01:58 --> Helper loaded: text_helper
INFO - 2024-03-02 08:01:58 --> Helper loaded: form_helper
INFO - 2024-03-02 08:01:58 --> Helper loaded: lang_helper
INFO - 2024-03-02 08:01:58 --> Helper loaded: security_helper
INFO - 2024-03-02 08:01:58 --> Helper loaded: cookie_helper
INFO - 2024-03-02 08:01:58 --> Database Driver Class Initialized
INFO - 2024-03-02 08:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 08:01:58 --> Parser Class Initialized
INFO - 2024-03-02 08:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 08:01:58 --> Pagination Class Initialized
INFO - 2024-03-02 08:01:58 --> Form Validation Class Initialized
INFO - 2024-03-02 08:01:58 --> Controller Class Initialized
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
DEBUG - 2024-03-02 08:01:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 08:01:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
INFO - 2024-03-02 08:01:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 08:01:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 08:01:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 08:01:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 08:01:58 --> Model Class Initialized
INFO - 2024-03-02 08:01:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 08:01:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 08:01:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 08:01:58 --> Final output sent to browser
DEBUG - 2024-03-02 08:01:58 --> Total execution time: 0.2382
ERROR - 2024-03-02 09:23:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 09:23:44 --> Config Class Initialized
INFO - 2024-03-02 09:23:44 --> Hooks Class Initialized
DEBUG - 2024-03-02 09:23:44 --> UTF-8 Support Enabled
INFO - 2024-03-02 09:23:44 --> Utf8 Class Initialized
INFO - 2024-03-02 09:23:44 --> URI Class Initialized
DEBUG - 2024-03-02 09:23:44 --> No URI present. Default controller set.
INFO - 2024-03-02 09:23:44 --> Router Class Initialized
INFO - 2024-03-02 09:23:44 --> Output Class Initialized
INFO - 2024-03-02 09:23:44 --> Security Class Initialized
DEBUG - 2024-03-02 09:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 09:23:44 --> Input Class Initialized
INFO - 2024-03-02 09:23:44 --> Language Class Initialized
INFO - 2024-03-02 09:23:44 --> Loader Class Initialized
INFO - 2024-03-02 09:23:44 --> Helper loaded: url_helper
INFO - 2024-03-02 09:23:44 --> Helper loaded: file_helper
INFO - 2024-03-02 09:23:44 --> Helper loaded: html_helper
INFO - 2024-03-02 09:23:44 --> Helper loaded: text_helper
INFO - 2024-03-02 09:23:44 --> Helper loaded: form_helper
INFO - 2024-03-02 09:23:44 --> Helper loaded: lang_helper
INFO - 2024-03-02 09:23:44 --> Helper loaded: security_helper
INFO - 2024-03-02 09:23:44 --> Helper loaded: cookie_helper
INFO - 2024-03-02 09:23:44 --> Database Driver Class Initialized
INFO - 2024-03-02 09:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 09:23:44 --> Parser Class Initialized
INFO - 2024-03-02 09:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 09:23:44 --> Pagination Class Initialized
INFO - 2024-03-02 09:23:44 --> Form Validation Class Initialized
INFO - 2024-03-02 09:23:44 --> Controller Class Initialized
INFO - 2024-03-02 09:23:44 --> Model Class Initialized
DEBUG - 2024-03-02 09:23:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 09:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 09:23:45 --> Config Class Initialized
INFO - 2024-03-02 09:23:45 --> Hooks Class Initialized
DEBUG - 2024-03-02 09:23:45 --> UTF-8 Support Enabled
INFO - 2024-03-02 09:23:45 --> Utf8 Class Initialized
INFO - 2024-03-02 09:23:45 --> URI Class Initialized
INFO - 2024-03-02 09:23:45 --> Router Class Initialized
INFO - 2024-03-02 09:23:45 --> Output Class Initialized
INFO - 2024-03-02 09:23:45 --> Security Class Initialized
DEBUG - 2024-03-02 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 09:23:45 --> Input Class Initialized
INFO - 2024-03-02 09:23:45 --> Language Class Initialized
INFO - 2024-03-02 09:23:45 --> Loader Class Initialized
INFO - 2024-03-02 09:23:45 --> Helper loaded: url_helper
INFO - 2024-03-02 09:23:45 --> Helper loaded: file_helper
INFO - 2024-03-02 09:23:45 --> Helper loaded: html_helper
INFO - 2024-03-02 09:23:45 --> Helper loaded: text_helper
INFO - 2024-03-02 09:23:45 --> Helper loaded: form_helper
INFO - 2024-03-02 09:23:45 --> Helper loaded: lang_helper
INFO - 2024-03-02 09:23:45 --> Helper loaded: security_helper
INFO - 2024-03-02 09:23:45 --> Helper loaded: cookie_helper
INFO - 2024-03-02 09:23:45 --> Database Driver Class Initialized
INFO - 2024-03-02 09:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 09:23:45 --> Parser Class Initialized
INFO - 2024-03-02 09:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 09:23:45 --> Pagination Class Initialized
INFO - 2024-03-02 09:23:45 --> Form Validation Class Initialized
INFO - 2024-03-02 09:23:45 --> Controller Class Initialized
INFO - 2024-03-02 09:23:45 --> Model Class Initialized
DEBUG - 2024-03-02 09:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 09:23:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 09:23:45 --> Model Class Initialized
INFO - 2024-03-02 09:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 09:23:45 --> Final output sent to browser
DEBUG - 2024-03-02 09:23:45 --> Total execution time: 0.0363
ERROR - 2024-03-02 11:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 11:59:30 --> Config Class Initialized
INFO - 2024-03-02 11:59:30 --> Hooks Class Initialized
DEBUG - 2024-03-02 11:59:30 --> UTF-8 Support Enabled
INFO - 2024-03-02 11:59:30 --> Utf8 Class Initialized
INFO - 2024-03-02 11:59:30 --> URI Class Initialized
DEBUG - 2024-03-02 11:59:30 --> No URI present. Default controller set.
INFO - 2024-03-02 11:59:30 --> Router Class Initialized
INFO - 2024-03-02 11:59:30 --> Output Class Initialized
INFO - 2024-03-02 11:59:30 --> Security Class Initialized
DEBUG - 2024-03-02 11:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 11:59:30 --> Input Class Initialized
INFO - 2024-03-02 11:59:30 --> Language Class Initialized
INFO - 2024-03-02 11:59:30 --> Loader Class Initialized
INFO - 2024-03-02 11:59:30 --> Helper loaded: url_helper
INFO - 2024-03-02 11:59:30 --> Helper loaded: file_helper
INFO - 2024-03-02 11:59:30 --> Helper loaded: html_helper
INFO - 2024-03-02 11:59:30 --> Helper loaded: text_helper
INFO - 2024-03-02 11:59:30 --> Helper loaded: form_helper
INFO - 2024-03-02 11:59:30 --> Helper loaded: lang_helper
INFO - 2024-03-02 11:59:30 --> Helper loaded: security_helper
INFO - 2024-03-02 11:59:30 --> Helper loaded: cookie_helper
INFO - 2024-03-02 11:59:30 --> Database Driver Class Initialized
INFO - 2024-03-02 11:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 11:59:30 --> Parser Class Initialized
INFO - 2024-03-02 11:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 11:59:30 --> Pagination Class Initialized
INFO - 2024-03-02 11:59:30 --> Form Validation Class Initialized
INFO - 2024-03-02 11:59:30 --> Controller Class Initialized
INFO - 2024-03-02 11:59:30 --> Model Class Initialized
DEBUG - 2024-03-02 11:59:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 11:59:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 11:59:31 --> Config Class Initialized
INFO - 2024-03-02 11:59:31 --> Hooks Class Initialized
DEBUG - 2024-03-02 11:59:31 --> UTF-8 Support Enabled
INFO - 2024-03-02 11:59:31 --> Utf8 Class Initialized
INFO - 2024-03-02 11:59:31 --> URI Class Initialized
INFO - 2024-03-02 11:59:31 --> Router Class Initialized
INFO - 2024-03-02 11:59:31 --> Output Class Initialized
INFO - 2024-03-02 11:59:31 --> Security Class Initialized
DEBUG - 2024-03-02 11:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 11:59:31 --> Input Class Initialized
INFO - 2024-03-02 11:59:31 --> Language Class Initialized
INFO - 2024-03-02 11:59:31 --> Loader Class Initialized
INFO - 2024-03-02 11:59:31 --> Helper loaded: url_helper
INFO - 2024-03-02 11:59:31 --> Helper loaded: file_helper
INFO - 2024-03-02 11:59:31 --> Helper loaded: html_helper
INFO - 2024-03-02 11:59:31 --> Helper loaded: text_helper
INFO - 2024-03-02 11:59:31 --> Helper loaded: form_helper
INFO - 2024-03-02 11:59:31 --> Helper loaded: lang_helper
INFO - 2024-03-02 11:59:31 --> Helper loaded: security_helper
INFO - 2024-03-02 11:59:31 --> Helper loaded: cookie_helper
INFO - 2024-03-02 11:59:31 --> Database Driver Class Initialized
INFO - 2024-03-02 11:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 11:59:31 --> Parser Class Initialized
INFO - 2024-03-02 11:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 11:59:31 --> Pagination Class Initialized
INFO - 2024-03-02 11:59:31 --> Form Validation Class Initialized
INFO - 2024-03-02 11:59:31 --> Controller Class Initialized
INFO - 2024-03-02 11:59:31 --> Model Class Initialized
DEBUG - 2024-03-02 11:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 11:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 11:59:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 11:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 11:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 11:59:31 --> Model Class Initialized
INFO - 2024-03-02 11:59:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 11:59:31 --> Final output sent to browser
DEBUG - 2024-03-02 11:59:31 --> Total execution time: 0.0305
ERROR - 2024-03-02 12:07:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 12:07:24 --> Config Class Initialized
INFO - 2024-03-02 12:07:24 --> Hooks Class Initialized
DEBUG - 2024-03-02 12:07:24 --> UTF-8 Support Enabled
INFO - 2024-03-02 12:07:24 --> Utf8 Class Initialized
INFO - 2024-03-02 12:07:24 --> URI Class Initialized
DEBUG - 2024-03-02 12:07:24 --> No URI present. Default controller set.
INFO - 2024-03-02 12:07:24 --> Router Class Initialized
INFO - 2024-03-02 12:07:24 --> Output Class Initialized
INFO - 2024-03-02 12:07:24 --> Security Class Initialized
DEBUG - 2024-03-02 12:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 12:07:24 --> Input Class Initialized
INFO - 2024-03-02 12:07:24 --> Language Class Initialized
INFO - 2024-03-02 12:07:24 --> Loader Class Initialized
INFO - 2024-03-02 12:07:24 --> Helper loaded: url_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: file_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: html_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: text_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: form_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: lang_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: security_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: cookie_helper
INFO - 2024-03-02 12:07:24 --> Database Driver Class Initialized
INFO - 2024-03-02 12:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 12:07:24 --> Parser Class Initialized
INFO - 2024-03-02 12:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 12:07:24 --> Pagination Class Initialized
INFO - 2024-03-02 12:07:24 --> Form Validation Class Initialized
INFO - 2024-03-02 12:07:24 --> Controller Class Initialized
INFO - 2024-03-02 12:07:24 --> Model Class Initialized
DEBUG - 2024-03-02 12:07:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 12:07:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 12:07:24 --> Config Class Initialized
INFO - 2024-03-02 12:07:24 --> Hooks Class Initialized
DEBUG - 2024-03-02 12:07:24 --> UTF-8 Support Enabled
INFO - 2024-03-02 12:07:24 --> Utf8 Class Initialized
INFO - 2024-03-02 12:07:24 --> URI Class Initialized
INFO - 2024-03-02 12:07:24 --> Router Class Initialized
INFO - 2024-03-02 12:07:24 --> Output Class Initialized
INFO - 2024-03-02 12:07:24 --> Security Class Initialized
DEBUG - 2024-03-02 12:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 12:07:24 --> Input Class Initialized
INFO - 2024-03-02 12:07:24 --> Language Class Initialized
INFO - 2024-03-02 12:07:24 --> Loader Class Initialized
INFO - 2024-03-02 12:07:24 --> Helper loaded: url_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: file_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: html_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: text_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: form_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: lang_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: security_helper
INFO - 2024-03-02 12:07:24 --> Helper loaded: cookie_helper
INFO - 2024-03-02 12:07:24 --> Database Driver Class Initialized
INFO - 2024-03-02 12:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 12:07:24 --> Parser Class Initialized
INFO - 2024-03-02 12:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 12:07:24 --> Pagination Class Initialized
INFO - 2024-03-02 12:07:24 --> Form Validation Class Initialized
INFO - 2024-03-02 12:07:24 --> Controller Class Initialized
INFO - 2024-03-02 12:07:24 --> Model Class Initialized
DEBUG - 2024-03-02 12:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 12:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 12:07:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 12:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 12:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 12:07:24 --> Model Class Initialized
INFO - 2024-03-02 12:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 12:07:24 --> Final output sent to browser
DEBUG - 2024-03-02 12:07:24 --> Total execution time: 0.0311
ERROR - 2024-03-02 14:24:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:24:45 --> Config Class Initialized
INFO - 2024-03-02 14:24:45 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:24:45 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:24:45 --> Utf8 Class Initialized
INFO - 2024-03-02 14:24:45 --> URI Class Initialized
DEBUG - 2024-03-02 14:24:45 --> No URI present. Default controller set.
INFO - 2024-03-02 14:24:45 --> Router Class Initialized
INFO - 2024-03-02 14:24:45 --> Output Class Initialized
INFO - 2024-03-02 14:24:45 --> Security Class Initialized
DEBUG - 2024-03-02 14:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:24:45 --> Input Class Initialized
INFO - 2024-03-02 14:24:45 --> Language Class Initialized
INFO - 2024-03-02 14:24:45 --> Loader Class Initialized
INFO - 2024-03-02 14:24:45 --> Helper loaded: url_helper
INFO - 2024-03-02 14:24:45 --> Helper loaded: file_helper
INFO - 2024-03-02 14:24:45 --> Helper loaded: html_helper
INFO - 2024-03-02 14:24:45 --> Helper loaded: text_helper
INFO - 2024-03-02 14:24:45 --> Helper loaded: form_helper
INFO - 2024-03-02 14:24:45 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:24:45 --> Helper loaded: security_helper
INFO - 2024-03-02 14:24:45 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:24:45 --> Database Driver Class Initialized
INFO - 2024-03-02 14:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:24:45 --> Parser Class Initialized
INFO - 2024-03-02 14:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:24:45 --> Pagination Class Initialized
INFO - 2024-03-02 14:24:45 --> Form Validation Class Initialized
INFO - 2024-03-02 14:24:45 --> Controller Class Initialized
INFO - 2024-03-02 14:24:45 --> Model Class Initialized
DEBUG - 2024-03-02 14:24:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 14:24:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:24:46 --> Config Class Initialized
INFO - 2024-03-02 14:24:46 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:24:46 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:24:46 --> Utf8 Class Initialized
INFO - 2024-03-02 14:24:46 --> URI Class Initialized
INFO - 2024-03-02 14:24:46 --> Router Class Initialized
INFO - 2024-03-02 14:24:46 --> Output Class Initialized
INFO - 2024-03-02 14:24:46 --> Security Class Initialized
DEBUG - 2024-03-02 14:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:24:46 --> Input Class Initialized
INFO - 2024-03-02 14:24:46 --> Language Class Initialized
INFO - 2024-03-02 14:24:46 --> Loader Class Initialized
INFO - 2024-03-02 14:24:46 --> Helper loaded: url_helper
INFO - 2024-03-02 14:24:46 --> Helper loaded: file_helper
INFO - 2024-03-02 14:24:46 --> Helper loaded: html_helper
INFO - 2024-03-02 14:24:46 --> Helper loaded: text_helper
INFO - 2024-03-02 14:24:46 --> Helper loaded: form_helper
INFO - 2024-03-02 14:24:46 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:24:46 --> Helper loaded: security_helper
INFO - 2024-03-02 14:24:46 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:24:46 --> Database Driver Class Initialized
INFO - 2024-03-02 14:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:24:46 --> Parser Class Initialized
INFO - 2024-03-02 14:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:24:46 --> Pagination Class Initialized
INFO - 2024-03-02 14:24:46 --> Form Validation Class Initialized
INFO - 2024-03-02 14:24:46 --> Controller Class Initialized
INFO - 2024-03-02 14:24:46 --> Model Class Initialized
DEBUG - 2024-03-02 14:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 14:24:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 14:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 14:24:46 --> Model Class Initialized
INFO - 2024-03-02 14:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 14:24:46 --> Final output sent to browser
DEBUG - 2024-03-02 14:24:46 --> Total execution time: 0.0414
ERROR - 2024-03-02 14:25:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:25:13 --> Config Class Initialized
INFO - 2024-03-02 14:25:13 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:25:13 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:25:13 --> Utf8 Class Initialized
INFO - 2024-03-02 14:25:13 --> URI Class Initialized
INFO - 2024-03-02 14:25:13 --> Router Class Initialized
INFO - 2024-03-02 14:25:13 --> Output Class Initialized
INFO - 2024-03-02 14:25:13 --> Security Class Initialized
DEBUG - 2024-03-02 14:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:25:13 --> Input Class Initialized
INFO - 2024-03-02 14:25:13 --> Language Class Initialized
INFO - 2024-03-02 14:25:13 --> Loader Class Initialized
INFO - 2024-03-02 14:25:13 --> Helper loaded: url_helper
INFO - 2024-03-02 14:25:13 --> Helper loaded: file_helper
INFO - 2024-03-02 14:25:13 --> Helper loaded: html_helper
INFO - 2024-03-02 14:25:13 --> Helper loaded: text_helper
INFO - 2024-03-02 14:25:13 --> Helper loaded: form_helper
INFO - 2024-03-02 14:25:13 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:25:13 --> Helper loaded: security_helper
INFO - 2024-03-02 14:25:13 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:25:13 --> Database Driver Class Initialized
INFO - 2024-03-02 14:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:25:13 --> Parser Class Initialized
INFO - 2024-03-02 14:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:25:13 --> Pagination Class Initialized
INFO - 2024-03-02 14:25:13 --> Form Validation Class Initialized
INFO - 2024-03-02 14:25:13 --> Controller Class Initialized
INFO - 2024-03-02 14:25:13 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:13 --> Model Class Initialized
INFO - 2024-03-02 14:25:13 --> Final output sent to browser
DEBUG - 2024-03-02 14:25:13 --> Total execution time: 0.0209
ERROR - 2024-03-02 14:25:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:25:14 --> Config Class Initialized
INFO - 2024-03-02 14:25:14 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:25:14 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:25:14 --> Utf8 Class Initialized
INFO - 2024-03-02 14:25:14 --> URI Class Initialized
DEBUG - 2024-03-02 14:25:14 --> No URI present. Default controller set.
INFO - 2024-03-02 14:25:14 --> Router Class Initialized
INFO - 2024-03-02 14:25:14 --> Output Class Initialized
INFO - 2024-03-02 14:25:14 --> Security Class Initialized
DEBUG - 2024-03-02 14:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:25:14 --> Input Class Initialized
INFO - 2024-03-02 14:25:14 --> Language Class Initialized
INFO - 2024-03-02 14:25:14 --> Loader Class Initialized
INFO - 2024-03-02 14:25:14 --> Helper loaded: url_helper
INFO - 2024-03-02 14:25:14 --> Helper loaded: file_helper
INFO - 2024-03-02 14:25:14 --> Helper loaded: html_helper
INFO - 2024-03-02 14:25:14 --> Helper loaded: text_helper
INFO - 2024-03-02 14:25:14 --> Helper loaded: form_helper
INFO - 2024-03-02 14:25:14 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:25:14 --> Helper loaded: security_helper
INFO - 2024-03-02 14:25:14 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:25:14 --> Database Driver Class Initialized
INFO - 2024-03-02 14:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:25:14 --> Parser Class Initialized
INFO - 2024-03-02 14:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:25:14 --> Pagination Class Initialized
INFO - 2024-03-02 14:25:14 --> Form Validation Class Initialized
INFO - 2024-03-02 14:25:14 --> Controller Class Initialized
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 14:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
INFO - 2024-03-02 14:25:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-02 14:25:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 14:25:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 14:25:14 --> Model Class Initialized
INFO - 2024-03-02 14:25:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 14:25:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 14:25:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 14:25:14 --> Final output sent to browser
DEBUG - 2024-03-02 14:25:14 --> Total execution time: 0.2638
ERROR - 2024-03-02 14:25:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:25:23 --> Config Class Initialized
INFO - 2024-03-02 14:25:23 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:25:23 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:25:23 --> Utf8 Class Initialized
INFO - 2024-03-02 14:25:23 --> URI Class Initialized
INFO - 2024-03-02 14:25:23 --> Router Class Initialized
INFO - 2024-03-02 14:25:23 --> Output Class Initialized
INFO - 2024-03-02 14:25:23 --> Security Class Initialized
DEBUG - 2024-03-02 14:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:25:23 --> Input Class Initialized
INFO - 2024-03-02 14:25:23 --> Language Class Initialized
INFO - 2024-03-02 14:25:23 --> Loader Class Initialized
INFO - 2024-03-02 14:25:23 --> Helper loaded: url_helper
INFO - 2024-03-02 14:25:23 --> Helper loaded: file_helper
INFO - 2024-03-02 14:25:23 --> Helper loaded: html_helper
INFO - 2024-03-02 14:25:23 --> Helper loaded: text_helper
INFO - 2024-03-02 14:25:23 --> Helper loaded: form_helper
INFO - 2024-03-02 14:25:23 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:25:23 --> Helper loaded: security_helper
INFO - 2024-03-02 14:25:23 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:25:23 --> Database Driver Class Initialized
INFO - 2024-03-02 14:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:25:23 --> Parser Class Initialized
INFO - 2024-03-02 14:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:25:23 --> Pagination Class Initialized
INFO - 2024-03-02 14:25:23 --> Form Validation Class Initialized
INFO - 2024-03-02 14:25:23 --> Controller Class Initialized
INFO - 2024-03-02 14:25:23 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 14:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:23 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:23 --> Model Class Initialized
INFO - 2024-03-02 14:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-02 14:25:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 14:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 14:25:23 --> Model Class Initialized
INFO - 2024-03-02 14:25:23 --> Model Class Initialized
INFO - 2024-03-02 14:25:23 --> Model Class Initialized
INFO - 2024-03-02 14:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-02 14:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-02 14:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 14:25:23 --> Final output sent to browser
DEBUG - 2024-03-02 14:25:23 --> Total execution time: 0.1447
ERROR - 2024-03-02 14:25:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:25:24 --> Config Class Initialized
INFO - 2024-03-02 14:25:24 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:25:24 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:25:24 --> Utf8 Class Initialized
INFO - 2024-03-02 14:25:24 --> URI Class Initialized
INFO - 2024-03-02 14:25:24 --> Router Class Initialized
INFO - 2024-03-02 14:25:24 --> Output Class Initialized
INFO - 2024-03-02 14:25:24 --> Security Class Initialized
DEBUG - 2024-03-02 14:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:25:24 --> Input Class Initialized
INFO - 2024-03-02 14:25:24 --> Language Class Initialized
INFO - 2024-03-02 14:25:24 --> Loader Class Initialized
INFO - 2024-03-02 14:25:24 --> Helper loaded: url_helper
INFO - 2024-03-02 14:25:24 --> Helper loaded: file_helper
INFO - 2024-03-02 14:25:24 --> Helper loaded: html_helper
INFO - 2024-03-02 14:25:24 --> Helper loaded: text_helper
INFO - 2024-03-02 14:25:24 --> Helper loaded: form_helper
INFO - 2024-03-02 14:25:24 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:25:24 --> Helper loaded: security_helper
INFO - 2024-03-02 14:25:24 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:25:24 --> Database Driver Class Initialized
INFO - 2024-03-02 14:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:25:24 --> Parser Class Initialized
INFO - 2024-03-02 14:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:25:24 --> Pagination Class Initialized
INFO - 2024-03-02 14:25:24 --> Form Validation Class Initialized
INFO - 2024-03-02 14:25:24 --> Controller Class Initialized
INFO - 2024-03-02 14:25:24 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-02 14:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:24 --> Model Class Initialized
DEBUG - 2024-03-02 14:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:25:24 --> Model Class Initialized
INFO - 2024-03-02 14:25:24 --> Final output sent to browser
DEBUG - 2024-03-02 14:25:24 --> Total execution time: 0.0216
ERROR - 2024-03-02 14:26:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:26:08 --> Config Class Initialized
INFO - 2024-03-02 14:26:08 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:26:08 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:26:08 --> Utf8 Class Initialized
INFO - 2024-03-02 14:26:08 --> URI Class Initialized
DEBUG - 2024-03-02 14:26:08 --> No URI present. Default controller set.
INFO - 2024-03-02 14:26:08 --> Router Class Initialized
INFO - 2024-03-02 14:26:08 --> Output Class Initialized
INFO - 2024-03-02 14:26:08 --> Security Class Initialized
DEBUG - 2024-03-02 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:26:08 --> Input Class Initialized
INFO - 2024-03-02 14:26:08 --> Language Class Initialized
INFO - 2024-03-02 14:26:08 --> Loader Class Initialized
INFO - 2024-03-02 14:26:08 --> Helper loaded: url_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: file_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: html_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: text_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: form_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: security_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:26:08 --> Database Driver Class Initialized
INFO - 2024-03-02 14:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:26:08 --> Parser Class Initialized
INFO - 2024-03-02 14:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:26:08 --> Pagination Class Initialized
INFO - 2024-03-02 14:26:08 --> Form Validation Class Initialized
INFO - 2024-03-02 14:26:08 --> Controller Class Initialized
INFO - 2024-03-02 14:26:08 --> Model Class Initialized
DEBUG - 2024-03-02 14:26:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-02 14:26:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-02 14:26:08 --> Config Class Initialized
INFO - 2024-03-02 14:26:08 --> Hooks Class Initialized
DEBUG - 2024-03-02 14:26:08 --> UTF-8 Support Enabled
INFO - 2024-03-02 14:26:08 --> Utf8 Class Initialized
INFO - 2024-03-02 14:26:08 --> URI Class Initialized
INFO - 2024-03-02 14:26:08 --> Router Class Initialized
INFO - 2024-03-02 14:26:08 --> Output Class Initialized
INFO - 2024-03-02 14:26:08 --> Security Class Initialized
DEBUG - 2024-03-02 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-02 14:26:08 --> Input Class Initialized
INFO - 2024-03-02 14:26:08 --> Language Class Initialized
INFO - 2024-03-02 14:26:08 --> Loader Class Initialized
INFO - 2024-03-02 14:26:08 --> Helper loaded: url_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: file_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: html_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: text_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: form_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: lang_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: security_helper
INFO - 2024-03-02 14:26:08 --> Helper loaded: cookie_helper
INFO - 2024-03-02 14:26:08 --> Database Driver Class Initialized
INFO - 2024-03-02 14:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-02 14:26:08 --> Parser Class Initialized
INFO - 2024-03-02 14:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-02 14:26:08 --> Pagination Class Initialized
INFO - 2024-03-02 14:26:08 --> Form Validation Class Initialized
INFO - 2024-03-02 14:26:08 --> Controller Class Initialized
INFO - 2024-03-02 14:26:08 --> Model Class Initialized
DEBUG - 2024-03-02 14:26:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:26:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-02 14:26:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-02 14:26:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-02 14:26:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-02 14:26:08 --> Model Class Initialized
INFO - 2024-03-02 14:26:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-02 14:26:08 --> Final output sent to browser
DEBUG - 2024-03-02 14:26:08 --> Total execution time: 0.0324
