<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-23 06:13:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:13:53 --> Config Class Initialized
INFO - 2023-09-23 06:13:53 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:13:53 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:13:53 --> Utf8 Class Initialized
INFO - 2023-09-23 06:13:53 --> URI Class Initialized
DEBUG - 2023-09-23 06:13:53 --> No URI present. Default controller set.
INFO - 2023-09-23 06:13:53 --> Router Class Initialized
INFO - 2023-09-23 06:13:53 --> Output Class Initialized
INFO - 2023-09-23 06:13:53 --> Security Class Initialized
DEBUG - 2023-09-23 06:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:13:53 --> Input Class Initialized
INFO - 2023-09-23 06:13:53 --> Language Class Initialized
INFO - 2023-09-23 06:13:53 --> Loader Class Initialized
INFO - 2023-09-23 06:13:53 --> Helper loaded: url_helper
INFO - 2023-09-23 06:13:53 --> Helper loaded: file_helper
INFO - 2023-09-23 06:13:53 --> Helper loaded: html_helper
INFO - 2023-09-23 06:13:53 --> Helper loaded: text_helper
INFO - 2023-09-23 06:13:53 --> Helper loaded: form_helper
INFO - 2023-09-23 06:13:53 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:13:53 --> Helper loaded: security_helper
INFO - 2023-09-23 06:13:53 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:13:53 --> Database Driver Class Initialized
INFO - 2023-09-23 06:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:13:53 --> Parser Class Initialized
INFO - 2023-09-23 06:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:13:53 --> Pagination Class Initialized
INFO - 2023-09-23 06:13:53 --> Form Validation Class Initialized
INFO - 2023-09-23 06:13:53 --> Controller Class Initialized
INFO - 2023-09-23 06:13:53 --> Model Class Initialized
DEBUG - 2023-09-23 06:13:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 06:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:13:54 --> Config Class Initialized
INFO - 2023-09-23 06:13:54 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:13:54 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:13:54 --> Utf8 Class Initialized
INFO - 2023-09-23 06:13:54 --> URI Class Initialized
INFO - 2023-09-23 06:13:54 --> Router Class Initialized
INFO - 2023-09-23 06:13:54 --> Output Class Initialized
INFO - 2023-09-23 06:13:54 --> Security Class Initialized
DEBUG - 2023-09-23 06:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:13:54 --> Input Class Initialized
INFO - 2023-09-23 06:13:54 --> Language Class Initialized
INFO - 2023-09-23 06:13:54 --> Loader Class Initialized
INFO - 2023-09-23 06:13:54 --> Helper loaded: url_helper
INFO - 2023-09-23 06:13:54 --> Helper loaded: file_helper
INFO - 2023-09-23 06:13:54 --> Helper loaded: html_helper
INFO - 2023-09-23 06:13:54 --> Helper loaded: text_helper
INFO - 2023-09-23 06:13:54 --> Helper loaded: form_helper
INFO - 2023-09-23 06:13:54 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:13:54 --> Helper loaded: security_helper
INFO - 2023-09-23 06:13:54 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:13:54 --> Database Driver Class Initialized
INFO - 2023-09-23 06:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:13:54 --> Parser Class Initialized
INFO - 2023-09-23 06:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:13:54 --> Pagination Class Initialized
INFO - 2023-09-23 06:13:54 --> Form Validation Class Initialized
INFO - 2023-09-23 06:13:54 --> Controller Class Initialized
INFO - 2023-09-23 06:13:54 --> Model Class Initialized
DEBUG - 2023-09-23 06:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-23 06:13:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:13:54 --> Model Class Initialized
INFO - 2023-09-23 06:13:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:13:54 --> Final output sent to browser
DEBUG - 2023-09-23 06:13:54 --> Total execution time: 0.0319
ERROR - 2023-09-23 06:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:14:13 --> Config Class Initialized
INFO - 2023-09-23 06:14:13 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:14:13 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:14:13 --> Utf8 Class Initialized
INFO - 2023-09-23 06:14:13 --> URI Class Initialized
INFO - 2023-09-23 06:14:13 --> Router Class Initialized
INFO - 2023-09-23 06:14:13 --> Output Class Initialized
INFO - 2023-09-23 06:14:13 --> Security Class Initialized
DEBUG - 2023-09-23 06:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:14:13 --> Input Class Initialized
INFO - 2023-09-23 06:14:13 --> Language Class Initialized
INFO - 2023-09-23 06:14:13 --> Loader Class Initialized
INFO - 2023-09-23 06:14:13 --> Helper loaded: url_helper
INFO - 2023-09-23 06:14:13 --> Helper loaded: file_helper
INFO - 2023-09-23 06:14:13 --> Helper loaded: html_helper
INFO - 2023-09-23 06:14:13 --> Helper loaded: text_helper
INFO - 2023-09-23 06:14:13 --> Helper loaded: form_helper
INFO - 2023-09-23 06:14:13 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:14:13 --> Helper loaded: security_helper
INFO - 2023-09-23 06:14:13 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:14:13 --> Database Driver Class Initialized
INFO - 2023-09-23 06:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:14:13 --> Parser Class Initialized
INFO - 2023-09-23 06:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:14:13 --> Pagination Class Initialized
INFO - 2023-09-23 06:14:13 --> Form Validation Class Initialized
INFO - 2023-09-23 06:14:13 --> Controller Class Initialized
INFO - 2023-09-23 06:14:13 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:13 --> Model Class Initialized
INFO - 2023-09-23 06:14:13 --> Final output sent to browser
DEBUG - 2023-09-23 06:14:13 --> Total execution time: 0.0234
ERROR - 2023-09-23 06:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:14:14 --> Config Class Initialized
INFO - 2023-09-23 06:14:14 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:14:14 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:14:14 --> Utf8 Class Initialized
INFO - 2023-09-23 06:14:14 --> URI Class Initialized
DEBUG - 2023-09-23 06:14:14 --> No URI present. Default controller set.
INFO - 2023-09-23 06:14:14 --> Router Class Initialized
INFO - 2023-09-23 06:14:14 --> Output Class Initialized
INFO - 2023-09-23 06:14:14 --> Security Class Initialized
DEBUG - 2023-09-23 06:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:14:14 --> Input Class Initialized
INFO - 2023-09-23 06:14:14 --> Language Class Initialized
INFO - 2023-09-23 06:14:14 --> Loader Class Initialized
INFO - 2023-09-23 06:14:14 --> Helper loaded: url_helper
INFO - 2023-09-23 06:14:14 --> Helper loaded: file_helper
INFO - 2023-09-23 06:14:14 --> Helper loaded: html_helper
INFO - 2023-09-23 06:14:14 --> Helper loaded: text_helper
INFO - 2023-09-23 06:14:14 --> Helper loaded: form_helper
INFO - 2023-09-23 06:14:14 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:14:14 --> Helper loaded: security_helper
INFO - 2023-09-23 06:14:14 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:14:14 --> Database Driver Class Initialized
INFO - 2023-09-23 06:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:14:14 --> Parser Class Initialized
INFO - 2023-09-23 06:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:14:14 --> Pagination Class Initialized
INFO - 2023-09-23 06:14:14 --> Form Validation Class Initialized
INFO - 2023-09-23 06:14:14 --> Controller Class Initialized
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
INFO - 2023-09-23 06:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-23 06:14:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:14:14 --> Model Class Initialized
INFO - 2023-09-23 06:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:14:14 --> Final output sent to browser
DEBUG - 2023-09-23 06:14:14 --> Total execution time: 0.1238
ERROR - 2023-09-23 06:14:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:14:22 --> Config Class Initialized
INFO - 2023-09-23 06:14:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:14:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:14:22 --> Utf8 Class Initialized
INFO - 2023-09-23 06:14:22 --> URI Class Initialized
INFO - 2023-09-23 06:14:22 --> Router Class Initialized
INFO - 2023-09-23 06:14:22 --> Output Class Initialized
INFO - 2023-09-23 06:14:22 --> Security Class Initialized
DEBUG - 2023-09-23 06:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:14:22 --> Input Class Initialized
INFO - 2023-09-23 06:14:22 --> Language Class Initialized
INFO - 2023-09-23 06:14:22 --> Loader Class Initialized
INFO - 2023-09-23 06:14:22 --> Helper loaded: url_helper
INFO - 2023-09-23 06:14:22 --> Helper loaded: file_helper
INFO - 2023-09-23 06:14:22 --> Helper loaded: html_helper
INFO - 2023-09-23 06:14:22 --> Helper loaded: text_helper
INFO - 2023-09-23 06:14:22 --> Helper loaded: form_helper
INFO - 2023-09-23 06:14:22 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:14:22 --> Helper loaded: security_helper
INFO - 2023-09-23 06:14:22 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:14:22 --> Database Driver Class Initialized
INFO - 2023-09-23 06:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:14:22 --> Parser Class Initialized
INFO - 2023-09-23 06:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:14:22 --> Pagination Class Initialized
INFO - 2023-09-23 06:14:22 --> Form Validation Class Initialized
INFO - 2023-09-23 06:14:22 --> Controller Class Initialized
INFO - 2023-09-23 06:14:22 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:22 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:22 --> Model Class Initialized
INFO - 2023-09-23 06:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-23 06:14:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:14:22 --> Model Class Initialized
INFO - 2023-09-23 06:14:22 --> Model Class Initialized
INFO - 2023-09-23 06:14:22 --> Model Class Initialized
INFO - 2023-09-23 06:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:14:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:14:22 --> Final output sent to browser
DEBUG - 2023-09-23 06:14:22 --> Total execution time: 0.0866
ERROR - 2023-09-23 06:14:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:14:23 --> Config Class Initialized
INFO - 2023-09-23 06:14:23 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:14:23 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:14:23 --> Utf8 Class Initialized
INFO - 2023-09-23 06:14:23 --> URI Class Initialized
INFO - 2023-09-23 06:14:23 --> Router Class Initialized
INFO - 2023-09-23 06:14:23 --> Output Class Initialized
INFO - 2023-09-23 06:14:23 --> Security Class Initialized
DEBUG - 2023-09-23 06:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:14:23 --> Input Class Initialized
INFO - 2023-09-23 06:14:23 --> Language Class Initialized
INFO - 2023-09-23 06:14:23 --> Loader Class Initialized
INFO - 2023-09-23 06:14:23 --> Helper loaded: url_helper
INFO - 2023-09-23 06:14:23 --> Helper loaded: file_helper
INFO - 2023-09-23 06:14:23 --> Helper loaded: html_helper
INFO - 2023-09-23 06:14:23 --> Helper loaded: text_helper
INFO - 2023-09-23 06:14:23 --> Helper loaded: form_helper
INFO - 2023-09-23 06:14:23 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:14:23 --> Helper loaded: security_helper
INFO - 2023-09-23 06:14:23 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:14:23 --> Database Driver Class Initialized
INFO - 2023-09-23 06:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:14:23 --> Parser Class Initialized
INFO - 2023-09-23 06:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:14:23 --> Pagination Class Initialized
INFO - 2023-09-23 06:14:23 --> Form Validation Class Initialized
INFO - 2023-09-23 06:14:23 --> Controller Class Initialized
INFO - 2023-09-23 06:14:23 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:23 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:23 --> Model Class Initialized
INFO - 2023-09-23 06:14:23 --> Final output sent to browser
DEBUG - 2023-09-23 06:14:23 --> Total execution time: 0.0396
ERROR - 2023-09-23 06:14:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:14:29 --> Config Class Initialized
INFO - 2023-09-23 06:14:29 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:14:29 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:14:29 --> Utf8 Class Initialized
INFO - 2023-09-23 06:14:29 --> URI Class Initialized
INFO - 2023-09-23 06:14:29 --> Router Class Initialized
INFO - 2023-09-23 06:14:29 --> Output Class Initialized
INFO - 2023-09-23 06:14:29 --> Security Class Initialized
DEBUG - 2023-09-23 06:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:14:29 --> Input Class Initialized
INFO - 2023-09-23 06:14:29 --> Language Class Initialized
INFO - 2023-09-23 06:14:29 --> Loader Class Initialized
INFO - 2023-09-23 06:14:29 --> Helper loaded: url_helper
INFO - 2023-09-23 06:14:29 --> Helper loaded: file_helper
INFO - 2023-09-23 06:14:29 --> Helper loaded: html_helper
INFO - 2023-09-23 06:14:29 --> Helper loaded: text_helper
INFO - 2023-09-23 06:14:29 --> Helper loaded: form_helper
INFO - 2023-09-23 06:14:29 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:14:29 --> Helper loaded: security_helper
INFO - 2023-09-23 06:14:29 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:14:29 --> Database Driver Class Initialized
INFO - 2023-09-23 06:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:14:29 --> Parser Class Initialized
INFO - 2023-09-23 06:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:14:29 --> Pagination Class Initialized
INFO - 2023-09-23 06:14:29 --> Form Validation Class Initialized
INFO - 2023-09-23 06:14:29 --> Controller Class Initialized
INFO - 2023-09-23 06:14:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:14:29 --> Model Class Initialized
INFO - 2023-09-23 06:14:29 --> Final output sent to browser
DEBUG - 2023-09-23 06:14:29 --> Total execution time: 0.1141
ERROR - 2023-09-23 06:15:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:29 --> Config Class Initialized
INFO - 2023-09-23 06:15:29 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:29 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:29 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:29 --> URI Class Initialized
INFO - 2023-09-23 06:15:29 --> Router Class Initialized
INFO - 2023-09-23 06:15:29 --> Output Class Initialized
INFO - 2023-09-23 06:15:29 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:29 --> Input Class Initialized
INFO - 2023-09-23 06:15:29 --> Language Class Initialized
INFO - 2023-09-23 06:15:29 --> Loader Class Initialized
INFO - 2023-09-23 06:15:29 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:29 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:29 --> Parser Class Initialized
INFO - 2023-09-23 06:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:29 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:29 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:29 --> Controller Class Initialized
INFO - 2023-09-23 06:15:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:29 --> Model Class Initialized
INFO - 2023-09-23 06:15:29 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:29 --> Total execution time: 0.1136
ERROR - 2023-09-23 06:15:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:29 --> Config Class Initialized
INFO - 2023-09-23 06:15:29 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:29 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:29 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:29 --> URI Class Initialized
INFO - 2023-09-23 06:15:29 --> Router Class Initialized
INFO - 2023-09-23 06:15:29 --> Output Class Initialized
INFO - 2023-09-23 06:15:29 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:29 --> Input Class Initialized
INFO - 2023-09-23 06:15:29 --> Language Class Initialized
INFO - 2023-09-23 06:15:29 --> Loader Class Initialized
INFO - 2023-09-23 06:15:29 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:29 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:29 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:29 --> Parser Class Initialized
INFO - 2023-09-23 06:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:29 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:29 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:29 --> Controller Class Initialized
INFO - 2023-09-23 06:15:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:29 --> Model Class Initialized
INFO - 2023-09-23 06:15:29 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:29 --> Total execution time: 0.0719
ERROR - 2023-09-23 06:15:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:30 --> Config Class Initialized
INFO - 2023-09-23 06:15:30 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:30 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:30 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:30 --> URI Class Initialized
INFO - 2023-09-23 06:15:30 --> Router Class Initialized
INFO - 2023-09-23 06:15:30 --> Output Class Initialized
INFO - 2023-09-23 06:15:30 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:30 --> Input Class Initialized
INFO - 2023-09-23 06:15:30 --> Language Class Initialized
INFO - 2023-09-23 06:15:30 --> Loader Class Initialized
INFO - 2023-09-23 06:15:30 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:30 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:30 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:30 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:30 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:30 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:30 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:30 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:30 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:30 --> Parser Class Initialized
INFO - 2023-09-23 06:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:30 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:30 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:30 --> Controller Class Initialized
INFO - 2023-09-23 06:15:30 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:30 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:30 --> Model Class Initialized
INFO - 2023-09-23 06:15:30 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:30 --> Total execution time: 0.0216
ERROR - 2023-09-23 06:15:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:32 --> Config Class Initialized
INFO - 2023-09-23 06:15:32 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:32 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:32 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:32 --> URI Class Initialized
INFO - 2023-09-23 06:15:32 --> Router Class Initialized
INFO - 2023-09-23 06:15:32 --> Output Class Initialized
INFO - 2023-09-23 06:15:32 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:32 --> Input Class Initialized
INFO - 2023-09-23 06:15:32 --> Language Class Initialized
INFO - 2023-09-23 06:15:32 --> Loader Class Initialized
INFO - 2023-09-23 06:15:32 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:32 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:32 --> Parser Class Initialized
INFO - 2023-09-23 06:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:32 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:32 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:32 --> Controller Class Initialized
INFO - 2023-09-23 06:15:32 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:32 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:32 --> Model Class Initialized
INFO - 2023-09-23 06:15:32 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:32 --> Total execution time: 0.0736
ERROR - 2023-09-23 06:15:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:32 --> Config Class Initialized
INFO - 2023-09-23 06:15:32 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:32 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:32 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:32 --> URI Class Initialized
INFO - 2023-09-23 06:15:32 --> Router Class Initialized
INFO - 2023-09-23 06:15:32 --> Output Class Initialized
INFO - 2023-09-23 06:15:32 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:32 --> Input Class Initialized
INFO - 2023-09-23 06:15:32 --> Language Class Initialized
INFO - 2023-09-23 06:15:32 --> Loader Class Initialized
INFO - 2023-09-23 06:15:32 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:32 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:32 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:32 --> Parser Class Initialized
INFO - 2023-09-23 06:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:32 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:32 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:32 --> Controller Class Initialized
INFO - 2023-09-23 06:15:32 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:32 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:32 --> Model Class Initialized
INFO - 2023-09-23 06:15:32 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:32 --> Total execution time: 0.1508
ERROR - 2023-09-23 06:15:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:33 --> Config Class Initialized
INFO - 2023-09-23 06:15:33 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:33 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:33 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:33 --> URI Class Initialized
INFO - 2023-09-23 06:15:33 --> Router Class Initialized
INFO - 2023-09-23 06:15:33 --> Output Class Initialized
INFO - 2023-09-23 06:15:33 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:33 --> Input Class Initialized
INFO - 2023-09-23 06:15:33 --> Language Class Initialized
INFO - 2023-09-23 06:15:33 --> Loader Class Initialized
INFO - 2023-09-23 06:15:33 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:33 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:33 --> Parser Class Initialized
INFO - 2023-09-23 06:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:33 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:33 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:33 --> Controller Class Initialized
INFO - 2023-09-23 06:15:33 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:33 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:33 --> Model Class Initialized
INFO - 2023-09-23 06:15:33 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:33 --> Total execution time: 0.1213
ERROR - 2023-09-23 06:15:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:33 --> Config Class Initialized
INFO - 2023-09-23 06:15:33 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:33 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:33 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:33 --> URI Class Initialized
INFO - 2023-09-23 06:15:33 --> Router Class Initialized
INFO - 2023-09-23 06:15:33 --> Output Class Initialized
INFO - 2023-09-23 06:15:33 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:33 --> Input Class Initialized
INFO - 2023-09-23 06:15:33 --> Language Class Initialized
INFO - 2023-09-23 06:15:33 --> Loader Class Initialized
INFO - 2023-09-23 06:15:33 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:33 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:33 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:33 --> Parser Class Initialized
INFO - 2023-09-23 06:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:33 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:33 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:33 --> Controller Class Initialized
INFO - 2023-09-23 06:15:33 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:33 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:33 --> Model Class Initialized
INFO - 2023-09-23 06:15:33 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:33 --> Total execution time: 0.0345
ERROR - 2023-09-23 06:15:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:34 --> Config Class Initialized
INFO - 2023-09-23 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:34 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:34 --> URI Class Initialized
INFO - 2023-09-23 06:15:34 --> Router Class Initialized
INFO - 2023-09-23 06:15:34 --> Output Class Initialized
INFO - 2023-09-23 06:15:34 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:34 --> Input Class Initialized
INFO - 2023-09-23 06:15:34 --> Language Class Initialized
INFO - 2023-09-23 06:15:34 --> Loader Class Initialized
INFO - 2023-09-23 06:15:34 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:34 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:34 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:34 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:34 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:34 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:34 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:34 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:34 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:34 --> Parser Class Initialized
INFO - 2023-09-23 06:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:34 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:34 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:34 --> Controller Class Initialized
INFO - 2023-09-23 06:15:34 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:34 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:34 --> Model Class Initialized
INFO - 2023-09-23 06:15:34 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:34 --> Total execution time: 0.0206
ERROR - 2023-09-23 06:15:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:35 --> Config Class Initialized
INFO - 2023-09-23 06:15:35 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:35 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:35 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:35 --> URI Class Initialized
INFO - 2023-09-23 06:15:35 --> Router Class Initialized
INFO - 2023-09-23 06:15:35 --> Output Class Initialized
INFO - 2023-09-23 06:15:35 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:35 --> Input Class Initialized
INFO - 2023-09-23 06:15:35 --> Language Class Initialized
INFO - 2023-09-23 06:15:35 --> Loader Class Initialized
INFO - 2023-09-23 06:15:35 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:35 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:35 --> Parser Class Initialized
INFO - 2023-09-23 06:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:35 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:35 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:35 --> Controller Class Initialized
INFO - 2023-09-23 06:15:35 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:35 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:35 --> Model Class Initialized
INFO - 2023-09-23 06:15:35 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:35 --> Total execution time: 0.0229
ERROR - 2023-09-23 06:15:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:35 --> Config Class Initialized
INFO - 2023-09-23 06:15:35 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:35 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:35 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:35 --> URI Class Initialized
INFO - 2023-09-23 06:15:35 --> Router Class Initialized
INFO - 2023-09-23 06:15:35 --> Output Class Initialized
INFO - 2023-09-23 06:15:35 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:35 --> Input Class Initialized
INFO - 2023-09-23 06:15:35 --> Language Class Initialized
INFO - 2023-09-23 06:15:35 --> Loader Class Initialized
INFO - 2023-09-23 06:15:35 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:35 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:35 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:35 --> Parser Class Initialized
INFO - 2023-09-23 06:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:35 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:35 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:35 --> Controller Class Initialized
INFO - 2023-09-23 06:15:35 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:35 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:35 --> Model Class Initialized
INFO - 2023-09-23 06:15:35 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:35 --> Total execution time: 0.0204
ERROR - 2023-09-23 06:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:36 --> Config Class Initialized
INFO - 2023-09-23 06:15:36 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:36 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:36 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:36 --> URI Class Initialized
INFO - 2023-09-23 06:15:36 --> Router Class Initialized
INFO - 2023-09-23 06:15:36 --> Output Class Initialized
INFO - 2023-09-23 06:15:36 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:36 --> Input Class Initialized
INFO - 2023-09-23 06:15:36 --> Language Class Initialized
INFO - 2023-09-23 06:15:36 --> Loader Class Initialized
INFO - 2023-09-23 06:15:36 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:36 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:36 --> Parser Class Initialized
INFO - 2023-09-23 06:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:36 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:36 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:36 --> Controller Class Initialized
INFO - 2023-09-23 06:15:36 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:36 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:36 --> Model Class Initialized
INFO - 2023-09-23 06:15:36 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:36 --> Total execution time: 0.0233
ERROR - 2023-09-23 06:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:36 --> Config Class Initialized
INFO - 2023-09-23 06:15:36 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:36 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:36 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:36 --> URI Class Initialized
INFO - 2023-09-23 06:15:36 --> Router Class Initialized
INFO - 2023-09-23 06:15:36 --> Output Class Initialized
INFO - 2023-09-23 06:15:36 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:36 --> Input Class Initialized
INFO - 2023-09-23 06:15:36 --> Language Class Initialized
INFO - 2023-09-23 06:15:36 --> Loader Class Initialized
INFO - 2023-09-23 06:15:36 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:36 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:36 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:36 --> Parser Class Initialized
INFO - 2023-09-23 06:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:36 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:36 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:36 --> Controller Class Initialized
INFO - 2023-09-23 06:15:36 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:36 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:36 --> Model Class Initialized
INFO - 2023-09-23 06:15:36 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:36 --> Total execution time: 0.1296
ERROR - 2023-09-23 06:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:37 --> Config Class Initialized
INFO - 2023-09-23 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:37 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:37 --> URI Class Initialized
INFO - 2023-09-23 06:15:37 --> Router Class Initialized
INFO - 2023-09-23 06:15:37 --> Output Class Initialized
INFO - 2023-09-23 06:15:37 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:37 --> Input Class Initialized
INFO - 2023-09-23 06:15:37 --> Language Class Initialized
INFO - 2023-09-23 06:15:37 --> Loader Class Initialized
INFO - 2023-09-23 06:15:37 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:37 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:37 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:37 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:37 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:37 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:37 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:37 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:37 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:37 --> Parser Class Initialized
INFO - 2023-09-23 06:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:37 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:37 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:37 --> Controller Class Initialized
INFO - 2023-09-23 06:15:37 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:37 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:37 --> Model Class Initialized
INFO - 2023-09-23 06:15:37 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:37 --> Total execution time: 0.1341
ERROR - 2023-09-23 06:15:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:39 --> Config Class Initialized
INFO - 2023-09-23 06:15:39 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:39 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:39 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:39 --> URI Class Initialized
INFO - 2023-09-23 06:15:39 --> Router Class Initialized
INFO - 2023-09-23 06:15:39 --> Output Class Initialized
INFO - 2023-09-23 06:15:39 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:39 --> Input Class Initialized
INFO - 2023-09-23 06:15:39 --> Language Class Initialized
INFO - 2023-09-23 06:15:39 --> Loader Class Initialized
INFO - 2023-09-23 06:15:39 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:39 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:39 --> Parser Class Initialized
INFO - 2023-09-23 06:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:39 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:39 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:39 --> Controller Class Initialized
INFO - 2023-09-23 06:15:39 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:39 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:39 --> Model Class Initialized
INFO - 2023-09-23 06:15:39 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:39 --> Total execution time: 0.1187
ERROR - 2023-09-23 06:15:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:39 --> Config Class Initialized
INFO - 2023-09-23 06:15:39 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:39 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:39 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:39 --> URI Class Initialized
INFO - 2023-09-23 06:15:39 --> Router Class Initialized
INFO - 2023-09-23 06:15:39 --> Output Class Initialized
INFO - 2023-09-23 06:15:39 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:39 --> Input Class Initialized
INFO - 2023-09-23 06:15:39 --> Language Class Initialized
INFO - 2023-09-23 06:15:39 --> Loader Class Initialized
INFO - 2023-09-23 06:15:39 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:39 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:39 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:39 --> Parser Class Initialized
INFO - 2023-09-23 06:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:39 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:39 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:39 --> Controller Class Initialized
INFO - 2023-09-23 06:15:39 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:39 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:39 --> Model Class Initialized
INFO - 2023-09-23 06:15:39 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:39 --> Total execution time: 0.0214
ERROR - 2023-09-23 06:15:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:40 --> Config Class Initialized
INFO - 2023-09-23 06:15:40 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:40 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:40 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:40 --> URI Class Initialized
INFO - 2023-09-23 06:15:40 --> Router Class Initialized
INFO - 2023-09-23 06:15:40 --> Output Class Initialized
INFO - 2023-09-23 06:15:40 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:40 --> Input Class Initialized
INFO - 2023-09-23 06:15:40 --> Language Class Initialized
INFO - 2023-09-23 06:15:40 --> Loader Class Initialized
INFO - 2023-09-23 06:15:40 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:40 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:40 --> Parser Class Initialized
INFO - 2023-09-23 06:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:40 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:40 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:40 --> Controller Class Initialized
INFO - 2023-09-23 06:15:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:40 --> Model Class Initialized
INFO - 2023-09-23 06:15:40 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:40 --> Total execution time: 0.0275
ERROR - 2023-09-23 06:15:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:40 --> Config Class Initialized
INFO - 2023-09-23 06:15:40 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:40 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:40 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:40 --> URI Class Initialized
INFO - 2023-09-23 06:15:40 --> Router Class Initialized
INFO - 2023-09-23 06:15:40 --> Output Class Initialized
INFO - 2023-09-23 06:15:40 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:40 --> Input Class Initialized
INFO - 2023-09-23 06:15:40 --> Language Class Initialized
INFO - 2023-09-23 06:15:40 --> Loader Class Initialized
INFO - 2023-09-23 06:15:40 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:40 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:40 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:40 --> Parser Class Initialized
INFO - 2023-09-23 06:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:40 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:40 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:40 --> Controller Class Initialized
INFO - 2023-09-23 06:15:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:40 --> Model Class Initialized
INFO - 2023-09-23 06:15:40 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:40 --> Total execution time: 0.0213
ERROR - 2023-09-23 06:15:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:41 --> Config Class Initialized
INFO - 2023-09-23 06:15:41 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:41 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:41 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:41 --> URI Class Initialized
INFO - 2023-09-23 06:15:41 --> Router Class Initialized
INFO - 2023-09-23 06:15:41 --> Output Class Initialized
INFO - 2023-09-23 06:15:41 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:41 --> Input Class Initialized
INFO - 2023-09-23 06:15:41 --> Language Class Initialized
INFO - 2023-09-23 06:15:41 --> Loader Class Initialized
INFO - 2023-09-23 06:15:41 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:41 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:41 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:41 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:41 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:41 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:41 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:41 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:41 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:41 --> Parser Class Initialized
INFO - 2023-09-23 06:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:41 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:41 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:41 --> Controller Class Initialized
INFO - 2023-09-23 06:15:41 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:41 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:41 --> Model Class Initialized
INFO - 2023-09-23 06:15:41 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:41 --> Total execution time: 0.0212
ERROR - 2023-09-23 06:15:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:42 --> Config Class Initialized
INFO - 2023-09-23 06:15:42 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:42 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:42 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:42 --> URI Class Initialized
INFO - 2023-09-23 06:15:42 --> Router Class Initialized
INFO - 2023-09-23 06:15:42 --> Output Class Initialized
INFO - 2023-09-23 06:15:42 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:42 --> Input Class Initialized
INFO - 2023-09-23 06:15:42 --> Language Class Initialized
INFO - 2023-09-23 06:15:42 --> Loader Class Initialized
INFO - 2023-09-23 06:15:42 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:42 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:42 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:42 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:42 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:42 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:42 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:42 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:42 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:42 --> Parser Class Initialized
INFO - 2023-09-23 06:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:42 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:42 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:42 --> Controller Class Initialized
INFO - 2023-09-23 06:15:42 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:42 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:42 --> Model Class Initialized
INFO - 2023-09-23 06:15:42 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:42 --> Total execution time: 0.0238
ERROR - 2023-09-23 06:15:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:43 --> Config Class Initialized
INFO - 2023-09-23 06:15:43 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:43 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:43 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:43 --> URI Class Initialized
INFO - 2023-09-23 06:15:43 --> Router Class Initialized
INFO - 2023-09-23 06:15:43 --> Output Class Initialized
INFO - 2023-09-23 06:15:43 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:43 --> Input Class Initialized
INFO - 2023-09-23 06:15:43 --> Language Class Initialized
INFO - 2023-09-23 06:15:43 --> Loader Class Initialized
INFO - 2023-09-23 06:15:43 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:43 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:43 --> Parser Class Initialized
INFO - 2023-09-23 06:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:43 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:43 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:43 --> Controller Class Initialized
INFO - 2023-09-23 06:15:43 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:43 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:43 --> Model Class Initialized
INFO - 2023-09-23 06:15:43 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:43 --> Total execution time: 0.0205
ERROR - 2023-09-23 06:15:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:43 --> Config Class Initialized
INFO - 2023-09-23 06:15:43 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:43 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:43 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:43 --> URI Class Initialized
INFO - 2023-09-23 06:15:43 --> Router Class Initialized
INFO - 2023-09-23 06:15:43 --> Output Class Initialized
INFO - 2023-09-23 06:15:43 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:43 --> Input Class Initialized
INFO - 2023-09-23 06:15:43 --> Language Class Initialized
INFO - 2023-09-23 06:15:43 --> Loader Class Initialized
INFO - 2023-09-23 06:15:43 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:43 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:43 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:43 --> Parser Class Initialized
INFO - 2023-09-23 06:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:43 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:43 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:43 --> Controller Class Initialized
INFO - 2023-09-23 06:15:43 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:43 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:43 --> Model Class Initialized
INFO - 2023-09-23 06:15:43 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:43 --> Total execution time: 0.0368
ERROR - 2023-09-23 06:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:49 --> Config Class Initialized
INFO - 2023-09-23 06:15:49 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:49 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:49 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:49 --> URI Class Initialized
INFO - 2023-09-23 06:15:49 --> Router Class Initialized
INFO - 2023-09-23 06:15:49 --> Output Class Initialized
INFO - 2023-09-23 06:15:49 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:49 --> Input Class Initialized
INFO - 2023-09-23 06:15:49 --> Language Class Initialized
INFO - 2023-09-23 06:15:49 --> Loader Class Initialized
INFO - 2023-09-23 06:15:49 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:49 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:49 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:49 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:49 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:49 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:49 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:49 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:49 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:49 --> Parser Class Initialized
INFO - 2023-09-23 06:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:49 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:49 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:49 --> Controller Class Initialized
DEBUG - 2023-09-23 06:15:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:49 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:49 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:49 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:49 --> Model Class Initialized
INFO - 2023-09-23 06:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-23 06:15:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:15:49 --> Model Class Initialized
INFO - 2023-09-23 06:15:49 --> Model Class Initialized
INFO - 2023-09-23 06:15:49 --> Model Class Initialized
INFO - 2023-09-23 06:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:15:49 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:49 --> Total execution time: 0.0811
ERROR - 2023-09-23 06:15:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:50 --> Config Class Initialized
INFO - 2023-09-23 06:15:50 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:50 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:50 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:50 --> URI Class Initialized
INFO - 2023-09-23 06:15:50 --> Router Class Initialized
INFO - 2023-09-23 06:15:50 --> Output Class Initialized
INFO - 2023-09-23 06:15:50 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:50 --> Input Class Initialized
INFO - 2023-09-23 06:15:50 --> Language Class Initialized
INFO - 2023-09-23 06:15:50 --> Loader Class Initialized
INFO - 2023-09-23 06:15:50 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:50 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:50 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:50 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:50 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:50 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:50 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:50 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:50 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:50 --> Parser Class Initialized
INFO - 2023-09-23 06:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:50 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:50 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:50 --> Controller Class Initialized
DEBUG - 2023-09-23 06:15:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:50 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:50 --> Model Class Initialized
INFO - 2023-09-23 06:15:50 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:50 --> Total execution time: 0.0205
ERROR - 2023-09-23 06:15:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:15:53 --> Config Class Initialized
INFO - 2023-09-23 06:15:53 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:15:53 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:15:53 --> Utf8 Class Initialized
INFO - 2023-09-23 06:15:53 --> URI Class Initialized
INFO - 2023-09-23 06:15:53 --> Router Class Initialized
INFO - 2023-09-23 06:15:53 --> Output Class Initialized
INFO - 2023-09-23 06:15:53 --> Security Class Initialized
DEBUG - 2023-09-23 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:15:53 --> Input Class Initialized
INFO - 2023-09-23 06:15:53 --> Language Class Initialized
INFO - 2023-09-23 06:15:53 --> Loader Class Initialized
INFO - 2023-09-23 06:15:53 --> Helper loaded: url_helper
INFO - 2023-09-23 06:15:53 --> Helper loaded: file_helper
INFO - 2023-09-23 06:15:53 --> Helper loaded: html_helper
INFO - 2023-09-23 06:15:53 --> Helper loaded: text_helper
INFO - 2023-09-23 06:15:53 --> Helper loaded: form_helper
INFO - 2023-09-23 06:15:53 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:15:53 --> Helper loaded: security_helper
INFO - 2023-09-23 06:15:53 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:15:53 --> Database Driver Class Initialized
INFO - 2023-09-23 06:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:15:53 --> Parser Class Initialized
INFO - 2023-09-23 06:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:15:53 --> Pagination Class Initialized
INFO - 2023-09-23 06:15:53 --> Form Validation Class Initialized
INFO - 2023-09-23 06:15:53 --> Controller Class Initialized
DEBUG - 2023-09-23 06:15:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:53 --> Model Class Initialized
DEBUG - 2023-09-23 06:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:15:53 --> Model Class Initialized
INFO - 2023-09-23 06:15:53 --> Final output sent to browser
DEBUG - 2023-09-23 06:15:53 --> Total execution time: 0.0307
ERROR - 2023-09-23 06:16:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:15 --> Config Class Initialized
INFO - 2023-09-23 06:16:15 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:15 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:15 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:15 --> URI Class Initialized
INFO - 2023-09-23 06:16:15 --> Router Class Initialized
INFO - 2023-09-23 06:16:15 --> Output Class Initialized
INFO - 2023-09-23 06:16:15 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:15 --> Input Class Initialized
INFO - 2023-09-23 06:16:15 --> Language Class Initialized
INFO - 2023-09-23 06:16:15 --> Loader Class Initialized
INFO - 2023-09-23 06:16:15 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:15 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:15 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:15 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:15 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:15 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:15 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:15 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:15 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:15 --> Parser Class Initialized
INFO - 2023-09-23 06:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:15 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:15 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:15 --> Controller Class Initialized
INFO - 2023-09-23 06:16:15 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:15 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:15 --> Model Class Initialized
INFO - 2023-09-23 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-23 06:16:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:16:16 --> Model Class Initialized
INFO - 2023-09-23 06:16:16 --> Model Class Initialized
INFO - 2023-09-23 06:16:16 --> Model Class Initialized
INFO - 2023-09-23 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:16:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:16:16 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:16 --> Total execution time: 0.2580
ERROR - 2023-09-23 06:16:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:16 --> Config Class Initialized
INFO - 2023-09-23 06:16:16 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:16 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:16 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:16 --> URI Class Initialized
INFO - 2023-09-23 06:16:16 --> Router Class Initialized
INFO - 2023-09-23 06:16:16 --> Output Class Initialized
INFO - 2023-09-23 06:16:16 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:16 --> Input Class Initialized
INFO - 2023-09-23 06:16:16 --> Language Class Initialized
INFO - 2023-09-23 06:16:16 --> Loader Class Initialized
INFO - 2023-09-23 06:16:16 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:16 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:16 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:16 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:16 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:16 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:16 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:16 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:16 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:16 --> Parser Class Initialized
INFO - 2023-09-23 06:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:16 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:16 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:16 --> Controller Class Initialized
INFO - 2023-09-23 06:16:16 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:16 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:16 --> Model Class Initialized
INFO - 2023-09-23 06:16:16 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:16 --> Total execution time: 0.0454
ERROR - 2023-09-23 06:16:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:20 --> Config Class Initialized
INFO - 2023-09-23 06:16:20 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:20 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:20 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:20 --> URI Class Initialized
INFO - 2023-09-23 06:16:20 --> Router Class Initialized
INFO - 2023-09-23 06:16:20 --> Output Class Initialized
INFO - 2023-09-23 06:16:20 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:20 --> Input Class Initialized
INFO - 2023-09-23 06:16:20 --> Language Class Initialized
INFO - 2023-09-23 06:16:20 --> Loader Class Initialized
INFO - 2023-09-23 06:16:20 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:20 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:20 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:21 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:21 --> Parser Class Initialized
INFO - 2023-09-23 06:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:21 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:21 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:21 --> Controller Class Initialized
INFO - 2023-09-23 06:16:21 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:21 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:21 --> Model Class Initialized
INFO - 2023-09-23 06:16:21 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:21 --> Total execution time: 0.0440
ERROR - 2023-09-23 06:16:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:21 --> Config Class Initialized
INFO - 2023-09-23 06:16:21 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:21 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:21 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:21 --> URI Class Initialized
INFO - 2023-09-23 06:16:21 --> Router Class Initialized
INFO - 2023-09-23 06:16:21 --> Output Class Initialized
INFO - 2023-09-23 06:16:21 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:21 --> Input Class Initialized
INFO - 2023-09-23 06:16:21 --> Language Class Initialized
INFO - 2023-09-23 06:16:21 --> Loader Class Initialized
INFO - 2023-09-23 06:16:21 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:21 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:21 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:21 --> Parser Class Initialized
INFO - 2023-09-23 06:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:21 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:21 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:21 --> Controller Class Initialized
INFO - 2023-09-23 06:16:21 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:21 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:21 --> Model Class Initialized
INFO - 2023-09-23 06:16:21 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:21 --> Total execution time: 0.0393
ERROR - 2023-09-23 06:16:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:23 --> Config Class Initialized
INFO - 2023-09-23 06:16:23 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:23 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:23 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:23 --> URI Class Initialized
INFO - 2023-09-23 06:16:23 --> Router Class Initialized
INFO - 2023-09-23 06:16:23 --> Output Class Initialized
INFO - 2023-09-23 06:16:23 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:23 --> Input Class Initialized
INFO - 2023-09-23 06:16:23 --> Language Class Initialized
INFO - 2023-09-23 06:16:23 --> Loader Class Initialized
INFO - 2023-09-23 06:16:23 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:23 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:23 --> Parser Class Initialized
INFO - 2023-09-23 06:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:23 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:23 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:23 --> Controller Class Initialized
INFO - 2023-09-23 06:16:23 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:23 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:23 --> Model Class Initialized
INFO - 2023-09-23 06:16:23 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:23 --> Total execution time: 0.0407
ERROR - 2023-09-23 06:16:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:23 --> Config Class Initialized
INFO - 2023-09-23 06:16:23 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:23 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:23 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:23 --> URI Class Initialized
INFO - 2023-09-23 06:16:23 --> Router Class Initialized
INFO - 2023-09-23 06:16:23 --> Output Class Initialized
INFO - 2023-09-23 06:16:23 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:23 --> Input Class Initialized
INFO - 2023-09-23 06:16:23 --> Language Class Initialized
INFO - 2023-09-23 06:16:23 --> Loader Class Initialized
INFO - 2023-09-23 06:16:23 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:23 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:23 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:23 --> Parser Class Initialized
INFO - 2023-09-23 06:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:23 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:23 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:23 --> Controller Class Initialized
INFO - 2023-09-23 06:16:23 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:23 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:23 --> Model Class Initialized
INFO - 2023-09-23 06:16:23 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:23 --> Total execution time: 0.0395
ERROR - 2023-09-23 06:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:24 --> Config Class Initialized
INFO - 2023-09-23 06:16:24 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:24 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:24 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:24 --> URI Class Initialized
INFO - 2023-09-23 06:16:24 --> Router Class Initialized
INFO - 2023-09-23 06:16:24 --> Output Class Initialized
INFO - 2023-09-23 06:16:24 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:24 --> Input Class Initialized
INFO - 2023-09-23 06:16:24 --> Language Class Initialized
INFO - 2023-09-23 06:16:24 --> Loader Class Initialized
INFO - 2023-09-23 06:16:24 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:24 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:24 --> Parser Class Initialized
INFO - 2023-09-23 06:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:24 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:24 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:24 --> Controller Class Initialized
INFO - 2023-09-23 06:16:24 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:24 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:24 --> Model Class Initialized
INFO - 2023-09-23 06:16:24 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:24 --> Total execution time: 0.0210
ERROR - 2023-09-23 06:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:24 --> Config Class Initialized
INFO - 2023-09-23 06:16:24 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:24 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:24 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:24 --> URI Class Initialized
INFO - 2023-09-23 06:16:24 --> Router Class Initialized
INFO - 2023-09-23 06:16:24 --> Output Class Initialized
INFO - 2023-09-23 06:16:24 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:24 --> Input Class Initialized
INFO - 2023-09-23 06:16:24 --> Language Class Initialized
INFO - 2023-09-23 06:16:24 --> Loader Class Initialized
INFO - 2023-09-23 06:16:24 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:24 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:24 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:24 --> Parser Class Initialized
INFO - 2023-09-23 06:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:24 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:24 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:24 --> Controller Class Initialized
INFO - 2023-09-23 06:16:24 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:24 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:24 --> Model Class Initialized
INFO - 2023-09-23 06:16:24 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:24 --> Total execution time: 0.0273
ERROR - 2023-09-23 06:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:26 --> Config Class Initialized
INFO - 2023-09-23 06:16:26 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:26 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:26 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:26 --> URI Class Initialized
INFO - 2023-09-23 06:16:26 --> Router Class Initialized
INFO - 2023-09-23 06:16:26 --> Output Class Initialized
INFO - 2023-09-23 06:16:26 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:26 --> Input Class Initialized
INFO - 2023-09-23 06:16:26 --> Language Class Initialized
INFO - 2023-09-23 06:16:26 --> Loader Class Initialized
INFO - 2023-09-23 06:16:26 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:26 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:26 --> Parser Class Initialized
INFO - 2023-09-23 06:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:26 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:26 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:26 --> Controller Class Initialized
INFO - 2023-09-23 06:16:26 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:26 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:26 --> Model Class Initialized
INFO - 2023-09-23 06:16:26 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:26 --> Total execution time: 0.0261
ERROR - 2023-09-23 06:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:26 --> Config Class Initialized
INFO - 2023-09-23 06:16:26 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:26 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:26 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:26 --> URI Class Initialized
INFO - 2023-09-23 06:16:26 --> Router Class Initialized
INFO - 2023-09-23 06:16:26 --> Output Class Initialized
INFO - 2023-09-23 06:16:26 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:26 --> Input Class Initialized
INFO - 2023-09-23 06:16:26 --> Language Class Initialized
INFO - 2023-09-23 06:16:26 --> Loader Class Initialized
INFO - 2023-09-23 06:16:26 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:26 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:26 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:26 --> Parser Class Initialized
INFO - 2023-09-23 06:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:26 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:26 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:26 --> Controller Class Initialized
INFO - 2023-09-23 06:16:26 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:26 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:26 --> Model Class Initialized
INFO - 2023-09-23 06:16:26 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:26 --> Total execution time: 0.0233
ERROR - 2023-09-23 06:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:27 --> Config Class Initialized
INFO - 2023-09-23 06:16:27 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:27 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:27 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:27 --> URI Class Initialized
INFO - 2023-09-23 06:16:27 --> Router Class Initialized
INFO - 2023-09-23 06:16:27 --> Output Class Initialized
INFO - 2023-09-23 06:16:27 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:27 --> Input Class Initialized
INFO - 2023-09-23 06:16:27 --> Language Class Initialized
INFO - 2023-09-23 06:16:27 --> Loader Class Initialized
INFO - 2023-09-23 06:16:27 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:27 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:27 --> Parser Class Initialized
INFO - 2023-09-23 06:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:27 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:27 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:27 --> Controller Class Initialized
INFO - 2023-09-23 06:16:27 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:27 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:27 --> Model Class Initialized
INFO - 2023-09-23 06:16:27 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:27 --> Total execution time: 0.0219
ERROR - 2023-09-23 06:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:27 --> Config Class Initialized
INFO - 2023-09-23 06:16:27 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:27 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:27 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:27 --> URI Class Initialized
INFO - 2023-09-23 06:16:27 --> Router Class Initialized
INFO - 2023-09-23 06:16:27 --> Output Class Initialized
INFO - 2023-09-23 06:16:27 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:27 --> Input Class Initialized
INFO - 2023-09-23 06:16:27 --> Language Class Initialized
INFO - 2023-09-23 06:16:27 --> Loader Class Initialized
INFO - 2023-09-23 06:16:27 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:27 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:27 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:27 --> Parser Class Initialized
INFO - 2023-09-23 06:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:27 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:27 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:27 --> Controller Class Initialized
INFO - 2023-09-23 06:16:27 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:27 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:27 --> Model Class Initialized
INFO - 2023-09-23 06:16:27 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:27 --> Total execution time: 0.0407
ERROR - 2023-09-23 06:16:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:37 --> Config Class Initialized
INFO - 2023-09-23 06:16:37 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:37 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:37 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:37 --> URI Class Initialized
INFO - 2023-09-23 06:16:37 --> Router Class Initialized
INFO - 2023-09-23 06:16:37 --> Output Class Initialized
INFO - 2023-09-23 06:16:37 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:37 --> Input Class Initialized
INFO - 2023-09-23 06:16:37 --> Language Class Initialized
INFO - 2023-09-23 06:16:37 --> Loader Class Initialized
INFO - 2023-09-23 06:16:37 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:37 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:37 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:37 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:37 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:37 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:37 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:37 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:37 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:37 --> Parser Class Initialized
INFO - 2023-09-23 06:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:37 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:37 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:37 --> Controller Class Initialized
INFO - 2023-09-23 06:16:37 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:37 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:37 --> Model Class Initialized
INFO - 2023-09-23 06:16:37 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:37 --> Total execution time: 0.0567
ERROR - 2023-09-23 06:16:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:49 --> Config Class Initialized
INFO - 2023-09-23 06:16:49 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:49 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:49 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:49 --> URI Class Initialized
INFO - 2023-09-23 06:16:49 --> Router Class Initialized
INFO - 2023-09-23 06:16:49 --> Output Class Initialized
INFO - 2023-09-23 06:16:49 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:49 --> Input Class Initialized
INFO - 2023-09-23 06:16:49 --> Language Class Initialized
INFO - 2023-09-23 06:16:49 --> Loader Class Initialized
INFO - 2023-09-23 06:16:49 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:49 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:49 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:49 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:49 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:49 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:49 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:49 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:49 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:49 --> Parser Class Initialized
INFO - 2023-09-23 06:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:49 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:49 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:49 --> Controller Class Initialized
INFO - 2023-09-23 06:16:49 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:49 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:49 --> Model Class Initialized
INFO - 2023-09-23 06:16:49 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:49 --> Total execution time: 0.0237
ERROR - 2023-09-23 06:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:50 --> Config Class Initialized
INFO - 2023-09-23 06:16:50 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:50 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:50 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:50 --> URI Class Initialized
INFO - 2023-09-23 06:16:50 --> Router Class Initialized
INFO - 2023-09-23 06:16:50 --> Output Class Initialized
INFO - 2023-09-23 06:16:50 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:50 --> Input Class Initialized
INFO - 2023-09-23 06:16:50 --> Language Class Initialized
INFO - 2023-09-23 06:16:50 --> Loader Class Initialized
INFO - 2023-09-23 06:16:50 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:50 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:50 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:50 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:50 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:50 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:50 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:50 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:50 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:50 --> Parser Class Initialized
INFO - 2023-09-23 06:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:50 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:50 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:50 --> Controller Class Initialized
INFO - 2023-09-23 06:16:50 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:50 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:50 --> Model Class Initialized
INFO - 2023-09-23 06:16:50 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:50 --> Total execution time: 0.0201
ERROR - 2023-09-23 06:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:52 --> Config Class Initialized
INFO - 2023-09-23 06:16:52 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:52 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:52 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:52 --> URI Class Initialized
INFO - 2023-09-23 06:16:52 --> Router Class Initialized
INFO - 2023-09-23 06:16:52 --> Output Class Initialized
INFO - 2023-09-23 06:16:52 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:52 --> Input Class Initialized
INFO - 2023-09-23 06:16:52 --> Language Class Initialized
INFO - 2023-09-23 06:16:52 --> Loader Class Initialized
INFO - 2023-09-23 06:16:52 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:52 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:52 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:52 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:52 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:52 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:52 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:52 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:52 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:52 --> Parser Class Initialized
INFO - 2023-09-23 06:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:52 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:52 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:52 --> Controller Class Initialized
INFO - 2023-09-23 06:16:52 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:52 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:52 --> Model Class Initialized
INFO - 2023-09-23 06:16:52 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:52 --> Total execution time: 0.0203
ERROR - 2023-09-23 06:16:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:53 --> Config Class Initialized
INFO - 2023-09-23 06:16:53 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:53 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:53 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:53 --> URI Class Initialized
INFO - 2023-09-23 06:16:53 --> Router Class Initialized
INFO - 2023-09-23 06:16:53 --> Output Class Initialized
INFO - 2023-09-23 06:16:53 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:53 --> Input Class Initialized
INFO - 2023-09-23 06:16:53 --> Language Class Initialized
INFO - 2023-09-23 06:16:53 --> Loader Class Initialized
INFO - 2023-09-23 06:16:53 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:53 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:53 --> Parser Class Initialized
INFO - 2023-09-23 06:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:53 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:53 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:53 --> Controller Class Initialized
INFO - 2023-09-23 06:16:53 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:53 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:53 --> Model Class Initialized
INFO - 2023-09-23 06:16:53 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:53 --> Total execution time: 0.0201
ERROR - 2023-09-23 06:16:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:53 --> Config Class Initialized
INFO - 2023-09-23 06:16:53 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:53 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:53 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:53 --> URI Class Initialized
INFO - 2023-09-23 06:16:53 --> Router Class Initialized
INFO - 2023-09-23 06:16:53 --> Output Class Initialized
INFO - 2023-09-23 06:16:53 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:53 --> Input Class Initialized
INFO - 2023-09-23 06:16:53 --> Language Class Initialized
INFO - 2023-09-23 06:16:53 --> Loader Class Initialized
INFO - 2023-09-23 06:16:53 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:53 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:53 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:53 --> Parser Class Initialized
INFO - 2023-09-23 06:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:53 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:53 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:53 --> Controller Class Initialized
INFO - 2023-09-23 06:16:53 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:53 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:53 --> Model Class Initialized
INFO - 2023-09-23 06:16:53 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:53 --> Total execution time: 0.0199
ERROR - 2023-09-23 06:16:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:16:54 --> Config Class Initialized
INFO - 2023-09-23 06:16:54 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:16:54 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:16:54 --> Utf8 Class Initialized
INFO - 2023-09-23 06:16:54 --> URI Class Initialized
INFO - 2023-09-23 06:16:54 --> Router Class Initialized
INFO - 2023-09-23 06:16:54 --> Output Class Initialized
INFO - 2023-09-23 06:16:54 --> Security Class Initialized
DEBUG - 2023-09-23 06:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:16:54 --> Input Class Initialized
INFO - 2023-09-23 06:16:54 --> Language Class Initialized
INFO - 2023-09-23 06:16:54 --> Loader Class Initialized
INFO - 2023-09-23 06:16:54 --> Helper loaded: url_helper
INFO - 2023-09-23 06:16:54 --> Helper loaded: file_helper
INFO - 2023-09-23 06:16:54 --> Helper loaded: html_helper
INFO - 2023-09-23 06:16:54 --> Helper loaded: text_helper
INFO - 2023-09-23 06:16:54 --> Helper loaded: form_helper
INFO - 2023-09-23 06:16:54 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:16:54 --> Helper loaded: security_helper
INFO - 2023-09-23 06:16:54 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:16:54 --> Database Driver Class Initialized
INFO - 2023-09-23 06:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:16:54 --> Parser Class Initialized
INFO - 2023-09-23 06:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:16:54 --> Pagination Class Initialized
INFO - 2023-09-23 06:16:54 --> Form Validation Class Initialized
INFO - 2023-09-23 06:16:54 --> Controller Class Initialized
INFO - 2023-09-23 06:16:54 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:54 --> Model Class Initialized
DEBUG - 2023-09-23 06:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:16:54 --> Model Class Initialized
INFO - 2023-09-23 06:16:54 --> Final output sent to browser
DEBUG - 2023-09-23 06:16:54 --> Total execution time: 0.0501
ERROR - 2023-09-23 06:17:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:05 --> Config Class Initialized
INFO - 2023-09-23 06:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:05 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:05 --> URI Class Initialized
INFO - 2023-09-23 06:17:05 --> Router Class Initialized
INFO - 2023-09-23 06:17:05 --> Output Class Initialized
INFO - 2023-09-23 06:17:05 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:05 --> Input Class Initialized
INFO - 2023-09-23 06:17:05 --> Language Class Initialized
INFO - 2023-09-23 06:17:05 --> Loader Class Initialized
INFO - 2023-09-23 06:17:05 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:05 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:05 --> Parser Class Initialized
INFO - 2023-09-23 06:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:05 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:05 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:05 --> Controller Class Initialized
INFO - 2023-09-23 06:17:05 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:05 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:05 --> Model Class Initialized
INFO - 2023-09-23 06:17:05 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:05 --> Total execution time: 0.0210
ERROR - 2023-09-23 06:17:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:05 --> Config Class Initialized
INFO - 2023-09-23 06:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:05 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:05 --> URI Class Initialized
INFO - 2023-09-23 06:17:05 --> Router Class Initialized
INFO - 2023-09-23 06:17:05 --> Output Class Initialized
INFO - 2023-09-23 06:17:05 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:05 --> Input Class Initialized
INFO - 2023-09-23 06:17:05 --> Language Class Initialized
INFO - 2023-09-23 06:17:05 --> Loader Class Initialized
INFO - 2023-09-23 06:17:05 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:05 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:05 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:05 --> Parser Class Initialized
INFO - 2023-09-23 06:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:05 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:05 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:05 --> Controller Class Initialized
INFO - 2023-09-23 06:17:05 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:05 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:05 --> Model Class Initialized
INFO - 2023-09-23 06:17:05 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:05 --> Total execution time: 0.0198
ERROR - 2023-09-23 06:17:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:06 --> Config Class Initialized
INFO - 2023-09-23 06:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:06 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:06 --> URI Class Initialized
INFO - 2023-09-23 06:17:06 --> Router Class Initialized
INFO - 2023-09-23 06:17:06 --> Output Class Initialized
INFO - 2023-09-23 06:17:06 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:06 --> Input Class Initialized
INFO - 2023-09-23 06:17:06 --> Language Class Initialized
INFO - 2023-09-23 06:17:06 --> Loader Class Initialized
INFO - 2023-09-23 06:17:06 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:06 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:06 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:06 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:06 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:06 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:06 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:06 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:06 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:06 --> Parser Class Initialized
INFO - 2023-09-23 06:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:06 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:06 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:06 --> Controller Class Initialized
INFO - 2023-09-23 06:17:06 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:06 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:06 --> Model Class Initialized
INFO - 2023-09-23 06:17:06 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:06 --> Total execution time: 0.0200
ERROR - 2023-09-23 06:17:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:09 --> Config Class Initialized
INFO - 2023-09-23 06:17:09 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:09 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:09 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:09 --> URI Class Initialized
INFO - 2023-09-23 06:17:09 --> Router Class Initialized
INFO - 2023-09-23 06:17:09 --> Output Class Initialized
INFO - 2023-09-23 06:17:09 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:09 --> Input Class Initialized
INFO - 2023-09-23 06:17:09 --> Language Class Initialized
INFO - 2023-09-23 06:17:09 --> Loader Class Initialized
INFO - 2023-09-23 06:17:09 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:09 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:09 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:09 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:09 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:09 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:09 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:09 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:09 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:09 --> Parser Class Initialized
INFO - 2023-09-23 06:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:09 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:09 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:09 --> Controller Class Initialized
INFO - 2023-09-23 06:17:09 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:09 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:09 --> Model Class Initialized
INFO - 2023-09-23 06:17:09 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:09 --> Total execution time: 0.0207
ERROR - 2023-09-23 06:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:10 --> Config Class Initialized
INFO - 2023-09-23 06:17:10 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:10 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:10 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:10 --> URI Class Initialized
INFO - 2023-09-23 06:17:10 --> Router Class Initialized
INFO - 2023-09-23 06:17:10 --> Output Class Initialized
INFO - 2023-09-23 06:17:10 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:10 --> Input Class Initialized
INFO - 2023-09-23 06:17:10 --> Language Class Initialized
INFO - 2023-09-23 06:17:10 --> Loader Class Initialized
INFO - 2023-09-23 06:17:10 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:10 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:10 --> Parser Class Initialized
INFO - 2023-09-23 06:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:10 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:10 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:10 --> Controller Class Initialized
INFO - 2023-09-23 06:17:10 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:10 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:10 --> Model Class Initialized
INFO - 2023-09-23 06:17:10 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:10 --> Total execution time: 0.0323
ERROR - 2023-09-23 06:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:10 --> Config Class Initialized
INFO - 2023-09-23 06:17:10 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:10 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:10 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:10 --> URI Class Initialized
INFO - 2023-09-23 06:17:10 --> Router Class Initialized
INFO - 2023-09-23 06:17:10 --> Output Class Initialized
INFO - 2023-09-23 06:17:10 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:10 --> Input Class Initialized
INFO - 2023-09-23 06:17:10 --> Language Class Initialized
INFO - 2023-09-23 06:17:10 --> Loader Class Initialized
INFO - 2023-09-23 06:17:10 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:10 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:10 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:10 --> Parser Class Initialized
INFO - 2023-09-23 06:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:10 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:10 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:10 --> Controller Class Initialized
INFO - 2023-09-23 06:17:10 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:10 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:10 --> Model Class Initialized
INFO - 2023-09-23 06:17:10 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:10 --> Total execution time: 0.0235
ERROR - 2023-09-23 06:17:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:11 --> Config Class Initialized
INFO - 2023-09-23 06:17:11 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:11 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:11 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:11 --> URI Class Initialized
INFO - 2023-09-23 06:17:11 --> Router Class Initialized
INFO - 2023-09-23 06:17:11 --> Output Class Initialized
INFO - 2023-09-23 06:17:11 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:11 --> Input Class Initialized
INFO - 2023-09-23 06:17:11 --> Language Class Initialized
INFO - 2023-09-23 06:17:11 --> Loader Class Initialized
INFO - 2023-09-23 06:17:11 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:11 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:11 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:11 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:11 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:11 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:11 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:11 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:11 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:11 --> Parser Class Initialized
INFO - 2023-09-23 06:17:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:11 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:11 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:11 --> Controller Class Initialized
INFO - 2023-09-23 06:17:11 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:11 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:11 --> Model Class Initialized
INFO - 2023-09-23 06:17:11 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:11 --> Total execution time: 0.0703
ERROR - 2023-09-23 06:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:18 --> Config Class Initialized
INFO - 2023-09-23 06:17:18 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:18 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:18 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:18 --> URI Class Initialized
INFO - 2023-09-23 06:17:18 --> Router Class Initialized
INFO - 2023-09-23 06:17:18 --> Output Class Initialized
INFO - 2023-09-23 06:17:18 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:18 --> Input Class Initialized
INFO - 2023-09-23 06:17:18 --> Language Class Initialized
INFO - 2023-09-23 06:17:18 --> Loader Class Initialized
INFO - 2023-09-23 06:17:18 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:18 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:18 --> Parser Class Initialized
INFO - 2023-09-23 06:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:18 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:18 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:18 --> Controller Class Initialized
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
INFO - 2023-09-23 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-23 06:17:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
INFO - 2023-09-23 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:17:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:17:18 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:18 --> Total execution time: 0.0815
ERROR - 2023-09-23 06:17:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:17:18 --> Config Class Initialized
INFO - 2023-09-23 06:17:18 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:17:18 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:17:18 --> Utf8 Class Initialized
INFO - 2023-09-23 06:17:18 --> URI Class Initialized
INFO - 2023-09-23 06:17:18 --> Router Class Initialized
INFO - 2023-09-23 06:17:18 --> Output Class Initialized
INFO - 2023-09-23 06:17:18 --> Security Class Initialized
DEBUG - 2023-09-23 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:17:18 --> Input Class Initialized
INFO - 2023-09-23 06:17:18 --> Language Class Initialized
INFO - 2023-09-23 06:17:18 --> Loader Class Initialized
INFO - 2023-09-23 06:17:18 --> Helper loaded: url_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: file_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: html_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: text_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: form_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: security_helper
INFO - 2023-09-23 06:17:18 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:17:18 --> Database Driver Class Initialized
INFO - 2023-09-23 06:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:17:18 --> Parser Class Initialized
INFO - 2023-09-23 06:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:17:18 --> Pagination Class Initialized
INFO - 2023-09-23 06:17:18 --> Form Validation Class Initialized
INFO - 2023-09-23 06:17:18 --> Controller Class Initialized
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
DEBUG - 2023-09-23 06:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:17:18 --> Model Class Initialized
INFO - 2023-09-23 06:17:18 --> Final output sent to browser
DEBUG - 2023-09-23 06:17:18 --> Total execution time: 0.0259
ERROR - 2023-09-23 06:22:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:16 --> Config Class Initialized
INFO - 2023-09-23 06:22:16 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:16 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:16 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:16 --> URI Class Initialized
DEBUG - 2023-09-23 06:22:16 --> No URI present. Default controller set.
INFO - 2023-09-23 06:22:16 --> Router Class Initialized
INFO - 2023-09-23 06:22:16 --> Output Class Initialized
INFO - 2023-09-23 06:22:16 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:16 --> Input Class Initialized
INFO - 2023-09-23 06:22:16 --> Language Class Initialized
INFO - 2023-09-23 06:22:16 --> Loader Class Initialized
INFO - 2023-09-23 06:22:16 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:16 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:16 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:16 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:16 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:16 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:16 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:16 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:16 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:16 --> Parser Class Initialized
INFO - 2023-09-23 06:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:16 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:16 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:16 --> Controller Class Initialized
INFO - 2023-09-23 06:22:16 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 06:22:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:17 --> Config Class Initialized
INFO - 2023-09-23 06:22:17 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:17 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:17 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:17 --> URI Class Initialized
INFO - 2023-09-23 06:22:17 --> Router Class Initialized
INFO - 2023-09-23 06:22:17 --> Output Class Initialized
INFO - 2023-09-23 06:22:17 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:17 --> Input Class Initialized
INFO - 2023-09-23 06:22:17 --> Language Class Initialized
INFO - 2023-09-23 06:22:17 --> Loader Class Initialized
INFO - 2023-09-23 06:22:17 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:17 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:17 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:17 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:17 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:17 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:17 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:17 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:17 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:17 --> Parser Class Initialized
INFO - 2023-09-23 06:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:17 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:17 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:17 --> Controller Class Initialized
INFO - 2023-09-23 06:22:17 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-23 06:22:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:22:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:22:17 --> Model Class Initialized
INFO - 2023-09-23 06:22:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:22:17 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:17 --> Total execution time: 0.0344
ERROR - 2023-09-23 06:22:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:19 --> Config Class Initialized
INFO - 2023-09-23 06:22:19 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:19 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:19 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:19 --> URI Class Initialized
INFO - 2023-09-23 06:22:19 --> Router Class Initialized
INFO - 2023-09-23 06:22:19 --> Output Class Initialized
INFO - 2023-09-23 06:22:19 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:19 --> Input Class Initialized
INFO - 2023-09-23 06:22:19 --> Language Class Initialized
INFO - 2023-09-23 06:22:19 --> Loader Class Initialized
INFO - 2023-09-23 06:22:19 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:19 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:19 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:19 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:19 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:19 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:19 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:19 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:19 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:19 --> Parser Class Initialized
INFO - 2023-09-23 06:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:19 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:19 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:19 --> Controller Class Initialized
INFO - 2023-09-23 06:22:19 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:19 --> Model Class Initialized
INFO - 2023-09-23 06:22:19 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:19 --> Total execution time: 0.0188
ERROR - 2023-09-23 06:22:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:20 --> Config Class Initialized
INFO - 2023-09-23 06:22:20 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:20 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:20 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:20 --> URI Class Initialized
DEBUG - 2023-09-23 06:22:20 --> No URI present. Default controller set.
INFO - 2023-09-23 06:22:20 --> Router Class Initialized
INFO - 2023-09-23 06:22:20 --> Output Class Initialized
INFO - 2023-09-23 06:22:20 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:20 --> Input Class Initialized
INFO - 2023-09-23 06:22:20 --> Language Class Initialized
INFO - 2023-09-23 06:22:20 --> Loader Class Initialized
INFO - 2023-09-23 06:22:20 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:20 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:20 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:20 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:20 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:20 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:20 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:20 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:20 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:20 --> Parser Class Initialized
INFO - 2023-09-23 06:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:20 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:20 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:20 --> Controller Class Initialized
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
INFO - 2023-09-23 06:22:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-23 06:22:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:22:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:22:20 --> Model Class Initialized
INFO - 2023-09-23 06:22:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:22:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:22:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:22:20 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:20 --> Total execution time: 0.2170
ERROR - 2023-09-23 06:22:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:21 --> Config Class Initialized
INFO - 2023-09-23 06:22:21 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:21 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:21 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:21 --> URI Class Initialized
INFO - 2023-09-23 06:22:21 --> Router Class Initialized
INFO - 2023-09-23 06:22:21 --> Output Class Initialized
INFO - 2023-09-23 06:22:21 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:21 --> Input Class Initialized
INFO - 2023-09-23 06:22:21 --> Language Class Initialized
INFO - 2023-09-23 06:22:21 --> Loader Class Initialized
INFO - 2023-09-23 06:22:21 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:21 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:21 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:21 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:21 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:21 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:21 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:21 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:21 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:21 --> Parser Class Initialized
INFO - 2023-09-23 06:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:21 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:21 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:21 --> Controller Class Initialized
DEBUG - 2023-09-23 06:22:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:21 --> Model Class Initialized
INFO - 2023-09-23 06:22:21 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:21 --> Total execution time: 0.0136
ERROR - 2023-09-23 06:22:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:28 --> Config Class Initialized
INFO - 2023-09-23 06:22:28 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:28 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:28 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:28 --> URI Class Initialized
INFO - 2023-09-23 06:22:28 --> Router Class Initialized
INFO - 2023-09-23 06:22:28 --> Output Class Initialized
INFO - 2023-09-23 06:22:28 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:28 --> Input Class Initialized
INFO - 2023-09-23 06:22:28 --> Language Class Initialized
INFO - 2023-09-23 06:22:28 --> Loader Class Initialized
INFO - 2023-09-23 06:22:28 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:28 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:28 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:28 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:28 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:28 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:28 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:28 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:28 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:28 --> Parser Class Initialized
INFO - 2023-09-23 06:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:28 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:28 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:28 --> Controller Class Initialized
INFO - 2023-09-23 06:22:28 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:28 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:28 --> Model Class Initialized
INFO - 2023-09-23 06:22:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-23 06:22:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:22:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:22:28 --> Model Class Initialized
INFO - 2023-09-23 06:22:28 --> Model Class Initialized
INFO - 2023-09-23 06:22:28 --> Model Class Initialized
INFO - 2023-09-23 06:22:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:22:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:22:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:22:28 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:28 --> Total execution time: 0.1579
ERROR - 2023-09-23 06:22:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:29 --> Config Class Initialized
INFO - 2023-09-23 06:22:29 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:29 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:29 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:29 --> URI Class Initialized
INFO - 2023-09-23 06:22:29 --> Router Class Initialized
INFO - 2023-09-23 06:22:29 --> Output Class Initialized
INFO - 2023-09-23 06:22:29 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:29 --> Input Class Initialized
INFO - 2023-09-23 06:22:29 --> Language Class Initialized
INFO - 2023-09-23 06:22:29 --> Loader Class Initialized
INFO - 2023-09-23 06:22:29 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:29 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:29 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:29 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:29 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:29 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:29 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:29 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:29 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:29 --> Parser Class Initialized
INFO - 2023-09-23 06:22:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:29 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:29 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:29 --> Controller Class Initialized
INFO - 2023-09-23 06:22:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:29 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:29 --> Model Class Initialized
INFO - 2023-09-23 06:22:29 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:29 --> Total execution time: 0.0551
ERROR - 2023-09-23 06:22:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:33 --> Config Class Initialized
INFO - 2023-09-23 06:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:33 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:33 --> URI Class Initialized
INFO - 2023-09-23 06:22:33 --> Router Class Initialized
INFO - 2023-09-23 06:22:33 --> Output Class Initialized
INFO - 2023-09-23 06:22:33 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:33 --> Input Class Initialized
INFO - 2023-09-23 06:22:33 --> Language Class Initialized
INFO - 2023-09-23 06:22:33 --> Loader Class Initialized
INFO - 2023-09-23 06:22:33 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:33 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:33 --> Parser Class Initialized
INFO - 2023-09-23 06:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:33 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:33 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:33 --> Controller Class Initialized
INFO - 2023-09-23 06:22:33 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:33 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:33 --> Model Class Initialized
INFO - 2023-09-23 06:22:33 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:33 --> Total execution time: 0.0497
ERROR - 2023-09-23 06:22:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:33 --> Config Class Initialized
INFO - 2023-09-23 06:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:33 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:33 --> URI Class Initialized
INFO - 2023-09-23 06:22:33 --> Router Class Initialized
INFO - 2023-09-23 06:22:33 --> Output Class Initialized
INFO - 2023-09-23 06:22:33 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:33 --> Input Class Initialized
INFO - 2023-09-23 06:22:33 --> Language Class Initialized
INFO - 2023-09-23 06:22:33 --> Loader Class Initialized
INFO - 2023-09-23 06:22:33 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:33 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:34 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:34 --> Parser Class Initialized
INFO - 2023-09-23 06:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:34 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:34 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:34 --> Controller Class Initialized
INFO - 2023-09-23 06:22:34 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:34 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:34 --> Model Class Initialized
INFO - 2023-09-23 06:22:34 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:34 --> Total execution time: 0.0301
ERROR - 2023-09-23 06:22:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:34 --> Config Class Initialized
INFO - 2023-09-23 06:22:34 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:34 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:34 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:34 --> URI Class Initialized
INFO - 2023-09-23 06:22:34 --> Router Class Initialized
INFO - 2023-09-23 06:22:34 --> Output Class Initialized
INFO - 2023-09-23 06:22:34 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:34 --> Input Class Initialized
INFO - 2023-09-23 06:22:34 --> Language Class Initialized
INFO - 2023-09-23 06:22:34 --> Loader Class Initialized
INFO - 2023-09-23 06:22:34 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:34 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:34 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:34 --> Parser Class Initialized
INFO - 2023-09-23 06:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:34 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:34 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:34 --> Controller Class Initialized
INFO - 2023-09-23 06:22:34 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:34 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:34 --> Model Class Initialized
INFO - 2023-09-23 06:22:34 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:34 --> Total execution time: 0.0268
ERROR - 2023-09-23 06:22:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:35 --> Config Class Initialized
INFO - 2023-09-23 06:22:35 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:35 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:35 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:35 --> URI Class Initialized
INFO - 2023-09-23 06:22:35 --> Router Class Initialized
INFO - 2023-09-23 06:22:35 --> Output Class Initialized
INFO - 2023-09-23 06:22:35 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:35 --> Input Class Initialized
INFO - 2023-09-23 06:22:35 --> Language Class Initialized
INFO - 2023-09-23 06:22:35 --> Loader Class Initialized
INFO - 2023-09-23 06:22:35 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:35 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:35 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:35 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:35 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:35 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:35 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:35 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:35 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:35 --> Parser Class Initialized
INFO - 2023-09-23 06:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:35 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:35 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:35 --> Controller Class Initialized
INFO - 2023-09-23 06:22:35 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:35 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:35 --> Model Class Initialized
INFO - 2023-09-23 06:22:35 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:35 --> Total execution time: 0.0270
ERROR - 2023-09-23 06:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:39 --> Config Class Initialized
INFO - 2023-09-23 06:22:39 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:39 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:39 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:39 --> URI Class Initialized
INFO - 2023-09-23 06:22:39 --> Router Class Initialized
INFO - 2023-09-23 06:22:39 --> Output Class Initialized
INFO - 2023-09-23 06:22:39 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:39 --> Input Class Initialized
INFO - 2023-09-23 06:22:39 --> Language Class Initialized
INFO - 2023-09-23 06:22:39 --> Loader Class Initialized
INFO - 2023-09-23 06:22:39 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:39 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:39 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:39 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:39 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:39 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:39 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:39 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:39 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:39 --> Parser Class Initialized
INFO - 2023-09-23 06:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:39 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:39 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:39 --> Controller Class Initialized
INFO - 2023-09-23 06:22:39 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:39 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:39 --> Model Class Initialized
INFO - 2023-09-23 06:22:39 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:39 --> Total execution time: 0.0261
ERROR - 2023-09-23 06:22:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:40 --> Config Class Initialized
INFO - 2023-09-23 06:22:40 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:40 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:40 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:40 --> URI Class Initialized
INFO - 2023-09-23 06:22:40 --> Router Class Initialized
INFO - 2023-09-23 06:22:40 --> Output Class Initialized
INFO - 2023-09-23 06:22:40 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:40 --> Input Class Initialized
INFO - 2023-09-23 06:22:40 --> Language Class Initialized
INFO - 2023-09-23 06:22:40 --> Loader Class Initialized
INFO - 2023-09-23 06:22:40 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:40 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:40 --> Parser Class Initialized
INFO - 2023-09-23 06:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:40 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:40 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:40 --> Controller Class Initialized
INFO - 2023-09-23 06:22:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:40 --> Model Class Initialized
INFO - 2023-09-23 06:22:40 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:40 --> Total execution time: 0.0304
ERROR - 2023-09-23 06:22:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:40 --> Config Class Initialized
INFO - 2023-09-23 06:22:40 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:40 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:40 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:40 --> URI Class Initialized
INFO - 2023-09-23 06:22:40 --> Router Class Initialized
INFO - 2023-09-23 06:22:40 --> Output Class Initialized
INFO - 2023-09-23 06:22:40 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:40 --> Input Class Initialized
INFO - 2023-09-23 06:22:40 --> Language Class Initialized
INFO - 2023-09-23 06:22:40 --> Loader Class Initialized
INFO - 2023-09-23 06:22:40 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:40 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:40 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:40 --> Parser Class Initialized
INFO - 2023-09-23 06:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:40 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:40 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:40 --> Controller Class Initialized
INFO - 2023-09-23 06:22:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:40 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:40 --> Model Class Initialized
INFO - 2023-09-23 06:22:40 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:40 --> Total execution time: 0.0604
ERROR - 2023-09-23 06:22:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:41 --> Config Class Initialized
INFO - 2023-09-23 06:22:41 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:41 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:41 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:41 --> URI Class Initialized
INFO - 2023-09-23 06:22:41 --> Router Class Initialized
INFO - 2023-09-23 06:22:41 --> Output Class Initialized
INFO - 2023-09-23 06:22:41 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:41 --> Input Class Initialized
INFO - 2023-09-23 06:22:41 --> Language Class Initialized
INFO - 2023-09-23 06:22:41 --> Loader Class Initialized
INFO - 2023-09-23 06:22:41 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:41 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:41 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:41 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:41 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:41 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:41 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:41 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:41 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:41 --> Parser Class Initialized
INFO - 2023-09-23 06:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:41 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:41 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:41 --> Controller Class Initialized
INFO - 2023-09-23 06:22:41 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:41 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:41 --> Model Class Initialized
INFO - 2023-09-23 06:22:41 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:41 --> Total execution time: 0.0534
ERROR - 2023-09-23 06:22:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 06:22:55 --> Config Class Initialized
INFO - 2023-09-23 06:22:55 --> Hooks Class Initialized
DEBUG - 2023-09-23 06:22:55 --> UTF-8 Support Enabled
INFO - 2023-09-23 06:22:55 --> Utf8 Class Initialized
INFO - 2023-09-23 06:22:55 --> URI Class Initialized
DEBUG - 2023-09-23 06:22:55 --> No URI present. Default controller set.
INFO - 2023-09-23 06:22:55 --> Router Class Initialized
INFO - 2023-09-23 06:22:55 --> Output Class Initialized
INFO - 2023-09-23 06:22:55 --> Security Class Initialized
DEBUG - 2023-09-23 06:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 06:22:55 --> Input Class Initialized
INFO - 2023-09-23 06:22:55 --> Language Class Initialized
INFO - 2023-09-23 06:22:55 --> Loader Class Initialized
INFO - 2023-09-23 06:22:55 --> Helper loaded: url_helper
INFO - 2023-09-23 06:22:55 --> Helper loaded: file_helper
INFO - 2023-09-23 06:22:55 --> Helper loaded: html_helper
INFO - 2023-09-23 06:22:55 --> Helper loaded: text_helper
INFO - 2023-09-23 06:22:55 --> Helper loaded: form_helper
INFO - 2023-09-23 06:22:55 --> Helper loaded: lang_helper
INFO - 2023-09-23 06:22:55 --> Helper loaded: security_helper
INFO - 2023-09-23 06:22:55 --> Helper loaded: cookie_helper
INFO - 2023-09-23 06:22:55 --> Database Driver Class Initialized
INFO - 2023-09-23 06:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 06:22:55 --> Parser Class Initialized
INFO - 2023-09-23 06:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 06:22:55 --> Pagination Class Initialized
INFO - 2023-09-23 06:22:55 --> Form Validation Class Initialized
INFO - 2023-09-23 06:22:55 --> Controller Class Initialized
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
DEBUG - 2023-09-23 06:22:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 06:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
INFO - 2023-09-23 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-23 06:22:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 06:22:55 --> Model Class Initialized
INFO - 2023-09-23 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 06:22:55 --> Final output sent to browser
DEBUG - 2023-09-23 06:22:55 --> Total execution time: 0.2041
ERROR - 2023-09-23 07:33:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 07:33:16 --> Config Class Initialized
INFO - 2023-09-23 07:33:16 --> Hooks Class Initialized
DEBUG - 2023-09-23 07:33:16 --> UTF-8 Support Enabled
INFO - 2023-09-23 07:33:16 --> Utf8 Class Initialized
INFO - 2023-09-23 07:33:16 --> URI Class Initialized
DEBUG - 2023-09-23 07:33:16 --> No URI present. Default controller set.
INFO - 2023-09-23 07:33:16 --> Router Class Initialized
INFO - 2023-09-23 07:33:16 --> Output Class Initialized
INFO - 2023-09-23 07:33:16 --> Security Class Initialized
DEBUG - 2023-09-23 07:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 07:33:16 --> Input Class Initialized
INFO - 2023-09-23 07:33:16 --> Language Class Initialized
INFO - 2023-09-23 07:33:16 --> Loader Class Initialized
INFO - 2023-09-23 07:33:16 --> Helper loaded: url_helper
INFO - 2023-09-23 07:33:16 --> Helper loaded: file_helper
INFO - 2023-09-23 07:33:16 --> Helper loaded: html_helper
INFO - 2023-09-23 07:33:16 --> Helper loaded: text_helper
INFO - 2023-09-23 07:33:16 --> Helper loaded: form_helper
INFO - 2023-09-23 07:33:16 --> Helper loaded: lang_helper
INFO - 2023-09-23 07:33:16 --> Helper loaded: security_helper
INFO - 2023-09-23 07:33:16 --> Helper loaded: cookie_helper
INFO - 2023-09-23 07:33:16 --> Database Driver Class Initialized
INFO - 2023-09-23 07:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 07:33:16 --> Parser Class Initialized
INFO - 2023-09-23 07:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 07:33:16 --> Pagination Class Initialized
INFO - 2023-09-23 07:33:16 --> Form Validation Class Initialized
INFO - 2023-09-23 07:33:16 --> Controller Class Initialized
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
DEBUG - 2023-09-23 07:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
DEBUG - 2023-09-23 07:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
DEBUG - 2023-09-23 07:33:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 07:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
INFO - 2023-09-23 07:33:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-23 07:33:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 07:33:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 07:33:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 07:33:16 --> Model Class Initialized
INFO - 2023-09-23 07:33:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 07:33:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 07:33:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 07:33:16 --> Final output sent to browser
DEBUG - 2023-09-23 07:33:16 --> Total execution time: 0.1079
ERROR - 2023-09-23 10:59:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:25 --> Config Class Initialized
INFO - 2023-09-23 10:59:25 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:25 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:25 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:25 --> URI Class Initialized
INFO - 2023-09-23 10:59:25 --> Router Class Initialized
INFO - 2023-09-23 10:59:25 --> Output Class Initialized
INFO - 2023-09-23 10:59:25 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:25 --> Input Class Initialized
INFO - 2023-09-23 10:59:25 --> Language Class Initialized
INFO - 2023-09-23 10:59:25 --> Loader Class Initialized
INFO - 2023-09-23 10:59:25 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:25 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:25 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:25 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:25 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:25 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:25 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:25 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:25 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:25 --> Parser Class Initialized
INFO - 2023-09-23 10:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:25 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:25 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:25 --> Controller Class Initialized
ERROR - 2023-09-23 10:59:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:26 --> Config Class Initialized
INFO - 2023-09-23 10:59:26 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:26 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:26 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:26 --> URI Class Initialized
INFO - 2023-09-23 10:59:26 --> Router Class Initialized
INFO - 2023-09-23 10:59:26 --> Output Class Initialized
INFO - 2023-09-23 10:59:26 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:26 --> Input Class Initialized
INFO - 2023-09-23 10:59:26 --> Language Class Initialized
INFO - 2023-09-23 10:59:26 --> Loader Class Initialized
INFO - 2023-09-23 10:59:26 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:26 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:26 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:26 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:26 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:26 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:26 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:26 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:26 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:26 --> Parser Class Initialized
INFO - 2023-09-23 10:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:26 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:26 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:26 --> Controller Class Initialized
INFO - 2023-09-23 10:59:26 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-23 10:59:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 10:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 10:59:26 --> Model Class Initialized
INFO - 2023-09-23 10:59:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 10:59:26 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:26 --> Total execution time: 0.0283
ERROR - 2023-09-23 10:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:30 --> Config Class Initialized
INFO - 2023-09-23 10:59:30 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:30 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:30 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:30 --> URI Class Initialized
INFO - 2023-09-23 10:59:30 --> Router Class Initialized
INFO - 2023-09-23 10:59:30 --> Output Class Initialized
INFO - 2023-09-23 10:59:30 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:30 --> Input Class Initialized
INFO - 2023-09-23 10:59:30 --> Language Class Initialized
INFO - 2023-09-23 10:59:30 --> Loader Class Initialized
INFO - 2023-09-23 10:59:30 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:30 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:30 --> Parser Class Initialized
INFO - 2023-09-23 10:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:30 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:30 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:30 --> Controller Class Initialized
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
INFO - 2023-09-23 10:59:30 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:30 --> Total execution time: 0.0177
ERROR - 2023-09-23 10:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:30 --> Config Class Initialized
INFO - 2023-09-23 10:59:30 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:30 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:30 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:30 --> URI Class Initialized
DEBUG - 2023-09-23 10:59:30 --> No URI present. Default controller set.
INFO - 2023-09-23 10:59:30 --> Router Class Initialized
INFO - 2023-09-23 10:59:30 --> Output Class Initialized
INFO - 2023-09-23 10:59:30 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:30 --> Input Class Initialized
INFO - 2023-09-23 10:59:30 --> Language Class Initialized
INFO - 2023-09-23 10:59:30 --> Loader Class Initialized
INFO - 2023-09-23 10:59:30 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:30 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:30 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:30 --> Parser Class Initialized
INFO - 2023-09-23 10:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:30 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:30 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:30 --> Controller Class Initialized
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 10:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
INFO - 2023-09-23 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-23 10:59:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 10:59:30 --> Model Class Initialized
INFO - 2023-09-23 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 10:59:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 10:59:30 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:30 --> Total execution time: 0.1033
ERROR - 2023-09-23 10:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:48 --> Config Class Initialized
INFO - 2023-09-23 10:59:48 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:48 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:48 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:48 --> URI Class Initialized
INFO - 2023-09-23 10:59:48 --> Router Class Initialized
INFO - 2023-09-23 10:59:48 --> Output Class Initialized
INFO - 2023-09-23 10:59:48 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:48 --> Input Class Initialized
INFO - 2023-09-23 10:59:48 --> Language Class Initialized
INFO - 2023-09-23 10:59:48 --> Loader Class Initialized
INFO - 2023-09-23 10:59:48 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:48 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:48 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:48 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:48 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:48 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:48 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:48 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:48 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:48 --> Parser Class Initialized
INFO - 2023-09-23 10:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:48 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:48 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:48 --> Controller Class Initialized
INFO - 2023-09-23 10:59:48 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 10:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:48 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-23 10:59:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-23 10:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-23 10:59:48 --> Model Class Initialized
INFO - 2023-09-23 10:59:48 --> Model Class Initialized
INFO - 2023-09-23 10:59:48 --> Model Class Initialized
INFO - 2023-09-23 10:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-23 10:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-23 10:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-23 10:59:48 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:48 --> Total execution time: 0.0818
ERROR - 2023-09-23 10:59:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:56 --> Config Class Initialized
INFO - 2023-09-23 10:59:56 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:56 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:56 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:56 --> URI Class Initialized
INFO - 2023-09-23 10:59:56 --> Router Class Initialized
INFO - 2023-09-23 10:59:56 --> Output Class Initialized
INFO - 2023-09-23 10:59:56 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:56 --> Input Class Initialized
INFO - 2023-09-23 10:59:56 --> Language Class Initialized
INFO - 2023-09-23 10:59:56 --> Loader Class Initialized
INFO - 2023-09-23 10:59:56 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:56 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:56 --> Parser Class Initialized
INFO - 2023-09-23 10:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:56 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:56 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:56 --> Controller Class Initialized
INFO - 2023-09-23 10:59:56 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:56 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:56 --> Model Class Initialized
INFO - 2023-09-23 10:59:56 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:56 --> Total execution time: 0.0666
ERROR - 2023-09-23 10:59:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:56 --> Config Class Initialized
INFO - 2023-09-23 10:59:56 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:56 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:56 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:56 --> URI Class Initialized
INFO - 2023-09-23 10:59:56 --> Router Class Initialized
INFO - 2023-09-23 10:59:56 --> Output Class Initialized
INFO - 2023-09-23 10:59:56 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:56 --> Input Class Initialized
INFO - 2023-09-23 10:59:56 --> Language Class Initialized
INFO - 2023-09-23 10:59:56 --> Loader Class Initialized
INFO - 2023-09-23 10:59:56 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:56 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:56 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:56 --> Parser Class Initialized
INFO - 2023-09-23 10:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:56 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:56 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:56 --> Controller Class Initialized
INFO - 2023-09-23 10:59:56 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:56 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:56 --> Model Class Initialized
INFO - 2023-09-23 10:59:56 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:56 --> Total execution time: 0.0627
ERROR - 2023-09-23 10:59:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:57 --> Config Class Initialized
INFO - 2023-09-23 10:59:57 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:57 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:57 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:57 --> URI Class Initialized
INFO - 2023-09-23 10:59:57 --> Router Class Initialized
INFO - 2023-09-23 10:59:57 --> Output Class Initialized
INFO - 2023-09-23 10:59:57 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:57 --> Input Class Initialized
INFO - 2023-09-23 10:59:57 --> Language Class Initialized
INFO - 2023-09-23 10:59:57 --> Loader Class Initialized
INFO - 2023-09-23 10:59:57 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:57 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:57 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:57 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:57 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:57 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:57 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:57 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:57 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:57 --> Parser Class Initialized
INFO - 2023-09-23 10:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:57 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:57 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:57 --> Controller Class Initialized
INFO - 2023-09-23 10:59:57 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 10:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:57 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:57 --> Model Class Initialized
INFO - 2023-09-23 10:59:57 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:57 --> Total execution time: 0.0618
ERROR - 2023-09-23 10:59:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 10:59:58 --> Config Class Initialized
INFO - 2023-09-23 10:59:58 --> Hooks Class Initialized
DEBUG - 2023-09-23 10:59:58 --> UTF-8 Support Enabled
INFO - 2023-09-23 10:59:58 --> Utf8 Class Initialized
INFO - 2023-09-23 10:59:58 --> URI Class Initialized
INFO - 2023-09-23 10:59:58 --> Router Class Initialized
INFO - 2023-09-23 10:59:58 --> Output Class Initialized
INFO - 2023-09-23 10:59:58 --> Security Class Initialized
DEBUG - 2023-09-23 10:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 10:59:58 --> Input Class Initialized
INFO - 2023-09-23 10:59:58 --> Language Class Initialized
INFO - 2023-09-23 10:59:58 --> Loader Class Initialized
INFO - 2023-09-23 10:59:58 --> Helper loaded: url_helper
INFO - 2023-09-23 10:59:58 --> Helper loaded: file_helper
INFO - 2023-09-23 10:59:58 --> Helper loaded: html_helper
INFO - 2023-09-23 10:59:58 --> Helper loaded: text_helper
INFO - 2023-09-23 10:59:58 --> Helper loaded: form_helper
INFO - 2023-09-23 10:59:58 --> Helper loaded: lang_helper
INFO - 2023-09-23 10:59:58 --> Helper loaded: security_helper
INFO - 2023-09-23 10:59:58 --> Helper loaded: cookie_helper
INFO - 2023-09-23 10:59:58 --> Database Driver Class Initialized
INFO - 2023-09-23 10:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 10:59:58 --> Parser Class Initialized
INFO - 2023-09-23 10:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 10:59:58 --> Pagination Class Initialized
INFO - 2023-09-23 10:59:58 --> Form Validation Class Initialized
INFO - 2023-09-23 10:59:58 --> Controller Class Initialized
INFO - 2023-09-23 10:59:58 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:58 --> Model Class Initialized
DEBUG - 2023-09-23 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 10:59:58 --> Model Class Initialized
INFO - 2023-09-23 10:59:58 --> Final output sent to browser
DEBUG - 2023-09-23 10:59:58 --> Total execution time: 0.0619
ERROR - 2023-09-23 11:00:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:12 --> Config Class Initialized
INFO - 2023-09-23 11:00:12 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:12 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:12 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:12 --> URI Class Initialized
INFO - 2023-09-23 11:00:12 --> Router Class Initialized
INFO - 2023-09-23 11:00:12 --> Output Class Initialized
INFO - 2023-09-23 11:00:12 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:12 --> Input Class Initialized
INFO - 2023-09-23 11:00:12 --> Language Class Initialized
INFO - 2023-09-23 11:00:12 --> Loader Class Initialized
INFO - 2023-09-23 11:00:12 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:12 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:12 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:12 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:12 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:12 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:12 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:12 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:12 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:12 --> Parser Class Initialized
INFO - 2023-09-23 11:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:12 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:12 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:12 --> Controller Class Initialized
INFO - 2023-09-23 11:00:12 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:12 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:12 --> Model Class Initialized
INFO - 2023-09-23 11:00:12 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:12 --> Total execution time: 0.0209
ERROR - 2023-09-23 11:00:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:13 --> Config Class Initialized
INFO - 2023-09-23 11:00:13 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:13 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:13 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:13 --> URI Class Initialized
INFO - 2023-09-23 11:00:13 --> Router Class Initialized
INFO - 2023-09-23 11:00:13 --> Output Class Initialized
INFO - 2023-09-23 11:00:13 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:13 --> Input Class Initialized
INFO - 2023-09-23 11:00:13 --> Language Class Initialized
INFO - 2023-09-23 11:00:13 --> Loader Class Initialized
INFO - 2023-09-23 11:00:13 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:13 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:13 --> Parser Class Initialized
INFO - 2023-09-23 11:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:13 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:13 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:13 --> Controller Class Initialized
INFO - 2023-09-23 11:00:13 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:13 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:13 --> Model Class Initialized
INFO - 2023-09-23 11:00:13 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:13 --> Total execution time: 0.0217
ERROR - 2023-09-23 11:00:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:13 --> Config Class Initialized
INFO - 2023-09-23 11:00:13 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:13 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:13 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:13 --> URI Class Initialized
INFO - 2023-09-23 11:00:13 --> Router Class Initialized
INFO - 2023-09-23 11:00:13 --> Output Class Initialized
INFO - 2023-09-23 11:00:13 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:13 --> Input Class Initialized
INFO - 2023-09-23 11:00:13 --> Language Class Initialized
INFO - 2023-09-23 11:00:13 --> Loader Class Initialized
INFO - 2023-09-23 11:00:13 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:13 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:13 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:13 --> Parser Class Initialized
INFO - 2023-09-23 11:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:13 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:13 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:13 --> Controller Class Initialized
INFO - 2023-09-23 11:00:13 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:13 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:13 --> Model Class Initialized
INFO - 2023-09-23 11:00:13 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:13 --> Total execution time: 0.0204
ERROR - 2023-09-23 11:00:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:14 --> Config Class Initialized
INFO - 2023-09-23 11:00:14 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:14 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:14 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:14 --> URI Class Initialized
INFO - 2023-09-23 11:00:14 --> Router Class Initialized
INFO - 2023-09-23 11:00:14 --> Output Class Initialized
INFO - 2023-09-23 11:00:14 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:14 --> Input Class Initialized
INFO - 2023-09-23 11:00:14 --> Language Class Initialized
INFO - 2023-09-23 11:00:14 --> Loader Class Initialized
INFO - 2023-09-23 11:00:14 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:14 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:14 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:14 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:14 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:14 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:14 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:14 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:14 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:14 --> Parser Class Initialized
INFO - 2023-09-23 11:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:14 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:14 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:14 --> Controller Class Initialized
INFO - 2023-09-23 11:00:14 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:14 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:14 --> Model Class Initialized
INFO - 2023-09-23 11:00:14 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:14 --> Total execution time: 0.0214
ERROR - 2023-09-23 11:00:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:15 --> Config Class Initialized
INFO - 2023-09-23 11:00:15 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:15 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:15 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:15 --> URI Class Initialized
INFO - 2023-09-23 11:00:15 --> Router Class Initialized
INFO - 2023-09-23 11:00:15 --> Output Class Initialized
INFO - 2023-09-23 11:00:15 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:15 --> Input Class Initialized
INFO - 2023-09-23 11:00:15 --> Language Class Initialized
INFO - 2023-09-23 11:00:15 --> Loader Class Initialized
INFO - 2023-09-23 11:00:15 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:15 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:15 --> Parser Class Initialized
INFO - 2023-09-23 11:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:15 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:15 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:15 --> Controller Class Initialized
INFO - 2023-09-23 11:00:15 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:15 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:15 --> Model Class Initialized
INFO - 2023-09-23 11:00:15 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:15 --> Total execution time: 0.0228
ERROR - 2023-09-23 11:00:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:15 --> Config Class Initialized
INFO - 2023-09-23 11:00:15 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:15 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:15 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:15 --> URI Class Initialized
INFO - 2023-09-23 11:00:15 --> Router Class Initialized
INFO - 2023-09-23 11:00:15 --> Output Class Initialized
INFO - 2023-09-23 11:00:15 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:15 --> Input Class Initialized
INFO - 2023-09-23 11:00:15 --> Language Class Initialized
INFO - 2023-09-23 11:00:15 --> Loader Class Initialized
INFO - 2023-09-23 11:00:15 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:15 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:15 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:15 --> Parser Class Initialized
INFO - 2023-09-23 11:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:15 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:15 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:15 --> Controller Class Initialized
INFO - 2023-09-23 11:00:15 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:15 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:15 --> Model Class Initialized
INFO - 2023-09-23 11:00:15 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:15 --> Total execution time: 0.0608
ERROR - 2023-09-23 11:00:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:21 --> Config Class Initialized
INFO - 2023-09-23 11:00:21 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:21 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:21 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:21 --> URI Class Initialized
INFO - 2023-09-23 11:00:21 --> Router Class Initialized
INFO - 2023-09-23 11:00:21 --> Output Class Initialized
INFO - 2023-09-23 11:00:21 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:21 --> Input Class Initialized
INFO - 2023-09-23 11:00:21 --> Language Class Initialized
INFO - 2023-09-23 11:00:21 --> Loader Class Initialized
INFO - 2023-09-23 11:00:21 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:21 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:21 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:21 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:21 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:21 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:21 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:21 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:21 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:21 --> Parser Class Initialized
INFO - 2023-09-23 11:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:21 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:21 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:21 --> Controller Class Initialized
INFO - 2023-09-23 11:00:21 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:21 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:21 --> Model Class Initialized
INFO - 2023-09-23 11:00:21 --> Model Class Initialized
INFO - 2023-09-23 11:00:21 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:21 --> Total execution time: 0.0230
ERROR - 2023-09-23 11:00:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:28 --> Config Class Initialized
INFO - 2023-09-23 11:00:28 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:28 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:28 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:28 --> URI Class Initialized
INFO - 2023-09-23 11:00:28 --> Router Class Initialized
INFO - 2023-09-23 11:00:28 --> Output Class Initialized
INFO - 2023-09-23 11:00:28 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:28 --> Input Class Initialized
INFO - 2023-09-23 11:00:28 --> Language Class Initialized
INFO - 2023-09-23 11:00:28 --> Loader Class Initialized
INFO - 2023-09-23 11:00:28 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:28 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:28 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:28 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:28 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:28 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:28 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:28 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:28 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:28 --> Parser Class Initialized
INFO - 2023-09-23 11:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:28 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:28 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:28 --> Controller Class Initialized
INFO - 2023-09-23 11:00:28 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:28 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:28 --> Model Class Initialized
INFO - 2023-09-23 11:00:29 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:29 --> Total execution time: 0.0222
ERROR - 2023-09-23 11:00:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:29 --> Config Class Initialized
INFO - 2023-09-23 11:00:29 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:29 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:29 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:29 --> URI Class Initialized
INFO - 2023-09-23 11:00:29 --> Router Class Initialized
INFO - 2023-09-23 11:00:29 --> Output Class Initialized
INFO - 2023-09-23 11:00:29 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:29 --> Input Class Initialized
INFO - 2023-09-23 11:00:29 --> Language Class Initialized
INFO - 2023-09-23 11:00:29 --> Loader Class Initialized
INFO - 2023-09-23 11:00:29 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:29 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:29 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:29 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:29 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:29 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:29 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:29 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:29 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:29 --> Parser Class Initialized
INFO - 2023-09-23 11:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:29 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:29 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:29 --> Controller Class Initialized
INFO - 2023-09-23 11:00:29 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:29 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:29 --> Model Class Initialized
INFO - 2023-09-23 11:00:29 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:29 --> Total execution time: 0.0203
ERROR - 2023-09-23 11:00:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:31 --> Config Class Initialized
INFO - 2023-09-23 11:00:31 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:31 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:31 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:31 --> URI Class Initialized
INFO - 2023-09-23 11:00:31 --> Router Class Initialized
INFO - 2023-09-23 11:00:31 --> Output Class Initialized
INFO - 2023-09-23 11:00:31 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:31 --> Input Class Initialized
INFO - 2023-09-23 11:00:31 --> Language Class Initialized
INFO - 2023-09-23 11:00:31 --> Loader Class Initialized
INFO - 2023-09-23 11:00:31 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:31 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:31 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:31 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:31 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:31 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:31 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:31 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:31 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:31 --> Parser Class Initialized
INFO - 2023-09-23 11:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:31 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:31 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:31 --> Controller Class Initialized
INFO - 2023-09-23 11:00:31 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:31 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:31 --> Model Class Initialized
INFO - 2023-09-23 11:00:31 --> Model Class Initialized
INFO - 2023-09-23 11:00:31 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:31 --> Total execution time: 0.0209
ERROR - 2023-09-23 11:00:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:40 --> Config Class Initialized
INFO - 2023-09-23 11:00:40 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:40 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:40 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:40 --> URI Class Initialized
INFO - 2023-09-23 11:00:40 --> Router Class Initialized
INFO - 2023-09-23 11:00:40 --> Output Class Initialized
INFO - 2023-09-23 11:00:40 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:40 --> Input Class Initialized
INFO - 2023-09-23 11:00:40 --> Language Class Initialized
INFO - 2023-09-23 11:00:40 --> Loader Class Initialized
INFO - 2023-09-23 11:00:40 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:40 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:40 --> Parser Class Initialized
INFO - 2023-09-23 11:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:40 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:40 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:40 --> Controller Class Initialized
INFO - 2023-09-23 11:00:40 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:40 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:40 --> Model Class Initialized
INFO - 2023-09-23 11:00:40 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:40 --> Total execution time: 0.0617
ERROR - 2023-09-23 11:00:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:40 --> Config Class Initialized
INFO - 2023-09-23 11:00:40 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:40 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:40 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:40 --> URI Class Initialized
INFO - 2023-09-23 11:00:40 --> Router Class Initialized
INFO - 2023-09-23 11:00:40 --> Output Class Initialized
INFO - 2023-09-23 11:00:40 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:40 --> Input Class Initialized
INFO - 2023-09-23 11:00:40 --> Language Class Initialized
INFO - 2023-09-23 11:00:40 --> Loader Class Initialized
INFO - 2023-09-23 11:00:40 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:40 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:40 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:40 --> Parser Class Initialized
INFO - 2023-09-23 11:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:40 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:40 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:40 --> Controller Class Initialized
INFO - 2023-09-23 11:00:40 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:40 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:40 --> Model Class Initialized
INFO - 2023-09-23 11:00:40 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:40 --> Total execution time: 0.0185
ERROR - 2023-09-23 11:00:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:41 --> Config Class Initialized
INFO - 2023-09-23 11:00:41 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:41 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:41 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:41 --> URI Class Initialized
INFO - 2023-09-23 11:00:41 --> Router Class Initialized
INFO - 2023-09-23 11:00:41 --> Output Class Initialized
INFO - 2023-09-23 11:00:41 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:41 --> Input Class Initialized
INFO - 2023-09-23 11:00:41 --> Language Class Initialized
INFO - 2023-09-23 11:00:41 --> Loader Class Initialized
INFO - 2023-09-23 11:00:41 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:41 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:41 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:41 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:41 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:41 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:41 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:41 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:41 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:41 --> Parser Class Initialized
INFO - 2023-09-23 11:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:41 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:41 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:41 --> Controller Class Initialized
INFO - 2023-09-23 11:00:41 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:41 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:41 --> Model Class Initialized
INFO - 2023-09-23 11:00:41 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:41 --> Total execution time: 0.0181
ERROR - 2023-09-23 11:00:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:43 --> Config Class Initialized
INFO - 2023-09-23 11:00:43 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:43 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:43 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:43 --> URI Class Initialized
INFO - 2023-09-23 11:00:43 --> Router Class Initialized
INFO - 2023-09-23 11:00:43 --> Output Class Initialized
INFO - 2023-09-23 11:00:43 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:43 --> Input Class Initialized
INFO - 2023-09-23 11:00:43 --> Language Class Initialized
INFO - 2023-09-23 11:00:43 --> Loader Class Initialized
INFO - 2023-09-23 11:00:43 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:43 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:43 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:43 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:43 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:43 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:43 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:43 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:43 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:43 --> Parser Class Initialized
INFO - 2023-09-23 11:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:43 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:43 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:43 --> Controller Class Initialized
INFO - 2023-09-23 11:00:43 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:43 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:43 --> Model Class Initialized
INFO - 2023-09-23 11:00:43 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:43 --> Total execution time: 0.0643
ERROR - 2023-09-23 11:00:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 11:00:44 --> Config Class Initialized
INFO - 2023-09-23 11:00:44 --> Hooks Class Initialized
DEBUG - 2023-09-23 11:00:44 --> UTF-8 Support Enabled
INFO - 2023-09-23 11:00:44 --> Utf8 Class Initialized
INFO - 2023-09-23 11:00:44 --> URI Class Initialized
INFO - 2023-09-23 11:00:44 --> Router Class Initialized
INFO - 2023-09-23 11:00:44 --> Output Class Initialized
INFO - 2023-09-23 11:00:44 --> Security Class Initialized
DEBUG - 2023-09-23 11:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 11:00:44 --> Input Class Initialized
INFO - 2023-09-23 11:00:44 --> Language Class Initialized
INFO - 2023-09-23 11:00:44 --> Loader Class Initialized
INFO - 2023-09-23 11:00:44 --> Helper loaded: url_helper
INFO - 2023-09-23 11:00:44 --> Helper loaded: file_helper
INFO - 2023-09-23 11:00:44 --> Helper loaded: html_helper
INFO - 2023-09-23 11:00:44 --> Helper loaded: text_helper
INFO - 2023-09-23 11:00:44 --> Helper loaded: form_helper
INFO - 2023-09-23 11:00:44 --> Helper loaded: lang_helper
INFO - 2023-09-23 11:00:44 --> Helper loaded: security_helper
INFO - 2023-09-23 11:00:44 --> Helper loaded: cookie_helper
INFO - 2023-09-23 11:00:44 --> Database Driver Class Initialized
INFO - 2023-09-23 11:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 11:00:44 --> Parser Class Initialized
INFO - 2023-09-23 11:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 11:00:44 --> Pagination Class Initialized
INFO - 2023-09-23 11:00:44 --> Form Validation Class Initialized
INFO - 2023-09-23 11:00:44 --> Controller Class Initialized
INFO - 2023-09-23 11:00:44 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-23 11:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:44 --> Model Class Initialized
DEBUG - 2023-09-23 11:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-23 11:00:44 --> Model Class Initialized
INFO - 2023-09-23 11:00:44 --> Final output sent to browser
DEBUG - 2023-09-23 11:00:44 --> Total execution time: 0.0199
ERROR - 2023-09-23 12:34:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:21 --> Config Class Initialized
INFO - 2023-09-23 12:34:21 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:21 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:21 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:21 --> URI Class Initialized
DEBUG - 2023-09-23 12:34:21 --> No URI present. Default controller set.
INFO - 2023-09-23 12:34:21 --> Router Class Initialized
INFO - 2023-09-23 12:34:21 --> Output Class Initialized
INFO - 2023-09-23 12:34:21 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:21 --> Input Class Initialized
INFO - 2023-09-23 12:34:21 --> Language Class Initialized
INFO - 2023-09-23 12:34:21 --> Loader Class Initialized
INFO - 2023-09-23 12:34:21 --> Helper loaded: url_helper
INFO - 2023-09-23 12:34:21 --> Helper loaded: file_helper
INFO - 2023-09-23 12:34:21 --> Helper loaded: html_helper
INFO - 2023-09-23 12:34:21 --> Helper loaded: text_helper
INFO - 2023-09-23 12:34:21 --> Helper loaded: form_helper
INFO - 2023-09-23 12:34:21 --> Helper loaded: lang_helper
INFO - 2023-09-23 12:34:21 --> Helper loaded: security_helper
INFO - 2023-09-23 12:34:21 --> Helper loaded: cookie_helper
INFO - 2023-09-23 12:34:21 --> Database Driver Class Initialized
INFO - 2023-09-23 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 12:34:21 --> Parser Class Initialized
INFO - 2023-09-23 12:34:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 12:34:21 --> Pagination Class Initialized
INFO - 2023-09-23 12:34:21 --> Form Validation Class Initialized
INFO - 2023-09-23 12:34:21 --> Controller Class Initialized
INFO - 2023-09-23 12:34:21 --> Model Class Initialized
DEBUG - 2023-09-23 12:34:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
DEBUG - 2023-09-23 12:34:22 --> No URI present. Default controller set.
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
INFO - 2023-09-23 12:34:22 --> Loader Class Initialized
INFO - 2023-09-23 12:34:22 --> Helper loaded: url_helper
INFO - 2023-09-23 12:34:22 --> Helper loaded: file_helper
INFO - 2023-09-23 12:34:22 --> Helper loaded: html_helper
INFO - 2023-09-23 12:34:22 --> Helper loaded: text_helper
INFO - 2023-09-23 12:34:22 --> Helper loaded: form_helper
INFO - 2023-09-23 12:34:22 --> Helper loaded: lang_helper
INFO - 2023-09-23 12:34:22 --> Helper loaded: security_helper
INFO - 2023-09-23 12:34:22 --> Helper loaded: cookie_helper
INFO - 2023-09-23 12:34:22 --> Database Driver Class Initialized
INFO - 2023-09-23 12:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 12:34:22 --> Parser Class Initialized
INFO - 2023-09-23 12:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 12:34:22 --> Pagination Class Initialized
INFO - 2023-09-23 12:34:22 --> Form Validation Class Initialized
INFO - 2023-09-23 12:34:22 --> Controller Class Initialized
INFO - 2023-09-23 12:34:22 --> Model Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-09-23 12:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:34:22 --> Config Class Initialized
INFO - 2023-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2023-09-23 12:34:22 --> URI Class Initialized
INFO - 2023-09-23 12:34:22 --> Router Class Initialized
INFO - 2023-09-23 12:34:22 --> Output Class Initialized
INFO - 2023-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2023-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:34:22 --> Input Class Initialized
INFO - 2023-09-23 12:34:22 --> Language Class Initialized
ERROR - 2023-09-23 12:34:22 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-09-23 12:37:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:37:43 --> Config Class Initialized
INFO - 2023-09-23 12:37:43 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:37:43 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:37:43 --> Utf8 Class Initialized
INFO - 2023-09-23 12:37:43 --> URI Class Initialized
INFO - 2023-09-23 12:37:43 --> Router Class Initialized
INFO - 2023-09-23 12:37:43 --> Output Class Initialized
INFO - 2023-09-23 12:37:43 --> Security Class Initialized
DEBUG - 2023-09-23 12:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:37:43 --> Input Class Initialized
INFO - 2023-09-23 12:37:43 --> Language Class Initialized
ERROR - 2023-09-23 12:37:43 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-09-23 12:37:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:37:44 --> Config Class Initialized
INFO - 2023-09-23 12:37:44 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:37:44 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:37:44 --> Utf8 Class Initialized
INFO - 2023-09-23 12:37:44 --> URI Class Initialized
DEBUG - 2023-09-23 12:37:44 --> No URI present. Default controller set.
INFO - 2023-09-23 12:37:44 --> Router Class Initialized
INFO - 2023-09-23 12:37:44 --> Output Class Initialized
INFO - 2023-09-23 12:37:44 --> Security Class Initialized
DEBUG - 2023-09-23 12:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:37:44 --> Input Class Initialized
INFO - 2023-09-23 12:37:44 --> Language Class Initialized
INFO - 2023-09-23 12:37:44 --> Loader Class Initialized
INFO - 2023-09-23 12:37:44 --> Helper loaded: url_helper
INFO - 2023-09-23 12:37:44 --> Helper loaded: file_helper
INFO - 2023-09-23 12:37:44 --> Helper loaded: html_helper
INFO - 2023-09-23 12:37:44 --> Helper loaded: text_helper
INFO - 2023-09-23 12:37:44 --> Helper loaded: form_helper
INFO - 2023-09-23 12:37:44 --> Helper loaded: lang_helper
INFO - 2023-09-23 12:37:44 --> Helper loaded: security_helper
INFO - 2023-09-23 12:37:44 --> Helper loaded: cookie_helper
INFO - 2023-09-23 12:37:44 --> Database Driver Class Initialized
INFO - 2023-09-23 12:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 12:37:44 --> Parser Class Initialized
INFO - 2023-09-23 12:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 12:37:44 --> Pagination Class Initialized
INFO - 2023-09-23 12:37:44 --> Form Validation Class Initialized
INFO - 2023-09-23 12:37:44 --> Controller Class Initialized
INFO - 2023-09-23 12:37:44 --> Model Class Initialized
DEBUG - 2023-09-23 12:37:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 12:37:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 12:37:45 --> Config Class Initialized
INFO - 2023-09-23 12:37:45 --> Hooks Class Initialized
DEBUG - 2023-09-23 12:37:45 --> UTF-8 Support Enabled
INFO - 2023-09-23 12:37:45 --> Utf8 Class Initialized
INFO - 2023-09-23 12:37:45 --> URI Class Initialized
INFO - 2023-09-23 12:37:45 --> Router Class Initialized
INFO - 2023-09-23 12:37:45 --> Output Class Initialized
INFO - 2023-09-23 12:37:45 --> Security Class Initialized
DEBUG - 2023-09-23 12:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 12:37:45 --> Input Class Initialized
INFO - 2023-09-23 12:37:45 --> Language Class Initialized
ERROR - 2023-09-23 12:37:45 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2023-09-23 21:02:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:02:57 --> Config Class Initialized
INFO - 2023-09-23 21:02:57 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:02:57 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:02:57 --> Utf8 Class Initialized
INFO - 2023-09-23 21:02:57 --> URI Class Initialized
DEBUG - 2023-09-23 21:02:57 --> No URI present. Default controller set.
INFO - 2023-09-23 21:02:57 --> Router Class Initialized
INFO - 2023-09-23 21:02:57 --> Output Class Initialized
INFO - 2023-09-23 21:02:57 --> Security Class Initialized
DEBUG - 2023-09-23 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:02:57 --> Input Class Initialized
INFO - 2023-09-23 21:02:57 --> Language Class Initialized
INFO - 2023-09-23 21:02:57 --> Loader Class Initialized
INFO - 2023-09-23 21:02:57 --> Helper loaded: url_helper
INFO - 2023-09-23 21:02:57 --> Helper loaded: file_helper
INFO - 2023-09-23 21:02:57 --> Helper loaded: html_helper
INFO - 2023-09-23 21:02:57 --> Helper loaded: text_helper
INFO - 2023-09-23 21:02:57 --> Helper loaded: form_helper
INFO - 2023-09-23 21:02:57 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:02:57 --> Helper loaded: security_helper
INFO - 2023-09-23 21:02:57 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:02:57 --> Database Driver Class Initialized
INFO - 2023-09-23 21:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:02:57 --> Parser Class Initialized
INFO - 2023-09-23 21:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:02:57 --> Pagination Class Initialized
INFO - 2023-09-23 21:02:57 --> Form Validation Class Initialized
INFO - 2023-09-23 21:02:57 --> Controller Class Initialized
INFO - 2023-09-23 21:02:57 --> Model Class Initialized
DEBUG - 2023-09-23 21:02:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:02:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:02:58 --> Config Class Initialized
INFO - 2023-09-23 21:02:58 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:02:58 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:02:58 --> Utf8 Class Initialized
INFO - 2023-09-23 21:02:58 --> URI Class Initialized
DEBUG - 2023-09-23 21:02:58 --> No URI present. Default controller set.
INFO - 2023-09-23 21:02:58 --> Router Class Initialized
INFO - 2023-09-23 21:02:58 --> Output Class Initialized
INFO - 2023-09-23 21:02:58 --> Security Class Initialized
DEBUG - 2023-09-23 21:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:02:58 --> Input Class Initialized
INFO - 2023-09-23 21:02:58 --> Language Class Initialized
INFO - 2023-09-23 21:02:58 --> Loader Class Initialized
INFO - 2023-09-23 21:02:58 --> Helper loaded: url_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: file_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: html_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: text_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: form_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: security_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:02:58 --> Database Driver Class Initialized
INFO - 2023-09-23 21:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:02:58 --> Parser Class Initialized
INFO - 2023-09-23 21:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:02:58 --> Pagination Class Initialized
INFO - 2023-09-23 21:02:58 --> Form Validation Class Initialized
INFO - 2023-09-23 21:02:58 --> Controller Class Initialized
INFO - 2023-09-23 21:02:58 --> Model Class Initialized
DEBUG - 2023-09-23 21:02:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:02:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:02:58 --> Config Class Initialized
INFO - 2023-09-23 21:02:58 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:02:58 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:02:58 --> Utf8 Class Initialized
INFO - 2023-09-23 21:02:58 --> URI Class Initialized
DEBUG - 2023-09-23 21:02:58 --> No URI present. Default controller set.
INFO - 2023-09-23 21:02:58 --> Router Class Initialized
INFO - 2023-09-23 21:02:58 --> Output Class Initialized
INFO - 2023-09-23 21:02:58 --> Security Class Initialized
DEBUG - 2023-09-23 21:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:02:58 --> Input Class Initialized
INFO - 2023-09-23 21:02:58 --> Language Class Initialized
INFO - 2023-09-23 21:02:58 --> Loader Class Initialized
INFO - 2023-09-23 21:02:58 --> Helper loaded: url_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: file_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: html_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: text_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: form_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: security_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:02:58 --> Database Driver Class Initialized
INFO - 2023-09-23 21:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:02:58 --> Parser Class Initialized
INFO - 2023-09-23 21:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:02:58 --> Pagination Class Initialized
INFO - 2023-09-23 21:02:58 --> Form Validation Class Initialized
INFO - 2023-09-23 21:02:58 --> Controller Class Initialized
INFO - 2023-09-23 21:02:58 --> Model Class Initialized
DEBUG - 2023-09-23 21:02:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:02:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:02:58 --> Config Class Initialized
INFO - 2023-09-23 21:02:58 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:02:58 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:02:58 --> Utf8 Class Initialized
INFO - 2023-09-23 21:02:58 --> URI Class Initialized
DEBUG - 2023-09-23 21:02:58 --> No URI present. Default controller set.
INFO - 2023-09-23 21:02:58 --> Router Class Initialized
INFO - 2023-09-23 21:02:58 --> Output Class Initialized
INFO - 2023-09-23 21:02:58 --> Security Class Initialized
DEBUG - 2023-09-23 21:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:02:58 --> Input Class Initialized
INFO - 2023-09-23 21:02:58 --> Language Class Initialized
INFO - 2023-09-23 21:02:58 --> Loader Class Initialized
INFO - 2023-09-23 21:02:58 --> Helper loaded: url_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: file_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: html_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: text_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: form_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: security_helper
INFO - 2023-09-23 21:02:58 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:02:58 --> Database Driver Class Initialized
INFO - 2023-09-23 21:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:02:58 --> Parser Class Initialized
INFO - 2023-09-23 21:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:02:58 --> Pagination Class Initialized
INFO - 2023-09-23 21:02:58 --> Form Validation Class Initialized
INFO - 2023-09-23 21:02:58 --> Controller Class Initialized
INFO - 2023-09-23 21:02:58 --> Model Class Initialized
DEBUG - 2023-09-23 21:02:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:02:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:02:59 --> Config Class Initialized
INFO - 2023-09-23 21:02:59 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:02:59 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:02:59 --> Utf8 Class Initialized
INFO - 2023-09-23 21:02:59 --> URI Class Initialized
DEBUG - 2023-09-23 21:02:59 --> No URI present. Default controller set.
INFO - 2023-09-23 21:02:59 --> Router Class Initialized
INFO - 2023-09-23 21:02:59 --> Output Class Initialized
INFO - 2023-09-23 21:02:59 --> Security Class Initialized
DEBUG - 2023-09-23 21:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:02:59 --> Input Class Initialized
INFO - 2023-09-23 21:02:59 --> Language Class Initialized
INFO - 2023-09-23 21:02:59 --> Loader Class Initialized
INFO - 2023-09-23 21:02:59 --> Helper loaded: url_helper
INFO - 2023-09-23 21:02:59 --> Helper loaded: file_helper
INFO - 2023-09-23 21:02:59 --> Helper loaded: html_helper
INFO - 2023-09-23 21:02:59 --> Helper loaded: text_helper
INFO - 2023-09-23 21:02:59 --> Helper loaded: form_helper
INFO - 2023-09-23 21:02:59 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:02:59 --> Helper loaded: security_helper
INFO - 2023-09-23 21:02:59 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:02:59 --> Database Driver Class Initialized
INFO - 2023-09-23 21:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:02:59 --> Parser Class Initialized
INFO - 2023-09-23 21:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:02:59 --> Pagination Class Initialized
INFO - 2023-09-23 21:02:59 --> Form Validation Class Initialized
INFO - 2023-09-23 21:02:59 --> Controller Class Initialized
INFO - 2023-09-23 21:02:59 --> Model Class Initialized
DEBUG - 2023-09-23 21:02:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:03:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:03:00 --> Config Class Initialized
INFO - 2023-09-23 21:03:00 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:03:00 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:03:00 --> Utf8 Class Initialized
INFO - 2023-09-23 21:03:00 --> URI Class Initialized
DEBUG - 2023-09-23 21:03:00 --> No URI present. Default controller set.
INFO - 2023-09-23 21:03:00 --> Router Class Initialized
INFO - 2023-09-23 21:03:00 --> Output Class Initialized
INFO - 2023-09-23 21:03:00 --> Security Class Initialized
DEBUG - 2023-09-23 21:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:03:00 --> Input Class Initialized
INFO - 2023-09-23 21:03:00 --> Language Class Initialized
INFO - 2023-09-23 21:03:00 --> Loader Class Initialized
INFO - 2023-09-23 21:03:00 --> Helper loaded: url_helper
INFO - 2023-09-23 21:03:00 --> Helper loaded: file_helper
INFO - 2023-09-23 21:03:00 --> Helper loaded: html_helper
INFO - 2023-09-23 21:03:00 --> Helper loaded: text_helper
INFO - 2023-09-23 21:03:00 --> Helper loaded: form_helper
INFO - 2023-09-23 21:03:00 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:03:00 --> Helper loaded: security_helper
INFO - 2023-09-23 21:03:00 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:03:00 --> Database Driver Class Initialized
INFO - 2023-09-23 21:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:03:00 --> Parser Class Initialized
INFO - 2023-09-23 21:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:03:00 --> Pagination Class Initialized
INFO - 2023-09-23 21:03:00 --> Form Validation Class Initialized
INFO - 2023-09-23 21:03:00 --> Controller Class Initialized
INFO - 2023-09-23 21:03:00 --> Model Class Initialized
DEBUG - 2023-09-23 21:03:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:03:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:03:01 --> Config Class Initialized
INFO - 2023-09-23 21:03:01 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:03:01 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:03:01 --> Utf8 Class Initialized
INFO - 2023-09-23 21:03:01 --> URI Class Initialized
DEBUG - 2023-09-23 21:03:01 --> No URI present. Default controller set.
INFO - 2023-09-23 21:03:01 --> Router Class Initialized
INFO - 2023-09-23 21:03:01 --> Output Class Initialized
INFO - 2023-09-23 21:03:01 --> Security Class Initialized
DEBUG - 2023-09-23 21:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:03:01 --> Input Class Initialized
INFO - 2023-09-23 21:03:01 --> Language Class Initialized
INFO - 2023-09-23 21:03:01 --> Loader Class Initialized
INFO - 2023-09-23 21:03:01 --> Helper loaded: url_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: file_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: html_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: text_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: form_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: security_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:03:01 --> Database Driver Class Initialized
INFO - 2023-09-23 21:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:03:01 --> Parser Class Initialized
INFO - 2023-09-23 21:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:03:01 --> Pagination Class Initialized
INFO - 2023-09-23 21:03:01 --> Form Validation Class Initialized
INFO - 2023-09-23 21:03:01 --> Controller Class Initialized
INFO - 2023-09-23 21:03:01 --> Model Class Initialized
DEBUG - 2023-09-23 21:03:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:03:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:03:01 --> Config Class Initialized
INFO - 2023-09-23 21:03:01 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:03:01 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:03:01 --> Utf8 Class Initialized
INFO - 2023-09-23 21:03:01 --> URI Class Initialized
DEBUG - 2023-09-23 21:03:01 --> No URI present. Default controller set.
INFO - 2023-09-23 21:03:01 --> Router Class Initialized
INFO - 2023-09-23 21:03:01 --> Output Class Initialized
INFO - 2023-09-23 21:03:01 --> Security Class Initialized
DEBUG - 2023-09-23 21:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:03:01 --> Input Class Initialized
INFO - 2023-09-23 21:03:01 --> Language Class Initialized
INFO - 2023-09-23 21:03:01 --> Loader Class Initialized
INFO - 2023-09-23 21:03:01 --> Helper loaded: url_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: file_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: html_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: text_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: form_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:03:01 --> Helper loaded: security_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:03:02 --> Database Driver Class Initialized
INFO - 2023-09-23 21:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:03:02 --> Parser Class Initialized
INFO - 2023-09-23 21:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:03:02 --> Pagination Class Initialized
INFO - 2023-09-23 21:03:02 --> Form Validation Class Initialized
INFO - 2023-09-23 21:03:02 --> Controller Class Initialized
INFO - 2023-09-23 21:03:02 --> Model Class Initialized
DEBUG - 2023-09-23 21:03:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:03:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:03:02 --> Config Class Initialized
INFO - 2023-09-23 21:03:02 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:03:02 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:03:02 --> Utf8 Class Initialized
INFO - 2023-09-23 21:03:02 --> URI Class Initialized
DEBUG - 2023-09-23 21:03:02 --> No URI present. Default controller set.
INFO - 2023-09-23 21:03:02 --> Router Class Initialized
INFO - 2023-09-23 21:03:02 --> Output Class Initialized
INFO - 2023-09-23 21:03:02 --> Security Class Initialized
DEBUG - 2023-09-23 21:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:03:02 --> Input Class Initialized
INFO - 2023-09-23 21:03:02 --> Language Class Initialized
INFO - 2023-09-23 21:03:02 --> Loader Class Initialized
INFO - 2023-09-23 21:03:02 --> Helper loaded: url_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: file_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: html_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: text_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: form_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: security_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:03:02 --> Database Driver Class Initialized
INFO - 2023-09-23 21:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:03:02 --> Parser Class Initialized
INFO - 2023-09-23 21:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:03:02 --> Pagination Class Initialized
INFO - 2023-09-23 21:03:02 --> Form Validation Class Initialized
INFO - 2023-09-23 21:03:02 --> Controller Class Initialized
INFO - 2023-09-23 21:03:02 --> Model Class Initialized
DEBUG - 2023-09-23 21:03:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:03:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:03:02 --> Config Class Initialized
INFO - 2023-09-23 21:03:02 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:03:02 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:03:02 --> Utf8 Class Initialized
INFO - 2023-09-23 21:03:02 --> URI Class Initialized
DEBUG - 2023-09-23 21:03:02 --> No URI present. Default controller set.
INFO - 2023-09-23 21:03:02 --> Router Class Initialized
INFO - 2023-09-23 21:03:02 --> Output Class Initialized
INFO - 2023-09-23 21:03:02 --> Security Class Initialized
DEBUG - 2023-09-23 21:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:03:02 --> Input Class Initialized
INFO - 2023-09-23 21:03:02 --> Language Class Initialized
INFO - 2023-09-23 21:03:02 --> Loader Class Initialized
INFO - 2023-09-23 21:03:02 --> Helper loaded: url_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: file_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: html_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: text_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: form_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: security_helper
INFO - 2023-09-23 21:03:02 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:03:02 --> Database Driver Class Initialized
INFO - 2023-09-23 21:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:03:02 --> Parser Class Initialized
INFO - 2023-09-23 21:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:03:02 --> Pagination Class Initialized
INFO - 2023-09-23 21:03:02 --> Form Validation Class Initialized
INFO - 2023-09-23 21:03:02 --> Controller Class Initialized
INFO - 2023-09-23 21:03:02 --> Model Class Initialized
DEBUG - 2023-09-23 21:03:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:03:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:03:03 --> Config Class Initialized
INFO - 2023-09-23 21:03:03 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:03:03 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:03:03 --> Utf8 Class Initialized
INFO - 2023-09-23 21:03:03 --> URI Class Initialized
DEBUG - 2023-09-23 21:03:03 --> No URI present. Default controller set.
INFO - 2023-09-23 21:03:03 --> Router Class Initialized
INFO - 2023-09-23 21:03:03 --> Output Class Initialized
INFO - 2023-09-23 21:03:03 --> Security Class Initialized
DEBUG - 2023-09-23 21:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:03:03 --> Input Class Initialized
INFO - 2023-09-23 21:03:03 --> Language Class Initialized
INFO - 2023-09-23 21:03:03 --> Loader Class Initialized
INFO - 2023-09-23 21:03:03 --> Helper loaded: url_helper
INFO - 2023-09-23 21:03:03 --> Helper loaded: file_helper
INFO - 2023-09-23 21:03:03 --> Helper loaded: html_helper
INFO - 2023-09-23 21:03:03 --> Helper loaded: text_helper
INFO - 2023-09-23 21:03:03 --> Helper loaded: form_helper
INFO - 2023-09-23 21:03:03 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:03:03 --> Helper loaded: security_helper
INFO - 2023-09-23 21:03:03 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:03:03 --> Database Driver Class Initialized
INFO - 2023-09-23 21:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:03:03 --> Parser Class Initialized
INFO - 2023-09-23 21:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:03:03 --> Pagination Class Initialized
INFO - 2023-09-23 21:03:03 --> Form Validation Class Initialized
INFO - 2023-09-23 21:03:03 --> Controller Class Initialized
INFO - 2023-09-23 21:03:03 --> Model Class Initialized
DEBUG - 2023-09-23 21:03:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-23 21:03:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-23 21:03:04 --> Config Class Initialized
INFO - 2023-09-23 21:03:04 --> Hooks Class Initialized
DEBUG - 2023-09-23 21:03:04 --> UTF-8 Support Enabled
INFO - 2023-09-23 21:03:04 --> Utf8 Class Initialized
INFO - 2023-09-23 21:03:04 --> URI Class Initialized
DEBUG - 2023-09-23 21:03:04 --> No URI present. Default controller set.
INFO - 2023-09-23 21:03:04 --> Router Class Initialized
INFO - 2023-09-23 21:03:04 --> Output Class Initialized
INFO - 2023-09-23 21:03:04 --> Security Class Initialized
DEBUG - 2023-09-23 21:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-23 21:03:04 --> Input Class Initialized
INFO - 2023-09-23 21:03:04 --> Language Class Initialized
INFO - 2023-09-23 21:03:04 --> Loader Class Initialized
INFO - 2023-09-23 21:03:04 --> Helper loaded: url_helper
INFO - 2023-09-23 21:03:04 --> Helper loaded: file_helper
INFO - 2023-09-23 21:03:04 --> Helper loaded: html_helper
INFO - 2023-09-23 21:03:04 --> Helper loaded: text_helper
INFO - 2023-09-23 21:03:04 --> Helper loaded: form_helper
INFO - 2023-09-23 21:03:04 --> Helper loaded: lang_helper
INFO - 2023-09-23 21:03:04 --> Helper loaded: security_helper
INFO - 2023-09-23 21:03:04 --> Helper loaded: cookie_helper
INFO - 2023-09-23 21:03:04 --> Database Driver Class Initialized
INFO - 2023-09-23 21:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-23 21:03:04 --> Parser Class Initialized
INFO - 2023-09-23 21:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-23 21:03:04 --> Pagination Class Initialized
INFO - 2023-09-23 21:03:04 --> Form Validation Class Initialized
INFO - 2023-09-23 21:03:04 --> Controller Class Initialized
INFO - 2023-09-23 21:03:04 --> Model Class Initialized
DEBUG - 2023-09-23 21:03:04 --> Session class already loaded. Second attempt ignored.
