<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-12 07:00:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:00:43 --> Config Class Initialized
INFO - 2024-04-12 07:00:43 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:00:43 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:00:43 --> Utf8 Class Initialized
INFO - 2024-04-12 07:00:43 --> URI Class Initialized
DEBUG - 2024-04-12 07:00:43 --> No URI present. Default controller set.
INFO - 2024-04-12 07:00:43 --> Router Class Initialized
INFO - 2024-04-12 07:00:43 --> Output Class Initialized
INFO - 2024-04-12 07:00:43 --> Security Class Initialized
DEBUG - 2024-04-12 07:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:00:43 --> Input Class Initialized
INFO - 2024-04-12 07:00:43 --> Language Class Initialized
INFO - 2024-04-12 07:00:43 --> Loader Class Initialized
INFO - 2024-04-12 07:00:43 --> Helper loaded: url_helper
INFO - 2024-04-12 07:00:43 --> Helper loaded: file_helper
INFO - 2024-04-12 07:00:43 --> Helper loaded: html_helper
INFO - 2024-04-12 07:00:43 --> Helper loaded: text_helper
INFO - 2024-04-12 07:00:43 --> Helper loaded: form_helper
INFO - 2024-04-12 07:00:43 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:00:43 --> Helper loaded: security_helper
INFO - 2024-04-12 07:00:43 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:00:43 --> Database Driver Class Initialized
INFO - 2024-04-12 07:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:00:43 --> Parser Class Initialized
INFO - 2024-04-12 07:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:00:43 --> Pagination Class Initialized
INFO - 2024-04-12 07:00:43 --> Form Validation Class Initialized
INFO - 2024-04-12 07:00:43 --> Controller Class Initialized
INFO - 2024-04-12 07:00:43 --> Model Class Initialized
DEBUG - 2024-04-12 07:00:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-12 07:00:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:00:45 --> Config Class Initialized
INFO - 2024-04-12 07:00:45 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:00:45 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:00:45 --> Utf8 Class Initialized
INFO - 2024-04-12 07:00:45 --> URI Class Initialized
INFO - 2024-04-12 07:00:45 --> Router Class Initialized
INFO - 2024-04-12 07:00:45 --> Output Class Initialized
INFO - 2024-04-12 07:00:45 --> Security Class Initialized
DEBUG - 2024-04-12 07:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:00:45 --> Input Class Initialized
INFO - 2024-04-12 07:00:45 --> Language Class Initialized
INFO - 2024-04-12 07:00:45 --> Loader Class Initialized
INFO - 2024-04-12 07:00:45 --> Helper loaded: url_helper
INFO - 2024-04-12 07:00:45 --> Helper loaded: file_helper
INFO - 2024-04-12 07:00:45 --> Helper loaded: html_helper
INFO - 2024-04-12 07:00:45 --> Helper loaded: text_helper
INFO - 2024-04-12 07:00:45 --> Helper loaded: form_helper
INFO - 2024-04-12 07:00:45 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:00:45 --> Helper loaded: security_helper
INFO - 2024-04-12 07:00:45 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:00:45 --> Database Driver Class Initialized
INFO - 2024-04-12 07:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:00:45 --> Parser Class Initialized
INFO - 2024-04-12 07:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:00:45 --> Pagination Class Initialized
INFO - 2024-04-12 07:00:45 --> Form Validation Class Initialized
INFO - 2024-04-12 07:00:45 --> Controller Class Initialized
INFO - 2024-04-12 07:00:45 --> Model Class Initialized
DEBUG - 2024-04-12 07:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-12 07:00:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:00:45 --> Model Class Initialized
INFO - 2024-04-12 07:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:00:45 --> Final output sent to browser
DEBUG - 2024-04-12 07:00:45 --> Total execution time: 0.0416
ERROR - 2024-04-12 07:00:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:00:56 --> Config Class Initialized
INFO - 2024-04-12 07:00:56 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:00:56 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:00:56 --> Utf8 Class Initialized
INFO - 2024-04-12 07:00:56 --> URI Class Initialized
INFO - 2024-04-12 07:00:56 --> Router Class Initialized
INFO - 2024-04-12 07:00:56 --> Output Class Initialized
INFO - 2024-04-12 07:00:56 --> Security Class Initialized
DEBUG - 2024-04-12 07:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:00:56 --> Input Class Initialized
INFO - 2024-04-12 07:00:56 --> Language Class Initialized
INFO - 2024-04-12 07:00:56 --> Loader Class Initialized
INFO - 2024-04-12 07:00:56 --> Helper loaded: url_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: file_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: html_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: text_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: form_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: security_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:00:56 --> Database Driver Class Initialized
INFO - 2024-04-12 07:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:00:56 --> Parser Class Initialized
INFO - 2024-04-12 07:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:00:56 --> Pagination Class Initialized
INFO - 2024-04-12 07:00:56 --> Form Validation Class Initialized
INFO - 2024-04-12 07:00:56 --> Controller Class Initialized
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
DEBUG - 2024-04-12 07:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
INFO - 2024-04-12 07:00:56 --> Final output sent to browser
DEBUG - 2024-04-12 07:00:56 --> Total execution time: 0.0185
ERROR - 2024-04-12 07:00:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:00:56 --> Config Class Initialized
INFO - 2024-04-12 07:00:56 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:00:56 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:00:56 --> Utf8 Class Initialized
INFO - 2024-04-12 07:00:56 --> URI Class Initialized
DEBUG - 2024-04-12 07:00:56 --> No URI present. Default controller set.
INFO - 2024-04-12 07:00:56 --> Router Class Initialized
INFO - 2024-04-12 07:00:56 --> Output Class Initialized
INFO - 2024-04-12 07:00:56 --> Security Class Initialized
DEBUG - 2024-04-12 07:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:00:56 --> Input Class Initialized
INFO - 2024-04-12 07:00:56 --> Language Class Initialized
INFO - 2024-04-12 07:00:56 --> Loader Class Initialized
INFO - 2024-04-12 07:00:56 --> Helper loaded: url_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: file_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: html_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: text_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: form_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: security_helper
INFO - 2024-04-12 07:00:56 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:00:56 --> Database Driver Class Initialized
INFO - 2024-04-12 07:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:00:56 --> Parser Class Initialized
INFO - 2024-04-12 07:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:00:56 --> Pagination Class Initialized
INFO - 2024-04-12 07:00:56 --> Form Validation Class Initialized
INFO - 2024-04-12 07:00:56 --> Controller Class Initialized
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
DEBUG - 2024-04-12 07:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
DEBUG - 2024-04-12 07:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
DEBUG - 2024-04-12 07:00:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
INFO - 2024-04-12 07:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-12 07:00:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:00:56 --> Model Class Initialized
INFO - 2024-04-12 07:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:00:56 --> Final output sent to browser
DEBUG - 2024-04-12 07:00:56 --> Total execution time: 0.3872
ERROR - 2024-04-12 07:01:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:02 --> Config Class Initialized
INFO - 2024-04-12 07:01:02 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:02 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:02 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:02 --> URI Class Initialized
INFO - 2024-04-12 07:01:02 --> Router Class Initialized
INFO - 2024-04-12 07:01:02 --> Output Class Initialized
INFO - 2024-04-12 07:01:02 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:02 --> Input Class Initialized
INFO - 2024-04-12 07:01:02 --> Language Class Initialized
INFO - 2024-04-12 07:01:02 --> Loader Class Initialized
INFO - 2024-04-12 07:01:02 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:02 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:02 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:02 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:02 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:02 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:02 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:02 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:02 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:02 --> Parser Class Initialized
INFO - 2024-04-12 07:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:02 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:02 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:02 --> Controller Class Initialized
INFO - 2024-04-12 07:01:02 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:02 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:02 --> Model Class Initialized
INFO - 2024-04-12 07:01:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-04-12 07:01:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:01:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:01:02 --> Model Class Initialized
INFO - 2024-04-12 07:01:02 --> Model Class Initialized
INFO - 2024-04-12 07:01:02 --> Model Class Initialized
INFO - 2024-04-12 07:01:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:01:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:01:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:01:02 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:02 --> Total execution time: 0.2597
ERROR - 2024-04-12 07:01:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:07 --> Config Class Initialized
INFO - 2024-04-12 07:01:07 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:07 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:07 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:07 --> URI Class Initialized
INFO - 2024-04-12 07:01:07 --> Router Class Initialized
INFO - 2024-04-12 07:01:07 --> Output Class Initialized
INFO - 2024-04-12 07:01:07 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:07 --> Input Class Initialized
INFO - 2024-04-12 07:01:07 --> Language Class Initialized
INFO - 2024-04-12 07:01:07 --> Loader Class Initialized
INFO - 2024-04-12 07:01:07 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:07 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:07 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:07 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:07 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:07 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:07 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:07 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:07 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:07 --> Parser Class Initialized
INFO - 2024-04-12 07:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:07 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:07 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:07 --> Controller Class Initialized
INFO - 2024-04-12 07:01:07 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:07 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:07 --> Total execution time: 0.0274
ERROR - 2024-04-12 07:01:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:08 --> Config Class Initialized
INFO - 2024-04-12 07:01:08 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:08 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:08 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:08 --> URI Class Initialized
INFO - 2024-04-12 07:01:08 --> Router Class Initialized
INFO - 2024-04-12 07:01:08 --> Output Class Initialized
INFO - 2024-04-12 07:01:08 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:08 --> Input Class Initialized
INFO - 2024-04-12 07:01:08 --> Language Class Initialized
INFO - 2024-04-12 07:01:08 --> Loader Class Initialized
INFO - 2024-04-12 07:01:08 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:08 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:08 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:08 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:08 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:08 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:08 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:08 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:08 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:08 --> Parser Class Initialized
INFO - 2024-04-12 07:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:08 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:08 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:08 --> Controller Class Initialized
INFO - 2024-04-12 07:01:08 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:08 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:08 --> Total execution time: 0.0153
ERROR - 2024-04-12 07:01:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:12 --> Config Class Initialized
INFO - 2024-04-12 07:01:12 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:12 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:12 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:12 --> URI Class Initialized
INFO - 2024-04-12 07:01:12 --> Router Class Initialized
INFO - 2024-04-12 07:01:12 --> Output Class Initialized
INFO - 2024-04-12 07:01:12 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:12 --> Input Class Initialized
INFO - 2024-04-12 07:01:12 --> Language Class Initialized
INFO - 2024-04-12 07:01:12 --> Loader Class Initialized
INFO - 2024-04-12 07:01:12 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:12 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:12 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:12 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:12 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:12 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:12 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:12 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:12 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:12 --> Parser Class Initialized
INFO - 2024-04-12 07:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:12 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:12 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:12 --> Controller Class Initialized
INFO - 2024-04-12 07:01:12 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:12 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:12 --> Total execution time: 0.0148
ERROR - 2024-04-12 07:01:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:17 --> Config Class Initialized
INFO - 2024-04-12 07:01:17 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:17 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:17 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:17 --> URI Class Initialized
INFO - 2024-04-12 07:01:17 --> Router Class Initialized
INFO - 2024-04-12 07:01:17 --> Output Class Initialized
INFO - 2024-04-12 07:01:17 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:17 --> Input Class Initialized
INFO - 2024-04-12 07:01:17 --> Language Class Initialized
INFO - 2024-04-12 07:01:17 --> Loader Class Initialized
INFO - 2024-04-12 07:01:17 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:17 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:17 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:17 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:17 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:17 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:17 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:17 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:17 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:17 --> Parser Class Initialized
INFO - 2024-04-12 07:01:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:17 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:17 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:17 --> Controller Class Initialized
INFO - 2024-04-12 07:01:17 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:17 --> Total execution time: 0.0132
ERROR - 2024-04-12 07:01:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:23 --> Config Class Initialized
INFO - 2024-04-12 07:01:23 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:23 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:23 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:23 --> URI Class Initialized
INFO - 2024-04-12 07:01:23 --> Router Class Initialized
INFO - 2024-04-12 07:01:23 --> Output Class Initialized
INFO - 2024-04-12 07:01:23 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:23 --> Input Class Initialized
INFO - 2024-04-12 07:01:23 --> Language Class Initialized
INFO - 2024-04-12 07:01:23 --> Loader Class Initialized
INFO - 2024-04-12 07:01:23 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:23 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:23 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:23 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:23 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:23 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:23 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:23 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:23 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:23 --> Parser Class Initialized
INFO - 2024-04-12 07:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:23 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:23 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:23 --> Controller Class Initialized
INFO - 2024-04-12 07:01:23 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:23 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:23 --> Model Class Initialized
INFO - 2024-04-12 07:01:23 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:23 --> Total execution time: 0.1565
ERROR - 2024-04-12 07:01:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:24 --> Config Class Initialized
INFO - 2024-04-12 07:01:24 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:24 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:24 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:24 --> URI Class Initialized
INFO - 2024-04-12 07:01:24 --> Router Class Initialized
INFO - 2024-04-12 07:01:24 --> Output Class Initialized
INFO - 2024-04-12 07:01:24 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:24 --> Input Class Initialized
INFO - 2024-04-12 07:01:24 --> Language Class Initialized
INFO - 2024-04-12 07:01:24 --> Loader Class Initialized
INFO - 2024-04-12 07:01:24 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:24 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:24 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:24 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:24 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:24 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:24 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:24 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:24 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:24 --> Parser Class Initialized
INFO - 2024-04-12 07:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:24 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:24 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:24 --> Controller Class Initialized
INFO - 2024-04-12 07:01:24 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:24 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:24 --> Model Class Initialized
INFO - 2024-04-12 07:01:24 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:24 --> Total execution time: 0.1524
ERROR - 2024-04-12 07:01:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:26 --> Config Class Initialized
INFO - 2024-04-12 07:01:26 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:26 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:26 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:26 --> URI Class Initialized
INFO - 2024-04-12 07:01:26 --> Router Class Initialized
INFO - 2024-04-12 07:01:26 --> Output Class Initialized
INFO - 2024-04-12 07:01:26 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:26 --> Input Class Initialized
INFO - 2024-04-12 07:01:26 --> Language Class Initialized
INFO - 2024-04-12 07:01:26 --> Loader Class Initialized
INFO - 2024-04-12 07:01:26 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:26 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:26 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:26 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:26 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:26 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:26 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:26 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:26 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:26 --> Parser Class Initialized
INFO - 2024-04-12 07:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:26 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:26 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:26 --> Controller Class Initialized
INFO - 2024-04-12 07:01:26 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:26 --> Model Class Initialized
INFO - 2024-04-12 07:01:26 --> Model Class Initialized
INFO - 2024-04-12 07:01:26 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:26 --> Total execution time: 0.0248
ERROR - 2024-04-12 07:01:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:29 --> Config Class Initialized
INFO - 2024-04-12 07:01:29 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:29 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:29 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:29 --> URI Class Initialized
INFO - 2024-04-12 07:01:29 --> Router Class Initialized
INFO - 2024-04-12 07:01:29 --> Output Class Initialized
INFO - 2024-04-12 07:01:29 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:29 --> Input Class Initialized
INFO - 2024-04-12 07:01:29 --> Language Class Initialized
INFO - 2024-04-12 07:01:29 --> Loader Class Initialized
INFO - 2024-04-12 07:01:29 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:29 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:29 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:29 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:29 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:29 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:29 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:29 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:29 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:29 --> Parser Class Initialized
INFO - 2024-04-12 07:01:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:29 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:29 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:29 --> Controller Class Initialized
INFO - 2024-04-12 07:01:29 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:29 --> Model Class Initialized
INFO - 2024-04-12 07:01:29 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:29 --> Total execution time: 0.0212
ERROR - 2024-04-12 07:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:45 --> Config Class Initialized
INFO - 2024-04-12 07:01:45 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:45 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:45 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:45 --> URI Class Initialized
INFO - 2024-04-12 07:01:45 --> Router Class Initialized
INFO - 2024-04-12 07:01:45 --> Output Class Initialized
INFO - 2024-04-12 07:01:45 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:45 --> Input Class Initialized
INFO - 2024-04-12 07:01:45 --> Language Class Initialized
INFO - 2024-04-12 07:01:45 --> Loader Class Initialized
INFO - 2024-04-12 07:01:45 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:45 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:45 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:45 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:45 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:45 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:45 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:45 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:45 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:45 --> Parser Class Initialized
INFO - 2024-04-12 07:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:45 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:45 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:45 --> Controller Class Initialized
INFO - 2024-04-12 07:01:45 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:45 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:45 --> Model Class Initialized
INFO - 2024-04-12 07:01:46 --> Email Class Initialized
DEBUG - 2024-04-12 07:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-04-12 07:01:46 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-04-12 07:01:46 --> Language file loaded: language/english/email_lang.php
INFO - 2024-04-12 07:01:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-04-12 07:01:46 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:46 --> Total execution time: 0.2642
ERROR - 2024-04-12 07:01:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:01:48 --> Config Class Initialized
INFO - 2024-04-12 07:01:48 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:01:48 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:01:48 --> Utf8 Class Initialized
INFO - 2024-04-12 07:01:48 --> URI Class Initialized
INFO - 2024-04-12 07:01:48 --> Router Class Initialized
INFO - 2024-04-12 07:01:48 --> Output Class Initialized
INFO - 2024-04-12 07:01:48 --> Security Class Initialized
DEBUG - 2024-04-12 07:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:01:48 --> Input Class Initialized
INFO - 2024-04-12 07:01:48 --> Language Class Initialized
INFO - 2024-04-12 07:01:48 --> Loader Class Initialized
INFO - 2024-04-12 07:01:48 --> Helper loaded: url_helper
INFO - 2024-04-12 07:01:48 --> Helper loaded: file_helper
INFO - 2024-04-12 07:01:48 --> Helper loaded: html_helper
INFO - 2024-04-12 07:01:48 --> Helper loaded: text_helper
INFO - 2024-04-12 07:01:48 --> Helper loaded: form_helper
INFO - 2024-04-12 07:01:48 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:01:48 --> Helper loaded: security_helper
INFO - 2024-04-12 07:01:48 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:01:48 --> Database Driver Class Initialized
INFO - 2024-04-12 07:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:01:48 --> Parser Class Initialized
INFO - 2024-04-12 07:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:01:48 --> Pagination Class Initialized
INFO - 2024-04-12 07:01:48 --> Form Validation Class Initialized
INFO - 2024-04-12 07:01:48 --> Controller Class Initialized
INFO - 2024-04-12 07:01:48 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:48 --> Model Class Initialized
DEBUG - 2024-04-12 07:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:48 --> Model Class Initialized
INFO - 2024-04-12 07:01:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-04-12 07:01:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:01:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:01:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:01:49 --> Model Class Initialized
INFO - 2024-04-12 07:01:49 --> Model Class Initialized
INFO - 2024-04-12 07:01:49 --> Model Class Initialized
INFO - 2024-04-12 07:01:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:01:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:01:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:01:49 --> Final output sent to browser
DEBUG - 2024-04-12 07:01:49 --> Total execution time: 0.2557
ERROR - 2024-04-12 07:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:12:26 --> Config Class Initialized
INFO - 2024-04-12 07:12:26 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:12:26 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:12:26 --> Utf8 Class Initialized
INFO - 2024-04-12 07:12:26 --> URI Class Initialized
DEBUG - 2024-04-12 07:12:26 --> No URI present. Default controller set.
INFO - 2024-04-12 07:12:26 --> Router Class Initialized
INFO - 2024-04-12 07:12:26 --> Output Class Initialized
INFO - 2024-04-12 07:12:26 --> Security Class Initialized
DEBUG - 2024-04-12 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:12:26 --> Input Class Initialized
INFO - 2024-04-12 07:12:26 --> Language Class Initialized
INFO - 2024-04-12 07:12:26 --> Loader Class Initialized
INFO - 2024-04-12 07:12:26 --> Helper loaded: url_helper
INFO - 2024-04-12 07:12:26 --> Helper loaded: file_helper
INFO - 2024-04-12 07:12:26 --> Helper loaded: html_helper
INFO - 2024-04-12 07:12:26 --> Helper loaded: text_helper
INFO - 2024-04-12 07:12:26 --> Helper loaded: form_helper
INFO - 2024-04-12 07:12:26 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:12:26 --> Helper loaded: security_helper
INFO - 2024-04-12 07:12:26 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:12:26 --> Database Driver Class Initialized
INFO - 2024-04-12 07:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:12:26 --> Parser Class Initialized
INFO - 2024-04-12 07:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:12:26 --> Pagination Class Initialized
INFO - 2024-04-12 07:12:26 --> Form Validation Class Initialized
INFO - 2024-04-12 07:12:26 --> Controller Class Initialized
INFO - 2024-04-12 07:12:26 --> Model Class Initialized
DEBUG - 2024-04-12 07:12:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-12 07:12:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:12:27 --> Config Class Initialized
INFO - 2024-04-12 07:12:27 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:12:27 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:12:27 --> Utf8 Class Initialized
INFO - 2024-04-12 07:12:27 --> URI Class Initialized
INFO - 2024-04-12 07:12:27 --> Router Class Initialized
INFO - 2024-04-12 07:12:27 --> Output Class Initialized
INFO - 2024-04-12 07:12:27 --> Security Class Initialized
DEBUG - 2024-04-12 07:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:12:27 --> Input Class Initialized
INFO - 2024-04-12 07:12:27 --> Language Class Initialized
INFO - 2024-04-12 07:12:27 --> Loader Class Initialized
INFO - 2024-04-12 07:12:27 --> Helper loaded: url_helper
INFO - 2024-04-12 07:12:27 --> Helper loaded: file_helper
INFO - 2024-04-12 07:12:27 --> Helper loaded: html_helper
INFO - 2024-04-12 07:12:27 --> Helper loaded: text_helper
INFO - 2024-04-12 07:12:27 --> Helper loaded: form_helper
INFO - 2024-04-12 07:12:27 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:12:27 --> Helper loaded: security_helper
INFO - 2024-04-12 07:12:27 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:12:27 --> Database Driver Class Initialized
INFO - 2024-04-12 07:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:12:27 --> Parser Class Initialized
INFO - 2024-04-12 07:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:12:27 --> Pagination Class Initialized
INFO - 2024-04-12 07:12:27 --> Form Validation Class Initialized
INFO - 2024-04-12 07:12:27 --> Controller Class Initialized
INFO - 2024-04-12 07:12:27 --> Model Class Initialized
DEBUG - 2024-04-12 07:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-12 07:12:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:12:27 --> Model Class Initialized
INFO - 2024-04-12 07:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:12:27 --> Final output sent to browser
DEBUG - 2024-04-12 07:12:27 --> Total execution time: 0.0315
ERROR - 2024-04-12 07:42:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:42:46 --> Config Class Initialized
INFO - 2024-04-12 07:42:46 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:42:46 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:42:46 --> Utf8 Class Initialized
INFO - 2024-04-12 07:42:46 --> URI Class Initialized
DEBUG - 2024-04-12 07:42:46 --> No URI present. Default controller set.
INFO - 2024-04-12 07:42:46 --> Router Class Initialized
INFO - 2024-04-12 07:42:46 --> Output Class Initialized
INFO - 2024-04-12 07:42:46 --> Security Class Initialized
DEBUG - 2024-04-12 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:42:46 --> Input Class Initialized
INFO - 2024-04-12 07:42:46 --> Language Class Initialized
INFO - 2024-04-12 07:42:46 --> Loader Class Initialized
INFO - 2024-04-12 07:42:46 --> Helper loaded: url_helper
INFO - 2024-04-12 07:42:46 --> Helper loaded: file_helper
INFO - 2024-04-12 07:42:46 --> Helper loaded: html_helper
INFO - 2024-04-12 07:42:46 --> Helper loaded: text_helper
INFO - 2024-04-12 07:42:46 --> Helper loaded: form_helper
INFO - 2024-04-12 07:42:46 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:42:46 --> Helper loaded: security_helper
INFO - 2024-04-12 07:42:46 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:42:46 --> Database Driver Class Initialized
INFO - 2024-04-12 07:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:42:46 --> Parser Class Initialized
INFO - 2024-04-12 07:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:42:46 --> Pagination Class Initialized
INFO - 2024-04-12 07:42:46 --> Form Validation Class Initialized
INFO - 2024-04-12 07:42:46 --> Controller Class Initialized
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
INFO - 2024-04-12 07:42:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-12 07:42:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:42:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:42:46 --> Model Class Initialized
INFO - 2024-04-12 07:42:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:42:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:42:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:42:46 --> Final output sent to browser
DEBUG - 2024-04-12 07:42:46 --> Total execution time: 0.3666
ERROR - 2024-04-12 07:42:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:42:50 --> Config Class Initialized
INFO - 2024-04-12 07:42:50 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:42:50 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:42:50 --> Utf8 Class Initialized
INFO - 2024-04-12 07:42:50 --> URI Class Initialized
INFO - 2024-04-12 07:42:50 --> Router Class Initialized
INFO - 2024-04-12 07:42:50 --> Output Class Initialized
INFO - 2024-04-12 07:42:50 --> Security Class Initialized
DEBUG - 2024-04-12 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:42:50 --> Input Class Initialized
INFO - 2024-04-12 07:42:50 --> Language Class Initialized
INFO - 2024-04-12 07:42:50 --> Loader Class Initialized
INFO - 2024-04-12 07:42:50 --> Helper loaded: url_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: file_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: html_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: text_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: form_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: security_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:42:50 --> Database Driver Class Initialized
INFO - 2024-04-12 07:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:42:50 --> Parser Class Initialized
INFO - 2024-04-12 07:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:42:50 --> Pagination Class Initialized
INFO - 2024-04-12 07:42:50 --> Form Validation Class Initialized
INFO - 2024-04-12 07:42:50 --> Controller Class Initialized
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
INFO - 2024-04-12 07:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-12 07:42:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
INFO - 2024-04-12 07:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:42:50 --> Final output sent to browser
DEBUG - 2024-04-12 07:42:50 --> Total execution time: 0.2194
ERROR - 2024-04-12 07:42:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:42:50 --> Config Class Initialized
INFO - 2024-04-12 07:42:50 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:42:50 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:42:50 --> Utf8 Class Initialized
INFO - 2024-04-12 07:42:50 --> URI Class Initialized
INFO - 2024-04-12 07:42:50 --> Router Class Initialized
INFO - 2024-04-12 07:42:50 --> Output Class Initialized
INFO - 2024-04-12 07:42:50 --> Security Class Initialized
DEBUG - 2024-04-12 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:42:50 --> Input Class Initialized
INFO - 2024-04-12 07:42:50 --> Language Class Initialized
INFO - 2024-04-12 07:42:50 --> Loader Class Initialized
INFO - 2024-04-12 07:42:50 --> Helper loaded: url_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: file_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: html_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: text_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: form_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: security_helper
INFO - 2024-04-12 07:42:50 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:42:50 --> Database Driver Class Initialized
INFO - 2024-04-12 07:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:42:50 --> Parser Class Initialized
INFO - 2024-04-12 07:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:42:50 --> Pagination Class Initialized
INFO - 2024-04-12 07:42:50 --> Form Validation Class Initialized
INFO - 2024-04-12 07:42:50 --> Controller Class Initialized
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:50 --> Model Class Initialized
INFO - 2024-04-12 07:42:51 --> Final output sent to browser
DEBUG - 2024-04-12 07:42:51 --> Total execution time: 0.0437
ERROR - 2024-04-12 07:42:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:42:55 --> Config Class Initialized
INFO - 2024-04-12 07:42:55 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:42:55 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:42:55 --> Utf8 Class Initialized
INFO - 2024-04-12 07:42:55 --> URI Class Initialized
INFO - 2024-04-12 07:42:55 --> Router Class Initialized
INFO - 2024-04-12 07:42:55 --> Output Class Initialized
INFO - 2024-04-12 07:42:55 --> Security Class Initialized
DEBUG - 2024-04-12 07:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:42:55 --> Input Class Initialized
INFO - 2024-04-12 07:42:55 --> Language Class Initialized
INFO - 2024-04-12 07:42:55 --> Loader Class Initialized
INFO - 2024-04-12 07:42:55 --> Helper loaded: url_helper
INFO - 2024-04-12 07:42:55 --> Helper loaded: file_helper
INFO - 2024-04-12 07:42:55 --> Helper loaded: html_helper
INFO - 2024-04-12 07:42:55 --> Helper loaded: text_helper
INFO - 2024-04-12 07:42:55 --> Helper loaded: form_helper
INFO - 2024-04-12 07:42:55 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:42:55 --> Helper loaded: security_helper
INFO - 2024-04-12 07:42:55 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:42:55 --> Database Driver Class Initialized
INFO - 2024-04-12 07:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:42:55 --> Parser Class Initialized
INFO - 2024-04-12 07:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:42:55 --> Pagination Class Initialized
INFO - 2024-04-12 07:42:55 --> Form Validation Class Initialized
INFO - 2024-04-12 07:42:55 --> Controller Class Initialized
INFO - 2024-04-12 07:42:55 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:55 --> Model Class Initialized
DEBUG - 2024-04-12 07:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:42:55 --> Model Class Initialized
INFO - 2024-04-12 07:42:55 --> Final output sent to browser
DEBUG - 2024-04-12 07:42:55 --> Total execution time: 0.2005
ERROR - 2024-04-12 07:43:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:43:26 --> Config Class Initialized
INFO - 2024-04-12 07:43:26 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:43:26 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:43:26 --> Utf8 Class Initialized
INFO - 2024-04-12 07:43:26 --> URI Class Initialized
DEBUG - 2024-04-12 07:43:26 --> No URI present. Default controller set.
INFO - 2024-04-12 07:43:26 --> Router Class Initialized
INFO - 2024-04-12 07:43:26 --> Output Class Initialized
INFO - 2024-04-12 07:43:26 --> Security Class Initialized
DEBUG - 2024-04-12 07:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:43:26 --> Input Class Initialized
INFO - 2024-04-12 07:43:26 --> Language Class Initialized
INFO - 2024-04-12 07:43:26 --> Loader Class Initialized
INFO - 2024-04-12 07:43:26 --> Helper loaded: url_helper
INFO - 2024-04-12 07:43:26 --> Helper loaded: file_helper
INFO - 2024-04-12 07:43:26 --> Helper loaded: html_helper
INFO - 2024-04-12 07:43:26 --> Helper loaded: text_helper
INFO - 2024-04-12 07:43:26 --> Helper loaded: form_helper
INFO - 2024-04-12 07:43:26 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:43:26 --> Helper loaded: security_helper
INFO - 2024-04-12 07:43:26 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:43:26 --> Database Driver Class Initialized
INFO - 2024-04-12 07:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:43:26 --> Parser Class Initialized
INFO - 2024-04-12 07:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:43:26 --> Pagination Class Initialized
INFO - 2024-04-12 07:43:26 --> Form Validation Class Initialized
INFO - 2024-04-12 07:43:26 --> Controller Class Initialized
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
INFO - 2024-04-12 07:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-12 07:43:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:43:26 --> Model Class Initialized
INFO - 2024-04-12 07:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:43:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:43:26 --> Final output sent to browser
DEBUG - 2024-04-12 07:43:26 --> Total execution time: 0.3884
ERROR - 2024-04-12 07:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:43:30 --> Config Class Initialized
INFO - 2024-04-12 07:43:30 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:43:30 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:43:30 --> Utf8 Class Initialized
INFO - 2024-04-12 07:43:30 --> URI Class Initialized
INFO - 2024-04-12 07:43:30 --> Router Class Initialized
INFO - 2024-04-12 07:43:30 --> Output Class Initialized
INFO - 2024-04-12 07:43:30 --> Security Class Initialized
DEBUG - 2024-04-12 07:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:43:30 --> Input Class Initialized
INFO - 2024-04-12 07:43:30 --> Language Class Initialized
INFO - 2024-04-12 07:43:30 --> Loader Class Initialized
INFO - 2024-04-12 07:43:30 --> Helper loaded: url_helper
INFO - 2024-04-12 07:43:30 --> Helper loaded: file_helper
INFO - 2024-04-12 07:43:30 --> Helper loaded: html_helper
INFO - 2024-04-12 07:43:30 --> Helper loaded: text_helper
INFO - 2024-04-12 07:43:30 --> Helper loaded: form_helper
INFO - 2024-04-12 07:43:30 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:43:30 --> Helper loaded: security_helper
INFO - 2024-04-12 07:43:30 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:43:30 --> Database Driver Class Initialized
INFO - 2024-04-12 07:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:43:30 --> Parser Class Initialized
INFO - 2024-04-12 07:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:43:30 --> Pagination Class Initialized
INFO - 2024-04-12 07:43:30 --> Form Validation Class Initialized
INFO - 2024-04-12 07:43:30 --> Controller Class Initialized
INFO - 2024-04-12 07:43:30 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:30 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:30 --> Model Class Initialized
INFO - 2024-04-12 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-04-12 07:43:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:43:30 --> Model Class Initialized
INFO - 2024-04-12 07:43:30 --> Model Class Initialized
INFO - 2024-04-12 07:43:30 --> Model Class Initialized
INFO - 2024-04-12 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:43:30 --> Final output sent to browser
DEBUG - 2024-04-12 07:43:30 --> Total execution time: 0.2446
ERROR - 2024-04-12 07:43:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:43:31 --> Config Class Initialized
INFO - 2024-04-12 07:43:31 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:43:31 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:43:31 --> Utf8 Class Initialized
INFO - 2024-04-12 07:43:31 --> URI Class Initialized
INFO - 2024-04-12 07:43:31 --> Router Class Initialized
INFO - 2024-04-12 07:43:31 --> Output Class Initialized
INFO - 2024-04-12 07:43:31 --> Security Class Initialized
DEBUG - 2024-04-12 07:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:43:31 --> Input Class Initialized
INFO - 2024-04-12 07:43:31 --> Language Class Initialized
INFO - 2024-04-12 07:43:31 --> Loader Class Initialized
INFO - 2024-04-12 07:43:31 --> Helper loaded: url_helper
INFO - 2024-04-12 07:43:31 --> Helper loaded: file_helper
INFO - 2024-04-12 07:43:31 --> Helper loaded: html_helper
INFO - 2024-04-12 07:43:31 --> Helper loaded: text_helper
INFO - 2024-04-12 07:43:31 --> Helper loaded: form_helper
INFO - 2024-04-12 07:43:31 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:43:31 --> Helper loaded: security_helper
INFO - 2024-04-12 07:43:31 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:43:31 --> Database Driver Class Initialized
INFO - 2024-04-12 07:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:43:31 --> Parser Class Initialized
INFO - 2024-04-12 07:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:43:31 --> Pagination Class Initialized
INFO - 2024-04-12 07:43:31 --> Form Validation Class Initialized
INFO - 2024-04-12 07:43:31 --> Controller Class Initialized
INFO - 2024-04-12 07:43:31 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:31 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:31 --> Model Class Initialized
INFO - 2024-04-12 07:43:31 --> Final output sent to browser
DEBUG - 2024-04-12 07:43:31 --> Total execution time: 0.0424
ERROR - 2024-04-12 07:43:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:43:36 --> Config Class Initialized
INFO - 2024-04-12 07:43:36 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:43:36 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:43:36 --> Utf8 Class Initialized
INFO - 2024-04-12 07:43:36 --> URI Class Initialized
INFO - 2024-04-12 07:43:36 --> Router Class Initialized
INFO - 2024-04-12 07:43:36 --> Output Class Initialized
INFO - 2024-04-12 07:43:36 --> Security Class Initialized
DEBUG - 2024-04-12 07:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:43:36 --> Input Class Initialized
INFO - 2024-04-12 07:43:36 --> Language Class Initialized
INFO - 2024-04-12 07:43:36 --> Loader Class Initialized
INFO - 2024-04-12 07:43:36 --> Helper loaded: url_helper
INFO - 2024-04-12 07:43:36 --> Helper loaded: file_helper
INFO - 2024-04-12 07:43:36 --> Helper loaded: html_helper
INFO - 2024-04-12 07:43:36 --> Helper loaded: text_helper
INFO - 2024-04-12 07:43:36 --> Helper loaded: form_helper
INFO - 2024-04-12 07:43:36 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:43:36 --> Helper loaded: security_helper
INFO - 2024-04-12 07:43:36 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:43:36 --> Database Driver Class Initialized
INFO - 2024-04-12 07:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:43:36 --> Parser Class Initialized
INFO - 2024-04-12 07:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:43:36 --> Pagination Class Initialized
INFO - 2024-04-12 07:43:36 --> Form Validation Class Initialized
INFO - 2024-04-12 07:43:36 --> Controller Class Initialized
INFO - 2024-04-12 07:43:36 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:36 --> Model Class Initialized
DEBUG - 2024-04-12 07:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:43:36 --> Model Class Initialized
INFO - 2024-04-12 07:43:36 --> Final output sent to browser
DEBUG - 2024-04-12 07:43:36 --> Total execution time: 0.2206
ERROR - 2024-04-12 07:46:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 07:46:00 --> Config Class Initialized
INFO - 2024-04-12 07:46:00 --> Hooks Class Initialized
DEBUG - 2024-04-12 07:46:00 --> UTF-8 Support Enabled
INFO - 2024-04-12 07:46:00 --> Utf8 Class Initialized
INFO - 2024-04-12 07:46:00 --> URI Class Initialized
DEBUG - 2024-04-12 07:46:00 --> No URI present. Default controller set.
INFO - 2024-04-12 07:46:00 --> Router Class Initialized
INFO - 2024-04-12 07:46:00 --> Output Class Initialized
INFO - 2024-04-12 07:46:00 --> Security Class Initialized
DEBUG - 2024-04-12 07:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 07:46:00 --> Input Class Initialized
INFO - 2024-04-12 07:46:00 --> Language Class Initialized
INFO - 2024-04-12 07:46:00 --> Loader Class Initialized
INFO - 2024-04-12 07:46:00 --> Helper loaded: url_helper
INFO - 2024-04-12 07:46:00 --> Helper loaded: file_helper
INFO - 2024-04-12 07:46:00 --> Helper loaded: html_helper
INFO - 2024-04-12 07:46:00 --> Helper loaded: text_helper
INFO - 2024-04-12 07:46:00 --> Helper loaded: form_helper
INFO - 2024-04-12 07:46:00 --> Helper loaded: lang_helper
INFO - 2024-04-12 07:46:00 --> Helper loaded: security_helper
INFO - 2024-04-12 07:46:00 --> Helper loaded: cookie_helper
INFO - 2024-04-12 07:46:00 --> Database Driver Class Initialized
INFO - 2024-04-12 07:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 07:46:00 --> Parser Class Initialized
INFO - 2024-04-12 07:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 07:46:00 --> Pagination Class Initialized
INFO - 2024-04-12 07:46:00 --> Form Validation Class Initialized
INFO - 2024-04-12 07:46:00 --> Controller Class Initialized
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
DEBUG - 2024-04-12 07:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
DEBUG - 2024-04-12 07:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
DEBUG - 2024-04-12 07:46:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 07:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
INFO - 2024-04-12 07:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-12 07:46:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 07:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 07:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 07:46:00 --> Model Class Initialized
INFO - 2024-04-12 07:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 07:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 07:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 07:46:00 --> Final output sent to browser
DEBUG - 2024-04-12 07:46:00 --> Total execution time: 0.3645
ERROR - 2024-04-12 12:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 12:37:24 --> Config Class Initialized
INFO - 2024-04-12 12:37:24 --> Hooks Class Initialized
DEBUG - 2024-04-12 12:37:24 --> UTF-8 Support Enabled
INFO - 2024-04-12 12:37:24 --> Utf8 Class Initialized
INFO - 2024-04-12 12:37:24 --> URI Class Initialized
INFO - 2024-04-12 12:37:24 --> Router Class Initialized
INFO - 2024-04-12 12:37:24 --> Output Class Initialized
INFO - 2024-04-12 12:37:24 --> Security Class Initialized
DEBUG - 2024-04-12 12:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 12:37:24 --> Input Class Initialized
INFO - 2024-04-12 12:37:24 --> Language Class Initialized
ERROR - 2024-04-12 12:37:24 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-12 15:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 15:11:52 --> Config Class Initialized
INFO - 2024-04-12 15:11:52 --> Hooks Class Initialized
DEBUG - 2024-04-12 15:11:52 --> UTF-8 Support Enabled
INFO - 2024-04-12 15:11:52 --> Utf8 Class Initialized
INFO - 2024-04-12 15:11:52 --> URI Class Initialized
DEBUG - 2024-04-12 15:11:52 --> No URI present. Default controller set.
INFO - 2024-04-12 15:11:52 --> Router Class Initialized
INFO - 2024-04-12 15:11:52 --> Output Class Initialized
INFO - 2024-04-12 15:11:52 --> Security Class Initialized
DEBUG - 2024-04-12 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 15:11:52 --> Input Class Initialized
INFO - 2024-04-12 15:11:52 --> Language Class Initialized
INFO - 2024-04-12 15:11:52 --> Loader Class Initialized
INFO - 2024-04-12 15:11:52 --> Helper loaded: url_helper
INFO - 2024-04-12 15:11:52 --> Helper loaded: file_helper
INFO - 2024-04-12 15:11:52 --> Helper loaded: html_helper
INFO - 2024-04-12 15:11:52 --> Helper loaded: text_helper
INFO - 2024-04-12 15:11:52 --> Helper loaded: form_helper
INFO - 2024-04-12 15:11:52 --> Helper loaded: lang_helper
INFO - 2024-04-12 15:11:52 --> Helper loaded: security_helper
INFO - 2024-04-12 15:11:52 --> Helper loaded: cookie_helper
INFO - 2024-04-12 15:11:52 --> Database Driver Class Initialized
INFO - 2024-04-12 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 15:11:52 --> Parser Class Initialized
INFO - 2024-04-12 15:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 15:11:52 --> Pagination Class Initialized
INFO - 2024-04-12 15:11:52 --> Form Validation Class Initialized
INFO - 2024-04-12 15:11:52 --> Controller Class Initialized
INFO - 2024-04-12 15:11:52 --> Model Class Initialized
DEBUG - 2024-04-12 15:11:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-12 15:11:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 15:11:53 --> Config Class Initialized
INFO - 2024-04-12 15:11:53 --> Hooks Class Initialized
DEBUG - 2024-04-12 15:11:53 --> UTF-8 Support Enabled
INFO - 2024-04-12 15:11:53 --> Utf8 Class Initialized
INFO - 2024-04-12 15:11:53 --> URI Class Initialized
INFO - 2024-04-12 15:11:53 --> Router Class Initialized
INFO - 2024-04-12 15:11:53 --> Output Class Initialized
INFO - 2024-04-12 15:11:53 --> Security Class Initialized
DEBUG - 2024-04-12 15:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 15:11:53 --> Input Class Initialized
INFO - 2024-04-12 15:11:53 --> Language Class Initialized
INFO - 2024-04-12 15:11:53 --> Loader Class Initialized
INFO - 2024-04-12 15:11:53 --> Helper loaded: url_helper
INFO - 2024-04-12 15:11:53 --> Helper loaded: file_helper
INFO - 2024-04-12 15:11:53 --> Helper loaded: html_helper
INFO - 2024-04-12 15:11:53 --> Helper loaded: text_helper
INFO - 2024-04-12 15:11:53 --> Helper loaded: form_helper
INFO - 2024-04-12 15:11:53 --> Helper loaded: lang_helper
INFO - 2024-04-12 15:11:53 --> Helper loaded: security_helper
INFO - 2024-04-12 15:11:53 --> Helper loaded: cookie_helper
INFO - 2024-04-12 15:11:53 --> Database Driver Class Initialized
INFO - 2024-04-12 15:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 15:11:53 --> Parser Class Initialized
INFO - 2024-04-12 15:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 15:11:53 --> Pagination Class Initialized
INFO - 2024-04-12 15:11:53 --> Form Validation Class Initialized
INFO - 2024-04-12 15:11:53 --> Controller Class Initialized
INFO - 2024-04-12 15:11:53 --> Model Class Initialized
DEBUG - 2024-04-12 15:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-12 15:11:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 15:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 15:11:53 --> Model Class Initialized
INFO - 2024-04-12 15:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 15:11:53 --> Final output sent to browser
DEBUG - 2024-04-12 15:11:53 --> Total execution time: 0.0367
ERROR - 2024-04-12 15:12:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 15:12:03 --> Config Class Initialized
INFO - 2024-04-12 15:12:03 --> Hooks Class Initialized
DEBUG - 2024-04-12 15:12:03 --> UTF-8 Support Enabled
INFO - 2024-04-12 15:12:03 --> Utf8 Class Initialized
INFO - 2024-04-12 15:12:03 --> URI Class Initialized
INFO - 2024-04-12 15:12:03 --> Router Class Initialized
INFO - 2024-04-12 15:12:03 --> Output Class Initialized
INFO - 2024-04-12 15:12:03 --> Security Class Initialized
DEBUG - 2024-04-12 15:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 15:12:03 --> Input Class Initialized
INFO - 2024-04-12 15:12:03 --> Language Class Initialized
INFO - 2024-04-12 15:12:03 --> Loader Class Initialized
INFO - 2024-04-12 15:12:03 --> Helper loaded: url_helper
INFO - 2024-04-12 15:12:03 --> Helper loaded: file_helper
INFO - 2024-04-12 15:12:03 --> Helper loaded: html_helper
INFO - 2024-04-12 15:12:03 --> Helper loaded: text_helper
INFO - 2024-04-12 15:12:03 --> Helper loaded: form_helper
INFO - 2024-04-12 15:12:03 --> Helper loaded: lang_helper
INFO - 2024-04-12 15:12:03 --> Helper loaded: security_helper
INFO - 2024-04-12 15:12:03 --> Helper loaded: cookie_helper
INFO - 2024-04-12 15:12:03 --> Database Driver Class Initialized
INFO - 2024-04-12 15:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 15:12:03 --> Parser Class Initialized
INFO - 2024-04-12 15:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 15:12:03 --> Pagination Class Initialized
INFO - 2024-04-12 15:12:03 --> Form Validation Class Initialized
INFO - 2024-04-12 15:12:03 --> Controller Class Initialized
INFO - 2024-04-12 15:12:03 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:03 --> Model Class Initialized
INFO - 2024-04-12 15:12:03 --> Final output sent to browser
DEBUG - 2024-04-12 15:12:03 --> Total execution time: 0.0191
ERROR - 2024-04-12 15:12:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 15:12:04 --> Config Class Initialized
INFO - 2024-04-12 15:12:04 --> Hooks Class Initialized
DEBUG - 2024-04-12 15:12:04 --> UTF-8 Support Enabled
INFO - 2024-04-12 15:12:04 --> Utf8 Class Initialized
INFO - 2024-04-12 15:12:04 --> URI Class Initialized
DEBUG - 2024-04-12 15:12:04 --> No URI present. Default controller set.
INFO - 2024-04-12 15:12:04 --> Router Class Initialized
INFO - 2024-04-12 15:12:04 --> Output Class Initialized
INFO - 2024-04-12 15:12:04 --> Security Class Initialized
DEBUG - 2024-04-12 15:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 15:12:04 --> Input Class Initialized
INFO - 2024-04-12 15:12:04 --> Language Class Initialized
INFO - 2024-04-12 15:12:04 --> Loader Class Initialized
INFO - 2024-04-12 15:12:04 --> Helper loaded: url_helper
INFO - 2024-04-12 15:12:04 --> Helper loaded: file_helper
INFO - 2024-04-12 15:12:04 --> Helper loaded: html_helper
INFO - 2024-04-12 15:12:04 --> Helper loaded: text_helper
INFO - 2024-04-12 15:12:04 --> Helper loaded: form_helper
INFO - 2024-04-12 15:12:04 --> Helper loaded: lang_helper
INFO - 2024-04-12 15:12:04 --> Helper loaded: security_helper
INFO - 2024-04-12 15:12:04 --> Helper loaded: cookie_helper
INFO - 2024-04-12 15:12:04 --> Database Driver Class Initialized
INFO - 2024-04-12 15:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 15:12:04 --> Parser Class Initialized
INFO - 2024-04-12 15:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 15:12:04 --> Pagination Class Initialized
INFO - 2024-04-12 15:12:04 --> Form Validation Class Initialized
INFO - 2024-04-12 15:12:04 --> Controller Class Initialized
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 15:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
INFO - 2024-04-12 15:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-12 15:12:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 15:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 15:12:04 --> Model Class Initialized
INFO - 2024-04-12 15:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 15:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 15:12:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 15:12:04 --> Final output sent to browser
DEBUG - 2024-04-12 15:12:04 --> Total execution time: 0.3717
ERROR - 2024-04-12 15:12:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 15:12:39 --> Config Class Initialized
INFO - 2024-04-12 15:12:39 --> Hooks Class Initialized
DEBUG - 2024-04-12 15:12:39 --> UTF-8 Support Enabled
INFO - 2024-04-12 15:12:39 --> Utf8 Class Initialized
INFO - 2024-04-12 15:12:39 --> URI Class Initialized
INFO - 2024-04-12 15:12:39 --> Router Class Initialized
INFO - 2024-04-12 15:12:39 --> Output Class Initialized
INFO - 2024-04-12 15:12:39 --> Security Class Initialized
DEBUG - 2024-04-12 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 15:12:39 --> Input Class Initialized
INFO - 2024-04-12 15:12:39 --> Language Class Initialized
INFO - 2024-04-12 15:12:39 --> Loader Class Initialized
INFO - 2024-04-12 15:12:39 --> Helper loaded: url_helper
INFO - 2024-04-12 15:12:39 --> Helper loaded: file_helper
INFO - 2024-04-12 15:12:39 --> Helper loaded: html_helper
INFO - 2024-04-12 15:12:39 --> Helper loaded: text_helper
INFO - 2024-04-12 15:12:39 --> Helper loaded: form_helper
INFO - 2024-04-12 15:12:39 --> Helper loaded: lang_helper
INFO - 2024-04-12 15:12:39 --> Helper loaded: security_helper
INFO - 2024-04-12 15:12:39 --> Helper loaded: cookie_helper
INFO - 2024-04-12 15:12:39 --> Database Driver Class Initialized
INFO - 2024-04-12 15:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 15:12:39 --> Parser Class Initialized
INFO - 2024-04-12 15:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 15:12:39 --> Pagination Class Initialized
INFO - 2024-04-12 15:12:39 --> Form Validation Class Initialized
INFO - 2024-04-12 15:12:39 --> Controller Class Initialized
INFO - 2024-04-12 15:12:39 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-12 15:12:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 15:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 15:12:39 --> Model Class Initialized
INFO - 2024-04-12 15:12:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 15:12:39 --> Final output sent to browser
DEBUG - 2024-04-12 15:12:39 --> Total execution time: 0.0304
ERROR - 2024-04-12 15:12:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 15:12:40 --> Config Class Initialized
INFO - 2024-04-12 15:12:40 --> Hooks Class Initialized
DEBUG - 2024-04-12 15:12:40 --> UTF-8 Support Enabled
INFO - 2024-04-12 15:12:40 --> Utf8 Class Initialized
INFO - 2024-04-12 15:12:40 --> URI Class Initialized
INFO - 2024-04-12 15:12:40 --> Router Class Initialized
INFO - 2024-04-12 15:12:40 --> Output Class Initialized
INFO - 2024-04-12 15:12:40 --> Security Class Initialized
DEBUG - 2024-04-12 15:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 15:12:40 --> Input Class Initialized
INFO - 2024-04-12 15:12:40 --> Language Class Initialized
INFO - 2024-04-12 15:12:40 --> Loader Class Initialized
INFO - 2024-04-12 15:12:40 --> Helper loaded: url_helper
INFO - 2024-04-12 15:12:40 --> Helper loaded: file_helper
INFO - 2024-04-12 15:12:40 --> Helper loaded: html_helper
INFO - 2024-04-12 15:12:40 --> Helper loaded: text_helper
INFO - 2024-04-12 15:12:40 --> Helper loaded: form_helper
INFO - 2024-04-12 15:12:40 --> Helper loaded: lang_helper
INFO - 2024-04-12 15:12:40 --> Helper loaded: security_helper
INFO - 2024-04-12 15:12:40 --> Helper loaded: cookie_helper
INFO - 2024-04-12 15:12:40 --> Database Driver Class Initialized
INFO - 2024-04-12 15:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 15:12:40 --> Parser Class Initialized
INFO - 2024-04-12 15:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 15:12:40 --> Pagination Class Initialized
INFO - 2024-04-12 15:12:40 --> Form Validation Class Initialized
INFO - 2024-04-12 15:12:40 --> Controller Class Initialized
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
DEBUG - 2024-04-12 15:12:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-04-12 15:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
INFO - 2024-04-12 15:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-04-12 15:12:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 15:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 15:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 15:12:40 --> Model Class Initialized
INFO - 2024-04-12 15:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-04-12 15:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-04-12 15:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 15:12:40 --> Final output sent to browser
DEBUG - 2024-04-12 15:12:40 --> Total execution time: 0.3614
ERROR - 2024-04-12 17:42:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 17:42:52 --> Config Class Initialized
INFO - 2024-04-12 17:42:52 --> Hooks Class Initialized
DEBUG - 2024-04-12 17:42:52 --> UTF-8 Support Enabled
INFO - 2024-04-12 17:42:52 --> Utf8 Class Initialized
INFO - 2024-04-12 17:42:52 --> URI Class Initialized
INFO - 2024-04-12 17:42:52 --> Router Class Initialized
INFO - 2024-04-12 17:42:52 --> Output Class Initialized
INFO - 2024-04-12 17:42:52 --> Security Class Initialized
DEBUG - 2024-04-12 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 17:42:52 --> Input Class Initialized
INFO - 2024-04-12 17:42:52 --> Language Class Initialized
ERROR - 2024-04-12 17:42:52 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-04-12 18:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 18:41:26 --> Config Class Initialized
INFO - 2024-04-12 18:41:26 --> Hooks Class Initialized
DEBUG - 2024-04-12 18:41:26 --> UTF-8 Support Enabled
INFO - 2024-04-12 18:41:26 --> Utf8 Class Initialized
INFO - 2024-04-12 18:41:26 --> URI Class Initialized
DEBUG - 2024-04-12 18:41:26 --> No URI present. Default controller set.
INFO - 2024-04-12 18:41:26 --> Router Class Initialized
INFO - 2024-04-12 18:41:26 --> Output Class Initialized
INFO - 2024-04-12 18:41:26 --> Security Class Initialized
DEBUG - 2024-04-12 18:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 18:41:26 --> Input Class Initialized
INFO - 2024-04-12 18:41:26 --> Language Class Initialized
INFO - 2024-04-12 18:41:26 --> Loader Class Initialized
INFO - 2024-04-12 18:41:26 --> Helper loaded: url_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: file_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: html_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: text_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: form_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: lang_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: security_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: cookie_helper
INFO - 2024-04-12 18:41:26 --> Database Driver Class Initialized
INFO - 2024-04-12 18:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 18:41:26 --> Parser Class Initialized
INFO - 2024-04-12 18:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 18:41:26 --> Pagination Class Initialized
INFO - 2024-04-12 18:41:26 --> Form Validation Class Initialized
INFO - 2024-04-12 18:41:26 --> Controller Class Initialized
INFO - 2024-04-12 18:41:26 --> Model Class Initialized
DEBUG - 2024-04-12 18:41:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-04-12 18:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-04-12 18:41:26 --> Config Class Initialized
INFO - 2024-04-12 18:41:26 --> Hooks Class Initialized
DEBUG - 2024-04-12 18:41:26 --> UTF-8 Support Enabled
INFO - 2024-04-12 18:41:26 --> Utf8 Class Initialized
INFO - 2024-04-12 18:41:26 --> URI Class Initialized
INFO - 2024-04-12 18:41:26 --> Router Class Initialized
INFO - 2024-04-12 18:41:26 --> Output Class Initialized
INFO - 2024-04-12 18:41:26 --> Security Class Initialized
DEBUG - 2024-04-12 18:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-12 18:41:26 --> Input Class Initialized
INFO - 2024-04-12 18:41:26 --> Language Class Initialized
INFO - 2024-04-12 18:41:26 --> Loader Class Initialized
INFO - 2024-04-12 18:41:26 --> Helper loaded: url_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: file_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: html_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: text_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: form_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: lang_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: security_helper
INFO - 2024-04-12 18:41:26 --> Helper loaded: cookie_helper
INFO - 2024-04-12 18:41:26 --> Database Driver Class Initialized
INFO - 2024-04-12 18:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-12 18:41:26 --> Parser Class Initialized
INFO - 2024-04-12 18:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-04-12 18:41:26 --> Pagination Class Initialized
INFO - 2024-04-12 18:41:26 --> Form Validation Class Initialized
INFO - 2024-04-12 18:41:26 --> Controller Class Initialized
INFO - 2024-04-12 18:41:26 --> Model Class Initialized
DEBUG - 2024-04-12 18:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-04-12 18:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-04-12 18:41:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-04-12 18:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-04-12 18:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-04-12 18:41:26 --> Model Class Initialized
INFO - 2024-04-12 18:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-04-12 18:41:26 --> Final output sent to browser
DEBUG - 2024-04-12 18:41:26 --> Total execution time: 0.0315
