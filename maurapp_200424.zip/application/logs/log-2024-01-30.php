<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-30 01:29:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 01:29:32 --> Config Class Initialized
INFO - 2024-01-30 01:29:32 --> Hooks Class Initialized
DEBUG - 2024-01-30 01:29:32 --> UTF-8 Support Enabled
INFO - 2024-01-30 01:29:32 --> Utf8 Class Initialized
INFO - 2024-01-30 01:29:32 --> URI Class Initialized
DEBUG - 2024-01-30 01:29:32 --> No URI present. Default controller set.
INFO - 2024-01-30 01:29:32 --> Router Class Initialized
INFO - 2024-01-30 01:29:32 --> Output Class Initialized
INFO - 2024-01-30 01:29:32 --> Security Class Initialized
DEBUG - 2024-01-30 01:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 01:29:32 --> Input Class Initialized
INFO - 2024-01-30 01:29:32 --> Language Class Initialized
INFO - 2024-01-30 01:29:32 --> Loader Class Initialized
INFO - 2024-01-30 01:29:32 --> Helper loaded: url_helper
INFO - 2024-01-30 01:29:32 --> Helper loaded: file_helper
INFO - 2024-01-30 01:29:32 --> Helper loaded: html_helper
INFO - 2024-01-30 01:29:32 --> Helper loaded: text_helper
INFO - 2024-01-30 01:29:32 --> Helper loaded: form_helper
INFO - 2024-01-30 01:29:32 --> Helper loaded: lang_helper
INFO - 2024-01-30 01:29:32 --> Helper loaded: security_helper
INFO - 2024-01-30 01:29:32 --> Helper loaded: cookie_helper
INFO - 2024-01-30 01:29:32 --> Database Driver Class Initialized
INFO - 2024-01-30 01:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 01:29:32 --> Parser Class Initialized
INFO - 2024-01-30 01:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 01:29:32 --> Pagination Class Initialized
INFO - 2024-01-30 01:29:32 --> Form Validation Class Initialized
INFO - 2024-01-30 01:29:32 --> Controller Class Initialized
INFO - 2024-01-30 01:29:32 --> Model Class Initialized
DEBUG - 2024-01-30 01:29:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 02:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 02:24:13 --> Config Class Initialized
INFO - 2024-01-30 02:24:13 --> Hooks Class Initialized
DEBUG - 2024-01-30 02:24:13 --> UTF-8 Support Enabled
INFO - 2024-01-30 02:24:13 --> Utf8 Class Initialized
INFO - 2024-01-30 02:24:13 --> URI Class Initialized
INFO - 2024-01-30 02:24:13 --> Router Class Initialized
INFO - 2024-01-30 02:24:13 --> Output Class Initialized
INFO - 2024-01-30 02:24:13 --> Security Class Initialized
DEBUG - 2024-01-30 02:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 02:24:13 --> Input Class Initialized
INFO - 2024-01-30 02:24:13 --> Language Class Initialized
ERROR - 2024-01-30 02:24:13 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-30 06:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:03:12 --> Config Class Initialized
INFO - 2024-01-30 06:03:12 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:03:12 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:03:12 --> Utf8 Class Initialized
INFO - 2024-01-30 06:03:12 --> URI Class Initialized
DEBUG - 2024-01-30 06:03:12 --> No URI present. Default controller set.
INFO - 2024-01-30 06:03:12 --> Router Class Initialized
INFO - 2024-01-30 06:03:12 --> Output Class Initialized
INFO - 2024-01-30 06:03:12 --> Security Class Initialized
DEBUG - 2024-01-30 06:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:03:12 --> Input Class Initialized
INFO - 2024-01-30 06:03:12 --> Language Class Initialized
INFO - 2024-01-30 06:03:12 --> Loader Class Initialized
INFO - 2024-01-30 06:03:12 --> Helper loaded: url_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: file_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: html_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: text_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: form_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: security_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:03:12 --> Database Driver Class Initialized
INFO - 2024-01-30 06:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:03:12 --> Parser Class Initialized
INFO - 2024-01-30 06:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:03:12 --> Pagination Class Initialized
INFO - 2024-01-30 06:03:12 --> Form Validation Class Initialized
INFO - 2024-01-30 06:03:12 --> Controller Class Initialized
INFO - 2024-01-30 06:03:12 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 06:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:03:12 --> Config Class Initialized
INFO - 2024-01-30 06:03:12 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:03:12 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:03:12 --> Utf8 Class Initialized
INFO - 2024-01-30 06:03:12 --> URI Class Initialized
INFO - 2024-01-30 06:03:12 --> Router Class Initialized
INFO - 2024-01-30 06:03:12 --> Output Class Initialized
INFO - 2024-01-30 06:03:12 --> Security Class Initialized
DEBUG - 2024-01-30 06:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:03:12 --> Input Class Initialized
INFO - 2024-01-30 06:03:12 --> Language Class Initialized
INFO - 2024-01-30 06:03:12 --> Loader Class Initialized
INFO - 2024-01-30 06:03:12 --> Helper loaded: url_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: file_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: html_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: text_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: form_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: security_helper
INFO - 2024-01-30 06:03:12 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:03:12 --> Database Driver Class Initialized
INFO - 2024-01-30 06:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:03:12 --> Parser Class Initialized
INFO - 2024-01-30 06:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:03:12 --> Pagination Class Initialized
INFO - 2024-01-30 06:03:12 --> Form Validation Class Initialized
INFO - 2024-01-30 06:03:12 --> Controller Class Initialized
INFO - 2024-01-30 06:03:12 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 06:03:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:03:12 --> Model Class Initialized
INFO - 2024-01-30 06:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:03:12 --> Final output sent to browser
DEBUG - 2024-01-30 06:03:12 --> Total execution time: 0.0402
ERROR - 2024-01-30 06:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:03:31 --> Config Class Initialized
INFO - 2024-01-30 06:03:31 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:03:31 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:03:31 --> Utf8 Class Initialized
INFO - 2024-01-30 06:03:31 --> URI Class Initialized
INFO - 2024-01-30 06:03:31 --> Router Class Initialized
INFO - 2024-01-30 06:03:31 --> Output Class Initialized
INFO - 2024-01-30 06:03:31 --> Security Class Initialized
DEBUG - 2024-01-30 06:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:03:31 --> Input Class Initialized
INFO - 2024-01-30 06:03:31 --> Language Class Initialized
INFO - 2024-01-30 06:03:31 --> Loader Class Initialized
INFO - 2024-01-30 06:03:31 --> Helper loaded: url_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: file_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: html_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: text_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: form_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: security_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:03:31 --> Database Driver Class Initialized
INFO - 2024-01-30 06:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:03:31 --> Parser Class Initialized
INFO - 2024-01-30 06:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:03:31 --> Pagination Class Initialized
INFO - 2024-01-30 06:03:31 --> Form Validation Class Initialized
INFO - 2024-01-30 06:03:31 --> Controller Class Initialized
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
INFO - 2024-01-30 06:03:31 --> Final output sent to browser
DEBUG - 2024-01-30 06:03:31 --> Total execution time: 0.0200
ERROR - 2024-01-30 06:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:03:31 --> Config Class Initialized
INFO - 2024-01-30 06:03:31 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:03:31 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:03:31 --> Utf8 Class Initialized
INFO - 2024-01-30 06:03:31 --> URI Class Initialized
DEBUG - 2024-01-30 06:03:31 --> No URI present. Default controller set.
INFO - 2024-01-30 06:03:31 --> Router Class Initialized
INFO - 2024-01-30 06:03:31 --> Output Class Initialized
INFO - 2024-01-30 06:03:31 --> Security Class Initialized
DEBUG - 2024-01-30 06:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:03:31 --> Input Class Initialized
INFO - 2024-01-30 06:03:31 --> Language Class Initialized
INFO - 2024-01-30 06:03:31 --> Loader Class Initialized
INFO - 2024-01-30 06:03:31 --> Helper loaded: url_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: file_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: html_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: text_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: form_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: security_helper
INFO - 2024-01-30 06:03:31 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:03:31 --> Database Driver Class Initialized
INFO - 2024-01-30 06:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:03:31 --> Parser Class Initialized
INFO - 2024-01-30 06:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:03:31 --> Pagination Class Initialized
INFO - 2024-01-30 06:03:31 --> Form Validation Class Initialized
INFO - 2024-01-30 06:03:31 --> Controller Class Initialized
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
INFO - 2024-01-30 06:03:31 --> Model Class Initialized
INFO - 2024-01-30 06:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 06:03:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:03:32 --> Model Class Initialized
INFO - 2024-01-30 06:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 06:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 06:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:03:32 --> Final output sent to browser
DEBUG - 2024-01-30 06:03:32 --> Total execution time: 0.2376
ERROR - 2024-01-30 06:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:03:44 --> Config Class Initialized
INFO - 2024-01-30 06:03:44 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:03:44 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:03:44 --> Utf8 Class Initialized
INFO - 2024-01-30 06:03:44 --> URI Class Initialized
INFO - 2024-01-30 06:03:44 --> Router Class Initialized
INFO - 2024-01-30 06:03:44 --> Output Class Initialized
INFO - 2024-01-30 06:03:44 --> Security Class Initialized
DEBUG - 2024-01-30 06:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:03:44 --> Input Class Initialized
INFO - 2024-01-30 06:03:44 --> Language Class Initialized
INFO - 2024-01-30 06:03:44 --> Loader Class Initialized
INFO - 2024-01-30 06:03:44 --> Helper loaded: url_helper
INFO - 2024-01-30 06:03:44 --> Helper loaded: file_helper
INFO - 2024-01-30 06:03:44 --> Helper loaded: html_helper
INFO - 2024-01-30 06:03:44 --> Helper loaded: text_helper
INFO - 2024-01-30 06:03:44 --> Helper loaded: form_helper
INFO - 2024-01-30 06:03:44 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:03:44 --> Helper loaded: security_helper
INFO - 2024-01-30 06:03:44 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:03:44 --> Database Driver Class Initialized
INFO - 2024-01-30 06:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:03:44 --> Parser Class Initialized
INFO - 2024-01-30 06:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:03:44 --> Pagination Class Initialized
INFO - 2024-01-30 06:03:44 --> Form Validation Class Initialized
INFO - 2024-01-30 06:03:44 --> Controller Class Initialized
DEBUG - 2024-01-30 06:03:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:44 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:44 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:44 --> Model Class Initialized
INFO - 2024-01-30 06:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 06:03:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:03:44 --> Model Class Initialized
INFO - 2024-01-30 06:03:44 --> Model Class Initialized
INFO - 2024-01-30 06:03:44 --> Model Class Initialized
INFO - 2024-01-30 06:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 06:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 06:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:03:44 --> Final output sent to browser
DEBUG - 2024-01-30 06:03:44 --> Total execution time: 0.1568
ERROR - 2024-01-30 06:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:03:45 --> Config Class Initialized
INFO - 2024-01-30 06:03:45 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:03:45 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:03:45 --> Utf8 Class Initialized
INFO - 2024-01-30 06:03:45 --> URI Class Initialized
INFO - 2024-01-30 06:03:45 --> Router Class Initialized
INFO - 2024-01-30 06:03:45 --> Output Class Initialized
INFO - 2024-01-30 06:03:45 --> Security Class Initialized
DEBUG - 2024-01-30 06:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:03:45 --> Input Class Initialized
INFO - 2024-01-30 06:03:45 --> Language Class Initialized
INFO - 2024-01-30 06:03:45 --> Loader Class Initialized
INFO - 2024-01-30 06:03:45 --> Helper loaded: url_helper
INFO - 2024-01-30 06:03:45 --> Helper loaded: file_helper
INFO - 2024-01-30 06:03:45 --> Helper loaded: html_helper
INFO - 2024-01-30 06:03:45 --> Helper loaded: text_helper
INFO - 2024-01-30 06:03:45 --> Helper loaded: form_helper
INFO - 2024-01-30 06:03:45 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:03:45 --> Helper loaded: security_helper
INFO - 2024-01-30 06:03:45 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:03:45 --> Database Driver Class Initialized
INFO - 2024-01-30 06:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:03:45 --> Parser Class Initialized
INFO - 2024-01-30 06:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:03:45 --> Pagination Class Initialized
INFO - 2024-01-30 06:03:45 --> Form Validation Class Initialized
INFO - 2024-01-30 06:03:45 --> Controller Class Initialized
DEBUG - 2024-01-30 06:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:45 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:45 --> Model Class Initialized
INFO - 2024-01-30 06:03:45 --> Final output sent to browser
DEBUG - 2024-01-30 06:03:45 --> Total execution time: 0.0213
ERROR - 2024-01-30 06:03:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:03:50 --> Config Class Initialized
INFO - 2024-01-30 06:03:50 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:03:50 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:03:50 --> Utf8 Class Initialized
INFO - 2024-01-30 06:03:50 --> URI Class Initialized
INFO - 2024-01-30 06:03:50 --> Router Class Initialized
INFO - 2024-01-30 06:03:50 --> Output Class Initialized
INFO - 2024-01-30 06:03:50 --> Security Class Initialized
DEBUG - 2024-01-30 06:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:03:50 --> Input Class Initialized
INFO - 2024-01-30 06:03:50 --> Language Class Initialized
INFO - 2024-01-30 06:03:50 --> Loader Class Initialized
INFO - 2024-01-30 06:03:50 --> Helper loaded: url_helper
INFO - 2024-01-30 06:03:50 --> Helper loaded: file_helper
INFO - 2024-01-30 06:03:50 --> Helper loaded: html_helper
INFO - 2024-01-30 06:03:50 --> Helper loaded: text_helper
INFO - 2024-01-30 06:03:50 --> Helper loaded: form_helper
INFO - 2024-01-30 06:03:50 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:03:50 --> Helper loaded: security_helper
INFO - 2024-01-30 06:03:50 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:03:50 --> Database Driver Class Initialized
INFO - 2024-01-30 06:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:03:50 --> Parser Class Initialized
INFO - 2024-01-30 06:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:03:50 --> Pagination Class Initialized
INFO - 2024-01-30 06:03:50 --> Form Validation Class Initialized
INFO - 2024-01-30 06:03:50 --> Controller Class Initialized
DEBUG - 2024-01-30 06:03:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:50 --> Model Class Initialized
DEBUG - 2024-01-30 06:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:03:50 --> Model Class Initialized
INFO - 2024-01-30 06:03:50 --> Final output sent to browser
DEBUG - 2024-01-30 06:03:50 --> Total execution time: 0.0255
ERROR - 2024-01-30 06:04:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:04:50 --> Config Class Initialized
INFO - 2024-01-30 06:04:50 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:04:50 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:04:50 --> Utf8 Class Initialized
INFO - 2024-01-30 06:04:50 --> URI Class Initialized
DEBUG - 2024-01-30 06:04:50 --> No URI present. Default controller set.
INFO - 2024-01-30 06:04:50 --> Router Class Initialized
INFO - 2024-01-30 06:04:50 --> Output Class Initialized
INFO - 2024-01-30 06:04:50 --> Security Class Initialized
DEBUG - 2024-01-30 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:04:50 --> Input Class Initialized
INFO - 2024-01-30 06:04:50 --> Language Class Initialized
INFO - 2024-01-30 06:04:50 --> Loader Class Initialized
INFO - 2024-01-30 06:04:50 --> Helper loaded: url_helper
INFO - 2024-01-30 06:04:50 --> Helper loaded: file_helper
INFO - 2024-01-30 06:04:50 --> Helper loaded: html_helper
INFO - 2024-01-30 06:04:50 --> Helper loaded: text_helper
INFO - 2024-01-30 06:04:50 --> Helper loaded: form_helper
INFO - 2024-01-30 06:04:50 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:04:50 --> Helper loaded: security_helper
INFO - 2024-01-30 06:04:50 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:04:50 --> Database Driver Class Initialized
INFO - 2024-01-30 06:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:04:50 --> Parser Class Initialized
INFO - 2024-01-30 06:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:04:50 --> Pagination Class Initialized
INFO - 2024-01-30 06:04:50 --> Form Validation Class Initialized
INFO - 2024-01-30 06:04:50 --> Controller Class Initialized
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
DEBUG - 2024-01-30 06:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
DEBUG - 2024-01-30 06:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
DEBUG - 2024-01-30 06:04:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
INFO - 2024-01-30 06:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 06:04:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:04:50 --> Model Class Initialized
INFO - 2024-01-30 06:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 06:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 06:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:04:50 --> Final output sent to browser
DEBUG - 2024-01-30 06:04:50 --> Total execution time: 0.2327
ERROR - 2024-01-30 06:18:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:18:49 --> Config Class Initialized
INFO - 2024-01-30 06:18:49 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:18:49 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:18:49 --> Utf8 Class Initialized
INFO - 2024-01-30 06:18:49 --> URI Class Initialized
DEBUG - 2024-01-30 06:18:49 --> No URI present. Default controller set.
INFO - 2024-01-30 06:18:49 --> Router Class Initialized
INFO - 2024-01-30 06:18:49 --> Output Class Initialized
INFO - 2024-01-30 06:18:49 --> Security Class Initialized
DEBUG - 2024-01-30 06:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:18:49 --> Input Class Initialized
INFO - 2024-01-30 06:18:49 --> Language Class Initialized
INFO - 2024-01-30 06:18:49 --> Loader Class Initialized
INFO - 2024-01-30 06:18:49 --> Helper loaded: url_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: file_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: html_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: text_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: form_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: security_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:18:49 --> Database Driver Class Initialized
INFO - 2024-01-30 06:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:18:49 --> Parser Class Initialized
INFO - 2024-01-30 06:18:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:18:49 --> Pagination Class Initialized
INFO - 2024-01-30 06:18:49 --> Form Validation Class Initialized
INFO - 2024-01-30 06:18:49 --> Controller Class Initialized
INFO - 2024-01-30 06:18:49 --> Model Class Initialized
DEBUG - 2024-01-30 06:18:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 06:18:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:18:49 --> Config Class Initialized
INFO - 2024-01-30 06:18:49 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:18:49 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:18:49 --> Utf8 Class Initialized
INFO - 2024-01-30 06:18:49 --> URI Class Initialized
INFO - 2024-01-30 06:18:49 --> Router Class Initialized
INFO - 2024-01-30 06:18:49 --> Output Class Initialized
INFO - 2024-01-30 06:18:49 --> Security Class Initialized
DEBUG - 2024-01-30 06:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:18:49 --> Input Class Initialized
INFO - 2024-01-30 06:18:49 --> Language Class Initialized
INFO - 2024-01-30 06:18:49 --> Loader Class Initialized
INFO - 2024-01-30 06:18:49 --> Helper loaded: url_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: file_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: html_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: text_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: form_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: security_helper
INFO - 2024-01-30 06:18:49 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:18:49 --> Database Driver Class Initialized
INFO - 2024-01-30 06:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:18:49 --> Parser Class Initialized
INFO - 2024-01-30 06:18:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:18:49 --> Pagination Class Initialized
INFO - 2024-01-30 06:18:49 --> Form Validation Class Initialized
INFO - 2024-01-30 06:18:49 --> Controller Class Initialized
INFO - 2024-01-30 06:18:49 --> Model Class Initialized
DEBUG - 2024-01-30 06:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 06:18:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:18:49 --> Model Class Initialized
INFO - 2024-01-30 06:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:18:49 --> Final output sent to browser
DEBUG - 2024-01-30 06:18:49 --> Total execution time: 0.0338
ERROR - 2024-01-30 06:52:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:52:05 --> Config Class Initialized
INFO - 2024-01-30 06:52:05 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:52:05 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:52:05 --> Utf8 Class Initialized
INFO - 2024-01-30 06:52:05 --> URI Class Initialized
INFO - 2024-01-30 06:52:05 --> Router Class Initialized
INFO - 2024-01-30 06:52:05 --> Output Class Initialized
INFO - 2024-01-30 06:52:05 --> Security Class Initialized
DEBUG - 2024-01-30 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:52:05 --> Input Class Initialized
INFO - 2024-01-30 06:52:05 --> Language Class Initialized
INFO - 2024-01-30 06:52:05 --> Loader Class Initialized
INFO - 2024-01-30 06:52:05 --> Helper loaded: url_helper
INFO - 2024-01-30 06:52:05 --> Helper loaded: file_helper
INFO - 2024-01-30 06:52:05 --> Helper loaded: html_helper
INFO - 2024-01-30 06:52:05 --> Helper loaded: text_helper
INFO - 2024-01-30 06:52:05 --> Helper loaded: form_helper
INFO - 2024-01-30 06:52:05 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:52:05 --> Helper loaded: security_helper
INFO - 2024-01-30 06:52:05 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:52:05 --> Database Driver Class Initialized
INFO - 2024-01-30 06:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:52:05 --> Parser Class Initialized
INFO - 2024-01-30 06:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:52:05 --> Pagination Class Initialized
INFO - 2024-01-30 06:52:05 --> Form Validation Class Initialized
INFO - 2024-01-30 06:52:05 --> Controller Class Initialized
INFO - 2024-01-30 06:52:05 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:05 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:05 --> Model Class Initialized
INFO - 2024-01-30 06:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-30 06:52:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:52:05 --> Model Class Initialized
INFO - 2024-01-30 06:52:05 --> Model Class Initialized
INFO - 2024-01-30 06:52:05 --> Model Class Initialized
INFO - 2024-01-30 06:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 06:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 06:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:52:05 --> Final output sent to browser
DEBUG - 2024-01-30 06:52:05 --> Total execution time: 0.1719
ERROR - 2024-01-30 06:52:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:52:07 --> Config Class Initialized
INFO - 2024-01-30 06:52:07 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:52:07 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:52:07 --> Utf8 Class Initialized
INFO - 2024-01-30 06:52:07 --> URI Class Initialized
INFO - 2024-01-30 06:52:07 --> Router Class Initialized
INFO - 2024-01-30 06:52:07 --> Output Class Initialized
INFO - 2024-01-30 06:52:07 --> Security Class Initialized
DEBUG - 2024-01-30 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:52:07 --> Input Class Initialized
INFO - 2024-01-30 06:52:07 --> Language Class Initialized
INFO - 2024-01-30 06:52:07 --> Loader Class Initialized
INFO - 2024-01-30 06:52:07 --> Helper loaded: url_helper
INFO - 2024-01-30 06:52:07 --> Helper loaded: file_helper
INFO - 2024-01-30 06:52:07 --> Helper loaded: html_helper
INFO - 2024-01-30 06:52:07 --> Helper loaded: text_helper
INFO - 2024-01-30 06:52:07 --> Helper loaded: form_helper
INFO - 2024-01-30 06:52:07 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:52:07 --> Helper loaded: security_helper
INFO - 2024-01-30 06:52:07 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:52:07 --> Database Driver Class Initialized
INFO - 2024-01-30 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:52:07 --> Parser Class Initialized
INFO - 2024-01-30 06:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:52:07 --> Pagination Class Initialized
INFO - 2024-01-30 06:52:07 --> Form Validation Class Initialized
INFO - 2024-01-30 06:52:07 --> Controller Class Initialized
INFO - 2024-01-30 06:52:07 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:07 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:07 --> Model Class Initialized
INFO - 2024-01-30 06:52:07 --> Final output sent to browser
DEBUG - 2024-01-30 06:52:07 --> Total execution time: 0.0405
ERROR - 2024-01-30 06:52:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:52:24 --> Config Class Initialized
INFO - 2024-01-30 06:52:24 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:52:24 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:52:24 --> Utf8 Class Initialized
INFO - 2024-01-30 06:52:24 --> URI Class Initialized
INFO - 2024-01-30 06:52:24 --> Router Class Initialized
INFO - 2024-01-30 06:52:24 --> Output Class Initialized
INFO - 2024-01-30 06:52:24 --> Security Class Initialized
DEBUG - 2024-01-30 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:52:24 --> Input Class Initialized
INFO - 2024-01-30 06:52:24 --> Language Class Initialized
INFO - 2024-01-30 06:52:24 --> Loader Class Initialized
INFO - 2024-01-30 06:52:24 --> Helper loaded: url_helper
INFO - 2024-01-30 06:52:24 --> Helper loaded: file_helper
INFO - 2024-01-30 06:52:24 --> Helper loaded: html_helper
INFO - 2024-01-30 06:52:24 --> Helper loaded: text_helper
INFO - 2024-01-30 06:52:24 --> Helper loaded: form_helper
INFO - 2024-01-30 06:52:24 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:52:24 --> Helper loaded: security_helper
INFO - 2024-01-30 06:52:24 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:52:24 --> Database Driver Class Initialized
INFO - 2024-01-30 06:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:52:24 --> Parser Class Initialized
INFO - 2024-01-30 06:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:52:24 --> Pagination Class Initialized
INFO - 2024-01-30 06:52:24 --> Form Validation Class Initialized
INFO - 2024-01-30 06:52:24 --> Controller Class Initialized
INFO - 2024-01-30 06:52:24 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:24 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:24 --> Model Class Initialized
INFO - 2024-01-30 06:52:24 --> Final output sent to browser
DEBUG - 2024-01-30 06:52:24 --> Total execution time: 0.0670
ERROR - 2024-01-30 06:52:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:52:27 --> Config Class Initialized
INFO - 2024-01-30 06:52:27 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:52:27 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:52:27 --> Utf8 Class Initialized
INFO - 2024-01-30 06:52:27 --> URI Class Initialized
INFO - 2024-01-30 06:52:27 --> Router Class Initialized
INFO - 2024-01-30 06:52:27 --> Output Class Initialized
INFO - 2024-01-30 06:52:27 --> Security Class Initialized
DEBUG - 2024-01-30 06:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:52:27 --> Input Class Initialized
INFO - 2024-01-30 06:52:27 --> Language Class Initialized
INFO - 2024-01-30 06:52:27 --> Loader Class Initialized
INFO - 2024-01-30 06:52:27 --> Helper loaded: url_helper
INFO - 2024-01-30 06:52:27 --> Helper loaded: file_helper
INFO - 2024-01-30 06:52:27 --> Helper loaded: html_helper
INFO - 2024-01-30 06:52:27 --> Helper loaded: text_helper
INFO - 2024-01-30 06:52:27 --> Helper loaded: form_helper
INFO - 2024-01-30 06:52:27 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:52:27 --> Helper loaded: security_helper
INFO - 2024-01-30 06:52:27 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:52:27 --> Database Driver Class Initialized
INFO - 2024-01-30 06:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:52:27 --> Parser Class Initialized
INFO - 2024-01-30 06:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:52:27 --> Pagination Class Initialized
INFO - 2024-01-30 06:52:27 --> Form Validation Class Initialized
INFO - 2024-01-30 06:52:27 --> Controller Class Initialized
INFO - 2024-01-30 06:52:27 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:27 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:27 --> Model Class Initialized
INFO - 2024-01-30 06:52:27 --> Final output sent to browser
DEBUG - 2024-01-30 06:52:27 --> Total execution time: 0.1102
ERROR - 2024-01-30 06:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:52:45 --> Config Class Initialized
INFO - 2024-01-30 06:52:45 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:52:45 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:52:45 --> Utf8 Class Initialized
INFO - 2024-01-30 06:52:45 --> URI Class Initialized
INFO - 2024-01-30 06:52:45 --> Router Class Initialized
INFO - 2024-01-30 06:52:45 --> Output Class Initialized
INFO - 2024-01-30 06:52:45 --> Security Class Initialized
DEBUG - 2024-01-30 06:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:52:45 --> Input Class Initialized
INFO - 2024-01-30 06:52:45 --> Language Class Initialized
INFO - 2024-01-30 06:52:45 --> Loader Class Initialized
INFO - 2024-01-30 06:52:45 --> Helper loaded: url_helper
INFO - 2024-01-30 06:52:45 --> Helper loaded: file_helper
INFO - 2024-01-30 06:52:45 --> Helper loaded: html_helper
INFO - 2024-01-30 06:52:45 --> Helper loaded: text_helper
INFO - 2024-01-30 06:52:45 --> Helper loaded: form_helper
INFO - 2024-01-30 06:52:45 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:52:45 --> Helper loaded: security_helper
INFO - 2024-01-30 06:52:45 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:52:45 --> Database Driver Class Initialized
INFO - 2024-01-30 06:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:52:45 --> Parser Class Initialized
INFO - 2024-01-30 06:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:52:45 --> Pagination Class Initialized
INFO - 2024-01-30 06:52:45 --> Form Validation Class Initialized
INFO - 2024-01-30 06:52:45 --> Controller Class Initialized
INFO - 2024-01-30 06:52:45 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:45 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:45 --> Model Class Initialized
DEBUG - 2024-01-30 06:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-30 06:52:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:52:45 --> Model Class Initialized
INFO - 2024-01-30 06:52:45 --> Model Class Initialized
INFO - 2024-01-30 06:52:45 --> Model Class Initialized
INFO - 2024-01-30 06:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 06:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 06:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:52:45 --> Final output sent to browser
DEBUG - 2024-01-30 06:52:45 --> Total execution time: 0.1583
ERROR - 2024-01-30 06:53:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:53:21 --> Config Class Initialized
INFO - 2024-01-30 06:53:21 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:53:21 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:53:21 --> Utf8 Class Initialized
INFO - 2024-01-30 06:53:21 --> URI Class Initialized
DEBUG - 2024-01-30 06:53:21 --> No URI present. Default controller set.
INFO - 2024-01-30 06:53:21 --> Router Class Initialized
INFO - 2024-01-30 06:53:21 --> Output Class Initialized
INFO - 2024-01-30 06:53:21 --> Security Class Initialized
DEBUG - 2024-01-30 06:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:53:21 --> Input Class Initialized
INFO - 2024-01-30 06:53:21 --> Language Class Initialized
INFO - 2024-01-30 06:53:21 --> Loader Class Initialized
INFO - 2024-01-30 06:53:21 --> Helper loaded: url_helper
INFO - 2024-01-30 06:53:21 --> Helper loaded: file_helper
INFO - 2024-01-30 06:53:21 --> Helper loaded: html_helper
INFO - 2024-01-30 06:53:21 --> Helper loaded: text_helper
INFO - 2024-01-30 06:53:21 --> Helper loaded: form_helper
INFO - 2024-01-30 06:53:21 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:53:21 --> Helper loaded: security_helper
INFO - 2024-01-30 06:53:21 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:53:21 --> Database Driver Class Initialized
INFO - 2024-01-30 06:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:53:21 --> Parser Class Initialized
INFO - 2024-01-30 06:53:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:53:21 --> Pagination Class Initialized
INFO - 2024-01-30 06:53:21 --> Form Validation Class Initialized
INFO - 2024-01-30 06:53:21 --> Controller Class Initialized
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
DEBUG - 2024-01-30 06:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
DEBUG - 2024-01-30 06:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
DEBUG - 2024-01-30 06:53:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 06:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
INFO - 2024-01-30 06:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 06:53:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:53:21 --> Model Class Initialized
INFO - 2024-01-30 06:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 06:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 06:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:53:21 --> Final output sent to browser
DEBUG - 2024-01-30 06:53:21 --> Total execution time: 0.2325
ERROR - 2024-01-30 06:58:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:58:40 --> Config Class Initialized
INFO - 2024-01-30 06:58:40 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:58:40 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:58:40 --> Utf8 Class Initialized
INFO - 2024-01-30 06:58:40 --> URI Class Initialized
DEBUG - 2024-01-30 06:58:40 --> No URI present. Default controller set.
INFO - 2024-01-30 06:58:40 --> Router Class Initialized
INFO - 2024-01-30 06:58:40 --> Output Class Initialized
INFO - 2024-01-30 06:58:40 --> Security Class Initialized
DEBUG - 2024-01-30 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:58:40 --> Input Class Initialized
INFO - 2024-01-30 06:58:40 --> Language Class Initialized
INFO - 2024-01-30 06:58:40 --> Loader Class Initialized
INFO - 2024-01-30 06:58:40 --> Helper loaded: url_helper
INFO - 2024-01-30 06:58:40 --> Helper loaded: file_helper
INFO - 2024-01-30 06:58:40 --> Helper loaded: html_helper
INFO - 2024-01-30 06:58:40 --> Helper loaded: text_helper
INFO - 2024-01-30 06:58:40 --> Helper loaded: form_helper
INFO - 2024-01-30 06:58:40 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:58:40 --> Helper loaded: security_helper
INFO - 2024-01-30 06:58:40 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:58:40 --> Database Driver Class Initialized
INFO - 2024-01-30 06:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:58:40 --> Parser Class Initialized
INFO - 2024-01-30 06:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:58:40 --> Pagination Class Initialized
INFO - 2024-01-30 06:58:40 --> Form Validation Class Initialized
INFO - 2024-01-30 06:58:40 --> Controller Class Initialized
INFO - 2024-01-30 06:58:40 --> Model Class Initialized
DEBUG - 2024-01-30 06:58:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 06:58:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 06:58:41 --> Config Class Initialized
INFO - 2024-01-30 06:58:41 --> Hooks Class Initialized
DEBUG - 2024-01-30 06:58:41 --> UTF-8 Support Enabled
INFO - 2024-01-30 06:58:41 --> Utf8 Class Initialized
INFO - 2024-01-30 06:58:41 --> URI Class Initialized
INFO - 2024-01-30 06:58:41 --> Router Class Initialized
INFO - 2024-01-30 06:58:41 --> Output Class Initialized
INFO - 2024-01-30 06:58:41 --> Security Class Initialized
DEBUG - 2024-01-30 06:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 06:58:41 --> Input Class Initialized
INFO - 2024-01-30 06:58:41 --> Language Class Initialized
INFO - 2024-01-30 06:58:41 --> Loader Class Initialized
INFO - 2024-01-30 06:58:41 --> Helper loaded: url_helper
INFO - 2024-01-30 06:58:41 --> Helper loaded: file_helper
INFO - 2024-01-30 06:58:41 --> Helper loaded: html_helper
INFO - 2024-01-30 06:58:41 --> Helper loaded: text_helper
INFO - 2024-01-30 06:58:41 --> Helper loaded: form_helper
INFO - 2024-01-30 06:58:41 --> Helper loaded: lang_helper
INFO - 2024-01-30 06:58:41 --> Helper loaded: security_helper
INFO - 2024-01-30 06:58:41 --> Helper loaded: cookie_helper
INFO - 2024-01-30 06:58:41 --> Database Driver Class Initialized
INFO - 2024-01-30 06:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 06:58:41 --> Parser Class Initialized
INFO - 2024-01-30 06:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 06:58:41 --> Pagination Class Initialized
INFO - 2024-01-30 06:58:41 --> Form Validation Class Initialized
INFO - 2024-01-30 06:58:41 --> Controller Class Initialized
INFO - 2024-01-30 06:58:41 --> Model Class Initialized
DEBUG - 2024-01-30 06:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 06:58:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 06:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 06:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 06:58:41 --> Model Class Initialized
INFO - 2024-01-30 06:58:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 06:58:41 --> Final output sent to browser
DEBUG - 2024-01-30 06:58:41 --> Total execution time: 0.0329
ERROR - 2024-01-30 07:21:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:21:01 --> Config Class Initialized
INFO - 2024-01-30 07:21:01 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:21:01 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:21:01 --> Utf8 Class Initialized
INFO - 2024-01-30 07:21:01 --> URI Class Initialized
DEBUG - 2024-01-30 07:21:01 --> No URI present. Default controller set.
INFO - 2024-01-30 07:21:01 --> Router Class Initialized
INFO - 2024-01-30 07:21:01 --> Output Class Initialized
INFO - 2024-01-30 07:21:01 --> Security Class Initialized
DEBUG - 2024-01-30 07:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:21:01 --> Input Class Initialized
INFO - 2024-01-30 07:21:01 --> Language Class Initialized
INFO - 2024-01-30 07:21:01 --> Loader Class Initialized
INFO - 2024-01-30 07:21:01 --> Helper loaded: url_helper
INFO - 2024-01-30 07:21:01 --> Helper loaded: file_helper
INFO - 2024-01-30 07:21:01 --> Helper loaded: html_helper
INFO - 2024-01-30 07:21:01 --> Helper loaded: text_helper
INFO - 2024-01-30 07:21:01 --> Helper loaded: form_helper
INFO - 2024-01-30 07:21:01 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:21:01 --> Helper loaded: security_helper
INFO - 2024-01-30 07:21:01 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:21:01 --> Database Driver Class Initialized
INFO - 2024-01-30 07:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:21:01 --> Parser Class Initialized
INFO - 2024-01-30 07:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:21:01 --> Pagination Class Initialized
INFO - 2024-01-30 07:21:01 --> Form Validation Class Initialized
INFO - 2024-01-30 07:21:01 --> Controller Class Initialized
INFO - 2024-01-30 07:21:01 --> Model Class Initialized
DEBUG - 2024-01-30 07:21:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 07:21:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:21:02 --> Config Class Initialized
INFO - 2024-01-30 07:21:02 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:21:02 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:21:02 --> Utf8 Class Initialized
INFO - 2024-01-30 07:21:02 --> URI Class Initialized
INFO - 2024-01-30 07:21:02 --> Router Class Initialized
INFO - 2024-01-30 07:21:02 --> Output Class Initialized
INFO - 2024-01-30 07:21:02 --> Security Class Initialized
DEBUG - 2024-01-30 07:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:21:02 --> Input Class Initialized
INFO - 2024-01-30 07:21:02 --> Language Class Initialized
INFO - 2024-01-30 07:21:02 --> Loader Class Initialized
INFO - 2024-01-30 07:21:02 --> Helper loaded: url_helper
INFO - 2024-01-30 07:21:02 --> Helper loaded: file_helper
INFO - 2024-01-30 07:21:02 --> Helper loaded: html_helper
INFO - 2024-01-30 07:21:02 --> Helper loaded: text_helper
INFO - 2024-01-30 07:21:02 --> Helper loaded: form_helper
INFO - 2024-01-30 07:21:02 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:21:02 --> Helper loaded: security_helper
INFO - 2024-01-30 07:21:02 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:21:02 --> Database Driver Class Initialized
INFO - 2024-01-30 07:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:21:02 --> Parser Class Initialized
INFO - 2024-01-30 07:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:21:02 --> Pagination Class Initialized
INFO - 2024-01-30 07:21:02 --> Form Validation Class Initialized
INFO - 2024-01-30 07:21:02 --> Controller Class Initialized
INFO - 2024-01-30 07:21:02 --> Model Class Initialized
DEBUG - 2024-01-30 07:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 07:21:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:21:02 --> Model Class Initialized
INFO - 2024-01-30 07:21:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:21:02 --> Final output sent to browser
DEBUG - 2024-01-30 07:21:02 --> Total execution time: 0.0336
ERROR - 2024-01-30 07:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:23:08 --> Config Class Initialized
INFO - 2024-01-30 07:23:08 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:23:08 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:23:08 --> Utf8 Class Initialized
INFO - 2024-01-30 07:23:08 --> URI Class Initialized
DEBUG - 2024-01-30 07:23:08 --> No URI present. Default controller set.
INFO - 2024-01-30 07:23:08 --> Router Class Initialized
INFO - 2024-01-30 07:23:08 --> Output Class Initialized
INFO - 2024-01-30 07:23:08 --> Security Class Initialized
DEBUG - 2024-01-30 07:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:23:08 --> Input Class Initialized
INFO - 2024-01-30 07:23:08 --> Language Class Initialized
INFO - 2024-01-30 07:23:08 --> Loader Class Initialized
INFO - 2024-01-30 07:23:08 --> Helper loaded: url_helper
INFO - 2024-01-30 07:23:08 --> Helper loaded: file_helper
INFO - 2024-01-30 07:23:08 --> Helper loaded: html_helper
INFO - 2024-01-30 07:23:08 --> Helper loaded: text_helper
INFO - 2024-01-30 07:23:08 --> Helper loaded: form_helper
INFO - 2024-01-30 07:23:08 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:23:08 --> Helper loaded: security_helper
INFO - 2024-01-30 07:23:08 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:23:08 --> Database Driver Class Initialized
INFO - 2024-01-30 07:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:23:08 --> Parser Class Initialized
INFO - 2024-01-30 07:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:23:08 --> Pagination Class Initialized
INFO - 2024-01-30 07:23:08 --> Form Validation Class Initialized
INFO - 2024-01-30 07:23:08 --> Controller Class Initialized
INFO - 2024-01-30 07:23:08 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 07:23:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:23:09 --> Config Class Initialized
INFO - 2024-01-30 07:23:09 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:23:09 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:23:09 --> Utf8 Class Initialized
INFO - 2024-01-30 07:23:09 --> URI Class Initialized
INFO - 2024-01-30 07:23:09 --> Router Class Initialized
INFO - 2024-01-30 07:23:09 --> Output Class Initialized
INFO - 2024-01-30 07:23:09 --> Security Class Initialized
DEBUG - 2024-01-30 07:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:23:09 --> Input Class Initialized
INFO - 2024-01-30 07:23:09 --> Language Class Initialized
INFO - 2024-01-30 07:23:09 --> Loader Class Initialized
INFO - 2024-01-30 07:23:09 --> Helper loaded: url_helper
INFO - 2024-01-30 07:23:09 --> Helper loaded: file_helper
INFO - 2024-01-30 07:23:09 --> Helper loaded: html_helper
INFO - 2024-01-30 07:23:09 --> Helper loaded: text_helper
INFO - 2024-01-30 07:23:09 --> Helper loaded: form_helper
INFO - 2024-01-30 07:23:09 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:23:09 --> Helper loaded: security_helper
INFO - 2024-01-30 07:23:09 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:23:09 --> Database Driver Class Initialized
INFO - 2024-01-30 07:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:23:09 --> Parser Class Initialized
INFO - 2024-01-30 07:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:23:09 --> Pagination Class Initialized
INFO - 2024-01-30 07:23:09 --> Form Validation Class Initialized
INFO - 2024-01-30 07:23:09 --> Controller Class Initialized
INFO - 2024-01-30 07:23:09 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 07:23:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:23:09 --> Model Class Initialized
INFO - 2024-01-30 07:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:23:09 --> Final output sent to browser
DEBUG - 2024-01-30 07:23:09 --> Total execution time: 0.0309
ERROR - 2024-01-30 07:23:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:23:19 --> Config Class Initialized
INFO - 2024-01-30 07:23:19 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:23:19 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:23:19 --> Utf8 Class Initialized
INFO - 2024-01-30 07:23:19 --> URI Class Initialized
INFO - 2024-01-30 07:23:19 --> Router Class Initialized
INFO - 2024-01-30 07:23:19 --> Output Class Initialized
INFO - 2024-01-30 07:23:19 --> Security Class Initialized
DEBUG - 2024-01-30 07:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:23:19 --> Input Class Initialized
INFO - 2024-01-30 07:23:19 --> Language Class Initialized
INFO - 2024-01-30 07:23:19 --> Loader Class Initialized
INFO - 2024-01-30 07:23:19 --> Helper loaded: url_helper
INFO - 2024-01-30 07:23:19 --> Helper loaded: file_helper
INFO - 2024-01-30 07:23:19 --> Helper loaded: html_helper
INFO - 2024-01-30 07:23:19 --> Helper loaded: text_helper
INFO - 2024-01-30 07:23:19 --> Helper loaded: form_helper
INFO - 2024-01-30 07:23:19 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:23:19 --> Helper loaded: security_helper
INFO - 2024-01-30 07:23:19 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:23:19 --> Database Driver Class Initialized
INFO - 2024-01-30 07:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:23:19 --> Parser Class Initialized
INFO - 2024-01-30 07:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:23:19 --> Pagination Class Initialized
INFO - 2024-01-30 07:23:19 --> Form Validation Class Initialized
INFO - 2024-01-30 07:23:19 --> Controller Class Initialized
INFO - 2024-01-30 07:23:19 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:19 --> Model Class Initialized
INFO - 2024-01-30 07:23:19 --> Final output sent to browser
DEBUG - 2024-01-30 07:23:19 --> Total execution time: 0.0178
ERROR - 2024-01-30 07:23:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:23:20 --> Config Class Initialized
INFO - 2024-01-30 07:23:20 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:23:20 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:23:20 --> Utf8 Class Initialized
INFO - 2024-01-30 07:23:20 --> URI Class Initialized
DEBUG - 2024-01-30 07:23:20 --> No URI present. Default controller set.
INFO - 2024-01-30 07:23:20 --> Router Class Initialized
INFO - 2024-01-30 07:23:20 --> Output Class Initialized
INFO - 2024-01-30 07:23:20 --> Security Class Initialized
DEBUG - 2024-01-30 07:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:23:20 --> Input Class Initialized
INFO - 2024-01-30 07:23:20 --> Language Class Initialized
INFO - 2024-01-30 07:23:20 --> Loader Class Initialized
INFO - 2024-01-30 07:23:20 --> Helper loaded: url_helper
INFO - 2024-01-30 07:23:20 --> Helper loaded: file_helper
INFO - 2024-01-30 07:23:20 --> Helper loaded: html_helper
INFO - 2024-01-30 07:23:20 --> Helper loaded: text_helper
INFO - 2024-01-30 07:23:20 --> Helper loaded: form_helper
INFO - 2024-01-30 07:23:20 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:23:20 --> Helper loaded: security_helper
INFO - 2024-01-30 07:23:20 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:23:20 --> Database Driver Class Initialized
INFO - 2024-01-30 07:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:23:20 --> Parser Class Initialized
INFO - 2024-01-30 07:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:23:20 --> Pagination Class Initialized
INFO - 2024-01-30 07:23:20 --> Form Validation Class Initialized
INFO - 2024-01-30 07:23:20 --> Controller Class Initialized
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
INFO - 2024-01-30 07:23:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 07:23:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:23:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:23:20 --> Model Class Initialized
INFO - 2024-01-30 07:23:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:23:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:23:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:23:20 --> Final output sent to browser
DEBUG - 2024-01-30 07:23:20 --> Total execution time: 0.3925
ERROR - 2024-01-30 07:23:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:23:36 --> Config Class Initialized
INFO - 2024-01-30 07:23:36 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:23:36 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:23:36 --> Utf8 Class Initialized
INFO - 2024-01-30 07:23:36 --> URI Class Initialized
INFO - 2024-01-30 07:23:36 --> Router Class Initialized
INFO - 2024-01-30 07:23:36 --> Output Class Initialized
INFO - 2024-01-30 07:23:36 --> Security Class Initialized
DEBUG - 2024-01-30 07:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:23:36 --> Input Class Initialized
INFO - 2024-01-30 07:23:36 --> Language Class Initialized
INFO - 2024-01-30 07:23:36 --> Loader Class Initialized
INFO - 2024-01-30 07:23:36 --> Helper loaded: url_helper
INFO - 2024-01-30 07:23:36 --> Helper loaded: file_helper
INFO - 2024-01-30 07:23:36 --> Helper loaded: html_helper
INFO - 2024-01-30 07:23:36 --> Helper loaded: text_helper
INFO - 2024-01-30 07:23:36 --> Helper loaded: form_helper
INFO - 2024-01-30 07:23:36 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:23:36 --> Helper loaded: security_helper
INFO - 2024-01-30 07:23:36 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:23:36 --> Database Driver Class Initialized
INFO - 2024-01-30 07:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:23:36 --> Parser Class Initialized
INFO - 2024-01-30 07:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:23:36 --> Pagination Class Initialized
INFO - 2024-01-30 07:23:36 --> Form Validation Class Initialized
INFO - 2024-01-30 07:23:36 --> Controller Class Initialized
DEBUG - 2024-01-30 07:23:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:23:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:36 --> Model Class Initialized
INFO - 2024-01-30 07:23:36 --> Final output sent to browser
DEBUG - 2024-01-30 07:23:36 --> Total execution time: 0.0154
ERROR - 2024-01-30 07:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:23:53 --> Config Class Initialized
INFO - 2024-01-30 07:23:53 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:23:53 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:23:53 --> Utf8 Class Initialized
INFO - 2024-01-30 07:23:53 --> URI Class Initialized
INFO - 2024-01-30 07:23:53 --> Router Class Initialized
INFO - 2024-01-30 07:23:53 --> Output Class Initialized
INFO - 2024-01-30 07:23:53 --> Security Class Initialized
DEBUG - 2024-01-30 07:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:23:53 --> Input Class Initialized
INFO - 2024-01-30 07:23:53 --> Language Class Initialized
INFO - 2024-01-30 07:23:53 --> Loader Class Initialized
INFO - 2024-01-30 07:23:53 --> Helper loaded: url_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: file_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: html_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: text_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: form_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: security_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:23:53 --> Database Driver Class Initialized
INFO - 2024-01-30 07:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:23:53 --> Parser Class Initialized
INFO - 2024-01-30 07:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:23:53 --> Pagination Class Initialized
INFO - 2024-01-30 07:23:53 --> Form Validation Class Initialized
INFO - 2024-01-30 07:23:53 --> Controller Class Initialized
INFO - 2024-01-30 07:23:53 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 07:23:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:23:53 --> Model Class Initialized
INFO - 2024-01-30 07:23:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:23:53 --> Final output sent to browser
DEBUG - 2024-01-30 07:23:53 --> Total execution time: 0.0338
ERROR - 2024-01-30 07:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:23:53 --> Config Class Initialized
INFO - 2024-01-30 07:23:53 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:23:53 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:23:53 --> Utf8 Class Initialized
INFO - 2024-01-30 07:23:53 --> URI Class Initialized
INFO - 2024-01-30 07:23:53 --> Router Class Initialized
INFO - 2024-01-30 07:23:53 --> Output Class Initialized
INFO - 2024-01-30 07:23:53 --> Security Class Initialized
DEBUG - 2024-01-30 07:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:23:53 --> Input Class Initialized
INFO - 2024-01-30 07:23:53 --> Language Class Initialized
INFO - 2024-01-30 07:23:53 --> Loader Class Initialized
INFO - 2024-01-30 07:23:53 --> Helper loaded: url_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: file_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: html_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: text_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: form_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: security_helper
INFO - 2024-01-30 07:23:53 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:23:53 --> Database Driver Class Initialized
INFO - 2024-01-30 07:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:23:53 --> Parser Class Initialized
INFO - 2024-01-30 07:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:23:53 --> Pagination Class Initialized
INFO - 2024-01-30 07:23:53 --> Form Validation Class Initialized
INFO - 2024-01-30 07:23:54 --> Controller Class Initialized
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
DEBUG - 2024-01-30 07:23:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
INFO - 2024-01-30 07:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 07:23:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:23:54 --> Model Class Initialized
INFO - 2024-01-30 07:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:23:54 --> Final output sent to browser
DEBUG - 2024-01-30 07:23:54 --> Total execution time: 0.4402
ERROR - 2024-01-30 07:24:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:24:00 --> Config Class Initialized
INFO - 2024-01-30 07:24:00 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:24:00 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:24:00 --> Utf8 Class Initialized
INFO - 2024-01-30 07:24:00 --> URI Class Initialized
INFO - 2024-01-30 07:24:00 --> Router Class Initialized
INFO - 2024-01-30 07:24:00 --> Output Class Initialized
INFO - 2024-01-30 07:24:00 --> Security Class Initialized
DEBUG - 2024-01-30 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:24:00 --> Input Class Initialized
INFO - 2024-01-30 07:24:00 --> Language Class Initialized
INFO - 2024-01-30 07:24:00 --> Loader Class Initialized
INFO - 2024-01-30 07:24:00 --> Helper loaded: url_helper
INFO - 2024-01-30 07:24:00 --> Helper loaded: file_helper
INFO - 2024-01-30 07:24:00 --> Helper loaded: html_helper
INFO - 2024-01-30 07:24:00 --> Helper loaded: text_helper
INFO - 2024-01-30 07:24:00 --> Helper loaded: form_helper
INFO - 2024-01-30 07:24:00 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:24:00 --> Helper loaded: security_helper
INFO - 2024-01-30 07:24:00 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:24:00 --> Database Driver Class Initialized
INFO - 2024-01-30 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:24:00 --> Parser Class Initialized
INFO - 2024-01-30 07:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:24:00 --> Pagination Class Initialized
INFO - 2024-01-30 07:24:00 --> Form Validation Class Initialized
INFO - 2024-01-30 07:24:00 --> Controller Class Initialized
DEBUG - 2024-01-30 07:24:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:00 --> Model Class Initialized
DEBUG - 2024-01-30 07:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:00 --> Model Class Initialized
DEBUG - 2024-01-30 07:24:00 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:00 --> Model Class Initialized
INFO - 2024-01-30 07:24:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:24:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:24:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:24:00 --> Model Class Initialized
INFO - 2024-01-30 07:24:00 --> Model Class Initialized
INFO - 2024-01-30 07:24:00 --> Model Class Initialized
INFO - 2024-01-30 07:24:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:24:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:24:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:24:00 --> Final output sent to browser
DEBUG - 2024-01-30 07:24:00 --> Total execution time: 0.2343
ERROR - 2024-01-30 07:24:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:24:01 --> Config Class Initialized
INFO - 2024-01-30 07:24:01 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:24:01 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:24:01 --> Utf8 Class Initialized
INFO - 2024-01-30 07:24:01 --> URI Class Initialized
INFO - 2024-01-30 07:24:01 --> Router Class Initialized
INFO - 2024-01-30 07:24:01 --> Output Class Initialized
INFO - 2024-01-30 07:24:01 --> Security Class Initialized
DEBUG - 2024-01-30 07:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:24:01 --> Input Class Initialized
INFO - 2024-01-30 07:24:01 --> Language Class Initialized
INFO - 2024-01-30 07:24:01 --> Loader Class Initialized
INFO - 2024-01-30 07:24:01 --> Helper loaded: url_helper
INFO - 2024-01-30 07:24:01 --> Helper loaded: file_helper
INFO - 2024-01-30 07:24:01 --> Helper loaded: html_helper
INFO - 2024-01-30 07:24:01 --> Helper loaded: text_helper
INFO - 2024-01-30 07:24:01 --> Helper loaded: form_helper
INFO - 2024-01-30 07:24:01 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:24:01 --> Helper loaded: security_helper
INFO - 2024-01-30 07:24:01 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:24:01 --> Database Driver Class Initialized
INFO - 2024-01-30 07:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:24:01 --> Parser Class Initialized
INFO - 2024-01-30 07:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:24:01 --> Pagination Class Initialized
INFO - 2024-01-30 07:24:01 --> Form Validation Class Initialized
INFO - 2024-01-30 07:24:01 --> Controller Class Initialized
DEBUG - 2024-01-30 07:24:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:01 --> Model Class Initialized
DEBUG - 2024-01-30 07:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:01 --> Model Class Initialized
INFO - 2024-01-30 07:24:01 --> Final output sent to browser
DEBUG - 2024-01-30 07:24:01 --> Total execution time: 0.0361
ERROR - 2024-01-30 07:24:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:24:12 --> Config Class Initialized
INFO - 2024-01-30 07:24:12 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:24:12 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:24:12 --> Utf8 Class Initialized
INFO - 2024-01-30 07:24:12 --> URI Class Initialized
INFO - 2024-01-30 07:24:12 --> Router Class Initialized
INFO - 2024-01-30 07:24:12 --> Output Class Initialized
INFO - 2024-01-30 07:24:12 --> Security Class Initialized
DEBUG - 2024-01-30 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:24:12 --> Input Class Initialized
INFO - 2024-01-30 07:24:12 --> Language Class Initialized
INFO - 2024-01-30 07:24:12 --> Loader Class Initialized
INFO - 2024-01-30 07:24:12 --> Helper loaded: url_helper
INFO - 2024-01-30 07:24:12 --> Helper loaded: file_helper
INFO - 2024-01-30 07:24:12 --> Helper loaded: html_helper
INFO - 2024-01-30 07:24:12 --> Helper loaded: text_helper
INFO - 2024-01-30 07:24:12 --> Helper loaded: form_helper
INFO - 2024-01-30 07:24:12 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:24:12 --> Helper loaded: security_helper
INFO - 2024-01-30 07:24:12 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:24:12 --> Database Driver Class Initialized
INFO - 2024-01-30 07:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:24:12 --> Parser Class Initialized
INFO - 2024-01-30 07:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:24:12 --> Pagination Class Initialized
INFO - 2024-01-30 07:24:12 --> Form Validation Class Initialized
INFO - 2024-01-30 07:24:12 --> Controller Class Initialized
DEBUG - 2024-01-30 07:24:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:12 --> Model Class Initialized
DEBUG - 2024-01-30 07:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:12 --> Model Class Initialized
INFO - 2024-01-30 07:24:12 --> Final output sent to browser
DEBUG - 2024-01-30 07:24:12 --> Total execution time: 0.0509
ERROR - 2024-01-30 07:24:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:24:17 --> Config Class Initialized
INFO - 2024-01-30 07:24:17 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:24:17 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:24:17 --> Utf8 Class Initialized
INFO - 2024-01-30 07:24:17 --> URI Class Initialized
INFO - 2024-01-30 07:24:17 --> Router Class Initialized
INFO - 2024-01-30 07:24:17 --> Output Class Initialized
INFO - 2024-01-30 07:24:17 --> Security Class Initialized
DEBUG - 2024-01-30 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:24:17 --> Input Class Initialized
INFO - 2024-01-30 07:24:17 --> Language Class Initialized
INFO - 2024-01-30 07:24:17 --> Loader Class Initialized
INFO - 2024-01-30 07:24:17 --> Helper loaded: url_helper
INFO - 2024-01-30 07:24:17 --> Helper loaded: file_helper
INFO - 2024-01-30 07:24:17 --> Helper loaded: html_helper
INFO - 2024-01-30 07:24:17 --> Helper loaded: text_helper
INFO - 2024-01-30 07:24:17 --> Helper loaded: form_helper
INFO - 2024-01-30 07:24:17 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:24:17 --> Helper loaded: security_helper
INFO - 2024-01-30 07:24:17 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:24:17 --> Database Driver Class Initialized
INFO - 2024-01-30 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:24:17 --> Parser Class Initialized
INFO - 2024-01-30 07:24:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:24:17 --> Pagination Class Initialized
INFO - 2024-01-30 07:24:17 --> Form Validation Class Initialized
INFO - 2024-01-30 07:24:17 --> Controller Class Initialized
DEBUG - 2024-01-30 07:24:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:17 --> Model Class Initialized
DEBUG - 2024-01-30 07:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:24:17 --> Model Class Initialized
INFO - 2024-01-30 07:24:18 --> Final output sent to browser
DEBUG - 2024-01-30 07:24:18 --> Total execution time: 0.1763
ERROR - 2024-01-30 07:25:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:25:35 --> Config Class Initialized
INFO - 2024-01-30 07:25:35 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:25:35 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:25:35 --> Utf8 Class Initialized
INFO - 2024-01-30 07:25:35 --> URI Class Initialized
INFO - 2024-01-30 07:25:35 --> Router Class Initialized
INFO - 2024-01-30 07:25:35 --> Output Class Initialized
INFO - 2024-01-30 07:25:35 --> Security Class Initialized
DEBUG - 2024-01-30 07:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:25:35 --> Input Class Initialized
INFO - 2024-01-30 07:25:35 --> Language Class Initialized
INFO - 2024-01-30 07:25:35 --> Loader Class Initialized
INFO - 2024-01-30 07:25:35 --> Helper loaded: url_helper
INFO - 2024-01-30 07:25:35 --> Helper loaded: file_helper
INFO - 2024-01-30 07:25:35 --> Helper loaded: html_helper
INFO - 2024-01-30 07:25:35 --> Helper loaded: text_helper
INFO - 2024-01-30 07:25:35 --> Helper loaded: form_helper
INFO - 2024-01-30 07:25:35 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:25:35 --> Helper loaded: security_helper
INFO - 2024-01-30 07:25:35 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:25:35 --> Database Driver Class Initialized
INFO - 2024-01-30 07:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:25:35 --> Parser Class Initialized
INFO - 2024-01-30 07:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:25:35 --> Pagination Class Initialized
INFO - 2024-01-30 07:25:35 --> Form Validation Class Initialized
INFO - 2024-01-30 07:25:35 --> Controller Class Initialized
DEBUG - 2024-01-30 07:25:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:35 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:35 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:35 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:35 --> Model Class Initialized
INFO - 2024-01-30 07:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:25:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:25:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:25:35 --> Model Class Initialized
INFO - 2024-01-30 07:25:35 --> Model Class Initialized
INFO - 2024-01-30 07:25:35 --> Model Class Initialized
INFO - 2024-01-30 07:25:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:25:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:25:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:25:36 --> Final output sent to browser
DEBUG - 2024-01-30 07:25:36 --> Total execution time: 0.2139
ERROR - 2024-01-30 07:25:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:25:37 --> Config Class Initialized
INFO - 2024-01-30 07:25:37 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:25:37 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:25:37 --> Utf8 Class Initialized
INFO - 2024-01-30 07:25:37 --> URI Class Initialized
INFO - 2024-01-30 07:25:37 --> Router Class Initialized
INFO - 2024-01-30 07:25:37 --> Output Class Initialized
INFO - 2024-01-30 07:25:37 --> Security Class Initialized
DEBUG - 2024-01-30 07:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:25:37 --> Input Class Initialized
INFO - 2024-01-30 07:25:37 --> Language Class Initialized
INFO - 2024-01-30 07:25:37 --> Loader Class Initialized
INFO - 2024-01-30 07:25:37 --> Helper loaded: url_helper
INFO - 2024-01-30 07:25:37 --> Helper loaded: file_helper
INFO - 2024-01-30 07:25:37 --> Helper loaded: html_helper
INFO - 2024-01-30 07:25:37 --> Helper loaded: text_helper
INFO - 2024-01-30 07:25:37 --> Helper loaded: form_helper
INFO - 2024-01-30 07:25:37 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:25:37 --> Helper loaded: security_helper
INFO - 2024-01-30 07:25:37 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:25:37 --> Database Driver Class Initialized
INFO - 2024-01-30 07:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:25:37 --> Parser Class Initialized
INFO - 2024-01-30 07:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:25:37 --> Pagination Class Initialized
INFO - 2024-01-30 07:25:37 --> Form Validation Class Initialized
INFO - 2024-01-30 07:25:37 --> Controller Class Initialized
DEBUG - 2024-01-30 07:25:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:37 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:37 --> Model Class Initialized
INFO - 2024-01-30 07:25:37 --> Final output sent to browser
DEBUG - 2024-01-30 07:25:37 --> Total execution time: 0.0340
ERROR - 2024-01-30 07:25:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:25:45 --> Config Class Initialized
INFO - 2024-01-30 07:25:45 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:25:45 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:25:45 --> Utf8 Class Initialized
INFO - 2024-01-30 07:25:45 --> URI Class Initialized
INFO - 2024-01-30 07:25:45 --> Router Class Initialized
INFO - 2024-01-30 07:25:45 --> Output Class Initialized
INFO - 2024-01-30 07:25:45 --> Security Class Initialized
DEBUG - 2024-01-30 07:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:25:45 --> Input Class Initialized
INFO - 2024-01-30 07:25:45 --> Language Class Initialized
INFO - 2024-01-30 07:25:45 --> Loader Class Initialized
INFO - 2024-01-30 07:25:45 --> Helper loaded: url_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: file_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: html_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: text_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: form_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: security_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:25:45 --> Database Driver Class Initialized
INFO - 2024-01-30 07:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:25:45 --> Parser Class Initialized
INFO - 2024-01-30 07:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:25:45 --> Pagination Class Initialized
INFO - 2024-01-30 07:25:45 --> Form Validation Class Initialized
INFO - 2024-01-30 07:25:45 --> Controller Class Initialized
DEBUG - 2024-01-30 07:25:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
ERROR - 2024-01-30 07:25:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:25:45 --> Config Class Initialized
INFO - 2024-01-30 07:25:45 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:25:45 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:25:45 --> Utf8 Class Initialized
INFO - 2024-01-30 07:25:45 --> URI Class Initialized
INFO - 2024-01-30 07:25:45 --> Router Class Initialized
INFO - 2024-01-30 07:25:45 --> Output Class Initialized
INFO - 2024-01-30 07:25:45 --> Security Class Initialized
DEBUG - 2024-01-30 07:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:25:45 --> Input Class Initialized
INFO - 2024-01-30 07:25:45 --> Language Class Initialized
INFO - 2024-01-30 07:25:45 --> Loader Class Initialized
INFO - 2024-01-30 07:25:45 --> Helper loaded: url_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: file_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: html_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: text_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: form_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: security_helper
INFO - 2024-01-30 07:25:45 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:25:45 --> Database Driver Class Initialized
INFO - 2024-01-30 07:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:25:45 --> Parser Class Initialized
INFO - 2024-01-30 07:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:25:45 --> Pagination Class Initialized
INFO - 2024-01-30 07:25:45 --> Form Validation Class Initialized
INFO - 2024-01-30 07:25:45 --> Controller Class Initialized
DEBUG - 2024-01-30 07:25:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
INFO - 2024-01-30 07:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:25:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
INFO - 2024-01-30 07:25:45 --> Model Class Initialized
INFO - 2024-01-30 07:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:25:45 --> Final output sent to browser
DEBUG - 2024-01-30 07:25:45 --> Total execution time: 0.1570
INFO - 2024-01-30 07:25:45 --> Final output sent to browser
DEBUG - 2024-01-30 07:25:45 --> Total execution time: 0.2017
ERROR - 2024-01-30 07:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:25:46 --> Config Class Initialized
INFO - 2024-01-30 07:25:46 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:25:46 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:25:46 --> Utf8 Class Initialized
INFO - 2024-01-30 07:25:46 --> URI Class Initialized
INFO - 2024-01-30 07:25:46 --> Router Class Initialized
INFO - 2024-01-30 07:25:46 --> Output Class Initialized
INFO - 2024-01-30 07:25:46 --> Security Class Initialized
DEBUG - 2024-01-30 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:25:46 --> Input Class Initialized
INFO - 2024-01-30 07:25:46 --> Language Class Initialized
INFO - 2024-01-30 07:25:46 --> Loader Class Initialized
INFO - 2024-01-30 07:25:46 --> Helper loaded: url_helper
INFO - 2024-01-30 07:25:46 --> Helper loaded: file_helper
INFO - 2024-01-30 07:25:46 --> Helper loaded: html_helper
INFO - 2024-01-30 07:25:46 --> Helper loaded: text_helper
INFO - 2024-01-30 07:25:46 --> Helper loaded: form_helper
INFO - 2024-01-30 07:25:46 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:25:46 --> Helper loaded: security_helper
INFO - 2024-01-30 07:25:46 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:25:46 --> Database Driver Class Initialized
INFO - 2024-01-30 07:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:25:46 --> Parser Class Initialized
INFO - 2024-01-30 07:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:25:46 --> Pagination Class Initialized
INFO - 2024-01-30 07:25:46 --> Form Validation Class Initialized
INFO - 2024-01-30 07:25:46 --> Controller Class Initialized
DEBUG - 2024-01-30 07:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:46 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:46 --> Model Class Initialized
INFO - 2024-01-30 07:25:46 --> Final output sent to browser
DEBUG - 2024-01-30 07:25:46 --> Total execution time: 0.0212
ERROR - 2024-01-30 07:25:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:25:52 --> Config Class Initialized
INFO - 2024-01-30 07:25:52 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:25:52 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:25:52 --> Utf8 Class Initialized
INFO - 2024-01-30 07:25:52 --> URI Class Initialized
INFO - 2024-01-30 07:25:52 --> Router Class Initialized
INFO - 2024-01-30 07:25:52 --> Output Class Initialized
INFO - 2024-01-30 07:25:52 --> Security Class Initialized
DEBUG - 2024-01-30 07:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:25:52 --> Input Class Initialized
INFO - 2024-01-30 07:25:52 --> Language Class Initialized
INFO - 2024-01-30 07:25:52 --> Loader Class Initialized
INFO - 2024-01-30 07:25:52 --> Helper loaded: url_helper
INFO - 2024-01-30 07:25:52 --> Helper loaded: file_helper
INFO - 2024-01-30 07:25:52 --> Helper loaded: html_helper
INFO - 2024-01-30 07:25:52 --> Helper loaded: text_helper
INFO - 2024-01-30 07:25:52 --> Helper loaded: form_helper
INFO - 2024-01-30 07:25:52 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:25:52 --> Helper loaded: security_helper
INFO - 2024-01-30 07:25:52 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:25:52 --> Database Driver Class Initialized
INFO - 2024-01-30 07:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:25:52 --> Parser Class Initialized
INFO - 2024-01-30 07:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:25:52 --> Pagination Class Initialized
INFO - 2024-01-30 07:25:52 --> Form Validation Class Initialized
INFO - 2024-01-30 07:25:52 --> Controller Class Initialized
DEBUG - 2024-01-30 07:25:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:52 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:52 --> Model Class Initialized
INFO - 2024-01-30 07:25:52 --> Final output sent to browser
DEBUG - 2024-01-30 07:25:52 --> Total execution time: 0.0298
ERROR - 2024-01-30 07:25:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:25:53 --> Config Class Initialized
INFO - 2024-01-30 07:25:53 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:25:53 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:25:53 --> Utf8 Class Initialized
INFO - 2024-01-30 07:25:53 --> URI Class Initialized
INFO - 2024-01-30 07:25:53 --> Router Class Initialized
INFO - 2024-01-30 07:25:53 --> Output Class Initialized
INFO - 2024-01-30 07:25:53 --> Security Class Initialized
DEBUG - 2024-01-30 07:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:25:53 --> Input Class Initialized
INFO - 2024-01-30 07:25:53 --> Language Class Initialized
INFO - 2024-01-30 07:25:53 --> Loader Class Initialized
INFO - 2024-01-30 07:25:53 --> Helper loaded: url_helper
INFO - 2024-01-30 07:25:53 --> Helper loaded: file_helper
INFO - 2024-01-30 07:25:53 --> Helper loaded: html_helper
INFO - 2024-01-30 07:25:53 --> Helper loaded: text_helper
INFO - 2024-01-30 07:25:53 --> Helper loaded: form_helper
INFO - 2024-01-30 07:25:53 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:25:53 --> Helper loaded: security_helper
INFO - 2024-01-30 07:25:53 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:25:53 --> Database Driver Class Initialized
INFO - 2024-01-30 07:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:25:53 --> Parser Class Initialized
INFO - 2024-01-30 07:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:25:53 --> Pagination Class Initialized
INFO - 2024-01-30 07:25:53 --> Form Validation Class Initialized
INFO - 2024-01-30 07:25:53 --> Controller Class Initialized
DEBUG - 2024-01-30 07:25:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:53 --> Model Class Initialized
DEBUG - 2024-01-30 07:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:25:53 --> Model Class Initialized
INFO - 2024-01-30 07:25:53 --> Final output sent to browser
DEBUG - 2024-01-30 07:25:53 --> Total execution time: 0.0165
ERROR - 2024-01-30 07:26:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:26:17 --> Config Class Initialized
INFO - 2024-01-30 07:26:17 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:26:17 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:26:17 --> Utf8 Class Initialized
INFO - 2024-01-30 07:26:17 --> URI Class Initialized
INFO - 2024-01-30 07:26:17 --> Router Class Initialized
INFO - 2024-01-30 07:26:17 --> Output Class Initialized
INFO - 2024-01-30 07:26:17 --> Security Class Initialized
DEBUG - 2024-01-30 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:26:17 --> Input Class Initialized
INFO - 2024-01-30 07:26:17 --> Language Class Initialized
INFO - 2024-01-30 07:26:17 --> Loader Class Initialized
INFO - 2024-01-30 07:26:17 --> Helper loaded: url_helper
INFO - 2024-01-30 07:26:17 --> Helper loaded: file_helper
INFO - 2024-01-30 07:26:17 --> Helper loaded: html_helper
INFO - 2024-01-30 07:26:17 --> Helper loaded: text_helper
INFO - 2024-01-30 07:26:17 --> Helper loaded: form_helper
INFO - 2024-01-30 07:26:17 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:26:17 --> Helper loaded: security_helper
INFO - 2024-01-30 07:26:17 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:26:17 --> Database Driver Class Initialized
INFO - 2024-01-30 07:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:26:17 --> Parser Class Initialized
INFO - 2024-01-30 07:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:26:17 --> Pagination Class Initialized
INFO - 2024-01-30 07:26:17 --> Form Validation Class Initialized
INFO - 2024-01-30 07:26:17 --> Controller Class Initialized
DEBUG - 2024-01-30 07:26:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:17 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:17 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:17 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:17 --> Model Class Initialized
INFO - 2024-01-30 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:26:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:26:17 --> Model Class Initialized
INFO - 2024-01-30 07:26:17 --> Model Class Initialized
INFO - 2024-01-30 07:26:17 --> Model Class Initialized
INFO - 2024-01-30 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:26:17 --> Final output sent to browser
DEBUG - 2024-01-30 07:26:17 --> Total execution time: 0.2100
ERROR - 2024-01-30 07:26:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:26:18 --> Config Class Initialized
INFO - 2024-01-30 07:26:18 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:26:18 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:26:18 --> Utf8 Class Initialized
INFO - 2024-01-30 07:26:18 --> URI Class Initialized
INFO - 2024-01-30 07:26:18 --> Router Class Initialized
INFO - 2024-01-30 07:26:18 --> Output Class Initialized
INFO - 2024-01-30 07:26:18 --> Security Class Initialized
DEBUG - 2024-01-30 07:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:26:18 --> Input Class Initialized
INFO - 2024-01-30 07:26:18 --> Language Class Initialized
INFO - 2024-01-30 07:26:18 --> Loader Class Initialized
INFO - 2024-01-30 07:26:18 --> Helper loaded: url_helper
INFO - 2024-01-30 07:26:18 --> Helper loaded: file_helper
INFO - 2024-01-30 07:26:18 --> Helper loaded: html_helper
INFO - 2024-01-30 07:26:18 --> Helper loaded: text_helper
INFO - 2024-01-30 07:26:18 --> Helper loaded: form_helper
INFO - 2024-01-30 07:26:18 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:26:18 --> Helper loaded: security_helper
INFO - 2024-01-30 07:26:18 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:26:18 --> Database Driver Class Initialized
INFO - 2024-01-30 07:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:26:18 --> Parser Class Initialized
INFO - 2024-01-30 07:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:26:18 --> Pagination Class Initialized
INFO - 2024-01-30 07:26:18 --> Form Validation Class Initialized
INFO - 2024-01-30 07:26:18 --> Controller Class Initialized
DEBUG - 2024-01-30 07:26:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:18 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:18 --> Model Class Initialized
INFO - 2024-01-30 07:26:18 --> Final output sent to browser
DEBUG - 2024-01-30 07:26:18 --> Total execution time: 0.0358
ERROR - 2024-01-30 07:26:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:26:26 --> Config Class Initialized
INFO - 2024-01-30 07:26:26 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:26:26 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:26:26 --> Utf8 Class Initialized
INFO - 2024-01-30 07:26:26 --> URI Class Initialized
INFO - 2024-01-30 07:26:26 --> Router Class Initialized
INFO - 2024-01-30 07:26:26 --> Output Class Initialized
INFO - 2024-01-30 07:26:26 --> Security Class Initialized
DEBUG - 2024-01-30 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:26:26 --> Input Class Initialized
INFO - 2024-01-30 07:26:26 --> Language Class Initialized
INFO - 2024-01-30 07:26:26 --> Loader Class Initialized
INFO - 2024-01-30 07:26:26 --> Helper loaded: url_helper
INFO - 2024-01-30 07:26:26 --> Helper loaded: file_helper
INFO - 2024-01-30 07:26:26 --> Helper loaded: html_helper
INFO - 2024-01-30 07:26:26 --> Helper loaded: text_helper
INFO - 2024-01-30 07:26:26 --> Helper loaded: form_helper
INFO - 2024-01-30 07:26:26 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:26:26 --> Helper loaded: security_helper
INFO - 2024-01-30 07:26:26 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:26:26 --> Database Driver Class Initialized
INFO - 2024-01-30 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:26:26 --> Parser Class Initialized
INFO - 2024-01-30 07:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:26:26 --> Pagination Class Initialized
INFO - 2024-01-30 07:26:26 --> Form Validation Class Initialized
INFO - 2024-01-30 07:26:26 --> Controller Class Initialized
DEBUG - 2024-01-30 07:26:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:26 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:26 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:26 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:26 --> Model Class Initialized
INFO - 2024-01-30 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:26:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:26:26 --> Model Class Initialized
INFO - 2024-01-30 07:26:26 --> Model Class Initialized
INFO - 2024-01-30 07:26:26 --> Model Class Initialized
INFO - 2024-01-30 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:26:26 --> Final output sent to browser
DEBUG - 2024-01-30 07:26:26 --> Total execution time: 0.2055
ERROR - 2024-01-30 07:26:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:26:27 --> Config Class Initialized
INFO - 2024-01-30 07:26:27 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:26:27 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:26:27 --> Utf8 Class Initialized
INFO - 2024-01-30 07:26:27 --> URI Class Initialized
INFO - 2024-01-30 07:26:27 --> Router Class Initialized
INFO - 2024-01-30 07:26:27 --> Output Class Initialized
INFO - 2024-01-30 07:26:27 --> Security Class Initialized
DEBUG - 2024-01-30 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:26:27 --> Input Class Initialized
INFO - 2024-01-30 07:26:27 --> Language Class Initialized
INFO - 2024-01-30 07:26:27 --> Loader Class Initialized
INFO - 2024-01-30 07:26:27 --> Helper loaded: url_helper
INFO - 2024-01-30 07:26:27 --> Helper loaded: file_helper
INFO - 2024-01-30 07:26:27 --> Helper loaded: html_helper
INFO - 2024-01-30 07:26:27 --> Helper loaded: text_helper
INFO - 2024-01-30 07:26:27 --> Helper loaded: form_helper
INFO - 2024-01-30 07:26:27 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:26:27 --> Helper loaded: security_helper
INFO - 2024-01-30 07:26:27 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:26:27 --> Database Driver Class Initialized
INFO - 2024-01-30 07:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:26:27 --> Parser Class Initialized
INFO - 2024-01-30 07:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:26:27 --> Pagination Class Initialized
INFO - 2024-01-30 07:26:27 --> Form Validation Class Initialized
INFO - 2024-01-30 07:26:27 --> Controller Class Initialized
DEBUG - 2024-01-30 07:26:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:27 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:27 --> Model Class Initialized
INFO - 2024-01-30 07:26:27 --> Final output sent to browser
DEBUG - 2024-01-30 07:26:27 --> Total execution time: 0.0330
ERROR - 2024-01-30 07:26:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:26:30 --> Config Class Initialized
INFO - 2024-01-30 07:26:30 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:26:30 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:26:30 --> Utf8 Class Initialized
INFO - 2024-01-30 07:26:30 --> URI Class Initialized
INFO - 2024-01-30 07:26:30 --> Router Class Initialized
INFO - 2024-01-30 07:26:30 --> Output Class Initialized
INFO - 2024-01-30 07:26:30 --> Security Class Initialized
DEBUG - 2024-01-30 07:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:26:30 --> Input Class Initialized
INFO - 2024-01-30 07:26:30 --> Language Class Initialized
INFO - 2024-01-30 07:26:30 --> Loader Class Initialized
INFO - 2024-01-30 07:26:30 --> Helper loaded: url_helper
INFO - 2024-01-30 07:26:30 --> Helper loaded: file_helper
INFO - 2024-01-30 07:26:30 --> Helper loaded: html_helper
INFO - 2024-01-30 07:26:30 --> Helper loaded: text_helper
INFO - 2024-01-30 07:26:30 --> Helper loaded: form_helper
INFO - 2024-01-30 07:26:30 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:26:30 --> Helper loaded: security_helper
INFO - 2024-01-30 07:26:30 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:26:30 --> Database Driver Class Initialized
INFO - 2024-01-30 07:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:26:30 --> Parser Class Initialized
INFO - 2024-01-30 07:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:26:30 --> Pagination Class Initialized
INFO - 2024-01-30 07:26:30 --> Form Validation Class Initialized
INFO - 2024-01-30 07:26:30 --> Controller Class Initialized
INFO - 2024-01-30 07:26:30 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 07:26:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:26:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:26:30 --> Model Class Initialized
INFO - 2024-01-30 07:26:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:26:30 --> Final output sent to browser
DEBUG - 2024-01-30 07:26:30 --> Total execution time: 0.0299
ERROR - 2024-01-30 07:26:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:26:31 --> Config Class Initialized
INFO - 2024-01-30 07:26:31 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:26:31 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:26:31 --> Utf8 Class Initialized
INFO - 2024-01-30 07:26:31 --> URI Class Initialized
INFO - 2024-01-30 07:26:31 --> Router Class Initialized
INFO - 2024-01-30 07:26:31 --> Output Class Initialized
INFO - 2024-01-30 07:26:31 --> Security Class Initialized
DEBUG - 2024-01-30 07:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:26:31 --> Input Class Initialized
INFO - 2024-01-30 07:26:31 --> Language Class Initialized
INFO - 2024-01-30 07:26:31 --> Loader Class Initialized
INFO - 2024-01-30 07:26:31 --> Helper loaded: url_helper
INFO - 2024-01-30 07:26:31 --> Helper loaded: file_helper
INFO - 2024-01-30 07:26:31 --> Helper loaded: html_helper
INFO - 2024-01-30 07:26:31 --> Helper loaded: text_helper
INFO - 2024-01-30 07:26:31 --> Helper loaded: form_helper
INFO - 2024-01-30 07:26:31 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:26:31 --> Helper loaded: security_helper
INFO - 2024-01-30 07:26:31 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:26:31 --> Database Driver Class Initialized
INFO - 2024-01-30 07:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:26:31 --> Parser Class Initialized
INFO - 2024-01-30 07:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:26:31 --> Pagination Class Initialized
INFO - 2024-01-30 07:26:31 --> Form Validation Class Initialized
INFO - 2024-01-30 07:26:31 --> Controller Class Initialized
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
INFO - 2024-01-30 07:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 07:26:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:26:31 --> Model Class Initialized
INFO - 2024-01-30 07:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:26:31 --> Final output sent to browser
DEBUG - 2024-01-30 07:26:31 --> Total execution time: 0.2293
ERROR - 2024-01-30 07:26:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:26:35 --> Config Class Initialized
INFO - 2024-01-30 07:26:35 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:26:35 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:26:35 --> Utf8 Class Initialized
INFO - 2024-01-30 07:26:35 --> URI Class Initialized
INFO - 2024-01-30 07:26:35 --> Router Class Initialized
INFO - 2024-01-30 07:26:35 --> Output Class Initialized
INFO - 2024-01-30 07:26:35 --> Security Class Initialized
DEBUG - 2024-01-30 07:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:26:35 --> Input Class Initialized
INFO - 2024-01-30 07:26:35 --> Language Class Initialized
INFO - 2024-01-30 07:26:35 --> Loader Class Initialized
INFO - 2024-01-30 07:26:35 --> Helper loaded: url_helper
INFO - 2024-01-30 07:26:35 --> Helper loaded: file_helper
INFO - 2024-01-30 07:26:35 --> Helper loaded: html_helper
INFO - 2024-01-30 07:26:35 --> Helper loaded: text_helper
INFO - 2024-01-30 07:26:35 --> Helper loaded: form_helper
INFO - 2024-01-30 07:26:35 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:26:35 --> Helper loaded: security_helper
INFO - 2024-01-30 07:26:35 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:26:35 --> Database Driver Class Initialized
INFO - 2024-01-30 07:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:26:35 --> Parser Class Initialized
INFO - 2024-01-30 07:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:26:35 --> Pagination Class Initialized
INFO - 2024-01-30 07:26:35 --> Form Validation Class Initialized
INFO - 2024-01-30 07:26:35 --> Controller Class Initialized
DEBUG - 2024-01-30 07:26:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:35 --> Model Class Initialized
DEBUG - 2024-01-30 07:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:26:35 --> Model Class Initialized
INFO - 2024-01-30 07:26:35 --> Final output sent to browser
DEBUG - 2024-01-30 07:26:35 --> Total execution time: 0.1928
ERROR - 2024-01-30 07:27:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:27:17 --> Config Class Initialized
INFO - 2024-01-30 07:27:17 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:27:17 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:27:17 --> Utf8 Class Initialized
INFO - 2024-01-30 07:27:17 --> URI Class Initialized
INFO - 2024-01-30 07:27:17 --> Router Class Initialized
INFO - 2024-01-30 07:27:17 --> Output Class Initialized
INFO - 2024-01-30 07:27:17 --> Security Class Initialized
DEBUG - 2024-01-30 07:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:27:17 --> Input Class Initialized
INFO - 2024-01-30 07:27:17 --> Language Class Initialized
INFO - 2024-01-30 07:27:17 --> Loader Class Initialized
INFO - 2024-01-30 07:27:17 --> Helper loaded: url_helper
INFO - 2024-01-30 07:27:17 --> Helper loaded: file_helper
INFO - 2024-01-30 07:27:17 --> Helper loaded: html_helper
INFO - 2024-01-30 07:27:17 --> Helper loaded: text_helper
INFO - 2024-01-30 07:27:17 --> Helper loaded: form_helper
INFO - 2024-01-30 07:27:17 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:27:17 --> Helper loaded: security_helper
INFO - 2024-01-30 07:27:17 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:27:17 --> Database Driver Class Initialized
INFO - 2024-01-30 07:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:27:17 --> Parser Class Initialized
INFO - 2024-01-30 07:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:27:17 --> Pagination Class Initialized
INFO - 2024-01-30 07:27:17 --> Form Validation Class Initialized
INFO - 2024-01-30 07:27:17 --> Controller Class Initialized
DEBUG - 2024-01-30 07:27:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:17 --> Model Class Initialized
DEBUG - 2024-01-30 07:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:17 --> Model Class Initialized
DEBUG - 2024-01-30 07:27:17 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:17 --> Model Class Initialized
INFO - 2024-01-30 07:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:27:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:27:17 --> Model Class Initialized
INFO - 2024-01-30 07:27:17 --> Model Class Initialized
INFO - 2024-01-30 07:27:17 --> Model Class Initialized
INFO - 2024-01-30 07:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:27:17 --> Final output sent to browser
DEBUG - 2024-01-30 07:27:17 --> Total execution time: 0.2405
ERROR - 2024-01-30 07:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:27:18 --> Config Class Initialized
INFO - 2024-01-30 07:27:18 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:27:18 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:27:18 --> Utf8 Class Initialized
INFO - 2024-01-30 07:27:18 --> URI Class Initialized
INFO - 2024-01-30 07:27:18 --> Router Class Initialized
INFO - 2024-01-30 07:27:18 --> Output Class Initialized
INFO - 2024-01-30 07:27:18 --> Security Class Initialized
DEBUG - 2024-01-30 07:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:27:18 --> Input Class Initialized
INFO - 2024-01-30 07:27:18 --> Language Class Initialized
INFO - 2024-01-30 07:27:18 --> Loader Class Initialized
INFO - 2024-01-30 07:27:18 --> Helper loaded: url_helper
INFO - 2024-01-30 07:27:18 --> Helper loaded: file_helper
INFO - 2024-01-30 07:27:18 --> Helper loaded: html_helper
INFO - 2024-01-30 07:27:18 --> Helper loaded: text_helper
INFO - 2024-01-30 07:27:18 --> Helper loaded: form_helper
INFO - 2024-01-30 07:27:18 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:27:18 --> Helper loaded: security_helper
INFO - 2024-01-30 07:27:18 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:27:18 --> Database Driver Class Initialized
INFO - 2024-01-30 07:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:27:18 --> Parser Class Initialized
INFO - 2024-01-30 07:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:27:18 --> Pagination Class Initialized
INFO - 2024-01-30 07:27:18 --> Form Validation Class Initialized
INFO - 2024-01-30 07:27:18 --> Controller Class Initialized
DEBUG - 2024-01-30 07:27:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:18 --> Model Class Initialized
DEBUG - 2024-01-30 07:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:18 --> Model Class Initialized
INFO - 2024-01-30 07:27:18 --> Final output sent to browser
DEBUG - 2024-01-30 07:27:18 --> Total execution time: 0.0371
ERROR - 2024-01-30 07:27:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:27:36 --> Config Class Initialized
INFO - 2024-01-30 07:27:36 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:27:36 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:27:36 --> Utf8 Class Initialized
INFO - 2024-01-30 07:27:36 --> URI Class Initialized
INFO - 2024-01-30 07:27:36 --> Router Class Initialized
INFO - 2024-01-30 07:27:36 --> Output Class Initialized
INFO - 2024-01-30 07:27:36 --> Security Class Initialized
DEBUG - 2024-01-30 07:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:27:36 --> Input Class Initialized
INFO - 2024-01-30 07:27:36 --> Language Class Initialized
INFO - 2024-01-30 07:27:36 --> Loader Class Initialized
INFO - 2024-01-30 07:27:36 --> Helper loaded: url_helper
INFO - 2024-01-30 07:27:36 --> Helper loaded: file_helper
INFO - 2024-01-30 07:27:36 --> Helper loaded: html_helper
INFO - 2024-01-30 07:27:36 --> Helper loaded: text_helper
INFO - 2024-01-30 07:27:36 --> Helper loaded: form_helper
INFO - 2024-01-30 07:27:36 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:27:36 --> Helper loaded: security_helper
INFO - 2024-01-30 07:27:36 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:27:36 --> Database Driver Class Initialized
INFO - 2024-01-30 07:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:27:36 --> Parser Class Initialized
INFO - 2024-01-30 07:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:27:36 --> Pagination Class Initialized
INFO - 2024-01-30 07:27:36 --> Form Validation Class Initialized
INFO - 2024-01-30 07:27:36 --> Controller Class Initialized
DEBUG - 2024-01-30 07:27:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:36 --> Model Class Initialized
DEBUG - 2024-01-30 07:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:36 --> Model Class Initialized
DEBUG - 2024-01-30 07:27:36 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:36 --> Model Class Initialized
INFO - 2024-01-30 07:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:27:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:27:36 --> Model Class Initialized
INFO - 2024-01-30 07:27:36 --> Model Class Initialized
INFO - 2024-01-30 07:27:36 --> Model Class Initialized
INFO - 2024-01-30 07:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:27:36 --> Final output sent to browser
DEBUG - 2024-01-30 07:27:36 --> Total execution time: 0.1489
ERROR - 2024-01-30 07:27:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:27:37 --> Config Class Initialized
INFO - 2024-01-30 07:27:37 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:27:37 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:27:37 --> Utf8 Class Initialized
INFO - 2024-01-30 07:27:37 --> URI Class Initialized
INFO - 2024-01-30 07:27:37 --> Router Class Initialized
INFO - 2024-01-30 07:27:37 --> Output Class Initialized
INFO - 2024-01-30 07:27:37 --> Security Class Initialized
DEBUG - 2024-01-30 07:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:27:37 --> Input Class Initialized
INFO - 2024-01-30 07:27:37 --> Language Class Initialized
INFO - 2024-01-30 07:27:37 --> Loader Class Initialized
INFO - 2024-01-30 07:27:37 --> Helper loaded: url_helper
INFO - 2024-01-30 07:27:37 --> Helper loaded: file_helper
INFO - 2024-01-30 07:27:37 --> Helper loaded: html_helper
INFO - 2024-01-30 07:27:37 --> Helper loaded: text_helper
INFO - 2024-01-30 07:27:37 --> Helper loaded: form_helper
INFO - 2024-01-30 07:27:37 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:27:37 --> Helper loaded: security_helper
INFO - 2024-01-30 07:27:37 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:27:37 --> Database Driver Class Initialized
INFO - 2024-01-30 07:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:27:37 --> Parser Class Initialized
INFO - 2024-01-30 07:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:27:37 --> Pagination Class Initialized
INFO - 2024-01-30 07:27:37 --> Form Validation Class Initialized
INFO - 2024-01-30 07:27:37 --> Controller Class Initialized
DEBUG - 2024-01-30 07:27:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:37 --> Model Class Initialized
DEBUG - 2024-01-30 07:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:37 --> Model Class Initialized
INFO - 2024-01-30 07:27:37 --> Final output sent to browser
DEBUG - 2024-01-30 07:27:37 --> Total execution time: 0.0272
ERROR - 2024-01-30 07:27:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:27:43 --> Config Class Initialized
INFO - 2024-01-30 07:27:43 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:27:43 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:27:43 --> Utf8 Class Initialized
INFO - 2024-01-30 07:27:43 --> URI Class Initialized
INFO - 2024-01-30 07:27:43 --> Router Class Initialized
INFO - 2024-01-30 07:27:43 --> Output Class Initialized
INFO - 2024-01-30 07:27:43 --> Security Class Initialized
DEBUG - 2024-01-30 07:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:27:43 --> Input Class Initialized
INFO - 2024-01-30 07:27:43 --> Language Class Initialized
INFO - 2024-01-30 07:27:43 --> Loader Class Initialized
INFO - 2024-01-30 07:27:43 --> Helper loaded: url_helper
INFO - 2024-01-30 07:27:43 --> Helper loaded: file_helper
INFO - 2024-01-30 07:27:43 --> Helper loaded: html_helper
INFO - 2024-01-30 07:27:43 --> Helper loaded: text_helper
INFO - 2024-01-30 07:27:43 --> Helper loaded: form_helper
INFO - 2024-01-30 07:27:43 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:27:43 --> Helper loaded: security_helper
INFO - 2024-01-30 07:27:43 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:27:43 --> Database Driver Class Initialized
INFO - 2024-01-30 07:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:27:43 --> Parser Class Initialized
INFO - 2024-01-30 07:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:27:43 --> Pagination Class Initialized
INFO - 2024-01-30 07:27:43 --> Form Validation Class Initialized
INFO - 2024-01-30 07:27:43 --> Controller Class Initialized
DEBUG - 2024-01-30 07:27:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:43 --> Model Class Initialized
DEBUG - 2024-01-30 07:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:27:43 --> Model Class Initialized
INFO - 2024-01-30 07:27:43 --> Final output sent to browser
DEBUG - 2024-01-30 07:27:43 --> Total execution time: 0.0259
ERROR - 2024-01-30 07:28:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:28:02 --> Config Class Initialized
INFO - 2024-01-30 07:28:02 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:28:02 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:28:02 --> Utf8 Class Initialized
INFO - 2024-01-30 07:28:02 --> URI Class Initialized
INFO - 2024-01-30 07:28:02 --> Router Class Initialized
INFO - 2024-01-30 07:28:02 --> Output Class Initialized
INFO - 2024-01-30 07:28:02 --> Security Class Initialized
DEBUG - 2024-01-30 07:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:28:02 --> Input Class Initialized
INFO - 2024-01-30 07:28:02 --> Language Class Initialized
INFO - 2024-01-30 07:28:02 --> Loader Class Initialized
INFO - 2024-01-30 07:28:02 --> Helper loaded: url_helper
INFO - 2024-01-30 07:28:02 --> Helper loaded: file_helper
INFO - 2024-01-30 07:28:02 --> Helper loaded: html_helper
INFO - 2024-01-30 07:28:02 --> Helper loaded: text_helper
INFO - 2024-01-30 07:28:02 --> Helper loaded: form_helper
INFO - 2024-01-30 07:28:02 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:28:02 --> Helper loaded: security_helper
INFO - 2024-01-30 07:28:02 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:28:02 --> Database Driver Class Initialized
INFO - 2024-01-30 07:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:28:02 --> Parser Class Initialized
INFO - 2024-01-30 07:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:28:02 --> Pagination Class Initialized
INFO - 2024-01-30 07:28:02 --> Form Validation Class Initialized
INFO - 2024-01-30 07:28:02 --> Controller Class Initialized
DEBUG - 2024-01-30 07:28:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:02 --> Model Class Initialized
DEBUG - 2024-01-30 07:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:02 --> Model Class Initialized
DEBUG - 2024-01-30 07:28:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:02 --> Model Class Initialized
INFO - 2024-01-30 07:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-30 07:28:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:28:02 --> Model Class Initialized
INFO - 2024-01-30 07:28:02 --> Model Class Initialized
INFO - 2024-01-30 07:28:02 --> Model Class Initialized
INFO - 2024-01-30 07:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:28:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:28:02 --> Final output sent to browser
DEBUG - 2024-01-30 07:28:02 --> Total execution time: 0.2072
ERROR - 2024-01-30 07:28:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:28:03 --> Config Class Initialized
INFO - 2024-01-30 07:28:03 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:28:03 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:28:03 --> Utf8 Class Initialized
INFO - 2024-01-30 07:28:03 --> URI Class Initialized
INFO - 2024-01-30 07:28:03 --> Router Class Initialized
INFO - 2024-01-30 07:28:03 --> Output Class Initialized
INFO - 2024-01-30 07:28:03 --> Security Class Initialized
DEBUG - 2024-01-30 07:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:28:03 --> Input Class Initialized
INFO - 2024-01-30 07:28:03 --> Language Class Initialized
INFO - 2024-01-30 07:28:03 --> Loader Class Initialized
INFO - 2024-01-30 07:28:03 --> Helper loaded: url_helper
INFO - 2024-01-30 07:28:03 --> Helper loaded: file_helper
INFO - 2024-01-30 07:28:03 --> Helper loaded: html_helper
INFO - 2024-01-30 07:28:03 --> Helper loaded: text_helper
INFO - 2024-01-30 07:28:03 --> Helper loaded: form_helper
INFO - 2024-01-30 07:28:03 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:28:03 --> Helper loaded: security_helper
INFO - 2024-01-30 07:28:03 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:28:03 --> Database Driver Class Initialized
INFO - 2024-01-30 07:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:28:03 --> Parser Class Initialized
INFO - 2024-01-30 07:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:28:03 --> Pagination Class Initialized
INFO - 2024-01-30 07:28:03 --> Form Validation Class Initialized
INFO - 2024-01-30 07:28:03 --> Controller Class Initialized
DEBUG - 2024-01-30 07:28:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:03 --> Model Class Initialized
DEBUG - 2024-01-30 07:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:03 --> Model Class Initialized
INFO - 2024-01-30 07:28:03 --> Final output sent to browser
DEBUG - 2024-01-30 07:28:03 --> Total execution time: 0.0308
ERROR - 2024-01-30 07:28:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 07:28:18 --> Config Class Initialized
INFO - 2024-01-30 07:28:18 --> Hooks Class Initialized
DEBUG - 2024-01-30 07:28:18 --> UTF-8 Support Enabled
INFO - 2024-01-30 07:28:18 --> Utf8 Class Initialized
INFO - 2024-01-30 07:28:18 --> URI Class Initialized
INFO - 2024-01-30 07:28:18 --> Router Class Initialized
INFO - 2024-01-30 07:28:18 --> Output Class Initialized
INFO - 2024-01-30 07:28:18 --> Security Class Initialized
DEBUG - 2024-01-30 07:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 07:28:18 --> Input Class Initialized
INFO - 2024-01-30 07:28:18 --> Language Class Initialized
INFO - 2024-01-30 07:28:18 --> Loader Class Initialized
INFO - 2024-01-30 07:28:18 --> Helper loaded: url_helper
INFO - 2024-01-30 07:28:18 --> Helper loaded: file_helper
INFO - 2024-01-30 07:28:18 --> Helper loaded: html_helper
INFO - 2024-01-30 07:28:18 --> Helper loaded: text_helper
INFO - 2024-01-30 07:28:18 --> Helper loaded: form_helper
INFO - 2024-01-30 07:28:18 --> Helper loaded: lang_helper
INFO - 2024-01-30 07:28:18 --> Helper loaded: security_helper
INFO - 2024-01-30 07:28:18 --> Helper loaded: cookie_helper
INFO - 2024-01-30 07:28:18 --> Database Driver Class Initialized
INFO - 2024-01-30 07:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 07:28:18 --> Parser Class Initialized
INFO - 2024-01-30 07:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 07:28:18 --> Pagination Class Initialized
INFO - 2024-01-30 07:28:18 --> Form Validation Class Initialized
INFO - 2024-01-30 07:28:18 --> Controller Class Initialized
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
DEBUG - 2024-01-30 07:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
DEBUG - 2024-01-30 07:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
DEBUG - 2024-01-30 07:28:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 07:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
INFO - 2024-01-30 07:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 07:28:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 07:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 07:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 07:28:18 --> Model Class Initialized
INFO - 2024-01-30 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 07:28:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 07:28:19 --> Final output sent to browser
DEBUG - 2024-01-30 07:28:19 --> Total execution time: 0.4038
ERROR - 2024-01-30 08:33:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:11 --> Config Class Initialized
INFO - 2024-01-30 08:33:11 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:11 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:11 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:11 --> URI Class Initialized
DEBUG - 2024-01-30 08:33:11 --> No URI present. Default controller set.
INFO - 2024-01-30 08:33:11 --> Router Class Initialized
INFO - 2024-01-30 08:33:11 --> Output Class Initialized
INFO - 2024-01-30 08:33:11 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:11 --> Input Class Initialized
INFO - 2024-01-30 08:33:11 --> Language Class Initialized
INFO - 2024-01-30 08:33:11 --> Loader Class Initialized
INFO - 2024-01-30 08:33:11 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:11 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:11 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:11 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:11 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:11 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:11 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:11 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:11 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:11 --> Parser Class Initialized
INFO - 2024-01-30 08:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:11 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:11 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:11 --> Controller Class Initialized
INFO - 2024-01-30 08:33:11 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 08:33:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:12 --> Config Class Initialized
INFO - 2024-01-30 08:33:12 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:12 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:12 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:12 --> URI Class Initialized
INFO - 2024-01-30 08:33:12 --> Router Class Initialized
INFO - 2024-01-30 08:33:12 --> Output Class Initialized
INFO - 2024-01-30 08:33:12 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:12 --> Input Class Initialized
INFO - 2024-01-30 08:33:12 --> Language Class Initialized
INFO - 2024-01-30 08:33:12 --> Loader Class Initialized
INFO - 2024-01-30 08:33:12 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:12 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:12 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:12 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:12 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:12 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:12 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:12 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:12 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:12 --> Parser Class Initialized
INFO - 2024-01-30 08:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:12 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:12 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:12 --> Controller Class Initialized
INFO - 2024-01-30 08:33:12 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 08:33:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 08:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 08:33:12 --> Model Class Initialized
INFO - 2024-01-30 08:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 08:33:12 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:12 --> Total execution time: 0.0387
ERROR - 2024-01-30 08:33:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:30 --> Config Class Initialized
INFO - 2024-01-30 08:33:30 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:30 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:30 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:30 --> URI Class Initialized
INFO - 2024-01-30 08:33:30 --> Router Class Initialized
INFO - 2024-01-30 08:33:30 --> Output Class Initialized
INFO - 2024-01-30 08:33:30 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:30 --> Input Class Initialized
INFO - 2024-01-30 08:33:30 --> Language Class Initialized
INFO - 2024-01-30 08:33:30 --> Loader Class Initialized
INFO - 2024-01-30 08:33:30 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:30 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:30 --> Parser Class Initialized
INFO - 2024-01-30 08:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:30 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:30 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:30 --> Controller Class Initialized
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
INFO - 2024-01-30 08:33:30 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:30 --> Total execution time: 0.0241
ERROR - 2024-01-30 08:33:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:30 --> Config Class Initialized
INFO - 2024-01-30 08:33:30 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:30 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:30 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:30 --> URI Class Initialized
DEBUG - 2024-01-30 08:33:30 --> No URI present. Default controller set.
INFO - 2024-01-30 08:33:30 --> Router Class Initialized
INFO - 2024-01-30 08:33:30 --> Output Class Initialized
INFO - 2024-01-30 08:33:30 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:30 --> Input Class Initialized
INFO - 2024-01-30 08:33:30 --> Language Class Initialized
INFO - 2024-01-30 08:33:30 --> Loader Class Initialized
INFO - 2024-01-30 08:33:30 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:30 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:30 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:30 --> Parser Class Initialized
INFO - 2024-01-30 08:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:30 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:30 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:30 --> Controller Class Initialized
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
INFO - 2024-01-30 08:33:30 --> Model Class Initialized
INFO - 2024-01-30 08:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 08:33:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 08:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 08:33:31 --> Model Class Initialized
INFO - 2024-01-30 08:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 08:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 08:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 08:33:31 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:31 --> Total execution time: 0.2458
ERROR - 2024-01-30 08:33:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:39 --> Config Class Initialized
INFO - 2024-01-30 08:33:39 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:39 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:39 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:39 --> URI Class Initialized
INFO - 2024-01-30 08:33:39 --> Router Class Initialized
INFO - 2024-01-30 08:33:39 --> Output Class Initialized
INFO - 2024-01-30 08:33:39 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:39 --> Input Class Initialized
INFO - 2024-01-30 08:33:39 --> Language Class Initialized
INFO - 2024-01-30 08:33:39 --> Loader Class Initialized
INFO - 2024-01-30 08:33:39 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:39 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:39 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:39 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:39 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:39 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:39 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:39 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:39 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:39 --> Parser Class Initialized
INFO - 2024-01-30 08:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:39 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:39 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:39 --> Controller Class Initialized
INFO - 2024-01-30 08:33:39 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:39 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:39 --> Model Class Initialized
INFO - 2024-01-30 08:33:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-30 08:33:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 08:33:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 08:33:39 --> Model Class Initialized
INFO - 2024-01-30 08:33:39 --> Model Class Initialized
INFO - 2024-01-30 08:33:39 --> Model Class Initialized
INFO - 2024-01-30 08:33:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 08:33:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 08:33:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 08:33:39 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:39 --> Total execution time: 0.1490
ERROR - 2024-01-30 08:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:40 --> Config Class Initialized
INFO - 2024-01-30 08:33:40 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:40 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:40 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:40 --> URI Class Initialized
INFO - 2024-01-30 08:33:40 --> Router Class Initialized
INFO - 2024-01-30 08:33:40 --> Output Class Initialized
INFO - 2024-01-30 08:33:40 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:40 --> Input Class Initialized
INFO - 2024-01-30 08:33:40 --> Language Class Initialized
INFO - 2024-01-30 08:33:40 --> Loader Class Initialized
INFO - 2024-01-30 08:33:40 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:40 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:40 --> Parser Class Initialized
INFO - 2024-01-30 08:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:40 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:40 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:40 --> Controller Class Initialized
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
INFO - 2024-01-30 08:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-30 08:33:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 08:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
INFO - 2024-01-30 08:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 08:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 08:33:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 08:33:40 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:40 --> Total execution time: 0.1502
ERROR - 2024-01-30 08:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:40 --> Config Class Initialized
INFO - 2024-01-30 08:33:40 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:40 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:40 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:40 --> URI Class Initialized
INFO - 2024-01-30 08:33:40 --> Router Class Initialized
INFO - 2024-01-30 08:33:40 --> Output Class Initialized
INFO - 2024-01-30 08:33:40 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:40 --> Input Class Initialized
INFO - 2024-01-30 08:33:40 --> Language Class Initialized
INFO - 2024-01-30 08:33:40 --> Loader Class Initialized
INFO - 2024-01-30 08:33:40 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:40 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:40 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:40 --> Parser Class Initialized
INFO - 2024-01-30 08:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:40 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:40 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:40 --> Controller Class Initialized
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:40 --> Model Class Initialized
INFO - 2024-01-30 08:33:40 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:40 --> Total execution time: 0.0432
ERROR - 2024-01-30 08:33:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:43 --> Config Class Initialized
INFO - 2024-01-30 08:33:43 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:43 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:43 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:43 --> URI Class Initialized
INFO - 2024-01-30 08:33:43 --> Router Class Initialized
INFO - 2024-01-30 08:33:43 --> Output Class Initialized
INFO - 2024-01-30 08:33:43 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:43 --> Input Class Initialized
INFO - 2024-01-30 08:33:43 --> Language Class Initialized
INFO - 2024-01-30 08:33:43 --> Loader Class Initialized
INFO - 2024-01-30 08:33:43 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:43 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:43 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:43 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:43 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:43 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:43 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:43 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:43 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:43 --> Parser Class Initialized
INFO - 2024-01-30 08:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:43 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:43 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:43 --> Controller Class Initialized
INFO - 2024-01-30 08:33:43 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:43 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:43 --> Model Class Initialized
INFO - 2024-01-30 08:33:43 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:43 --> Total execution time: 0.0389
ERROR - 2024-01-30 08:33:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:44 --> Config Class Initialized
INFO - 2024-01-30 08:33:44 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:44 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:44 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:44 --> URI Class Initialized
INFO - 2024-01-30 08:33:44 --> Router Class Initialized
INFO - 2024-01-30 08:33:44 --> Output Class Initialized
INFO - 2024-01-30 08:33:44 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:44 --> Input Class Initialized
INFO - 2024-01-30 08:33:44 --> Language Class Initialized
INFO - 2024-01-30 08:33:44 --> Loader Class Initialized
INFO - 2024-01-30 08:33:44 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:44 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:44 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:44 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:44 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:44 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:44 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:44 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:44 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:44 --> Parser Class Initialized
INFO - 2024-01-30 08:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:44 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:44 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:44 --> Controller Class Initialized
INFO - 2024-01-30 08:33:44 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:44 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:44 --> Model Class Initialized
INFO - 2024-01-30 08:33:44 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:44 --> Total execution time: 0.0399
ERROR - 2024-01-30 08:33:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:46 --> Config Class Initialized
INFO - 2024-01-30 08:33:46 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:46 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:46 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:46 --> URI Class Initialized
INFO - 2024-01-30 08:33:46 --> Router Class Initialized
INFO - 2024-01-30 08:33:46 --> Output Class Initialized
INFO - 2024-01-30 08:33:46 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:46 --> Input Class Initialized
INFO - 2024-01-30 08:33:46 --> Language Class Initialized
INFO - 2024-01-30 08:33:46 --> Loader Class Initialized
INFO - 2024-01-30 08:33:46 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:46 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:46 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:46 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:46 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:46 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:46 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:46 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:46 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:46 --> Parser Class Initialized
INFO - 2024-01-30 08:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:46 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:46 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:46 --> Controller Class Initialized
INFO - 2024-01-30 08:33:46 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:46 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:46 --> Model Class Initialized
INFO - 2024-01-30 08:33:46 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:46 --> Total execution time: 0.0246
ERROR - 2024-01-30 08:33:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 08:33:59 --> Config Class Initialized
INFO - 2024-01-30 08:33:59 --> Hooks Class Initialized
DEBUG - 2024-01-30 08:33:59 --> UTF-8 Support Enabled
INFO - 2024-01-30 08:33:59 --> Utf8 Class Initialized
INFO - 2024-01-30 08:33:59 --> URI Class Initialized
INFO - 2024-01-30 08:33:59 --> Router Class Initialized
INFO - 2024-01-30 08:33:59 --> Output Class Initialized
INFO - 2024-01-30 08:33:59 --> Security Class Initialized
DEBUG - 2024-01-30 08:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 08:33:59 --> Input Class Initialized
INFO - 2024-01-30 08:33:59 --> Language Class Initialized
INFO - 2024-01-30 08:33:59 --> Loader Class Initialized
INFO - 2024-01-30 08:33:59 --> Helper loaded: url_helper
INFO - 2024-01-30 08:33:59 --> Helper loaded: file_helper
INFO - 2024-01-30 08:33:59 --> Helper loaded: html_helper
INFO - 2024-01-30 08:33:59 --> Helper loaded: text_helper
INFO - 2024-01-30 08:33:59 --> Helper loaded: form_helper
INFO - 2024-01-30 08:33:59 --> Helper loaded: lang_helper
INFO - 2024-01-30 08:33:59 --> Helper loaded: security_helper
INFO - 2024-01-30 08:33:59 --> Helper loaded: cookie_helper
INFO - 2024-01-30 08:33:59 --> Database Driver Class Initialized
INFO - 2024-01-30 08:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 08:33:59 --> Parser Class Initialized
INFO - 2024-01-30 08:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 08:33:59 --> Pagination Class Initialized
INFO - 2024-01-30 08:33:59 --> Form Validation Class Initialized
INFO - 2024-01-30 08:33:59 --> Controller Class Initialized
INFO - 2024-01-30 08:33:59 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 08:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:59 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:59 --> Model Class Initialized
DEBUG - 2024-01-30 08:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-30 08:33:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 08:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 08:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 08:33:59 --> Model Class Initialized
INFO - 2024-01-30 08:33:59 --> Model Class Initialized
INFO - 2024-01-30 08:33:59 --> Model Class Initialized
INFO - 2024-01-30 08:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 08:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 08:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 08:33:59 --> Final output sent to browser
DEBUG - 2024-01-30 08:33:59 --> Total execution time: 0.1485
ERROR - 2024-01-30 09:58:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 09:58:24 --> Config Class Initialized
INFO - 2024-01-30 09:58:24 --> Hooks Class Initialized
DEBUG - 2024-01-30 09:58:24 --> UTF-8 Support Enabled
INFO - 2024-01-30 09:58:24 --> Utf8 Class Initialized
INFO - 2024-01-30 09:58:24 --> URI Class Initialized
DEBUG - 2024-01-30 09:58:24 --> No URI present. Default controller set.
INFO - 2024-01-30 09:58:24 --> Router Class Initialized
INFO - 2024-01-30 09:58:24 --> Output Class Initialized
INFO - 2024-01-30 09:58:24 --> Security Class Initialized
DEBUG - 2024-01-30 09:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 09:58:24 --> Input Class Initialized
INFO - 2024-01-30 09:58:24 --> Language Class Initialized
INFO - 2024-01-30 09:58:24 --> Loader Class Initialized
INFO - 2024-01-30 09:58:24 --> Helper loaded: url_helper
INFO - 2024-01-30 09:58:24 --> Helper loaded: file_helper
INFO - 2024-01-30 09:58:24 --> Helper loaded: html_helper
INFO - 2024-01-30 09:58:24 --> Helper loaded: text_helper
INFO - 2024-01-30 09:58:24 --> Helper loaded: form_helper
INFO - 2024-01-30 09:58:24 --> Helper loaded: lang_helper
INFO - 2024-01-30 09:58:24 --> Helper loaded: security_helper
INFO - 2024-01-30 09:58:24 --> Helper loaded: cookie_helper
INFO - 2024-01-30 09:58:24 --> Database Driver Class Initialized
INFO - 2024-01-30 09:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 09:58:24 --> Parser Class Initialized
INFO - 2024-01-30 09:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 09:58:24 --> Pagination Class Initialized
INFO - 2024-01-30 09:58:24 --> Form Validation Class Initialized
INFO - 2024-01-30 09:58:24 --> Controller Class Initialized
INFO - 2024-01-30 09:58:24 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 09:58:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 09:58:25 --> Config Class Initialized
INFO - 2024-01-30 09:58:25 --> Hooks Class Initialized
DEBUG - 2024-01-30 09:58:25 --> UTF-8 Support Enabled
INFO - 2024-01-30 09:58:25 --> Utf8 Class Initialized
INFO - 2024-01-30 09:58:25 --> URI Class Initialized
INFO - 2024-01-30 09:58:25 --> Router Class Initialized
INFO - 2024-01-30 09:58:25 --> Output Class Initialized
INFO - 2024-01-30 09:58:25 --> Security Class Initialized
DEBUG - 2024-01-30 09:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 09:58:25 --> Input Class Initialized
INFO - 2024-01-30 09:58:25 --> Language Class Initialized
INFO - 2024-01-30 09:58:25 --> Loader Class Initialized
INFO - 2024-01-30 09:58:25 --> Helper loaded: url_helper
INFO - 2024-01-30 09:58:25 --> Helper loaded: file_helper
INFO - 2024-01-30 09:58:25 --> Helper loaded: html_helper
INFO - 2024-01-30 09:58:25 --> Helper loaded: text_helper
INFO - 2024-01-30 09:58:25 --> Helper loaded: form_helper
INFO - 2024-01-30 09:58:25 --> Helper loaded: lang_helper
INFO - 2024-01-30 09:58:25 --> Helper loaded: security_helper
INFO - 2024-01-30 09:58:25 --> Helper loaded: cookie_helper
INFO - 2024-01-30 09:58:25 --> Database Driver Class Initialized
INFO - 2024-01-30 09:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 09:58:25 --> Parser Class Initialized
INFO - 2024-01-30 09:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 09:58:25 --> Pagination Class Initialized
INFO - 2024-01-30 09:58:25 --> Form Validation Class Initialized
INFO - 2024-01-30 09:58:25 --> Controller Class Initialized
INFO - 2024-01-30 09:58:25 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 09:58:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 09:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 09:58:25 --> Model Class Initialized
INFO - 2024-01-30 09:58:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 09:58:25 --> Final output sent to browser
DEBUG - 2024-01-30 09:58:25 --> Total execution time: 0.0313
ERROR - 2024-01-30 09:58:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 09:58:38 --> Config Class Initialized
INFO - 2024-01-30 09:58:38 --> Hooks Class Initialized
DEBUG - 2024-01-30 09:58:38 --> UTF-8 Support Enabled
INFO - 2024-01-30 09:58:38 --> Utf8 Class Initialized
INFO - 2024-01-30 09:58:38 --> URI Class Initialized
INFO - 2024-01-30 09:58:38 --> Router Class Initialized
INFO - 2024-01-30 09:58:38 --> Output Class Initialized
INFO - 2024-01-30 09:58:38 --> Security Class Initialized
DEBUG - 2024-01-30 09:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 09:58:38 --> Input Class Initialized
INFO - 2024-01-30 09:58:38 --> Language Class Initialized
INFO - 2024-01-30 09:58:38 --> Loader Class Initialized
INFO - 2024-01-30 09:58:38 --> Helper loaded: url_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: file_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: html_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: text_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: form_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: lang_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: security_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: cookie_helper
INFO - 2024-01-30 09:58:38 --> Database Driver Class Initialized
INFO - 2024-01-30 09:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 09:58:38 --> Parser Class Initialized
INFO - 2024-01-30 09:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 09:58:38 --> Pagination Class Initialized
INFO - 2024-01-30 09:58:38 --> Form Validation Class Initialized
INFO - 2024-01-30 09:58:38 --> Controller Class Initialized
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
INFO - 2024-01-30 09:58:38 --> Final output sent to browser
DEBUG - 2024-01-30 09:58:38 --> Total execution time: 0.0199
ERROR - 2024-01-30 09:58:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 09:58:38 --> Config Class Initialized
INFO - 2024-01-30 09:58:38 --> Hooks Class Initialized
DEBUG - 2024-01-30 09:58:38 --> UTF-8 Support Enabled
INFO - 2024-01-30 09:58:38 --> Utf8 Class Initialized
INFO - 2024-01-30 09:58:38 --> URI Class Initialized
DEBUG - 2024-01-30 09:58:38 --> No URI present. Default controller set.
INFO - 2024-01-30 09:58:38 --> Router Class Initialized
INFO - 2024-01-30 09:58:38 --> Output Class Initialized
INFO - 2024-01-30 09:58:38 --> Security Class Initialized
DEBUG - 2024-01-30 09:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 09:58:38 --> Input Class Initialized
INFO - 2024-01-30 09:58:38 --> Language Class Initialized
INFO - 2024-01-30 09:58:38 --> Loader Class Initialized
INFO - 2024-01-30 09:58:38 --> Helper loaded: url_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: file_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: html_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: text_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: form_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: lang_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: security_helper
INFO - 2024-01-30 09:58:38 --> Helper loaded: cookie_helper
INFO - 2024-01-30 09:58:38 --> Database Driver Class Initialized
INFO - 2024-01-30 09:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 09:58:38 --> Parser Class Initialized
INFO - 2024-01-30 09:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 09:58:38 --> Pagination Class Initialized
INFO - 2024-01-30 09:58:38 --> Form Validation Class Initialized
INFO - 2024-01-30 09:58:38 --> Controller Class Initialized
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 09:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
INFO - 2024-01-30 09:58:38 --> Model Class Initialized
INFO - 2024-01-30 09:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 09:58:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 09:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 09:58:39 --> Model Class Initialized
INFO - 2024-01-30 09:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 09:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 09:58:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 09:58:39 --> Final output sent to browser
DEBUG - 2024-01-30 09:58:39 --> Total execution time: 0.3837
ERROR - 2024-01-30 09:58:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 09:58:40 --> Config Class Initialized
INFO - 2024-01-30 09:58:40 --> Hooks Class Initialized
DEBUG - 2024-01-30 09:58:40 --> UTF-8 Support Enabled
INFO - 2024-01-30 09:58:40 --> Utf8 Class Initialized
INFO - 2024-01-30 09:58:40 --> URI Class Initialized
INFO - 2024-01-30 09:58:40 --> Router Class Initialized
INFO - 2024-01-30 09:58:40 --> Output Class Initialized
INFO - 2024-01-30 09:58:40 --> Security Class Initialized
DEBUG - 2024-01-30 09:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 09:58:40 --> Input Class Initialized
INFO - 2024-01-30 09:58:40 --> Language Class Initialized
INFO - 2024-01-30 09:58:40 --> Loader Class Initialized
INFO - 2024-01-30 09:58:40 --> Helper loaded: url_helper
INFO - 2024-01-30 09:58:40 --> Helper loaded: file_helper
INFO - 2024-01-30 09:58:40 --> Helper loaded: html_helper
INFO - 2024-01-30 09:58:40 --> Helper loaded: text_helper
INFO - 2024-01-30 09:58:40 --> Helper loaded: form_helper
INFO - 2024-01-30 09:58:40 --> Helper loaded: lang_helper
INFO - 2024-01-30 09:58:40 --> Helper loaded: security_helper
INFO - 2024-01-30 09:58:40 --> Helper loaded: cookie_helper
INFO - 2024-01-30 09:58:40 --> Database Driver Class Initialized
INFO - 2024-01-30 09:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 09:58:40 --> Parser Class Initialized
INFO - 2024-01-30 09:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 09:58:40 --> Pagination Class Initialized
INFO - 2024-01-30 09:58:40 --> Form Validation Class Initialized
INFO - 2024-01-30 09:58:40 --> Controller Class Initialized
DEBUG - 2024-01-30 09:58:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 09:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:40 --> Model Class Initialized
INFO - 2024-01-30 09:58:40 --> Final output sent to browser
DEBUG - 2024-01-30 09:58:40 --> Total execution time: 0.0149
ERROR - 2024-01-30 09:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 09:58:56 --> Config Class Initialized
INFO - 2024-01-30 09:58:56 --> Hooks Class Initialized
DEBUG - 2024-01-30 09:58:56 --> UTF-8 Support Enabled
INFO - 2024-01-30 09:58:56 --> Utf8 Class Initialized
INFO - 2024-01-30 09:58:56 --> URI Class Initialized
DEBUG - 2024-01-30 09:58:56 --> No URI present. Default controller set.
INFO - 2024-01-30 09:58:56 --> Router Class Initialized
INFO - 2024-01-30 09:58:56 --> Output Class Initialized
INFO - 2024-01-30 09:58:56 --> Security Class Initialized
DEBUG - 2024-01-30 09:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 09:58:56 --> Input Class Initialized
INFO - 2024-01-30 09:58:56 --> Language Class Initialized
INFO - 2024-01-30 09:58:56 --> Loader Class Initialized
INFO - 2024-01-30 09:58:56 --> Helper loaded: url_helper
INFO - 2024-01-30 09:58:56 --> Helper loaded: file_helper
INFO - 2024-01-30 09:58:56 --> Helper loaded: html_helper
INFO - 2024-01-30 09:58:56 --> Helper loaded: text_helper
INFO - 2024-01-30 09:58:56 --> Helper loaded: form_helper
INFO - 2024-01-30 09:58:56 --> Helper loaded: lang_helper
INFO - 2024-01-30 09:58:56 --> Helper loaded: security_helper
INFO - 2024-01-30 09:58:56 --> Helper loaded: cookie_helper
INFO - 2024-01-30 09:58:56 --> Database Driver Class Initialized
INFO - 2024-01-30 09:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 09:58:56 --> Parser Class Initialized
INFO - 2024-01-30 09:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 09:58:56 --> Pagination Class Initialized
INFO - 2024-01-30 09:58:56 --> Form Validation Class Initialized
INFO - 2024-01-30 09:58:56 --> Controller Class Initialized
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
DEBUG - 2024-01-30 09:58:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 09:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
INFO - 2024-01-30 09:58:56 --> Model Class Initialized
INFO - 2024-01-30 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 09:58:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 09:58:57 --> Model Class Initialized
INFO - 2024-01-30 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 09:58:57 --> Final output sent to browser
DEBUG - 2024-01-30 09:58:57 --> Total execution time: 0.4076
ERROR - 2024-01-30 12:33:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 12:33:59 --> Config Class Initialized
INFO - 2024-01-30 12:33:59 --> Hooks Class Initialized
DEBUG - 2024-01-30 12:33:59 --> UTF-8 Support Enabled
INFO - 2024-01-30 12:33:59 --> Utf8 Class Initialized
INFO - 2024-01-30 12:33:59 --> URI Class Initialized
INFO - 2024-01-30 12:33:59 --> Router Class Initialized
INFO - 2024-01-30 12:33:59 --> Output Class Initialized
INFO - 2024-01-30 12:33:59 --> Security Class Initialized
DEBUG - 2024-01-30 12:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 12:33:59 --> Input Class Initialized
INFO - 2024-01-30 12:33:59 --> Language Class Initialized
ERROR - 2024-01-30 12:33:59 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-01-30 12:34:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 12:34:00 --> Config Class Initialized
INFO - 2024-01-30 12:34:00 --> Hooks Class Initialized
DEBUG - 2024-01-30 12:34:00 --> UTF-8 Support Enabled
INFO - 2024-01-30 12:34:00 --> Utf8 Class Initialized
INFO - 2024-01-30 12:34:00 --> URI Class Initialized
DEBUG - 2024-01-30 12:34:00 --> No URI present. Default controller set.
INFO - 2024-01-30 12:34:00 --> Router Class Initialized
INFO - 2024-01-30 12:34:00 --> Output Class Initialized
INFO - 2024-01-30 12:34:00 --> Security Class Initialized
DEBUG - 2024-01-30 12:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 12:34:00 --> Input Class Initialized
INFO - 2024-01-30 12:34:00 --> Language Class Initialized
INFO - 2024-01-30 12:34:00 --> Loader Class Initialized
INFO - 2024-01-30 12:34:00 --> Helper loaded: url_helper
INFO - 2024-01-30 12:34:00 --> Helper loaded: file_helper
INFO - 2024-01-30 12:34:00 --> Helper loaded: html_helper
INFO - 2024-01-30 12:34:00 --> Helper loaded: text_helper
INFO - 2024-01-30 12:34:00 --> Helper loaded: form_helper
INFO - 2024-01-30 12:34:00 --> Helper loaded: lang_helper
INFO - 2024-01-30 12:34:00 --> Helper loaded: security_helper
INFO - 2024-01-30 12:34:00 --> Helper loaded: cookie_helper
INFO - 2024-01-30 12:34:00 --> Database Driver Class Initialized
INFO - 2024-01-30 12:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 12:34:00 --> Parser Class Initialized
INFO - 2024-01-30 12:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 12:34:01 --> Pagination Class Initialized
INFO - 2024-01-30 12:34:01 --> Form Validation Class Initialized
INFO - 2024-01-30 12:34:01 --> Controller Class Initialized
INFO - 2024-01-30 12:34:01 --> Model Class Initialized
DEBUG - 2024-01-30 12:34:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 12:34:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 12:34:02 --> Config Class Initialized
INFO - 2024-01-30 12:34:02 --> Hooks Class Initialized
DEBUG - 2024-01-30 12:34:02 --> UTF-8 Support Enabled
INFO - 2024-01-30 12:34:02 --> Utf8 Class Initialized
INFO - 2024-01-30 12:34:02 --> URI Class Initialized
INFO - 2024-01-30 12:34:02 --> Router Class Initialized
INFO - 2024-01-30 12:34:02 --> Output Class Initialized
INFO - 2024-01-30 12:34:02 --> Security Class Initialized
DEBUG - 2024-01-30 12:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 12:34:02 --> Input Class Initialized
INFO - 2024-01-30 12:34:02 --> Language Class Initialized
ERROR - 2024-01-30 12:34:02 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-01-30 14:25:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 14:25:39 --> Config Class Initialized
INFO - 2024-01-30 14:25:39 --> Hooks Class Initialized
DEBUG - 2024-01-30 14:25:39 --> UTF-8 Support Enabled
INFO - 2024-01-30 14:25:39 --> Utf8 Class Initialized
INFO - 2024-01-30 14:25:39 --> URI Class Initialized
DEBUG - 2024-01-30 14:25:39 --> No URI present. Default controller set.
INFO - 2024-01-30 14:25:39 --> Router Class Initialized
INFO - 2024-01-30 14:25:39 --> Output Class Initialized
INFO - 2024-01-30 14:25:39 --> Security Class Initialized
DEBUG - 2024-01-30 14:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 14:25:39 --> Input Class Initialized
INFO - 2024-01-30 14:25:39 --> Language Class Initialized
INFO - 2024-01-30 14:25:39 --> Loader Class Initialized
INFO - 2024-01-30 14:25:39 --> Helper loaded: url_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: file_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: html_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: text_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: form_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: lang_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: security_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: cookie_helper
INFO - 2024-01-30 14:25:39 --> Database Driver Class Initialized
INFO - 2024-01-30 14:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 14:25:39 --> Parser Class Initialized
INFO - 2024-01-30 14:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 14:25:39 --> Pagination Class Initialized
INFO - 2024-01-30 14:25:39 --> Form Validation Class Initialized
INFO - 2024-01-30 14:25:39 --> Controller Class Initialized
INFO - 2024-01-30 14:25:39 --> Model Class Initialized
DEBUG - 2024-01-30 14:25:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 14:25:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 14:25:39 --> Config Class Initialized
INFO - 2024-01-30 14:25:39 --> Hooks Class Initialized
DEBUG - 2024-01-30 14:25:39 --> UTF-8 Support Enabled
INFO - 2024-01-30 14:25:39 --> Utf8 Class Initialized
INFO - 2024-01-30 14:25:39 --> URI Class Initialized
INFO - 2024-01-30 14:25:39 --> Router Class Initialized
INFO - 2024-01-30 14:25:39 --> Output Class Initialized
INFO - 2024-01-30 14:25:39 --> Security Class Initialized
DEBUG - 2024-01-30 14:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 14:25:39 --> Input Class Initialized
INFO - 2024-01-30 14:25:39 --> Language Class Initialized
INFO - 2024-01-30 14:25:39 --> Loader Class Initialized
INFO - 2024-01-30 14:25:39 --> Helper loaded: url_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: file_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: html_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: text_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: form_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: lang_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: security_helper
INFO - 2024-01-30 14:25:39 --> Helper loaded: cookie_helper
INFO - 2024-01-30 14:25:39 --> Database Driver Class Initialized
INFO - 2024-01-30 14:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 14:25:39 --> Parser Class Initialized
INFO - 2024-01-30 14:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 14:25:39 --> Pagination Class Initialized
INFO - 2024-01-30 14:25:39 --> Form Validation Class Initialized
INFO - 2024-01-30 14:25:39 --> Controller Class Initialized
INFO - 2024-01-30 14:25:39 --> Model Class Initialized
DEBUG - 2024-01-30 14:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 14:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 14:25:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 14:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 14:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 14:25:39 --> Model Class Initialized
INFO - 2024-01-30 14:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 14:25:39 --> Final output sent to browser
DEBUG - 2024-01-30 14:25:39 --> Total execution time: 0.0357
ERROR - 2024-01-30 14:25:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 14:25:40 --> Config Class Initialized
INFO - 2024-01-30 14:25:40 --> Hooks Class Initialized
DEBUG - 2024-01-30 14:25:40 --> UTF-8 Support Enabled
INFO - 2024-01-30 14:25:40 --> Utf8 Class Initialized
INFO - 2024-01-30 14:25:40 --> URI Class Initialized
INFO - 2024-01-30 14:25:40 --> Router Class Initialized
INFO - 2024-01-30 14:25:40 --> Output Class Initialized
INFO - 2024-01-30 14:25:40 --> Security Class Initialized
DEBUG - 2024-01-30 14:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 14:25:40 --> Input Class Initialized
INFO - 2024-01-30 14:25:40 --> Language Class Initialized
ERROR - 2024-01-30 14:25:40 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2024-01-30 14:25:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 14:25:40 --> Config Class Initialized
INFO - 2024-01-30 14:25:40 --> Hooks Class Initialized
DEBUG - 2024-01-30 14:25:40 --> UTF-8 Support Enabled
INFO - 2024-01-30 14:25:40 --> Utf8 Class Initialized
INFO - 2024-01-30 14:25:40 --> URI Class Initialized
INFO - 2024-01-30 14:25:40 --> Router Class Initialized
INFO - 2024-01-30 14:25:40 --> Output Class Initialized
INFO - 2024-01-30 14:25:40 --> Security Class Initialized
DEBUG - 2024-01-30 14:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 14:25:40 --> Input Class Initialized
INFO - 2024-01-30 14:25:40 --> Language Class Initialized
ERROR - 2024-01-30 14:25:40 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2024-01-30 15:16:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:16:39 --> Config Class Initialized
INFO - 2024-01-30 15:16:39 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:16:39 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:16:39 --> Utf8 Class Initialized
INFO - 2024-01-30 15:16:39 --> URI Class Initialized
DEBUG - 2024-01-30 15:16:39 --> No URI present. Default controller set.
INFO - 2024-01-30 15:16:39 --> Router Class Initialized
INFO - 2024-01-30 15:16:39 --> Output Class Initialized
INFO - 2024-01-30 15:16:39 --> Security Class Initialized
DEBUG - 2024-01-30 15:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:16:39 --> Input Class Initialized
INFO - 2024-01-30 15:16:39 --> Language Class Initialized
INFO - 2024-01-30 15:16:39 --> Loader Class Initialized
INFO - 2024-01-30 15:16:39 --> Helper loaded: url_helper
INFO - 2024-01-30 15:16:39 --> Helper loaded: file_helper
INFO - 2024-01-30 15:16:39 --> Helper loaded: html_helper
INFO - 2024-01-30 15:16:39 --> Helper loaded: text_helper
INFO - 2024-01-30 15:16:39 --> Helper loaded: form_helper
INFO - 2024-01-30 15:16:39 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:16:39 --> Helper loaded: security_helper
INFO - 2024-01-30 15:16:39 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:16:39 --> Database Driver Class Initialized
INFO - 2024-01-30 15:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:16:39 --> Parser Class Initialized
INFO - 2024-01-30 15:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:16:39 --> Pagination Class Initialized
INFO - 2024-01-30 15:16:39 --> Form Validation Class Initialized
INFO - 2024-01-30 15:16:39 --> Controller Class Initialized
INFO - 2024-01-30 15:16:39 --> Model Class Initialized
DEBUG - 2024-01-30 15:16:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 15:16:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:16:41 --> Config Class Initialized
INFO - 2024-01-30 15:16:41 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:16:41 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:16:41 --> Utf8 Class Initialized
INFO - 2024-01-30 15:16:41 --> URI Class Initialized
INFO - 2024-01-30 15:16:41 --> Router Class Initialized
INFO - 2024-01-30 15:16:41 --> Output Class Initialized
INFO - 2024-01-30 15:16:41 --> Security Class Initialized
DEBUG - 2024-01-30 15:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:16:41 --> Input Class Initialized
INFO - 2024-01-30 15:16:41 --> Language Class Initialized
INFO - 2024-01-30 15:16:41 --> Loader Class Initialized
INFO - 2024-01-30 15:16:41 --> Helper loaded: url_helper
INFO - 2024-01-30 15:16:41 --> Helper loaded: file_helper
INFO - 2024-01-30 15:16:41 --> Helper loaded: html_helper
INFO - 2024-01-30 15:16:41 --> Helper loaded: text_helper
INFO - 2024-01-30 15:16:41 --> Helper loaded: form_helper
INFO - 2024-01-30 15:16:41 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:16:41 --> Helper loaded: security_helper
INFO - 2024-01-30 15:16:41 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:16:41 --> Database Driver Class Initialized
INFO - 2024-01-30 15:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:16:41 --> Parser Class Initialized
INFO - 2024-01-30 15:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:16:41 --> Pagination Class Initialized
INFO - 2024-01-30 15:16:41 --> Form Validation Class Initialized
INFO - 2024-01-30 15:16:41 --> Controller Class Initialized
INFO - 2024-01-30 15:16:41 --> Model Class Initialized
DEBUG - 2024-01-30 15:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 15:16:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:16:41 --> Model Class Initialized
INFO - 2024-01-30 15:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:16:41 --> Final output sent to browser
DEBUG - 2024-01-30 15:16:41 --> Total execution time: 0.0359
ERROR - 2024-01-30 15:17:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:17:08 --> Config Class Initialized
INFO - 2024-01-30 15:17:08 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:17:08 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:17:08 --> Utf8 Class Initialized
INFO - 2024-01-30 15:17:08 --> URI Class Initialized
INFO - 2024-01-30 15:17:08 --> Router Class Initialized
INFO - 2024-01-30 15:17:08 --> Output Class Initialized
INFO - 2024-01-30 15:17:08 --> Security Class Initialized
DEBUG - 2024-01-30 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:17:08 --> Input Class Initialized
INFO - 2024-01-30 15:17:08 --> Language Class Initialized
INFO - 2024-01-30 15:17:08 --> Loader Class Initialized
INFO - 2024-01-30 15:17:08 --> Helper loaded: url_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: file_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: html_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: text_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: form_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: security_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:17:08 --> Database Driver Class Initialized
INFO - 2024-01-30 15:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:17:08 --> Parser Class Initialized
INFO - 2024-01-30 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:17:08 --> Pagination Class Initialized
INFO - 2024-01-30 15:17:08 --> Form Validation Class Initialized
INFO - 2024-01-30 15:17:08 --> Controller Class Initialized
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
DEBUG - 2024-01-30 15:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
INFO - 2024-01-30 15:17:08 --> Final output sent to browser
DEBUG - 2024-01-30 15:17:08 --> Total execution time: 0.0228
ERROR - 2024-01-30 15:17:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:17:08 --> Config Class Initialized
INFO - 2024-01-30 15:17:08 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:17:08 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:17:08 --> Utf8 Class Initialized
INFO - 2024-01-30 15:17:08 --> URI Class Initialized
DEBUG - 2024-01-30 15:17:08 --> No URI present. Default controller set.
INFO - 2024-01-30 15:17:08 --> Router Class Initialized
INFO - 2024-01-30 15:17:08 --> Output Class Initialized
INFO - 2024-01-30 15:17:08 --> Security Class Initialized
DEBUG - 2024-01-30 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:17:08 --> Input Class Initialized
INFO - 2024-01-30 15:17:08 --> Language Class Initialized
INFO - 2024-01-30 15:17:08 --> Loader Class Initialized
INFO - 2024-01-30 15:17:08 --> Helper loaded: url_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: file_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: html_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: text_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: form_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: security_helper
INFO - 2024-01-30 15:17:08 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:17:08 --> Database Driver Class Initialized
INFO - 2024-01-30 15:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:17:08 --> Parser Class Initialized
INFO - 2024-01-30 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:17:08 --> Pagination Class Initialized
INFO - 2024-01-30 15:17:08 --> Form Validation Class Initialized
INFO - 2024-01-30 15:17:08 --> Controller Class Initialized
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
DEBUG - 2024-01-30 15:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
DEBUG - 2024-01-30 15:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
DEBUG - 2024-01-30 15:17:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 15:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
INFO - 2024-01-30 15:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 15:17:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:17:08 --> Model Class Initialized
INFO - 2024-01-30 15:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 15:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 15:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:17:08 --> Final output sent to browser
DEBUG - 2024-01-30 15:17:08 --> Total execution time: 0.2220
ERROR - 2024-01-30 15:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:17:25 --> Config Class Initialized
INFO - 2024-01-30 15:17:25 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:17:25 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:17:25 --> Utf8 Class Initialized
INFO - 2024-01-30 15:17:25 --> URI Class Initialized
INFO - 2024-01-30 15:17:25 --> Router Class Initialized
INFO - 2024-01-30 15:17:25 --> Output Class Initialized
INFO - 2024-01-30 15:17:25 --> Security Class Initialized
DEBUG - 2024-01-30 15:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:17:25 --> Input Class Initialized
INFO - 2024-01-30 15:17:25 --> Language Class Initialized
INFO - 2024-01-30 15:17:25 --> Loader Class Initialized
INFO - 2024-01-30 15:17:25 --> Helper loaded: url_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: file_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: html_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: text_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: form_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: security_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:17:25 --> Database Driver Class Initialized
INFO - 2024-01-30 15:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:17:25 --> Parser Class Initialized
INFO - 2024-01-30 15:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:17:25 --> Pagination Class Initialized
INFO - 2024-01-30 15:17:25 --> Form Validation Class Initialized
INFO - 2024-01-30 15:17:25 --> Controller Class Initialized
INFO - 2024-01-30 15:17:25 --> Model Class Initialized
INFO - 2024-01-30 15:17:25 --> Model Class Initialized
INFO - 2024-01-30 15:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2024-01-30 15:17:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:17:25 --> Model Class Initialized
INFO - 2024-01-30 15:17:25 --> Model Class Initialized
INFO - 2024-01-30 15:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 15:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 15:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:17:25 --> Final output sent to browser
DEBUG - 2024-01-30 15:17:25 --> Total execution time: 0.2202
ERROR - 2024-01-30 15:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:17:25 --> Config Class Initialized
INFO - 2024-01-30 15:17:25 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:17:25 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:17:25 --> Utf8 Class Initialized
INFO - 2024-01-30 15:17:25 --> URI Class Initialized
INFO - 2024-01-30 15:17:25 --> Router Class Initialized
INFO - 2024-01-30 15:17:25 --> Output Class Initialized
INFO - 2024-01-30 15:17:25 --> Security Class Initialized
DEBUG - 2024-01-30 15:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:17:25 --> Input Class Initialized
INFO - 2024-01-30 15:17:25 --> Language Class Initialized
INFO - 2024-01-30 15:17:25 --> Loader Class Initialized
INFO - 2024-01-30 15:17:25 --> Helper loaded: url_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: file_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: html_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: text_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: form_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: security_helper
INFO - 2024-01-30 15:17:25 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:17:25 --> Database Driver Class Initialized
INFO - 2024-01-30 15:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:17:25 --> Parser Class Initialized
INFO - 2024-01-30 15:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:17:25 --> Pagination Class Initialized
INFO - 2024-01-30 15:17:25 --> Form Validation Class Initialized
INFO - 2024-01-30 15:17:25 --> Controller Class Initialized
INFO - 2024-01-30 15:17:25 --> Model Class Initialized
INFO - 2024-01-30 15:17:25 --> Model Class Initialized
INFO - 2024-01-30 15:17:26 --> Final output sent to browser
DEBUG - 2024-01-30 15:17:26 --> Total execution time: 0.1904
ERROR - 2024-01-30 15:17:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:17:39 --> Config Class Initialized
INFO - 2024-01-30 15:17:39 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:17:39 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:17:39 --> Utf8 Class Initialized
INFO - 2024-01-30 15:17:39 --> URI Class Initialized
INFO - 2024-01-30 15:17:39 --> Router Class Initialized
INFO - 2024-01-30 15:17:39 --> Output Class Initialized
INFO - 2024-01-30 15:17:39 --> Security Class Initialized
DEBUG - 2024-01-30 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:17:39 --> Input Class Initialized
INFO - 2024-01-30 15:17:39 --> Language Class Initialized
INFO - 2024-01-30 15:17:39 --> Loader Class Initialized
INFO - 2024-01-30 15:17:39 --> Helper loaded: url_helper
INFO - 2024-01-30 15:17:39 --> Helper loaded: file_helper
INFO - 2024-01-30 15:17:39 --> Helper loaded: html_helper
INFO - 2024-01-30 15:17:39 --> Helper loaded: text_helper
INFO - 2024-01-30 15:17:39 --> Helper loaded: form_helper
INFO - 2024-01-30 15:17:39 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:17:39 --> Helper loaded: security_helper
INFO - 2024-01-30 15:17:39 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:17:39 --> Database Driver Class Initialized
INFO - 2024-01-30 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:17:39 --> Parser Class Initialized
INFO - 2024-01-30 15:17:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:17:39 --> Pagination Class Initialized
INFO - 2024-01-30 15:17:39 --> Form Validation Class Initialized
INFO - 2024-01-30 15:17:39 --> Controller Class Initialized
INFO - 2024-01-30 15:17:39 --> Model Class Initialized
INFO - 2024-01-30 15:17:39 --> Model Class Initialized
INFO - 2024-01-30 15:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-01-30 15:17:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:17:39 --> Model Class Initialized
INFO - 2024-01-30 15:17:39 --> Model Class Initialized
INFO - 2024-01-30 15:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 15:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 15:17:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:17:39 --> Final output sent to browser
DEBUG - 2024-01-30 15:17:39 --> Total execution time: 0.1737
ERROR - 2024-01-30 15:17:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:17:40 --> Config Class Initialized
INFO - 2024-01-30 15:17:40 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:17:40 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:17:40 --> Utf8 Class Initialized
INFO - 2024-01-30 15:17:40 --> URI Class Initialized
INFO - 2024-01-30 15:17:40 --> Router Class Initialized
INFO - 2024-01-30 15:17:40 --> Output Class Initialized
INFO - 2024-01-30 15:17:40 --> Security Class Initialized
DEBUG - 2024-01-30 15:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:17:40 --> Input Class Initialized
INFO - 2024-01-30 15:17:40 --> Language Class Initialized
INFO - 2024-01-30 15:17:40 --> Loader Class Initialized
INFO - 2024-01-30 15:17:40 --> Helper loaded: url_helper
INFO - 2024-01-30 15:17:40 --> Helper loaded: file_helper
INFO - 2024-01-30 15:17:40 --> Helper loaded: html_helper
INFO - 2024-01-30 15:17:40 --> Helper loaded: text_helper
INFO - 2024-01-30 15:17:40 --> Helper loaded: form_helper
INFO - 2024-01-30 15:17:40 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:17:40 --> Helper loaded: security_helper
INFO - 2024-01-30 15:17:40 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:17:40 --> Database Driver Class Initialized
INFO - 2024-01-30 15:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:17:40 --> Parser Class Initialized
INFO - 2024-01-30 15:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:17:40 --> Pagination Class Initialized
INFO - 2024-01-30 15:17:40 --> Form Validation Class Initialized
INFO - 2024-01-30 15:17:40 --> Controller Class Initialized
INFO - 2024-01-30 15:17:40 --> Model Class Initialized
INFO - 2024-01-30 15:17:40 --> Model Class Initialized
INFO - 2024-01-30 15:17:40 --> Final output sent to browser
DEBUG - 2024-01-30 15:17:40 --> Total execution time: 0.0756
ERROR - 2024-01-30 15:18:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:18:09 --> Config Class Initialized
INFO - 2024-01-30 15:18:09 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:18:09 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:18:09 --> Utf8 Class Initialized
INFO - 2024-01-30 15:18:09 --> URI Class Initialized
INFO - 2024-01-30 15:18:09 --> Router Class Initialized
INFO - 2024-01-30 15:18:09 --> Output Class Initialized
INFO - 2024-01-30 15:18:09 --> Security Class Initialized
DEBUG - 2024-01-30 15:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:18:09 --> Input Class Initialized
INFO - 2024-01-30 15:18:09 --> Language Class Initialized
INFO - 2024-01-30 15:18:09 --> Loader Class Initialized
INFO - 2024-01-30 15:18:09 --> Helper loaded: url_helper
INFO - 2024-01-30 15:18:09 --> Helper loaded: file_helper
INFO - 2024-01-30 15:18:09 --> Helper loaded: html_helper
INFO - 2024-01-30 15:18:09 --> Helper loaded: text_helper
INFO - 2024-01-30 15:18:09 --> Helper loaded: form_helper
INFO - 2024-01-30 15:18:09 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:18:09 --> Helper loaded: security_helper
INFO - 2024-01-30 15:18:09 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:18:09 --> Database Driver Class Initialized
INFO - 2024-01-30 15:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:18:09 --> Parser Class Initialized
INFO - 2024-01-30 15:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:18:09 --> Pagination Class Initialized
INFO - 2024-01-30 15:18:09 --> Form Validation Class Initialized
INFO - 2024-01-30 15:18:09 --> Controller Class Initialized
INFO - 2024-01-30 15:18:09 --> Model Class Initialized
INFO - 2024-01-30 15:18:09 --> Model Class Initialized
INFO - 2024-01-30 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2024-01-30 15:18:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:18:09 --> Model Class Initialized
INFO - 2024-01-30 15:18:09 --> Model Class Initialized
INFO - 2024-01-30 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 15:18:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:18:09 --> Final output sent to browser
DEBUG - 2024-01-30 15:18:09 --> Total execution time: 0.1880
ERROR - 2024-01-30 15:18:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:18:10 --> Config Class Initialized
INFO - 2024-01-30 15:18:10 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:18:10 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:18:10 --> Utf8 Class Initialized
INFO - 2024-01-30 15:18:10 --> URI Class Initialized
INFO - 2024-01-30 15:18:10 --> Router Class Initialized
INFO - 2024-01-30 15:18:10 --> Output Class Initialized
INFO - 2024-01-30 15:18:10 --> Security Class Initialized
DEBUG - 2024-01-30 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:18:10 --> Input Class Initialized
INFO - 2024-01-30 15:18:10 --> Language Class Initialized
INFO - 2024-01-30 15:18:10 --> Loader Class Initialized
INFO - 2024-01-30 15:18:10 --> Helper loaded: url_helper
INFO - 2024-01-30 15:18:10 --> Helper loaded: file_helper
INFO - 2024-01-30 15:18:10 --> Helper loaded: html_helper
INFO - 2024-01-30 15:18:10 --> Helper loaded: text_helper
INFO - 2024-01-30 15:18:10 --> Helper loaded: form_helper
INFO - 2024-01-30 15:18:10 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:18:10 --> Helper loaded: security_helper
INFO - 2024-01-30 15:18:10 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:18:10 --> Database Driver Class Initialized
INFO - 2024-01-30 15:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:18:10 --> Parser Class Initialized
INFO - 2024-01-30 15:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:18:10 --> Pagination Class Initialized
INFO - 2024-01-30 15:18:10 --> Form Validation Class Initialized
INFO - 2024-01-30 15:18:10 --> Controller Class Initialized
INFO - 2024-01-30 15:18:10 --> Model Class Initialized
INFO - 2024-01-30 15:18:10 --> Model Class Initialized
INFO - 2024-01-30 15:18:10 --> Final output sent to browser
DEBUG - 2024-01-30 15:18:10 --> Total execution time: 0.1848
ERROR - 2024-01-30 15:18:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:18:12 --> Config Class Initialized
INFO - 2024-01-30 15:18:12 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:18:12 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:18:12 --> Utf8 Class Initialized
INFO - 2024-01-30 15:18:12 --> URI Class Initialized
DEBUG - 2024-01-30 15:18:12 --> No URI present. Default controller set.
INFO - 2024-01-30 15:18:12 --> Router Class Initialized
INFO - 2024-01-30 15:18:12 --> Output Class Initialized
INFO - 2024-01-30 15:18:12 --> Security Class Initialized
DEBUG - 2024-01-30 15:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:18:12 --> Input Class Initialized
INFO - 2024-01-30 15:18:12 --> Language Class Initialized
INFO - 2024-01-30 15:18:12 --> Loader Class Initialized
INFO - 2024-01-30 15:18:12 --> Helper loaded: url_helper
INFO - 2024-01-30 15:18:12 --> Helper loaded: file_helper
INFO - 2024-01-30 15:18:12 --> Helper loaded: html_helper
INFO - 2024-01-30 15:18:12 --> Helper loaded: text_helper
INFO - 2024-01-30 15:18:12 --> Helper loaded: form_helper
INFO - 2024-01-30 15:18:12 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:18:12 --> Helper loaded: security_helper
INFO - 2024-01-30 15:18:12 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:18:12 --> Database Driver Class Initialized
INFO - 2024-01-30 15:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:18:12 --> Parser Class Initialized
INFO - 2024-01-30 15:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:18:12 --> Pagination Class Initialized
INFO - 2024-01-30 15:18:12 --> Form Validation Class Initialized
INFO - 2024-01-30 15:18:12 --> Controller Class Initialized
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
DEBUG - 2024-01-30 15:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
DEBUG - 2024-01-30 15:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
DEBUG - 2024-01-30 15:18:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 15:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
INFO - 2024-01-30 15:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 15:18:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:18:12 --> Model Class Initialized
INFO - 2024-01-30 15:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 15:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 15:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:18:12 --> Final output sent to browser
DEBUG - 2024-01-30 15:18:12 --> Total execution time: 0.2153
ERROR - 2024-01-30 15:18:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:18:18 --> Config Class Initialized
INFO - 2024-01-30 15:18:18 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:18:18 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:18:18 --> Utf8 Class Initialized
INFO - 2024-01-30 15:18:18 --> URI Class Initialized
INFO - 2024-01-30 15:18:18 --> Router Class Initialized
INFO - 2024-01-30 15:18:18 --> Output Class Initialized
INFO - 2024-01-30 15:18:18 --> Security Class Initialized
DEBUG - 2024-01-30 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:18:18 --> Input Class Initialized
INFO - 2024-01-30 15:18:18 --> Language Class Initialized
INFO - 2024-01-30 15:18:18 --> Loader Class Initialized
INFO - 2024-01-30 15:18:18 --> Helper loaded: url_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: file_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: html_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: text_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: form_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: security_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:18:18 --> Database Driver Class Initialized
INFO - 2024-01-30 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:18:18 --> Parser Class Initialized
INFO - 2024-01-30 15:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:18:18 --> Pagination Class Initialized
INFO - 2024-01-30 15:18:18 --> Form Validation Class Initialized
INFO - 2024-01-30 15:18:18 --> Controller Class Initialized
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
DEBUG - 2024-01-30 15:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-30 15:18:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:18:18 --> Final output sent to browser
DEBUG - 2024-01-30 15:18:18 --> Total execution time: 0.0309
ERROR - 2024-01-30 15:18:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 15:18:18 --> Config Class Initialized
INFO - 2024-01-30 15:18:18 --> Hooks Class Initialized
DEBUG - 2024-01-30 15:18:18 --> UTF-8 Support Enabled
INFO - 2024-01-30 15:18:18 --> Utf8 Class Initialized
INFO - 2024-01-30 15:18:18 --> URI Class Initialized
INFO - 2024-01-30 15:18:18 --> Router Class Initialized
INFO - 2024-01-30 15:18:18 --> Output Class Initialized
INFO - 2024-01-30 15:18:18 --> Security Class Initialized
DEBUG - 2024-01-30 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 15:18:18 --> Input Class Initialized
INFO - 2024-01-30 15:18:18 --> Language Class Initialized
INFO - 2024-01-30 15:18:18 --> Loader Class Initialized
INFO - 2024-01-30 15:18:18 --> Helper loaded: url_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: file_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: html_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: text_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: form_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: lang_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: security_helper
INFO - 2024-01-30 15:18:18 --> Helper loaded: cookie_helper
INFO - 2024-01-30 15:18:18 --> Database Driver Class Initialized
INFO - 2024-01-30 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 15:18:18 --> Parser Class Initialized
INFO - 2024-01-30 15:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 15:18:18 --> Pagination Class Initialized
INFO - 2024-01-30 15:18:18 --> Form Validation Class Initialized
INFO - 2024-01-30 15:18:18 --> Controller Class Initialized
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
DEBUG - 2024-01-30 15:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
DEBUG - 2024-01-30 15:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
DEBUG - 2024-01-30 15:18:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-30 15:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-30 15:18:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-30 15:18:18 --> Model Class Initialized
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-30 15:18:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-30 15:18:18 --> Final output sent to browser
DEBUG - 2024-01-30 15:18:18 --> Total execution time: 0.2128
ERROR - 2024-01-30 16:33:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 16:33:53 --> Config Class Initialized
INFO - 2024-01-30 16:33:53 --> Hooks Class Initialized
DEBUG - 2024-01-30 16:33:53 --> UTF-8 Support Enabled
INFO - 2024-01-30 16:33:53 --> Utf8 Class Initialized
INFO - 2024-01-30 16:33:53 --> URI Class Initialized
INFO - 2024-01-30 16:33:53 --> Router Class Initialized
INFO - 2024-01-30 16:33:53 --> Output Class Initialized
INFO - 2024-01-30 16:33:53 --> Security Class Initialized
DEBUG - 2024-01-30 16:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 16:33:53 --> Input Class Initialized
INFO - 2024-01-30 16:33:53 --> Language Class Initialized
ERROR - 2024-01-30 16:33:53 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-30 19:22:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 19:22:20 --> Config Class Initialized
INFO - 2024-01-30 19:22:20 --> Hooks Class Initialized
DEBUG - 2024-01-30 19:22:20 --> UTF-8 Support Enabled
INFO - 2024-01-30 19:22:20 --> Utf8 Class Initialized
INFO - 2024-01-30 19:22:20 --> URI Class Initialized
DEBUG - 2024-01-30 19:22:20 --> No URI present. Default controller set.
INFO - 2024-01-30 19:22:20 --> Router Class Initialized
INFO - 2024-01-30 19:22:20 --> Output Class Initialized
INFO - 2024-01-30 19:22:20 --> Security Class Initialized
DEBUG - 2024-01-30 19:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 19:22:20 --> Input Class Initialized
INFO - 2024-01-30 19:22:20 --> Language Class Initialized
INFO - 2024-01-30 19:22:20 --> Loader Class Initialized
INFO - 2024-01-30 19:22:20 --> Helper loaded: url_helper
INFO - 2024-01-30 19:22:20 --> Helper loaded: file_helper
INFO - 2024-01-30 19:22:20 --> Helper loaded: html_helper
INFO - 2024-01-30 19:22:20 --> Helper loaded: text_helper
INFO - 2024-01-30 19:22:20 --> Helper loaded: form_helper
INFO - 2024-01-30 19:22:20 --> Helper loaded: lang_helper
INFO - 2024-01-30 19:22:20 --> Helper loaded: security_helper
INFO - 2024-01-30 19:22:20 --> Helper loaded: cookie_helper
INFO - 2024-01-30 19:22:20 --> Database Driver Class Initialized
INFO - 2024-01-30 19:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 19:22:20 --> Parser Class Initialized
INFO - 2024-01-30 19:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 19:22:20 --> Pagination Class Initialized
INFO - 2024-01-30 19:22:20 --> Form Validation Class Initialized
INFO - 2024-01-30 19:22:20 --> Controller Class Initialized
INFO - 2024-01-30 19:22:20 --> Model Class Initialized
DEBUG - 2024-01-30 19:22:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-30 21:32:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-30 21:32:15 --> Config Class Initialized
INFO - 2024-01-30 21:32:15 --> Hooks Class Initialized
DEBUG - 2024-01-30 21:32:15 --> UTF-8 Support Enabled
INFO - 2024-01-30 21:32:15 --> Utf8 Class Initialized
INFO - 2024-01-30 21:32:15 --> URI Class Initialized
DEBUG - 2024-01-30 21:32:15 --> No URI present. Default controller set.
INFO - 2024-01-30 21:32:15 --> Router Class Initialized
INFO - 2024-01-30 21:32:15 --> Output Class Initialized
INFO - 2024-01-30 21:32:15 --> Security Class Initialized
DEBUG - 2024-01-30 21:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-30 21:32:15 --> Input Class Initialized
INFO - 2024-01-30 21:32:15 --> Language Class Initialized
INFO - 2024-01-30 21:32:15 --> Loader Class Initialized
INFO - 2024-01-30 21:32:15 --> Helper loaded: url_helper
INFO - 2024-01-30 21:32:15 --> Helper loaded: file_helper
INFO - 2024-01-30 21:32:15 --> Helper loaded: html_helper
INFO - 2024-01-30 21:32:15 --> Helper loaded: text_helper
INFO - 2024-01-30 21:32:15 --> Helper loaded: form_helper
INFO - 2024-01-30 21:32:15 --> Helper loaded: lang_helper
INFO - 2024-01-30 21:32:15 --> Helper loaded: security_helper
INFO - 2024-01-30 21:32:15 --> Helper loaded: cookie_helper
INFO - 2024-01-30 21:32:15 --> Database Driver Class Initialized
INFO - 2024-01-30 21:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-30 21:32:15 --> Parser Class Initialized
INFO - 2024-01-30 21:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-30 21:32:15 --> Pagination Class Initialized
INFO - 2024-01-30 21:32:15 --> Form Validation Class Initialized
INFO - 2024-01-30 21:32:15 --> Controller Class Initialized
INFO - 2024-01-30 21:32:15 --> Model Class Initialized
DEBUG - 2024-01-30 21:32:15 --> Session class already loaded. Second attempt ignored.
