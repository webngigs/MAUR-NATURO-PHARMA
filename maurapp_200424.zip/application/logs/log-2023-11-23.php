<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-23 03:07:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 03:07:19 --> Config Class Initialized
INFO - 2023-11-23 03:07:19 --> Hooks Class Initialized
DEBUG - 2023-11-23 03:07:19 --> UTF-8 Support Enabled
INFO - 2023-11-23 03:07:19 --> Utf8 Class Initialized
INFO - 2023-11-23 03:07:19 --> URI Class Initialized
INFO - 2023-11-23 03:07:19 --> Router Class Initialized
INFO - 2023-11-23 03:07:19 --> Output Class Initialized
INFO - 2023-11-23 03:07:19 --> Security Class Initialized
DEBUG - 2023-11-23 03:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 03:07:19 --> Input Class Initialized
INFO - 2023-11-23 03:07:19 --> Language Class Initialized
ERROR - 2023-11-23 03:07:19 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-23 06:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 06:57:31 --> Config Class Initialized
INFO - 2023-11-23 06:57:31 --> Hooks Class Initialized
DEBUG - 2023-11-23 06:57:31 --> UTF-8 Support Enabled
INFO - 2023-11-23 06:57:31 --> Utf8 Class Initialized
INFO - 2023-11-23 06:57:31 --> URI Class Initialized
DEBUG - 2023-11-23 06:57:31 --> No URI present. Default controller set.
INFO - 2023-11-23 06:57:31 --> Router Class Initialized
INFO - 2023-11-23 06:57:31 --> Output Class Initialized
INFO - 2023-11-23 06:57:31 --> Security Class Initialized
DEBUG - 2023-11-23 06:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 06:57:31 --> Input Class Initialized
INFO - 2023-11-23 06:57:31 --> Language Class Initialized
INFO - 2023-11-23 06:57:31 --> Loader Class Initialized
INFO - 2023-11-23 06:57:31 --> Helper loaded: url_helper
INFO - 2023-11-23 06:57:31 --> Helper loaded: file_helper
INFO - 2023-11-23 06:57:31 --> Helper loaded: html_helper
INFO - 2023-11-23 06:57:31 --> Helper loaded: text_helper
INFO - 2023-11-23 06:57:31 --> Helper loaded: form_helper
INFO - 2023-11-23 06:57:31 --> Helper loaded: lang_helper
INFO - 2023-11-23 06:57:31 --> Helper loaded: security_helper
INFO - 2023-11-23 06:57:31 --> Helper loaded: cookie_helper
INFO - 2023-11-23 06:57:31 --> Database Driver Class Initialized
INFO - 2023-11-23 06:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 06:57:31 --> Parser Class Initialized
INFO - 2023-11-23 06:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 06:57:31 --> Pagination Class Initialized
INFO - 2023-11-23 06:57:31 --> Form Validation Class Initialized
INFO - 2023-11-23 06:57:31 --> Controller Class Initialized
INFO - 2023-11-23 06:57:31 --> Model Class Initialized
DEBUG - 2023-11-23 06:57:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-23 11:12:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:12:23 --> Config Class Initialized
INFO - 2023-11-23 11:12:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:12:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:12:23 --> Utf8 Class Initialized
INFO - 2023-11-23 11:12:23 --> URI Class Initialized
DEBUG - 2023-11-23 11:12:23 --> No URI present. Default controller set.
INFO - 2023-11-23 11:12:23 --> Router Class Initialized
INFO - 2023-11-23 11:12:23 --> Output Class Initialized
INFO - 2023-11-23 11:12:23 --> Security Class Initialized
DEBUG - 2023-11-23 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:12:23 --> Input Class Initialized
INFO - 2023-11-23 11:12:23 --> Language Class Initialized
INFO - 2023-11-23 11:12:23 --> Loader Class Initialized
INFO - 2023-11-23 11:12:23 --> Helper loaded: url_helper
INFO - 2023-11-23 11:12:23 --> Helper loaded: file_helper
INFO - 2023-11-23 11:12:23 --> Helper loaded: html_helper
INFO - 2023-11-23 11:12:23 --> Helper loaded: text_helper
INFO - 2023-11-23 11:12:23 --> Helper loaded: form_helper
INFO - 2023-11-23 11:12:23 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:12:23 --> Helper loaded: security_helper
INFO - 2023-11-23 11:12:23 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:12:23 --> Database Driver Class Initialized
INFO - 2023-11-23 11:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:12:23 --> Parser Class Initialized
INFO - 2023-11-23 11:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:12:23 --> Pagination Class Initialized
INFO - 2023-11-23 11:12:23 --> Form Validation Class Initialized
INFO - 2023-11-23 11:12:23 --> Controller Class Initialized
INFO - 2023-11-23 11:12:23 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-23 11:12:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:12:24 --> Config Class Initialized
INFO - 2023-11-23 11:12:24 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:12:24 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:12:24 --> Utf8 Class Initialized
INFO - 2023-11-23 11:12:24 --> URI Class Initialized
INFO - 2023-11-23 11:12:24 --> Router Class Initialized
INFO - 2023-11-23 11:12:24 --> Output Class Initialized
INFO - 2023-11-23 11:12:24 --> Security Class Initialized
DEBUG - 2023-11-23 11:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:12:24 --> Input Class Initialized
INFO - 2023-11-23 11:12:24 --> Language Class Initialized
INFO - 2023-11-23 11:12:24 --> Loader Class Initialized
INFO - 2023-11-23 11:12:24 --> Helper loaded: url_helper
INFO - 2023-11-23 11:12:24 --> Helper loaded: file_helper
INFO - 2023-11-23 11:12:24 --> Helper loaded: html_helper
INFO - 2023-11-23 11:12:24 --> Helper loaded: text_helper
INFO - 2023-11-23 11:12:24 --> Helper loaded: form_helper
INFO - 2023-11-23 11:12:24 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:12:24 --> Helper loaded: security_helper
INFO - 2023-11-23 11:12:24 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:12:24 --> Database Driver Class Initialized
INFO - 2023-11-23 11:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:12:24 --> Parser Class Initialized
INFO - 2023-11-23 11:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:12:24 --> Pagination Class Initialized
INFO - 2023-11-23 11:12:24 --> Form Validation Class Initialized
INFO - 2023-11-23 11:12:24 --> Controller Class Initialized
INFO - 2023-11-23 11:12:24 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-23 11:12:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:12:24 --> Model Class Initialized
INFO - 2023-11-23 11:12:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:12:24 --> Final output sent to browser
DEBUG - 2023-11-23 11:12:24 --> Total execution time: 0.0334
ERROR - 2023-11-23 11:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:12:36 --> Config Class Initialized
INFO - 2023-11-23 11:12:36 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:12:36 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:12:36 --> Utf8 Class Initialized
INFO - 2023-11-23 11:12:36 --> URI Class Initialized
INFO - 2023-11-23 11:12:36 --> Router Class Initialized
INFO - 2023-11-23 11:12:36 --> Output Class Initialized
INFO - 2023-11-23 11:12:36 --> Security Class Initialized
DEBUG - 2023-11-23 11:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:12:36 --> Input Class Initialized
INFO - 2023-11-23 11:12:36 --> Language Class Initialized
INFO - 2023-11-23 11:12:36 --> Loader Class Initialized
INFO - 2023-11-23 11:12:36 --> Helper loaded: url_helper
INFO - 2023-11-23 11:12:36 --> Helper loaded: file_helper
INFO - 2023-11-23 11:12:36 --> Helper loaded: html_helper
INFO - 2023-11-23 11:12:36 --> Helper loaded: text_helper
INFO - 2023-11-23 11:12:36 --> Helper loaded: form_helper
INFO - 2023-11-23 11:12:36 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:12:36 --> Helper loaded: security_helper
INFO - 2023-11-23 11:12:36 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:12:36 --> Database Driver Class Initialized
INFO - 2023-11-23 11:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:12:36 --> Parser Class Initialized
INFO - 2023-11-23 11:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:12:36 --> Pagination Class Initialized
INFO - 2023-11-23 11:12:36 --> Form Validation Class Initialized
INFO - 2023-11-23 11:12:36 --> Controller Class Initialized
INFO - 2023-11-23 11:12:36 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:36 --> Model Class Initialized
INFO - 2023-11-23 11:12:36 --> Final output sent to browser
DEBUG - 2023-11-23 11:12:36 --> Total execution time: 0.0206
ERROR - 2023-11-23 11:12:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:12:37 --> Config Class Initialized
INFO - 2023-11-23 11:12:37 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:12:37 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:12:37 --> Utf8 Class Initialized
INFO - 2023-11-23 11:12:37 --> URI Class Initialized
DEBUG - 2023-11-23 11:12:37 --> No URI present. Default controller set.
INFO - 2023-11-23 11:12:37 --> Router Class Initialized
INFO - 2023-11-23 11:12:37 --> Output Class Initialized
INFO - 2023-11-23 11:12:37 --> Security Class Initialized
DEBUG - 2023-11-23 11:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:12:37 --> Input Class Initialized
INFO - 2023-11-23 11:12:37 --> Language Class Initialized
INFO - 2023-11-23 11:12:37 --> Loader Class Initialized
INFO - 2023-11-23 11:12:37 --> Helper loaded: url_helper
INFO - 2023-11-23 11:12:37 --> Helper loaded: file_helper
INFO - 2023-11-23 11:12:37 --> Helper loaded: html_helper
INFO - 2023-11-23 11:12:37 --> Helper loaded: text_helper
INFO - 2023-11-23 11:12:37 --> Helper loaded: form_helper
INFO - 2023-11-23 11:12:37 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:12:37 --> Helper loaded: security_helper
INFO - 2023-11-23 11:12:37 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:12:37 --> Database Driver Class Initialized
INFO - 2023-11-23 11:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:12:37 --> Parser Class Initialized
INFO - 2023-11-23 11:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:12:37 --> Pagination Class Initialized
INFO - 2023-11-23 11:12:37 --> Form Validation Class Initialized
INFO - 2023-11-23 11:12:37 --> Controller Class Initialized
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
INFO - 2023-11-23 11:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 11:12:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:12:37 --> Model Class Initialized
INFO - 2023-11-23 11:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:12:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:12:37 --> Final output sent to browser
DEBUG - 2023-11-23 11:12:37 --> Total execution time: 0.2265
ERROR - 2023-11-23 11:12:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:12:49 --> Config Class Initialized
INFO - 2023-11-23 11:12:49 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:12:49 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:12:49 --> Utf8 Class Initialized
INFO - 2023-11-23 11:12:49 --> URI Class Initialized
INFO - 2023-11-23 11:12:49 --> Router Class Initialized
INFO - 2023-11-23 11:12:49 --> Output Class Initialized
INFO - 2023-11-23 11:12:49 --> Security Class Initialized
DEBUG - 2023-11-23 11:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:12:49 --> Input Class Initialized
INFO - 2023-11-23 11:12:49 --> Language Class Initialized
INFO - 2023-11-23 11:12:49 --> Loader Class Initialized
INFO - 2023-11-23 11:12:49 --> Helper loaded: url_helper
INFO - 2023-11-23 11:12:49 --> Helper loaded: file_helper
INFO - 2023-11-23 11:12:49 --> Helper loaded: html_helper
INFO - 2023-11-23 11:12:49 --> Helper loaded: text_helper
INFO - 2023-11-23 11:12:49 --> Helper loaded: form_helper
INFO - 2023-11-23 11:12:49 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:12:49 --> Helper loaded: security_helper
INFO - 2023-11-23 11:12:49 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:12:49 --> Database Driver Class Initialized
INFO - 2023-11-23 11:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:12:49 --> Parser Class Initialized
INFO - 2023-11-23 11:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:12:49 --> Pagination Class Initialized
INFO - 2023-11-23 11:12:49 --> Form Validation Class Initialized
INFO - 2023-11-23 11:12:49 --> Controller Class Initialized
INFO - 2023-11-23 11:12:49 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:49 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:49 --> Model Class Initialized
INFO - 2023-11-23 11:12:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-11-23 11:12:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:12:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:12:49 --> Model Class Initialized
INFO - 2023-11-23 11:12:49 --> Model Class Initialized
INFO - 2023-11-23 11:12:49 --> Model Class Initialized
INFO - 2023-11-23 11:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:12:50 --> Final output sent to browser
DEBUG - 2023-11-23 11:12:50 --> Total execution time: 0.1665
ERROR - 2023-11-23 11:12:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:12:58 --> Config Class Initialized
INFO - 2023-11-23 11:12:58 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:12:58 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:12:58 --> Utf8 Class Initialized
INFO - 2023-11-23 11:12:58 --> URI Class Initialized
DEBUG - 2023-11-23 11:12:58 --> No URI present. Default controller set.
INFO - 2023-11-23 11:12:58 --> Router Class Initialized
INFO - 2023-11-23 11:12:58 --> Output Class Initialized
INFO - 2023-11-23 11:12:58 --> Security Class Initialized
DEBUG - 2023-11-23 11:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:12:58 --> Input Class Initialized
INFO - 2023-11-23 11:12:58 --> Language Class Initialized
INFO - 2023-11-23 11:12:58 --> Loader Class Initialized
INFO - 2023-11-23 11:12:58 --> Helper loaded: url_helper
INFO - 2023-11-23 11:12:58 --> Helper loaded: file_helper
INFO - 2023-11-23 11:12:58 --> Helper loaded: html_helper
INFO - 2023-11-23 11:12:58 --> Helper loaded: text_helper
INFO - 2023-11-23 11:12:58 --> Helper loaded: form_helper
INFO - 2023-11-23 11:12:58 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:12:58 --> Helper loaded: security_helper
INFO - 2023-11-23 11:12:58 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:12:58 --> Database Driver Class Initialized
INFO - 2023-11-23 11:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:12:58 --> Parser Class Initialized
INFO - 2023-11-23 11:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:12:58 --> Pagination Class Initialized
INFO - 2023-11-23 11:12:58 --> Form Validation Class Initialized
INFO - 2023-11-23 11:12:58 --> Controller Class Initialized
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
DEBUG - 2023-11-23 11:12:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
INFO - 2023-11-23 11:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 11:12:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:12:58 --> Model Class Initialized
INFO - 2023-11-23 11:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:12:58 --> Final output sent to browser
DEBUG - 2023-11-23 11:12:58 --> Total execution time: 0.2144
ERROR - 2023-11-23 11:13:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:13:01 --> Config Class Initialized
INFO - 2023-11-23 11:13:01 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:13:01 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:13:01 --> Utf8 Class Initialized
INFO - 2023-11-23 11:13:01 --> URI Class Initialized
INFO - 2023-11-23 11:13:01 --> Router Class Initialized
INFO - 2023-11-23 11:13:01 --> Output Class Initialized
INFO - 2023-11-23 11:13:01 --> Security Class Initialized
DEBUG - 2023-11-23 11:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:13:01 --> Input Class Initialized
INFO - 2023-11-23 11:13:01 --> Language Class Initialized
INFO - 2023-11-23 11:13:01 --> Loader Class Initialized
INFO - 2023-11-23 11:13:01 --> Helper loaded: url_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: file_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: html_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: text_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: form_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: security_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:13:01 --> Database Driver Class Initialized
INFO - 2023-11-23 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:13:01 --> Parser Class Initialized
INFO - 2023-11-23 11:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:13:01 --> Pagination Class Initialized
INFO - 2023-11-23 11:13:01 --> Form Validation Class Initialized
INFO - 2023-11-23 11:13:01 --> Controller Class Initialized
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-23 11:13:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
INFO - 2023-11-23 11:13:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:13:01 --> Final output sent to browser
DEBUG - 2023-11-23 11:13:01 --> Total execution time: 0.0284
ERROR - 2023-11-23 11:13:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:13:01 --> Config Class Initialized
INFO - 2023-11-23 11:13:01 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:13:01 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:13:01 --> Utf8 Class Initialized
INFO - 2023-11-23 11:13:01 --> URI Class Initialized
INFO - 2023-11-23 11:13:01 --> Router Class Initialized
INFO - 2023-11-23 11:13:01 --> Output Class Initialized
INFO - 2023-11-23 11:13:01 --> Security Class Initialized
DEBUG - 2023-11-23 11:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:13:01 --> Input Class Initialized
INFO - 2023-11-23 11:13:01 --> Language Class Initialized
INFO - 2023-11-23 11:13:01 --> Loader Class Initialized
INFO - 2023-11-23 11:13:01 --> Helper loaded: url_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: file_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: html_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: text_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: form_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: security_helper
INFO - 2023-11-23 11:13:01 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:13:01 --> Database Driver Class Initialized
INFO - 2023-11-23 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:13:01 --> Parser Class Initialized
INFO - 2023-11-23 11:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:13:01 --> Pagination Class Initialized
INFO - 2023-11-23 11:13:01 --> Form Validation Class Initialized
INFO - 2023-11-23 11:13:01 --> Controller Class Initialized
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
INFO - 2023-11-23 11:13:01 --> Model Class Initialized
INFO - 2023-11-23 11:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 11:13:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:13:02 --> Model Class Initialized
INFO - 2023-11-23 11:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:13:02 --> Final output sent to browser
DEBUG - 2023-11-23 11:13:02 --> Total execution time: 0.2307
ERROR - 2023-11-23 11:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:13:40 --> Config Class Initialized
INFO - 2023-11-23 11:13:40 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:13:40 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:13:40 --> Utf8 Class Initialized
INFO - 2023-11-23 11:13:40 --> URI Class Initialized
INFO - 2023-11-23 11:13:40 --> Router Class Initialized
INFO - 2023-11-23 11:13:40 --> Output Class Initialized
INFO - 2023-11-23 11:13:40 --> Security Class Initialized
DEBUG - 2023-11-23 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:13:40 --> Input Class Initialized
INFO - 2023-11-23 11:13:40 --> Language Class Initialized
INFO - 2023-11-23 11:13:40 --> Loader Class Initialized
INFO - 2023-11-23 11:13:40 --> Helper loaded: url_helper
INFO - 2023-11-23 11:13:40 --> Helper loaded: file_helper
INFO - 2023-11-23 11:13:40 --> Helper loaded: html_helper
INFO - 2023-11-23 11:13:40 --> Helper loaded: text_helper
INFO - 2023-11-23 11:13:40 --> Helper loaded: form_helper
INFO - 2023-11-23 11:13:40 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:13:40 --> Helper loaded: security_helper
INFO - 2023-11-23 11:13:40 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:13:40 --> Database Driver Class Initialized
INFO - 2023-11-23 11:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:13:40 --> Parser Class Initialized
INFO - 2023-11-23 11:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:13:40 --> Pagination Class Initialized
INFO - 2023-11-23 11:13:40 --> Form Validation Class Initialized
INFO - 2023-11-23 11:13:40 --> Controller Class Initialized
INFO - 2023-11-23 11:13:40 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:40 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:40 --> Model Class Initialized
INFO - 2023-11-23 11:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-23 11:13:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:13:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:13:40 --> Model Class Initialized
INFO - 2023-11-23 11:13:40 --> Model Class Initialized
INFO - 2023-11-23 11:13:40 --> Model Class Initialized
INFO - 2023-11-23 11:13:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:13:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:13:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:13:41 --> Final output sent to browser
DEBUG - 2023-11-23 11:13:41 --> Total execution time: 0.1445
ERROR - 2023-11-23 11:13:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:13:42 --> Config Class Initialized
INFO - 2023-11-23 11:13:42 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:13:42 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:13:42 --> Utf8 Class Initialized
INFO - 2023-11-23 11:13:42 --> URI Class Initialized
INFO - 2023-11-23 11:13:42 --> Router Class Initialized
INFO - 2023-11-23 11:13:42 --> Output Class Initialized
INFO - 2023-11-23 11:13:42 --> Security Class Initialized
DEBUG - 2023-11-23 11:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:13:42 --> Input Class Initialized
INFO - 2023-11-23 11:13:42 --> Language Class Initialized
INFO - 2023-11-23 11:13:42 --> Loader Class Initialized
INFO - 2023-11-23 11:13:42 --> Helper loaded: url_helper
INFO - 2023-11-23 11:13:42 --> Helper loaded: file_helper
INFO - 2023-11-23 11:13:42 --> Helper loaded: html_helper
INFO - 2023-11-23 11:13:42 --> Helper loaded: text_helper
INFO - 2023-11-23 11:13:42 --> Helper loaded: form_helper
INFO - 2023-11-23 11:13:42 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:13:42 --> Helper loaded: security_helper
INFO - 2023-11-23 11:13:42 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:13:42 --> Database Driver Class Initialized
INFO - 2023-11-23 11:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:13:42 --> Parser Class Initialized
INFO - 2023-11-23 11:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:13:42 --> Pagination Class Initialized
INFO - 2023-11-23 11:13:42 --> Form Validation Class Initialized
INFO - 2023-11-23 11:13:42 --> Controller Class Initialized
INFO - 2023-11-23 11:13:42 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:42 --> Model Class Initialized
DEBUG - 2023-11-23 11:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:13:42 --> Model Class Initialized
INFO - 2023-11-23 11:13:42 --> Final output sent to browser
DEBUG - 2023-11-23 11:13:42 --> Total execution time: 0.0385
ERROR - 2023-11-23 11:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:14:13 --> Config Class Initialized
INFO - 2023-11-23 11:14:13 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:14:13 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:14:13 --> Utf8 Class Initialized
INFO - 2023-11-23 11:14:13 --> URI Class Initialized
INFO - 2023-11-23 11:14:13 --> Router Class Initialized
INFO - 2023-11-23 11:14:13 --> Output Class Initialized
INFO - 2023-11-23 11:14:13 --> Security Class Initialized
DEBUG - 2023-11-23 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:14:13 --> Input Class Initialized
INFO - 2023-11-23 11:14:13 --> Language Class Initialized
INFO - 2023-11-23 11:14:13 --> Loader Class Initialized
INFO - 2023-11-23 11:14:13 --> Helper loaded: url_helper
INFO - 2023-11-23 11:14:13 --> Helper loaded: file_helper
INFO - 2023-11-23 11:14:13 --> Helper loaded: html_helper
INFO - 2023-11-23 11:14:13 --> Helper loaded: text_helper
INFO - 2023-11-23 11:14:13 --> Helper loaded: form_helper
INFO - 2023-11-23 11:14:13 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:14:13 --> Helper loaded: security_helper
INFO - 2023-11-23 11:14:13 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:14:13 --> Database Driver Class Initialized
INFO - 2023-11-23 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:14:13 --> Parser Class Initialized
INFO - 2023-11-23 11:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:14:13 --> Pagination Class Initialized
INFO - 2023-11-23 11:14:13 --> Form Validation Class Initialized
INFO - 2023-11-23 11:14:13 --> Controller Class Initialized
INFO - 2023-11-23 11:14:13 --> Model Class Initialized
DEBUG - 2023-11-23 11:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:14:13 --> Model Class Initialized
DEBUG - 2023-11-23 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:14:13 --> Model Class Initialized
DEBUG - 2023-11-23 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-11-23 11:14:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:14:13 --> Model Class Initialized
INFO - 2023-11-23 11:14:13 --> Model Class Initialized
INFO - 2023-11-23 11:14:13 --> Model Class Initialized
INFO - 2023-11-23 11:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:14:14 --> Final output sent to browser
DEBUG - 2023-11-23 11:14:14 --> Total execution time: 0.1533
ERROR - 2023-11-23 11:15:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:15:22 --> Config Class Initialized
INFO - 2023-11-23 11:15:22 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:15:22 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:15:22 --> Utf8 Class Initialized
INFO - 2023-11-23 11:15:22 --> URI Class Initialized
INFO - 2023-11-23 11:15:22 --> Router Class Initialized
INFO - 2023-11-23 11:15:22 --> Output Class Initialized
INFO - 2023-11-23 11:15:22 --> Security Class Initialized
DEBUG - 2023-11-23 11:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:15:22 --> Input Class Initialized
INFO - 2023-11-23 11:15:22 --> Language Class Initialized
INFO - 2023-11-23 11:15:22 --> Loader Class Initialized
INFO - 2023-11-23 11:15:22 --> Helper loaded: url_helper
INFO - 2023-11-23 11:15:22 --> Helper loaded: file_helper
INFO - 2023-11-23 11:15:22 --> Helper loaded: html_helper
INFO - 2023-11-23 11:15:22 --> Helper loaded: text_helper
INFO - 2023-11-23 11:15:22 --> Helper loaded: form_helper
INFO - 2023-11-23 11:15:22 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:15:22 --> Helper loaded: security_helper
INFO - 2023-11-23 11:15:22 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:15:22 --> Database Driver Class Initialized
INFO - 2023-11-23 11:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:15:22 --> Parser Class Initialized
INFO - 2023-11-23 11:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:15:22 --> Pagination Class Initialized
INFO - 2023-11-23 11:15:22 --> Form Validation Class Initialized
INFO - 2023-11-23 11:15:22 --> Controller Class Initialized
INFO - 2023-11-23 11:15:22 --> Model Class Initialized
DEBUG - 2023-11-23 11:15:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:22 --> Model Class Initialized
DEBUG - 2023-11-23 11:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:22 --> Model Class Initialized
INFO - 2023-11-23 11:15:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-23 11:15:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:15:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:15:22 --> Model Class Initialized
INFO - 2023-11-23 11:15:22 --> Model Class Initialized
INFO - 2023-11-23 11:15:22 --> Model Class Initialized
INFO - 2023-11-23 11:15:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:15:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:15:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:15:22 --> Final output sent to browser
DEBUG - 2023-11-23 11:15:22 --> Total execution time: 0.1525
ERROR - 2023-11-23 11:15:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:15:23 --> Config Class Initialized
INFO - 2023-11-23 11:15:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:15:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:15:23 --> Utf8 Class Initialized
INFO - 2023-11-23 11:15:23 --> URI Class Initialized
INFO - 2023-11-23 11:15:23 --> Router Class Initialized
INFO - 2023-11-23 11:15:23 --> Output Class Initialized
INFO - 2023-11-23 11:15:23 --> Security Class Initialized
DEBUG - 2023-11-23 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:15:23 --> Input Class Initialized
INFO - 2023-11-23 11:15:23 --> Language Class Initialized
INFO - 2023-11-23 11:15:23 --> Loader Class Initialized
INFO - 2023-11-23 11:15:23 --> Helper loaded: url_helper
INFO - 2023-11-23 11:15:23 --> Helper loaded: file_helper
INFO - 2023-11-23 11:15:23 --> Helper loaded: html_helper
INFO - 2023-11-23 11:15:23 --> Helper loaded: text_helper
INFO - 2023-11-23 11:15:23 --> Helper loaded: form_helper
INFO - 2023-11-23 11:15:23 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:15:23 --> Helper loaded: security_helper
INFO - 2023-11-23 11:15:23 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:15:23 --> Database Driver Class Initialized
INFO - 2023-11-23 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:15:23 --> Parser Class Initialized
INFO - 2023-11-23 11:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:15:23 --> Pagination Class Initialized
INFO - 2023-11-23 11:15:23 --> Form Validation Class Initialized
INFO - 2023-11-23 11:15:23 --> Controller Class Initialized
INFO - 2023-11-23 11:15:23 --> Model Class Initialized
DEBUG - 2023-11-23 11:15:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:23 --> Model Class Initialized
DEBUG - 2023-11-23 11:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:23 --> Model Class Initialized
INFO - 2023-11-23 11:15:23 --> Final output sent to browser
DEBUG - 2023-11-23 11:15:23 --> Total execution time: 0.0414
ERROR - 2023-11-23 11:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:15:26 --> Config Class Initialized
INFO - 2023-11-23 11:15:26 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:15:26 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:15:26 --> Utf8 Class Initialized
INFO - 2023-11-23 11:15:26 --> URI Class Initialized
INFO - 2023-11-23 11:15:26 --> Router Class Initialized
INFO - 2023-11-23 11:15:26 --> Output Class Initialized
INFO - 2023-11-23 11:15:26 --> Security Class Initialized
DEBUG - 2023-11-23 11:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:15:26 --> Input Class Initialized
INFO - 2023-11-23 11:15:26 --> Language Class Initialized
INFO - 2023-11-23 11:15:26 --> Loader Class Initialized
INFO - 2023-11-23 11:15:26 --> Helper loaded: url_helper
INFO - 2023-11-23 11:15:26 --> Helper loaded: file_helper
INFO - 2023-11-23 11:15:26 --> Helper loaded: html_helper
INFO - 2023-11-23 11:15:26 --> Helper loaded: text_helper
INFO - 2023-11-23 11:15:26 --> Helper loaded: form_helper
INFO - 2023-11-23 11:15:26 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:15:26 --> Helper loaded: security_helper
INFO - 2023-11-23 11:15:26 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:15:26 --> Database Driver Class Initialized
INFO - 2023-11-23 11:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:15:26 --> Parser Class Initialized
INFO - 2023-11-23 11:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:15:26 --> Pagination Class Initialized
INFO - 2023-11-23 11:15:26 --> Form Validation Class Initialized
INFO - 2023-11-23 11:15:26 --> Controller Class Initialized
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
DEBUG - 2023-11-23 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
DEBUG - 2023-11-23 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
DEBUG - 2023-11-23 11:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
INFO - 2023-11-23 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 11:15:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 11:15:26 --> Model Class Initialized
INFO - 2023-11-23 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 11:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 11:15:26 --> Final output sent to browser
DEBUG - 2023-11-23 11:15:26 --> Total execution time: 0.2135
ERROR - 2023-11-23 11:31:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:31:03 --> Config Class Initialized
INFO - 2023-11-23 11:31:03 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:31:03 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:31:03 --> Utf8 Class Initialized
INFO - 2023-11-23 11:31:03 --> URI Class Initialized
INFO - 2023-11-23 11:31:03 --> Router Class Initialized
INFO - 2023-11-23 11:31:03 --> Output Class Initialized
INFO - 2023-11-23 11:31:03 --> Security Class Initialized
DEBUG - 2023-11-23 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:31:03 --> Input Class Initialized
INFO - 2023-11-23 11:31:03 --> Language Class Initialized
ERROR - 2023-11-23 11:31:03 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-11-23 11:31:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:31:04 --> Config Class Initialized
INFO - 2023-11-23 11:31:04 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:31:04 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:31:04 --> Utf8 Class Initialized
INFO - 2023-11-23 11:31:04 --> URI Class Initialized
DEBUG - 2023-11-23 11:31:04 --> No URI present. Default controller set.
INFO - 2023-11-23 11:31:04 --> Router Class Initialized
INFO - 2023-11-23 11:31:04 --> Output Class Initialized
INFO - 2023-11-23 11:31:04 --> Security Class Initialized
DEBUG - 2023-11-23 11:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:31:04 --> Input Class Initialized
INFO - 2023-11-23 11:31:04 --> Language Class Initialized
INFO - 2023-11-23 11:31:04 --> Loader Class Initialized
INFO - 2023-11-23 11:31:04 --> Helper loaded: url_helper
INFO - 2023-11-23 11:31:04 --> Helper loaded: file_helper
INFO - 2023-11-23 11:31:04 --> Helper loaded: html_helper
INFO - 2023-11-23 11:31:04 --> Helper loaded: text_helper
INFO - 2023-11-23 11:31:04 --> Helper loaded: form_helper
INFO - 2023-11-23 11:31:04 --> Helper loaded: lang_helper
INFO - 2023-11-23 11:31:04 --> Helper loaded: security_helper
INFO - 2023-11-23 11:31:04 --> Helper loaded: cookie_helper
INFO - 2023-11-23 11:31:04 --> Database Driver Class Initialized
INFO - 2023-11-23 11:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:31:04 --> Parser Class Initialized
INFO - 2023-11-23 11:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 11:31:04 --> Pagination Class Initialized
INFO - 2023-11-23 11:31:04 --> Form Validation Class Initialized
INFO - 2023-11-23 11:31:04 --> Controller Class Initialized
INFO - 2023-11-23 11:31:04 --> Model Class Initialized
DEBUG - 2023-11-23 11:31:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-23 11:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:31:05 --> Config Class Initialized
INFO - 2023-11-23 11:31:05 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:31:05 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:31:05 --> Utf8 Class Initialized
INFO - 2023-11-23 11:31:05 --> URI Class Initialized
INFO - 2023-11-23 11:31:05 --> Router Class Initialized
INFO - 2023-11-23 11:31:05 --> Output Class Initialized
INFO - 2023-11-23 11:31:05 --> Security Class Initialized
DEBUG - 2023-11-23 11:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:31:05 --> Input Class Initialized
INFO - 2023-11-23 11:31:05 --> Language Class Initialized
ERROR - 2023-11-23 11:31:05 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2023-11-23 15:58:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 15:58:50 --> Config Class Initialized
INFO - 2023-11-23 15:58:50 --> Hooks Class Initialized
DEBUG - 2023-11-23 15:58:50 --> UTF-8 Support Enabled
INFO - 2023-11-23 15:58:50 --> Utf8 Class Initialized
INFO - 2023-11-23 15:58:50 --> URI Class Initialized
DEBUG - 2023-11-23 15:58:50 --> No URI present. Default controller set.
INFO - 2023-11-23 15:58:50 --> Router Class Initialized
INFO - 2023-11-23 15:58:50 --> Output Class Initialized
INFO - 2023-11-23 15:58:50 --> Security Class Initialized
DEBUG - 2023-11-23 15:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 15:58:50 --> Input Class Initialized
INFO - 2023-11-23 15:58:50 --> Language Class Initialized
INFO - 2023-11-23 15:58:50 --> Loader Class Initialized
INFO - 2023-11-23 15:58:50 --> Helper loaded: url_helper
INFO - 2023-11-23 15:58:50 --> Helper loaded: file_helper
INFO - 2023-11-23 15:58:50 --> Helper loaded: html_helper
INFO - 2023-11-23 15:58:50 --> Helper loaded: text_helper
INFO - 2023-11-23 15:58:50 --> Helper loaded: form_helper
INFO - 2023-11-23 15:58:50 --> Helper loaded: lang_helper
INFO - 2023-11-23 15:58:50 --> Helper loaded: security_helper
INFO - 2023-11-23 15:58:50 --> Helper loaded: cookie_helper
INFO - 2023-11-23 15:58:50 --> Database Driver Class Initialized
INFO - 2023-11-23 15:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 15:58:50 --> Parser Class Initialized
INFO - 2023-11-23 15:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 15:58:50 --> Pagination Class Initialized
INFO - 2023-11-23 15:58:50 --> Form Validation Class Initialized
INFO - 2023-11-23 15:58:50 --> Controller Class Initialized
INFO - 2023-11-23 15:58:50 --> Model Class Initialized
DEBUG - 2023-11-23 15:58:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-23 15:58:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 15:58:51 --> Config Class Initialized
INFO - 2023-11-23 15:58:51 --> Hooks Class Initialized
DEBUG - 2023-11-23 15:58:51 --> UTF-8 Support Enabled
INFO - 2023-11-23 15:58:51 --> Utf8 Class Initialized
INFO - 2023-11-23 15:58:51 --> URI Class Initialized
INFO - 2023-11-23 15:58:51 --> Router Class Initialized
INFO - 2023-11-23 15:58:51 --> Output Class Initialized
INFO - 2023-11-23 15:58:51 --> Security Class Initialized
DEBUG - 2023-11-23 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 15:58:51 --> Input Class Initialized
INFO - 2023-11-23 15:58:51 --> Language Class Initialized
INFO - 2023-11-23 15:58:51 --> Loader Class Initialized
INFO - 2023-11-23 15:58:51 --> Helper loaded: url_helper
INFO - 2023-11-23 15:58:51 --> Helper loaded: file_helper
INFO - 2023-11-23 15:58:51 --> Helper loaded: html_helper
INFO - 2023-11-23 15:58:51 --> Helper loaded: text_helper
INFO - 2023-11-23 15:58:51 --> Helper loaded: form_helper
INFO - 2023-11-23 15:58:51 --> Helper loaded: lang_helper
INFO - 2023-11-23 15:58:51 --> Helper loaded: security_helper
INFO - 2023-11-23 15:58:51 --> Helper loaded: cookie_helper
INFO - 2023-11-23 15:58:51 --> Database Driver Class Initialized
INFO - 2023-11-23 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 15:58:51 --> Parser Class Initialized
INFO - 2023-11-23 15:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 15:58:51 --> Pagination Class Initialized
INFO - 2023-11-23 15:58:51 --> Form Validation Class Initialized
INFO - 2023-11-23 15:58:51 --> Controller Class Initialized
INFO - 2023-11-23 15:58:51 --> Model Class Initialized
DEBUG - 2023-11-23 15:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-23 15:58:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 15:58:51 --> Model Class Initialized
INFO - 2023-11-23 15:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 15:58:51 --> Final output sent to browser
DEBUG - 2023-11-23 15:58:51 --> Total execution time: 0.0342
ERROR - 2023-11-23 15:58:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 15:58:54 --> Config Class Initialized
INFO - 2023-11-23 15:58:54 --> Hooks Class Initialized
DEBUG - 2023-11-23 15:58:54 --> UTF-8 Support Enabled
INFO - 2023-11-23 15:58:54 --> Utf8 Class Initialized
INFO - 2023-11-23 15:58:54 --> URI Class Initialized
INFO - 2023-11-23 15:58:54 --> Router Class Initialized
INFO - 2023-11-23 15:58:54 --> Output Class Initialized
INFO - 2023-11-23 15:58:54 --> Security Class Initialized
DEBUG - 2023-11-23 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 15:58:54 --> Input Class Initialized
INFO - 2023-11-23 15:58:54 --> Language Class Initialized
INFO - 2023-11-23 15:58:54 --> Loader Class Initialized
INFO - 2023-11-23 15:58:54 --> Helper loaded: url_helper
INFO - 2023-11-23 15:58:54 --> Helper loaded: file_helper
INFO - 2023-11-23 15:58:54 --> Helper loaded: html_helper
INFO - 2023-11-23 15:58:54 --> Helper loaded: text_helper
INFO - 2023-11-23 15:58:54 --> Helper loaded: form_helper
INFO - 2023-11-23 15:58:54 --> Helper loaded: lang_helper
INFO - 2023-11-23 15:58:54 --> Helper loaded: security_helper
INFO - 2023-11-23 15:58:54 --> Helper loaded: cookie_helper
INFO - 2023-11-23 15:58:54 --> Database Driver Class Initialized
INFO - 2023-11-23 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 15:58:54 --> Parser Class Initialized
INFO - 2023-11-23 15:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 15:58:54 --> Pagination Class Initialized
INFO - 2023-11-23 15:58:54 --> Form Validation Class Initialized
INFO - 2023-11-23 15:58:54 --> Controller Class Initialized
INFO - 2023-11-23 15:58:54 --> Model Class Initialized
DEBUG - 2023-11-23 15:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:54 --> Model Class Initialized
INFO - 2023-11-23 15:58:54 --> Final output sent to browser
DEBUG - 2023-11-23 15:58:54 --> Total execution time: 0.0196
ERROR - 2023-11-23 15:58:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 15:58:55 --> Config Class Initialized
INFO - 2023-11-23 15:58:55 --> Hooks Class Initialized
DEBUG - 2023-11-23 15:58:55 --> UTF-8 Support Enabled
INFO - 2023-11-23 15:58:55 --> Utf8 Class Initialized
INFO - 2023-11-23 15:58:55 --> URI Class Initialized
DEBUG - 2023-11-23 15:58:55 --> No URI present. Default controller set.
INFO - 2023-11-23 15:58:55 --> Router Class Initialized
INFO - 2023-11-23 15:58:55 --> Output Class Initialized
INFO - 2023-11-23 15:58:55 --> Security Class Initialized
DEBUG - 2023-11-23 15:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 15:58:55 --> Input Class Initialized
INFO - 2023-11-23 15:58:55 --> Language Class Initialized
INFO - 2023-11-23 15:58:55 --> Loader Class Initialized
INFO - 2023-11-23 15:58:55 --> Helper loaded: url_helper
INFO - 2023-11-23 15:58:55 --> Helper loaded: file_helper
INFO - 2023-11-23 15:58:55 --> Helper loaded: html_helper
INFO - 2023-11-23 15:58:55 --> Helper loaded: text_helper
INFO - 2023-11-23 15:58:55 --> Helper loaded: form_helper
INFO - 2023-11-23 15:58:55 --> Helper loaded: lang_helper
INFO - 2023-11-23 15:58:55 --> Helper loaded: security_helper
INFO - 2023-11-23 15:58:55 --> Helper loaded: cookie_helper
INFO - 2023-11-23 15:58:55 --> Database Driver Class Initialized
INFO - 2023-11-23 15:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 15:58:55 --> Parser Class Initialized
INFO - 2023-11-23 15:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 15:58:55 --> Pagination Class Initialized
INFO - 2023-11-23 15:58:55 --> Form Validation Class Initialized
INFO - 2023-11-23 15:58:55 --> Controller Class Initialized
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
DEBUG - 2023-11-23 15:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
DEBUG - 2023-11-23 15:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
DEBUG - 2023-11-23 15:58:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 15:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
INFO - 2023-11-23 15:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 15:58:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 15:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 15:58:55 --> Model Class Initialized
INFO - 2023-11-23 15:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 15:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 15:58:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 15:58:55 --> Final output sent to browser
DEBUG - 2023-11-23 15:58:55 --> Total execution time: 0.3947
ERROR - 2023-11-23 15:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 15:58:56 --> Config Class Initialized
INFO - 2023-11-23 15:58:56 --> Hooks Class Initialized
DEBUG - 2023-11-23 15:58:56 --> UTF-8 Support Enabled
INFO - 2023-11-23 15:58:56 --> Utf8 Class Initialized
INFO - 2023-11-23 15:58:56 --> URI Class Initialized
INFO - 2023-11-23 15:58:56 --> Router Class Initialized
INFO - 2023-11-23 15:58:56 --> Output Class Initialized
INFO - 2023-11-23 15:58:56 --> Security Class Initialized
DEBUG - 2023-11-23 15:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 15:58:56 --> Input Class Initialized
INFO - 2023-11-23 15:58:56 --> Language Class Initialized
INFO - 2023-11-23 15:58:56 --> Loader Class Initialized
INFO - 2023-11-23 15:58:56 --> Helper loaded: url_helper
INFO - 2023-11-23 15:58:56 --> Helper loaded: file_helper
INFO - 2023-11-23 15:58:56 --> Helper loaded: html_helper
INFO - 2023-11-23 15:58:56 --> Helper loaded: text_helper
INFO - 2023-11-23 15:58:56 --> Helper loaded: form_helper
INFO - 2023-11-23 15:58:56 --> Helper loaded: lang_helper
INFO - 2023-11-23 15:58:56 --> Helper loaded: security_helper
INFO - 2023-11-23 15:58:56 --> Helper loaded: cookie_helper
INFO - 2023-11-23 15:58:56 --> Database Driver Class Initialized
INFO - 2023-11-23 15:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 15:58:56 --> Parser Class Initialized
INFO - 2023-11-23 15:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 15:58:56 --> Pagination Class Initialized
INFO - 2023-11-23 15:58:56 --> Form Validation Class Initialized
INFO - 2023-11-23 15:58:56 --> Controller Class Initialized
DEBUG - 2023-11-23 15:58:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 15:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 15:58:56 --> Model Class Initialized
INFO - 2023-11-23 15:58:56 --> Final output sent to browser
DEBUG - 2023-11-23 15:58:56 --> Total execution time: 0.0140
ERROR - 2023-11-23 16:04:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:04:59 --> Config Class Initialized
INFO - 2023-11-23 16:04:59 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:04:59 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:04:59 --> Utf8 Class Initialized
INFO - 2023-11-23 16:04:59 --> URI Class Initialized
DEBUG - 2023-11-23 16:04:59 --> No URI present. Default controller set.
INFO - 2023-11-23 16:04:59 --> Router Class Initialized
INFO - 2023-11-23 16:04:59 --> Output Class Initialized
INFO - 2023-11-23 16:04:59 --> Security Class Initialized
DEBUG - 2023-11-23 16:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:04:59 --> Input Class Initialized
INFO - 2023-11-23 16:04:59 --> Language Class Initialized
INFO - 2023-11-23 16:04:59 --> Loader Class Initialized
INFO - 2023-11-23 16:04:59 --> Helper loaded: url_helper
INFO - 2023-11-23 16:04:59 --> Helper loaded: file_helper
INFO - 2023-11-23 16:04:59 --> Helper loaded: html_helper
INFO - 2023-11-23 16:04:59 --> Helper loaded: text_helper
INFO - 2023-11-23 16:04:59 --> Helper loaded: form_helper
INFO - 2023-11-23 16:04:59 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:04:59 --> Helper loaded: security_helper
INFO - 2023-11-23 16:04:59 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:04:59 --> Database Driver Class Initialized
INFO - 2023-11-23 16:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:04:59 --> Parser Class Initialized
INFO - 2023-11-23 16:04:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:04:59 --> Pagination Class Initialized
INFO - 2023-11-23 16:04:59 --> Form Validation Class Initialized
INFO - 2023-11-23 16:04:59 --> Controller Class Initialized
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
DEBUG - 2023-11-23 16:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
DEBUG - 2023-11-23 16:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
DEBUG - 2023-11-23 16:04:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
INFO - 2023-11-23 16:04:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 16:04:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:04:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:04:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:04:59 --> Model Class Initialized
INFO - 2023-11-23 16:04:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:04:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:04:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:04:59 --> Final output sent to browser
DEBUG - 2023-11-23 16:04:59 --> Total execution time: 0.3990
ERROR - 2023-11-23 16:05:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:05:03 --> Config Class Initialized
INFO - 2023-11-23 16:05:03 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:05:03 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:05:03 --> Utf8 Class Initialized
INFO - 2023-11-23 16:05:03 --> URI Class Initialized
INFO - 2023-11-23 16:05:03 --> Router Class Initialized
INFO - 2023-11-23 16:05:03 --> Output Class Initialized
INFO - 2023-11-23 16:05:03 --> Security Class Initialized
DEBUG - 2023-11-23 16:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:05:03 --> Input Class Initialized
INFO - 2023-11-23 16:05:03 --> Language Class Initialized
INFO - 2023-11-23 16:05:03 --> Loader Class Initialized
INFO - 2023-11-23 16:05:03 --> Helper loaded: url_helper
INFO - 2023-11-23 16:05:03 --> Helper loaded: file_helper
INFO - 2023-11-23 16:05:03 --> Helper loaded: html_helper
INFO - 2023-11-23 16:05:03 --> Helper loaded: text_helper
INFO - 2023-11-23 16:05:03 --> Helper loaded: form_helper
INFO - 2023-11-23 16:05:03 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:05:03 --> Helper loaded: security_helper
INFO - 2023-11-23 16:05:03 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:05:03 --> Database Driver Class Initialized
INFO - 2023-11-23 16:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:05:03 --> Parser Class Initialized
INFO - 2023-11-23 16:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:05:03 --> Pagination Class Initialized
INFO - 2023-11-23 16:05:03 --> Form Validation Class Initialized
INFO - 2023-11-23 16:05:03 --> Controller Class Initialized
DEBUG - 2023-11-23 16:05:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:03 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:03 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:03 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:03 --> Model Class Initialized
INFO - 2023-11-23 16:05:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-11-23 16:05:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:05:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:05:03 --> Model Class Initialized
INFO - 2023-11-23 16:05:03 --> Model Class Initialized
INFO - 2023-11-23 16:05:03 --> Model Class Initialized
INFO - 2023-11-23 16:05:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:05:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:05:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:05:03 --> Final output sent to browser
DEBUG - 2023-11-23 16:05:03 --> Total execution time: 0.2109
ERROR - 2023-11-23 16:05:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:05:04 --> Config Class Initialized
INFO - 2023-11-23 16:05:04 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:05:04 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:05:04 --> Utf8 Class Initialized
INFO - 2023-11-23 16:05:04 --> URI Class Initialized
INFO - 2023-11-23 16:05:04 --> Router Class Initialized
INFO - 2023-11-23 16:05:04 --> Output Class Initialized
INFO - 2023-11-23 16:05:04 --> Security Class Initialized
DEBUG - 2023-11-23 16:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:05:04 --> Input Class Initialized
INFO - 2023-11-23 16:05:04 --> Language Class Initialized
INFO - 2023-11-23 16:05:04 --> Loader Class Initialized
INFO - 2023-11-23 16:05:04 --> Helper loaded: url_helper
INFO - 2023-11-23 16:05:04 --> Helper loaded: file_helper
INFO - 2023-11-23 16:05:04 --> Helper loaded: html_helper
INFO - 2023-11-23 16:05:04 --> Helper loaded: text_helper
INFO - 2023-11-23 16:05:04 --> Helper loaded: form_helper
INFO - 2023-11-23 16:05:04 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:05:04 --> Helper loaded: security_helper
INFO - 2023-11-23 16:05:04 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:05:04 --> Database Driver Class Initialized
INFO - 2023-11-23 16:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:05:04 --> Parser Class Initialized
INFO - 2023-11-23 16:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:05:04 --> Pagination Class Initialized
INFO - 2023-11-23 16:05:04 --> Form Validation Class Initialized
INFO - 2023-11-23 16:05:04 --> Controller Class Initialized
DEBUG - 2023-11-23 16:05:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:04 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:04 --> Model Class Initialized
INFO - 2023-11-23 16:05:04 --> Final output sent to browser
DEBUG - 2023-11-23 16:05:04 --> Total execution time: 0.0391
ERROR - 2023-11-23 16:05:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:05:09 --> Config Class Initialized
INFO - 2023-11-23 16:05:09 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:05:09 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:05:09 --> Utf8 Class Initialized
INFO - 2023-11-23 16:05:09 --> URI Class Initialized
INFO - 2023-11-23 16:05:09 --> Router Class Initialized
INFO - 2023-11-23 16:05:09 --> Output Class Initialized
INFO - 2023-11-23 16:05:09 --> Security Class Initialized
DEBUG - 2023-11-23 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:05:09 --> Input Class Initialized
INFO - 2023-11-23 16:05:09 --> Language Class Initialized
INFO - 2023-11-23 16:05:09 --> Loader Class Initialized
INFO - 2023-11-23 16:05:09 --> Helper loaded: url_helper
INFO - 2023-11-23 16:05:09 --> Helper loaded: file_helper
INFO - 2023-11-23 16:05:09 --> Helper loaded: html_helper
INFO - 2023-11-23 16:05:09 --> Helper loaded: text_helper
INFO - 2023-11-23 16:05:09 --> Helper loaded: form_helper
INFO - 2023-11-23 16:05:09 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:05:09 --> Helper loaded: security_helper
INFO - 2023-11-23 16:05:09 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:05:09 --> Database Driver Class Initialized
INFO - 2023-11-23 16:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:05:09 --> Parser Class Initialized
INFO - 2023-11-23 16:05:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:05:09 --> Pagination Class Initialized
INFO - 2023-11-23 16:05:09 --> Form Validation Class Initialized
INFO - 2023-11-23 16:05:09 --> Controller Class Initialized
INFO - 2023-11-23 16:05:09 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:09 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:09 --> Model Class Initialized
INFO - 2023-11-23 16:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-23 16:05:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:05:09 --> Model Class Initialized
INFO - 2023-11-23 16:05:09 --> Model Class Initialized
INFO - 2023-11-23 16:05:09 --> Model Class Initialized
INFO - 2023-11-23 16:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:05:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:05:09 --> Final output sent to browser
DEBUG - 2023-11-23 16:05:09 --> Total execution time: 0.2059
ERROR - 2023-11-23 16:05:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:05:10 --> Config Class Initialized
INFO - 2023-11-23 16:05:10 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:05:10 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:05:10 --> Utf8 Class Initialized
INFO - 2023-11-23 16:05:10 --> URI Class Initialized
INFO - 2023-11-23 16:05:10 --> Router Class Initialized
INFO - 2023-11-23 16:05:10 --> Output Class Initialized
INFO - 2023-11-23 16:05:10 --> Security Class Initialized
DEBUG - 2023-11-23 16:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:05:10 --> Input Class Initialized
INFO - 2023-11-23 16:05:10 --> Language Class Initialized
INFO - 2023-11-23 16:05:10 --> Loader Class Initialized
INFO - 2023-11-23 16:05:10 --> Helper loaded: url_helper
INFO - 2023-11-23 16:05:10 --> Helper loaded: file_helper
INFO - 2023-11-23 16:05:10 --> Helper loaded: html_helper
INFO - 2023-11-23 16:05:10 --> Helper loaded: text_helper
INFO - 2023-11-23 16:05:10 --> Helper loaded: form_helper
INFO - 2023-11-23 16:05:10 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:05:10 --> Helper loaded: security_helper
INFO - 2023-11-23 16:05:10 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:05:10 --> Database Driver Class Initialized
INFO - 2023-11-23 16:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:05:10 --> Parser Class Initialized
INFO - 2023-11-23 16:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:05:10 --> Pagination Class Initialized
INFO - 2023-11-23 16:05:10 --> Form Validation Class Initialized
INFO - 2023-11-23 16:05:10 --> Controller Class Initialized
INFO - 2023-11-23 16:05:10 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:10 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:10 --> Model Class Initialized
INFO - 2023-11-23 16:05:10 --> Final output sent to browser
DEBUG - 2023-11-23 16:05:10 --> Total execution time: 0.0578
ERROR - 2023-11-23 16:05:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:05:53 --> Config Class Initialized
INFO - 2023-11-23 16:05:53 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:05:53 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:05:53 --> Utf8 Class Initialized
INFO - 2023-11-23 16:05:53 --> URI Class Initialized
INFO - 2023-11-23 16:05:53 --> Router Class Initialized
INFO - 2023-11-23 16:05:53 --> Output Class Initialized
INFO - 2023-11-23 16:05:53 --> Security Class Initialized
DEBUG - 2023-11-23 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:05:53 --> Input Class Initialized
INFO - 2023-11-23 16:05:53 --> Language Class Initialized
INFO - 2023-11-23 16:05:53 --> Loader Class Initialized
INFO - 2023-11-23 16:05:53 --> Helper loaded: url_helper
INFO - 2023-11-23 16:05:53 --> Helper loaded: file_helper
INFO - 2023-11-23 16:05:53 --> Helper loaded: html_helper
INFO - 2023-11-23 16:05:53 --> Helper loaded: text_helper
INFO - 2023-11-23 16:05:53 --> Helper loaded: form_helper
INFO - 2023-11-23 16:05:53 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:05:53 --> Helper loaded: security_helper
INFO - 2023-11-23 16:05:53 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:05:53 --> Database Driver Class Initialized
INFO - 2023-11-23 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:05:53 --> Parser Class Initialized
INFO - 2023-11-23 16:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:05:53 --> Pagination Class Initialized
INFO - 2023-11-23 16:05:53 --> Form Validation Class Initialized
INFO - 2023-11-23 16:05:53 --> Controller Class Initialized
INFO - 2023-11-23 16:05:53 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:53 --> Model Class Initialized
DEBUG - 2023-11-23 16:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:05:53 --> Model Class Initialized
INFO - 2023-11-23 16:05:53 --> Final output sent to browser
DEBUG - 2023-11-23 16:05:53 --> Total execution time: 0.0501
ERROR - 2023-11-23 16:06:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:06:11 --> Config Class Initialized
INFO - 2023-11-23 16:06:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:06:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:06:11 --> Utf8 Class Initialized
INFO - 2023-11-23 16:06:11 --> URI Class Initialized
INFO - 2023-11-23 16:06:11 --> Router Class Initialized
INFO - 2023-11-23 16:06:11 --> Output Class Initialized
INFO - 2023-11-23 16:06:11 --> Security Class Initialized
DEBUG - 2023-11-23 16:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:06:12 --> Input Class Initialized
INFO - 2023-11-23 16:06:12 --> Language Class Initialized
INFO - 2023-11-23 16:06:12 --> Loader Class Initialized
INFO - 2023-11-23 16:06:12 --> Helper loaded: url_helper
INFO - 2023-11-23 16:06:12 --> Helper loaded: file_helper
INFO - 2023-11-23 16:06:12 --> Helper loaded: html_helper
INFO - 2023-11-23 16:06:12 --> Helper loaded: text_helper
INFO - 2023-11-23 16:06:12 --> Helper loaded: form_helper
INFO - 2023-11-23 16:06:12 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:06:12 --> Helper loaded: security_helper
INFO - 2023-11-23 16:06:12 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:06:12 --> Database Driver Class Initialized
INFO - 2023-11-23 16:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:06:12 --> Parser Class Initialized
INFO - 2023-11-23 16:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:06:12 --> Pagination Class Initialized
INFO - 2023-11-23 16:06:12 --> Form Validation Class Initialized
INFO - 2023-11-23 16:06:12 --> Controller Class Initialized
INFO - 2023-11-23 16:06:12 --> Model Class Initialized
DEBUG - 2023-11-23 16:06:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:12 --> Model Class Initialized
DEBUG - 2023-11-23 16:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:12 --> Model Class Initialized
INFO - 2023-11-23 16:06:12 --> Final output sent to browser
DEBUG - 2023-11-23 16:06:12 --> Total execution time: 0.0568
ERROR - 2023-11-23 16:06:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:06:34 --> Config Class Initialized
INFO - 2023-11-23 16:06:34 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:06:34 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:06:34 --> Utf8 Class Initialized
INFO - 2023-11-23 16:06:34 --> URI Class Initialized
INFO - 2023-11-23 16:06:34 --> Router Class Initialized
INFO - 2023-11-23 16:06:34 --> Output Class Initialized
INFO - 2023-11-23 16:06:34 --> Security Class Initialized
DEBUG - 2023-11-23 16:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:06:34 --> Input Class Initialized
INFO - 2023-11-23 16:06:34 --> Language Class Initialized
INFO - 2023-11-23 16:06:34 --> Loader Class Initialized
INFO - 2023-11-23 16:06:34 --> Helper loaded: url_helper
INFO - 2023-11-23 16:06:34 --> Helper loaded: file_helper
INFO - 2023-11-23 16:06:34 --> Helper loaded: html_helper
INFO - 2023-11-23 16:06:34 --> Helper loaded: text_helper
INFO - 2023-11-23 16:06:34 --> Helper loaded: form_helper
INFO - 2023-11-23 16:06:34 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:06:34 --> Helper loaded: security_helper
INFO - 2023-11-23 16:06:34 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:06:34 --> Database Driver Class Initialized
INFO - 2023-11-23 16:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:06:34 --> Parser Class Initialized
INFO - 2023-11-23 16:06:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:06:34 --> Pagination Class Initialized
INFO - 2023-11-23 16:06:34 --> Form Validation Class Initialized
INFO - 2023-11-23 16:06:34 --> Controller Class Initialized
INFO - 2023-11-23 16:06:34 --> Model Class Initialized
DEBUG - 2023-11-23 16:06:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:34 --> Model Class Initialized
DEBUG - 2023-11-23 16:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:34 --> Model Class Initialized
INFO - 2023-11-23 16:06:34 --> Final output sent to browser
DEBUG - 2023-11-23 16:06:34 --> Total execution time: 0.0464
ERROR - 2023-11-23 16:06:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:06:59 --> Config Class Initialized
INFO - 2023-11-23 16:06:59 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:06:59 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:06:59 --> Utf8 Class Initialized
INFO - 2023-11-23 16:06:59 --> URI Class Initialized
DEBUG - 2023-11-23 16:06:59 --> No URI present. Default controller set.
INFO - 2023-11-23 16:06:59 --> Router Class Initialized
INFO - 2023-11-23 16:06:59 --> Output Class Initialized
INFO - 2023-11-23 16:06:59 --> Security Class Initialized
DEBUG - 2023-11-23 16:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:06:59 --> Input Class Initialized
INFO - 2023-11-23 16:06:59 --> Language Class Initialized
INFO - 2023-11-23 16:06:59 --> Loader Class Initialized
INFO - 2023-11-23 16:06:59 --> Helper loaded: url_helper
INFO - 2023-11-23 16:06:59 --> Helper loaded: file_helper
INFO - 2023-11-23 16:06:59 --> Helper loaded: html_helper
INFO - 2023-11-23 16:06:59 --> Helper loaded: text_helper
INFO - 2023-11-23 16:06:59 --> Helper loaded: form_helper
INFO - 2023-11-23 16:06:59 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:06:59 --> Helper loaded: security_helper
INFO - 2023-11-23 16:06:59 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:06:59 --> Database Driver Class Initialized
INFO - 2023-11-23 16:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:06:59 --> Parser Class Initialized
INFO - 2023-11-23 16:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:06:59 --> Pagination Class Initialized
INFO - 2023-11-23 16:06:59 --> Form Validation Class Initialized
INFO - 2023-11-23 16:06:59 --> Controller Class Initialized
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
DEBUG - 2023-11-23 16:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
DEBUG - 2023-11-23 16:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
DEBUG - 2023-11-23 16:06:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
INFO - 2023-11-23 16:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 16:06:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:06:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:06:59 --> Model Class Initialized
INFO - 2023-11-23 16:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:07:00 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:00 --> Total execution time: 0.3873
ERROR - 2023-11-23 16:07:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:07:04 --> Config Class Initialized
INFO - 2023-11-23 16:07:04 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:07:04 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:07:04 --> Utf8 Class Initialized
INFO - 2023-11-23 16:07:04 --> URI Class Initialized
INFO - 2023-11-23 16:07:04 --> Router Class Initialized
INFO - 2023-11-23 16:07:04 --> Output Class Initialized
INFO - 2023-11-23 16:07:04 --> Security Class Initialized
DEBUG - 2023-11-23 16:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:07:04 --> Input Class Initialized
INFO - 2023-11-23 16:07:04 --> Language Class Initialized
INFO - 2023-11-23 16:07:04 --> Loader Class Initialized
INFO - 2023-11-23 16:07:04 --> Helper loaded: url_helper
INFO - 2023-11-23 16:07:04 --> Helper loaded: file_helper
INFO - 2023-11-23 16:07:04 --> Helper loaded: html_helper
INFO - 2023-11-23 16:07:04 --> Helper loaded: text_helper
INFO - 2023-11-23 16:07:04 --> Helper loaded: form_helper
INFO - 2023-11-23 16:07:04 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:07:04 --> Helper loaded: security_helper
INFO - 2023-11-23 16:07:04 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:07:04 --> Database Driver Class Initialized
INFO - 2023-11-23 16:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:07:04 --> Parser Class Initialized
INFO - 2023-11-23 16:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:07:04 --> Pagination Class Initialized
INFO - 2023-11-23 16:07:04 --> Form Validation Class Initialized
INFO - 2023-11-23 16:07:04 --> Controller Class Initialized
INFO - 2023-11-23 16:07:04 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:04 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:04 --> Model Class Initialized
INFO - 2023-11-23 16:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-23 16:07:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:07:04 --> Model Class Initialized
INFO - 2023-11-23 16:07:04 --> Model Class Initialized
INFO - 2023-11-23 16:07:04 --> Model Class Initialized
INFO - 2023-11-23 16:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:07:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:07:04 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:04 --> Total execution time: 0.2114
ERROR - 2023-11-23 16:07:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:07:05 --> Config Class Initialized
INFO - 2023-11-23 16:07:05 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:07:05 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:07:05 --> Utf8 Class Initialized
INFO - 2023-11-23 16:07:05 --> URI Class Initialized
INFO - 2023-11-23 16:07:05 --> Router Class Initialized
INFO - 2023-11-23 16:07:05 --> Output Class Initialized
INFO - 2023-11-23 16:07:05 --> Security Class Initialized
DEBUG - 2023-11-23 16:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:07:05 --> Input Class Initialized
INFO - 2023-11-23 16:07:05 --> Language Class Initialized
INFO - 2023-11-23 16:07:05 --> Loader Class Initialized
INFO - 2023-11-23 16:07:05 --> Helper loaded: url_helper
INFO - 2023-11-23 16:07:05 --> Helper loaded: file_helper
INFO - 2023-11-23 16:07:05 --> Helper loaded: html_helper
INFO - 2023-11-23 16:07:05 --> Helper loaded: text_helper
INFO - 2023-11-23 16:07:05 --> Helper loaded: form_helper
INFO - 2023-11-23 16:07:05 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:07:05 --> Helper loaded: security_helper
INFO - 2023-11-23 16:07:05 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:07:05 --> Database Driver Class Initialized
INFO - 2023-11-23 16:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:07:05 --> Parser Class Initialized
INFO - 2023-11-23 16:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:07:05 --> Pagination Class Initialized
INFO - 2023-11-23 16:07:05 --> Form Validation Class Initialized
INFO - 2023-11-23 16:07:05 --> Controller Class Initialized
INFO - 2023-11-23 16:07:05 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:05 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:05 --> Model Class Initialized
INFO - 2023-11-23 16:07:06 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:06 --> Total execution time: 0.0651
ERROR - 2023-11-23 16:07:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:07:09 --> Config Class Initialized
INFO - 2023-11-23 16:07:09 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:07:09 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:07:09 --> Utf8 Class Initialized
INFO - 2023-11-23 16:07:09 --> URI Class Initialized
INFO - 2023-11-23 16:07:09 --> Router Class Initialized
INFO - 2023-11-23 16:07:09 --> Output Class Initialized
INFO - 2023-11-23 16:07:09 --> Security Class Initialized
DEBUG - 2023-11-23 16:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:07:09 --> Input Class Initialized
INFO - 2023-11-23 16:07:09 --> Language Class Initialized
INFO - 2023-11-23 16:07:09 --> Loader Class Initialized
INFO - 2023-11-23 16:07:09 --> Helper loaded: url_helper
INFO - 2023-11-23 16:07:09 --> Helper loaded: file_helper
INFO - 2023-11-23 16:07:09 --> Helper loaded: html_helper
INFO - 2023-11-23 16:07:09 --> Helper loaded: text_helper
INFO - 2023-11-23 16:07:09 --> Helper loaded: form_helper
INFO - 2023-11-23 16:07:09 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:07:09 --> Helper loaded: security_helper
INFO - 2023-11-23 16:07:09 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:07:09 --> Database Driver Class Initialized
INFO - 2023-11-23 16:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:07:09 --> Parser Class Initialized
INFO - 2023-11-23 16:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:07:09 --> Pagination Class Initialized
INFO - 2023-11-23 16:07:09 --> Form Validation Class Initialized
INFO - 2023-11-23 16:07:09 --> Controller Class Initialized
INFO - 2023-11-23 16:07:09 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:09 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:09 --> Model Class Initialized
INFO - 2023-11-23 16:07:10 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:10 --> Total execution time: 1.0711
ERROR - 2023-11-23 16:07:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:07:34 --> Config Class Initialized
INFO - 2023-11-23 16:07:34 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:07:34 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:07:34 --> Utf8 Class Initialized
INFO - 2023-11-23 16:07:34 --> URI Class Initialized
DEBUG - 2023-11-23 16:07:34 --> No URI present. Default controller set.
INFO - 2023-11-23 16:07:34 --> Router Class Initialized
INFO - 2023-11-23 16:07:34 --> Output Class Initialized
INFO - 2023-11-23 16:07:34 --> Security Class Initialized
DEBUG - 2023-11-23 16:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:07:34 --> Input Class Initialized
INFO - 2023-11-23 16:07:34 --> Language Class Initialized
INFO - 2023-11-23 16:07:34 --> Loader Class Initialized
INFO - 2023-11-23 16:07:34 --> Helper loaded: url_helper
INFO - 2023-11-23 16:07:34 --> Helper loaded: file_helper
INFO - 2023-11-23 16:07:34 --> Helper loaded: html_helper
INFO - 2023-11-23 16:07:34 --> Helper loaded: text_helper
INFO - 2023-11-23 16:07:34 --> Helper loaded: form_helper
INFO - 2023-11-23 16:07:34 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:07:34 --> Helper loaded: security_helper
INFO - 2023-11-23 16:07:34 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:07:34 --> Database Driver Class Initialized
INFO - 2023-11-23 16:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:07:34 --> Parser Class Initialized
INFO - 2023-11-23 16:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:07:34 --> Pagination Class Initialized
INFO - 2023-11-23 16:07:34 --> Form Validation Class Initialized
INFO - 2023-11-23 16:07:34 --> Controller Class Initialized
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
DEBUG - 2023-11-23 16:07:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
INFO - 2023-11-23 16:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 16:07:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:07:34 --> Model Class Initialized
INFO - 2023-11-23 16:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:07:34 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:34 --> Total execution time: 0.3934
ERROR - 2023-11-23 16:07:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:07:44 --> Config Class Initialized
INFO - 2023-11-23 16:07:44 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:07:44 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:07:44 --> Utf8 Class Initialized
INFO - 2023-11-23 16:07:44 --> URI Class Initialized
INFO - 2023-11-23 16:07:44 --> Router Class Initialized
INFO - 2023-11-23 16:07:44 --> Output Class Initialized
INFO - 2023-11-23 16:07:44 --> Security Class Initialized
DEBUG - 2023-11-23 16:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:07:44 --> Input Class Initialized
INFO - 2023-11-23 16:07:44 --> Language Class Initialized
INFO - 2023-11-23 16:07:44 --> Loader Class Initialized
INFO - 2023-11-23 16:07:44 --> Helper loaded: url_helper
INFO - 2023-11-23 16:07:44 --> Helper loaded: file_helper
INFO - 2023-11-23 16:07:44 --> Helper loaded: html_helper
INFO - 2023-11-23 16:07:44 --> Helper loaded: text_helper
INFO - 2023-11-23 16:07:44 --> Helper loaded: form_helper
INFO - 2023-11-23 16:07:44 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:07:44 --> Helper loaded: security_helper
INFO - 2023-11-23 16:07:44 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:07:44 --> Database Driver Class Initialized
INFO - 2023-11-23 16:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:07:44 --> Parser Class Initialized
INFO - 2023-11-23 16:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:07:44 --> Pagination Class Initialized
INFO - 2023-11-23 16:07:44 --> Form Validation Class Initialized
INFO - 2023-11-23 16:07:44 --> Controller Class Initialized
INFO - 2023-11-23 16:07:44 --> Model Class Initialized
INFO - 2023-11-23 16:07:44 --> Model Class Initialized
INFO - 2023-11-23 16:07:44 --> Model Class Initialized
INFO - 2023-11-23 16:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-11-23 16:07:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:07:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:07:44 --> Model Class Initialized
INFO - 2023-11-23 16:07:44 --> Model Class Initialized
INFO - 2023-11-23 16:07:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:07:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:07:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:07:45 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:45 --> Total execution time: 0.2133
ERROR - 2023-11-23 16:07:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:07:46 --> Config Class Initialized
INFO - 2023-11-23 16:07:46 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:07:46 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:07:46 --> Utf8 Class Initialized
INFO - 2023-11-23 16:07:46 --> URI Class Initialized
INFO - 2023-11-23 16:07:46 --> Router Class Initialized
INFO - 2023-11-23 16:07:46 --> Output Class Initialized
INFO - 2023-11-23 16:07:46 --> Security Class Initialized
DEBUG - 2023-11-23 16:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:07:46 --> Input Class Initialized
INFO - 2023-11-23 16:07:46 --> Language Class Initialized
INFO - 2023-11-23 16:07:46 --> Loader Class Initialized
INFO - 2023-11-23 16:07:46 --> Helper loaded: url_helper
INFO - 2023-11-23 16:07:46 --> Helper loaded: file_helper
INFO - 2023-11-23 16:07:46 --> Helper loaded: html_helper
INFO - 2023-11-23 16:07:46 --> Helper loaded: text_helper
INFO - 2023-11-23 16:07:46 --> Helper loaded: form_helper
INFO - 2023-11-23 16:07:46 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:07:46 --> Helper loaded: security_helper
INFO - 2023-11-23 16:07:46 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:07:46 --> Database Driver Class Initialized
INFO - 2023-11-23 16:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:07:46 --> Parser Class Initialized
INFO - 2023-11-23 16:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:07:46 --> Pagination Class Initialized
INFO - 2023-11-23 16:07:46 --> Form Validation Class Initialized
INFO - 2023-11-23 16:07:46 --> Controller Class Initialized
INFO - 2023-11-23 16:07:46 --> Model Class Initialized
INFO - 2023-11-23 16:07:46 --> Model Class Initialized
INFO - 2023-11-23 16:07:46 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:46 --> Total execution time: 0.0290
ERROR - 2023-11-23 16:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:07:54 --> Config Class Initialized
INFO - 2023-11-23 16:07:54 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:07:54 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:07:54 --> Utf8 Class Initialized
INFO - 2023-11-23 16:07:54 --> URI Class Initialized
INFO - 2023-11-23 16:07:54 --> Router Class Initialized
INFO - 2023-11-23 16:07:54 --> Output Class Initialized
INFO - 2023-11-23 16:07:54 --> Security Class Initialized
DEBUG - 2023-11-23 16:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:07:54 --> Input Class Initialized
INFO - 2023-11-23 16:07:54 --> Language Class Initialized
INFO - 2023-11-23 16:07:54 --> Loader Class Initialized
INFO - 2023-11-23 16:07:54 --> Helper loaded: url_helper
INFO - 2023-11-23 16:07:54 --> Helper loaded: file_helper
INFO - 2023-11-23 16:07:54 --> Helper loaded: html_helper
INFO - 2023-11-23 16:07:54 --> Helper loaded: text_helper
INFO - 2023-11-23 16:07:54 --> Helper loaded: form_helper
INFO - 2023-11-23 16:07:54 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:07:54 --> Helper loaded: security_helper
INFO - 2023-11-23 16:07:54 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:07:54 --> Database Driver Class Initialized
INFO - 2023-11-23 16:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:07:54 --> Parser Class Initialized
INFO - 2023-11-23 16:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:07:54 --> Pagination Class Initialized
INFO - 2023-11-23 16:07:54 --> Form Validation Class Initialized
INFO - 2023-11-23 16:07:54 --> Controller Class Initialized
INFO - 2023-11-23 16:07:54 --> Model Class Initialized
INFO - 2023-11-23 16:07:54 --> Model Class Initialized
INFO - 2023-11-23 16:07:54 --> Final output sent to browser
DEBUG - 2023-11-23 16:07:54 --> Total execution time: 0.0636
ERROR - 2023-11-23 16:08:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:08:34 --> Config Class Initialized
INFO - 2023-11-23 16:08:34 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:08:34 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:08:34 --> Utf8 Class Initialized
INFO - 2023-11-23 16:08:34 --> URI Class Initialized
INFO - 2023-11-23 16:08:34 --> Router Class Initialized
INFO - 2023-11-23 16:08:34 --> Output Class Initialized
INFO - 2023-11-23 16:08:34 --> Security Class Initialized
DEBUG - 2023-11-23 16:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:08:34 --> Input Class Initialized
INFO - 2023-11-23 16:08:34 --> Language Class Initialized
INFO - 2023-11-23 16:08:34 --> Loader Class Initialized
INFO - 2023-11-23 16:08:34 --> Helper loaded: url_helper
INFO - 2023-11-23 16:08:34 --> Helper loaded: file_helper
INFO - 2023-11-23 16:08:34 --> Helper loaded: html_helper
INFO - 2023-11-23 16:08:34 --> Helper loaded: text_helper
INFO - 2023-11-23 16:08:34 --> Helper loaded: form_helper
INFO - 2023-11-23 16:08:34 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:08:34 --> Helper loaded: security_helper
INFO - 2023-11-23 16:08:34 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:08:34 --> Database Driver Class Initialized
INFO - 2023-11-23 16:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:08:34 --> Parser Class Initialized
INFO - 2023-11-23 16:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:08:34 --> Pagination Class Initialized
INFO - 2023-11-23 16:08:34 --> Form Validation Class Initialized
INFO - 2023-11-23 16:08:34 --> Controller Class Initialized
DEBUG - 2023-11-23 16:08:34 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:08:34 --> Model Class Initialized
INFO - 2023-11-23 16:08:34 --> Model Class Initialized
INFO - 2023-11-23 16:08:34 --> Model Class Initialized
INFO - 2023-11-23 16:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-11-23 16:08:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:08:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:08:34 --> Model Class Initialized
INFO - 2023-11-23 16:08:34 --> Model Class Initialized
INFO - 2023-11-23 16:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:08:35 --> Final output sent to browser
DEBUG - 2023-11-23 16:08:35 --> Total execution time: 0.2394
ERROR - 2023-11-23 16:09:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:09:06 --> Config Class Initialized
INFO - 2023-11-23 16:09:06 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:09:06 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:09:06 --> Utf8 Class Initialized
INFO - 2023-11-23 16:09:06 --> URI Class Initialized
INFO - 2023-11-23 16:09:06 --> Router Class Initialized
INFO - 2023-11-23 16:09:06 --> Output Class Initialized
INFO - 2023-11-23 16:09:06 --> Security Class Initialized
DEBUG - 2023-11-23 16:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:09:06 --> Input Class Initialized
INFO - 2023-11-23 16:09:06 --> Language Class Initialized
INFO - 2023-11-23 16:09:06 --> Loader Class Initialized
INFO - 2023-11-23 16:09:06 --> Helper loaded: url_helper
INFO - 2023-11-23 16:09:06 --> Helper loaded: file_helper
INFO - 2023-11-23 16:09:06 --> Helper loaded: html_helper
INFO - 2023-11-23 16:09:06 --> Helper loaded: text_helper
INFO - 2023-11-23 16:09:06 --> Helper loaded: form_helper
INFO - 2023-11-23 16:09:06 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:09:06 --> Helper loaded: security_helper
INFO - 2023-11-23 16:09:06 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:09:06 --> Database Driver Class Initialized
INFO - 2023-11-23 16:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:09:06 --> Parser Class Initialized
INFO - 2023-11-23 16:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:09:06 --> Pagination Class Initialized
INFO - 2023-11-23 16:09:06 --> Form Validation Class Initialized
INFO - 2023-11-23 16:09:06 --> Controller Class Initialized
INFO - 2023-11-23 16:09:06 --> Model Class Initialized
DEBUG - 2023-11-23 16:09:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:09:06 --> Model Class Initialized
DEBUG - 2023-11-23 16:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-11-23 16:09:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:09:06 --> Model Class Initialized
INFO - 2023-11-23 16:09:06 --> Model Class Initialized
INFO - 2023-11-23 16:09:06 --> Model Class Initialized
INFO - 2023-11-23 16:09:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:09:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:09:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:09:07 --> Final output sent to browser
DEBUG - 2023-11-23 16:09:07 --> Total execution time: 0.2042
ERROR - 2023-11-23 16:09:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:09:21 --> Config Class Initialized
INFO - 2023-11-23 16:09:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:09:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:09:21 --> Utf8 Class Initialized
INFO - 2023-11-23 16:09:21 --> URI Class Initialized
DEBUG - 2023-11-23 16:09:21 --> No URI present. Default controller set.
INFO - 2023-11-23 16:09:21 --> Router Class Initialized
INFO - 2023-11-23 16:09:21 --> Output Class Initialized
INFO - 2023-11-23 16:09:21 --> Security Class Initialized
DEBUG - 2023-11-23 16:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:09:21 --> Input Class Initialized
INFO - 2023-11-23 16:09:21 --> Language Class Initialized
INFO - 2023-11-23 16:09:21 --> Loader Class Initialized
INFO - 2023-11-23 16:09:21 --> Helper loaded: url_helper
INFO - 2023-11-23 16:09:21 --> Helper loaded: file_helper
INFO - 2023-11-23 16:09:21 --> Helper loaded: html_helper
INFO - 2023-11-23 16:09:21 --> Helper loaded: text_helper
INFO - 2023-11-23 16:09:21 --> Helper loaded: form_helper
INFO - 2023-11-23 16:09:21 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:09:21 --> Helper loaded: security_helper
INFO - 2023-11-23 16:09:21 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:09:21 --> Database Driver Class Initialized
INFO - 2023-11-23 16:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:09:21 --> Parser Class Initialized
INFO - 2023-11-23 16:09:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:09:21 --> Pagination Class Initialized
INFO - 2023-11-23 16:09:21 --> Form Validation Class Initialized
INFO - 2023-11-23 16:09:21 --> Controller Class Initialized
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
DEBUG - 2023-11-23 16:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
DEBUG - 2023-11-23 16:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
DEBUG - 2023-11-23 16:09:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
INFO - 2023-11-23 16:09:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 16:09:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:09:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:09:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:09:21 --> Model Class Initialized
INFO - 2023-11-23 16:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:09:22 --> Final output sent to browser
DEBUG - 2023-11-23 16:09:22 --> Total execution time: 0.3639
ERROR - 2023-11-23 16:32:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:32:14 --> Config Class Initialized
INFO - 2023-11-23 16:32:14 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:32:14 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:32:14 --> Utf8 Class Initialized
INFO - 2023-11-23 16:32:14 --> URI Class Initialized
INFO - 2023-11-23 16:32:14 --> Router Class Initialized
INFO - 2023-11-23 16:32:14 --> Output Class Initialized
INFO - 2023-11-23 16:32:14 --> Security Class Initialized
DEBUG - 2023-11-23 16:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:32:14 --> Input Class Initialized
INFO - 2023-11-23 16:32:14 --> Language Class Initialized
INFO - 2023-11-23 16:32:14 --> Loader Class Initialized
INFO - 2023-11-23 16:32:14 --> Helper loaded: url_helper
INFO - 2023-11-23 16:32:14 --> Helper loaded: file_helper
INFO - 2023-11-23 16:32:14 --> Helper loaded: html_helper
INFO - 2023-11-23 16:32:14 --> Helper loaded: text_helper
INFO - 2023-11-23 16:32:14 --> Helper loaded: form_helper
INFO - 2023-11-23 16:32:14 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:32:14 --> Helper loaded: security_helper
INFO - 2023-11-23 16:32:14 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:32:14 --> Database Driver Class Initialized
INFO - 2023-11-23 16:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:32:14 --> Parser Class Initialized
INFO - 2023-11-23 16:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:32:14 --> Pagination Class Initialized
INFO - 2023-11-23 16:32:14 --> Form Validation Class Initialized
INFO - 2023-11-23 16:32:14 --> Controller Class Initialized
INFO - 2023-11-23 16:32:14 --> Model Class Initialized
DEBUG - 2023-11-23 16:32:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:32:14 --> Model Class Initialized
DEBUG - 2023-11-23 16:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:32:14 --> Model Class Initialized
INFO - 2023-11-23 16:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-23 16:32:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:32:14 --> Model Class Initialized
INFO - 2023-11-23 16:32:14 --> Model Class Initialized
INFO - 2023-11-23 16:32:14 --> Model Class Initialized
INFO - 2023-11-23 16:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:32:14 --> Final output sent to browser
DEBUG - 2023-11-23 16:32:14 --> Total execution time: 0.2071
ERROR - 2023-11-23 16:32:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:32:15 --> Config Class Initialized
INFO - 2023-11-23 16:32:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:32:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:32:15 --> Utf8 Class Initialized
INFO - 2023-11-23 16:32:15 --> URI Class Initialized
INFO - 2023-11-23 16:32:15 --> Router Class Initialized
INFO - 2023-11-23 16:32:15 --> Output Class Initialized
INFO - 2023-11-23 16:32:15 --> Security Class Initialized
DEBUG - 2023-11-23 16:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:32:15 --> Input Class Initialized
INFO - 2023-11-23 16:32:15 --> Language Class Initialized
INFO - 2023-11-23 16:32:15 --> Loader Class Initialized
INFO - 2023-11-23 16:32:15 --> Helper loaded: url_helper
INFO - 2023-11-23 16:32:15 --> Helper loaded: file_helper
INFO - 2023-11-23 16:32:15 --> Helper loaded: html_helper
INFO - 2023-11-23 16:32:15 --> Helper loaded: text_helper
INFO - 2023-11-23 16:32:15 --> Helper loaded: form_helper
INFO - 2023-11-23 16:32:15 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:32:15 --> Helper loaded: security_helper
INFO - 2023-11-23 16:32:15 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:32:15 --> Database Driver Class Initialized
INFO - 2023-11-23 16:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:32:15 --> Parser Class Initialized
INFO - 2023-11-23 16:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:32:15 --> Pagination Class Initialized
INFO - 2023-11-23 16:32:15 --> Form Validation Class Initialized
INFO - 2023-11-23 16:32:15 --> Controller Class Initialized
INFO - 2023-11-23 16:32:15 --> Model Class Initialized
DEBUG - 2023-11-23 16:32:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:32:15 --> Model Class Initialized
DEBUG - 2023-11-23 16:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:32:15 --> Model Class Initialized
INFO - 2023-11-23 16:32:15 --> Final output sent to browser
DEBUG - 2023-11-23 16:32:15 --> Total execution time: 0.0548
ERROR - 2023-11-23 16:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:32:26 --> Config Class Initialized
INFO - 2023-11-23 16:32:26 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:32:26 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:32:26 --> Utf8 Class Initialized
INFO - 2023-11-23 16:32:26 --> URI Class Initialized
INFO - 2023-11-23 16:32:26 --> Router Class Initialized
INFO - 2023-11-23 16:32:26 --> Output Class Initialized
INFO - 2023-11-23 16:32:26 --> Security Class Initialized
DEBUG - 2023-11-23 16:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:32:26 --> Input Class Initialized
INFO - 2023-11-23 16:32:26 --> Language Class Initialized
INFO - 2023-11-23 16:32:26 --> Loader Class Initialized
INFO - 2023-11-23 16:32:26 --> Helper loaded: url_helper
INFO - 2023-11-23 16:32:26 --> Helper loaded: file_helper
INFO - 2023-11-23 16:32:26 --> Helper loaded: html_helper
INFO - 2023-11-23 16:32:26 --> Helper loaded: text_helper
INFO - 2023-11-23 16:32:26 --> Helper loaded: form_helper
INFO - 2023-11-23 16:32:26 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:32:26 --> Helper loaded: security_helper
INFO - 2023-11-23 16:32:26 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:32:26 --> Database Driver Class Initialized
INFO - 2023-11-23 16:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:32:26 --> Parser Class Initialized
INFO - 2023-11-23 16:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:32:26 --> Pagination Class Initialized
INFO - 2023-11-23 16:32:26 --> Form Validation Class Initialized
INFO - 2023-11-23 16:32:26 --> Controller Class Initialized
INFO - 2023-11-23 16:32:26 --> Model Class Initialized
DEBUG - 2023-11-23 16:32:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:32:26 --> Model Class Initialized
DEBUG - 2023-11-23 16:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:32:26 --> Model Class Initialized
INFO - 2023-11-23 16:32:27 --> Final output sent to browser
DEBUG - 2023-11-23 16:32:27 --> Total execution time: 1.0946
ERROR - 2023-11-23 16:33:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:33:29 --> Config Class Initialized
INFO - 2023-11-23 16:33:29 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:33:29 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:33:29 --> Utf8 Class Initialized
INFO - 2023-11-23 16:33:29 --> URI Class Initialized
INFO - 2023-11-23 16:33:29 --> Router Class Initialized
INFO - 2023-11-23 16:33:29 --> Output Class Initialized
INFO - 2023-11-23 16:33:29 --> Security Class Initialized
DEBUG - 2023-11-23 16:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:33:29 --> Input Class Initialized
INFO - 2023-11-23 16:33:29 --> Language Class Initialized
INFO - 2023-11-23 16:33:29 --> Loader Class Initialized
INFO - 2023-11-23 16:33:29 --> Helper loaded: url_helper
INFO - 2023-11-23 16:33:29 --> Helper loaded: file_helper
INFO - 2023-11-23 16:33:29 --> Helper loaded: html_helper
INFO - 2023-11-23 16:33:29 --> Helper loaded: text_helper
INFO - 2023-11-23 16:33:29 --> Helper loaded: form_helper
INFO - 2023-11-23 16:33:29 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:33:29 --> Helper loaded: security_helper
INFO - 2023-11-23 16:33:29 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:33:29 --> Database Driver Class Initialized
INFO - 2023-11-23 16:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:33:29 --> Parser Class Initialized
INFO - 2023-11-23 16:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:33:29 --> Pagination Class Initialized
INFO - 2023-11-23 16:33:29 --> Form Validation Class Initialized
INFO - 2023-11-23 16:33:29 --> Controller Class Initialized
INFO - 2023-11-23 16:33:29 --> Model Class Initialized
DEBUG - 2023-11-23 16:33:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:29 --> Model Class Initialized
INFO - 2023-11-23 16:33:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-11-23 16:33:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:33:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:33:29 --> Model Class Initialized
INFO - 2023-11-23 16:33:29 --> Model Class Initialized
INFO - 2023-11-23 16:33:29 --> Model Class Initialized
INFO - 2023-11-23 16:33:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:33:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:33:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:33:30 --> Final output sent to browser
DEBUG - 2023-11-23 16:33:30 --> Total execution time: 0.2250
ERROR - 2023-11-23 16:33:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:33:30 --> Config Class Initialized
INFO - 2023-11-23 16:33:30 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:33:30 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:33:30 --> Utf8 Class Initialized
INFO - 2023-11-23 16:33:30 --> URI Class Initialized
INFO - 2023-11-23 16:33:30 --> Router Class Initialized
INFO - 2023-11-23 16:33:30 --> Output Class Initialized
INFO - 2023-11-23 16:33:30 --> Security Class Initialized
DEBUG - 2023-11-23 16:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:33:30 --> Input Class Initialized
INFO - 2023-11-23 16:33:30 --> Language Class Initialized
INFO - 2023-11-23 16:33:30 --> Loader Class Initialized
INFO - 2023-11-23 16:33:30 --> Helper loaded: url_helper
INFO - 2023-11-23 16:33:30 --> Helper loaded: file_helper
INFO - 2023-11-23 16:33:30 --> Helper loaded: html_helper
INFO - 2023-11-23 16:33:30 --> Helper loaded: text_helper
INFO - 2023-11-23 16:33:30 --> Helper loaded: form_helper
INFO - 2023-11-23 16:33:30 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:33:30 --> Helper loaded: security_helper
INFO - 2023-11-23 16:33:30 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:33:30 --> Database Driver Class Initialized
INFO - 2023-11-23 16:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:33:30 --> Parser Class Initialized
INFO - 2023-11-23 16:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:33:30 --> Pagination Class Initialized
INFO - 2023-11-23 16:33:30 --> Form Validation Class Initialized
INFO - 2023-11-23 16:33:30 --> Controller Class Initialized
INFO - 2023-11-23 16:33:30 --> Model Class Initialized
DEBUG - 2023-11-23 16:33:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:30 --> Model Class Initialized
INFO - 2023-11-23 16:33:30 --> Final output sent to browser
DEBUG - 2023-11-23 16:33:30 --> Total execution time: 0.0290
ERROR - 2023-11-23 16:33:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:33:34 --> Config Class Initialized
INFO - 2023-11-23 16:33:34 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:33:34 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:33:34 --> Utf8 Class Initialized
INFO - 2023-11-23 16:33:34 --> URI Class Initialized
INFO - 2023-11-23 16:33:34 --> Router Class Initialized
INFO - 2023-11-23 16:33:34 --> Output Class Initialized
INFO - 2023-11-23 16:33:34 --> Security Class Initialized
DEBUG - 2023-11-23 16:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:33:34 --> Input Class Initialized
INFO - 2023-11-23 16:33:34 --> Language Class Initialized
INFO - 2023-11-23 16:33:34 --> Loader Class Initialized
INFO - 2023-11-23 16:33:34 --> Helper loaded: url_helper
INFO - 2023-11-23 16:33:34 --> Helper loaded: file_helper
INFO - 2023-11-23 16:33:34 --> Helper loaded: html_helper
INFO - 2023-11-23 16:33:34 --> Helper loaded: text_helper
INFO - 2023-11-23 16:33:34 --> Helper loaded: form_helper
INFO - 2023-11-23 16:33:34 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:33:34 --> Helper loaded: security_helper
INFO - 2023-11-23 16:33:34 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:33:34 --> Database Driver Class Initialized
INFO - 2023-11-23 16:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:33:34 --> Parser Class Initialized
INFO - 2023-11-23 16:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:33:34 --> Pagination Class Initialized
INFO - 2023-11-23 16:33:34 --> Form Validation Class Initialized
INFO - 2023-11-23 16:33:34 --> Controller Class Initialized
INFO - 2023-11-23 16:33:34 --> Model Class Initialized
DEBUG - 2023-11-23 16:33:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:34 --> Model Class Initialized
INFO - 2023-11-23 16:33:34 --> Final output sent to browser
DEBUG - 2023-11-23 16:33:34 --> Total execution time: 0.1318
ERROR - 2023-11-23 16:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:33:41 --> Config Class Initialized
INFO - 2023-11-23 16:33:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:33:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:33:41 --> Utf8 Class Initialized
INFO - 2023-11-23 16:33:41 --> URI Class Initialized
INFO - 2023-11-23 16:33:41 --> Router Class Initialized
INFO - 2023-11-23 16:33:41 --> Output Class Initialized
INFO - 2023-11-23 16:33:41 --> Security Class Initialized
DEBUG - 2023-11-23 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:33:41 --> Input Class Initialized
INFO - 2023-11-23 16:33:41 --> Language Class Initialized
INFO - 2023-11-23 16:33:41 --> Loader Class Initialized
INFO - 2023-11-23 16:33:41 --> Helper loaded: url_helper
INFO - 2023-11-23 16:33:41 --> Helper loaded: file_helper
INFO - 2023-11-23 16:33:41 --> Helper loaded: html_helper
INFO - 2023-11-23 16:33:41 --> Helper loaded: text_helper
INFO - 2023-11-23 16:33:41 --> Helper loaded: form_helper
INFO - 2023-11-23 16:33:41 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:33:41 --> Helper loaded: security_helper
INFO - 2023-11-23 16:33:41 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:33:41 --> Database Driver Class Initialized
INFO - 2023-11-23 16:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:33:41 --> Parser Class Initialized
INFO - 2023-11-23 16:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:33:41 --> Pagination Class Initialized
INFO - 2023-11-23 16:33:41 --> Form Validation Class Initialized
INFO - 2023-11-23 16:33:41 --> Controller Class Initialized
DEBUG - 2023-11-23 16:33:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:41 --> Model Class Initialized
DEBUG - 2023-11-23 16:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:41 --> Model Class Initialized
DEBUG - 2023-11-23 16:33:41 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:41 --> Model Class Initialized
INFO - 2023-11-23 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-11-23 16:33:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:33:41 --> Model Class Initialized
INFO - 2023-11-23 16:33:41 --> Model Class Initialized
INFO - 2023-11-23 16:33:41 --> Model Class Initialized
INFO - 2023-11-23 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:33:41 --> Final output sent to browser
DEBUG - 2023-11-23 16:33:41 --> Total execution time: 0.2204
ERROR - 2023-11-23 16:33:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:33:42 --> Config Class Initialized
INFO - 2023-11-23 16:33:42 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:33:42 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:33:42 --> Utf8 Class Initialized
INFO - 2023-11-23 16:33:42 --> URI Class Initialized
INFO - 2023-11-23 16:33:42 --> Router Class Initialized
INFO - 2023-11-23 16:33:42 --> Output Class Initialized
INFO - 2023-11-23 16:33:42 --> Security Class Initialized
DEBUG - 2023-11-23 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:33:42 --> Input Class Initialized
INFO - 2023-11-23 16:33:42 --> Language Class Initialized
INFO - 2023-11-23 16:33:42 --> Loader Class Initialized
INFO - 2023-11-23 16:33:42 --> Helper loaded: url_helper
INFO - 2023-11-23 16:33:42 --> Helper loaded: file_helper
INFO - 2023-11-23 16:33:42 --> Helper loaded: html_helper
INFO - 2023-11-23 16:33:42 --> Helper loaded: text_helper
INFO - 2023-11-23 16:33:42 --> Helper loaded: form_helper
INFO - 2023-11-23 16:33:42 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:33:42 --> Helper loaded: security_helper
INFO - 2023-11-23 16:33:42 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:33:42 --> Database Driver Class Initialized
INFO - 2023-11-23 16:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:33:42 --> Parser Class Initialized
INFO - 2023-11-23 16:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:33:42 --> Pagination Class Initialized
INFO - 2023-11-23 16:33:42 --> Form Validation Class Initialized
INFO - 2023-11-23 16:33:42 --> Controller Class Initialized
DEBUG - 2023-11-23 16:33:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:42 --> Model Class Initialized
DEBUG - 2023-11-23 16:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:42 --> Model Class Initialized
INFO - 2023-11-23 16:33:42 --> Final output sent to browser
DEBUG - 2023-11-23 16:33:42 --> Total execution time: 0.0302
ERROR - 2023-11-23 16:33:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:33:46 --> Config Class Initialized
INFO - 2023-11-23 16:33:46 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:33:46 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:33:46 --> Utf8 Class Initialized
INFO - 2023-11-23 16:33:46 --> URI Class Initialized
INFO - 2023-11-23 16:33:46 --> Router Class Initialized
INFO - 2023-11-23 16:33:46 --> Output Class Initialized
INFO - 2023-11-23 16:33:46 --> Security Class Initialized
DEBUG - 2023-11-23 16:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:33:46 --> Input Class Initialized
INFO - 2023-11-23 16:33:46 --> Language Class Initialized
INFO - 2023-11-23 16:33:46 --> Loader Class Initialized
INFO - 2023-11-23 16:33:46 --> Helper loaded: url_helper
INFO - 2023-11-23 16:33:46 --> Helper loaded: file_helper
INFO - 2023-11-23 16:33:46 --> Helper loaded: html_helper
INFO - 2023-11-23 16:33:46 --> Helper loaded: text_helper
INFO - 2023-11-23 16:33:46 --> Helper loaded: form_helper
INFO - 2023-11-23 16:33:46 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:33:46 --> Helper loaded: security_helper
INFO - 2023-11-23 16:33:46 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:33:46 --> Database Driver Class Initialized
INFO - 2023-11-23 16:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:33:46 --> Parser Class Initialized
INFO - 2023-11-23 16:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:33:46 --> Pagination Class Initialized
INFO - 2023-11-23 16:33:46 --> Form Validation Class Initialized
INFO - 2023-11-23 16:33:46 --> Controller Class Initialized
DEBUG - 2023-11-23 16:33:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:46 --> Model Class Initialized
DEBUG - 2023-11-23 16:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:33:46 --> Model Class Initialized
INFO - 2023-11-23 16:33:46 --> Final output sent to browser
DEBUG - 2023-11-23 16:33:46 --> Total execution time: 0.1681
ERROR - 2023-11-23 16:34:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:34:17 --> Config Class Initialized
INFO - 2023-11-23 16:34:17 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:34:17 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:34:17 --> Utf8 Class Initialized
INFO - 2023-11-23 16:34:17 --> URI Class Initialized
INFO - 2023-11-23 16:34:17 --> Router Class Initialized
INFO - 2023-11-23 16:34:17 --> Output Class Initialized
INFO - 2023-11-23 16:34:17 --> Security Class Initialized
DEBUG - 2023-11-23 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:34:17 --> Input Class Initialized
INFO - 2023-11-23 16:34:17 --> Language Class Initialized
INFO - 2023-11-23 16:34:17 --> Loader Class Initialized
INFO - 2023-11-23 16:34:17 --> Helper loaded: url_helper
INFO - 2023-11-23 16:34:17 --> Helper loaded: file_helper
INFO - 2023-11-23 16:34:17 --> Helper loaded: html_helper
INFO - 2023-11-23 16:34:17 --> Helper loaded: text_helper
INFO - 2023-11-23 16:34:17 --> Helper loaded: form_helper
INFO - 2023-11-23 16:34:17 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:34:17 --> Helper loaded: security_helper
INFO - 2023-11-23 16:34:17 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:34:17 --> Database Driver Class Initialized
INFO - 2023-11-23 16:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:34:17 --> Parser Class Initialized
INFO - 2023-11-23 16:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:34:17 --> Pagination Class Initialized
INFO - 2023-11-23 16:34:17 --> Form Validation Class Initialized
INFO - 2023-11-23 16:34:17 --> Controller Class Initialized
DEBUG - 2023-11-23 16:34:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:34:17 --> Model Class Initialized
INFO - 2023-11-23 16:34:17 --> Model Class Initialized
DEBUG - 2023-11-23 16:34:17 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:34:17 --> Model Class Initialized
INFO - 2023-11-23 16:34:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-11-23 16:34:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:34:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 16:34:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 16:34:17 --> Model Class Initialized
INFO - 2023-11-23 16:34:17 --> Model Class Initialized
INFO - 2023-11-23 16:34:17 --> Model Class Initialized
INFO - 2023-11-23 16:34:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 16:34:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 16:34:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 16:34:17 --> Final output sent to browser
DEBUG - 2023-11-23 16:34:17 --> Total execution time: 0.1887
ERROR - 2023-11-23 16:34:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:34:18 --> Config Class Initialized
INFO - 2023-11-23 16:34:18 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:34:18 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:34:18 --> Utf8 Class Initialized
INFO - 2023-11-23 16:34:18 --> URI Class Initialized
INFO - 2023-11-23 16:34:18 --> Router Class Initialized
INFO - 2023-11-23 16:34:18 --> Output Class Initialized
INFO - 2023-11-23 16:34:18 --> Security Class Initialized
DEBUG - 2023-11-23 16:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:34:18 --> Input Class Initialized
INFO - 2023-11-23 16:34:18 --> Language Class Initialized
INFO - 2023-11-23 16:34:18 --> Loader Class Initialized
INFO - 2023-11-23 16:34:18 --> Helper loaded: url_helper
INFO - 2023-11-23 16:34:18 --> Helper loaded: file_helper
INFO - 2023-11-23 16:34:18 --> Helper loaded: html_helper
INFO - 2023-11-23 16:34:18 --> Helper loaded: text_helper
INFO - 2023-11-23 16:34:18 --> Helper loaded: form_helper
INFO - 2023-11-23 16:34:18 --> Helper loaded: lang_helper
INFO - 2023-11-23 16:34:18 --> Helper loaded: security_helper
INFO - 2023-11-23 16:34:18 --> Helper loaded: cookie_helper
INFO - 2023-11-23 16:34:18 --> Database Driver Class Initialized
INFO - 2023-11-23 16:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:34:18 --> Parser Class Initialized
INFO - 2023-11-23 16:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 16:34:18 --> Pagination Class Initialized
INFO - 2023-11-23 16:34:18 --> Form Validation Class Initialized
INFO - 2023-11-23 16:34:18 --> Controller Class Initialized
DEBUG - 2023-11-23 16:34:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:34:18 --> Model Class Initialized
INFO - 2023-11-23 16:34:18 --> Model Class Initialized
INFO - 2023-11-23 16:34:18 --> Final output sent to browser
DEBUG - 2023-11-23 16:34:18 --> Total execution time: 0.0213
ERROR - 2023-11-23 17:02:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:02:32 --> Config Class Initialized
INFO - 2023-11-23 17:02:32 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:02:32 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:02:32 --> Utf8 Class Initialized
INFO - 2023-11-23 17:02:32 --> URI Class Initialized
DEBUG - 2023-11-23 17:02:32 --> No URI present. Default controller set.
INFO - 2023-11-23 17:02:32 --> Router Class Initialized
INFO - 2023-11-23 17:02:32 --> Output Class Initialized
INFO - 2023-11-23 17:02:32 --> Security Class Initialized
DEBUG - 2023-11-23 17:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:02:32 --> Input Class Initialized
INFO - 2023-11-23 17:02:32 --> Language Class Initialized
INFO - 2023-11-23 17:02:32 --> Loader Class Initialized
INFO - 2023-11-23 17:02:32 --> Helper loaded: url_helper
INFO - 2023-11-23 17:02:32 --> Helper loaded: file_helper
INFO - 2023-11-23 17:02:32 --> Helper loaded: html_helper
INFO - 2023-11-23 17:02:32 --> Helper loaded: text_helper
INFO - 2023-11-23 17:02:32 --> Helper loaded: form_helper
INFO - 2023-11-23 17:02:32 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:02:32 --> Helper loaded: security_helper
INFO - 2023-11-23 17:02:32 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:02:32 --> Database Driver Class Initialized
INFO - 2023-11-23 17:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:02:32 --> Parser Class Initialized
INFO - 2023-11-23 17:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:02:32 --> Pagination Class Initialized
INFO - 2023-11-23 17:02:32 --> Form Validation Class Initialized
INFO - 2023-11-23 17:02:32 --> Controller Class Initialized
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
DEBUG - 2023-11-23 17:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
DEBUG - 2023-11-23 17:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
DEBUG - 2023-11-23 17:02:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
INFO - 2023-11-23 17:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 17:02:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 17:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 17:02:32 --> Model Class Initialized
INFO - 2023-11-23 17:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 17:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 17:02:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 17:02:32 --> Final output sent to browser
DEBUG - 2023-11-23 17:02:32 --> Total execution time: 0.3817
ERROR - 2023-11-23 17:12:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:12:08 --> Config Class Initialized
INFO - 2023-11-23 17:12:08 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:12:08 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:12:08 --> Utf8 Class Initialized
INFO - 2023-11-23 17:12:08 --> URI Class Initialized
INFO - 2023-11-23 17:12:08 --> Router Class Initialized
INFO - 2023-11-23 17:12:08 --> Output Class Initialized
INFO - 2023-11-23 17:12:08 --> Security Class Initialized
DEBUG - 2023-11-23 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:12:08 --> Input Class Initialized
INFO - 2023-11-23 17:12:08 --> Language Class Initialized
INFO - 2023-11-23 17:12:08 --> Loader Class Initialized
INFO - 2023-11-23 17:12:08 --> Helper loaded: url_helper
INFO - 2023-11-23 17:12:08 --> Helper loaded: file_helper
INFO - 2023-11-23 17:12:08 --> Helper loaded: html_helper
INFO - 2023-11-23 17:12:08 --> Helper loaded: text_helper
INFO - 2023-11-23 17:12:08 --> Helper loaded: form_helper
INFO - 2023-11-23 17:12:08 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:12:08 --> Helper loaded: security_helper
INFO - 2023-11-23 17:12:08 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:12:08 --> Database Driver Class Initialized
INFO - 2023-11-23 17:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:12:08 --> Parser Class Initialized
INFO - 2023-11-23 17:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:12:08 --> Pagination Class Initialized
INFO - 2023-11-23 17:12:08 --> Form Validation Class Initialized
INFO - 2023-11-23 17:12:08 --> Controller Class Initialized
INFO - 2023-11-23 17:12:08 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:08 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:08 --> Model Class Initialized
INFO - 2023-11-23 17:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-11-23 17:12:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 17:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 17:12:09 --> Model Class Initialized
INFO - 2023-11-23 17:12:09 --> Model Class Initialized
INFO - 2023-11-23 17:12:09 --> Model Class Initialized
INFO - 2023-11-23 17:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 17:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 17:12:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 17:12:09 --> Final output sent to browser
DEBUG - 2023-11-23 17:12:09 --> Total execution time: 0.2665
ERROR - 2023-11-23 17:12:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:12:10 --> Config Class Initialized
INFO - 2023-11-23 17:12:10 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:12:10 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:12:10 --> Utf8 Class Initialized
INFO - 2023-11-23 17:12:10 --> URI Class Initialized
INFO - 2023-11-23 17:12:10 --> Router Class Initialized
INFO - 2023-11-23 17:12:10 --> Output Class Initialized
INFO - 2023-11-23 17:12:10 --> Security Class Initialized
DEBUG - 2023-11-23 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:12:10 --> Input Class Initialized
INFO - 2023-11-23 17:12:10 --> Language Class Initialized
INFO - 2023-11-23 17:12:10 --> Loader Class Initialized
INFO - 2023-11-23 17:12:10 --> Helper loaded: url_helper
INFO - 2023-11-23 17:12:10 --> Helper loaded: file_helper
INFO - 2023-11-23 17:12:10 --> Helper loaded: html_helper
INFO - 2023-11-23 17:12:10 --> Helper loaded: text_helper
INFO - 2023-11-23 17:12:10 --> Helper loaded: form_helper
INFO - 2023-11-23 17:12:10 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:12:10 --> Helper loaded: security_helper
INFO - 2023-11-23 17:12:10 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:12:10 --> Database Driver Class Initialized
INFO - 2023-11-23 17:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:12:10 --> Parser Class Initialized
INFO - 2023-11-23 17:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:12:10 --> Pagination Class Initialized
INFO - 2023-11-23 17:12:10 --> Form Validation Class Initialized
INFO - 2023-11-23 17:12:10 --> Controller Class Initialized
INFO - 2023-11-23 17:12:10 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:10 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:10 --> Model Class Initialized
INFO - 2023-11-23 17:12:10 --> Final output sent to browser
DEBUG - 2023-11-23 17:12:10 --> Total execution time: 0.0588
ERROR - 2023-11-23 17:12:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:12:15 --> Config Class Initialized
INFO - 2023-11-23 17:12:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:12:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:12:15 --> Utf8 Class Initialized
INFO - 2023-11-23 17:12:15 --> URI Class Initialized
INFO - 2023-11-23 17:12:15 --> Router Class Initialized
INFO - 2023-11-23 17:12:15 --> Output Class Initialized
INFO - 2023-11-23 17:12:15 --> Security Class Initialized
DEBUG - 2023-11-23 17:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:12:15 --> Input Class Initialized
INFO - 2023-11-23 17:12:15 --> Language Class Initialized
INFO - 2023-11-23 17:12:15 --> Loader Class Initialized
INFO - 2023-11-23 17:12:15 --> Helper loaded: url_helper
INFO - 2023-11-23 17:12:15 --> Helper loaded: file_helper
INFO - 2023-11-23 17:12:15 --> Helper loaded: html_helper
INFO - 2023-11-23 17:12:15 --> Helper loaded: text_helper
INFO - 2023-11-23 17:12:15 --> Helper loaded: form_helper
INFO - 2023-11-23 17:12:15 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:12:15 --> Helper loaded: security_helper
INFO - 2023-11-23 17:12:15 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:12:15 --> Database Driver Class Initialized
INFO - 2023-11-23 17:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:12:15 --> Parser Class Initialized
INFO - 2023-11-23 17:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:12:15 --> Pagination Class Initialized
INFO - 2023-11-23 17:12:15 --> Form Validation Class Initialized
INFO - 2023-11-23 17:12:15 --> Controller Class Initialized
INFO - 2023-11-23 17:12:15 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:15 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:15 --> Model Class Initialized
INFO - 2023-11-23 17:12:15 --> Final output sent to browser
DEBUG - 2023-11-23 17:12:15 --> Total execution time: 0.1546
ERROR - 2023-11-23 17:12:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:12:47 --> Config Class Initialized
INFO - 2023-11-23 17:12:47 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:12:47 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:12:47 --> Utf8 Class Initialized
INFO - 2023-11-23 17:12:47 --> URI Class Initialized
INFO - 2023-11-23 17:12:47 --> Router Class Initialized
INFO - 2023-11-23 17:12:47 --> Output Class Initialized
INFO - 2023-11-23 17:12:47 --> Security Class Initialized
DEBUG - 2023-11-23 17:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:12:47 --> Input Class Initialized
INFO - 2023-11-23 17:12:47 --> Language Class Initialized
INFO - 2023-11-23 17:12:47 --> Loader Class Initialized
INFO - 2023-11-23 17:12:47 --> Helper loaded: url_helper
INFO - 2023-11-23 17:12:47 --> Helper loaded: file_helper
INFO - 2023-11-23 17:12:47 --> Helper loaded: html_helper
INFO - 2023-11-23 17:12:47 --> Helper loaded: text_helper
INFO - 2023-11-23 17:12:47 --> Helper loaded: form_helper
INFO - 2023-11-23 17:12:47 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:12:47 --> Helper loaded: security_helper
INFO - 2023-11-23 17:12:47 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:12:47 --> Database Driver Class Initialized
INFO - 2023-11-23 17:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:12:47 --> Parser Class Initialized
INFO - 2023-11-23 17:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:12:47 --> Pagination Class Initialized
INFO - 2023-11-23 17:12:47 --> Form Validation Class Initialized
INFO - 2023-11-23 17:12:47 --> Controller Class Initialized
INFO - 2023-11-23 17:12:47 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:47 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:47 --> Model Class Initialized
INFO - 2023-11-23 17:12:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-23 17:12:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 17:12:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 17:12:47 --> Model Class Initialized
INFO - 2023-11-23 17:12:47 --> Model Class Initialized
INFO - 2023-11-23 17:12:47 --> Model Class Initialized
INFO - 2023-11-23 17:12:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 17:12:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 17:12:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 17:12:47 --> Final output sent to browser
DEBUG - 2023-11-23 17:12:47 --> Total execution time: 0.2125
ERROR - 2023-11-23 17:12:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:12:48 --> Config Class Initialized
INFO - 2023-11-23 17:12:48 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:12:48 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:12:48 --> Utf8 Class Initialized
INFO - 2023-11-23 17:12:48 --> URI Class Initialized
INFO - 2023-11-23 17:12:48 --> Router Class Initialized
INFO - 2023-11-23 17:12:48 --> Output Class Initialized
INFO - 2023-11-23 17:12:48 --> Security Class Initialized
DEBUG - 2023-11-23 17:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:12:48 --> Input Class Initialized
INFO - 2023-11-23 17:12:48 --> Language Class Initialized
INFO - 2023-11-23 17:12:48 --> Loader Class Initialized
INFO - 2023-11-23 17:12:48 --> Helper loaded: url_helper
INFO - 2023-11-23 17:12:48 --> Helper loaded: file_helper
INFO - 2023-11-23 17:12:48 --> Helper loaded: html_helper
INFO - 2023-11-23 17:12:48 --> Helper loaded: text_helper
INFO - 2023-11-23 17:12:48 --> Helper loaded: form_helper
INFO - 2023-11-23 17:12:48 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:12:48 --> Helper loaded: security_helper
INFO - 2023-11-23 17:12:48 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:12:48 --> Database Driver Class Initialized
INFO - 2023-11-23 17:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:12:48 --> Parser Class Initialized
INFO - 2023-11-23 17:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:12:48 --> Pagination Class Initialized
INFO - 2023-11-23 17:12:48 --> Form Validation Class Initialized
INFO - 2023-11-23 17:12:48 --> Controller Class Initialized
INFO - 2023-11-23 17:12:48 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:48 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:48 --> Model Class Initialized
INFO - 2023-11-23 17:12:48 --> Final output sent to browser
DEBUG - 2023-11-23 17:12:48 --> Total execution time: 0.0612
ERROR - 2023-11-23 17:12:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:12:52 --> Config Class Initialized
INFO - 2023-11-23 17:12:52 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:12:52 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:12:52 --> Utf8 Class Initialized
INFO - 2023-11-23 17:12:52 --> URI Class Initialized
INFO - 2023-11-23 17:12:52 --> Router Class Initialized
INFO - 2023-11-23 17:12:52 --> Output Class Initialized
INFO - 2023-11-23 17:12:52 --> Security Class Initialized
DEBUG - 2023-11-23 17:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:12:52 --> Input Class Initialized
INFO - 2023-11-23 17:12:52 --> Language Class Initialized
INFO - 2023-11-23 17:12:52 --> Loader Class Initialized
INFO - 2023-11-23 17:12:52 --> Helper loaded: url_helper
INFO - 2023-11-23 17:12:52 --> Helper loaded: file_helper
INFO - 2023-11-23 17:12:52 --> Helper loaded: html_helper
INFO - 2023-11-23 17:12:52 --> Helper loaded: text_helper
INFO - 2023-11-23 17:12:52 --> Helper loaded: form_helper
INFO - 2023-11-23 17:12:52 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:12:52 --> Helper loaded: security_helper
INFO - 2023-11-23 17:12:52 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:12:52 --> Database Driver Class Initialized
INFO - 2023-11-23 17:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:12:52 --> Parser Class Initialized
INFO - 2023-11-23 17:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:12:52 --> Pagination Class Initialized
INFO - 2023-11-23 17:12:52 --> Form Validation Class Initialized
INFO - 2023-11-23 17:12:52 --> Controller Class Initialized
INFO - 2023-11-23 17:12:52 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:52 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:52 --> Model Class Initialized
INFO - 2023-11-23 17:12:53 --> Final output sent to browser
DEBUG - 2023-11-23 17:12:53 --> Total execution time: 0.9607
ERROR - 2023-11-23 17:12:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:12:55 --> Config Class Initialized
INFO - 2023-11-23 17:12:55 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:12:55 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:12:55 --> Utf8 Class Initialized
INFO - 2023-11-23 17:12:55 --> URI Class Initialized
INFO - 2023-11-23 17:12:55 --> Router Class Initialized
INFO - 2023-11-23 17:12:55 --> Output Class Initialized
INFO - 2023-11-23 17:12:55 --> Security Class Initialized
DEBUG - 2023-11-23 17:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:12:55 --> Input Class Initialized
INFO - 2023-11-23 17:12:55 --> Language Class Initialized
INFO - 2023-11-23 17:12:55 --> Loader Class Initialized
INFO - 2023-11-23 17:12:55 --> Helper loaded: url_helper
INFO - 2023-11-23 17:12:55 --> Helper loaded: file_helper
INFO - 2023-11-23 17:12:55 --> Helper loaded: html_helper
INFO - 2023-11-23 17:12:55 --> Helper loaded: text_helper
INFO - 2023-11-23 17:12:55 --> Helper loaded: form_helper
INFO - 2023-11-23 17:12:55 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:12:55 --> Helper loaded: security_helper
INFO - 2023-11-23 17:12:55 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:12:55 --> Database Driver Class Initialized
INFO - 2023-11-23 17:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:12:55 --> Parser Class Initialized
INFO - 2023-11-23 17:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:12:55 --> Pagination Class Initialized
INFO - 2023-11-23 17:12:55 --> Form Validation Class Initialized
INFO - 2023-11-23 17:12:55 --> Controller Class Initialized
DEBUG - 2023-11-23 17:12:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:55 --> Model Class Initialized
INFO - 2023-11-23 17:12:55 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:55 --> Model Class Initialized
DEBUG - 2023-11-23 17:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-11-23 17:12:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 17:12:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 17:12:55 --> Model Class Initialized
INFO - 2023-11-23 17:12:55 --> Model Class Initialized
INFO - 2023-11-23 17:12:55 --> Model Class Initialized
INFO - 2023-11-23 17:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 17:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 17:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 17:12:56 --> Final output sent to browser
DEBUG - 2023-11-23 17:12:56 --> Total execution time: 0.2414
ERROR - 2023-11-23 17:13:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:13:51 --> Config Class Initialized
INFO - 2023-11-23 17:13:51 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:13:51 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:13:51 --> Utf8 Class Initialized
INFO - 2023-11-23 17:13:51 --> URI Class Initialized
DEBUG - 2023-11-23 17:13:51 --> No URI present. Default controller set.
INFO - 2023-11-23 17:13:51 --> Router Class Initialized
INFO - 2023-11-23 17:13:52 --> Output Class Initialized
INFO - 2023-11-23 17:13:52 --> Security Class Initialized
DEBUG - 2023-11-23 17:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:13:52 --> Input Class Initialized
INFO - 2023-11-23 17:13:52 --> Language Class Initialized
INFO - 2023-11-23 17:13:52 --> Loader Class Initialized
INFO - 2023-11-23 17:13:52 --> Helper loaded: url_helper
INFO - 2023-11-23 17:13:52 --> Helper loaded: file_helper
INFO - 2023-11-23 17:13:52 --> Helper loaded: html_helper
INFO - 2023-11-23 17:13:52 --> Helper loaded: text_helper
INFO - 2023-11-23 17:13:52 --> Helper loaded: form_helper
INFO - 2023-11-23 17:13:52 --> Helper loaded: lang_helper
INFO - 2023-11-23 17:13:52 --> Helper loaded: security_helper
INFO - 2023-11-23 17:13:52 --> Helper loaded: cookie_helper
INFO - 2023-11-23 17:13:52 --> Database Driver Class Initialized
INFO - 2023-11-23 17:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:13:52 --> Parser Class Initialized
INFO - 2023-11-23 17:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 17:13:52 --> Pagination Class Initialized
INFO - 2023-11-23 17:13:52 --> Form Validation Class Initialized
INFO - 2023-11-23 17:13:52 --> Controller Class Initialized
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
DEBUG - 2023-11-23 17:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
DEBUG - 2023-11-23 17:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
DEBUG - 2023-11-23 17:13:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
INFO - 2023-11-23 17:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-23 17:13:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-23 17:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-23 17:13:52 --> Model Class Initialized
INFO - 2023-11-23 17:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-23 17:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-23 17:13:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-23 17:13:52 --> Final output sent to browser
DEBUG - 2023-11-23 17:13:52 --> Total execution time: 0.3903
ERROR - 2023-11-23 19:07:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 19:07:23 --> Config Class Initialized
INFO - 2023-11-23 19:07:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 19:07:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 19:07:23 --> Utf8 Class Initialized
INFO - 2023-11-23 19:07:23 --> URI Class Initialized
INFO - 2023-11-23 19:07:23 --> Router Class Initialized
INFO - 2023-11-23 19:07:23 --> Output Class Initialized
INFO - 2023-11-23 19:07:23 --> Security Class Initialized
DEBUG - 2023-11-23 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 19:07:23 --> Input Class Initialized
INFO - 2023-11-23 19:07:23 --> Language Class Initialized
ERROR - 2023-11-23 19:07:23 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-23 20:11:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-23 20:11:13 --> Config Class Initialized
INFO - 2023-11-23 20:11:13 --> Hooks Class Initialized
DEBUG - 2023-11-23 20:11:13 --> UTF-8 Support Enabled
INFO - 2023-11-23 20:11:13 --> Utf8 Class Initialized
INFO - 2023-11-23 20:11:13 --> URI Class Initialized
DEBUG - 2023-11-23 20:11:13 --> No URI present. Default controller set.
INFO - 2023-11-23 20:11:13 --> Router Class Initialized
INFO - 2023-11-23 20:11:13 --> Output Class Initialized
INFO - 2023-11-23 20:11:13 --> Security Class Initialized
DEBUG - 2023-11-23 20:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 20:11:13 --> Input Class Initialized
INFO - 2023-11-23 20:11:13 --> Language Class Initialized
INFO - 2023-11-23 20:11:13 --> Loader Class Initialized
INFO - 2023-11-23 20:11:13 --> Helper loaded: url_helper
INFO - 2023-11-23 20:11:13 --> Helper loaded: file_helper
INFO - 2023-11-23 20:11:13 --> Helper loaded: html_helper
INFO - 2023-11-23 20:11:13 --> Helper loaded: text_helper
INFO - 2023-11-23 20:11:13 --> Helper loaded: form_helper
INFO - 2023-11-23 20:11:13 --> Helper loaded: lang_helper
INFO - 2023-11-23 20:11:13 --> Helper loaded: security_helper
INFO - 2023-11-23 20:11:13 --> Helper loaded: cookie_helper
INFO - 2023-11-23 20:11:13 --> Database Driver Class Initialized
INFO - 2023-11-23 20:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 20:11:13 --> Parser Class Initialized
INFO - 2023-11-23 20:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-23 20:11:13 --> Pagination Class Initialized
INFO - 2023-11-23 20:11:13 --> Form Validation Class Initialized
INFO - 2023-11-23 20:11:13 --> Controller Class Initialized
INFO - 2023-11-23 20:11:13 --> Model Class Initialized
DEBUG - 2023-11-23 20:11:13 --> Session class already loaded. Second attempt ignored.
