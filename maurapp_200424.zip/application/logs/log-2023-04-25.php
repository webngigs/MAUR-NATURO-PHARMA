<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-25 03:16:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 03:16:23 --> Config Class Initialized
INFO - 2023-04-25 03:16:23 --> Hooks Class Initialized
DEBUG - 2023-04-25 03:16:23 --> UTF-8 Support Enabled
INFO - 2023-04-25 03:16:23 --> Utf8 Class Initialized
INFO - 2023-04-25 03:16:23 --> URI Class Initialized
DEBUG - 2023-04-25 03:16:23 --> No URI present. Default controller set.
INFO - 2023-04-25 03:16:23 --> Router Class Initialized
INFO - 2023-04-25 03:16:23 --> Output Class Initialized
INFO - 2023-04-25 03:16:23 --> Security Class Initialized
DEBUG - 2023-04-25 03:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 03:16:23 --> Input Class Initialized
INFO - 2023-04-25 03:16:23 --> Language Class Initialized
INFO - 2023-04-25 03:16:23 --> Loader Class Initialized
INFO - 2023-04-25 03:16:23 --> Helper loaded: url_helper
INFO - 2023-04-25 03:16:23 --> Helper loaded: file_helper
INFO - 2023-04-25 03:16:23 --> Helper loaded: html_helper
INFO - 2023-04-25 03:16:23 --> Helper loaded: text_helper
INFO - 2023-04-25 03:16:23 --> Helper loaded: form_helper
INFO - 2023-04-25 03:16:23 --> Helper loaded: lang_helper
INFO - 2023-04-25 03:16:23 --> Helper loaded: security_helper
INFO - 2023-04-25 03:16:23 --> Helper loaded: cookie_helper
INFO - 2023-04-25 03:16:23 --> Database Driver Class Initialized
INFO - 2023-04-25 03:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 03:16:23 --> Parser Class Initialized
INFO - 2023-04-25 03:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 03:16:23 --> Pagination Class Initialized
INFO - 2023-04-25 03:16:23 --> Form Validation Class Initialized
INFO - 2023-04-25 03:16:23 --> Controller Class Initialized
INFO - 2023-04-25 03:16:23 --> Model Class Initialized
DEBUG - 2023-04-25 03:16:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 03:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 03:16:24 --> Config Class Initialized
INFO - 2023-04-25 03:16:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 03:16:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 03:16:24 --> Utf8 Class Initialized
INFO - 2023-04-25 03:16:24 --> URI Class Initialized
INFO - 2023-04-25 03:16:24 --> Router Class Initialized
INFO - 2023-04-25 03:16:24 --> Output Class Initialized
INFO - 2023-04-25 03:16:24 --> Security Class Initialized
DEBUG - 2023-04-25 03:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 03:16:24 --> Input Class Initialized
INFO - 2023-04-25 03:16:24 --> Language Class Initialized
INFO - 2023-04-25 03:16:24 --> Loader Class Initialized
INFO - 2023-04-25 03:16:24 --> Helper loaded: url_helper
INFO - 2023-04-25 03:16:24 --> Helper loaded: file_helper
INFO - 2023-04-25 03:16:24 --> Helper loaded: html_helper
INFO - 2023-04-25 03:16:24 --> Helper loaded: text_helper
INFO - 2023-04-25 03:16:24 --> Helper loaded: form_helper
INFO - 2023-04-25 03:16:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 03:16:24 --> Helper loaded: security_helper
INFO - 2023-04-25 03:16:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 03:16:24 --> Database Driver Class Initialized
INFO - 2023-04-25 03:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 03:16:24 --> Parser Class Initialized
INFO - 2023-04-25 03:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 03:16:24 --> Pagination Class Initialized
INFO - 2023-04-25 03:16:24 --> Form Validation Class Initialized
INFO - 2023-04-25 03:16:24 --> Controller Class Initialized
INFO - 2023-04-25 03:16:24 --> Model Class Initialized
DEBUG - 2023-04-25 03:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 03:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 03:16:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 03:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 03:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 03:16:24 --> Model Class Initialized
INFO - 2023-04-25 03:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 03:16:24 --> Final output sent to browser
DEBUG - 2023-04-25 03:16:24 --> Total execution time: 0.0313
ERROR - 2023-04-25 03:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 03:16:33 --> Config Class Initialized
INFO - 2023-04-25 03:16:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 03:16:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 03:16:33 --> Utf8 Class Initialized
INFO - 2023-04-25 03:16:33 --> URI Class Initialized
INFO - 2023-04-25 03:16:33 --> Router Class Initialized
INFO - 2023-04-25 03:16:33 --> Output Class Initialized
INFO - 2023-04-25 03:16:33 --> Security Class Initialized
DEBUG - 2023-04-25 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 03:16:33 --> Input Class Initialized
INFO - 2023-04-25 03:16:33 --> Language Class Initialized
INFO - 2023-04-25 03:16:33 --> Loader Class Initialized
INFO - 2023-04-25 03:16:33 --> Helper loaded: url_helper
INFO - 2023-04-25 03:16:33 --> Helper loaded: file_helper
INFO - 2023-04-25 03:16:33 --> Helper loaded: html_helper
INFO - 2023-04-25 03:16:33 --> Helper loaded: text_helper
INFO - 2023-04-25 03:16:33 --> Helper loaded: form_helper
INFO - 2023-04-25 03:16:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 03:16:33 --> Helper loaded: security_helper
INFO - 2023-04-25 03:16:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 03:16:33 --> Database Driver Class Initialized
INFO - 2023-04-25 03:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 03:16:33 --> Parser Class Initialized
INFO - 2023-04-25 03:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 03:16:33 --> Pagination Class Initialized
INFO - 2023-04-25 03:16:33 --> Form Validation Class Initialized
INFO - 2023-04-25 03:16:33 --> Controller Class Initialized
INFO - 2023-04-25 03:16:33 --> Model Class Initialized
DEBUG - 2023-04-25 03:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 03:16:33 --> Model Class Initialized
INFO - 2023-04-25 03:16:33 --> Final output sent to browser
DEBUG - 2023-04-25 03:16:33 --> Total execution time: 0.0206
ERROR - 2023-04-25 03:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 03:16:34 --> Config Class Initialized
INFO - 2023-04-25 03:16:34 --> Hooks Class Initialized
DEBUG - 2023-04-25 03:16:34 --> UTF-8 Support Enabled
INFO - 2023-04-25 03:16:34 --> Utf8 Class Initialized
INFO - 2023-04-25 03:16:34 --> URI Class Initialized
DEBUG - 2023-04-25 03:16:34 --> No URI present. Default controller set.
INFO - 2023-04-25 03:16:34 --> Router Class Initialized
INFO - 2023-04-25 03:16:34 --> Output Class Initialized
INFO - 2023-04-25 03:16:34 --> Security Class Initialized
DEBUG - 2023-04-25 03:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 03:16:34 --> Input Class Initialized
INFO - 2023-04-25 03:16:34 --> Language Class Initialized
INFO - 2023-04-25 03:16:34 --> Loader Class Initialized
INFO - 2023-04-25 03:16:34 --> Helper loaded: url_helper
INFO - 2023-04-25 03:16:34 --> Helper loaded: file_helper
INFO - 2023-04-25 03:16:34 --> Helper loaded: html_helper
INFO - 2023-04-25 03:16:34 --> Helper loaded: text_helper
INFO - 2023-04-25 03:16:34 --> Helper loaded: form_helper
INFO - 2023-04-25 03:16:34 --> Helper loaded: lang_helper
INFO - 2023-04-25 03:16:34 --> Helper loaded: security_helper
INFO - 2023-04-25 03:16:34 --> Helper loaded: cookie_helper
INFO - 2023-04-25 03:16:34 --> Database Driver Class Initialized
INFO - 2023-04-25 03:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 03:16:34 --> Parser Class Initialized
INFO - 2023-04-25 03:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 03:16:34 --> Pagination Class Initialized
INFO - 2023-04-25 03:16:34 --> Form Validation Class Initialized
INFO - 2023-04-25 03:16:34 --> Controller Class Initialized
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
DEBUG - 2023-04-25 03:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
DEBUG - 2023-04-25 03:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
DEBUG - 2023-04-25 03:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 03:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
INFO - 2023-04-25 03:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 03:16:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 03:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 03:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 03:16:34 --> Model Class Initialized
INFO - 2023-04-25 03:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 03:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 03:16:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 03:16:34 --> Final output sent to browser
DEBUG - 2023-04-25 03:16:34 --> Total execution time: 0.0637
ERROR - 2023-04-25 04:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:23:45 --> Config Class Initialized
INFO - 2023-04-25 04:23:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:23:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:23:45 --> Utf8 Class Initialized
INFO - 2023-04-25 04:23:45 --> URI Class Initialized
DEBUG - 2023-04-25 04:23:45 --> No URI present. Default controller set.
INFO - 2023-04-25 04:23:45 --> Router Class Initialized
INFO - 2023-04-25 04:23:45 --> Output Class Initialized
INFO - 2023-04-25 04:23:45 --> Security Class Initialized
DEBUG - 2023-04-25 04:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:23:45 --> Input Class Initialized
INFO - 2023-04-25 04:23:45 --> Language Class Initialized
INFO - 2023-04-25 04:23:45 --> Loader Class Initialized
INFO - 2023-04-25 04:23:45 --> Helper loaded: url_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: file_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: html_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: text_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: form_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: security_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:23:45 --> Database Driver Class Initialized
INFO - 2023-04-25 04:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:23:45 --> Parser Class Initialized
INFO - 2023-04-25 04:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:23:45 --> Pagination Class Initialized
INFO - 2023-04-25 04:23:45 --> Form Validation Class Initialized
INFO - 2023-04-25 04:23:45 --> Controller Class Initialized
INFO - 2023-04-25 04:23:45 --> Model Class Initialized
DEBUG - 2023-04-25 04:23:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 04:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:23:45 --> Config Class Initialized
INFO - 2023-04-25 04:23:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:23:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:23:45 --> Utf8 Class Initialized
INFO - 2023-04-25 04:23:45 --> URI Class Initialized
INFO - 2023-04-25 04:23:45 --> Router Class Initialized
INFO - 2023-04-25 04:23:45 --> Output Class Initialized
INFO - 2023-04-25 04:23:45 --> Security Class Initialized
DEBUG - 2023-04-25 04:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:23:45 --> Input Class Initialized
INFO - 2023-04-25 04:23:45 --> Language Class Initialized
INFO - 2023-04-25 04:23:45 --> Loader Class Initialized
INFO - 2023-04-25 04:23:45 --> Helper loaded: url_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: file_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: html_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: text_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: form_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: security_helper
INFO - 2023-04-25 04:23:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:23:45 --> Database Driver Class Initialized
INFO - 2023-04-25 04:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:23:45 --> Parser Class Initialized
INFO - 2023-04-25 04:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:23:45 --> Pagination Class Initialized
INFO - 2023-04-25 04:23:45 --> Form Validation Class Initialized
INFO - 2023-04-25 04:23:45 --> Controller Class Initialized
INFO - 2023-04-25 04:23:45 --> Model Class Initialized
DEBUG - 2023-04-25 04:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 04:23:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:23:46 --> Model Class Initialized
INFO - 2023-04-25 04:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:23:46 --> Final output sent to browser
DEBUG - 2023-04-25 04:23:46 --> Total execution time: 0.0327
ERROR - 2023-04-25 04:24:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:01 --> Config Class Initialized
INFO - 2023-04-25 04:24:01 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:01 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:01 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:01 --> URI Class Initialized
INFO - 2023-04-25 04:24:01 --> Router Class Initialized
INFO - 2023-04-25 04:24:01 --> Output Class Initialized
INFO - 2023-04-25 04:24:01 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:01 --> Input Class Initialized
INFO - 2023-04-25 04:24:01 --> Language Class Initialized
INFO - 2023-04-25 04:24:01 --> Loader Class Initialized
INFO - 2023-04-25 04:24:01 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:01 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:01 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:01 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:01 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:01 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:01 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:01 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:01 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:01 --> Parser Class Initialized
INFO - 2023-04-25 04:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:01 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:01 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:01 --> Controller Class Initialized
INFO - 2023-04-25 04:24:01 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:01 --> Model Class Initialized
INFO - 2023-04-25 04:24:01 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:01 --> Total execution time: 0.0202
ERROR - 2023-04-25 04:24:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:02 --> Config Class Initialized
INFO - 2023-04-25 04:24:02 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:02 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:02 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:02 --> URI Class Initialized
DEBUG - 2023-04-25 04:24:02 --> No URI present. Default controller set.
INFO - 2023-04-25 04:24:02 --> Router Class Initialized
INFO - 2023-04-25 04:24:02 --> Output Class Initialized
INFO - 2023-04-25 04:24:02 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:02 --> Input Class Initialized
INFO - 2023-04-25 04:24:02 --> Language Class Initialized
INFO - 2023-04-25 04:24:02 --> Loader Class Initialized
INFO - 2023-04-25 04:24:02 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:02 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:02 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:02 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:02 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:02 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:02 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:02 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:02 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:02 --> Parser Class Initialized
INFO - 2023-04-25 04:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:02 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:02 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:02 --> Controller Class Initialized
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
INFO - 2023-04-25 04:24:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 04:24:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:24:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:24:02 --> Model Class Initialized
INFO - 2023-04-25 04:24:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:24:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:24:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:24:02 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:02 --> Total execution time: 0.0732
ERROR - 2023-04-25 04:24:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:16 --> Config Class Initialized
INFO - 2023-04-25 04:24:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:16 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:16 --> URI Class Initialized
INFO - 2023-04-25 04:24:16 --> Router Class Initialized
INFO - 2023-04-25 04:24:16 --> Output Class Initialized
INFO - 2023-04-25 04:24:16 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:16 --> Input Class Initialized
INFO - 2023-04-25 04:24:16 --> Language Class Initialized
INFO - 2023-04-25 04:24:16 --> Loader Class Initialized
INFO - 2023-04-25 04:24:16 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:16 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:16 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:16 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:16 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:16 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:16 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:16 --> Parser Class Initialized
INFO - 2023-04-25 04:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:16 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:16 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:16 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:16 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:16 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:16 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:16 --> Model Class Initialized
INFO - 2023-04-25 04:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-25 04:24:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:24:16 --> Model Class Initialized
INFO - 2023-04-25 04:24:16 --> Model Class Initialized
INFO - 2023-04-25 04:24:16 --> Model Class Initialized
INFO - 2023-04-25 04:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:24:16 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:16 --> Total execution time: 0.0713
ERROR - 2023-04-25 04:24:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:18 --> Config Class Initialized
INFO - 2023-04-25 04:24:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:18 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:18 --> URI Class Initialized
INFO - 2023-04-25 04:24:18 --> Router Class Initialized
INFO - 2023-04-25 04:24:18 --> Output Class Initialized
INFO - 2023-04-25 04:24:18 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:18 --> Input Class Initialized
INFO - 2023-04-25 04:24:18 --> Language Class Initialized
INFO - 2023-04-25 04:24:18 --> Loader Class Initialized
INFO - 2023-04-25 04:24:18 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:18 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:18 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:18 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:18 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:18 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:18 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:18 --> Parser Class Initialized
INFO - 2023-04-25 04:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:18 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:18 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:18 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:18 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:18 --> Model Class Initialized
INFO - 2023-04-25 04:24:18 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:18 --> Total execution time: 0.0235
ERROR - 2023-04-25 04:24:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:22 --> Config Class Initialized
INFO - 2023-04-25 04:24:22 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:22 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:22 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:22 --> URI Class Initialized
INFO - 2023-04-25 04:24:22 --> Router Class Initialized
INFO - 2023-04-25 04:24:22 --> Output Class Initialized
INFO - 2023-04-25 04:24:22 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:22 --> Input Class Initialized
INFO - 2023-04-25 04:24:22 --> Language Class Initialized
INFO - 2023-04-25 04:24:22 --> Loader Class Initialized
INFO - 2023-04-25 04:24:22 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:22 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:22 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:22 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:22 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:22 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:22 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:22 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:22 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:22 --> Parser Class Initialized
INFO - 2023-04-25 04:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:22 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:22 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:22 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:22 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:22 --> Model Class Initialized
INFO - 2023-04-25 04:24:22 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:22 --> Total execution time: 0.0203
ERROR - 2023-04-25 04:24:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:28 --> Config Class Initialized
INFO - 2023-04-25 04:24:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:28 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:28 --> URI Class Initialized
INFO - 2023-04-25 04:24:28 --> Router Class Initialized
INFO - 2023-04-25 04:24:28 --> Output Class Initialized
INFO - 2023-04-25 04:24:28 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:28 --> Input Class Initialized
INFO - 2023-04-25 04:24:28 --> Language Class Initialized
INFO - 2023-04-25 04:24:28 --> Loader Class Initialized
INFO - 2023-04-25 04:24:28 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:28 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:28 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:28 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:28 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:28 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:28 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:28 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:28 --> Parser Class Initialized
INFO - 2023-04-25 04:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:28 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:28 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:28 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:28 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:28 --> Model Class Initialized
INFO - 2023-04-25 04:24:28 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:28 --> Total execution time: 0.0195
ERROR - 2023-04-25 04:24:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:52 --> Config Class Initialized
INFO - 2023-04-25 04:24:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:52 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:52 --> URI Class Initialized
INFO - 2023-04-25 04:24:52 --> Router Class Initialized
INFO - 2023-04-25 04:24:52 --> Output Class Initialized
INFO - 2023-04-25 04:24:52 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:52 --> Input Class Initialized
INFO - 2023-04-25 04:24:52 --> Language Class Initialized
INFO - 2023-04-25 04:24:52 --> Loader Class Initialized
INFO - 2023-04-25 04:24:52 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:52 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:52 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:52 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:52 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:52 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:52 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:52 --> Parser Class Initialized
INFO - 2023-04-25 04:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:52 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:52 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:52 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:52 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:52 --> Model Class Initialized
INFO - 2023-04-25 04:24:52 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:52 --> Total execution time: 0.0227
ERROR - 2023-04-25 04:24:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:53 --> Config Class Initialized
INFO - 2023-04-25 04:24:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:53 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:53 --> URI Class Initialized
INFO - 2023-04-25 04:24:53 --> Router Class Initialized
INFO - 2023-04-25 04:24:53 --> Output Class Initialized
INFO - 2023-04-25 04:24:53 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:53 --> Input Class Initialized
INFO - 2023-04-25 04:24:53 --> Language Class Initialized
INFO - 2023-04-25 04:24:53 --> Loader Class Initialized
INFO - 2023-04-25 04:24:53 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:53 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:53 --> Parser Class Initialized
INFO - 2023-04-25 04:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:53 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:53 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:53 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:53 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:53 --> Model Class Initialized
INFO - 2023-04-25 04:24:53 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:53 --> Total execution time: 0.0187
ERROR - 2023-04-25 04:24:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:53 --> Config Class Initialized
INFO - 2023-04-25 04:24:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:53 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:53 --> URI Class Initialized
INFO - 2023-04-25 04:24:53 --> Router Class Initialized
INFO - 2023-04-25 04:24:53 --> Output Class Initialized
INFO - 2023-04-25 04:24:53 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:53 --> Input Class Initialized
INFO - 2023-04-25 04:24:53 --> Language Class Initialized
INFO - 2023-04-25 04:24:53 --> Loader Class Initialized
INFO - 2023-04-25 04:24:53 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:53 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:53 --> Parser Class Initialized
INFO - 2023-04-25 04:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:53 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:53 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:53 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:53 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:53 --> Model Class Initialized
INFO - 2023-04-25 04:24:53 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:53 --> Total execution time: 0.0179
ERROR - 2023-04-25 04:24:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:55 --> Config Class Initialized
INFO - 2023-04-25 04:24:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:55 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:55 --> URI Class Initialized
INFO - 2023-04-25 04:24:55 --> Router Class Initialized
INFO - 2023-04-25 04:24:55 --> Output Class Initialized
INFO - 2023-04-25 04:24:55 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:55 --> Input Class Initialized
INFO - 2023-04-25 04:24:55 --> Language Class Initialized
INFO - 2023-04-25 04:24:55 --> Loader Class Initialized
INFO - 2023-04-25 04:24:55 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:55 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:55 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:55 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:55 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:55 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:55 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:55 --> Parser Class Initialized
INFO - 2023-04-25 04:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:55 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:55 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:55 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:55 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:55 --> Model Class Initialized
INFO - 2023-04-25 04:24:55 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:55 --> Total execution time: 0.0234
ERROR - 2023-04-25 04:24:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:24:56 --> Config Class Initialized
INFO - 2023-04-25 04:24:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:24:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:24:56 --> Utf8 Class Initialized
INFO - 2023-04-25 04:24:56 --> URI Class Initialized
INFO - 2023-04-25 04:24:56 --> Router Class Initialized
INFO - 2023-04-25 04:24:56 --> Output Class Initialized
INFO - 2023-04-25 04:24:56 --> Security Class Initialized
DEBUG - 2023-04-25 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:24:56 --> Input Class Initialized
INFO - 2023-04-25 04:24:56 --> Language Class Initialized
INFO - 2023-04-25 04:24:56 --> Loader Class Initialized
INFO - 2023-04-25 04:24:56 --> Helper loaded: url_helper
INFO - 2023-04-25 04:24:56 --> Helper loaded: file_helper
INFO - 2023-04-25 04:24:56 --> Helper loaded: html_helper
INFO - 2023-04-25 04:24:56 --> Helper loaded: text_helper
INFO - 2023-04-25 04:24:56 --> Helper loaded: form_helper
INFO - 2023-04-25 04:24:56 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:24:56 --> Helper loaded: security_helper
INFO - 2023-04-25 04:24:56 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:24:56 --> Database Driver Class Initialized
INFO - 2023-04-25 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:24:56 --> Parser Class Initialized
INFO - 2023-04-25 04:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:24:56 --> Pagination Class Initialized
INFO - 2023-04-25 04:24:56 --> Form Validation Class Initialized
INFO - 2023-04-25 04:24:56 --> Controller Class Initialized
DEBUG - 2023-04-25 04:24:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:56 --> Model Class Initialized
DEBUG - 2023-04-25 04:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:24:56 --> Model Class Initialized
INFO - 2023-04-25 04:24:56 --> Final output sent to browser
DEBUG - 2023-04-25 04:24:56 --> Total execution time: 0.0178
ERROR - 2023-04-25 04:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:25:16 --> Config Class Initialized
INFO - 2023-04-25 04:25:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:25:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:25:16 --> Utf8 Class Initialized
INFO - 2023-04-25 04:25:16 --> URI Class Initialized
INFO - 2023-04-25 04:25:16 --> Router Class Initialized
INFO - 2023-04-25 04:25:16 --> Output Class Initialized
INFO - 2023-04-25 04:25:16 --> Security Class Initialized
DEBUG - 2023-04-25 04:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:25:16 --> Input Class Initialized
INFO - 2023-04-25 04:25:16 --> Language Class Initialized
INFO - 2023-04-25 04:25:16 --> Loader Class Initialized
INFO - 2023-04-25 04:25:16 --> Helper loaded: url_helper
INFO - 2023-04-25 04:25:16 --> Helper loaded: file_helper
INFO - 2023-04-25 04:25:16 --> Helper loaded: html_helper
INFO - 2023-04-25 04:25:16 --> Helper loaded: text_helper
INFO - 2023-04-25 04:25:16 --> Helper loaded: form_helper
INFO - 2023-04-25 04:25:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:25:16 --> Helper loaded: security_helper
INFO - 2023-04-25 04:25:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:25:16 --> Database Driver Class Initialized
INFO - 2023-04-25 04:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:25:16 --> Parser Class Initialized
INFO - 2023-04-25 04:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:25:16 --> Pagination Class Initialized
INFO - 2023-04-25 04:25:16 --> Form Validation Class Initialized
INFO - 2023-04-25 04:25:16 --> Controller Class Initialized
DEBUG - 2023-04-25 04:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:25:16 --> Model Class Initialized
DEBUG - 2023-04-25 04:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:25:16 --> Model Class Initialized
DEBUG - 2023-04-25 04:25:16 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:25:16 --> Model Class Initialized
INFO - 2023-04-25 04:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/credit_customer.php
DEBUG - 2023-04-25 04:25:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:25:16 --> Model Class Initialized
INFO - 2023-04-25 04:25:16 --> Model Class Initialized
INFO - 2023-04-25 04:25:16 --> Model Class Initialized
INFO - 2023-04-25 04:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:25:16 --> Final output sent to browser
DEBUG - 2023-04-25 04:25:16 --> Total execution time: 0.0631
ERROR - 2023-04-25 04:25:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:25:18 --> Config Class Initialized
INFO - 2023-04-25 04:25:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:25:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:25:18 --> Utf8 Class Initialized
INFO - 2023-04-25 04:25:18 --> URI Class Initialized
INFO - 2023-04-25 04:25:18 --> Router Class Initialized
INFO - 2023-04-25 04:25:18 --> Output Class Initialized
INFO - 2023-04-25 04:25:18 --> Security Class Initialized
DEBUG - 2023-04-25 04:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:25:18 --> Input Class Initialized
INFO - 2023-04-25 04:25:18 --> Language Class Initialized
INFO - 2023-04-25 04:25:18 --> Loader Class Initialized
INFO - 2023-04-25 04:25:18 --> Helper loaded: url_helper
INFO - 2023-04-25 04:25:18 --> Helper loaded: file_helper
INFO - 2023-04-25 04:25:18 --> Helper loaded: html_helper
INFO - 2023-04-25 04:25:18 --> Helper loaded: text_helper
INFO - 2023-04-25 04:25:18 --> Helper loaded: form_helper
INFO - 2023-04-25 04:25:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:25:18 --> Helper loaded: security_helper
INFO - 2023-04-25 04:25:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:25:18 --> Database Driver Class Initialized
INFO - 2023-04-25 04:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:25:18 --> Parser Class Initialized
INFO - 2023-04-25 04:25:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:25:18 --> Pagination Class Initialized
INFO - 2023-04-25 04:25:18 --> Form Validation Class Initialized
INFO - 2023-04-25 04:25:18 --> Controller Class Initialized
DEBUG - 2023-04-25 04:25:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:25:18 --> Model Class Initialized
DEBUG - 2023-04-25 04:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:25:18 --> Model Class Initialized
INFO - 2023-04-25 04:25:18 --> Final output sent to browser
DEBUG - 2023-04-25 04:25:18 --> Total execution time: 0.0206
ERROR - 2023-04-25 04:26:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:26:03 --> Config Class Initialized
INFO - 2023-04-25 04:26:03 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:26:03 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:26:03 --> Utf8 Class Initialized
INFO - 2023-04-25 04:26:03 --> URI Class Initialized
INFO - 2023-04-25 04:26:03 --> Router Class Initialized
INFO - 2023-04-25 04:26:03 --> Output Class Initialized
INFO - 2023-04-25 04:26:03 --> Security Class Initialized
DEBUG - 2023-04-25 04:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:26:03 --> Input Class Initialized
INFO - 2023-04-25 04:26:03 --> Language Class Initialized
INFO - 2023-04-25 04:26:03 --> Loader Class Initialized
INFO - 2023-04-25 04:26:03 --> Helper loaded: url_helper
INFO - 2023-04-25 04:26:03 --> Helper loaded: file_helper
INFO - 2023-04-25 04:26:03 --> Helper loaded: html_helper
INFO - 2023-04-25 04:26:03 --> Helper loaded: text_helper
INFO - 2023-04-25 04:26:03 --> Helper loaded: form_helper
INFO - 2023-04-25 04:26:03 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:26:03 --> Helper loaded: security_helper
INFO - 2023-04-25 04:26:03 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:26:03 --> Database Driver Class Initialized
INFO - 2023-04-25 04:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:26:03 --> Parser Class Initialized
INFO - 2023-04-25 04:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:26:03 --> Pagination Class Initialized
INFO - 2023-04-25 04:26:03 --> Form Validation Class Initialized
INFO - 2023-04-25 04:26:03 --> Controller Class Initialized
DEBUG - 2023-04-25 04:26:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:03 --> Model Class Initialized
DEBUG - 2023-04-25 04:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:03 --> Model Class Initialized
DEBUG - 2023-04-25 04:26:03 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:03 --> Model Class Initialized
INFO - 2023-04-25 04:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/paid_customer.php
DEBUG - 2023-04-25 04:26:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:26:03 --> Model Class Initialized
INFO - 2023-04-25 04:26:03 --> Model Class Initialized
INFO - 2023-04-25 04:26:03 --> Model Class Initialized
INFO - 2023-04-25 04:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:26:03 --> Final output sent to browser
DEBUG - 2023-04-25 04:26:03 --> Total execution time: 0.0640
ERROR - 2023-04-25 04:26:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:26:04 --> Config Class Initialized
INFO - 2023-04-25 04:26:04 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:26:04 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:26:04 --> Utf8 Class Initialized
INFO - 2023-04-25 04:26:04 --> URI Class Initialized
INFO - 2023-04-25 04:26:04 --> Router Class Initialized
INFO - 2023-04-25 04:26:04 --> Output Class Initialized
INFO - 2023-04-25 04:26:04 --> Security Class Initialized
DEBUG - 2023-04-25 04:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:26:04 --> Input Class Initialized
INFO - 2023-04-25 04:26:04 --> Language Class Initialized
INFO - 2023-04-25 04:26:04 --> Loader Class Initialized
INFO - 2023-04-25 04:26:04 --> Helper loaded: url_helper
INFO - 2023-04-25 04:26:04 --> Helper loaded: file_helper
INFO - 2023-04-25 04:26:04 --> Helper loaded: html_helper
INFO - 2023-04-25 04:26:04 --> Helper loaded: text_helper
INFO - 2023-04-25 04:26:04 --> Helper loaded: form_helper
INFO - 2023-04-25 04:26:04 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:26:04 --> Helper loaded: security_helper
INFO - 2023-04-25 04:26:04 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:26:04 --> Database Driver Class Initialized
INFO - 2023-04-25 04:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:26:04 --> Parser Class Initialized
INFO - 2023-04-25 04:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:26:04 --> Pagination Class Initialized
INFO - 2023-04-25 04:26:04 --> Form Validation Class Initialized
INFO - 2023-04-25 04:26:04 --> Controller Class Initialized
DEBUG - 2023-04-25 04:26:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:04 --> Model Class Initialized
DEBUG - 2023-04-25 04:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:04 --> Model Class Initialized
INFO - 2023-04-25 04:26:04 --> Final output sent to browser
DEBUG - 2023-04-25 04:26:04 --> Total execution time: 0.0207
ERROR - 2023-04-25 04:26:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:26:33 --> Config Class Initialized
INFO - 2023-04-25 04:26:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:26:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:26:33 --> Utf8 Class Initialized
INFO - 2023-04-25 04:26:33 --> URI Class Initialized
INFO - 2023-04-25 04:26:33 --> Router Class Initialized
INFO - 2023-04-25 04:26:33 --> Output Class Initialized
INFO - 2023-04-25 04:26:33 --> Security Class Initialized
DEBUG - 2023-04-25 04:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:26:33 --> Input Class Initialized
INFO - 2023-04-25 04:26:33 --> Language Class Initialized
INFO - 2023-04-25 04:26:33 --> Loader Class Initialized
INFO - 2023-04-25 04:26:33 --> Helper loaded: url_helper
INFO - 2023-04-25 04:26:33 --> Helper loaded: file_helper
INFO - 2023-04-25 04:26:33 --> Helper loaded: html_helper
INFO - 2023-04-25 04:26:33 --> Helper loaded: text_helper
INFO - 2023-04-25 04:26:33 --> Helper loaded: form_helper
INFO - 2023-04-25 04:26:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:26:33 --> Helper loaded: security_helper
INFO - 2023-04-25 04:26:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:26:33 --> Database Driver Class Initialized
INFO - 2023-04-25 04:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:26:33 --> Parser Class Initialized
INFO - 2023-04-25 04:26:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:26:33 --> Pagination Class Initialized
INFO - 2023-04-25 04:26:33 --> Form Validation Class Initialized
INFO - 2023-04-25 04:26:33 --> Controller Class Initialized
DEBUG - 2023-04-25 04:26:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:33 --> Model Class Initialized
DEBUG - 2023-04-25 04:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:33 --> Model Class Initialized
DEBUG - 2023-04-25 04:26:33 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:33 --> Model Class Initialized
INFO - 2023-04-25 04:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/credit_customer.php
DEBUG - 2023-04-25 04:26:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:26:33 --> Model Class Initialized
INFO - 2023-04-25 04:26:33 --> Model Class Initialized
INFO - 2023-04-25 04:26:33 --> Model Class Initialized
INFO - 2023-04-25 04:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:26:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:26:33 --> Final output sent to browser
DEBUG - 2023-04-25 04:26:33 --> Total execution time: 0.0722
ERROR - 2023-04-25 04:26:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:26:35 --> Config Class Initialized
INFO - 2023-04-25 04:26:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:26:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:26:35 --> Utf8 Class Initialized
INFO - 2023-04-25 04:26:35 --> URI Class Initialized
INFO - 2023-04-25 04:26:35 --> Router Class Initialized
INFO - 2023-04-25 04:26:35 --> Output Class Initialized
INFO - 2023-04-25 04:26:35 --> Security Class Initialized
DEBUG - 2023-04-25 04:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:26:35 --> Input Class Initialized
INFO - 2023-04-25 04:26:35 --> Language Class Initialized
INFO - 2023-04-25 04:26:35 --> Loader Class Initialized
INFO - 2023-04-25 04:26:35 --> Helper loaded: url_helper
INFO - 2023-04-25 04:26:35 --> Helper loaded: file_helper
INFO - 2023-04-25 04:26:35 --> Helper loaded: html_helper
INFO - 2023-04-25 04:26:35 --> Helper loaded: text_helper
INFO - 2023-04-25 04:26:35 --> Helper loaded: form_helper
INFO - 2023-04-25 04:26:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:26:35 --> Helper loaded: security_helper
INFO - 2023-04-25 04:26:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:26:35 --> Database Driver Class Initialized
INFO - 2023-04-25 04:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:26:35 --> Parser Class Initialized
INFO - 2023-04-25 04:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:26:35 --> Pagination Class Initialized
INFO - 2023-04-25 04:26:35 --> Form Validation Class Initialized
INFO - 2023-04-25 04:26:35 --> Controller Class Initialized
DEBUG - 2023-04-25 04:26:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:35 --> Model Class Initialized
DEBUG - 2023-04-25 04:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:35 --> Model Class Initialized
INFO - 2023-04-25 04:26:35 --> Final output sent to browser
DEBUG - 2023-04-25 04:26:35 --> Total execution time: 0.0211
ERROR - 2023-04-25 04:26:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:26:46 --> Config Class Initialized
INFO - 2023-04-25 04:26:46 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:26:46 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:26:46 --> Utf8 Class Initialized
INFO - 2023-04-25 04:26:46 --> URI Class Initialized
INFO - 2023-04-25 04:26:46 --> Router Class Initialized
INFO - 2023-04-25 04:26:46 --> Output Class Initialized
INFO - 2023-04-25 04:26:46 --> Security Class Initialized
DEBUG - 2023-04-25 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:26:46 --> Input Class Initialized
INFO - 2023-04-25 04:26:46 --> Language Class Initialized
INFO - 2023-04-25 04:26:46 --> Loader Class Initialized
INFO - 2023-04-25 04:26:46 --> Helper loaded: url_helper
INFO - 2023-04-25 04:26:46 --> Helper loaded: file_helper
INFO - 2023-04-25 04:26:46 --> Helper loaded: html_helper
INFO - 2023-04-25 04:26:46 --> Helper loaded: text_helper
INFO - 2023-04-25 04:26:46 --> Helper loaded: form_helper
INFO - 2023-04-25 04:26:46 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:26:46 --> Helper loaded: security_helper
INFO - 2023-04-25 04:26:46 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:26:46 --> Database Driver Class Initialized
INFO - 2023-04-25 04:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:26:46 --> Parser Class Initialized
INFO - 2023-04-25 04:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:26:46 --> Pagination Class Initialized
INFO - 2023-04-25 04:26:46 --> Form Validation Class Initialized
INFO - 2023-04-25 04:26:46 --> Controller Class Initialized
INFO - 2023-04-25 04:26:46 --> Model Class Initialized
INFO - 2023-04-25 04:26:46 --> Model Class Initialized
INFO - 2023-04-25 04:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-04-25 04:26:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:26:46 --> Model Class Initialized
INFO - 2023-04-25 04:26:46 --> Model Class Initialized
INFO - 2023-04-25 04:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:26:46 --> Final output sent to browser
DEBUG - 2023-04-25 04:26:46 --> Total execution time: 0.0567
ERROR - 2023-04-25 04:26:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:26:47 --> Config Class Initialized
INFO - 2023-04-25 04:26:47 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:26:47 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:26:47 --> Utf8 Class Initialized
INFO - 2023-04-25 04:26:47 --> URI Class Initialized
INFO - 2023-04-25 04:26:47 --> Router Class Initialized
INFO - 2023-04-25 04:26:47 --> Output Class Initialized
INFO - 2023-04-25 04:26:47 --> Security Class Initialized
DEBUG - 2023-04-25 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:26:47 --> Input Class Initialized
INFO - 2023-04-25 04:26:47 --> Language Class Initialized
INFO - 2023-04-25 04:26:47 --> Loader Class Initialized
INFO - 2023-04-25 04:26:47 --> Helper loaded: url_helper
INFO - 2023-04-25 04:26:47 --> Helper loaded: file_helper
INFO - 2023-04-25 04:26:47 --> Helper loaded: html_helper
INFO - 2023-04-25 04:26:47 --> Helper loaded: text_helper
INFO - 2023-04-25 04:26:47 --> Helper loaded: form_helper
INFO - 2023-04-25 04:26:47 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:26:47 --> Helper loaded: security_helper
INFO - 2023-04-25 04:26:47 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:26:47 --> Database Driver Class Initialized
INFO - 2023-04-25 04:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:26:47 --> Parser Class Initialized
INFO - 2023-04-25 04:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:26:47 --> Pagination Class Initialized
INFO - 2023-04-25 04:26:47 --> Form Validation Class Initialized
INFO - 2023-04-25 04:26:47 --> Controller Class Initialized
INFO - 2023-04-25 04:26:47 --> Model Class Initialized
INFO - 2023-04-25 04:26:47 --> Model Class Initialized
INFO - 2023-04-25 04:26:47 --> Final output sent to browser
DEBUG - 2023-04-25 04:26:47 --> Total execution time: 0.0202
ERROR - 2023-04-25 04:27:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:27:06 --> Config Class Initialized
INFO - 2023-04-25 04:27:06 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:27:06 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:27:06 --> Utf8 Class Initialized
INFO - 2023-04-25 04:27:06 --> URI Class Initialized
DEBUG - 2023-04-25 04:27:06 --> No URI present. Default controller set.
INFO - 2023-04-25 04:27:06 --> Router Class Initialized
INFO - 2023-04-25 04:27:06 --> Output Class Initialized
INFO - 2023-04-25 04:27:06 --> Security Class Initialized
DEBUG - 2023-04-25 04:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:27:06 --> Input Class Initialized
INFO - 2023-04-25 04:27:06 --> Language Class Initialized
INFO - 2023-04-25 04:27:06 --> Loader Class Initialized
INFO - 2023-04-25 04:27:06 --> Helper loaded: url_helper
INFO - 2023-04-25 04:27:06 --> Helper loaded: file_helper
INFO - 2023-04-25 04:27:06 --> Helper loaded: html_helper
INFO - 2023-04-25 04:27:06 --> Helper loaded: text_helper
INFO - 2023-04-25 04:27:06 --> Helper loaded: form_helper
INFO - 2023-04-25 04:27:06 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:27:06 --> Helper loaded: security_helper
INFO - 2023-04-25 04:27:06 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:27:06 --> Database Driver Class Initialized
INFO - 2023-04-25 04:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:27:06 --> Parser Class Initialized
INFO - 2023-04-25 04:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:27:06 --> Pagination Class Initialized
INFO - 2023-04-25 04:27:06 --> Form Validation Class Initialized
INFO - 2023-04-25 04:27:06 --> Controller Class Initialized
INFO - 2023-04-25 04:27:06 --> Model Class Initialized
DEBUG - 2023-04-25 04:27:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 04:27:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:27:08 --> Config Class Initialized
INFO - 2023-04-25 04:27:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:27:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:27:08 --> Utf8 Class Initialized
INFO - 2023-04-25 04:27:08 --> URI Class Initialized
INFO - 2023-04-25 04:27:08 --> Router Class Initialized
INFO - 2023-04-25 04:27:08 --> Output Class Initialized
INFO - 2023-04-25 04:27:08 --> Security Class Initialized
DEBUG - 2023-04-25 04:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:27:08 --> Input Class Initialized
INFO - 2023-04-25 04:27:08 --> Language Class Initialized
INFO - 2023-04-25 04:27:08 --> Loader Class Initialized
INFO - 2023-04-25 04:27:08 --> Helper loaded: url_helper
INFO - 2023-04-25 04:27:08 --> Helper loaded: file_helper
INFO - 2023-04-25 04:27:08 --> Helper loaded: html_helper
INFO - 2023-04-25 04:27:08 --> Helper loaded: text_helper
INFO - 2023-04-25 04:27:08 --> Helper loaded: form_helper
INFO - 2023-04-25 04:27:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:27:08 --> Helper loaded: security_helper
INFO - 2023-04-25 04:27:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:27:08 --> Database Driver Class Initialized
INFO - 2023-04-25 04:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:27:08 --> Parser Class Initialized
INFO - 2023-04-25 04:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:27:08 --> Pagination Class Initialized
INFO - 2023-04-25 04:27:08 --> Form Validation Class Initialized
INFO - 2023-04-25 04:27:08 --> Controller Class Initialized
INFO - 2023-04-25 04:27:08 --> Model Class Initialized
DEBUG - 2023-04-25 04:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 04:27:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:27:08 --> Model Class Initialized
INFO - 2023-04-25 04:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:27:08 --> Final output sent to browser
DEBUG - 2023-04-25 04:27:08 --> Total execution time: 0.0290
ERROR - 2023-04-25 04:28:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:28:18 --> Config Class Initialized
INFO - 2023-04-25 04:28:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:28:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:28:18 --> Utf8 Class Initialized
INFO - 2023-04-25 04:28:18 --> URI Class Initialized
INFO - 2023-04-25 04:28:18 --> Router Class Initialized
INFO - 2023-04-25 04:28:18 --> Output Class Initialized
INFO - 2023-04-25 04:28:18 --> Security Class Initialized
DEBUG - 2023-04-25 04:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:28:18 --> Input Class Initialized
INFO - 2023-04-25 04:28:18 --> Language Class Initialized
INFO - 2023-04-25 04:28:18 --> Loader Class Initialized
INFO - 2023-04-25 04:28:18 --> Helper loaded: url_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: file_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: html_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: text_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: form_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: security_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:28:18 --> Database Driver Class Initialized
INFO - 2023-04-25 04:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:28:18 --> Parser Class Initialized
INFO - 2023-04-25 04:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:28:18 --> Pagination Class Initialized
INFO - 2023-04-25 04:28:18 --> Form Validation Class Initialized
INFO - 2023-04-25 04:28:18 --> Controller Class Initialized
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
INFO - 2023-04-25 04:28:18 --> Final output sent to browser
DEBUG - 2023-04-25 04:28:18 --> Total execution time: 0.0160
ERROR - 2023-04-25 04:28:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:28:18 --> Config Class Initialized
INFO - 2023-04-25 04:28:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:28:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:28:18 --> Utf8 Class Initialized
INFO - 2023-04-25 04:28:18 --> URI Class Initialized
DEBUG - 2023-04-25 04:28:18 --> No URI present. Default controller set.
INFO - 2023-04-25 04:28:18 --> Router Class Initialized
INFO - 2023-04-25 04:28:18 --> Output Class Initialized
INFO - 2023-04-25 04:28:18 --> Security Class Initialized
DEBUG - 2023-04-25 04:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:28:18 --> Input Class Initialized
INFO - 2023-04-25 04:28:18 --> Language Class Initialized
INFO - 2023-04-25 04:28:18 --> Loader Class Initialized
INFO - 2023-04-25 04:28:18 --> Helper loaded: url_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: file_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: html_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: text_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: form_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: security_helper
INFO - 2023-04-25 04:28:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:28:18 --> Database Driver Class Initialized
INFO - 2023-04-25 04:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:28:18 --> Parser Class Initialized
INFO - 2023-04-25 04:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:28:18 --> Pagination Class Initialized
INFO - 2023-04-25 04:28:18 --> Form Validation Class Initialized
INFO - 2023-04-25 04:28:18 --> Controller Class Initialized
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
INFO - 2023-04-25 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 04:28:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:28:18 --> Model Class Initialized
INFO - 2023-04-25 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:28:18 --> Final output sent to browser
DEBUG - 2023-04-25 04:28:18 --> Total execution time: 0.0870
ERROR - 2023-04-25 04:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:28:26 --> Config Class Initialized
INFO - 2023-04-25 04:28:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:28:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:28:26 --> Utf8 Class Initialized
INFO - 2023-04-25 04:28:26 --> URI Class Initialized
INFO - 2023-04-25 04:28:26 --> Router Class Initialized
INFO - 2023-04-25 04:28:26 --> Output Class Initialized
INFO - 2023-04-25 04:28:26 --> Security Class Initialized
DEBUG - 2023-04-25 04:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:28:26 --> Input Class Initialized
INFO - 2023-04-25 04:28:26 --> Language Class Initialized
INFO - 2023-04-25 04:28:26 --> Loader Class Initialized
INFO - 2023-04-25 04:28:26 --> Helper loaded: url_helper
INFO - 2023-04-25 04:28:26 --> Helper loaded: file_helper
INFO - 2023-04-25 04:28:26 --> Helper loaded: html_helper
INFO - 2023-04-25 04:28:26 --> Helper loaded: text_helper
INFO - 2023-04-25 04:28:26 --> Helper loaded: form_helper
INFO - 2023-04-25 04:28:26 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:28:26 --> Helper loaded: security_helper
INFO - 2023-04-25 04:28:26 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:28:26 --> Database Driver Class Initialized
INFO - 2023-04-25 04:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:28:26 --> Parser Class Initialized
INFO - 2023-04-25 04:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:28:26 --> Pagination Class Initialized
INFO - 2023-04-25 04:28:26 --> Form Validation Class Initialized
INFO - 2023-04-25 04:28:26 --> Controller Class Initialized
INFO - 2023-04-25 04:28:26 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:26 --> Model Class Initialized
INFO - 2023-04-25 04:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-25 04:28:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:28:27 --> Model Class Initialized
INFO - 2023-04-25 04:28:27 --> Model Class Initialized
INFO - 2023-04-25 04:28:27 --> Model Class Initialized
INFO - 2023-04-25 04:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:28:27 --> Final output sent to browser
DEBUG - 2023-04-25 04:28:27 --> Total execution time: 0.0648
ERROR - 2023-04-25 04:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:28:27 --> Config Class Initialized
INFO - 2023-04-25 04:28:27 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:28:27 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:28:27 --> Utf8 Class Initialized
INFO - 2023-04-25 04:28:27 --> URI Class Initialized
INFO - 2023-04-25 04:28:27 --> Router Class Initialized
INFO - 2023-04-25 04:28:27 --> Output Class Initialized
INFO - 2023-04-25 04:28:27 --> Security Class Initialized
DEBUG - 2023-04-25 04:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:28:27 --> Input Class Initialized
INFO - 2023-04-25 04:28:27 --> Language Class Initialized
INFO - 2023-04-25 04:28:27 --> Loader Class Initialized
INFO - 2023-04-25 04:28:27 --> Helper loaded: url_helper
INFO - 2023-04-25 04:28:27 --> Helper loaded: file_helper
INFO - 2023-04-25 04:28:27 --> Helper loaded: html_helper
INFO - 2023-04-25 04:28:27 --> Helper loaded: text_helper
INFO - 2023-04-25 04:28:27 --> Helper loaded: form_helper
INFO - 2023-04-25 04:28:27 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:28:27 --> Helper loaded: security_helper
INFO - 2023-04-25 04:28:27 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:28:27 --> Database Driver Class Initialized
INFO - 2023-04-25 04:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:28:27 --> Parser Class Initialized
INFO - 2023-04-25 04:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:28:27 --> Pagination Class Initialized
INFO - 2023-04-25 04:28:27 --> Form Validation Class Initialized
INFO - 2023-04-25 04:28:27 --> Controller Class Initialized
INFO - 2023-04-25 04:28:27 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:27 --> Model Class Initialized
INFO - 2023-04-25 04:28:27 --> Final output sent to browser
DEBUG - 2023-04-25 04:28:27 --> Total execution time: 0.0207
ERROR - 2023-04-25 04:28:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:28:35 --> Config Class Initialized
INFO - 2023-04-25 04:28:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:28:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:28:35 --> Utf8 Class Initialized
INFO - 2023-04-25 04:28:35 --> URI Class Initialized
INFO - 2023-04-25 04:28:35 --> Router Class Initialized
INFO - 2023-04-25 04:28:35 --> Output Class Initialized
INFO - 2023-04-25 04:28:35 --> Security Class Initialized
DEBUG - 2023-04-25 04:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:28:35 --> Input Class Initialized
INFO - 2023-04-25 04:28:35 --> Language Class Initialized
INFO - 2023-04-25 04:28:35 --> Loader Class Initialized
INFO - 2023-04-25 04:28:35 --> Helper loaded: url_helper
INFO - 2023-04-25 04:28:35 --> Helper loaded: file_helper
INFO - 2023-04-25 04:28:35 --> Helper loaded: html_helper
INFO - 2023-04-25 04:28:35 --> Helper loaded: text_helper
INFO - 2023-04-25 04:28:35 --> Helper loaded: form_helper
INFO - 2023-04-25 04:28:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:28:35 --> Helper loaded: security_helper
INFO - 2023-04-25 04:28:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:28:35 --> Database Driver Class Initialized
INFO - 2023-04-25 04:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:28:35 --> Parser Class Initialized
INFO - 2023-04-25 04:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:28:35 --> Pagination Class Initialized
INFO - 2023-04-25 04:28:35 --> Form Validation Class Initialized
INFO - 2023-04-25 04:28:35 --> Controller Class Initialized
INFO - 2023-04-25 04:28:35 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:35 --> Model Class Initialized
DEBUG - 2023-04-25 04:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-25 04:28:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:28:35 --> Model Class Initialized
INFO - 2023-04-25 04:28:35 --> Model Class Initialized
INFO - 2023-04-25 04:28:35 --> Model Class Initialized
INFO - 2023-04-25 04:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:28:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:28:35 --> Final output sent to browser
DEBUG - 2023-04-25 04:28:35 --> Total execution time: 0.0678
ERROR - 2023-04-25 04:38:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:38:20 --> Config Class Initialized
INFO - 2023-04-25 04:38:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:38:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:38:20 --> Utf8 Class Initialized
INFO - 2023-04-25 04:38:20 --> URI Class Initialized
INFO - 2023-04-25 04:38:20 --> Router Class Initialized
INFO - 2023-04-25 04:38:20 --> Output Class Initialized
INFO - 2023-04-25 04:38:20 --> Security Class Initialized
DEBUG - 2023-04-25 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:38:20 --> Input Class Initialized
INFO - 2023-04-25 04:38:20 --> Language Class Initialized
INFO - 2023-04-25 04:38:20 --> Loader Class Initialized
INFO - 2023-04-25 04:38:20 --> Helper loaded: url_helper
INFO - 2023-04-25 04:38:20 --> Helper loaded: file_helper
INFO - 2023-04-25 04:38:20 --> Helper loaded: html_helper
INFO - 2023-04-25 04:38:20 --> Helper loaded: text_helper
INFO - 2023-04-25 04:38:20 --> Helper loaded: form_helper
INFO - 2023-04-25 04:38:20 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:38:20 --> Helper loaded: security_helper
INFO - 2023-04-25 04:38:20 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:38:20 --> Database Driver Class Initialized
INFO - 2023-04-25 04:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:38:20 --> Parser Class Initialized
INFO - 2023-04-25 04:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:38:20 --> Pagination Class Initialized
INFO - 2023-04-25 04:38:20 --> Form Validation Class Initialized
INFO - 2023-04-25 04:38:20 --> Controller Class Initialized
INFO - 2023-04-25 04:38:20 --> Model Class Initialized
DEBUG - 2023-04-25 04:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 04:38:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:38:20 --> Model Class Initialized
INFO - 2023-04-25 04:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:38:20 --> Final output sent to browser
DEBUG - 2023-04-25 04:38:20 --> Total execution time: 0.0307
ERROR - 2023-04-25 04:38:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 04:38:21 --> Config Class Initialized
INFO - 2023-04-25 04:38:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 04:38:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 04:38:21 --> Utf8 Class Initialized
INFO - 2023-04-25 04:38:21 --> URI Class Initialized
INFO - 2023-04-25 04:38:21 --> Router Class Initialized
INFO - 2023-04-25 04:38:21 --> Output Class Initialized
INFO - 2023-04-25 04:38:21 --> Security Class Initialized
DEBUG - 2023-04-25 04:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 04:38:21 --> Input Class Initialized
INFO - 2023-04-25 04:38:21 --> Language Class Initialized
INFO - 2023-04-25 04:38:21 --> Loader Class Initialized
INFO - 2023-04-25 04:38:21 --> Helper loaded: url_helper
INFO - 2023-04-25 04:38:21 --> Helper loaded: file_helper
INFO - 2023-04-25 04:38:21 --> Helper loaded: html_helper
INFO - 2023-04-25 04:38:21 --> Helper loaded: text_helper
INFO - 2023-04-25 04:38:21 --> Helper loaded: form_helper
INFO - 2023-04-25 04:38:21 --> Helper loaded: lang_helper
INFO - 2023-04-25 04:38:21 --> Helper loaded: security_helper
INFO - 2023-04-25 04:38:21 --> Helper loaded: cookie_helper
INFO - 2023-04-25 04:38:21 --> Database Driver Class Initialized
INFO - 2023-04-25 04:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 04:38:21 --> Parser Class Initialized
INFO - 2023-04-25 04:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 04:38:21 --> Pagination Class Initialized
INFO - 2023-04-25 04:38:21 --> Form Validation Class Initialized
INFO - 2023-04-25 04:38:21 --> Controller Class Initialized
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
DEBUG - 2023-04-25 04:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
DEBUG - 2023-04-25 04:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
DEBUG - 2023-04-25 04:38:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 04:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
INFO - 2023-04-25 04:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 04:38:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 04:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 04:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 04:38:21 --> Model Class Initialized
INFO - 2023-04-25 04:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 04:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 04:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 04:38:21 --> Final output sent to browser
DEBUG - 2023-04-25 04:38:21 --> Total execution time: 0.0712
ERROR - 2023-04-25 05:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:01 --> Config Class Initialized
INFO - 2023-04-25 05:11:01 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:01 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:01 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:01 --> URI Class Initialized
DEBUG - 2023-04-25 05:11:01 --> No URI present. Default controller set.
INFO - 2023-04-25 05:11:01 --> Router Class Initialized
INFO - 2023-04-25 05:11:01 --> Output Class Initialized
INFO - 2023-04-25 05:11:01 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:01 --> Input Class Initialized
INFO - 2023-04-25 05:11:01 --> Language Class Initialized
INFO - 2023-04-25 05:11:01 --> Loader Class Initialized
INFO - 2023-04-25 05:11:01 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:01 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:01 --> Parser Class Initialized
INFO - 2023-04-25 05:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:01 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:01 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:01 --> Controller Class Initialized
INFO - 2023-04-25 05:11:01 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 05:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:01 --> Config Class Initialized
INFO - 2023-04-25 05:11:01 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:01 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:01 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:01 --> URI Class Initialized
INFO - 2023-04-25 05:11:01 --> Router Class Initialized
INFO - 2023-04-25 05:11:01 --> Output Class Initialized
INFO - 2023-04-25 05:11:01 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:01 --> Input Class Initialized
INFO - 2023-04-25 05:11:01 --> Language Class Initialized
INFO - 2023-04-25 05:11:01 --> Loader Class Initialized
INFO - 2023-04-25 05:11:01 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:01 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:01 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:01 --> Parser Class Initialized
INFO - 2023-04-25 05:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:01 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:01 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:01 --> Controller Class Initialized
INFO - 2023-04-25 05:11:01 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 05:11:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:11:01 --> Model Class Initialized
INFO - 2023-04-25 05:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:11:01 --> Final output sent to browser
DEBUG - 2023-04-25 05:11:01 --> Total execution time: 0.0302
ERROR - 2023-04-25 05:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:34 --> Config Class Initialized
INFO - 2023-04-25 05:11:34 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:34 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:34 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:34 --> URI Class Initialized
INFO - 2023-04-25 05:11:34 --> Router Class Initialized
INFO - 2023-04-25 05:11:34 --> Output Class Initialized
INFO - 2023-04-25 05:11:34 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:34 --> Input Class Initialized
INFO - 2023-04-25 05:11:34 --> Language Class Initialized
INFO - 2023-04-25 05:11:34 --> Loader Class Initialized
INFO - 2023-04-25 05:11:34 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:34 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:34 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:34 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:34 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:34 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:34 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:34 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:34 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:34 --> Parser Class Initialized
INFO - 2023-04-25 05:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:34 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:34 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:34 --> Controller Class Initialized
INFO - 2023-04-25 05:11:34 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:34 --> Model Class Initialized
INFO - 2023-04-25 05:11:34 --> Final output sent to browser
DEBUG - 2023-04-25 05:11:34 --> Total execution time: 0.0204
ERROR - 2023-04-25 05:11:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:35 --> Config Class Initialized
INFO - 2023-04-25 05:11:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:35 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:35 --> URI Class Initialized
DEBUG - 2023-04-25 05:11:35 --> No URI present. Default controller set.
INFO - 2023-04-25 05:11:35 --> Router Class Initialized
INFO - 2023-04-25 05:11:35 --> Output Class Initialized
INFO - 2023-04-25 05:11:35 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:35 --> Input Class Initialized
INFO - 2023-04-25 05:11:35 --> Language Class Initialized
INFO - 2023-04-25 05:11:35 --> Loader Class Initialized
INFO - 2023-04-25 05:11:35 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:35 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:35 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:35 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:35 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:35 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:35 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:35 --> Parser Class Initialized
INFO - 2023-04-25 05:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:35 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:35 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:35 --> Controller Class Initialized
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
INFO - 2023-04-25 05:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:11:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:11:35 --> Model Class Initialized
INFO - 2023-04-25 05:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:11:35 --> Final output sent to browser
DEBUG - 2023-04-25 05:11:35 --> Total execution time: 0.1831
ERROR - 2023-04-25 05:11:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:36 --> Config Class Initialized
INFO - 2023-04-25 05:11:36 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:36 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:36 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:36 --> URI Class Initialized
INFO - 2023-04-25 05:11:36 --> Router Class Initialized
INFO - 2023-04-25 05:11:36 --> Output Class Initialized
INFO - 2023-04-25 05:11:36 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:36 --> Input Class Initialized
INFO - 2023-04-25 05:11:36 --> Language Class Initialized
INFO - 2023-04-25 05:11:36 --> Loader Class Initialized
INFO - 2023-04-25 05:11:36 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:36 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:36 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:36 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:36 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:36 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:36 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:36 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:36 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:36 --> Parser Class Initialized
INFO - 2023-04-25 05:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:36 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:36 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:36 --> Controller Class Initialized
DEBUG - 2023-04-25 05:11:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:36 --> Model Class Initialized
INFO - 2023-04-25 05:11:36 --> Final output sent to browser
DEBUG - 2023-04-25 05:11:36 --> Total execution time: 0.0133
ERROR - 2023-04-25 05:11:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:45 --> Config Class Initialized
INFO - 2023-04-25 05:11:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:45 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:45 --> URI Class Initialized
INFO - 2023-04-25 05:11:45 --> Router Class Initialized
INFO - 2023-04-25 05:11:45 --> Output Class Initialized
INFO - 2023-04-25 05:11:45 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:45 --> Input Class Initialized
INFO - 2023-04-25 05:11:45 --> Language Class Initialized
INFO - 2023-04-25 05:11:45 --> Loader Class Initialized
INFO - 2023-04-25 05:11:45 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:45 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:45 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:45 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:45 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:45 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:45 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:45 --> Parser Class Initialized
INFO - 2023-04-25 05:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:45 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:45 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:45 --> Controller Class Initialized
DEBUG - 2023-04-25 05:11:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:45 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:45 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:45 --> Model Class Initialized
INFO - 2023-04-25 05:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-25 05:11:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:11:45 --> Model Class Initialized
INFO - 2023-04-25 05:11:45 --> Model Class Initialized
INFO - 2023-04-25 05:11:45 --> Model Class Initialized
INFO - 2023-04-25 05:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:11:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:11:45 --> Final output sent to browser
DEBUG - 2023-04-25 05:11:45 --> Total execution time: 0.1546
ERROR - 2023-04-25 05:11:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:46 --> Config Class Initialized
INFO - 2023-04-25 05:11:46 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:46 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:46 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:46 --> URI Class Initialized
INFO - 2023-04-25 05:11:46 --> Router Class Initialized
INFO - 2023-04-25 05:11:46 --> Output Class Initialized
INFO - 2023-04-25 05:11:46 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:46 --> Input Class Initialized
INFO - 2023-04-25 05:11:46 --> Language Class Initialized
INFO - 2023-04-25 05:11:46 --> Loader Class Initialized
INFO - 2023-04-25 05:11:46 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:46 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:46 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:46 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:46 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:46 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:46 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:46 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:46 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:46 --> Parser Class Initialized
INFO - 2023-04-25 05:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:46 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:46 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:46 --> Controller Class Initialized
DEBUG - 2023-04-25 05:11:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:46 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:46 --> Model Class Initialized
INFO - 2023-04-25 05:11:46 --> Final output sent to browser
DEBUG - 2023-04-25 05:11:46 --> Total execution time: 0.0301
ERROR - 2023-04-25 05:11:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:11:53 --> Config Class Initialized
INFO - 2023-04-25 05:11:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:11:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:11:53 --> Utf8 Class Initialized
INFO - 2023-04-25 05:11:53 --> URI Class Initialized
DEBUG - 2023-04-25 05:11:53 --> No URI present. Default controller set.
INFO - 2023-04-25 05:11:53 --> Router Class Initialized
INFO - 2023-04-25 05:11:53 --> Output Class Initialized
INFO - 2023-04-25 05:11:53 --> Security Class Initialized
DEBUG - 2023-04-25 05:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:11:53 --> Input Class Initialized
INFO - 2023-04-25 05:11:53 --> Language Class Initialized
INFO - 2023-04-25 05:11:53 --> Loader Class Initialized
INFO - 2023-04-25 05:11:53 --> Helper loaded: url_helper
INFO - 2023-04-25 05:11:53 --> Helper loaded: file_helper
INFO - 2023-04-25 05:11:53 --> Helper loaded: html_helper
INFO - 2023-04-25 05:11:53 --> Helper loaded: text_helper
INFO - 2023-04-25 05:11:53 --> Helper loaded: form_helper
INFO - 2023-04-25 05:11:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:11:53 --> Helper loaded: security_helper
INFO - 2023-04-25 05:11:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:11:53 --> Database Driver Class Initialized
INFO - 2023-04-25 05:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:11:53 --> Parser Class Initialized
INFO - 2023-04-25 05:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:11:53 --> Pagination Class Initialized
INFO - 2023-04-25 05:11:53 --> Form Validation Class Initialized
INFO - 2023-04-25 05:11:53 --> Controller Class Initialized
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
DEBUG - 2023-04-25 05:11:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
INFO - 2023-04-25 05:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:11:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:11:53 --> Model Class Initialized
INFO - 2023-04-25 05:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:11:53 --> Final output sent to browser
DEBUG - 2023-04-25 05:11:53 --> Total execution time: 0.1762
ERROR - 2023-04-25 05:12:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:12:56 --> Config Class Initialized
INFO - 2023-04-25 05:12:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:12:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:12:56 --> Utf8 Class Initialized
INFO - 2023-04-25 05:12:56 --> URI Class Initialized
INFO - 2023-04-25 05:12:56 --> Router Class Initialized
INFO - 2023-04-25 05:12:56 --> Output Class Initialized
INFO - 2023-04-25 05:12:56 --> Security Class Initialized
DEBUG - 2023-04-25 05:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:12:56 --> Input Class Initialized
INFO - 2023-04-25 05:12:56 --> Language Class Initialized
INFO - 2023-04-25 05:12:56 --> Loader Class Initialized
INFO - 2023-04-25 05:12:56 --> Helper loaded: url_helper
INFO - 2023-04-25 05:12:56 --> Helper loaded: file_helper
INFO - 2023-04-25 05:12:56 --> Helper loaded: html_helper
INFO - 2023-04-25 05:12:56 --> Helper loaded: text_helper
INFO - 2023-04-25 05:12:56 --> Helper loaded: form_helper
INFO - 2023-04-25 05:12:56 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:12:56 --> Helper loaded: security_helper
INFO - 2023-04-25 05:12:56 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:12:56 --> Database Driver Class Initialized
INFO - 2023-04-25 05:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:12:56 --> Parser Class Initialized
INFO - 2023-04-25 05:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:12:56 --> Pagination Class Initialized
INFO - 2023-04-25 05:12:56 --> Form Validation Class Initialized
INFO - 2023-04-25 05:12:56 --> Controller Class Initialized
DEBUG - 2023-04-25 05:12:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:12:56 --> Model Class Initialized
DEBUG - 2023-04-25 05:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:12:56 --> Model Class Initialized
DEBUG - 2023-04-25 05:12:56 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:12:56 --> Model Class Initialized
INFO - 2023-04-25 05:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-25 05:12:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:12:56 --> Model Class Initialized
INFO - 2023-04-25 05:12:56 --> Model Class Initialized
INFO - 2023-04-25 05:12:56 --> Model Class Initialized
INFO - 2023-04-25 05:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:12:56 --> Final output sent to browser
DEBUG - 2023-04-25 05:12:56 --> Total execution time: 0.1334
ERROR - 2023-04-25 05:12:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:12:57 --> Config Class Initialized
INFO - 2023-04-25 05:12:57 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:12:57 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:12:57 --> Utf8 Class Initialized
INFO - 2023-04-25 05:12:57 --> URI Class Initialized
INFO - 2023-04-25 05:12:57 --> Router Class Initialized
INFO - 2023-04-25 05:12:57 --> Output Class Initialized
INFO - 2023-04-25 05:12:57 --> Security Class Initialized
DEBUG - 2023-04-25 05:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:12:57 --> Input Class Initialized
INFO - 2023-04-25 05:12:57 --> Language Class Initialized
INFO - 2023-04-25 05:12:57 --> Loader Class Initialized
INFO - 2023-04-25 05:12:57 --> Helper loaded: url_helper
INFO - 2023-04-25 05:12:57 --> Helper loaded: file_helper
INFO - 2023-04-25 05:12:57 --> Helper loaded: html_helper
INFO - 2023-04-25 05:12:57 --> Helper loaded: text_helper
INFO - 2023-04-25 05:12:57 --> Helper loaded: form_helper
INFO - 2023-04-25 05:12:57 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:12:57 --> Helper loaded: security_helper
INFO - 2023-04-25 05:12:57 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:12:57 --> Database Driver Class Initialized
INFO - 2023-04-25 05:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:12:57 --> Parser Class Initialized
INFO - 2023-04-25 05:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:12:57 --> Pagination Class Initialized
INFO - 2023-04-25 05:12:57 --> Form Validation Class Initialized
INFO - 2023-04-25 05:12:57 --> Controller Class Initialized
DEBUG - 2023-04-25 05:12:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:12:57 --> Model Class Initialized
DEBUG - 2023-04-25 05:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:12:57 --> Model Class Initialized
INFO - 2023-04-25 05:12:57 --> Final output sent to browser
DEBUG - 2023-04-25 05:12:57 --> Total execution time: 0.0333
ERROR - 2023-04-25 05:13:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:13:00 --> Config Class Initialized
INFO - 2023-04-25 05:13:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:13:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:13:00 --> Utf8 Class Initialized
INFO - 2023-04-25 05:13:00 --> URI Class Initialized
DEBUG - 2023-04-25 05:13:00 --> No URI present. Default controller set.
INFO - 2023-04-25 05:13:00 --> Router Class Initialized
INFO - 2023-04-25 05:13:00 --> Output Class Initialized
INFO - 2023-04-25 05:13:00 --> Security Class Initialized
DEBUG - 2023-04-25 05:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:13:00 --> Input Class Initialized
INFO - 2023-04-25 05:13:00 --> Language Class Initialized
INFO - 2023-04-25 05:13:00 --> Loader Class Initialized
INFO - 2023-04-25 05:13:00 --> Helper loaded: url_helper
INFO - 2023-04-25 05:13:00 --> Helper loaded: file_helper
INFO - 2023-04-25 05:13:00 --> Helper loaded: html_helper
INFO - 2023-04-25 05:13:00 --> Helper loaded: text_helper
INFO - 2023-04-25 05:13:00 --> Helper loaded: form_helper
INFO - 2023-04-25 05:13:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:13:00 --> Helper loaded: security_helper
INFO - 2023-04-25 05:13:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:13:00 --> Database Driver Class Initialized
INFO - 2023-04-25 05:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:13:00 --> Parser Class Initialized
INFO - 2023-04-25 05:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:13:00 --> Pagination Class Initialized
INFO - 2023-04-25 05:13:00 --> Form Validation Class Initialized
INFO - 2023-04-25 05:13:00 --> Controller Class Initialized
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
DEBUG - 2023-04-25 05:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
DEBUG - 2023-04-25 05:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
DEBUG - 2023-04-25 05:13:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
INFO - 2023-04-25 05:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:13:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:13:00 --> Model Class Initialized
INFO - 2023-04-25 05:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:13:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:13:00 --> Final output sent to browser
DEBUG - 2023-04-25 05:13:00 --> Total execution time: 0.1612
ERROR - 2023-04-25 05:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:13:39 --> Config Class Initialized
INFO - 2023-04-25 05:13:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:13:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:13:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:13:39 --> URI Class Initialized
INFO - 2023-04-25 05:13:39 --> Router Class Initialized
INFO - 2023-04-25 05:13:39 --> Output Class Initialized
INFO - 2023-04-25 05:13:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:13:39 --> Input Class Initialized
INFO - 2023-04-25 05:13:39 --> Language Class Initialized
INFO - 2023-04-25 05:13:39 --> Loader Class Initialized
INFO - 2023-04-25 05:13:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:13:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:13:39 --> Parser Class Initialized
INFO - 2023-04-25 05:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:13:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:13:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:13:39 --> Controller Class Initialized
DEBUG - 2023-04-25 05:13:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:13:39 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
INFO - 2023-04-25 05:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-25 05:13:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
INFO - 2023-04-25 05:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:13:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:13:39 --> Final output sent to browser
DEBUG - 2023-04-25 05:13:39 --> Total execution time: 0.1282
ERROR - 2023-04-25 05:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:13:39 --> Config Class Initialized
INFO - 2023-04-25 05:13:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:13:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:13:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:13:39 --> URI Class Initialized
INFO - 2023-04-25 05:13:39 --> Router Class Initialized
INFO - 2023-04-25 05:13:39 --> Output Class Initialized
INFO - 2023-04-25 05:13:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:13:39 --> Input Class Initialized
INFO - 2023-04-25 05:13:39 --> Language Class Initialized
INFO - 2023-04-25 05:13:39 --> Loader Class Initialized
INFO - 2023-04-25 05:13:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:13:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:13:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:13:39 --> Parser Class Initialized
INFO - 2023-04-25 05:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:13:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:13:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:13:39 --> Controller Class Initialized
DEBUG - 2023-04-25 05:13:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:39 --> Model Class Initialized
INFO - 2023-04-25 05:13:39 --> Final output sent to browser
DEBUG - 2023-04-25 05:13:39 --> Total execution time: 0.0285
ERROR - 2023-04-25 05:13:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:13:46 --> Config Class Initialized
INFO - 2023-04-25 05:13:46 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:13:46 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:13:46 --> Utf8 Class Initialized
INFO - 2023-04-25 05:13:46 --> URI Class Initialized
INFO - 2023-04-25 05:13:46 --> Router Class Initialized
INFO - 2023-04-25 05:13:46 --> Output Class Initialized
INFO - 2023-04-25 05:13:46 --> Security Class Initialized
DEBUG - 2023-04-25 05:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:13:46 --> Input Class Initialized
INFO - 2023-04-25 05:13:46 --> Language Class Initialized
INFO - 2023-04-25 05:13:46 --> Loader Class Initialized
INFO - 2023-04-25 05:13:46 --> Helper loaded: url_helper
INFO - 2023-04-25 05:13:46 --> Helper loaded: file_helper
INFO - 2023-04-25 05:13:46 --> Helper loaded: html_helper
INFO - 2023-04-25 05:13:46 --> Helper loaded: text_helper
INFO - 2023-04-25 05:13:46 --> Helper loaded: form_helper
INFO - 2023-04-25 05:13:46 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:13:46 --> Helper loaded: security_helper
INFO - 2023-04-25 05:13:46 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:13:46 --> Database Driver Class Initialized
INFO - 2023-04-25 05:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:13:46 --> Parser Class Initialized
INFO - 2023-04-25 05:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:13:46 --> Pagination Class Initialized
INFO - 2023-04-25 05:13:46 --> Form Validation Class Initialized
INFO - 2023-04-25 05:13:46 --> Controller Class Initialized
DEBUG - 2023-04-25 05:13:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:46 --> Model Class Initialized
DEBUG - 2023-04-25 05:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:13:46 --> Model Class Initialized
INFO - 2023-04-25 05:13:46 --> Final output sent to browser
DEBUG - 2023-04-25 05:13:46 --> Total execution time: 0.0718
ERROR - 2023-04-25 05:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:14:08 --> Config Class Initialized
INFO - 2023-04-25 05:14:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:14:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:14:08 --> Utf8 Class Initialized
INFO - 2023-04-25 05:14:08 --> URI Class Initialized
INFO - 2023-04-25 05:14:08 --> Router Class Initialized
INFO - 2023-04-25 05:14:08 --> Output Class Initialized
INFO - 2023-04-25 05:14:08 --> Security Class Initialized
DEBUG - 2023-04-25 05:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:14:08 --> Input Class Initialized
INFO - 2023-04-25 05:14:08 --> Language Class Initialized
INFO - 2023-04-25 05:14:08 --> Loader Class Initialized
INFO - 2023-04-25 05:14:08 --> Helper loaded: url_helper
INFO - 2023-04-25 05:14:08 --> Helper loaded: file_helper
INFO - 2023-04-25 05:14:08 --> Helper loaded: html_helper
INFO - 2023-04-25 05:14:08 --> Helper loaded: text_helper
INFO - 2023-04-25 05:14:08 --> Helper loaded: form_helper
INFO - 2023-04-25 05:14:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:14:08 --> Helper loaded: security_helper
INFO - 2023-04-25 05:14:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:14:08 --> Database Driver Class Initialized
INFO - 2023-04-25 05:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:14:08 --> Parser Class Initialized
INFO - 2023-04-25 05:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:14:08 --> Pagination Class Initialized
INFO - 2023-04-25 05:14:08 --> Form Validation Class Initialized
INFO - 2023-04-25 05:14:08 --> Controller Class Initialized
INFO - 2023-04-25 05:14:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:14:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:14:08 --> Model Class Initialized
INFO - 2023-04-25 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-25 05:14:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:14:08 --> Model Class Initialized
INFO - 2023-04-25 05:14:08 --> Model Class Initialized
INFO - 2023-04-25 05:14:08 --> Model Class Initialized
INFO - 2023-04-25 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:14:08 --> Final output sent to browser
DEBUG - 2023-04-25 05:14:08 --> Total execution time: 0.1238
ERROR - 2023-04-25 05:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:14:08 --> Config Class Initialized
INFO - 2023-04-25 05:14:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:14:09 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:14:09 --> Utf8 Class Initialized
INFO - 2023-04-25 05:14:09 --> URI Class Initialized
INFO - 2023-04-25 05:14:09 --> Router Class Initialized
INFO - 2023-04-25 05:14:09 --> Output Class Initialized
INFO - 2023-04-25 05:14:09 --> Security Class Initialized
DEBUG - 2023-04-25 05:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:14:09 --> Input Class Initialized
INFO - 2023-04-25 05:14:09 --> Language Class Initialized
INFO - 2023-04-25 05:14:09 --> Loader Class Initialized
INFO - 2023-04-25 05:14:09 --> Helper loaded: url_helper
INFO - 2023-04-25 05:14:09 --> Helper loaded: file_helper
INFO - 2023-04-25 05:14:09 --> Helper loaded: html_helper
INFO - 2023-04-25 05:14:09 --> Helper loaded: text_helper
INFO - 2023-04-25 05:14:09 --> Helper loaded: form_helper
INFO - 2023-04-25 05:14:09 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:14:09 --> Helper loaded: security_helper
INFO - 2023-04-25 05:14:09 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:14:09 --> Database Driver Class Initialized
INFO - 2023-04-25 05:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:14:09 --> Parser Class Initialized
INFO - 2023-04-25 05:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:14:09 --> Pagination Class Initialized
INFO - 2023-04-25 05:14:09 --> Form Validation Class Initialized
INFO - 2023-04-25 05:14:09 --> Controller Class Initialized
INFO - 2023-04-25 05:14:09 --> Model Class Initialized
DEBUG - 2023-04-25 05:14:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:14:09 --> Model Class Initialized
INFO - 2023-04-25 05:14:09 --> Final output sent to browser
DEBUG - 2023-04-25 05:14:09 --> Total execution time: 0.0242
ERROR - 2023-04-25 05:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:22:39 --> Config Class Initialized
INFO - 2023-04-25 05:22:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:22:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:22:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:22:39 --> URI Class Initialized
DEBUG - 2023-04-25 05:22:39 --> No URI present. Default controller set.
INFO - 2023-04-25 05:22:39 --> Router Class Initialized
INFO - 2023-04-25 05:22:39 --> Output Class Initialized
INFO - 2023-04-25 05:22:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:22:39 --> Input Class Initialized
INFO - 2023-04-25 05:22:39 --> Language Class Initialized
INFO - 2023-04-25 05:22:39 --> Loader Class Initialized
INFO - 2023-04-25 05:22:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:22:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:22:39 --> Parser Class Initialized
INFO - 2023-04-25 05:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:22:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:22:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:22:39 --> Controller Class Initialized
INFO - 2023-04-25 05:22:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:22:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 05:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:22:39 --> Config Class Initialized
INFO - 2023-04-25 05:22:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:22:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:22:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:22:39 --> URI Class Initialized
INFO - 2023-04-25 05:22:39 --> Router Class Initialized
INFO - 2023-04-25 05:22:39 --> Output Class Initialized
INFO - 2023-04-25 05:22:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:22:39 --> Input Class Initialized
INFO - 2023-04-25 05:22:39 --> Language Class Initialized
INFO - 2023-04-25 05:22:39 --> Loader Class Initialized
INFO - 2023-04-25 05:22:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:22:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:22:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:22:39 --> Parser Class Initialized
INFO - 2023-04-25 05:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:22:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:22:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:22:39 --> Controller Class Initialized
INFO - 2023-04-25 05:22:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 05:22:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:22:39 --> Model Class Initialized
INFO - 2023-04-25 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:22:39 --> Final output sent to browser
DEBUG - 2023-04-25 05:22:39 --> Total execution time: 0.0327
ERROR - 2023-04-25 05:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:23:08 --> Config Class Initialized
INFO - 2023-04-25 05:23:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:23:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:23:08 --> Utf8 Class Initialized
INFO - 2023-04-25 05:23:08 --> URI Class Initialized
INFO - 2023-04-25 05:23:08 --> Router Class Initialized
INFO - 2023-04-25 05:23:08 --> Output Class Initialized
INFO - 2023-04-25 05:23:08 --> Security Class Initialized
DEBUG - 2023-04-25 05:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:23:08 --> Input Class Initialized
INFO - 2023-04-25 05:23:08 --> Language Class Initialized
INFO - 2023-04-25 05:23:08 --> Loader Class Initialized
INFO - 2023-04-25 05:23:08 --> Helper loaded: url_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: file_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: html_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: text_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: form_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: security_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:23:08 --> Database Driver Class Initialized
INFO - 2023-04-25 05:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:23:08 --> Parser Class Initialized
INFO - 2023-04-25 05:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:23:08 --> Pagination Class Initialized
INFO - 2023-04-25 05:23:08 --> Form Validation Class Initialized
INFO - 2023-04-25 05:23:08 --> Controller Class Initialized
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
INFO - 2023-04-25 05:23:08 --> Final output sent to browser
DEBUG - 2023-04-25 05:23:08 --> Total execution time: 0.0209
ERROR - 2023-04-25 05:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:23:08 --> Config Class Initialized
INFO - 2023-04-25 05:23:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:23:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:23:08 --> Utf8 Class Initialized
INFO - 2023-04-25 05:23:08 --> URI Class Initialized
DEBUG - 2023-04-25 05:23:08 --> No URI present. Default controller set.
INFO - 2023-04-25 05:23:08 --> Router Class Initialized
INFO - 2023-04-25 05:23:08 --> Output Class Initialized
INFO - 2023-04-25 05:23:08 --> Security Class Initialized
DEBUG - 2023-04-25 05:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:23:08 --> Input Class Initialized
INFO - 2023-04-25 05:23:08 --> Language Class Initialized
INFO - 2023-04-25 05:23:08 --> Loader Class Initialized
INFO - 2023-04-25 05:23:08 --> Helper loaded: url_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: file_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: html_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: text_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: form_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: security_helper
INFO - 2023-04-25 05:23:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:23:08 --> Database Driver Class Initialized
INFO - 2023-04-25 05:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:23:08 --> Parser Class Initialized
INFO - 2023-04-25 05:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:23:08 --> Pagination Class Initialized
INFO - 2023-04-25 05:23:08 --> Form Validation Class Initialized
INFO - 2023-04-25 05:23:08 --> Controller Class Initialized
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:23:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
INFO - 2023-04-25 05:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:23:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:23:08 --> Model Class Initialized
INFO - 2023-04-25 05:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:23:08 --> Final output sent to browser
DEBUG - 2023-04-25 05:23:08 --> Total execution time: 0.0856
ERROR - 2023-04-25 05:23:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:23:38 --> Config Class Initialized
INFO - 2023-04-25 05:23:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:23:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:23:38 --> Utf8 Class Initialized
INFO - 2023-04-25 05:23:38 --> URI Class Initialized
INFO - 2023-04-25 05:23:38 --> Router Class Initialized
INFO - 2023-04-25 05:23:38 --> Output Class Initialized
INFO - 2023-04-25 05:23:38 --> Security Class Initialized
DEBUG - 2023-04-25 05:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:23:38 --> Input Class Initialized
INFO - 2023-04-25 05:23:38 --> Language Class Initialized
INFO - 2023-04-25 05:23:38 --> Loader Class Initialized
INFO - 2023-04-25 05:23:38 --> Helper loaded: url_helper
INFO - 2023-04-25 05:23:38 --> Helper loaded: file_helper
INFO - 2023-04-25 05:23:38 --> Helper loaded: html_helper
INFO - 2023-04-25 05:23:38 --> Helper loaded: text_helper
INFO - 2023-04-25 05:23:38 --> Helper loaded: form_helper
INFO - 2023-04-25 05:23:38 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:23:38 --> Helper loaded: security_helper
INFO - 2023-04-25 05:23:38 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:23:38 --> Database Driver Class Initialized
INFO - 2023-04-25 05:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:23:38 --> Parser Class Initialized
INFO - 2023-04-25 05:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:23:38 --> Pagination Class Initialized
INFO - 2023-04-25 05:23:38 --> Form Validation Class Initialized
INFO - 2023-04-25 05:23:38 --> Controller Class Initialized
INFO - 2023-04-25 05:23:38 --> Model Class Initialized
DEBUG - 2023-04-25 05:23:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:38 --> Model Class Initialized
INFO - 2023-04-25 05:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-25 05:23:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:23:38 --> Model Class Initialized
INFO - 2023-04-25 05:23:38 --> Model Class Initialized
INFO - 2023-04-25 05:23:38 --> Model Class Initialized
INFO - 2023-04-25 05:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:23:38 --> Final output sent to browser
DEBUG - 2023-04-25 05:23:38 --> Total execution time: 0.0594
ERROR - 2023-04-25 05:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:23:39 --> Config Class Initialized
INFO - 2023-04-25 05:23:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:23:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:23:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:23:39 --> URI Class Initialized
INFO - 2023-04-25 05:23:39 --> Router Class Initialized
INFO - 2023-04-25 05:23:39 --> Output Class Initialized
INFO - 2023-04-25 05:23:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:23:39 --> Input Class Initialized
INFO - 2023-04-25 05:23:39 --> Language Class Initialized
INFO - 2023-04-25 05:23:39 --> Loader Class Initialized
INFO - 2023-04-25 05:23:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:23:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:23:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:23:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:23:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:23:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:23:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:23:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:23:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:23:39 --> Parser Class Initialized
INFO - 2023-04-25 05:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:23:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:23:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:23:39 --> Controller Class Initialized
INFO - 2023-04-25 05:23:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:39 --> Model Class Initialized
INFO - 2023-04-25 05:23:39 --> Final output sent to browser
DEBUG - 2023-04-25 05:23:39 --> Total execution time: 0.0186
ERROR - 2023-04-25 05:23:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:23:52 --> Config Class Initialized
INFO - 2023-04-25 05:23:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:23:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:23:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:23:52 --> URI Class Initialized
INFO - 2023-04-25 05:23:52 --> Router Class Initialized
INFO - 2023-04-25 05:23:52 --> Output Class Initialized
INFO - 2023-04-25 05:23:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:23:52 --> Input Class Initialized
INFO - 2023-04-25 05:23:52 --> Language Class Initialized
INFO - 2023-04-25 05:23:52 --> Loader Class Initialized
INFO - 2023-04-25 05:23:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:23:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:23:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:23:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:23:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:23:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:23:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:23:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:23:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:23:52 --> Parser Class Initialized
INFO - 2023-04-25 05:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:23:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:23:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:23:52 --> Controller Class Initialized
INFO - 2023-04-25 05:23:52 --> Model Class Initialized
DEBUG - 2023-04-25 05:23:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:23:52 --> Model Class Initialized
INFO - 2023-04-25 05:23:52 --> Final output sent to browser
DEBUG - 2023-04-25 05:23:52 --> Total execution time: 0.0205
ERROR - 2023-04-25 05:25:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:25:19 --> Config Class Initialized
INFO - 2023-04-25 05:25:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:25:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:25:19 --> Utf8 Class Initialized
INFO - 2023-04-25 05:25:19 --> URI Class Initialized
INFO - 2023-04-25 05:25:19 --> Router Class Initialized
INFO - 2023-04-25 05:25:19 --> Output Class Initialized
INFO - 2023-04-25 05:25:19 --> Security Class Initialized
DEBUG - 2023-04-25 05:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:25:19 --> Input Class Initialized
INFO - 2023-04-25 05:25:19 --> Language Class Initialized
INFO - 2023-04-25 05:25:19 --> Loader Class Initialized
INFO - 2023-04-25 05:25:19 --> Helper loaded: url_helper
INFO - 2023-04-25 05:25:19 --> Helper loaded: file_helper
INFO - 2023-04-25 05:25:19 --> Helper loaded: html_helper
INFO - 2023-04-25 05:25:19 --> Helper loaded: text_helper
INFO - 2023-04-25 05:25:19 --> Helper loaded: form_helper
INFO - 2023-04-25 05:25:19 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:25:19 --> Helper loaded: security_helper
INFO - 2023-04-25 05:25:19 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:25:19 --> Database Driver Class Initialized
INFO - 2023-04-25 05:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:25:19 --> Parser Class Initialized
INFO - 2023-04-25 05:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:25:19 --> Pagination Class Initialized
INFO - 2023-04-25 05:25:19 --> Form Validation Class Initialized
INFO - 2023-04-25 05:25:19 --> Controller Class Initialized
INFO - 2023-04-25 05:25:19 --> Model Class Initialized
DEBUG - 2023-04-25 05:25:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:25:19 --> Model Class Initialized
INFO - 2023-04-25 05:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-25 05:25:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:25:19 --> Model Class Initialized
INFO - 2023-04-25 05:25:19 --> Model Class Initialized
INFO - 2023-04-25 05:25:19 --> Model Class Initialized
INFO - 2023-04-25 05:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:25:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:25:19 --> Final output sent to browser
DEBUG - 2023-04-25 05:25:19 --> Total execution time: 0.1325
ERROR - 2023-04-25 05:25:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:25:20 --> Config Class Initialized
INFO - 2023-04-25 05:25:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:25:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:25:20 --> Utf8 Class Initialized
INFO - 2023-04-25 05:25:20 --> URI Class Initialized
INFO - 2023-04-25 05:25:20 --> Router Class Initialized
INFO - 2023-04-25 05:25:20 --> Output Class Initialized
INFO - 2023-04-25 05:25:20 --> Security Class Initialized
DEBUG - 2023-04-25 05:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:25:20 --> Input Class Initialized
INFO - 2023-04-25 05:25:20 --> Language Class Initialized
INFO - 2023-04-25 05:25:20 --> Loader Class Initialized
INFO - 2023-04-25 05:25:20 --> Helper loaded: url_helper
INFO - 2023-04-25 05:25:20 --> Helper loaded: file_helper
INFO - 2023-04-25 05:25:20 --> Helper loaded: html_helper
INFO - 2023-04-25 05:25:20 --> Helper loaded: text_helper
INFO - 2023-04-25 05:25:20 --> Helper loaded: form_helper
INFO - 2023-04-25 05:25:20 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:25:20 --> Helper loaded: security_helper
INFO - 2023-04-25 05:25:20 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:25:20 --> Database Driver Class Initialized
INFO - 2023-04-25 05:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:25:20 --> Parser Class Initialized
INFO - 2023-04-25 05:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:25:20 --> Pagination Class Initialized
INFO - 2023-04-25 05:25:20 --> Form Validation Class Initialized
INFO - 2023-04-25 05:25:20 --> Controller Class Initialized
INFO - 2023-04-25 05:25:20 --> Model Class Initialized
DEBUG - 2023-04-25 05:25:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:25:20 --> Model Class Initialized
INFO - 2023-04-25 05:25:20 --> Final output sent to browser
DEBUG - 2023-04-25 05:25:20 --> Total execution time: 0.0208
ERROR - 2023-04-25 05:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:25:26 --> Config Class Initialized
INFO - 2023-04-25 05:25:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:25:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:25:26 --> Utf8 Class Initialized
INFO - 2023-04-25 05:25:26 --> URI Class Initialized
INFO - 2023-04-25 05:25:26 --> Router Class Initialized
INFO - 2023-04-25 05:25:26 --> Output Class Initialized
INFO - 2023-04-25 05:25:26 --> Security Class Initialized
DEBUG - 2023-04-25 05:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:25:26 --> Input Class Initialized
INFO - 2023-04-25 05:25:26 --> Language Class Initialized
INFO - 2023-04-25 05:25:26 --> Loader Class Initialized
INFO - 2023-04-25 05:25:26 --> Helper loaded: url_helper
INFO - 2023-04-25 05:25:26 --> Helper loaded: file_helper
INFO - 2023-04-25 05:25:26 --> Helper loaded: html_helper
INFO - 2023-04-25 05:25:26 --> Helper loaded: text_helper
INFO - 2023-04-25 05:25:26 --> Helper loaded: form_helper
INFO - 2023-04-25 05:25:26 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:25:26 --> Helper loaded: security_helper
INFO - 2023-04-25 05:25:26 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:25:26 --> Database Driver Class Initialized
INFO - 2023-04-25 05:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:25:26 --> Parser Class Initialized
INFO - 2023-04-25 05:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:25:26 --> Pagination Class Initialized
INFO - 2023-04-25 05:25:26 --> Form Validation Class Initialized
INFO - 2023-04-25 05:25:26 --> Controller Class Initialized
INFO - 2023-04-25 05:25:26 --> Model Class Initialized
DEBUG - 2023-04-25 05:25:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:25:26 --> Model Class Initialized
INFO - 2023-04-25 05:25:26 --> Final output sent to browser
DEBUG - 2023-04-25 05:25:26 --> Total execution time: 0.0200
ERROR - 2023-04-25 05:26:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:24 --> Config Class Initialized
INFO - 2023-04-25 05:26:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:24 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:24 --> URI Class Initialized
INFO - 2023-04-25 05:26:24 --> Router Class Initialized
INFO - 2023-04-25 05:26:24 --> Output Class Initialized
INFO - 2023-04-25 05:26:24 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:24 --> Input Class Initialized
INFO - 2023-04-25 05:26:24 --> Language Class Initialized
INFO - 2023-04-25 05:26:24 --> Loader Class Initialized
INFO - 2023-04-25 05:26:24 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:24 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:24 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:24 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:24 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:24 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:24 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:24 --> Parser Class Initialized
INFO - 2023-04-25 05:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:24 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:24 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:24 --> Controller Class Initialized
INFO - 2023-04-25 05:26:24 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:24 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-25 05:26:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:26:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:26:24 --> Model Class Initialized
INFO - 2023-04-25 05:26:24 --> Model Class Initialized
INFO - 2023-04-25 05:26:24 --> Model Class Initialized
INFO - 2023-04-25 05:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:26:25 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:25 --> Total execution time: 0.1394
ERROR - 2023-04-25 05:26:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:34 --> Config Class Initialized
INFO - 2023-04-25 05:26:34 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:34 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:34 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:34 --> URI Class Initialized
INFO - 2023-04-25 05:26:34 --> Router Class Initialized
INFO - 2023-04-25 05:26:34 --> Output Class Initialized
INFO - 2023-04-25 05:26:34 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:34 --> Input Class Initialized
INFO - 2023-04-25 05:26:34 --> Language Class Initialized
INFO - 2023-04-25 05:26:34 --> Loader Class Initialized
INFO - 2023-04-25 05:26:34 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:34 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:34 --> Parser Class Initialized
INFO - 2023-04-25 05:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:34 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:34 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:34 --> Controller Class Initialized
INFO - 2023-04-25 05:26:34 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:34 --> Model Class Initialized
INFO - 2023-04-25 05:26:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-25 05:26:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:26:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:26:34 --> Model Class Initialized
INFO - 2023-04-25 05:26:34 --> Model Class Initialized
INFO - 2023-04-25 05:26:34 --> Model Class Initialized
INFO - 2023-04-25 05:26:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:26:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:26:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:26:34 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:34 --> Total execution time: 0.0683
ERROR - 2023-04-25 05:26:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:34 --> Config Class Initialized
INFO - 2023-04-25 05:26:34 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:34 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:34 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:34 --> URI Class Initialized
INFO - 2023-04-25 05:26:34 --> Router Class Initialized
INFO - 2023-04-25 05:26:34 --> Output Class Initialized
INFO - 2023-04-25 05:26:34 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:34 --> Input Class Initialized
INFO - 2023-04-25 05:26:34 --> Language Class Initialized
INFO - 2023-04-25 05:26:34 --> Loader Class Initialized
INFO - 2023-04-25 05:26:34 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:34 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:34 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:34 --> Parser Class Initialized
INFO - 2023-04-25 05:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:34 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:34 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:34 --> Controller Class Initialized
INFO - 2023-04-25 05:26:34 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:34 --> Model Class Initialized
INFO - 2023-04-25 05:26:34 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:34 --> Total execution time: 0.0229
ERROR - 2023-04-25 05:26:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:37 --> Config Class Initialized
INFO - 2023-04-25 05:26:37 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:37 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:37 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:37 --> URI Class Initialized
INFO - 2023-04-25 05:26:37 --> Router Class Initialized
INFO - 2023-04-25 05:26:37 --> Output Class Initialized
INFO - 2023-04-25 05:26:37 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:37 --> Input Class Initialized
INFO - 2023-04-25 05:26:37 --> Language Class Initialized
INFO - 2023-04-25 05:26:37 --> Loader Class Initialized
INFO - 2023-04-25 05:26:37 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:37 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:37 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:37 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:37 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:37 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:37 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:37 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:37 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:37 --> Parser Class Initialized
INFO - 2023-04-25 05:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:37 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:37 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:37 --> Controller Class Initialized
INFO - 2023-04-25 05:26:37 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:37 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-04-25 05:26:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:26:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:26:37 --> Model Class Initialized
INFO - 2023-04-25 05:26:37 --> Model Class Initialized
INFO - 2023-04-25 05:26:37 --> Model Class Initialized
INFO - 2023-04-25 05:26:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:26:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:26:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:26:37 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:37 --> Total execution time: 0.0695
ERROR - 2023-04-25 05:26:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:40 --> Config Class Initialized
INFO - 2023-04-25 05:26:40 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:40 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:40 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:40 --> URI Class Initialized
INFO - 2023-04-25 05:26:40 --> Router Class Initialized
INFO - 2023-04-25 05:26:40 --> Output Class Initialized
INFO - 2023-04-25 05:26:40 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:40 --> Input Class Initialized
INFO - 2023-04-25 05:26:40 --> Language Class Initialized
INFO - 2023-04-25 05:26:40 --> Loader Class Initialized
INFO - 2023-04-25 05:26:40 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:40 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:40 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:40 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:40 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:40 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:40 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:40 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:40 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:40 --> Parser Class Initialized
INFO - 2023-04-25 05:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:40 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:40 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:40 --> Controller Class Initialized
INFO - 2023-04-25 05:26:40 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:40 --> Total execution time: 0.0187
ERROR - 2023-04-25 05:26:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:43 --> Config Class Initialized
INFO - 2023-04-25 05:26:43 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:43 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:43 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:43 --> URI Class Initialized
INFO - 2023-04-25 05:26:43 --> Router Class Initialized
INFO - 2023-04-25 05:26:43 --> Output Class Initialized
INFO - 2023-04-25 05:26:43 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:43 --> Input Class Initialized
INFO - 2023-04-25 05:26:43 --> Language Class Initialized
INFO - 2023-04-25 05:26:43 --> Loader Class Initialized
INFO - 2023-04-25 05:26:43 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:43 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:43 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:43 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:43 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:43 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:43 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:43 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:43 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:43 --> Parser Class Initialized
INFO - 2023-04-25 05:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:43 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:43 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:43 --> Controller Class Initialized
INFO - 2023-04-25 05:26:43 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:43 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-04-25 05:26:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:26:43 --> Model Class Initialized
INFO - 2023-04-25 05:26:43 --> Model Class Initialized
INFO - 2023-04-25 05:26:43 --> Model Class Initialized
INFO - 2023-04-25 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:26:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:26:43 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:43 --> Total execution time: 0.0641
ERROR - 2023-04-25 05:26:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:46 --> Config Class Initialized
INFO - 2023-04-25 05:26:46 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:46 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:46 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:46 --> URI Class Initialized
INFO - 2023-04-25 05:26:46 --> Router Class Initialized
INFO - 2023-04-25 05:26:46 --> Output Class Initialized
INFO - 2023-04-25 05:26:46 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:46 --> Input Class Initialized
INFO - 2023-04-25 05:26:46 --> Language Class Initialized
INFO - 2023-04-25 05:26:46 --> Loader Class Initialized
INFO - 2023-04-25 05:26:46 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:46 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:46 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:46 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:46 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:46 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:46 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:46 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:46 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:46 --> Parser Class Initialized
INFO - 2023-04-25 05:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:46 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:46 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:46 --> Controller Class Initialized
INFO - 2023-04-25 05:26:46 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:46 --> Model Class Initialized
INFO - 2023-04-25 05:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-25 05:26:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:26:46 --> Model Class Initialized
INFO - 2023-04-25 05:26:46 --> Model Class Initialized
INFO - 2023-04-25 05:26:46 --> Model Class Initialized
INFO - 2023-04-25 05:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:26:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:26:46 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:46 --> Total execution time: 0.0627
ERROR - 2023-04-25 05:26:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:47 --> Config Class Initialized
INFO - 2023-04-25 05:26:47 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:47 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:47 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:47 --> URI Class Initialized
INFO - 2023-04-25 05:26:47 --> Router Class Initialized
INFO - 2023-04-25 05:26:47 --> Output Class Initialized
INFO - 2023-04-25 05:26:47 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:47 --> Input Class Initialized
INFO - 2023-04-25 05:26:47 --> Language Class Initialized
INFO - 2023-04-25 05:26:47 --> Loader Class Initialized
INFO - 2023-04-25 05:26:47 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:47 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:47 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:47 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:47 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:47 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:47 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:47 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:47 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:47 --> Parser Class Initialized
INFO - 2023-04-25 05:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:47 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:47 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:47 --> Controller Class Initialized
INFO - 2023-04-25 05:26:47 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:47 --> Model Class Initialized
INFO - 2023-04-25 05:26:47 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:47 --> Total execution time: 0.0209
ERROR - 2023-04-25 05:26:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:49 --> Config Class Initialized
INFO - 2023-04-25 05:26:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:49 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:49 --> URI Class Initialized
INFO - 2023-04-25 05:26:49 --> Router Class Initialized
INFO - 2023-04-25 05:26:49 --> Output Class Initialized
INFO - 2023-04-25 05:26:49 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:49 --> Input Class Initialized
INFO - 2023-04-25 05:26:49 --> Language Class Initialized
INFO - 2023-04-25 05:26:49 --> Loader Class Initialized
INFO - 2023-04-25 05:26:49 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:49 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:49 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:49 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:49 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:49 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:49 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:49 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:49 --> Parser Class Initialized
INFO - 2023-04-25 05:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:49 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:49 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:49 --> Controller Class Initialized
INFO - 2023-04-25 05:26:49 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:49 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-04-25 05:26:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:26:49 --> Model Class Initialized
INFO - 2023-04-25 05:26:49 --> Model Class Initialized
INFO - 2023-04-25 05:26:49 --> Model Class Initialized
INFO - 2023-04-25 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:26:49 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:49 --> Total execution time: 0.0637
ERROR - 2023-04-25 05:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:57 --> Config Class Initialized
INFO - 2023-04-25 05:26:57 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:57 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:57 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:57 --> URI Class Initialized
INFO - 2023-04-25 05:26:57 --> Router Class Initialized
INFO - 2023-04-25 05:26:57 --> Output Class Initialized
INFO - 2023-04-25 05:26:57 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:57 --> Input Class Initialized
INFO - 2023-04-25 05:26:57 --> Language Class Initialized
INFO - 2023-04-25 05:26:57 --> Loader Class Initialized
INFO - 2023-04-25 05:26:57 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:57 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:57 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:57 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:57 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:57 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:57 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:57 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:57 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:57 --> Parser Class Initialized
INFO - 2023-04-25 05:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:57 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:57 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:57 --> Controller Class Initialized
INFO - 2023-04-25 05:26:57 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:57 --> Model Class Initialized
INFO - 2023-04-25 05:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-25 05:26:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:26:57 --> Model Class Initialized
INFO - 2023-04-25 05:26:57 --> Model Class Initialized
INFO - 2023-04-25 05:26:57 --> Model Class Initialized
INFO - 2023-04-25 05:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:26:57 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:57 --> Total execution time: 0.0677
ERROR - 2023-04-25 05:26:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:26:58 --> Config Class Initialized
INFO - 2023-04-25 05:26:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:26:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:26:58 --> Utf8 Class Initialized
INFO - 2023-04-25 05:26:58 --> URI Class Initialized
INFO - 2023-04-25 05:26:58 --> Router Class Initialized
INFO - 2023-04-25 05:26:58 --> Output Class Initialized
INFO - 2023-04-25 05:26:58 --> Security Class Initialized
DEBUG - 2023-04-25 05:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:26:58 --> Input Class Initialized
INFO - 2023-04-25 05:26:58 --> Language Class Initialized
INFO - 2023-04-25 05:26:58 --> Loader Class Initialized
INFO - 2023-04-25 05:26:58 --> Helper loaded: url_helper
INFO - 2023-04-25 05:26:58 --> Helper loaded: file_helper
INFO - 2023-04-25 05:26:58 --> Helper loaded: html_helper
INFO - 2023-04-25 05:26:58 --> Helper loaded: text_helper
INFO - 2023-04-25 05:26:58 --> Helper loaded: form_helper
INFO - 2023-04-25 05:26:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:26:58 --> Helper loaded: security_helper
INFO - 2023-04-25 05:26:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:26:58 --> Database Driver Class Initialized
INFO - 2023-04-25 05:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:26:58 --> Parser Class Initialized
INFO - 2023-04-25 05:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:26:58 --> Pagination Class Initialized
INFO - 2023-04-25 05:26:58 --> Form Validation Class Initialized
INFO - 2023-04-25 05:26:58 --> Controller Class Initialized
INFO - 2023-04-25 05:26:58 --> Model Class Initialized
DEBUG - 2023-04-25 05:26:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:26:58 --> Model Class Initialized
INFO - 2023-04-25 05:26:58 --> Final output sent to browser
DEBUG - 2023-04-25 05:26:58 --> Total execution time: 0.0232
ERROR - 2023-04-25 05:27:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:00 --> Config Class Initialized
INFO - 2023-04-25 05:27:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:00 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:00 --> URI Class Initialized
INFO - 2023-04-25 05:27:00 --> Router Class Initialized
INFO - 2023-04-25 05:27:00 --> Output Class Initialized
INFO - 2023-04-25 05:27:00 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:00 --> Input Class Initialized
INFO - 2023-04-25 05:27:00 --> Language Class Initialized
INFO - 2023-04-25 05:27:00 --> Loader Class Initialized
INFO - 2023-04-25 05:27:00 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:00 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:00 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:00 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:00 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:00 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:00 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:00 --> Parser Class Initialized
INFO - 2023-04-25 05:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:00 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:00 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:00 --> Controller Class Initialized
INFO - 2023-04-25 05:27:00 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:00 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-04-25 05:27:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:27:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:27:00 --> Model Class Initialized
INFO - 2023-04-25 05:27:00 --> Model Class Initialized
INFO - 2023-04-25 05:27:00 --> Model Class Initialized
INFO - 2023-04-25 05:27:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:27:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:27:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:27:00 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:00 --> Total execution time: 0.0661
ERROR - 2023-04-25 05:27:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:06 --> Config Class Initialized
INFO - 2023-04-25 05:27:06 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:06 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:06 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:06 --> URI Class Initialized
INFO - 2023-04-25 05:27:06 --> Router Class Initialized
INFO - 2023-04-25 05:27:06 --> Output Class Initialized
INFO - 2023-04-25 05:27:06 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:06 --> Input Class Initialized
INFO - 2023-04-25 05:27:06 --> Language Class Initialized
INFO - 2023-04-25 05:27:06 --> Loader Class Initialized
INFO - 2023-04-25 05:27:06 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:06 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:06 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:06 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:06 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:06 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:06 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:06 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:06 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:06 --> Parser Class Initialized
INFO - 2023-04-25 05:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:06 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:06 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:06 --> Controller Class Initialized
INFO - 2023-04-25 05:27:06 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:06 --> Model Class Initialized
INFO - 2023-04-25 05:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-25 05:27:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:27:06 --> Model Class Initialized
INFO - 2023-04-25 05:27:06 --> Model Class Initialized
INFO - 2023-04-25 05:27:06 --> Model Class Initialized
INFO - 2023-04-25 05:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:27:06 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:06 --> Total execution time: 0.0632
ERROR - 2023-04-25 05:27:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:07 --> Config Class Initialized
INFO - 2023-04-25 05:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:07 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:07 --> URI Class Initialized
INFO - 2023-04-25 05:27:07 --> Router Class Initialized
INFO - 2023-04-25 05:27:07 --> Output Class Initialized
INFO - 2023-04-25 05:27:07 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:07 --> Input Class Initialized
INFO - 2023-04-25 05:27:07 --> Language Class Initialized
INFO - 2023-04-25 05:27:07 --> Loader Class Initialized
INFO - 2023-04-25 05:27:07 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:07 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:07 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:07 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:07 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:07 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:07 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:07 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:07 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:07 --> Parser Class Initialized
INFO - 2023-04-25 05:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:07 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:07 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:07 --> Controller Class Initialized
INFO - 2023-04-25 05:27:07 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:07 --> Model Class Initialized
INFO - 2023-04-25 05:27:07 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:07 --> Total execution time: 0.0209
ERROR - 2023-04-25 05:27:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:11 --> Config Class Initialized
INFO - 2023-04-25 05:27:11 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:11 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:11 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:11 --> URI Class Initialized
INFO - 2023-04-25 05:27:11 --> Router Class Initialized
INFO - 2023-04-25 05:27:11 --> Output Class Initialized
INFO - 2023-04-25 05:27:11 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:11 --> Input Class Initialized
INFO - 2023-04-25 05:27:11 --> Language Class Initialized
INFO - 2023-04-25 05:27:11 --> Loader Class Initialized
INFO - 2023-04-25 05:27:11 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:11 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:11 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:11 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:11 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:11 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:11 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:11 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:11 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:11 --> Parser Class Initialized
INFO - 2023-04-25 05:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:11 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:11 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:11 --> Controller Class Initialized
INFO - 2023-04-25 05:27:11 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:11 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-04-25 05:27:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:27:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:27:11 --> Model Class Initialized
INFO - 2023-04-25 05:27:11 --> Model Class Initialized
INFO - 2023-04-25 05:27:11 --> Model Class Initialized
INFO - 2023-04-25 05:27:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:27:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:27:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:27:11 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:11 --> Total execution time: 0.0716
ERROR - 2023-04-25 05:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:18 --> Config Class Initialized
INFO - 2023-04-25 05:27:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:18 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:18 --> URI Class Initialized
INFO - 2023-04-25 05:27:18 --> Router Class Initialized
INFO - 2023-04-25 05:27:18 --> Output Class Initialized
INFO - 2023-04-25 05:27:18 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:18 --> Input Class Initialized
INFO - 2023-04-25 05:27:18 --> Language Class Initialized
INFO - 2023-04-25 05:27:18 --> Loader Class Initialized
INFO - 2023-04-25 05:27:18 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:18 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:18 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:18 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:18 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:18 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:18 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:18 --> Parser Class Initialized
INFO - 2023-04-25 05:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:18 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:18 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:18 --> Controller Class Initialized
INFO - 2023-04-25 05:27:18 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:18 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-25 05:27:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:27:18 --> Model Class Initialized
INFO - 2023-04-25 05:27:18 --> Model Class Initialized
INFO - 2023-04-25 05:27:18 --> Model Class Initialized
INFO - 2023-04-25 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:27:19 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:19 --> Total execution time: 0.1387
ERROR - 2023-04-25 05:27:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:22 --> Config Class Initialized
INFO - 2023-04-25 05:27:22 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:22 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:22 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:22 --> URI Class Initialized
INFO - 2023-04-25 05:27:22 --> Router Class Initialized
INFO - 2023-04-25 05:27:22 --> Output Class Initialized
INFO - 2023-04-25 05:27:22 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:22 --> Input Class Initialized
INFO - 2023-04-25 05:27:22 --> Language Class Initialized
INFO - 2023-04-25 05:27:22 --> Loader Class Initialized
INFO - 2023-04-25 05:27:22 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:22 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:22 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:22 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:22 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:22 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:22 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:22 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:22 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:22 --> Parser Class Initialized
INFO - 2023-04-25 05:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:22 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:22 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:22 --> Controller Class Initialized
INFO - 2023-04-25 05:27:22 --> Model Class Initialized
INFO - 2023-04-25 05:27:22 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:22 --> Total execution time: 0.0161
ERROR - 2023-04-25 05:27:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:23 --> Config Class Initialized
INFO - 2023-04-25 05:27:23 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:23 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:23 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:23 --> URI Class Initialized
INFO - 2023-04-25 05:27:23 --> Router Class Initialized
INFO - 2023-04-25 05:27:23 --> Output Class Initialized
INFO - 2023-04-25 05:27:23 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:23 --> Input Class Initialized
INFO - 2023-04-25 05:27:23 --> Language Class Initialized
INFO - 2023-04-25 05:27:23 --> Loader Class Initialized
INFO - 2023-04-25 05:27:23 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:23 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:23 --> Parser Class Initialized
INFO - 2023-04-25 05:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:23 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:23 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:23 --> Controller Class Initialized
INFO - 2023-04-25 05:27:23 --> Model Class Initialized
INFO - 2023-04-25 05:27:23 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:23 --> Total execution time: 0.0135
ERROR - 2023-04-25 05:27:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:23 --> Config Class Initialized
INFO - 2023-04-25 05:27:23 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:23 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:23 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:23 --> URI Class Initialized
INFO - 2023-04-25 05:27:23 --> Router Class Initialized
INFO - 2023-04-25 05:27:23 --> Output Class Initialized
INFO - 2023-04-25 05:27:23 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:23 --> Input Class Initialized
INFO - 2023-04-25 05:27:23 --> Language Class Initialized
INFO - 2023-04-25 05:27:23 --> Loader Class Initialized
INFO - 2023-04-25 05:27:23 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:23 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:23 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:23 --> Parser Class Initialized
INFO - 2023-04-25 05:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:23 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:23 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:23 --> Controller Class Initialized
INFO - 2023-04-25 05:27:23 --> Model Class Initialized
INFO - 2023-04-25 05:27:23 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:23 --> Total execution time: 0.0139
ERROR - 2023-04-25 05:27:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:24 --> Config Class Initialized
INFO - 2023-04-25 05:27:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:24 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:24 --> URI Class Initialized
INFO - 2023-04-25 05:27:24 --> Router Class Initialized
INFO - 2023-04-25 05:27:24 --> Output Class Initialized
INFO - 2023-04-25 05:27:24 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:24 --> Input Class Initialized
INFO - 2023-04-25 05:27:24 --> Language Class Initialized
INFO - 2023-04-25 05:27:24 --> Loader Class Initialized
INFO - 2023-04-25 05:27:24 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:24 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:24 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:24 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:24 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:24 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:24 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:24 --> Parser Class Initialized
INFO - 2023-04-25 05:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:24 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:24 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:24 --> Controller Class Initialized
INFO - 2023-04-25 05:27:24 --> Model Class Initialized
INFO - 2023-04-25 05:27:24 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:24 --> Total execution time: 0.0131
ERROR - 2023-04-25 05:27:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:25 --> Config Class Initialized
INFO - 2023-04-25 05:27:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:25 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:25 --> URI Class Initialized
INFO - 2023-04-25 05:27:25 --> Router Class Initialized
INFO - 2023-04-25 05:27:25 --> Output Class Initialized
INFO - 2023-04-25 05:27:25 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:25 --> Input Class Initialized
INFO - 2023-04-25 05:27:25 --> Language Class Initialized
INFO - 2023-04-25 05:27:25 --> Loader Class Initialized
INFO - 2023-04-25 05:27:25 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:25 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:25 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:25 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:25 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:25 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:25 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:25 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:25 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:25 --> Parser Class Initialized
INFO - 2023-04-25 05:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:25 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:25 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:25 --> Controller Class Initialized
INFO - 2023-04-25 05:27:25 --> Model Class Initialized
INFO - 2023-04-25 05:27:25 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:25 --> Total execution time: 0.0134
ERROR - 2023-04-25 05:27:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:27 --> Config Class Initialized
INFO - 2023-04-25 05:27:27 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:27 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:27 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:27 --> URI Class Initialized
INFO - 2023-04-25 05:27:27 --> Router Class Initialized
INFO - 2023-04-25 05:27:27 --> Output Class Initialized
INFO - 2023-04-25 05:27:27 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:27 --> Input Class Initialized
INFO - 2023-04-25 05:27:27 --> Language Class Initialized
INFO - 2023-04-25 05:27:27 --> Loader Class Initialized
INFO - 2023-04-25 05:27:27 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:27 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:27 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:27 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:27 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:27 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:27 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:27 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:27 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:27 --> Parser Class Initialized
INFO - 2023-04-25 05:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:27 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:27 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:27 --> Controller Class Initialized
INFO - 2023-04-25 05:27:27 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:27 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:27 --> Model Class Initialized
INFO - 2023-04-25 05:27:27 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:27 --> Total execution time: 0.0214
ERROR - 2023-04-25 05:27:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:28 --> Config Class Initialized
INFO - 2023-04-25 05:27:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:28 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:28 --> URI Class Initialized
INFO - 2023-04-25 05:27:28 --> Router Class Initialized
INFO - 2023-04-25 05:27:28 --> Output Class Initialized
INFO - 2023-04-25 05:27:28 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:28 --> Input Class Initialized
INFO - 2023-04-25 05:27:28 --> Language Class Initialized
INFO - 2023-04-25 05:27:28 --> Loader Class Initialized
INFO - 2023-04-25 05:27:28 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:28 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:28 --> Parser Class Initialized
INFO - 2023-04-25 05:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:28 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:28 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:28 --> Controller Class Initialized
INFO - 2023-04-25 05:27:28 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:28 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:28 --> Model Class Initialized
INFO - 2023-04-25 05:27:28 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:28 --> Total execution time: 0.0184
ERROR - 2023-04-25 05:27:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:28 --> Config Class Initialized
INFO - 2023-04-25 05:27:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:28 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:28 --> URI Class Initialized
INFO - 2023-04-25 05:27:28 --> Router Class Initialized
INFO - 2023-04-25 05:27:28 --> Output Class Initialized
INFO - 2023-04-25 05:27:28 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:28 --> Input Class Initialized
INFO - 2023-04-25 05:27:28 --> Language Class Initialized
INFO - 2023-04-25 05:27:28 --> Loader Class Initialized
INFO - 2023-04-25 05:27:28 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:28 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:28 --> Parser Class Initialized
INFO - 2023-04-25 05:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:28 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:28 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:28 --> Controller Class Initialized
INFO - 2023-04-25 05:27:28 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:28 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:28 --> Model Class Initialized
INFO - 2023-04-25 05:27:28 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:28 --> Total execution time: 0.0176
ERROR - 2023-04-25 05:27:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:28 --> Config Class Initialized
INFO - 2023-04-25 05:27:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:28 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:29 --> URI Class Initialized
INFO - 2023-04-25 05:27:29 --> Router Class Initialized
INFO - 2023-04-25 05:27:29 --> Output Class Initialized
INFO - 2023-04-25 05:27:29 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:29 --> Input Class Initialized
INFO - 2023-04-25 05:27:29 --> Language Class Initialized
INFO - 2023-04-25 05:27:29 --> Loader Class Initialized
INFO - 2023-04-25 05:27:29 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:29 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:29 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:29 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:29 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:29 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:29 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:29 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:29 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:29 --> Parser Class Initialized
INFO - 2023-04-25 05:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:29 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:29 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:29 --> Controller Class Initialized
INFO - 2023-04-25 05:27:29 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:29 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:29 --> Model Class Initialized
INFO - 2023-04-25 05:27:29 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:29 --> Total execution time: 0.0178
ERROR - 2023-04-25 05:27:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:33 --> Config Class Initialized
INFO - 2023-04-25 05:27:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:33 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:33 --> URI Class Initialized
ERROR - 2023-04-25 05:27:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:33 --> Router Class Initialized
INFO - 2023-04-25 05:27:33 --> Config Class Initialized
INFO - 2023-04-25 05:27:33 --> Hooks Class Initialized
INFO - 2023-04-25 05:27:33 --> Output Class Initialized
INFO - 2023-04-25 05:27:33 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:33 --> Input Class Initialized
DEBUG - 2023-04-25 05:27:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:33 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:33 --> Language Class Initialized
INFO - 2023-04-25 05:27:33 --> URI Class Initialized
INFO - 2023-04-25 05:27:33 --> Router Class Initialized
INFO - 2023-04-25 05:27:33 --> Output Class Initialized
INFO - 2023-04-25 05:27:33 --> Loader Class Initialized
INFO - 2023-04-25 05:27:33 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:33 --> Security Class Initialized
INFO - 2023-04-25 05:27:33 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: html_helper
DEBUG - 2023-04-25 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:33 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:33 --> Input Class Initialized
INFO - 2023-04-25 05:27:33 --> Language Class Initialized
INFO - 2023-04-25 05:27:33 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:33 --> Loader Class Initialized
INFO - 2023-04-25 05:27:33 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:33 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:33 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:33 --> Parser Class Initialized
INFO - 2023-04-25 05:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:33 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:33 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:33 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:33 --> Controller Class Initialized
INFO - 2023-04-25 05:27:33 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:33 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:33 --> Model Class Initialized
INFO - 2023-04-25 05:27:33 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:33 --> Total execution time: 0.0175
INFO - 2023-04-25 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:33 --> Parser Class Initialized
INFO - 2023-04-25 05:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:33 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:33 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:33 --> Controller Class Initialized
INFO - 2023-04-25 05:27:33 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:33 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:33 --> Model Class Initialized
INFO - 2023-04-25 05:27:33 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:33 --> Total execution time: 0.0222
ERROR - 2023-04-25 05:27:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:34 --> Config Class Initialized
INFO - 2023-04-25 05:27:34 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:34 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:34 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:34 --> URI Class Initialized
INFO - 2023-04-25 05:27:34 --> Router Class Initialized
INFO - 2023-04-25 05:27:34 --> Output Class Initialized
INFO - 2023-04-25 05:27:34 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:34 --> Input Class Initialized
INFO - 2023-04-25 05:27:34 --> Language Class Initialized
INFO - 2023-04-25 05:27:34 --> Loader Class Initialized
INFO - 2023-04-25 05:27:34 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:34 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:34 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:34 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:34 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:34 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:34 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:34 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:34 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:34 --> Parser Class Initialized
INFO - 2023-04-25 05:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:34 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:34 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:34 --> Controller Class Initialized
INFO - 2023-04-25 05:27:34 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:34 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:34 --> Model Class Initialized
INFO - 2023-04-25 05:27:34 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:34 --> Total execution time: 0.0203
ERROR - 2023-04-25 05:27:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:36 --> Config Class Initialized
INFO - 2023-04-25 05:27:36 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:36 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:36 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:36 --> URI Class Initialized
INFO - 2023-04-25 05:27:36 --> Router Class Initialized
INFO - 2023-04-25 05:27:36 --> Output Class Initialized
INFO - 2023-04-25 05:27:36 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:36 --> Input Class Initialized
INFO - 2023-04-25 05:27:36 --> Language Class Initialized
INFO - 2023-04-25 05:27:36 --> Loader Class Initialized
INFO - 2023-04-25 05:27:36 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:36 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:36 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:36 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:36 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:36 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:36 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:36 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:36 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:36 --> Parser Class Initialized
INFO - 2023-04-25 05:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:36 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:36 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:36 --> Controller Class Initialized
INFO - 2023-04-25 05:27:36 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:36 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:36 --> Model Class Initialized
INFO - 2023-04-25 05:27:36 --> Model Class Initialized
INFO - 2023-04-25 05:27:36 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:36 --> Total execution time: 0.0196
ERROR - 2023-04-25 05:27:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:39 --> Config Class Initialized
INFO - 2023-04-25 05:27:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:39 --> URI Class Initialized
INFO - 2023-04-25 05:27:39 --> Router Class Initialized
INFO - 2023-04-25 05:27:39 --> Output Class Initialized
INFO - 2023-04-25 05:27:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:39 --> Input Class Initialized
INFO - 2023-04-25 05:27:39 --> Language Class Initialized
INFO - 2023-04-25 05:27:39 --> Loader Class Initialized
INFO - 2023-04-25 05:27:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:39 --> Parser Class Initialized
INFO - 2023-04-25 05:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:39 --> Controller Class Initialized
INFO - 2023-04-25 05:27:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:39 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:39 --> Model Class Initialized
INFO - 2023-04-25 05:27:39 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:39 --> Total execution time: 0.0172
ERROR - 2023-04-25 05:27:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:51 --> Config Class Initialized
INFO - 2023-04-25 05:27:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:51 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:51 --> URI Class Initialized
INFO - 2023-04-25 05:27:51 --> Router Class Initialized
INFO - 2023-04-25 05:27:51 --> Output Class Initialized
INFO - 2023-04-25 05:27:51 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:51 --> Input Class Initialized
INFO - 2023-04-25 05:27:51 --> Language Class Initialized
INFO - 2023-04-25 05:27:51 --> Loader Class Initialized
INFO - 2023-04-25 05:27:51 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:51 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:51 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:51 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:51 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:51 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:51 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:51 --> Parser Class Initialized
INFO - 2023-04-25 05:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:51 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:51 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:51 --> Controller Class Initialized
INFO - 2023-04-25 05:27:51 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:51 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:51 --> Model Class Initialized
INFO - 2023-04-25 05:27:51 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:51 --> Total execution time: 0.0206
ERROR - 2023-04-25 05:27:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:52 --> Config Class Initialized
INFO - 2023-04-25 05:27:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:52 --> URI Class Initialized
INFO - 2023-04-25 05:27:52 --> Router Class Initialized
INFO - 2023-04-25 05:27:52 --> Output Class Initialized
INFO - 2023-04-25 05:27:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:52 --> Input Class Initialized
INFO - 2023-04-25 05:27:52 --> Language Class Initialized
INFO - 2023-04-25 05:27:52 --> Loader Class Initialized
INFO - 2023-04-25 05:27:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:52 --> Parser Class Initialized
INFO - 2023-04-25 05:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:52 --> Controller Class Initialized
INFO - 2023-04-25 05:27:52 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:52 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:52 --> Model Class Initialized
INFO - 2023-04-25 05:27:52 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:52 --> Total execution time: 0.0184
ERROR - 2023-04-25 05:27:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:52 --> Config Class Initialized
INFO - 2023-04-25 05:27:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:52 --> URI Class Initialized
INFO - 2023-04-25 05:27:52 --> Router Class Initialized
INFO - 2023-04-25 05:27:52 --> Output Class Initialized
INFO - 2023-04-25 05:27:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:52 --> Input Class Initialized
INFO - 2023-04-25 05:27:52 --> Language Class Initialized
INFO - 2023-04-25 05:27:52 --> Loader Class Initialized
INFO - 2023-04-25 05:27:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:52 --> Parser Class Initialized
INFO - 2023-04-25 05:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:52 --> Controller Class Initialized
INFO - 2023-04-25 05:27:52 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:52 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:52 --> Model Class Initialized
INFO - 2023-04-25 05:27:52 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:52 --> Total execution time: 0.0166
ERROR - 2023-04-25 05:27:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:53 --> Config Class Initialized
INFO - 2023-04-25 05:27:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:53 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:53 --> URI Class Initialized
INFO - 2023-04-25 05:27:53 --> Router Class Initialized
INFO - 2023-04-25 05:27:53 --> Output Class Initialized
INFO - 2023-04-25 05:27:53 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:53 --> Input Class Initialized
INFO - 2023-04-25 05:27:53 --> Language Class Initialized
INFO - 2023-04-25 05:27:53 --> Loader Class Initialized
INFO - 2023-04-25 05:27:53 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:53 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:53 --> Parser Class Initialized
INFO - 2023-04-25 05:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:53 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:53 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:53 --> Controller Class Initialized
INFO - 2023-04-25 05:27:53 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:53 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:53 --> Model Class Initialized
INFO - 2023-04-25 05:27:53 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:53 --> Total execution time: 0.0178
ERROR - 2023-04-25 05:27:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:53 --> Config Class Initialized
INFO - 2023-04-25 05:27:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:53 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:53 --> URI Class Initialized
INFO - 2023-04-25 05:27:53 --> Router Class Initialized
INFO - 2023-04-25 05:27:53 --> Output Class Initialized
INFO - 2023-04-25 05:27:53 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:53 --> Input Class Initialized
INFO - 2023-04-25 05:27:53 --> Language Class Initialized
INFO - 2023-04-25 05:27:53 --> Loader Class Initialized
INFO - 2023-04-25 05:27:53 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:53 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:53 --> Parser Class Initialized
INFO - 2023-04-25 05:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:53 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:53 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:53 --> Controller Class Initialized
INFO - 2023-04-25 05:27:53 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:53 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:53 --> Model Class Initialized
INFO - 2023-04-25 05:27:53 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:53 --> Total execution time: 0.0174
ERROR - 2023-04-25 05:27:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:55 --> Config Class Initialized
INFO - 2023-04-25 05:27:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:55 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:55 --> URI Class Initialized
INFO - 2023-04-25 05:27:55 --> Router Class Initialized
INFO - 2023-04-25 05:27:55 --> Output Class Initialized
INFO - 2023-04-25 05:27:55 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:55 --> Input Class Initialized
INFO - 2023-04-25 05:27:55 --> Language Class Initialized
INFO - 2023-04-25 05:27:55 --> Loader Class Initialized
INFO - 2023-04-25 05:27:55 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:55 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:55 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:55 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:55 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:55 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:55 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:55 --> Parser Class Initialized
INFO - 2023-04-25 05:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:55 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:55 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:55 --> Controller Class Initialized
INFO - 2023-04-25 05:27:55 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:55 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:55 --> Model Class Initialized
INFO - 2023-04-25 05:27:55 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:55 --> Total execution time: 0.0181
ERROR - 2023-04-25 05:27:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:56 --> Config Class Initialized
INFO - 2023-04-25 05:27:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:56 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:56 --> URI Class Initialized
INFO - 2023-04-25 05:27:56 --> Router Class Initialized
INFO - 2023-04-25 05:27:56 --> Output Class Initialized
INFO - 2023-04-25 05:27:56 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:56 --> Input Class Initialized
INFO - 2023-04-25 05:27:56 --> Language Class Initialized
INFO - 2023-04-25 05:27:56 --> Loader Class Initialized
INFO - 2023-04-25 05:27:56 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:56 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:56 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:56 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:56 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:56 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:56 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:56 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:56 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:56 --> Parser Class Initialized
INFO - 2023-04-25 05:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:56 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:56 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:56 --> Controller Class Initialized
INFO - 2023-04-25 05:27:56 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:56 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:56 --> Model Class Initialized
INFO - 2023-04-25 05:27:56 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:56 --> Total execution time: 0.0168
ERROR - 2023-04-25 05:27:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:27:58 --> Config Class Initialized
INFO - 2023-04-25 05:27:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:27:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:27:58 --> Utf8 Class Initialized
INFO - 2023-04-25 05:27:58 --> URI Class Initialized
INFO - 2023-04-25 05:27:58 --> Router Class Initialized
INFO - 2023-04-25 05:27:58 --> Output Class Initialized
INFO - 2023-04-25 05:27:58 --> Security Class Initialized
DEBUG - 2023-04-25 05:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:27:58 --> Input Class Initialized
INFO - 2023-04-25 05:27:58 --> Language Class Initialized
INFO - 2023-04-25 05:27:58 --> Loader Class Initialized
INFO - 2023-04-25 05:27:58 --> Helper loaded: url_helper
INFO - 2023-04-25 05:27:58 --> Helper loaded: file_helper
INFO - 2023-04-25 05:27:58 --> Helper loaded: html_helper
INFO - 2023-04-25 05:27:58 --> Helper loaded: text_helper
INFO - 2023-04-25 05:27:58 --> Helper loaded: form_helper
INFO - 2023-04-25 05:27:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:27:58 --> Helper loaded: security_helper
INFO - 2023-04-25 05:27:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:27:58 --> Database Driver Class Initialized
INFO - 2023-04-25 05:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:27:58 --> Parser Class Initialized
INFO - 2023-04-25 05:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:27:58 --> Pagination Class Initialized
INFO - 2023-04-25 05:27:58 --> Form Validation Class Initialized
INFO - 2023-04-25 05:27:58 --> Controller Class Initialized
INFO - 2023-04-25 05:27:58 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:58 --> Model Class Initialized
DEBUG - 2023-04-25 05:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:27:58 --> Model Class Initialized
INFO - 2023-04-25 05:27:58 --> Model Class Initialized
INFO - 2023-04-25 05:27:58 --> Final output sent to browser
DEBUG - 2023-04-25 05:27:58 --> Total execution time: 0.0215
ERROR - 2023-04-25 05:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:28:01 --> Config Class Initialized
INFO - 2023-04-25 05:28:01 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:28:01 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:28:01 --> Utf8 Class Initialized
INFO - 2023-04-25 05:28:01 --> URI Class Initialized
INFO - 2023-04-25 05:28:01 --> Router Class Initialized
INFO - 2023-04-25 05:28:01 --> Output Class Initialized
INFO - 2023-04-25 05:28:01 --> Security Class Initialized
DEBUG - 2023-04-25 05:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:28:01 --> Input Class Initialized
INFO - 2023-04-25 05:28:01 --> Language Class Initialized
INFO - 2023-04-25 05:28:01 --> Loader Class Initialized
INFO - 2023-04-25 05:28:01 --> Helper loaded: url_helper
INFO - 2023-04-25 05:28:01 --> Helper loaded: file_helper
INFO - 2023-04-25 05:28:01 --> Helper loaded: html_helper
INFO - 2023-04-25 05:28:01 --> Helper loaded: text_helper
INFO - 2023-04-25 05:28:01 --> Helper loaded: form_helper
INFO - 2023-04-25 05:28:01 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:28:01 --> Helper loaded: security_helper
INFO - 2023-04-25 05:28:01 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:28:01 --> Database Driver Class Initialized
INFO - 2023-04-25 05:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:28:01 --> Parser Class Initialized
INFO - 2023-04-25 05:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:28:01 --> Pagination Class Initialized
INFO - 2023-04-25 05:28:01 --> Form Validation Class Initialized
INFO - 2023-04-25 05:28:01 --> Controller Class Initialized
INFO - 2023-04-25 05:28:01 --> Model Class Initialized
DEBUG - 2023-04-25 05:28:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:01 --> Model Class Initialized
DEBUG - 2023-04-25 05:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:01 --> Model Class Initialized
INFO - 2023-04-25 05:28:01 --> Final output sent to browser
DEBUG - 2023-04-25 05:28:01 --> Total execution time: 0.0194
ERROR - 2023-04-25 05:28:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:28:16 --> Config Class Initialized
INFO - 2023-04-25 05:28:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:28:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:28:16 --> Utf8 Class Initialized
INFO - 2023-04-25 05:28:16 --> URI Class Initialized
INFO - 2023-04-25 05:28:16 --> Router Class Initialized
INFO - 2023-04-25 05:28:16 --> Output Class Initialized
INFO - 2023-04-25 05:28:16 --> Security Class Initialized
DEBUG - 2023-04-25 05:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:28:16 --> Input Class Initialized
INFO - 2023-04-25 05:28:16 --> Language Class Initialized
INFO - 2023-04-25 05:28:16 --> Loader Class Initialized
INFO - 2023-04-25 05:28:16 --> Helper loaded: url_helper
INFO - 2023-04-25 05:28:16 --> Helper loaded: file_helper
INFO - 2023-04-25 05:28:16 --> Helper loaded: html_helper
INFO - 2023-04-25 05:28:16 --> Helper loaded: text_helper
INFO - 2023-04-25 05:28:16 --> Helper loaded: form_helper
INFO - 2023-04-25 05:28:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:28:16 --> Helper loaded: security_helper
INFO - 2023-04-25 05:28:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:28:16 --> Database Driver Class Initialized
INFO - 2023-04-25 05:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:28:16 --> Parser Class Initialized
INFO - 2023-04-25 05:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:28:16 --> Pagination Class Initialized
INFO - 2023-04-25 05:28:16 --> Form Validation Class Initialized
INFO - 2023-04-25 05:28:16 --> Controller Class Initialized
INFO - 2023-04-25 05:28:16 --> Model Class Initialized
DEBUG - 2023-04-25 05:28:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:16 --> Model Class Initialized
INFO - 2023-04-25 05:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-04-25 05:28:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:28:16 --> Model Class Initialized
INFO - 2023-04-25 05:28:16 --> Model Class Initialized
INFO - 2023-04-25 05:28:16 --> Model Class Initialized
INFO - 2023-04-25 05:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:28:16 --> Final output sent to browser
DEBUG - 2023-04-25 05:28:16 --> Total execution time: 0.1228
ERROR - 2023-04-25 05:28:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:28:17 --> Config Class Initialized
INFO - 2023-04-25 05:28:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:28:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:28:17 --> Utf8 Class Initialized
INFO - 2023-04-25 05:28:17 --> URI Class Initialized
INFO - 2023-04-25 05:28:17 --> Router Class Initialized
INFO - 2023-04-25 05:28:17 --> Output Class Initialized
INFO - 2023-04-25 05:28:17 --> Security Class Initialized
DEBUG - 2023-04-25 05:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:28:17 --> Input Class Initialized
INFO - 2023-04-25 05:28:17 --> Language Class Initialized
INFO - 2023-04-25 05:28:17 --> Loader Class Initialized
INFO - 2023-04-25 05:28:17 --> Helper loaded: url_helper
INFO - 2023-04-25 05:28:17 --> Helper loaded: file_helper
INFO - 2023-04-25 05:28:17 --> Helper loaded: html_helper
INFO - 2023-04-25 05:28:17 --> Helper loaded: text_helper
INFO - 2023-04-25 05:28:17 --> Helper loaded: form_helper
INFO - 2023-04-25 05:28:17 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:28:17 --> Helper loaded: security_helper
INFO - 2023-04-25 05:28:17 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:28:17 --> Database Driver Class Initialized
INFO - 2023-04-25 05:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:28:17 --> Parser Class Initialized
INFO - 2023-04-25 05:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:28:17 --> Pagination Class Initialized
INFO - 2023-04-25 05:28:17 --> Form Validation Class Initialized
INFO - 2023-04-25 05:28:17 --> Controller Class Initialized
INFO - 2023-04-25 05:28:17 --> Model Class Initialized
DEBUG - 2023-04-25 05:28:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:17 --> Model Class Initialized
INFO - 2023-04-25 05:28:17 --> Final output sent to browser
DEBUG - 2023-04-25 05:28:17 --> Total execution time: 0.0178
ERROR - 2023-04-25 05:28:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:28:50 --> Config Class Initialized
INFO - 2023-04-25 05:28:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:28:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:28:50 --> Utf8 Class Initialized
INFO - 2023-04-25 05:28:50 --> URI Class Initialized
INFO - 2023-04-25 05:28:50 --> Router Class Initialized
INFO - 2023-04-25 05:28:50 --> Output Class Initialized
INFO - 2023-04-25 05:28:50 --> Security Class Initialized
DEBUG - 2023-04-25 05:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:28:50 --> Input Class Initialized
INFO - 2023-04-25 05:28:50 --> Language Class Initialized
INFO - 2023-04-25 05:28:50 --> Loader Class Initialized
INFO - 2023-04-25 05:28:50 --> Helper loaded: url_helper
INFO - 2023-04-25 05:28:50 --> Helper loaded: file_helper
INFO - 2023-04-25 05:28:50 --> Helper loaded: html_helper
INFO - 2023-04-25 05:28:50 --> Helper loaded: text_helper
INFO - 2023-04-25 05:28:50 --> Helper loaded: form_helper
INFO - 2023-04-25 05:28:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:28:50 --> Helper loaded: security_helper
INFO - 2023-04-25 05:28:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:28:50 --> Database Driver Class Initialized
INFO - 2023-04-25 05:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:28:50 --> Parser Class Initialized
INFO - 2023-04-25 05:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:28:50 --> Pagination Class Initialized
INFO - 2023-04-25 05:28:50 --> Form Validation Class Initialized
INFO - 2023-04-25 05:28:50 --> Controller Class Initialized
DEBUG - 2023-04-25 05:28:50 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:50 --> Model Class Initialized
INFO - 2023-04-25 05:28:50 --> Model Class Initialized
INFO - 2023-04-25 05:28:50 --> Model Class Initialized
INFO - 2023-04-25 05:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-25 05:28:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:28:50 --> Model Class Initialized
INFO - 2023-04-25 05:28:50 --> Model Class Initialized
INFO - 2023-04-25 05:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:28:50 --> Final output sent to browser
DEBUG - 2023-04-25 05:28:50 --> Total execution time: 0.1346
ERROR - 2023-04-25 05:28:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:28:52 --> Config Class Initialized
INFO - 2023-04-25 05:28:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:28:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:28:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:28:52 --> URI Class Initialized
INFO - 2023-04-25 05:28:52 --> Router Class Initialized
INFO - 2023-04-25 05:28:52 --> Output Class Initialized
INFO - 2023-04-25 05:28:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:28:52 --> Input Class Initialized
INFO - 2023-04-25 05:28:52 --> Language Class Initialized
INFO - 2023-04-25 05:28:52 --> Loader Class Initialized
INFO - 2023-04-25 05:28:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:28:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:28:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:28:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:28:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:28:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:28:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:28:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:28:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:28:52 --> Parser Class Initialized
INFO - 2023-04-25 05:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:28:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:28:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:28:52 --> Controller Class Initialized
DEBUG - 2023-04-25 05:28:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:52 --> Model Class Initialized
INFO - 2023-04-25 05:28:52 --> Model Class Initialized
INFO - 2023-04-25 05:28:52 --> Final output sent to browser
DEBUG - 2023-04-25 05:28:52 --> Total execution time: 0.0453
ERROR - 2023-04-25 05:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:28:58 --> Config Class Initialized
INFO - 2023-04-25 05:28:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:28:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:28:58 --> Utf8 Class Initialized
INFO - 2023-04-25 05:28:58 --> URI Class Initialized
INFO - 2023-04-25 05:28:58 --> Router Class Initialized
INFO - 2023-04-25 05:28:58 --> Output Class Initialized
INFO - 2023-04-25 05:28:58 --> Security Class Initialized
DEBUG - 2023-04-25 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:28:58 --> Input Class Initialized
INFO - 2023-04-25 05:28:58 --> Language Class Initialized
INFO - 2023-04-25 05:28:58 --> Loader Class Initialized
INFO - 2023-04-25 05:28:58 --> Helper loaded: url_helper
INFO - 2023-04-25 05:28:58 --> Helper loaded: file_helper
INFO - 2023-04-25 05:28:58 --> Helper loaded: html_helper
INFO - 2023-04-25 05:28:58 --> Helper loaded: text_helper
INFO - 2023-04-25 05:28:58 --> Helper loaded: form_helper
INFO - 2023-04-25 05:28:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:28:58 --> Helper loaded: security_helper
INFO - 2023-04-25 05:28:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:28:58 --> Database Driver Class Initialized
INFO - 2023-04-25 05:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:28:58 --> Parser Class Initialized
INFO - 2023-04-25 05:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:28:58 --> Pagination Class Initialized
INFO - 2023-04-25 05:28:58 --> Form Validation Class Initialized
INFO - 2023-04-25 05:28:58 --> Controller Class Initialized
DEBUG - 2023-04-25 05:28:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:58 --> Model Class Initialized
INFO - 2023-04-25 05:28:58 --> Model Class Initialized
INFO - 2023-04-25 05:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-04-25 05:28:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:28:58 --> Model Class Initialized
INFO - 2023-04-25 05:28:58 --> Model Class Initialized
INFO - 2023-04-25 05:28:58 --> Model Class Initialized
INFO - 2023-04-25 05:28:58 --> Model Class Initialized
INFO - 2023-04-25 05:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:28:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:28:58 --> Final output sent to browser
DEBUG - 2023-04-25 05:28:58 --> Total execution time: 0.1578
ERROR - 2023-04-25 05:29:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:06 --> Config Class Initialized
INFO - 2023-04-25 05:29:06 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:06 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:06 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:06 --> URI Class Initialized
INFO - 2023-04-25 05:29:06 --> Router Class Initialized
INFO - 2023-04-25 05:29:06 --> Output Class Initialized
INFO - 2023-04-25 05:29:06 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:06 --> Input Class Initialized
INFO - 2023-04-25 05:29:06 --> Language Class Initialized
INFO - 2023-04-25 05:29:06 --> Loader Class Initialized
INFO - 2023-04-25 05:29:06 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:06 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:06 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:06 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:06 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:06 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:06 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:06 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:06 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:06 --> Parser Class Initialized
INFO - 2023-04-25 05:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:06 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:06 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:06 --> Controller Class Initialized
INFO - 2023-04-25 05:29:06 --> Model Class Initialized
INFO - 2023-04-25 05:29:06 --> Model Class Initialized
INFO - 2023-04-25 05:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:29:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:29:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:29:06 --> Model Class Initialized
INFO - 2023-04-25 05:29:06 --> Model Class Initialized
INFO - 2023-04-25 05:29:06 --> Model Class Initialized
INFO - 2023-04-25 05:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:29:07 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:07 --> Total execution time: 0.1401
ERROR - 2023-04-25 05:29:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:07 --> Config Class Initialized
INFO - 2023-04-25 05:29:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:07 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:07 --> URI Class Initialized
INFO - 2023-04-25 05:29:07 --> Router Class Initialized
INFO - 2023-04-25 05:29:07 --> Output Class Initialized
INFO - 2023-04-25 05:29:07 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:07 --> Input Class Initialized
INFO - 2023-04-25 05:29:07 --> Language Class Initialized
INFO - 2023-04-25 05:29:07 --> Loader Class Initialized
INFO - 2023-04-25 05:29:07 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:07 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:07 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:07 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:07 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:07 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:07 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:07 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:07 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:07 --> Parser Class Initialized
INFO - 2023-04-25 05:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:07 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:07 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:07 --> Controller Class Initialized
INFO - 2023-04-25 05:29:07 --> Model Class Initialized
INFO - 2023-04-25 05:29:07 --> Model Class Initialized
INFO - 2023-04-25 05:29:07 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:07 --> Total execution time: 0.0498
ERROR - 2023-04-25 05:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:15 --> Config Class Initialized
INFO - 2023-04-25 05:29:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:15 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:15 --> URI Class Initialized
INFO - 2023-04-25 05:29:15 --> Router Class Initialized
INFO - 2023-04-25 05:29:15 --> Output Class Initialized
INFO - 2023-04-25 05:29:15 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:15 --> Input Class Initialized
INFO - 2023-04-25 05:29:15 --> Language Class Initialized
INFO - 2023-04-25 05:29:15 --> Loader Class Initialized
INFO - 2023-04-25 05:29:15 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:15 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:15 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:15 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:15 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:15 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:15 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:15 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:15 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:15 --> Parser Class Initialized
INFO - 2023-04-25 05:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:15 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:15 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:15 --> Controller Class Initialized
INFO - 2023-04-25 05:29:15 --> Model Class Initialized
INFO - 2023-04-25 05:29:15 --> Model Class Initialized
INFO - 2023-04-25 05:29:15 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:15 --> Total execution time: 0.0705
ERROR - 2023-04-25 05:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:30 --> Config Class Initialized
INFO - 2023-04-25 05:29:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:30 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:30 --> URI Class Initialized
INFO - 2023-04-25 05:29:30 --> Router Class Initialized
INFO - 2023-04-25 05:29:30 --> Output Class Initialized
INFO - 2023-04-25 05:29:30 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:30 --> Input Class Initialized
INFO - 2023-04-25 05:29:30 --> Language Class Initialized
INFO - 2023-04-25 05:29:30 --> Loader Class Initialized
INFO - 2023-04-25 05:29:30 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:30 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:30 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:30 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:30 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:30 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:30 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:30 --> Parser Class Initialized
INFO - 2023-04-25 05:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:30 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:30 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:30 --> Controller Class Initialized
INFO - 2023-04-25 05:29:30 --> Model Class Initialized
INFO - 2023-04-25 05:29:30 --> Model Class Initialized
INFO - 2023-04-25 05:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:29:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:29:30 --> Model Class Initialized
INFO - 2023-04-25 05:29:30 --> Model Class Initialized
INFO - 2023-04-25 05:29:30 --> Model Class Initialized
INFO - 2023-04-25 05:29:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:29:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:29:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:29:31 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:31 --> Total execution time: 0.1323
ERROR - 2023-04-25 05:29:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:39 --> Config Class Initialized
INFO - 2023-04-25 05:29:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:39 --> URI Class Initialized
INFO - 2023-04-25 05:29:39 --> Router Class Initialized
INFO - 2023-04-25 05:29:39 --> Output Class Initialized
INFO - 2023-04-25 05:29:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:39 --> Input Class Initialized
INFO - 2023-04-25 05:29:39 --> Language Class Initialized
INFO - 2023-04-25 05:29:39 --> Loader Class Initialized
INFO - 2023-04-25 05:29:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:39 --> Parser Class Initialized
INFO - 2023-04-25 05:29:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:39 --> Controller Class Initialized
INFO - 2023-04-25 05:29:39 --> Model Class Initialized
INFO - 2023-04-25 05:29:39 --> Model Class Initialized
INFO - 2023-04-25 05:29:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:29:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:29:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:29:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:29:39 --> Model Class Initialized
INFO - 2023-04-25 05:29:39 --> Model Class Initialized
INFO - 2023-04-25 05:29:39 --> Model Class Initialized
INFO - 2023-04-25 05:29:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:29:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:29:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:29:39 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:39 --> Total execution time: 0.1325
ERROR - 2023-04-25 05:29:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:40 --> Config Class Initialized
INFO - 2023-04-25 05:29:40 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:40 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:40 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:40 --> URI Class Initialized
INFO - 2023-04-25 05:29:40 --> Router Class Initialized
INFO - 2023-04-25 05:29:40 --> Output Class Initialized
INFO - 2023-04-25 05:29:40 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:40 --> Input Class Initialized
INFO - 2023-04-25 05:29:40 --> Language Class Initialized
INFO - 2023-04-25 05:29:40 --> Loader Class Initialized
INFO - 2023-04-25 05:29:40 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:40 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:40 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:40 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:40 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:40 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:40 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:40 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:40 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:40 --> Parser Class Initialized
INFO - 2023-04-25 05:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:40 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:40 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:40 --> Controller Class Initialized
INFO - 2023-04-25 05:29:40 --> Model Class Initialized
INFO - 2023-04-25 05:29:40 --> Model Class Initialized
INFO - 2023-04-25 05:29:40 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:40 --> Total execution time: 0.0433
ERROR - 2023-04-25 05:29:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:45 --> Config Class Initialized
INFO - 2023-04-25 05:29:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:45 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:45 --> URI Class Initialized
INFO - 2023-04-25 05:29:45 --> Router Class Initialized
INFO - 2023-04-25 05:29:45 --> Output Class Initialized
INFO - 2023-04-25 05:29:45 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:45 --> Input Class Initialized
INFO - 2023-04-25 05:29:45 --> Language Class Initialized
INFO - 2023-04-25 05:29:45 --> Loader Class Initialized
INFO - 2023-04-25 05:29:45 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:45 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:45 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:45 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:45 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:45 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:45 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:45 --> Parser Class Initialized
INFO - 2023-04-25 05:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:45 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:45 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:45 --> Controller Class Initialized
INFO - 2023-04-25 05:29:45 --> Model Class Initialized
INFO - 2023-04-25 05:29:45 --> Model Class Initialized
INFO - 2023-04-25 05:29:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:29:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:29:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:29:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:29:45 --> Model Class Initialized
INFO - 2023-04-25 05:29:45 --> Model Class Initialized
INFO - 2023-04-25 05:29:45 --> Model Class Initialized
INFO - 2023-04-25 05:29:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:29:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:29:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:29:45 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:45 --> Total execution time: 0.1403
ERROR - 2023-04-25 05:29:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:49 --> Config Class Initialized
INFO - 2023-04-25 05:29:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:49 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:49 --> URI Class Initialized
INFO - 2023-04-25 05:29:49 --> Router Class Initialized
INFO - 2023-04-25 05:29:49 --> Output Class Initialized
INFO - 2023-04-25 05:29:49 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:49 --> Input Class Initialized
INFO - 2023-04-25 05:29:49 --> Language Class Initialized
INFO - 2023-04-25 05:29:49 --> Loader Class Initialized
INFO - 2023-04-25 05:29:49 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:49 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:49 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:49 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:49 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:49 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:49 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:49 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:49 --> Parser Class Initialized
INFO - 2023-04-25 05:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:49 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:49 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:49 --> Controller Class Initialized
INFO - 2023-04-25 05:29:49 --> Model Class Initialized
INFO - 2023-04-25 05:29:49 --> Model Class Initialized
INFO - 2023-04-25 05:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:29:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:29:49 --> Model Class Initialized
INFO - 2023-04-25 05:29:49 --> Model Class Initialized
INFO - 2023-04-25 05:29:49 --> Model Class Initialized
INFO - 2023-04-25 05:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:29:49 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:49 --> Total execution time: 0.1446
ERROR - 2023-04-25 05:29:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:50 --> Config Class Initialized
INFO - 2023-04-25 05:29:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:50 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:50 --> URI Class Initialized
INFO - 2023-04-25 05:29:50 --> Router Class Initialized
INFO - 2023-04-25 05:29:50 --> Output Class Initialized
INFO - 2023-04-25 05:29:50 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:50 --> Input Class Initialized
INFO - 2023-04-25 05:29:50 --> Language Class Initialized
INFO - 2023-04-25 05:29:50 --> Loader Class Initialized
INFO - 2023-04-25 05:29:50 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:50 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:50 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:50 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:50 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:50 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:50 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:50 --> Parser Class Initialized
INFO - 2023-04-25 05:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:50 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:50 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:50 --> Controller Class Initialized
INFO - 2023-04-25 05:29:50 --> Model Class Initialized
INFO - 2023-04-25 05:29:50 --> Model Class Initialized
INFO - 2023-04-25 05:29:50 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:50 --> Total execution time: 0.0427
ERROR - 2023-04-25 05:29:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:29:57 --> Config Class Initialized
INFO - 2023-04-25 05:29:57 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:29:57 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:29:57 --> Utf8 Class Initialized
INFO - 2023-04-25 05:29:57 --> URI Class Initialized
INFO - 2023-04-25 05:29:57 --> Router Class Initialized
INFO - 2023-04-25 05:29:57 --> Output Class Initialized
INFO - 2023-04-25 05:29:57 --> Security Class Initialized
DEBUG - 2023-04-25 05:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:29:57 --> Input Class Initialized
INFO - 2023-04-25 05:29:57 --> Language Class Initialized
INFO - 2023-04-25 05:29:57 --> Loader Class Initialized
INFO - 2023-04-25 05:29:57 --> Helper loaded: url_helper
INFO - 2023-04-25 05:29:57 --> Helper loaded: file_helper
INFO - 2023-04-25 05:29:57 --> Helper loaded: html_helper
INFO - 2023-04-25 05:29:57 --> Helper loaded: text_helper
INFO - 2023-04-25 05:29:57 --> Helper loaded: form_helper
INFO - 2023-04-25 05:29:57 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:29:57 --> Helper loaded: security_helper
INFO - 2023-04-25 05:29:57 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:29:57 --> Database Driver Class Initialized
INFO - 2023-04-25 05:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:29:57 --> Parser Class Initialized
INFO - 2023-04-25 05:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:29:57 --> Pagination Class Initialized
INFO - 2023-04-25 05:29:57 --> Form Validation Class Initialized
INFO - 2023-04-25 05:29:57 --> Controller Class Initialized
INFO - 2023-04-25 05:29:57 --> Model Class Initialized
INFO - 2023-04-25 05:29:57 --> Model Class Initialized
INFO - 2023-04-25 05:29:57 --> Final output sent to browser
DEBUG - 2023-04-25 05:29:57 --> Total execution time: 0.0656
ERROR - 2023-04-25 05:30:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:02 --> Config Class Initialized
INFO - 2023-04-25 05:30:02 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:02 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:02 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:02 --> URI Class Initialized
INFO - 2023-04-25 05:30:02 --> Router Class Initialized
INFO - 2023-04-25 05:30:02 --> Output Class Initialized
INFO - 2023-04-25 05:30:02 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:02 --> Input Class Initialized
INFO - 2023-04-25 05:30:02 --> Language Class Initialized
INFO - 2023-04-25 05:30:02 --> Loader Class Initialized
INFO - 2023-04-25 05:30:02 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:02 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:02 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:02 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:02 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:02 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:02 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:02 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:02 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:02 --> Parser Class Initialized
INFO - 2023-04-25 05:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:02 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:02 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:02 --> Controller Class Initialized
INFO - 2023-04-25 05:30:02 --> Model Class Initialized
INFO - 2023-04-25 05:30:02 --> Model Class Initialized
INFO - 2023-04-25 05:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:30:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:30:02 --> Model Class Initialized
INFO - 2023-04-25 05:30:02 --> Model Class Initialized
INFO - 2023-04-25 05:30:02 --> Model Class Initialized
INFO - 2023-04-25 05:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:30:02 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:02 --> Total execution time: 0.1449
ERROR - 2023-04-25 05:30:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:08 --> Config Class Initialized
INFO - 2023-04-25 05:30:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:08 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:08 --> URI Class Initialized
INFO - 2023-04-25 05:30:08 --> Router Class Initialized
INFO - 2023-04-25 05:30:08 --> Output Class Initialized
INFO - 2023-04-25 05:30:08 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:08 --> Input Class Initialized
INFO - 2023-04-25 05:30:08 --> Language Class Initialized
INFO - 2023-04-25 05:30:08 --> Loader Class Initialized
INFO - 2023-04-25 05:30:08 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:08 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:08 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:08 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:08 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:08 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:08 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:08 --> Parser Class Initialized
INFO - 2023-04-25 05:30:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:08 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:08 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:08 --> Controller Class Initialized
INFO - 2023-04-25 05:30:08 --> Model Class Initialized
INFO - 2023-04-25 05:30:08 --> Model Class Initialized
INFO - 2023-04-25 05:30:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:30:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:30:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:30:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:30:08 --> Model Class Initialized
INFO - 2023-04-25 05:30:08 --> Model Class Initialized
INFO - 2023-04-25 05:30:08 --> Model Class Initialized
INFO - 2023-04-25 05:30:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:30:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:30:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:30:08 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:08 --> Total execution time: 0.1389
ERROR - 2023-04-25 05:30:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:09 --> Config Class Initialized
INFO - 2023-04-25 05:30:09 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:09 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:09 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:09 --> URI Class Initialized
INFO - 2023-04-25 05:30:09 --> Router Class Initialized
INFO - 2023-04-25 05:30:09 --> Output Class Initialized
INFO - 2023-04-25 05:30:09 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:09 --> Input Class Initialized
INFO - 2023-04-25 05:30:09 --> Language Class Initialized
INFO - 2023-04-25 05:30:09 --> Loader Class Initialized
INFO - 2023-04-25 05:30:09 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:09 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:09 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:09 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:09 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:09 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:09 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:09 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:09 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:09 --> Parser Class Initialized
INFO - 2023-04-25 05:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:09 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:09 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:09 --> Controller Class Initialized
INFO - 2023-04-25 05:30:09 --> Model Class Initialized
INFO - 2023-04-25 05:30:09 --> Model Class Initialized
INFO - 2023-04-25 05:30:09 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:09 --> Total execution time: 0.0425
ERROR - 2023-04-25 05:30:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:12 --> Config Class Initialized
INFO - 2023-04-25 05:30:12 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:12 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:12 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:12 --> URI Class Initialized
INFO - 2023-04-25 05:30:12 --> Router Class Initialized
INFO - 2023-04-25 05:30:12 --> Output Class Initialized
INFO - 2023-04-25 05:30:12 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:12 --> Input Class Initialized
INFO - 2023-04-25 05:30:12 --> Language Class Initialized
INFO - 2023-04-25 05:30:12 --> Loader Class Initialized
INFO - 2023-04-25 05:30:12 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:12 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:12 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:12 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:12 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:12 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:12 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:12 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:12 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:12 --> Parser Class Initialized
INFO - 2023-04-25 05:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:12 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:12 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:12 --> Controller Class Initialized
INFO - 2023-04-25 05:30:12 --> Model Class Initialized
INFO - 2023-04-25 05:30:12 --> Model Class Initialized
INFO - 2023-04-25 05:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:30:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:30:12 --> Model Class Initialized
INFO - 2023-04-25 05:30:12 --> Model Class Initialized
INFO - 2023-04-25 05:30:12 --> Model Class Initialized
INFO - 2023-04-25 05:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:30:12 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:12 --> Total execution time: 0.1436
ERROR - 2023-04-25 05:30:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:42 --> Config Class Initialized
INFO - 2023-04-25 05:30:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:42 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:42 --> URI Class Initialized
INFO - 2023-04-25 05:30:42 --> Router Class Initialized
INFO - 2023-04-25 05:30:42 --> Output Class Initialized
INFO - 2023-04-25 05:30:42 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:42 --> Input Class Initialized
INFO - 2023-04-25 05:30:42 --> Language Class Initialized
INFO - 2023-04-25 05:30:42 --> Loader Class Initialized
INFO - 2023-04-25 05:30:42 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:42 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:42 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:42 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:42 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:42 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:42 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:42 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:42 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:42 --> Parser Class Initialized
INFO - 2023-04-25 05:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:42 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:42 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:42 --> Controller Class Initialized
INFO - 2023-04-25 05:30:42 --> Model Class Initialized
INFO - 2023-04-25 05:30:42 --> Model Class Initialized
INFO - 2023-04-25 05:30:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:30:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:30:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:30:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:30:42 --> Model Class Initialized
INFO - 2023-04-25 05:30:42 --> Model Class Initialized
INFO - 2023-04-25 05:30:42 --> Model Class Initialized
INFO - 2023-04-25 05:30:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:30:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:30:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:30:42 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:42 --> Total execution time: 0.1404
ERROR - 2023-04-25 05:30:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:43 --> Config Class Initialized
INFO - 2023-04-25 05:30:43 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:43 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:43 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:43 --> URI Class Initialized
INFO - 2023-04-25 05:30:43 --> Router Class Initialized
INFO - 2023-04-25 05:30:43 --> Output Class Initialized
INFO - 2023-04-25 05:30:43 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:43 --> Input Class Initialized
INFO - 2023-04-25 05:30:43 --> Language Class Initialized
INFO - 2023-04-25 05:30:43 --> Loader Class Initialized
INFO - 2023-04-25 05:30:43 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:43 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:43 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:43 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:43 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:43 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:43 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:43 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:43 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:43 --> Parser Class Initialized
INFO - 2023-04-25 05:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:43 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:43 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:43 --> Controller Class Initialized
INFO - 2023-04-25 05:30:43 --> Model Class Initialized
INFO - 2023-04-25 05:30:43 --> Model Class Initialized
INFO - 2023-04-25 05:30:43 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:43 --> Total execution time: 0.0439
ERROR - 2023-04-25 05:30:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:48 --> Config Class Initialized
INFO - 2023-04-25 05:30:48 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:48 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:48 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:48 --> URI Class Initialized
INFO - 2023-04-25 05:30:48 --> Router Class Initialized
INFO - 2023-04-25 05:30:48 --> Output Class Initialized
INFO - 2023-04-25 05:30:48 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:48 --> Input Class Initialized
INFO - 2023-04-25 05:30:48 --> Language Class Initialized
INFO - 2023-04-25 05:30:48 --> Loader Class Initialized
INFO - 2023-04-25 05:30:48 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:48 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:48 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:48 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:48 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:48 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:48 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:48 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:48 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:48 --> Parser Class Initialized
INFO - 2023-04-25 05:30:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:48 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:48 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:48 --> Controller Class Initialized
INFO - 2023-04-25 05:30:48 --> Model Class Initialized
INFO - 2023-04-25 05:30:48 --> Model Class Initialized
INFO - 2023-04-25 05:30:48 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:48 --> Total execution time: 0.0717
ERROR - 2023-04-25 05:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:30:52 --> Config Class Initialized
INFO - 2023-04-25 05:30:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:30:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:30:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:30:52 --> URI Class Initialized
INFO - 2023-04-25 05:30:52 --> Router Class Initialized
INFO - 2023-04-25 05:30:52 --> Output Class Initialized
INFO - 2023-04-25 05:30:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:30:52 --> Input Class Initialized
INFO - 2023-04-25 05:30:52 --> Language Class Initialized
INFO - 2023-04-25 05:30:52 --> Loader Class Initialized
INFO - 2023-04-25 05:30:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:30:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:30:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:30:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:30:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:30:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:30:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:30:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:30:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:30:52 --> Parser Class Initialized
INFO - 2023-04-25 05:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:30:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:30:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:30:52 --> Controller Class Initialized
INFO - 2023-04-25 05:30:52 --> Model Class Initialized
INFO - 2023-04-25 05:30:52 --> Model Class Initialized
INFO - 2023-04-25 05:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:30:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:30:52 --> Model Class Initialized
INFO - 2023-04-25 05:30:52 --> Model Class Initialized
INFO - 2023-04-25 05:30:52 --> Model Class Initialized
INFO - 2023-04-25 05:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:30:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:30:52 --> Final output sent to browser
DEBUG - 2023-04-25 05:30:52 --> Total execution time: 0.1295
ERROR - 2023-04-25 05:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:00 --> Config Class Initialized
INFO - 2023-04-25 05:31:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:00 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:00 --> URI Class Initialized
INFO - 2023-04-25 05:31:00 --> Router Class Initialized
INFO - 2023-04-25 05:31:00 --> Output Class Initialized
INFO - 2023-04-25 05:31:00 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:00 --> Input Class Initialized
INFO - 2023-04-25 05:31:00 --> Language Class Initialized
INFO - 2023-04-25 05:31:00 --> Loader Class Initialized
INFO - 2023-04-25 05:31:00 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:00 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:00 --> Parser Class Initialized
INFO - 2023-04-25 05:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:00 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:00 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:00 --> Controller Class Initialized
INFO - 2023-04-25 05:31:00 --> Model Class Initialized
INFO - 2023-04-25 05:31:00 --> Model Class Initialized
INFO - 2023-04-25 05:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:31:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:31:00 --> Model Class Initialized
INFO - 2023-04-25 05:31:00 --> Model Class Initialized
INFO - 2023-04-25 05:31:00 --> Model Class Initialized
INFO - 2023-04-25 05:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:31:00 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:00 --> Total execution time: 0.1455
ERROR - 2023-04-25 05:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:00 --> Config Class Initialized
INFO - 2023-04-25 05:31:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:00 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:00 --> URI Class Initialized
INFO - 2023-04-25 05:31:00 --> Router Class Initialized
INFO - 2023-04-25 05:31:00 --> Output Class Initialized
INFO - 2023-04-25 05:31:00 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:00 --> Input Class Initialized
INFO - 2023-04-25 05:31:00 --> Language Class Initialized
INFO - 2023-04-25 05:31:00 --> Loader Class Initialized
INFO - 2023-04-25 05:31:00 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:00 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:00 --> Parser Class Initialized
INFO - 2023-04-25 05:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:00 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:00 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:00 --> Controller Class Initialized
INFO - 2023-04-25 05:31:00 --> Model Class Initialized
INFO - 2023-04-25 05:31:00 --> Model Class Initialized
INFO - 2023-04-25 05:31:00 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:00 --> Total execution time: 0.0423
ERROR - 2023-04-25 05:31:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:03 --> Config Class Initialized
INFO - 2023-04-25 05:31:03 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:03 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:03 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:03 --> URI Class Initialized
INFO - 2023-04-25 05:31:03 --> Router Class Initialized
INFO - 2023-04-25 05:31:03 --> Output Class Initialized
INFO - 2023-04-25 05:31:03 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:03 --> Input Class Initialized
INFO - 2023-04-25 05:31:03 --> Language Class Initialized
INFO - 2023-04-25 05:31:03 --> Loader Class Initialized
INFO - 2023-04-25 05:31:03 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:03 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:03 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:03 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:03 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:03 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:03 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:03 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:03 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:03 --> Parser Class Initialized
INFO - 2023-04-25 05:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:03 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:03 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:03 --> Controller Class Initialized
INFO - 2023-04-25 05:31:03 --> Model Class Initialized
INFO - 2023-04-25 05:31:03 --> Model Class Initialized
INFO - 2023-04-25 05:31:03 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:03 --> Total execution time: 0.0703
ERROR - 2023-04-25 05:31:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:07 --> Config Class Initialized
INFO - 2023-04-25 05:31:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:07 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:07 --> URI Class Initialized
INFO - 2023-04-25 05:31:07 --> Router Class Initialized
INFO - 2023-04-25 05:31:07 --> Output Class Initialized
INFO - 2023-04-25 05:31:07 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:07 --> Input Class Initialized
INFO - 2023-04-25 05:31:07 --> Language Class Initialized
INFO - 2023-04-25 05:31:07 --> Loader Class Initialized
INFO - 2023-04-25 05:31:07 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:07 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:07 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:07 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:07 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:07 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:07 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:07 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:07 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:07 --> Parser Class Initialized
INFO - 2023-04-25 05:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:07 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:07 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:07 --> Controller Class Initialized
INFO - 2023-04-25 05:31:07 --> Model Class Initialized
INFO - 2023-04-25 05:31:07 --> Model Class Initialized
INFO - 2023-04-25 05:31:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:31:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:31:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:31:07 --> Model Class Initialized
INFO - 2023-04-25 05:31:07 --> Model Class Initialized
INFO - 2023-04-25 05:31:07 --> Model Class Initialized
INFO - 2023-04-25 05:31:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:31:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:31:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:31:07 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:07 --> Total execution time: 0.1618
ERROR - 2023-04-25 05:31:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:16 --> Config Class Initialized
INFO - 2023-04-25 05:31:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:16 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:16 --> URI Class Initialized
INFO - 2023-04-25 05:31:16 --> Router Class Initialized
INFO - 2023-04-25 05:31:16 --> Output Class Initialized
INFO - 2023-04-25 05:31:16 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:16 --> Input Class Initialized
INFO - 2023-04-25 05:31:16 --> Language Class Initialized
INFO - 2023-04-25 05:31:16 --> Loader Class Initialized
INFO - 2023-04-25 05:31:16 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:16 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:16 --> Parser Class Initialized
INFO - 2023-04-25 05:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:16 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:16 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:16 --> Controller Class Initialized
DEBUG - 2023-04-25 05:31:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:16 --> Model Class Initialized
DEBUG - 2023-04-25 05:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:16 --> Model Class Initialized
DEBUG - 2023-04-25 05:31:16 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:16 --> Model Class Initialized
INFO - 2023-04-25 05:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-25 05:31:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:31:16 --> Model Class Initialized
INFO - 2023-04-25 05:31:16 --> Model Class Initialized
INFO - 2023-04-25 05:31:16 --> Model Class Initialized
INFO - 2023-04-25 05:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:31:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:31:16 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:16 --> Total execution time: 0.1305
ERROR - 2023-04-25 05:31:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:16 --> Config Class Initialized
INFO - 2023-04-25 05:31:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:16 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:16 --> URI Class Initialized
INFO - 2023-04-25 05:31:16 --> Router Class Initialized
INFO - 2023-04-25 05:31:16 --> Output Class Initialized
INFO - 2023-04-25 05:31:16 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:16 --> Input Class Initialized
INFO - 2023-04-25 05:31:16 --> Language Class Initialized
INFO - 2023-04-25 05:31:16 --> Loader Class Initialized
INFO - 2023-04-25 05:31:16 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:16 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:16 --> Parser Class Initialized
INFO - 2023-04-25 05:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:16 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:16 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:16 --> Controller Class Initialized
DEBUG - 2023-04-25 05:31:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:17 --> Model Class Initialized
DEBUG - 2023-04-25 05:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:17 --> Model Class Initialized
INFO - 2023-04-25 05:31:17 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:17 --> Total execution time: 0.0357
ERROR - 2023-04-25 05:31:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:30 --> Config Class Initialized
INFO - 2023-04-25 05:31:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:30 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:30 --> URI Class Initialized
INFO - 2023-04-25 05:31:30 --> Router Class Initialized
INFO - 2023-04-25 05:31:30 --> Output Class Initialized
INFO - 2023-04-25 05:31:30 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:30 --> Input Class Initialized
INFO - 2023-04-25 05:31:30 --> Language Class Initialized
INFO - 2023-04-25 05:31:30 --> Loader Class Initialized
INFO - 2023-04-25 05:31:30 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:30 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:30 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:30 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:30 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:30 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:30 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:30 --> Parser Class Initialized
INFO - 2023-04-25 05:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:30 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:30 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:30 --> Controller Class Initialized
INFO - 2023-04-25 05:31:30 --> Model Class Initialized
INFO - 2023-04-25 05:31:30 --> Model Class Initialized
INFO - 2023-04-25 05:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:31:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:31:30 --> Model Class Initialized
INFO - 2023-04-25 05:31:30 --> Model Class Initialized
INFO - 2023-04-25 05:31:30 --> Model Class Initialized
INFO - 2023-04-25 05:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:31:30 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:30 --> Total execution time: 0.1334
ERROR - 2023-04-25 05:31:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:31 --> Config Class Initialized
INFO - 2023-04-25 05:31:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:31 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:31 --> URI Class Initialized
INFO - 2023-04-25 05:31:31 --> Router Class Initialized
INFO - 2023-04-25 05:31:31 --> Output Class Initialized
INFO - 2023-04-25 05:31:31 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:31 --> Input Class Initialized
INFO - 2023-04-25 05:31:31 --> Language Class Initialized
INFO - 2023-04-25 05:31:31 --> Loader Class Initialized
INFO - 2023-04-25 05:31:31 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:31 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:31 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:31 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:31 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:31 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:31 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:31 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:31 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:31 --> Parser Class Initialized
INFO - 2023-04-25 05:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:31 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:31 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:31 --> Controller Class Initialized
INFO - 2023-04-25 05:31:31 --> Model Class Initialized
INFO - 2023-04-25 05:31:31 --> Model Class Initialized
INFO - 2023-04-25 05:31:31 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:31 --> Total execution time: 0.0478
ERROR - 2023-04-25 05:31:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:37 --> Config Class Initialized
INFO - 2023-04-25 05:31:37 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:37 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:37 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:37 --> URI Class Initialized
INFO - 2023-04-25 05:31:37 --> Router Class Initialized
INFO - 2023-04-25 05:31:37 --> Output Class Initialized
INFO - 2023-04-25 05:31:37 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:37 --> Input Class Initialized
INFO - 2023-04-25 05:31:37 --> Language Class Initialized
INFO - 2023-04-25 05:31:37 --> Loader Class Initialized
INFO - 2023-04-25 05:31:37 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:37 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:37 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:37 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:37 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:37 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:37 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:37 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:37 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:37 --> Parser Class Initialized
INFO - 2023-04-25 05:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:37 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:37 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:37 --> Controller Class Initialized
INFO - 2023-04-25 05:31:37 --> Model Class Initialized
INFO - 2023-04-25 05:31:37 --> Model Class Initialized
INFO - 2023-04-25 05:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:31:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:31:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:31:37 --> Model Class Initialized
INFO - 2023-04-25 05:31:37 --> Model Class Initialized
INFO - 2023-04-25 05:31:37 --> Model Class Initialized
INFO - 2023-04-25 05:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:31:38 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:38 --> Total execution time: 0.1470
ERROR - 2023-04-25 05:31:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:47 --> Config Class Initialized
INFO - 2023-04-25 05:31:47 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:47 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:47 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:47 --> URI Class Initialized
INFO - 2023-04-25 05:31:47 --> Router Class Initialized
INFO - 2023-04-25 05:31:47 --> Output Class Initialized
INFO - 2023-04-25 05:31:47 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:47 --> Input Class Initialized
INFO - 2023-04-25 05:31:47 --> Language Class Initialized
INFO - 2023-04-25 05:31:47 --> Loader Class Initialized
INFO - 2023-04-25 05:31:47 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:47 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:47 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:47 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:47 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:47 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:47 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:47 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:47 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:47 --> Parser Class Initialized
INFO - 2023-04-25 05:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:47 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:47 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:47 --> Controller Class Initialized
INFO - 2023-04-25 05:31:47 --> Model Class Initialized
INFO - 2023-04-25 05:31:47 --> Model Class Initialized
INFO - 2023-04-25 05:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:31:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:31:47 --> Model Class Initialized
INFO - 2023-04-25 05:31:47 --> Model Class Initialized
INFO - 2023-04-25 05:31:47 --> Model Class Initialized
INFO - 2023-04-25 05:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:31:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:31:47 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:47 --> Total execution time: 0.1323
ERROR - 2023-04-25 05:31:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:48 --> Config Class Initialized
INFO - 2023-04-25 05:31:48 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:48 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:48 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:48 --> URI Class Initialized
INFO - 2023-04-25 05:31:48 --> Router Class Initialized
INFO - 2023-04-25 05:31:48 --> Output Class Initialized
INFO - 2023-04-25 05:31:48 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:48 --> Input Class Initialized
INFO - 2023-04-25 05:31:48 --> Language Class Initialized
INFO - 2023-04-25 05:31:48 --> Loader Class Initialized
INFO - 2023-04-25 05:31:48 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:48 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:48 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:48 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:48 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:48 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:48 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:48 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:48 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:48 --> Parser Class Initialized
INFO - 2023-04-25 05:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:48 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:48 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:48 --> Controller Class Initialized
INFO - 2023-04-25 05:31:48 --> Model Class Initialized
INFO - 2023-04-25 05:31:48 --> Model Class Initialized
INFO - 2023-04-25 05:31:48 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:48 --> Total execution time: 0.0426
ERROR - 2023-04-25 05:31:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:52 --> Config Class Initialized
INFO - 2023-04-25 05:31:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:52 --> URI Class Initialized
INFO - 2023-04-25 05:31:52 --> Router Class Initialized
INFO - 2023-04-25 05:31:52 --> Output Class Initialized
INFO - 2023-04-25 05:31:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:52 --> Input Class Initialized
INFO - 2023-04-25 05:31:52 --> Language Class Initialized
INFO - 2023-04-25 05:31:52 --> Loader Class Initialized
INFO - 2023-04-25 05:31:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:52 --> Parser Class Initialized
INFO - 2023-04-25 05:31:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:52 --> Controller Class Initialized
INFO - 2023-04-25 05:31:52 --> Model Class Initialized
INFO - 2023-04-25 05:31:52 --> Model Class Initialized
INFO - 2023-04-25 05:31:52 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:52 --> Total execution time: 0.0851
ERROR - 2023-04-25 05:31:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:31:58 --> Config Class Initialized
INFO - 2023-04-25 05:31:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:31:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:31:58 --> Utf8 Class Initialized
INFO - 2023-04-25 05:31:58 --> URI Class Initialized
INFO - 2023-04-25 05:31:58 --> Router Class Initialized
INFO - 2023-04-25 05:31:58 --> Output Class Initialized
INFO - 2023-04-25 05:31:58 --> Security Class Initialized
DEBUG - 2023-04-25 05:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:31:58 --> Input Class Initialized
INFO - 2023-04-25 05:31:58 --> Language Class Initialized
INFO - 2023-04-25 05:31:58 --> Loader Class Initialized
INFO - 2023-04-25 05:31:58 --> Helper loaded: url_helper
INFO - 2023-04-25 05:31:58 --> Helper loaded: file_helper
INFO - 2023-04-25 05:31:58 --> Helper loaded: html_helper
INFO - 2023-04-25 05:31:58 --> Helper loaded: text_helper
INFO - 2023-04-25 05:31:58 --> Helper loaded: form_helper
INFO - 2023-04-25 05:31:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:31:58 --> Helper loaded: security_helper
INFO - 2023-04-25 05:31:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:31:58 --> Database Driver Class Initialized
INFO - 2023-04-25 05:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:31:58 --> Parser Class Initialized
INFO - 2023-04-25 05:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:31:58 --> Pagination Class Initialized
INFO - 2023-04-25 05:31:58 --> Form Validation Class Initialized
INFO - 2023-04-25 05:31:58 --> Controller Class Initialized
INFO - 2023-04-25 05:31:58 --> Model Class Initialized
INFO - 2023-04-25 05:31:58 --> Model Class Initialized
INFO - 2023-04-25 05:31:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:31:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:31:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:31:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:31:58 --> Model Class Initialized
INFO - 2023-04-25 05:31:58 --> Model Class Initialized
INFO - 2023-04-25 05:31:58 --> Model Class Initialized
INFO - 2023-04-25 05:31:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:31:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:31:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:31:59 --> Final output sent to browser
DEBUG - 2023-04-25 05:31:59 --> Total execution time: 0.1428
ERROR - 2023-04-25 05:32:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:32:12 --> Config Class Initialized
INFO - 2023-04-25 05:32:12 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:32:12 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:32:12 --> Utf8 Class Initialized
INFO - 2023-04-25 05:32:12 --> URI Class Initialized
INFO - 2023-04-25 05:32:12 --> Router Class Initialized
INFO - 2023-04-25 05:32:12 --> Output Class Initialized
INFO - 2023-04-25 05:32:12 --> Security Class Initialized
DEBUG - 2023-04-25 05:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:32:12 --> Input Class Initialized
INFO - 2023-04-25 05:32:12 --> Language Class Initialized
INFO - 2023-04-25 05:32:12 --> Loader Class Initialized
INFO - 2023-04-25 05:32:12 --> Helper loaded: url_helper
INFO - 2023-04-25 05:32:12 --> Helper loaded: file_helper
INFO - 2023-04-25 05:32:12 --> Helper loaded: html_helper
INFO - 2023-04-25 05:32:12 --> Helper loaded: text_helper
INFO - 2023-04-25 05:32:12 --> Helper loaded: form_helper
INFO - 2023-04-25 05:32:12 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:32:12 --> Helper loaded: security_helper
INFO - 2023-04-25 05:32:12 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:32:12 --> Database Driver Class Initialized
INFO - 2023-04-25 05:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:32:12 --> Parser Class Initialized
INFO - 2023-04-25 05:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:32:12 --> Pagination Class Initialized
INFO - 2023-04-25 05:32:12 --> Form Validation Class Initialized
INFO - 2023-04-25 05:32:12 --> Controller Class Initialized
INFO - 2023-04-25 05:32:12 --> Model Class Initialized
INFO - 2023-04-25 05:32:12 --> Model Class Initialized
INFO - 2023-04-25 05:32:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:32:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:32:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:32:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:32:12 --> Model Class Initialized
INFO - 2023-04-25 05:32:12 --> Model Class Initialized
INFO - 2023-04-25 05:32:12 --> Model Class Initialized
INFO - 2023-04-25 05:32:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:32:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:32:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:32:12 --> Final output sent to browser
DEBUG - 2023-04-25 05:32:12 --> Total execution time: 0.1334
ERROR - 2023-04-25 05:32:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:32:13 --> Config Class Initialized
INFO - 2023-04-25 05:32:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:32:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:32:13 --> Utf8 Class Initialized
INFO - 2023-04-25 05:32:13 --> URI Class Initialized
INFO - 2023-04-25 05:32:13 --> Router Class Initialized
INFO - 2023-04-25 05:32:13 --> Output Class Initialized
INFO - 2023-04-25 05:32:13 --> Security Class Initialized
DEBUG - 2023-04-25 05:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:32:13 --> Input Class Initialized
INFO - 2023-04-25 05:32:13 --> Language Class Initialized
INFO - 2023-04-25 05:32:13 --> Loader Class Initialized
INFO - 2023-04-25 05:32:13 --> Helper loaded: url_helper
INFO - 2023-04-25 05:32:13 --> Helper loaded: file_helper
INFO - 2023-04-25 05:32:13 --> Helper loaded: html_helper
INFO - 2023-04-25 05:32:13 --> Helper loaded: text_helper
INFO - 2023-04-25 05:32:13 --> Helper loaded: form_helper
INFO - 2023-04-25 05:32:13 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:32:13 --> Helper loaded: security_helper
INFO - 2023-04-25 05:32:13 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:32:13 --> Database Driver Class Initialized
INFO - 2023-04-25 05:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:32:13 --> Parser Class Initialized
INFO - 2023-04-25 05:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:32:13 --> Pagination Class Initialized
INFO - 2023-04-25 05:32:13 --> Form Validation Class Initialized
INFO - 2023-04-25 05:32:13 --> Controller Class Initialized
INFO - 2023-04-25 05:32:13 --> Model Class Initialized
INFO - 2023-04-25 05:32:13 --> Model Class Initialized
INFO - 2023-04-25 05:32:13 --> Final output sent to browser
DEBUG - 2023-04-25 05:32:13 --> Total execution time: 0.0482
ERROR - 2023-04-25 05:32:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:32:19 --> Config Class Initialized
INFO - 2023-04-25 05:32:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:32:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:32:19 --> Utf8 Class Initialized
INFO - 2023-04-25 05:32:19 --> URI Class Initialized
INFO - 2023-04-25 05:32:19 --> Router Class Initialized
INFO - 2023-04-25 05:32:19 --> Output Class Initialized
INFO - 2023-04-25 05:32:19 --> Security Class Initialized
DEBUG - 2023-04-25 05:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:32:19 --> Input Class Initialized
INFO - 2023-04-25 05:32:19 --> Language Class Initialized
INFO - 2023-04-25 05:32:19 --> Loader Class Initialized
INFO - 2023-04-25 05:32:19 --> Helper loaded: url_helper
INFO - 2023-04-25 05:32:19 --> Helper loaded: file_helper
INFO - 2023-04-25 05:32:19 --> Helper loaded: html_helper
INFO - 2023-04-25 05:32:19 --> Helper loaded: text_helper
INFO - 2023-04-25 05:32:19 --> Helper loaded: form_helper
INFO - 2023-04-25 05:32:19 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:32:19 --> Helper loaded: security_helper
INFO - 2023-04-25 05:32:19 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:32:19 --> Database Driver Class Initialized
INFO - 2023-04-25 05:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:32:19 --> Parser Class Initialized
INFO - 2023-04-25 05:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:32:19 --> Pagination Class Initialized
INFO - 2023-04-25 05:32:19 --> Form Validation Class Initialized
INFO - 2023-04-25 05:32:19 --> Controller Class Initialized
INFO - 2023-04-25 05:32:19 --> Model Class Initialized
INFO - 2023-04-25 05:32:19 --> Model Class Initialized
INFO - 2023-04-25 05:32:19 --> Final output sent to browser
DEBUG - 2023-04-25 05:32:19 --> Total execution time: 0.0676
ERROR - 2023-04-25 05:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:32:26 --> Config Class Initialized
INFO - 2023-04-25 05:32:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:32:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:32:26 --> Utf8 Class Initialized
INFO - 2023-04-25 05:32:26 --> URI Class Initialized
INFO - 2023-04-25 05:32:26 --> Router Class Initialized
INFO - 2023-04-25 05:32:26 --> Output Class Initialized
INFO - 2023-04-25 05:32:26 --> Security Class Initialized
DEBUG - 2023-04-25 05:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:32:26 --> Input Class Initialized
INFO - 2023-04-25 05:32:26 --> Language Class Initialized
INFO - 2023-04-25 05:32:26 --> Loader Class Initialized
INFO - 2023-04-25 05:32:26 --> Helper loaded: url_helper
INFO - 2023-04-25 05:32:26 --> Helper loaded: file_helper
INFO - 2023-04-25 05:32:26 --> Helper loaded: html_helper
INFO - 2023-04-25 05:32:26 --> Helper loaded: text_helper
INFO - 2023-04-25 05:32:26 --> Helper loaded: form_helper
INFO - 2023-04-25 05:32:26 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:32:26 --> Helper loaded: security_helper
INFO - 2023-04-25 05:32:26 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:32:26 --> Database Driver Class Initialized
INFO - 2023-04-25 05:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:32:26 --> Parser Class Initialized
INFO - 2023-04-25 05:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:32:26 --> Pagination Class Initialized
INFO - 2023-04-25 05:32:26 --> Form Validation Class Initialized
INFO - 2023-04-25 05:32:26 --> Controller Class Initialized
INFO - 2023-04-25 05:32:26 --> Model Class Initialized
INFO - 2023-04-25 05:32:26 --> Model Class Initialized
INFO - 2023-04-25 05:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:32:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:32:26 --> Model Class Initialized
INFO - 2023-04-25 05:32:26 --> Model Class Initialized
INFO - 2023-04-25 05:32:26 --> Model Class Initialized
INFO - 2023-04-25 05:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:32:26 --> Final output sent to browser
DEBUG - 2023-04-25 05:32:26 --> Total execution time: 0.1395
ERROR - 2023-04-25 05:32:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:32:31 --> Config Class Initialized
INFO - 2023-04-25 05:32:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:32:31 --> Utf8 Class Initialized
INFO - 2023-04-25 05:32:31 --> URI Class Initialized
INFO - 2023-04-25 05:32:31 --> Router Class Initialized
INFO - 2023-04-25 05:32:31 --> Output Class Initialized
INFO - 2023-04-25 05:32:31 --> Security Class Initialized
DEBUG - 2023-04-25 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:32:31 --> Input Class Initialized
INFO - 2023-04-25 05:32:31 --> Language Class Initialized
INFO - 2023-04-25 05:32:31 --> Loader Class Initialized
INFO - 2023-04-25 05:32:31 --> Helper loaded: url_helper
INFO - 2023-04-25 05:32:31 --> Helper loaded: file_helper
INFO - 2023-04-25 05:32:31 --> Helper loaded: html_helper
INFO - 2023-04-25 05:32:31 --> Helper loaded: text_helper
INFO - 2023-04-25 05:32:31 --> Helper loaded: form_helper
INFO - 2023-04-25 05:32:31 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:32:31 --> Helper loaded: security_helper
INFO - 2023-04-25 05:32:31 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:32:31 --> Database Driver Class Initialized
INFO - 2023-04-25 05:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:32:31 --> Parser Class Initialized
INFO - 2023-04-25 05:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:32:31 --> Pagination Class Initialized
INFO - 2023-04-25 05:32:31 --> Form Validation Class Initialized
INFO - 2023-04-25 05:32:31 --> Controller Class Initialized
INFO - 2023-04-25 05:32:31 --> Model Class Initialized
INFO - 2023-04-25 05:32:31 --> Model Class Initialized
INFO - 2023-04-25 05:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:32:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:32:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:32:31 --> Model Class Initialized
INFO - 2023-04-25 05:32:31 --> Model Class Initialized
INFO - 2023-04-25 05:32:31 --> Model Class Initialized
INFO - 2023-04-25 05:32:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:32:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:32:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:32:32 --> Final output sent to browser
DEBUG - 2023-04-25 05:32:32 --> Total execution time: 0.1274
ERROR - 2023-04-25 05:32:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:32:32 --> Config Class Initialized
INFO - 2023-04-25 05:32:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:32:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:32:32 --> Utf8 Class Initialized
INFO - 2023-04-25 05:32:32 --> URI Class Initialized
INFO - 2023-04-25 05:32:32 --> Router Class Initialized
INFO - 2023-04-25 05:32:32 --> Output Class Initialized
INFO - 2023-04-25 05:32:32 --> Security Class Initialized
DEBUG - 2023-04-25 05:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:32:32 --> Input Class Initialized
INFO - 2023-04-25 05:32:32 --> Language Class Initialized
INFO - 2023-04-25 05:32:32 --> Loader Class Initialized
INFO - 2023-04-25 05:32:32 --> Helper loaded: url_helper
INFO - 2023-04-25 05:32:32 --> Helper loaded: file_helper
INFO - 2023-04-25 05:32:32 --> Helper loaded: html_helper
INFO - 2023-04-25 05:32:32 --> Helper loaded: text_helper
INFO - 2023-04-25 05:32:32 --> Helper loaded: form_helper
INFO - 2023-04-25 05:32:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:32:32 --> Helper loaded: security_helper
INFO - 2023-04-25 05:32:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:32:32 --> Database Driver Class Initialized
INFO - 2023-04-25 05:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:32:32 --> Parser Class Initialized
INFO - 2023-04-25 05:32:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:32:32 --> Pagination Class Initialized
INFO - 2023-04-25 05:32:32 --> Form Validation Class Initialized
INFO - 2023-04-25 05:32:32 --> Controller Class Initialized
INFO - 2023-04-25 05:32:32 --> Model Class Initialized
INFO - 2023-04-25 05:32:32 --> Model Class Initialized
INFO - 2023-04-25 05:32:32 --> Final output sent to browser
DEBUG - 2023-04-25 05:32:32 --> Total execution time: 0.0452
ERROR - 2023-04-25 05:32:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:32:39 --> Config Class Initialized
INFO - 2023-04-25 05:32:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:32:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:32:39 --> Utf8 Class Initialized
INFO - 2023-04-25 05:32:39 --> URI Class Initialized
INFO - 2023-04-25 05:32:39 --> Router Class Initialized
INFO - 2023-04-25 05:32:39 --> Output Class Initialized
INFO - 2023-04-25 05:32:39 --> Security Class Initialized
DEBUG - 2023-04-25 05:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:32:39 --> Input Class Initialized
INFO - 2023-04-25 05:32:39 --> Language Class Initialized
INFO - 2023-04-25 05:32:39 --> Loader Class Initialized
INFO - 2023-04-25 05:32:39 --> Helper loaded: url_helper
INFO - 2023-04-25 05:32:39 --> Helper loaded: file_helper
INFO - 2023-04-25 05:32:39 --> Helper loaded: html_helper
INFO - 2023-04-25 05:32:39 --> Helper loaded: text_helper
INFO - 2023-04-25 05:32:39 --> Helper loaded: form_helper
INFO - 2023-04-25 05:32:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:32:39 --> Helper loaded: security_helper
INFO - 2023-04-25 05:32:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:32:39 --> Database Driver Class Initialized
INFO - 2023-04-25 05:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:32:39 --> Parser Class Initialized
INFO - 2023-04-25 05:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:32:39 --> Pagination Class Initialized
INFO - 2023-04-25 05:32:39 --> Form Validation Class Initialized
INFO - 2023-04-25 05:32:39 --> Controller Class Initialized
INFO - 2023-04-25 05:32:39 --> Model Class Initialized
INFO - 2023-04-25 05:32:39 --> Model Class Initialized
INFO - 2023-04-25 05:32:39 --> Final output sent to browser
DEBUG - 2023-04-25 05:32:39 --> Total execution time: 0.0769
ERROR - 2023-04-25 05:34:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:34:28 --> Config Class Initialized
INFO - 2023-04-25 05:34:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:34:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:34:28 --> Utf8 Class Initialized
INFO - 2023-04-25 05:34:28 --> URI Class Initialized
INFO - 2023-04-25 05:34:28 --> Router Class Initialized
INFO - 2023-04-25 05:34:28 --> Output Class Initialized
INFO - 2023-04-25 05:34:28 --> Security Class Initialized
DEBUG - 2023-04-25 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:34:28 --> Input Class Initialized
INFO - 2023-04-25 05:34:28 --> Language Class Initialized
INFO - 2023-04-25 05:34:28 --> Loader Class Initialized
INFO - 2023-04-25 05:34:28 --> Helper loaded: url_helper
INFO - 2023-04-25 05:34:28 --> Helper loaded: file_helper
INFO - 2023-04-25 05:34:28 --> Helper loaded: html_helper
INFO - 2023-04-25 05:34:28 --> Helper loaded: text_helper
INFO - 2023-04-25 05:34:28 --> Helper loaded: form_helper
INFO - 2023-04-25 05:34:28 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:34:28 --> Helper loaded: security_helper
INFO - 2023-04-25 05:34:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:34:28 --> Database Driver Class Initialized
INFO - 2023-04-25 05:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:34:28 --> Parser Class Initialized
INFO - 2023-04-25 05:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:34:28 --> Pagination Class Initialized
INFO - 2023-04-25 05:34:28 --> Form Validation Class Initialized
INFO - 2023-04-25 05:34:28 --> Controller Class Initialized
INFO - 2023-04-25 05:34:28 --> Model Class Initialized
INFO - 2023-04-25 05:34:28 --> Model Class Initialized
INFO - 2023-04-25 05:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-04-25 05:34:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:34:28 --> Model Class Initialized
INFO - 2023-04-25 05:34:28 --> Model Class Initialized
INFO - 2023-04-25 05:34:28 --> Model Class Initialized
INFO - 2023-04-25 05:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:34:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:34:29 --> Final output sent to browser
DEBUG - 2023-04-25 05:34:29 --> Total execution time: 0.1437
ERROR - 2023-04-25 05:35:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:35:28 --> Config Class Initialized
INFO - 2023-04-25 05:35:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:35:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:35:28 --> Utf8 Class Initialized
INFO - 2023-04-25 05:35:28 --> URI Class Initialized
INFO - 2023-04-25 05:35:28 --> Router Class Initialized
INFO - 2023-04-25 05:35:28 --> Output Class Initialized
INFO - 2023-04-25 05:35:28 --> Security Class Initialized
DEBUG - 2023-04-25 05:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:35:28 --> Input Class Initialized
INFO - 2023-04-25 05:35:28 --> Language Class Initialized
INFO - 2023-04-25 05:35:28 --> Loader Class Initialized
INFO - 2023-04-25 05:35:28 --> Helper loaded: url_helper
INFO - 2023-04-25 05:35:28 --> Helper loaded: file_helper
INFO - 2023-04-25 05:35:28 --> Helper loaded: html_helper
INFO - 2023-04-25 05:35:28 --> Helper loaded: text_helper
INFO - 2023-04-25 05:35:28 --> Helper loaded: form_helper
INFO - 2023-04-25 05:35:28 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:35:28 --> Helper loaded: security_helper
INFO - 2023-04-25 05:35:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:35:28 --> Database Driver Class Initialized
INFO - 2023-04-25 05:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:35:28 --> Parser Class Initialized
INFO - 2023-04-25 05:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:35:28 --> Pagination Class Initialized
INFO - 2023-04-25 05:35:28 --> Form Validation Class Initialized
INFO - 2023-04-25 05:35:28 --> Controller Class Initialized
DEBUG - 2023-04-25 05:35:28 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-04-25 05:35:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:35:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:28 --> Model Class Initialized
INFO - 2023-04-25 05:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:35:29 --> Final output sent to browser
DEBUG - 2023-04-25 05:35:29 --> Total execution time: 0.1587
ERROR - 2023-04-25 05:35:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:35:34 --> Config Class Initialized
INFO - 2023-04-25 05:35:34 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:35:34 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:35:34 --> Utf8 Class Initialized
INFO - 2023-04-25 05:35:34 --> URI Class Initialized
INFO - 2023-04-25 05:35:34 --> Router Class Initialized
INFO - 2023-04-25 05:35:34 --> Output Class Initialized
INFO - 2023-04-25 05:35:34 --> Security Class Initialized
DEBUG - 2023-04-25 05:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:35:34 --> Input Class Initialized
INFO - 2023-04-25 05:35:34 --> Language Class Initialized
INFO - 2023-04-25 05:35:34 --> Loader Class Initialized
INFO - 2023-04-25 05:35:34 --> Helper loaded: url_helper
INFO - 2023-04-25 05:35:34 --> Helper loaded: file_helper
INFO - 2023-04-25 05:35:34 --> Helper loaded: html_helper
INFO - 2023-04-25 05:35:34 --> Helper loaded: text_helper
INFO - 2023-04-25 05:35:34 --> Helper loaded: form_helper
INFO - 2023-04-25 05:35:34 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:35:34 --> Helper loaded: security_helper
INFO - 2023-04-25 05:35:34 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:35:34 --> Database Driver Class Initialized
INFO - 2023-04-25 05:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:35:34 --> Parser Class Initialized
INFO - 2023-04-25 05:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:35:34 --> Pagination Class Initialized
INFO - 2023-04-25 05:35:34 --> Form Validation Class Initialized
INFO - 2023-04-25 05:35:34 --> Controller Class Initialized
DEBUG - 2023-04-25 05:35:34 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:35:34 --> Model Class Initialized
INFO - 2023-04-25 05:35:34 --> Model Class Initialized
INFO - 2023-04-25 05:35:34 --> Model Class Initialized
INFO - 2023-04-25 05:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-25 05:35:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:35:34 --> Model Class Initialized
INFO - 2023-04-25 05:35:34 --> Model Class Initialized
INFO - 2023-04-25 05:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:35:34 --> Final output sent to browser
DEBUG - 2023-04-25 05:35:34 --> Total execution time: 0.1250
ERROR - 2023-04-25 05:35:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:35:35 --> Config Class Initialized
INFO - 2023-04-25 05:35:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:35:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:35:35 --> Utf8 Class Initialized
INFO - 2023-04-25 05:35:35 --> URI Class Initialized
INFO - 2023-04-25 05:35:35 --> Router Class Initialized
INFO - 2023-04-25 05:35:35 --> Output Class Initialized
INFO - 2023-04-25 05:35:35 --> Security Class Initialized
DEBUG - 2023-04-25 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:35:35 --> Input Class Initialized
INFO - 2023-04-25 05:35:35 --> Language Class Initialized
INFO - 2023-04-25 05:35:35 --> Loader Class Initialized
INFO - 2023-04-25 05:35:35 --> Helper loaded: url_helper
INFO - 2023-04-25 05:35:35 --> Helper loaded: file_helper
INFO - 2023-04-25 05:35:35 --> Helper loaded: html_helper
INFO - 2023-04-25 05:35:35 --> Helper loaded: text_helper
INFO - 2023-04-25 05:35:35 --> Helper loaded: form_helper
INFO - 2023-04-25 05:35:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:35:35 --> Helper loaded: security_helper
INFO - 2023-04-25 05:35:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:35:35 --> Database Driver Class Initialized
INFO - 2023-04-25 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:35:35 --> Parser Class Initialized
INFO - 2023-04-25 05:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:35:35 --> Pagination Class Initialized
INFO - 2023-04-25 05:35:35 --> Form Validation Class Initialized
INFO - 2023-04-25 05:35:35 --> Controller Class Initialized
DEBUG - 2023-04-25 05:35:35 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:35:35 --> Model Class Initialized
INFO - 2023-04-25 05:35:35 --> Model Class Initialized
INFO - 2023-04-25 05:35:35 --> Final output sent to browser
DEBUG - 2023-04-25 05:35:35 --> Total execution time: 0.0428
ERROR - 2023-04-25 05:35:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:35:38 --> Config Class Initialized
INFO - 2023-04-25 05:35:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:35:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:35:38 --> Utf8 Class Initialized
INFO - 2023-04-25 05:35:38 --> URI Class Initialized
INFO - 2023-04-25 05:35:38 --> Router Class Initialized
INFO - 2023-04-25 05:35:38 --> Output Class Initialized
INFO - 2023-04-25 05:35:38 --> Security Class Initialized
DEBUG - 2023-04-25 05:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:35:38 --> Input Class Initialized
INFO - 2023-04-25 05:35:38 --> Language Class Initialized
INFO - 2023-04-25 05:35:38 --> Loader Class Initialized
INFO - 2023-04-25 05:35:38 --> Helper loaded: url_helper
INFO - 2023-04-25 05:35:38 --> Helper loaded: file_helper
INFO - 2023-04-25 05:35:38 --> Helper loaded: html_helper
INFO - 2023-04-25 05:35:38 --> Helper loaded: text_helper
INFO - 2023-04-25 05:35:38 --> Helper loaded: form_helper
INFO - 2023-04-25 05:35:38 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:35:38 --> Helper loaded: security_helper
INFO - 2023-04-25 05:35:38 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:35:38 --> Database Driver Class Initialized
INFO - 2023-04-25 05:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:35:38 --> Parser Class Initialized
INFO - 2023-04-25 05:35:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:35:38 --> Pagination Class Initialized
INFO - 2023-04-25 05:35:38 --> Form Validation Class Initialized
INFO - 2023-04-25 05:35:38 --> Controller Class Initialized
DEBUG - 2023-04-25 05:35:38 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:35:38 --> Model Class Initialized
INFO - 2023-04-25 05:35:38 --> Model Class Initialized
INFO - 2023-04-25 05:35:38 --> Final output sent to browser
DEBUG - 2023-04-25 05:35:38 --> Total execution time: 0.1140
ERROR - 2023-04-25 05:36:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:05 --> Config Class Initialized
INFO - 2023-04-25 05:36:05 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:05 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:05 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:05 --> URI Class Initialized
INFO - 2023-04-25 05:36:05 --> Router Class Initialized
INFO - 2023-04-25 05:36:05 --> Output Class Initialized
INFO - 2023-04-25 05:36:05 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:05 --> Input Class Initialized
INFO - 2023-04-25 05:36:05 --> Language Class Initialized
INFO - 2023-04-25 05:36:05 --> Loader Class Initialized
INFO - 2023-04-25 05:36:05 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:05 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:05 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:05 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:05 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:05 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:05 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:05 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:05 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:05 --> Parser Class Initialized
INFO - 2023-04-25 05:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:05 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:05 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:05 --> Controller Class Initialized
INFO - 2023-04-25 05:36:05 --> Model Class Initialized
INFO - 2023-04-25 05:36:05 --> Model Class Initialized
INFO - 2023-04-25 05:36:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-04-25 05:36:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:36:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:36:05 --> Model Class Initialized
INFO - 2023-04-25 05:36:05 --> Model Class Initialized
INFO - 2023-04-25 05:36:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:36:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:36:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:36:05 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:05 --> Total execution time: 0.1339
ERROR - 2023-04-25 05:36:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:06 --> Config Class Initialized
INFO - 2023-04-25 05:36:06 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:06 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:06 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:06 --> URI Class Initialized
INFO - 2023-04-25 05:36:06 --> Router Class Initialized
INFO - 2023-04-25 05:36:06 --> Output Class Initialized
INFO - 2023-04-25 05:36:06 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:06 --> Input Class Initialized
INFO - 2023-04-25 05:36:06 --> Language Class Initialized
INFO - 2023-04-25 05:36:06 --> Loader Class Initialized
INFO - 2023-04-25 05:36:06 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:06 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:06 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:06 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:06 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:06 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:06 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:06 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:06 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:06 --> Parser Class Initialized
INFO - 2023-04-25 05:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:06 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:06 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:06 --> Controller Class Initialized
INFO - 2023-04-25 05:36:06 --> Model Class Initialized
INFO - 2023-04-25 05:36:06 --> Model Class Initialized
ERROR - 2023-04-25 05:36:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/application/models/Reports.php 447
INFO - 2023-04-25 05:36:06 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:06 --> Total execution time: 0.0191
ERROR - 2023-04-25 05:36:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:13 --> Config Class Initialized
INFO - 2023-04-25 05:36:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:13 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:13 --> URI Class Initialized
INFO - 2023-04-25 05:36:13 --> Router Class Initialized
INFO - 2023-04-25 05:36:13 --> Output Class Initialized
INFO - 2023-04-25 05:36:13 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:13 --> Input Class Initialized
INFO - 2023-04-25 05:36:13 --> Language Class Initialized
INFO - 2023-04-25 05:36:13 --> Loader Class Initialized
INFO - 2023-04-25 05:36:13 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:13 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:13 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:13 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:13 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:13 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:13 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:13 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:13 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:13 --> Parser Class Initialized
INFO - 2023-04-25 05:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:13 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:13 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:13 --> Controller Class Initialized
INFO - 2023-04-25 05:36:13 --> Model Class Initialized
INFO - 2023-04-25 05:36:13 --> Model Class Initialized
ERROR - 2023-04-25 05:36:13 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/application/models/Reports.php 447
INFO - 2023-04-25 05:36:13 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:13 --> Total execution time: 0.0254
ERROR - 2023-04-25 05:36:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:14 --> Config Class Initialized
INFO - 2023-04-25 05:36:14 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:14 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:14 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:14 --> URI Class Initialized
DEBUG - 2023-04-25 05:36:14 --> No URI present. Default controller set.
INFO - 2023-04-25 05:36:14 --> Router Class Initialized
INFO - 2023-04-25 05:36:14 --> Output Class Initialized
INFO - 2023-04-25 05:36:14 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:14 --> Input Class Initialized
INFO - 2023-04-25 05:36:14 --> Language Class Initialized
INFO - 2023-04-25 05:36:14 --> Loader Class Initialized
INFO - 2023-04-25 05:36:14 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:14 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:14 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:14 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:14 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:14 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:14 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:14 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:14 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:14 --> Parser Class Initialized
INFO - 2023-04-25 05:36:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:14 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:14 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:14 --> Controller Class Initialized
INFO - 2023-04-25 05:36:14 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 05:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:16 --> Config Class Initialized
INFO - 2023-04-25 05:36:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:16 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:16 --> URI Class Initialized
INFO - 2023-04-25 05:36:16 --> Router Class Initialized
INFO - 2023-04-25 05:36:16 --> Output Class Initialized
INFO - 2023-04-25 05:36:16 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:16 --> Input Class Initialized
INFO - 2023-04-25 05:36:16 --> Language Class Initialized
INFO - 2023-04-25 05:36:16 --> Loader Class Initialized
INFO - 2023-04-25 05:36:16 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:16 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:16 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:16 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:16 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:16 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:16 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:16 --> Parser Class Initialized
INFO - 2023-04-25 05:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:16 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:16 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:16 --> Controller Class Initialized
INFO - 2023-04-25 05:36:16 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 05:36:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:36:16 --> Model Class Initialized
INFO - 2023-04-25 05:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:36:16 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:16 --> Total execution time: 0.0277
ERROR - 2023-04-25 05:36:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:20 --> Config Class Initialized
INFO - 2023-04-25 05:36:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:20 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:20 --> URI Class Initialized
INFO - 2023-04-25 05:36:20 --> Router Class Initialized
INFO - 2023-04-25 05:36:20 --> Output Class Initialized
INFO - 2023-04-25 05:36:20 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:20 --> Input Class Initialized
INFO - 2023-04-25 05:36:20 --> Language Class Initialized
INFO - 2023-04-25 05:36:20 --> Loader Class Initialized
INFO - 2023-04-25 05:36:20 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:20 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:20 --> Parser Class Initialized
INFO - 2023-04-25 05:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:20 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:20 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:20 --> Controller Class Initialized
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
INFO - 2023-04-25 05:36:20 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:20 --> Total execution time: 0.0202
ERROR - 2023-04-25 05:36:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:20 --> Config Class Initialized
INFO - 2023-04-25 05:36:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:20 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:20 --> URI Class Initialized
DEBUG - 2023-04-25 05:36:20 --> No URI present. Default controller set.
INFO - 2023-04-25 05:36:20 --> Router Class Initialized
INFO - 2023-04-25 05:36:20 --> Output Class Initialized
INFO - 2023-04-25 05:36:20 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:20 --> Input Class Initialized
INFO - 2023-04-25 05:36:20 --> Language Class Initialized
INFO - 2023-04-25 05:36:20 --> Loader Class Initialized
INFO - 2023-04-25 05:36:20 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:20 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:20 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:20 --> Parser Class Initialized
INFO - 2023-04-25 05:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:20 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:20 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:20 --> Controller Class Initialized
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
INFO - 2023-04-25 05:36:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:36:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:36:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:36:20 --> Model Class Initialized
INFO - 2023-04-25 05:36:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:36:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:36:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:36:20 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:20 --> Total execution time: 0.1639
ERROR - 2023-04-25 05:36:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:21 --> Config Class Initialized
INFO - 2023-04-25 05:36:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:21 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:21 --> URI Class Initialized
INFO - 2023-04-25 05:36:21 --> Router Class Initialized
INFO - 2023-04-25 05:36:21 --> Output Class Initialized
INFO - 2023-04-25 05:36:21 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:21 --> Input Class Initialized
INFO - 2023-04-25 05:36:21 --> Language Class Initialized
INFO - 2023-04-25 05:36:21 --> Loader Class Initialized
INFO - 2023-04-25 05:36:21 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:21 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:21 --> Parser Class Initialized
INFO - 2023-04-25 05:36:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:21 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:21 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:21 --> Controller Class Initialized
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
INFO - 2023-04-25 05:36:21 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:21 --> Total execution time: 0.0148
ERROR - 2023-04-25 05:36:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:21 --> Config Class Initialized
INFO - 2023-04-25 05:36:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:21 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:21 --> URI Class Initialized
DEBUG - 2023-04-25 05:36:21 --> No URI present. Default controller set.
INFO - 2023-04-25 05:36:21 --> Router Class Initialized
INFO - 2023-04-25 05:36:21 --> Output Class Initialized
INFO - 2023-04-25 05:36:21 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:21 --> Input Class Initialized
INFO - 2023-04-25 05:36:21 --> Language Class Initialized
INFO - 2023-04-25 05:36:21 --> Loader Class Initialized
INFO - 2023-04-25 05:36:21 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:21 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:21 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:21 --> Parser Class Initialized
INFO - 2023-04-25 05:36:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:21 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:21 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:21 --> Controller Class Initialized
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
INFO - 2023-04-25 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:36:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:36:21 --> Model Class Initialized
INFO - 2023-04-25 05:36:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:36:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:36:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:36:22 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:22 --> Total execution time: 0.1667
ERROR - 2023-04-25 05:36:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:23 --> Config Class Initialized
INFO - 2023-04-25 05:36:23 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:23 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:23 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:23 --> URI Class Initialized
INFO - 2023-04-25 05:36:23 --> Router Class Initialized
INFO - 2023-04-25 05:36:23 --> Output Class Initialized
INFO - 2023-04-25 05:36:23 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:23 --> Input Class Initialized
INFO - 2023-04-25 05:36:23 --> Language Class Initialized
INFO - 2023-04-25 05:36:23 --> Loader Class Initialized
INFO - 2023-04-25 05:36:23 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:23 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:23 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:23 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:23 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:23 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:23 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:23 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:23 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:23 --> Parser Class Initialized
INFO - 2023-04-25 05:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:23 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:23 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:23 --> Controller Class Initialized
DEBUG - 2023-04-25 05:36:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:23 --> Model Class Initialized
INFO - 2023-04-25 05:36:23 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:23 --> Total execution time: 0.0136
ERROR - 2023-04-25 05:36:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:50 --> Config Class Initialized
INFO - 2023-04-25 05:36:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:50 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:50 --> URI Class Initialized
INFO - 2023-04-25 05:36:50 --> Router Class Initialized
INFO - 2023-04-25 05:36:50 --> Output Class Initialized
INFO - 2023-04-25 05:36:50 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:50 --> Input Class Initialized
INFO - 2023-04-25 05:36:50 --> Language Class Initialized
INFO - 2023-04-25 05:36:50 --> Loader Class Initialized
INFO - 2023-04-25 05:36:50 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:50 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:50 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:50 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:50 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:50 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:50 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:50 --> Parser Class Initialized
INFO - 2023-04-25 05:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:50 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:50 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:50 --> Controller Class Initialized
INFO - 2023-04-25 05:36:50 --> Model Class Initialized
INFO - 2023-04-25 05:36:50 --> Model Class Initialized
INFO - 2023-04-25 05:36:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:36:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:36:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:36:50 --> Model Class Initialized
INFO - 2023-04-25 05:36:50 --> Model Class Initialized
INFO - 2023-04-25 05:36:50 --> Model Class Initialized
INFO - 2023-04-25 05:36:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:36:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:36:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:36:50 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:50 --> Total execution time: 0.1382
ERROR - 2023-04-25 05:36:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:51 --> Config Class Initialized
INFO - 2023-04-25 05:36:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:51 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:51 --> URI Class Initialized
INFO - 2023-04-25 05:36:51 --> Router Class Initialized
INFO - 2023-04-25 05:36:51 --> Output Class Initialized
INFO - 2023-04-25 05:36:51 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:51 --> Input Class Initialized
INFO - 2023-04-25 05:36:51 --> Language Class Initialized
INFO - 2023-04-25 05:36:51 --> Loader Class Initialized
INFO - 2023-04-25 05:36:51 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:51 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:51 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:51 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:51 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:51 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:51 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:51 --> Parser Class Initialized
INFO - 2023-04-25 05:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:51 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:51 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:51 --> Controller Class Initialized
INFO - 2023-04-25 05:36:51 --> Model Class Initialized
INFO - 2023-04-25 05:36:51 --> Model Class Initialized
INFO - 2023-04-25 05:36:51 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:51 --> Total execution time: 0.0499
ERROR - 2023-04-25 05:36:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:36:56 --> Config Class Initialized
INFO - 2023-04-25 05:36:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:36:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:36:56 --> Utf8 Class Initialized
INFO - 2023-04-25 05:36:56 --> URI Class Initialized
DEBUG - 2023-04-25 05:36:56 --> No URI present. Default controller set.
INFO - 2023-04-25 05:36:56 --> Router Class Initialized
INFO - 2023-04-25 05:36:56 --> Output Class Initialized
INFO - 2023-04-25 05:36:56 --> Security Class Initialized
DEBUG - 2023-04-25 05:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:36:56 --> Input Class Initialized
INFO - 2023-04-25 05:36:56 --> Language Class Initialized
INFO - 2023-04-25 05:36:56 --> Loader Class Initialized
INFO - 2023-04-25 05:36:56 --> Helper loaded: url_helper
INFO - 2023-04-25 05:36:56 --> Helper loaded: file_helper
INFO - 2023-04-25 05:36:56 --> Helper loaded: html_helper
INFO - 2023-04-25 05:36:56 --> Helper loaded: text_helper
INFO - 2023-04-25 05:36:56 --> Helper loaded: form_helper
INFO - 2023-04-25 05:36:56 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:36:56 --> Helper loaded: security_helper
INFO - 2023-04-25 05:36:56 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:36:56 --> Database Driver Class Initialized
INFO - 2023-04-25 05:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:36:56 --> Parser Class Initialized
INFO - 2023-04-25 05:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:36:56 --> Pagination Class Initialized
INFO - 2023-04-25 05:36:56 --> Form Validation Class Initialized
INFO - 2023-04-25 05:36:56 --> Controller Class Initialized
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
DEBUG - 2023-04-25 05:36:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
INFO - 2023-04-25 05:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:36:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:36:56 --> Model Class Initialized
INFO - 2023-04-25 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:36:57 --> Final output sent to browser
DEBUG - 2023-04-25 05:36:57 --> Total execution time: 0.1797
ERROR - 2023-04-25 05:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:39:37 --> Config Class Initialized
INFO - 2023-04-25 05:39:37 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:39:37 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:39:37 --> Utf8 Class Initialized
INFO - 2023-04-25 05:39:37 --> URI Class Initialized
INFO - 2023-04-25 05:39:37 --> Router Class Initialized
INFO - 2023-04-25 05:39:37 --> Output Class Initialized
INFO - 2023-04-25 05:39:37 --> Security Class Initialized
DEBUG - 2023-04-25 05:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:39:37 --> Input Class Initialized
INFO - 2023-04-25 05:39:37 --> Language Class Initialized
INFO - 2023-04-25 05:39:37 --> Loader Class Initialized
INFO - 2023-04-25 05:39:37 --> Helper loaded: url_helper
INFO - 2023-04-25 05:39:37 --> Helper loaded: file_helper
INFO - 2023-04-25 05:39:37 --> Helper loaded: html_helper
INFO - 2023-04-25 05:39:37 --> Helper loaded: text_helper
INFO - 2023-04-25 05:39:37 --> Helper loaded: form_helper
INFO - 2023-04-25 05:39:37 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:39:37 --> Helper loaded: security_helper
INFO - 2023-04-25 05:39:37 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:39:37 --> Database Driver Class Initialized
INFO - 2023-04-25 05:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:39:37 --> Parser Class Initialized
INFO - 2023-04-25 05:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:39:37 --> Pagination Class Initialized
INFO - 2023-04-25 05:39:37 --> Form Validation Class Initialized
INFO - 2023-04-25 05:39:37 --> Controller Class Initialized
DEBUG - 2023-04-25 05:39:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:37 --> Model Class Initialized
DEBUG - 2023-04-25 05:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:37 --> Model Class Initialized
DEBUG - 2023-04-25 05:39:37 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:37 --> Model Class Initialized
INFO - 2023-04-25 05:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-25 05:39:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:39:38 --> Model Class Initialized
INFO - 2023-04-25 05:39:38 --> Model Class Initialized
INFO - 2023-04-25 05:39:38 --> Model Class Initialized
INFO - 2023-04-25 05:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:39:38 --> Final output sent to browser
DEBUG - 2023-04-25 05:39:38 --> Total execution time: 0.1416
ERROR - 2023-04-25 05:39:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:39:38 --> Config Class Initialized
INFO - 2023-04-25 05:39:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:39:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:39:38 --> Utf8 Class Initialized
INFO - 2023-04-25 05:39:38 --> URI Class Initialized
INFO - 2023-04-25 05:39:38 --> Router Class Initialized
INFO - 2023-04-25 05:39:38 --> Output Class Initialized
INFO - 2023-04-25 05:39:38 --> Security Class Initialized
DEBUG - 2023-04-25 05:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:39:38 --> Input Class Initialized
INFO - 2023-04-25 05:39:38 --> Language Class Initialized
INFO - 2023-04-25 05:39:38 --> Loader Class Initialized
INFO - 2023-04-25 05:39:38 --> Helper loaded: url_helper
INFO - 2023-04-25 05:39:38 --> Helper loaded: file_helper
INFO - 2023-04-25 05:39:38 --> Helper loaded: html_helper
INFO - 2023-04-25 05:39:38 --> Helper loaded: text_helper
INFO - 2023-04-25 05:39:38 --> Helper loaded: form_helper
INFO - 2023-04-25 05:39:38 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:39:38 --> Helper loaded: security_helper
INFO - 2023-04-25 05:39:38 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:39:38 --> Database Driver Class Initialized
INFO - 2023-04-25 05:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:39:38 --> Parser Class Initialized
INFO - 2023-04-25 05:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:39:38 --> Pagination Class Initialized
INFO - 2023-04-25 05:39:38 --> Form Validation Class Initialized
INFO - 2023-04-25 05:39:38 --> Controller Class Initialized
DEBUG - 2023-04-25 05:39:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:38 --> Model Class Initialized
DEBUG - 2023-04-25 05:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:38 --> Model Class Initialized
INFO - 2023-04-25 05:39:38 --> Final output sent to browser
DEBUG - 2023-04-25 05:39:38 --> Total execution time: 0.0324
ERROR - 2023-04-25 05:39:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:39:44 --> Config Class Initialized
INFO - 2023-04-25 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-25 05:39:44 --> URI Class Initialized
INFO - 2023-04-25 05:39:44 --> Router Class Initialized
INFO - 2023-04-25 05:39:44 --> Output Class Initialized
INFO - 2023-04-25 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-25 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:39:44 --> Input Class Initialized
INFO - 2023-04-25 05:39:44 --> Language Class Initialized
INFO - 2023-04-25 05:39:44 --> Loader Class Initialized
INFO - 2023-04-25 05:39:44 --> Helper loaded: url_helper
INFO - 2023-04-25 05:39:44 --> Helper loaded: file_helper
INFO - 2023-04-25 05:39:44 --> Helper loaded: html_helper
INFO - 2023-04-25 05:39:44 --> Helper loaded: text_helper
INFO - 2023-04-25 05:39:44 --> Helper loaded: form_helper
INFO - 2023-04-25 05:39:44 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:39:44 --> Helper loaded: security_helper
INFO - 2023-04-25 05:39:44 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-25 05:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:39:44 --> Parser Class Initialized
INFO - 2023-04-25 05:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:39:44 --> Pagination Class Initialized
INFO - 2023-04-25 05:39:44 --> Form Validation Class Initialized
INFO - 2023-04-25 05:39:44 --> Controller Class Initialized
DEBUG - 2023-04-25 05:39:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:44 --> Model Class Initialized
DEBUG - 2023-04-25 05:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:44 --> Model Class Initialized
INFO - 2023-04-25 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-25 05:39:44 --> Total execution time: 0.0296
ERROR - 2023-04-25 05:39:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:39:57 --> Config Class Initialized
INFO - 2023-04-25 05:39:57 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:39:57 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:39:57 --> Utf8 Class Initialized
INFO - 2023-04-25 05:39:57 --> URI Class Initialized
INFO - 2023-04-25 05:39:57 --> Router Class Initialized
INFO - 2023-04-25 05:39:57 --> Output Class Initialized
INFO - 2023-04-25 05:39:57 --> Security Class Initialized
DEBUG - 2023-04-25 05:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:39:57 --> Input Class Initialized
INFO - 2023-04-25 05:39:57 --> Language Class Initialized
INFO - 2023-04-25 05:39:57 --> Loader Class Initialized
INFO - 2023-04-25 05:39:57 --> Helper loaded: url_helper
INFO - 2023-04-25 05:39:57 --> Helper loaded: file_helper
INFO - 2023-04-25 05:39:57 --> Helper loaded: html_helper
INFO - 2023-04-25 05:39:57 --> Helper loaded: text_helper
INFO - 2023-04-25 05:39:57 --> Helper loaded: form_helper
INFO - 2023-04-25 05:39:57 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:39:57 --> Helper loaded: security_helper
INFO - 2023-04-25 05:39:57 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:39:57 --> Database Driver Class Initialized
INFO - 2023-04-25 05:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:39:57 --> Parser Class Initialized
INFO - 2023-04-25 05:39:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:39:57 --> Pagination Class Initialized
INFO - 2023-04-25 05:39:57 --> Form Validation Class Initialized
INFO - 2023-04-25 05:39:57 --> Controller Class Initialized
INFO - 2023-04-25 05:39:57 --> Model Class Initialized
DEBUG - 2023-04-25 05:39:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:39:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:57 --> Model Class Initialized
INFO - 2023-04-25 05:39:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-25 05:39:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:39:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:39:57 --> Model Class Initialized
INFO - 2023-04-25 05:39:57 --> Model Class Initialized
INFO - 2023-04-25 05:39:57 --> Model Class Initialized
INFO - 2023-04-25 05:39:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:39:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:39:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:39:58 --> Final output sent to browser
DEBUG - 2023-04-25 05:39:58 --> Total execution time: 0.1579
ERROR - 2023-04-25 05:39:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:39:58 --> Config Class Initialized
INFO - 2023-04-25 05:39:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:39:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:39:58 --> Utf8 Class Initialized
INFO - 2023-04-25 05:39:58 --> URI Class Initialized
INFO - 2023-04-25 05:39:58 --> Router Class Initialized
INFO - 2023-04-25 05:39:58 --> Output Class Initialized
INFO - 2023-04-25 05:39:58 --> Security Class Initialized
DEBUG - 2023-04-25 05:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:39:58 --> Input Class Initialized
INFO - 2023-04-25 05:39:58 --> Language Class Initialized
INFO - 2023-04-25 05:39:58 --> Loader Class Initialized
INFO - 2023-04-25 05:39:58 --> Helper loaded: url_helper
INFO - 2023-04-25 05:39:58 --> Helper loaded: file_helper
INFO - 2023-04-25 05:39:58 --> Helper loaded: html_helper
INFO - 2023-04-25 05:39:58 --> Helper loaded: text_helper
INFO - 2023-04-25 05:39:58 --> Helper loaded: form_helper
INFO - 2023-04-25 05:39:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:39:58 --> Helper loaded: security_helper
INFO - 2023-04-25 05:39:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:39:58 --> Database Driver Class Initialized
INFO - 2023-04-25 05:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:39:58 --> Parser Class Initialized
INFO - 2023-04-25 05:39:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:39:58 --> Pagination Class Initialized
INFO - 2023-04-25 05:39:58 --> Form Validation Class Initialized
INFO - 2023-04-25 05:39:58 --> Controller Class Initialized
INFO - 2023-04-25 05:39:58 --> Model Class Initialized
DEBUG - 2023-04-25 05:39:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:39:58 --> Model Class Initialized
INFO - 2023-04-25 05:39:58 --> Final output sent to browser
DEBUG - 2023-04-25 05:39:58 --> Total execution time: 0.0268
ERROR - 2023-04-25 05:40:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:40:14 --> Config Class Initialized
INFO - 2023-04-25 05:40:14 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:40:14 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:40:14 --> Utf8 Class Initialized
INFO - 2023-04-25 05:40:14 --> URI Class Initialized
INFO - 2023-04-25 05:40:14 --> Router Class Initialized
INFO - 2023-04-25 05:40:14 --> Output Class Initialized
INFO - 2023-04-25 05:40:14 --> Security Class Initialized
DEBUG - 2023-04-25 05:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:40:14 --> Input Class Initialized
INFO - 2023-04-25 05:40:14 --> Language Class Initialized
INFO - 2023-04-25 05:40:14 --> Loader Class Initialized
INFO - 2023-04-25 05:40:14 --> Helper loaded: url_helper
INFO - 2023-04-25 05:40:14 --> Helper loaded: file_helper
INFO - 2023-04-25 05:40:14 --> Helper loaded: html_helper
INFO - 2023-04-25 05:40:14 --> Helper loaded: text_helper
INFO - 2023-04-25 05:40:14 --> Helper loaded: form_helper
INFO - 2023-04-25 05:40:14 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:40:14 --> Helper loaded: security_helper
INFO - 2023-04-25 05:40:14 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:40:14 --> Database Driver Class Initialized
INFO - 2023-04-25 05:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:40:14 --> Parser Class Initialized
INFO - 2023-04-25 05:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:40:14 --> Pagination Class Initialized
INFO - 2023-04-25 05:40:14 --> Form Validation Class Initialized
INFO - 2023-04-25 05:40:14 --> Controller Class Initialized
INFO - 2023-04-25 05:40:14 --> Model Class Initialized
DEBUG - 2023-04-25 05:40:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:14 --> Model Class Initialized
INFO - 2023-04-25 05:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-04-25 05:40:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:40:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:40:14 --> Model Class Initialized
INFO - 2023-04-25 05:40:14 --> Model Class Initialized
INFO - 2023-04-25 05:40:14 --> Model Class Initialized
INFO - 2023-04-25 05:40:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:40:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:40:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:40:15 --> Final output sent to browser
DEBUG - 2023-04-25 05:40:15 --> Total execution time: 0.1444
ERROR - 2023-04-25 05:40:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:40:15 --> Config Class Initialized
INFO - 2023-04-25 05:40:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:40:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:40:15 --> Utf8 Class Initialized
INFO - 2023-04-25 05:40:15 --> URI Class Initialized
INFO - 2023-04-25 05:40:15 --> Router Class Initialized
INFO - 2023-04-25 05:40:15 --> Output Class Initialized
INFO - 2023-04-25 05:40:15 --> Security Class Initialized
DEBUG - 2023-04-25 05:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:40:15 --> Input Class Initialized
INFO - 2023-04-25 05:40:15 --> Language Class Initialized
INFO - 2023-04-25 05:40:15 --> Loader Class Initialized
INFO - 2023-04-25 05:40:15 --> Helper loaded: url_helper
INFO - 2023-04-25 05:40:15 --> Helper loaded: file_helper
INFO - 2023-04-25 05:40:15 --> Helper loaded: html_helper
INFO - 2023-04-25 05:40:15 --> Helper loaded: text_helper
INFO - 2023-04-25 05:40:15 --> Helper loaded: form_helper
INFO - 2023-04-25 05:40:15 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:40:15 --> Helper loaded: security_helper
INFO - 2023-04-25 05:40:15 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:40:15 --> Database Driver Class Initialized
INFO - 2023-04-25 05:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:40:15 --> Parser Class Initialized
INFO - 2023-04-25 05:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:40:15 --> Pagination Class Initialized
INFO - 2023-04-25 05:40:15 --> Form Validation Class Initialized
INFO - 2023-04-25 05:40:15 --> Controller Class Initialized
INFO - 2023-04-25 05:40:15 --> Model Class Initialized
DEBUG - 2023-04-25 05:40:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:15 --> Model Class Initialized
INFO - 2023-04-25 05:40:15 --> Final output sent to browser
DEBUG - 2023-04-25 05:40:15 --> Total execution time: 0.0307
ERROR - 2023-04-25 05:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:40:23 --> Config Class Initialized
INFO - 2023-04-25 05:40:23 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:40:23 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:40:23 --> Utf8 Class Initialized
INFO - 2023-04-25 05:40:23 --> URI Class Initialized
INFO - 2023-04-25 05:40:23 --> Router Class Initialized
INFO - 2023-04-25 05:40:23 --> Output Class Initialized
INFO - 2023-04-25 05:40:23 --> Security Class Initialized
DEBUG - 2023-04-25 05:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:40:23 --> Input Class Initialized
INFO - 2023-04-25 05:40:23 --> Language Class Initialized
INFO - 2023-04-25 05:40:23 --> Loader Class Initialized
INFO - 2023-04-25 05:40:23 --> Helper loaded: url_helper
INFO - 2023-04-25 05:40:23 --> Helper loaded: file_helper
INFO - 2023-04-25 05:40:23 --> Helper loaded: html_helper
INFO - 2023-04-25 05:40:23 --> Helper loaded: text_helper
INFO - 2023-04-25 05:40:23 --> Helper loaded: form_helper
INFO - 2023-04-25 05:40:23 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:40:23 --> Helper loaded: security_helper
INFO - 2023-04-25 05:40:23 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:40:23 --> Database Driver Class Initialized
INFO - 2023-04-25 05:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:40:23 --> Parser Class Initialized
INFO - 2023-04-25 05:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:40:23 --> Pagination Class Initialized
INFO - 2023-04-25 05:40:23 --> Form Validation Class Initialized
INFO - 2023-04-25 05:40:23 --> Controller Class Initialized
INFO - 2023-04-25 05:40:23 --> Model Class Initialized
INFO - 2023-04-25 05:40:23 --> Model Class Initialized
INFO - 2023-04-25 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-04-25 05:40:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:40:23 --> Model Class Initialized
INFO - 2023-04-25 05:40:23 --> Model Class Initialized
INFO - 2023-04-25 05:40:23 --> Model Class Initialized
INFO - 2023-04-25 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:40:23 --> Final output sent to browser
DEBUG - 2023-04-25 05:40:23 --> Total execution time: 0.1251
ERROR - 2023-04-25 05:40:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:40:24 --> Config Class Initialized
INFO - 2023-04-25 05:40:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:40:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:40:24 --> Utf8 Class Initialized
INFO - 2023-04-25 05:40:24 --> URI Class Initialized
INFO - 2023-04-25 05:40:24 --> Router Class Initialized
INFO - 2023-04-25 05:40:24 --> Output Class Initialized
INFO - 2023-04-25 05:40:24 --> Security Class Initialized
DEBUG - 2023-04-25 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:40:24 --> Input Class Initialized
INFO - 2023-04-25 05:40:24 --> Language Class Initialized
INFO - 2023-04-25 05:40:24 --> Loader Class Initialized
INFO - 2023-04-25 05:40:24 --> Helper loaded: url_helper
INFO - 2023-04-25 05:40:24 --> Helper loaded: file_helper
INFO - 2023-04-25 05:40:24 --> Helper loaded: html_helper
INFO - 2023-04-25 05:40:24 --> Helper loaded: text_helper
INFO - 2023-04-25 05:40:24 --> Helper loaded: form_helper
INFO - 2023-04-25 05:40:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:40:24 --> Helper loaded: security_helper
INFO - 2023-04-25 05:40:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:40:24 --> Database Driver Class Initialized
INFO - 2023-04-25 05:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:40:24 --> Parser Class Initialized
INFO - 2023-04-25 05:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:40:24 --> Pagination Class Initialized
INFO - 2023-04-25 05:40:24 --> Form Validation Class Initialized
INFO - 2023-04-25 05:40:24 --> Controller Class Initialized
INFO - 2023-04-25 05:40:24 --> Model Class Initialized
INFO - 2023-04-25 05:40:24 --> Model Class Initialized
INFO - 2023-04-25 05:40:24 --> Final output sent to browser
DEBUG - 2023-04-25 05:40:24 --> Total execution time: 0.0445
ERROR - 2023-04-25 05:40:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:40:40 --> Config Class Initialized
INFO - 2023-04-25 05:40:40 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:40:40 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:40:40 --> Utf8 Class Initialized
INFO - 2023-04-25 05:40:40 --> URI Class Initialized
DEBUG - 2023-04-25 05:40:40 --> No URI present. Default controller set.
INFO - 2023-04-25 05:40:40 --> Router Class Initialized
INFO - 2023-04-25 05:40:40 --> Output Class Initialized
INFO - 2023-04-25 05:40:40 --> Security Class Initialized
DEBUG - 2023-04-25 05:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:40:40 --> Input Class Initialized
INFO - 2023-04-25 05:40:40 --> Language Class Initialized
INFO - 2023-04-25 05:40:40 --> Loader Class Initialized
INFO - 2023-04-25 05:40:40 --> Helper loaded: url_helper
INFO - 2023-04-25 05:40:40 --> Helper loaded: file_helper
INFO - 2023-04-25 05:40:40 --> Helper loaded: html_helper
INFO - 2023-04-25 05:40:40 --> Helper loaded: text_helper
INFO - 2023-04-25 05:40:40 --> Helper loaded: form_helper
INFO - 2023-04-25 05:40:40 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:40:40 --> Helper loaded: security_helper
INFO - 2023-04-25 05:40:40 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:40:40 --> Database Driver Class Initialized
INFO - 2023-04-25 05:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:40:40 --> Parser Class Initialized
INFO - 2023-04-25 05:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:40:40 --> Pagination Class Initialized
INFO - 2023-04-25 05:40:40 --> Form Validation Class Initialized
INFO - 2023-04-25 05:40:40 --> Controller Class Initialized
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
DEBUG - 2023-04-25 05:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
DEBUG - 2023-04-25 05:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
DEBUG - 2023-04-25 05:40:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
INFO - 2023-04-25 05:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:40:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:40:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:40:40 --> Model Class Initialized
INFO - 2023-04-25 05:40:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:40:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:40:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:40:41 --> Final output sent to browser
DEBUG - 2023-04-25 05:40:41 --> Total execution time: 0.1816
ERROR - 2023-04-25 05:41:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:41:07 --> Config Class Initialized
INFO - 2023-04-25 05:41:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:41:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:41:07 --> Utf8 Class Initialized
INFO - 2023-04-25 05:41:07 --> URI Class Initialized
DEBUG - 2023-04-25 05:41:07 --> No URI present. Default controller set.
INFO - 2023-04-25 05:41:07 --> Router Class Initialized
INFO - 2023-04-25 05:41:07 --> Output Class Initialized
INFO - 2023-04-25 05:41:07 --> Security Class Initialized
DEBUG - 2023-04-25 05:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:41:07 --> Input Class Initialized
INFO - 2023-04-25 05:41:07 --> Language Class Initialized
INFO - 2023-04-25 05:41:07 --> Loader Class Initialized
INFO - 2023-04-25 05:41:07 --> Helper loaded: url_helper
INFO - 2023-04-25 05:41:07 --> Helper loaded: file_helper
INFO - 2023-04-25 05:41:07 --> Helper loaded: html_helper
INFO - 2023-04-25 05:41:07 --> Helper loaded: text_helper
INFO - 2023-04-25 05:41:07 --> Helper loaded: form_helper
INFO - 2023-04-25 05:41:07 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:41:07 --> Helper loaded: security_helper
INFO - 2023-04-25 05:41:07 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:41:07 --> Database Driver Class Initialized
INFO - 2023-04-25 05:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:41:07 --> Parser Class Initialized
INFO - 2023-04-25 05:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:41:07 --> Pagination Class Initialized
INFO - 2023-04-25 05:41:07 --> Form Validation Class Initialized
INFO - 2023-04-25 05:41:07 --> Controller Class Initialized
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
DEBUG - 2023-04-25 05:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
DEBUG - 2023-04-25 05:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
DEBUG - 2023-04-25 05:41:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
INFO - 2023-04-25 05:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:41:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:41:07 --> Model Class Initialized
INFO - 2023-04-25 05:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:41:07 --> Final output sent to browser
DEBUG - 2023-04-25 05:41:07 --> Total execution time: 0.1865
ERROR - 2023-04-25 05:42:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:42:12 --> Config Class Initialized
INFO - 2023-04-25 05:42:12 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:42:12 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:42:12 --> Utf8 Class Initialized
INFO - 2023-04-25 05:42:12 --> URI Class Initialized
INFO - 2023-04-25 05:42:12 --> Router Class Initialized
INFO - 2023-04-25 05:42:12 --> Output Class Initialized
INFO - 2023-04-25 05:42:12 --> Security Class Initialized
DEBUG - 2023-04-25 05:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:42:12 --> Input Class Initialized
INFO - 2023-04-25 05:42:12 --> Language Class Initialized
INFO - 2023-04-25 05:42:12 --> Loader Class Initialized
INFO - 2023-04-25 05:42:12 --> Helper loaded: url_helper
INFO - 2023-04-25 05:42:12 --> Helper loaded: file_helper
INFO - 2023-04-25 05:42:12 --> Helper loaded: html_helper
INFO - 2023-04-25 05:42:12 --> Helper loaded: text_helper
INFO - 2023-04-25 05:42:12 --> Helper loaded: form_helper
INFO - 2023-04-25 05:42:12 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:42:12 --> Helper loaded: security_helper
INFO - 2023-04-25 05:42:12 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:42:12 --> Database Driver Class Initialized
INFO - 2023-04-25 05:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:42:12 --> Parser Class Initialized
INFO - 2023-04-25 05:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:42:12 --> Pagination Class Initialized
INFO - 2023-04-25 05:42:12 --> Form Validation Class Initialized
INFO - 2023-04-25 05:42:12 --> Controller Class Initialized
INFO - 2023-04-25 05:42:12 --> Model Class Initialized
INFO - 2023-04-25 05:42:12 --> Model Class Initialized
ERROR - 2023-04-25 05:42:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-25 05:42:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-25 05:42:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:42:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:42:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:42:12 --> Model Class Initialized
INFO - 2023-04-25 05:42:12 --> Model Class Initialized
INFO - 2023-04-25 05:42:12 --> Model Class Initialized
INFO - 2023-04-25 05:42:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:42:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:42:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:42:12 --> Final output sent to browser
DEBUG - 2023-04-25 05:42:12 --> Total execution time: 0.1563
ERROR - 2023-04-25 05:42:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:42:24 --> Config Class Initialized
INFO - 2023-04-25 05:42:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:42:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:42:24 --> Utf8 Class Initialized
INFO - 2023-04-25 05:42:24 --> URI Class Initialized
INFO - 2023-04-25 05:42:24 --> Router Class Initialized
INFO - 2023-04-25 05:42:24 --> Output Class Initialized
INFO - 2023-04-25 05:42:24 --> Security Class Initialized
DEBUG - 2023-04-25 05:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:42:24 --> Input Class Initialized
INFO - 2023-04-25 05:42:24 --> Language Class Initialized
INFO - 2023-04-25 05:42:24 --> Loader Class Initialized
INFO - 2023-04-25 05:42:24 --> Helper loaded: url_helper
INFO - 2023-04-25 05:42:24 --> Helper loaded: file_helper
INFO - 2023-04-25 05:42:24 --> Helper loaded: html_helper
INFO - 2023-04-25 05:42:24 --> Helper loaded: text_helper
INFO - 2023-04-25 05:42:24 --> Helper loaded: form_helper
INFO - 2023-04-25 05:42:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:42:24 --> Helper loaded: security_helper
INFO - 2023-04-25 05:42:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:42:24 --> Database Driver Class Initialized
INFO - 2023-04-25 05:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:42:24 --> Parser Class Initialized
INFO - 2023-04-25 05:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:42:24 --> Pagination Class Initialized
INFO - 2023-04-25 05:42:24 --> Form Validation Class Initialized
INFO - 2023-04-25 05:42:24 --> Controller Class Initialized
INFO - 2023-04-25 05:42:24 --> Model Class Initialized
INFO - 2023-04-25 05:42:24 --> Final output sent to browser
DEBUG - 2023-04-25 05:42:24 --> Total execution time: 0.0188
ERROR - 2023-04-25 05:42:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:42:27 --> Config Class Initialized
INFO - 2023-04-25 05:42:27 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:42:27 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:42:27 --> Utf8 Class Initialized
INFO - 2023-04-25 05:42:27 --> URI Class Initialized
INFO - 2023-04-25 05:42:27 --> Router Class Initialized
INFO - 2023-04-25 05:42:27 --> Output Class Initialized
INFO - 2023-04-25 05:42:27 --> Security Class Initialized
DEBUG - 2023-04-25 05:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:42:27 --> Input Class Initialized
INFO - 2023-04-25 05:42:27 --> Language Class Initialized
INFO - 2023-04-25 05:42:27 --> Loader Class Initialized
INFO - 2023-04-25 05:42:27 --> Helper loaded: url_helper
INFO - 2023-04-25 05:42:27 --> Helper loaded: file_helper
INFO - 2023-04-25 05:42:27 --> Helper loaded: html_helper
INFO - 2023-04-25 05:42:27 --> Helper loaded: text_helper
INFO - 2023-04-25 05:42:27 --> Helper loaded: form_helper
INFO - 2023-04-25 05:42:27 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:42:27 --> Helper loaded: security_helper
INFO - 2023-04-25 05:42:27 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:42:27 --> Database Driver Class Initialized
INFO - 2023-04-25 05:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:42:27 --> Parser Class Initialized
INFO - 2023-04-25 05:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:42:27 --> Pagination Class Initialized
INFO - 2023-04-25 05:42:27 --> Form Validation Class Initialized
INFO - 2023-04-25 05:42:27 --> Controller Class Initialized
INFO - 2023-04-25 05:42:27 --> Model Class Initialized
DEBUG - 2023-04-25 05:42:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:42:27 --> Model Class Initialized
DEBUG - 2023-04-25 05:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:42:27 --> Model Class Initialized
INFO - 2023-04-25 05:42:27 --> Final output sent to browser
DEBUG - 2023-04-25 05:42:27 --> Total execution time: 0.0197
ERROR - 2023-04-25 05:44:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:44:08 --> Config Class Initialized
INFO - 2023-04-25 05:44:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:44:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:44:08 --> Utf8 Class Initialized
INFO - 2023-04-25 05:44:08 --> URI Class Initialized
DEBUG - 2023-04-25 05:44:08 --> No URI present. Default controller set.
INFO - 2023-04-25 05:44:08 --> Router Class Initialized
INFO - 2023-04-25 05:44:08 --> Output Class Initialized
INFO - 2023-04-25 05:44:08 --> Security Class Initialized
DEBUG - 2023-04-25 05:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:44:08 --> Input Class Initialized
INFO - 2023-04-25 05:44:08 --> Language Class Initialized
INFO - 2023-04-25 05:44:08 --> Loader Class Initialized
INFO - 2023-04-25 05:44:08 --> Helper loaded: url_helper
INFO - 2023-04-25 05:44:08 --> Helper loaded: file_helper
INFO - 2023-04-25 05:44:08 --> Helper loaded: html_helper
INFO - 2023-04-25 05:44:08 --> Helper loaded: text_helper
INFO - 2023-04-25 05:44:08 --> Helper loaded: form_helper
INFO - 2023-04-25 05:44:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:44:08 --> Helper loaded: security_helper
INFO - 2023-04-25 05:44:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:44:08 --> Database Driver Class Initialized
INFO - 2023-04-25 05:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:44:08 --> Parser Class Initialized
INFO - 2023-04-25 05:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:44:08 --> Pagination Class Initialized
INFO - 2023-04-25 05:44:08 --> Form Validation Class Initialized
INFO - 2023-04-25 05:44:08 --> Controller Class Initialized
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
INFO - 2023-04-25 05:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:44:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:44:08 --> Model Class Initialized
INFO - 2023-04-25 05:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:44:08 --> Final output sent to browser
DEBUG - 2023-04-25 05:44:08 --> Total execution time: 0.1608
ERROR - 2023-04-25 05:44:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:44:41 --> Config Class Initialized
INFO - 2023-04-25 05:44:41 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:44:41 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:44:41 --> Utf8 Class Initialized
INFO - 2023-04-25 05:44:41 --> URI Class Initialized
INFO - 2023-04-25 05:44:41 --> Router Class Initialized
INFO - 2023-04-25 05:44:41 --> Output Class Initialized
INFO - 2023-04-25 05:44:41 --> Security Class Initialized
DEBUG - 2023-04-25 05:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:44:41 --> Input Class Initialized
INFO - 2023-04-25 05:44:41 --> Language Class Initialized
INFO - 2023-04-25 05:44:41 --> Loader Class Initialized
INFO - 2023-04-25 05:44:41 --> Helper loaded: url_helper
INFO - 2023-04-25 05:44:41 --> Helper loaded: file_helper
INFO - 2023-04-25 05:44:41 --> Helper loaded: html_helper
INFO - 2023-04-25 05:44:41 --> Helper loaded: text_helper
INFO - 2023-04-25 05:44:41 --> Helper loaded: form_helper
INFO - 2023-04-25 05:44:41 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:44:41 --> Helper loaded: security_helper
INFO - 2023-04-25 05:44:41 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:44:41 --> Database Driver Class Initialized
INFO - 2023-04-25 05:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:44:41 --> Parser Class Initialized
INFO - 2023-04-25 05:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:44:41 --> Pagination Class Initialized
INFO - 2023-04-25 05:44:41 --> Form Validation Class Initialized
INFO - 2023-04-25 05:44:41 --> Controller Class Initialized
INFO - 2023-04-25 05:44:41 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:41 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:41 --> Model Class Initialized
INFO - 2023-04-25 05:44:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 05:44:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:44:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:44:41 --> Model Class Initialized
INFO - 2023-04-25 05:44:41 --> Model Class Initialized
INFO - 2023-04-25 05:44:41 --> Model Class Initialized
INFO - 2023-04-25 05:44:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:44:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:44:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:44:41 --> Final output sent to browser
DEBUG - 2023-04-25 05:44:41 --> Total execution time: 0.1430
ERROR - 2023-04-25 05:44:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:44:42 --> Config Class Initialized
INFO - 2023-04-25 05:44:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:44:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:44:42 --> Utf8 Class Initialized
INFO - 2023-04-25 05:44:42 --> URI Class Initialized
INFO - 2023-04-25 05:44:42 --> Router Class Initialized
INFO - 2023-04-25 05:44:42 --> Output Class Initialized
INFO - 2023-04-25 05:44:42 --> Security Class Initialized
DEBUG - 2023-04-25 05:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:44:42 --> Input Class Initialized
INFO - 2023-04-25 05:44:42 --> Language Class Initialized
INFO - 2023-04-25 05:44:42 --> Loader Class Initialized
INFO - 2023-04-25 05:44:42 --> Helper loaded: url_helper
INFO - 2023-04-25 05:44:42 --> Helper loaded: file_helper
INFO - 2023-04-25 05:44:42 --> Helper loaded: html_helper
INFO - 2023-04-25 05:44:42 --> Helper loaded: text_helper
INFO - 2023-04-25 05:44:42 --> Helper loaded: form_helper
INFO - 2023-04-25 05:44:42 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:44:42 --> Helper loaded: security_helper
INFO - 2023-04-25 05:44:42 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:44:42 --> Database Driver Class Initialized
INFO - 2023-04-25 05:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:44:42 --> Parser Class Initialized
INFO - 2023-04-25 05:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:44:42 --> Pagination Class Initialized
INFO - 2023-04-25 05:44:42 --> Form Validation Class Initialized
INFO - 2023-04-25 05:44:42 --> Controller Class Initialized
INFO - 2023-04-25 05:44:42 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:42 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:42 --> Model Class Initialized
INFO - 2023-04-25 05:44:42 --> Final output sent to browser
DEBUG - 2023-04-25 05:44:42 --> Total execution time: 0.0591
ERROR - 2023-04-25 05:44:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:44:44 --> Config Class Initialized
INFO - 2023-04-25 05:44:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:44:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:44:44 --> Utf8 Class Initialized
INFO - 2023-04-25 05:44:44 --> URI Class Initialized
INFO - 2023-04-25 05:44:44 --> Router Class Initialized
INFO - 2023-04-25 05:44:44 --> Output Class Initialized
INFO - 2023-04-25 05:44:44 --> Security Class Initialized
DEBUG - 2023-04-25 05:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:44:44 --> Input Class Initialized
INFO - 2023-04-25 05:44:44 --> Language Class Initialized
INFO - 2023-04-25 05:44:44 --> Loader Class Initialized
INFO - 2023-04-25 05:44:45 --> Helper loaded: url_helper
INFO - 2023-04-25 05:44:45 --> Helper loaded: file_helper
INFO - 2023-04-25 05:44:45 --> Helper loaded: html_helper
INFO - 2023-04-25 05:44:45 --> Helper loaded: text_helper
INFO - 2023-04-25 05:44:45 --> Helper loaded: form_helper
INFO - 2023-04-25 05:44:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:44:45 --> Helper loaded: security_helper
INFO - 2023-04-25 05:44:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:44:45 --> Database Driver Class Initialized
INFO - 2023-04-25 05:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:44:45 --> Parser Class Initialized
INFO - 2023-04-25 05:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:44:45 --> Pagination Class Initialized
INFO - 2023-04-25 05:44:45 --> Form Validation Class Initialized
INFO - 2023-04-25 05:44:45 --> Controller Class Initialized
INFO - 2023-04-25 05:44:45 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:45 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:45 --> Model Class Initialized
DEBUG - 2023-04-25 05:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-04-25 05:44:45 --> Occational class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
DEBUG - 2023-04-25 05:44:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:44:45 --> Model Class Initialized
INFO - 2023-04-25 05:44:45 --> Model Class Initialized
INFO - 2023-04-25 05:44:45 --> Model Class Initialized
INFO - 2023-04-25 05:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:44:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:44:45 --> Final output sent to browser
DEBUG - 2023-04-25 05:44:45 --> Total execution time: 0.1628
ERROR - 2023-04-25 05:45:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:04 --> Config Class Initialized
INFO - 2023-04-25 05:45:04 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:04 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:04 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:04 --> URI Class Initialized
INFO - 2023-04-25 05:45:04 --> Router Class Initialized
INFO - 2023-04-25 05:45:04 --> Output Class Initialized
INFO - 2023-04-25 05:45:04 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:04 --> Input Class Initialized
INFO - 2023-04-25 05:45:04 --> Language Class Initialized
INFO - 2023-04-25 05:45:04 --> Loader Class Initialized
INFO - 2023-04-25 05:45:04 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:04 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:04 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:04 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:04 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:04 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:04 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:04 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:04 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:04 --> Parser Class Initialized
INFO - 2023-04-25 05:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:04 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:04 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:04 --> Controller Class Initialized
INFO - 2023-04-25 05:45:04 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:04 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:04 --> Model Class Initialized
INFO - 2023-04-25 05:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 05:45:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:45:04 --> Model Class Initialized
INFO - 2023-04-25 05:45:04 --> Model Class Initialized
INFO - 2023-04-25 05:45:04 --> Model Class Initialized
INFO - 2023-04-25 05:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:45:04 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:04 --> Total execution time: 0.1378
ERROR - 2023-04-25 05:45:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:05 --> Config Class Initialized
INFO - 2023-04-25 05:45:05 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:05 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:05 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:05 --> URI Class Initialized
INFO - 2023-04-25 05:45:05 --> Router Class Initialized
INFO - 2023-04-25 05:45:05 --> Output Class Initialized
INFO - 2023-04-25 05:45:05 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:05 --> Input Class Initialized
INFO - 2023-04-25 05:45:05 --> Language Class Initialized
INFO - 2023-04-25 05:45:05 --> Loader Class Initialized
INFO - 2023-04-25 05:45:05 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:05 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:05 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:05 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:05 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:05 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:05 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:05 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:05 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:05 --> Parser Class Initialized
INFO - 2023-04-25 05:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:05 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:05 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:05 --> Controller Class Initialized
INFO - 2023-04-25 05:45:05 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:05 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:05 --> Model Class Initialized
INFO - 2023-04-25 05:45:05 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:05 --> Total execution time: 0.0498
ERROR - 2023-04-25 05:45:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:11 --> Config Class Initialized
INFO - 2023-04-25 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:11 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:11 --> URI Class Initialized
INFO - 2023-04-25 05:45:11 --> Router Class Initialized
INFO - 2023-04-25 05:45:11 --> Output Class Initialized
INFO - 2023-04-25 05:45:11 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:11 --> Input Class Initialized
INFO - 2023-04-25 05:45:11 --> Language Class Initialized
INFO - 2023-04-25 05:45:11 --> Loader Class Initialized
INFO - 2023-04-25 05:45:11 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:11 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:11 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:11 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:11 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:11 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:11 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:11 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:11 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:11 --> Parser Class Initialized
INFO - 2023-04-25 05:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:11 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:11 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:11 --> Controller Class Initialized
INFO - 2023-04-25 05:45:11 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:11 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:11 --> Model Class Initialized
INFO - 2023-04-25 05:45:11 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:11 --> Total execution time: 0.0455
ERROR - 2023-04-25 05:45:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:13 --> Config Class Initialized
INFO - 2023-04-25 05:45:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:13 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:13 --> URI Class Initialized
INFO - 2023-04-25 05:45:13 --> Router Class Initialized
INFO - 2023-04-25 05:45:13 --> Output Class Initialized
INFO - 2023-04-25 05:45:13 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:13 --> Input Class Initialized
INFO - 2023-04-25 05:45:13 --> Language Class Initialized
INFO - 2023-04-25 05:45:13 --> Loader Class Initialized
INFO - 2023-04-25 05:45:13 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:13 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:13 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:13 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:13 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:13 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:13 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:13 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:13 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:13 --> Parser Class Initialized
INFO - 2023-04-25 05:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:13 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:13 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:13 --> Controller Class Initialized
INFO - 2023-04-25 05:45:13 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:13 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:13 --> Model Class Initialized
INFO - 2023-04-25 05:45:13 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:13 --> Total execution time: 0.0575
ERROR - 2023-04-25 05:45:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:16 --> Config Class Initialized
INFO - 2023-04-25 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:16 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:16 --> URI Class Initialized
INFO - 2023-04-25 05:45:16 --> Router Class Initialized
INFO - 2023-04-25 05:45:16 --> Output Class Initialized
INFO - 2023-04-25 05:45:16 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:16 --> Input Class Initialized
INFO - 2023-04-25 05:45:16 --> Language Class Initialized
INFO - 2023-04-25 05:45:16 --> Loader Class Initialized
INFO - 2023-04-25 05:45:16 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:16 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:16 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:16 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:16 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:16 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:16 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:16 --> Parser Class Initialized
INFO - 2023-04-25 05:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:16 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:16 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:16 --> Controller Class Initialized
INFO - 2023-04-25 05:45:16 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:16 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:16 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-04-25 05:45:16 --> Occational class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
DEBUG - 2023-04-25 05:45:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:45:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:45:16 --> Model Class Initialized
INFO - 2023-04-25 05:45:16 --> Model Class Initialized
INFO - 2023-04-25 05:45:16 --> Model Class Initialized
INFO - 2023-04-25 05:45:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:45:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:45:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:45:16 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:16 --> Total execution time: 0.1609
ERROR - 2023-04-25 05:45:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:28 --> Config Class Initialized
INFO - 2023-04-25 05:45:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:28 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:28 --> URI Class Initialized
DEBUG - 2023-04-25 05:45:28 --> No URI present. Default controller set.
INFO - 2023-04-25 05:45:28 --> Router Class Initialized
INFO - 2023-04-25 05:45:28 --> Output Class Initialized
INFO - 2023-04-25 05:45:28 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:28 --> Input Class Initialized
INFO - 2023-04-25 05:45:28 --> Language Class Initialized
INFO - 2023-04-25 05:45:28 --> Loader Class Initialized
INFO - 2023-04-25 05:45:28 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:28 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:28 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:28 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:28 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:28 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:28 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:28 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:28 --> Parser Class Initialized
INFO - 2023-04-25 05:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:28 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:28 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:28 --> Controller Class Initialized
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
INFO - 2023-04-25 05:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:45:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:45:28 --> Model Class Initialized
INFO - 2023-04-25 05:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:45:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:45:28 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:28 --> Total execution time: 0.1688
ERROR - 2023-04-25 05:45:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:32 --> Config Class Initialized
INFO - 2023-04-25 05:45:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:32 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:32 --> URI Class Initialized
INFO - 2023-04-25 05:45:32 --> Router Class Initialized
INFO - 2023-04-25 05:45:32 --> Output Class Initialized
INFO - 2023-04-25 05:45:32 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:32 --> Input Class Initialized
INFO - 2023-04-25 05:45:32 --> Language Class Initialized
INFO - 2023-04-25 05:45:32 --> Loader Class Initialized
INFO - 2023-04-25 05:45:32 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:32 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:32 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:32 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:32 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:32 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:32 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:32 --> Parser Class Initialized
INFO - 2023-04-25 05:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:32 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:32 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:32 --> Controller Class Initialized
INFO - 2023-04-25 05:45:32 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:32 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:32 --> Model Class Initialized
INFO - 2023-04-25 05:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-25 05:45:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:45:32 --> Model Class Initialized
INFO - 2023-04-25 05:45:32 --> Model Class Initialized
INFO - 2023-04-25 05:45:32 --> Model Class Initialized
INFO - 2023-04-25 05:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:45:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:45:32 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:32 --> Total execution time: 0.1390
ERROR - 2023-04-25 05:45:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:33 --> Config Class Initialized
INFO - 2023-04-25 05:45:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:33 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:33 --> URI Class Initialized
INFO - 2023-04-25 05:45:33 --> Router Class Initialized
INFO - 2023-04-25 05:45:33 --> Output Class Initialized
INFO - 2023-04-25 05:45:33 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:33 --> Input Class Initialized
INFO - 2023-04-25 05:45:33 --> Language Class Initialized
INFO - 2023-04-25 05:45:33 --> Loader Class Initialized
INFO - 2023-04-25 05:45:33 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:33 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:33 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:33 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:33 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:33 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:33 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:33 --> Parser Class Initialized
INFO - 2023-04-25 05:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:33 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:33 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:33 --> Controller Class Initialized
INFO - 2023-04-25 05:45:33 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:33 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:33 --> Model Class Initialized
INFO - 2023-04-25 05:45:33 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:33 --> Total execution time: 0.0264
ERROR - 2023-04-25 05:45:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:36 --> Config Class Initialized
INFO - 2023-04-25 05:45:36 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:36 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:36 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:36 --> URI Class Initialized
INFO - 2023-04-25 05:45:36 --> Router Class Initialized
INFO - 2023-04-25 05:45:36 --> Output Class Initialized
INFO - 2023-04-25 05:45:36 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:36 --> Input Class Initialized
INFO - 2023-04-25 05:45:36 --> Language Class Initialized
INFO - 2023-04-25 05:45:36 --> Loader Class Initialized
INFO - 2023-04-25 05:45:36 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:36 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:36 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:36 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:36 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:36 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:36 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:36 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:36 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:36 --> Parser Class Initialized
INFO - 2023-04-25 05:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:36 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:36 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:36 --> Controller Class Initialized
INFO - 2023-04-25 05:45:36 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:36 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:36 --> Model Class Initialized
INFO - 2023-04-25 05:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-04-25 05:45:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:45:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:45:36 --> Model Class Initialized
INFO - 2023-04-25 05:45:36 --> Model Class Initialized
INFO - 2023-04-25 05:45:36 --> Model Class Initialized
INFO - 2023-04-25 05:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:45:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:45:37 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:37 --> Total execution time: 0.1332
ERROR - 2023-04-25 05:45:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:51 --> Config Class Initialized
INFO - 2023-04-25 05:45:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:51 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:51 --> URI Class Initialized
INFO - 2023-04-25 05:45:51 --> Router Class Initialized
INFO - 2023-04-25 05:45:51 --> Output Class Initialized
INFO - 2023-04-25 05:45:51 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:51 --> Input Class Initialized
INFO - 2023-04-25 05:45:51 --> Language Class Initialized
INFO - 2023-04-25 05:45:51 --> Loader Class Initialized
INFO - 2023-04-25 05:45:51 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:51 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:51 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:51 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:51 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:51 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:51 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:51 --> Parser Class Initialized
INFO - 2023-04-25 05:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:51 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:51 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:51 --> Controller Class Initialized
INFO - 2023-04-25 05:45:51 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:51 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:51 --> Model Class Initialized
INFO - 2023-04-25 05:45:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 05:45:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:45:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:45:52 --> Model Class Initialized
INFO - 2023-04-25 05:45:52 --> Model Class Initialized
INFO - 2023-04-25 05:45:52 --> Model Class Initialized
INFO - 2023-04-25 05:45:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:45:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:45:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:45:52 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:52 --> Total execution time: 0.1381
ERROR - 2023-04-25 05:45:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:52 --> Config Class Initialized
INFO - 2023-04-25 05:45:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:52 --> URI Class Initialized
INFO - 2023-04-25 05:45:52 --> Router Class Initialized
INFO - 2023-04-25 05:45:52 --> Output Class Initialized
INFO - 2023-04-25 05:45:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:52 --> Input Class Initialized
INFO - 2023-04-25 05:45:52 --> Language Class Initialized
INFO - 2023-04-25 05:45:52 --> Loader Class Initialized
INFO - 2023-04-25 05:45:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:52 --> Parser Class Initialized
INFO - 2023-04-25 05:45:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:52 --> Controller Class Initialized
INFO - 2023-04-25 05:45:52 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:52 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:52 --> Model Class Initialized
INFO - 2023-04-25 05:45:53 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:53 --> Total execution time: 0.0517
ERROR - 2023-04-25 05:45:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:45:54 --> Config Class Initialized
INFO - 2023-04-25 05:45:54 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:45:54 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:45:54 --> Utf8 Class Initialized
INFO - 2023-04-25 05:45:54 --> URI Class Initialized
DEBUG - 2023-04-25 05:45:54 --> No URI present. Default controller set.
INFO - 2023-04-25 05:45:54 --> Router Class Initialized
INFO - 2023-04-25 05:45:54 --> Output Class Initialized
INFO - 2023-04-25 05:45:54 --> Security Class Initialized
DEBUG - 2023-04-25 05:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:45:54 --> Input Class Initialized
INFO - 2023-04-25 05:45:54 --> Language Class Initialized
INFO - 2023-04-25 05:45:54 --> Loader Class Initialized
INFO - 2023-04-25 05:45:54 --> Helper loaded: url_helper
INFO - 2023-04-25 05:45:54 --> Helper loaded: file_helper
INFO - 2023-04-25 05:45:54 --> Helper loaded: html_helper
INFO - 2023-04-25 05:45:54 --> Helper loaded: text_helper
INFO - 2023-04-25 05:45:54 --> Helper loaded: form_helper
INFO - 2023-04-25 05:45:54 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:45:54 --> Helper loaded: security_helper
INFO - 2023-04-25 05:45:54 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:45:54 --> Database Driver Class Initialized
INFO - 2023-04-25 05:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:45:54 --> Parser Class Initialized
INFO - 2023-04-25 05:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:45:54 --> Pagination Class Initialized
INFO - 2023-04-25 05:45:54 --> Form Validation Class Initialized
INFO - 2023-04-25 05:45:54 --> Controller Class Initialized
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
DEBUG - 2023-04-25 05:45:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
INFO - 2023-04-25 05:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:45:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:45:54 --> Model Class Initialized
INFO - 2023-04-25 05:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:45:54 --> Final output sent to browser
DEBUG - 2023-04-25 05:45:54 --> Total execution time: 0.1694
ERROR - 2023-04-25 05:56:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:56:08 --> Config Class Initialized
INFO - 2023-04-25 05:56:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:56:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:56:08 --> Utf8 Class Initialized
INFO - 2023-04-25 05:56:08 --> URI Class Initialized
DEBUG - 2023-04-25 05:56:08 --> No URI present. Default controller set.
INFO - 2023-04-25 05:56:08 --> Router Class Initialized
INFO - 2023-04-25 05:56:08 --> Output Class Initialized
INFO - 2023-04-25 05:56:08 --> Security Class Initialized
DEBUG - 2023-04-25 05:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:56:08 --> Input Class Initialized
INFO - 2023-04-25 05:56:08 --> Language Class Initialized
INFO - 2023-04-25 05:56:08 --> Loader Class Initialized
INFO - 2023-04-25 05:56:08 --> Helper loaded: url_helper
INFO - 2023-04-25 05:56:08 --> Helper loaded: file_helper
INFO - 2023-04-25 05:56:08 --> Helper loaded: html_helper
INFO - 2023-04-25 05:56:08 --> Helper loaded: text_helper
INFO - 2023-04-25 05:56:08 --> Helper loaded: form_helper
INFO - 2023-04-25 05:56:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:56:08 --> Helper loaded: security_helper
INFO - 2023-04-25 05:56:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:56:08 --> Database Driver Class Initialized
INFO - 2023-04-25 05:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:56:08 --> Parser Class Initialized
INFO - 2023-04-25 05:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:56:08 --> Pagination Class Initialized
INFO - 2023-04-25 05:56:08 --> Form Validation Class Initialized
INFO - 2023-04-25 05:56:08 --> Controller Class Initialized
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
DEBUG - 2023-04-25 05:56:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 05:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
INFO - 2023-04-25 05:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 05:56:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:56:08 --> Model Class Initialized
INFO - 2023-04-25 05:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:56:08 --> Final output sent to browser
DEBUG - 2023-04-25 05:56:08 --> Total execution time: 0.1942
ERROR - 2023-04-25 05:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:56:30 --> Config Class Initialized
INFO - 2023-04-25 05:56:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:56:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:56:30 --> Utf8 Class Initialized
INFO - 2023-04-25 05:56:30 --> URI Class Initialized
INFO - 2023-04-25 05:56:30 --> Router Class Initialized
INFO - 2023-04-25 05:56:30 --> Output Class Initialized
INFO - 2023-04-25 05:56:30 --> Security Class Initialized
DEBUG - 2023-04-25 05:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:56:30 --> Input Class Initialized
INFO - 2023-04-25 05:56:30 --> Language Class Initialized
INFO - 2023-04-25 05:56:30 --> Loader Class Initialized
INFO - 2023-04-25 05:56:30 --> Helper loaded: url_helper
INFO - 2023-04-25 05:56:30 --> Helper loaded: file_helper
INFO - 2023-04-25 05:56:30 --> Helper loaded: html_helper
INFO - 2023-04-25 05:56:30 --> Helper loaded: text_helper
INFO - 2023-04-25 05:56:30 --> Helper loaded: form_helper
INFO - 2023-04-25 05:56:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:56:30 --> Helper loaded: security_helper
INFO - 2023-04-25 05:56:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:56:30 --> Database Driver Class Initialized
INFO - 2023-04-25 05:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:56:30 --> Parser Class Initialized
INFO - 2023-04-25 05:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:56:30 --> Pagination Class Initialized
INFO - 2023-04-25 05:56:30 --> Form Validation Class Initialized
INFO - 2023-04-25 05:56:30 --> Controller Class Initialized
DEBUG - 2023-04-25 05:56:30 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:30 --> Model Class Initialized
INFO - 2023-04-25 05:56:30 --> Model Class Initialized
INFO - 2023-04-25 05:56:30 --> Model Class Initialized
INFO - 2023-04-25 05:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-25 05:56:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:56:30 --> Model Class Initialized
INFO - 2023-04-25 05:56:30 --> Model Class Initialized
INFO - 2023-04-25 05:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:56:30 --> Final output sent to browser
DEBUG - 2023-04-25 05:56:30 --> Total execution time: 0.1276
ERROR - 2023-04-25 05:56:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:56:31 --> Config Class Initialized
INFO - 2023-04-25 05:56:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:56:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:56:31 --> Utf8 Class Initialized
INFO - 2023-04-25 05:56:31 --> URI Class Initialized
INFO - 2023-04-25 05:56:31 --> Router Class Initialized
INFO - 2023-04-25 05:56:31 --> Output Class Initialized
INFO - 2023-04-25 05:56:31 --> Security Class Initialized
DEBUG - 2023-04-25 05:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:56:31 --> Input Class Initialized
INFO - 2023-04-25 05:56:31 --> Language Class Initialized
INFO - 2023-04-25 05:56:31 --> Loader Class Initialized
INFO - 2023-04-25 05:56:31 --> Helper loaded: url_helper
INFO - 2023-04-25 05:56:31 --> Helper loaded: file_helper
INFO - 2023-04-25 05:56:31 --> Helper loaded: html_helper
INFO - 2023-04-25 05:56:31 --> Helper loaded: text_helper
INFO - 2023-04-25 05:56:31 --> Helper loaded: form_helper
INFO - 2023-04-25 05:56:31 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:56:31 --> Helper loaded: security_helper
INFO - 2023-04-25 05:56:31 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:56:31 --> Database Driver Class Initialized
INFO - 2023-04-25 05:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:56:31 --> Parser Class Initialized
INFO - 2023-04-25 05:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:56:31 --> Pagination Class Initialized
INFO - 2023-04-25 05:56:31 --> Form Validation Class Initialized
INFO - 2023-04-25 05:56:31 --> Controller Class Initialized
DEBUG - 2023-04-25 05:56:31 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:31 --> Model Class Initialized
INFO - 2023-04-25 05:56:31 --> Model Class Initialized
INFO - 2023-04-25 05:56:31 --> Final output sent to browser
DEBUG - 2023-04-25 05:56:31 --> Total execution time: 0.0425
ERROR - 2023-04-25 05:56:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:56:35 --> Config Class Initialized
INFO - 2023-04-25 05:56:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:56:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:56:35 --> Utf8 Class Initialized
INFO - 2023-04-25 05:56:35 --> URI Class Initialized
INFO - 2023-04-25 05:56:35 --> Router Class Initialized
INFO - 2023-04-25 05:56:35 --> Output Class Initialized
INFO - 2023-04-25 05:56:35 --> Security Class Initialized
DEBUG - 2023-04-25 05:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:56:35 --> Input Class Initialized
INFO - 2023-04-25 05:56:35 --> Language Class Initialized
INFO - 2023-04-25 05:56:35 --> Loader Class Initialized
INFO - 2023-04-25 05:56:35 --> Helper loaded: url_helper
INFO - 2023-04-25 05:56:35 --> Helper loaded: file_helper
INFO - 2023-04-25 05:56:35 --> Helper loaded: html_helper
INFO - 2023-04-25 05:56:35 --> Helper loaded: text_helper
INFO - 2023-04-25 05:56:35 --> Helper loaded: form_helper
INFO - 2023-04-25 05:56:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:56:35 --> Helper loaded: security_helper
INFO - 2023-04-25 05:56:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:56:35 --> Database Driver Class Initialized
INFO - 2023-04-25 05:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:56:35 --> Parser Class Initialized
INFO - 2023-04-25 05:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:56:35 --> Pagination Class Initialized
INFO - 2023-04-25 05:56:35 --> Form Validation Class Initialized
INFO - 2023-04-25 05:56:35 --> Controller Class Initialized
DEBUG - 2023-04-25 05:56:35 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:35 --> Model Class Initialized
INFO - 2023-04-25 05:56:35 --> Model Class Initialized
INFO - 2023-04-25 05:56:35 --> Final output sent to browser
DEBUG - 2023-04-25 05:56:35 --> Total execution time: 0.1053
ERROR - 2023-04-25 05:56:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:56:52 --> Config Class Initialized
INFO - 2023-04-25 05:56:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:56:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:56:52 --> Utf8 Class Initialized
INFO - 2023-04-25 05:56:52 --> URI Class Initialized
INFO - 2023-04-25 05:56:52 --> Router Class Initialized
INFO - 2023-04-25 05:56:52 --> Output Class Initialized
INFO - 2023-04-25 05:56:52 --> Security Class Initialized
DEBUG - 2023-04-25 05:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:56:52 --> Input Class Initialized
INFO - 2023-04-25 05:56:52 --> Language Class Initialized
INFO - 2023-04-25 05:56:52 --> Loader Class Initialized
INFO - 2023-04-25 05:56:52 --> Helper loaded: url_helper
INFO - 2023-04-25 05:56:52 --> Helper loaded: file_helper
INFO - 2023-04-25 05:56:52 --> Helper loaded: html_helper
INFO - 2023-04-25 05:56:52 --> Helper loaded: text_helper
INFO - 2023-04-25 05:56:52 --> Helper loaded: form_helper
INFO - 2023-04-25 05:56:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:56:52 --> Helper loaded: security_helper
INFO - 2023-04-25 05:56:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:56:52 --> Database Driver Class Initialized
INFO - 2023-04-25 05:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:56:52 --> Parser Class Initialized
INFO - 2023-04-25 05:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:56:52 --> Pagination Class Initialized
INFO - 2023-04-25 05:56:52 --> Form Validation Class Initialized
INFO - 2023-04-25 05:56:52 --> Controller Class Initialized
DEBUG - 2023-04-25 05:56:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-04-25 05:56:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:56:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:52 --> Model Class Initialized
INFO - 2023-04-25 05:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:56:53 --> Final output sent to browser
DEBUG - 2023-04-25 05:56:53 --> Total execution time: 0.1548
ERROR - 2023-04-25 05:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:58:11 --> Config Class Initialized
INFO - 2023-04-25 05:58:11 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:58:11 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:58:11 --> Utf8 Class Initialized
INFO - 2023-04-25 05:58:11 --> URI Class Initialized
INFO - 2023-04-25 05:58:11 --> Router Class Initialized
INFO - 2023-04-25 05:58:11 --> Output Class Initialized
INFO - 2023-04-25 05:58:11 --> Security Class Initialized
DEBUG - 2023-04-25 05:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:58:11 --> Input Class Initialized
INFO - 2023-04-25 05:58:11 --> Language Class Initialized
INFO - 2023-04-25 05:58:11 --> Loader Class Initialized
INFO - 2023-04-25 05:58:11 --> Helper loaded: url_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: file_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: html_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: text_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: form_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: security_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:58:11 --> Database Driver Class Initialized
INFO - 2023-04-25 05:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:58:11 --> Parser Class Initialized
INFO - 2023-04-25 05:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:58:11 --> Pagination Class Initialized
INFO - 2023-04-25 05:58:11 --> Form Validation Class Initialized
INFO - 2023-04-25 05:58:11 --> Controller Class Initialized
DEBUG - 2023-04-25 05:58:11 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:58:11 --> Model Class Initialized
INFO - 2023-04-25 05:58:11 --> Model Class Initialized
ERROR - 2023-04-25 05:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:58:11 --> Config Class Initialized
INFO - 2023-04-25 05:58:11 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:58:11 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:58:11 --> Utf8 Class Initialized
INFO - 2023-04-25 05:58:11 --> URI Class Initialized
INFO - 2023-04-25 05:58:11 --> Router Class Initialized
INFO - 2023-04-25 05:58:11 --> Output Class Initialized
INFO - 2023-04-25 05:58:11 --> Security Class Initialized
DEBUG - 2023-04-25 05:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:58:11 --> Input Class Initialized
INFO - 2023-04-25 05:58:11 --> Language Class Initialized
INFO - 2023-04-25 05:58:11 --> Loader Class Initialized
INFO - 2023-04-25 05:58:11 --> Helper loaded: url_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: file_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: html_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: text_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: form_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: security_helper
INFO - 2023-04-25 05:58:11 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:58:11 --> Database Driver Class Initialized
INFO - 2023-04-25 05:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:58:11 --> Parser Class Initialized
INFO - 2023-04-25 05:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:58:11 --> Pagination Class Initialized
INFO - 2023-04-25 05:58:11 --> Form Validation Class Initialized
INFO - 2023-04-25 05:58:11 --> Controller Class Initialized
DEBUG - 2023-04-25 05:58:11 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:58:11 --> Model Class Initialized
INFO - 2023-04-25 05:58:11 --> Model Class Initialized
INFO - 2023-04-25 05:58:11 --> Model Class Initialized
INFO - 2023-04-25 05:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-25 05:58:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:58:11 --> Model Class Initialized
INFO - 2023-04-25 05:58:11 --> Model Class Initialized
INFO - 2023-04-25 05:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:58:11 --> Final output sent to browser
DEBUG - 2023-04-25 05:58:11 --> Total execution time: 0.1337
ERROR - 2023-04-25 05:58:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:58:13 --> Config Class Initialized
INFO - 2023-04-25 05:58:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:58:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:58:13 --> Utf8 Class Initialized
INFO - 2023-04-25 05:58:13 --> URI Class Initialized
INFO - 2023-04-25 05:58:13 --> Router Class Initialized
INFO - 2023-04-25 05:58:13 --> Output Class Initialized
INFO - 2023-04-25 05:58:13 --> Security Class Initialized
DEBUG - 2023-04-25 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:58:13 --> Input Class Initialized
INFO - 2023-04-25 05:58:13 --> Language Class Initialized
INFO - 2023-04-25 05:58:13 --> Loader Class Initialized
INFO - 2023-04-25 05:58:13 --> Helper loaded: url_helper
INFO - 2023-04-25 05:58:13 --> Helper loaded: file_helper
INFO - 2023-04-25 05:58:13 --> Helper loaded: html_helper
INFO - 2023-04-25 05:58:13 --> Helper loaded: text_helper
INFO - 2023-04-25 05:58:13 --> Helper loaded: form_helper
INFO - 2023-04-25 05:58:13 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:58:13 --> Helper loaded: security_helper
INFO - 2023-04-25 05:58:13 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:58:13 --> Database Driver Class Initialized
INFO - 2023-04-25 05:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:58:13 --> Parser Class Initialized
INFO - 2023-04-25 05:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:58:13 --> Pagination Class Initialized
INFO - 2023-04-25 05:58:13 --> Form Validation Class Initialized
INFO - 2023-04-25 05:58:13 --> Controller Class Initialized
DEBUG - 2023-04-25 05:58:13 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:58:13 --> Model Class Initialized
INFO - 2023-04-25 05:58:13 --> Model Class Initialized
INFO - 2023-04-25 05:58:13 --> Final output sent to browser
DEBUG - 2023-04-25 05:58:13 --> Total execution time: 0.0438
ERROR - 2023-04-25 05:58:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:58:26 --> Config Class Initialized
INFO - 2023-04-25 05:58:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:58:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:58:26 --> Utf8 Class Initialized
INFO - 2023-04-25 05:58:26 --> URI Class Initialized
INFO - 2023-04-25 05:58:26 --> Router Class Initialized
INFO - 2023-04-25 05:58:26 --> Output Class Initialized
INFO - 2023-04-25 05:58:26 --> Security Class Initialized
DEBUG - 2023-04-25 05:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:58:26 --> Input Class Initialized
INFO - 2023-04-25 05:58:26 --> Language Class Initialized
INFO - 2023-04-25 05:58:26 --> Loader Class Initialized
INFO - 2023-04-25 05:58:26 --> Helper loaded: url_helper
INFO - 2023-04-25 05:58:26 --> Helper loaded: file_helper
INFO - 2023-04-25 05:58:26 --> Helper loaded: html_helper
INFO - 2023-04-25 05:58:26 --> Helper loaded: text_helper
INFO - 2023-04-25 05:58:26 --> Helper loaded: form_helper
INFO - 2023-04-25 05:58:26 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:58:26 --> Helper loaded: security_helper
INFO - 2023-04-25 05:58:26 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:58:26 --> Database Driver Class Initialized
INFO - 2023-04-25 05:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:58:26 --> Parser Class Initialized
INFO - 2023-04-25 05:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:58:26 --> Pagination Class Initialized
INFO - 2023-04-25 05:58:26 --> Form Validation Class Initialized
INFO - 2023-04-25 05:58:26 --> Controller Class Initialized
DEBUG - 2023-04-25 05:58:26 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-04-25 05:58:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:58:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:58:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> Model Class Initialized
INFO - 2023-04-25 05:58:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:58:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:58:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:58:26 --> Final output sent to browser
DEBUG - 2023-04-25 05:58:26 --> Total execution time: 0.1522
ERROR - 2023-04-25 05:59:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:59:06 --> Config Class Initialized
INFO - 2023-04-25 05:59:06 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:59:06 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:59:06 --> Utf8 Class Initialized
INFO - 2023-04-25 05:59:06 --> URI Class Initialized
INFO - 2023-04-25 05:59:06 --> Router Class Initialized
INFO - 2023-04-25 05:59:06 --> Output Class Initialized
INFO - 2023-04-25 05:59:06 --> Security Class Initialized
DEBUG - 2023-04-25 05:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:59:06 --> Input Class Initialized
INFO - 2023-04-25 05:59:06 --> Language Class Initialized
INFO - 2023-04-25 05:59:06 --> Loader Class Initialized
INFO - 2023-04-25 05:59:06 --> Helper loaded: url_helper
INFO - 2023-04-25 05:59:06 --> Helper loaded: file_helper
INFO - 2023-04-25 05:59:06 --> Helper loaded: html_helper
INFO - 2023-04-25 05:59:06 --> Helper loaded: text_helper
INFO - 2023-04-25 05:59:06 --> Helper loaded: form_helper
INFO - 2023-04-25 05:59:06 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:59:06 --> Helper loaded: security_helper
INFO - 2023-04-25 05:59:06 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:59:06 --> Database Driver Class Initialized
INFO - 2023-04-25 05:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:59:06 --> Parser Class Initialized
INFO - 2023-04-25 05:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:59:06 --> Pagination Class Initialized
INFO - 2023-04-25 05:59:06 --> Form Validation Class Initialized
INFO - 2023-04-25 05:59:06 --> Controller Class Initialized
DEBUG - 2023-04-25 05:59:06 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:59:06 --> Model Class Initialized
INFO - 2023-04-25 05:59:06 --> Model Class Initialized
ERROR - 2023-04-25 05:59:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:59:07 --> Config Class Initialized
INFO - 2023-04-25 05:59:07 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:59:07 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:59:07 --> Utf8 Class Initialized
INFO - 2023-04-25 05:59:07 --> URI Class Initialized
INFO - 2023-04-25 05:59:07 --> Router Class Initialized
INFO - 2023-04-25 05:59:07 --> Output Class Initialized
INFO - 2023-04-25 05:59:07 --> Security Class Initialized
DEBUG - 2023-04-25 05:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:59:07 --> Input Class Initialized
INFO - 2023-04-25 05:59:07 --> Language Class Initialized
INFO - 2023-04-25 05:59:07 --> Loader Class Initialized
INFO - 2023-04-25 05:59:07 --> Helper loaded: url_helper
INFO - 2023-04-25 05:59:07 --> Helper loaded: file_helper
INFO - 2023-04-25 05:59:07 --> Helper loaded: html_helper
INFO - 2023-04-25 05:59:07 --> Helper loaded: text_helper
INFO - 2023-04-25 05:59:07 --> Helper loaded: form_helper
INFO - 2023-04-25 05:59:07 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:59:07 --> Helper loaded: security_helper
INFO - 2023-04-25 05:59:07 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:59:07 --> Database Driver Class Initialized
INFO - 2023-04-25 05:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:59:07 --> Parser Class Initialized
INFO - 2023-04-25 05:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:59:07 --> Pagination Class Initialized
INFO - 2023-04-25 05:59:07 --> Form Validation Class Initialized
INFO - 2023-04-25 05:59:07 --> Controller Class Initialized
DEBUG - 2023-04-25 05:59:07 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:59:07 --> Model Class Initialized
INFO - 2023-04-25 05:59:07 --> Model Class Initialized
INFO - 2023-04-25 05:59:07 --> Model Class Initialized
INFO - 2023-04-25 05:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-25 05:59:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 05:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 05:59:07 --> Model Class Initialized
INFO - 2023-04-25 05:59:07 --> Model Class Initialized
INFO - 2023-04-25 05:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 05:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 05:59:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 05:59:07 --> Final output sent to browser
DEBUG - 2023-04-25 05:59:07 --> Total execution time: 0.1252
ERROR - 2023-04-25 05:59:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:59:08 --> Config Class Initialized
INFO - 2023-04-25 05:59:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:59:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:59:08 --> Utf8 Class Initialized
INFO - 2023-04-25 05:59:08 --> URI Class Initialized
INFO - 2023-04-25 05:59:08 --> Router Class Initialized
INFO - 2023-04-25 05:59:08 --> Output Class Initialized
INFO - 2023-04-25 05:59:08 --> Security Class Initialized
DEBUG - 2023-04-25 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:59:08 --> Input Class Initialized
INFO - 2023-04-25 05:59:08 --> Language Class Initialized
INFO - 2023-04-25 05:59:08 --> Loader Class Initialized
INFO - 2023-04-25 05:59:08 --> Helper loaded: url_helper
INFO - 2023-04-25 05:59:08 --> Helper loaded: file_helper
INFO - 2023-04-25 05:59:08 --> Helper loaded: html_helper
INFO - 2023-04-25 05:59:08 --> Helper loaded: text_helper
INFO - 2023-04-25 05:59:08 --> Helper loaded: form_helper
INFO - 2023-04-25 05:59:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:59:08 --> Helper loaded: security_helper
INFO - 2023-04-25 05:59:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:59:08 --> Database Driver Class Initialized
INFO - 2023-04-25 05:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:59:08 --> Parser Class Initialized
INFO - 2023-04-25 05:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:59:08 --> Pagination Class Initialized
INFO - 2023-04-25 05:59:08 --> Form Validation Class Initialized
INFO - 2023-04-25 05:59:08 --> Controller Class Initialized
DEBUG - 2023-04-25 05:59:08 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:59:08 --> Model Class Initialized
INFO - 2023-04-25 05:59:08 --> Model Class Initialized
INFO - 2023-04-25 05:59:08 --> Final output sent to browser
DEBUG - 2023-04-25 05:59:08 --> Total execution time: 0.0416
ERROR - 2023-04-25 05:59:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 05:59:56 --> Config Class Initialized
INFO - 2023-04-25 05:59:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 05:59:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 05:59:56 --> Utf8 Class Initialized
INFO - 2023-04-25 05:59:56 --> URI Class Initialized
INFO - 2023-04-25 05:59:56 --> Router Class Initialized
INFO - 2023-04-25 05:59:56 --> Output Class Initialized
INFO - 2023-04-25 05:59:56 --> Security Class Initialized
DEBUG - 2023-04-25 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 05:59:56 --> Input Class Initialized
INFO - 2023-04-25 05:59:56 --> Language Class Initialized
INFO - 2023-04-25 05:59:56 --> Loader Class Initialized
INFO - 2023-04-25 05:59:56 --> Helper loaded: url_helper
INFO - 2023-04-25 05:59:56 --> Helper loaded: file_helper
INFO - 2023-04-25 05:59:56 --> Helper loaded: html_helper
INFO - 2023-04-25 05:59:56 --> Helper loaded: text_helper
INFO - 2023-04-25 05:59:56 --> Helper loaded: form_helper
INFO - 2023-04-25 05:59:56 --> Helper loaded: lang_helper
INFO - 2023-04-25 05:59:56 --> Helper loaded: security_helper
INFO - 2023-04-25 05:59:56 --> Helper loaded: cookie_helper
INFO - 2023-04-25 05:59:56 --> Database Driver Class Initialized
INFO - 2023-04-25 05:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 05:59:56 --> Parser Class Initialized
INFO - 2023-04-25 05:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 05:59:56 --> Pagination Class Initialized
INFO - 2023-04-25 05:59:56 --> Form Validation Class Initialized
INFO - 2023-04-25 05:59:56 --> Controller Class Initialized
DEBUG - 2023-04-25 05:59:56 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 05:59:56 --> Model Class Initialized
INFO - 2023-04-25 05:59:56 --> Model Class Initialized
INFO - 2023-04-25 05:59:56 --> Final output sent to browser
DEBUG - 2023-04-25 05:59:56 --> Total execution time: 0.1054
ERROR - 2023-04-25 06:37:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:37:32 --> Config Class Initialized
INFO - 2023-04-25 06:37:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:37:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:37:32 --> Utf8 Class Initialized
INFO - 2023-04-25 06:37:32 --> URI Class Initialized
DEBUG - 2023-04-25 06:37:32 --> No URI present. Default controller set.
INFO - 2023-04-25 06:37:32 --> Router Class Initialized
INFO - 2023-04-25 06:37:32 --> Output Class Initialized
INFO - 2023-04-25 06:37:32 --> Security Class Initialized
DEBUG - 2023-04-25 06:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:37:32 --> Input Class Initialized
INFO - 2023-04-25 06:37:32 --> Language Class Initialized
INFO - 2023-04-25 06:37:32 --> Loader Class Initialized
INFO - 2023-04-25 06:37:32 --> Helper loaded: url_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: file_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: html_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: text_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: form_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: security_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:37:32 --> Database Driver Class Initialized
INFO - 2023-04-25 06:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:37:32 --> Parser Class Initialized
INFO - 2023-04-25 06:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:37:32 --> Pagination Class Initialized
INFO - 2023-04-25 06:37:32 --> Form Validation Class Initialized
INFO - 2023-04-25 06:37:32 --> Controller Class Initialized
INFO - 2023-04-25 06:37:32 --> Model Class Initialized
DEBUG - 2023-04-25 06:37:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 06:37:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:37:32 --> Config Class Initialized
INFO - 2023-04-25 06:37:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:37:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:37:32 --> Utf8 Class Initialized
INFO - 2023-04-25 06:37:32 --> URI Class Initialized
INFO - 2023-04-25 06:37:32 --> Router Class Initialized
INFO - 2023-04-25 06:37:32 --> Output Class Initialized
INFO - 2023-04-25 06:37:32 --> Security Class Initialized
DEBUG - 2023-04-25 06:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:37:32 --> Input Class Initialized
INFO - 2023-04-25 06:37:32 --> Language Class Initialized
INFO - 2023-04-25 06:37:32 --> Loader Class Initialized
INFO - 2023-04-25 06:37:32 --> Helper loaded: url_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: file_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: html_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: text_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: form_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: security_helper
INFO - 2023-04-25 06:37:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:37:32 --> Database Driver Class Initialized
INFO - 2023-04-25 06:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:37:32 --> Parser Class Initialized
INFO - 2023-04-25 06:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:37:32 --> Pagination Class Initialized
INFO - 2023-04-25 06:37:32 --> Form Validation Class Initialized
INFO - 2023-04-25 06:37:32 --> Controller Class Initialized
INFO - 2023-04-25 06:37:32 --> Model Class Initialized
DEBUG - 2023-04-25 06:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 06:37:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 06:37:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 06:37:32 --> Model Class Initialized
INFO - 2023-04-25 06:37:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 06:37:32 --> Final output sent to browser
DEBUG - 2023-04-25 06:37:32 --> Total execution time: 0.0326
ERROR - 2023-04-25 06:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:37:50 --> Config Class Initialized
INFO - 2023-04-25 06:37:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:37:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:37:50 --> Utf8 Class Initialized
INFO - 2023-04-25 06:37:50 --> URI Class Initialized
INFO - 2023-04-25 06:37:50 --> Router Class Initialized
INFO - 2023-04-25 06:37:50 --> Output Class Initialized
INFO - 2023-04-25 06:37:50 --> Security Class Initialized
DEBUG - 2023-04-25 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:37:50 --> Input Class Initialized
INFO - 2023-04-25 06:37:50 --> Language Class Initialized
INFO - 2023-04-25 06:37:50 --> Loader Class Initialized
INFO - 2023-04-25 06:37:50 --> Helper loaded: url_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: file_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: html_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: text_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: form_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: security_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:37:50 --> Database Driver Class Initialized
INFO - 2023-04-25 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:37:50 --> Parser Class Initialized
INFO - 2023-04-25 06:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:37:50 --> Pagination Class Initialized
INFO - 2023-04-25 06:37:50 --> Form Validation Class Initialized
INFO - 2023-04-25 06:37:50 --> Controller Class Initialized
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
DEBUG - 2023-04-25 06:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
INFO - 2023-04-25 06:37:50 --> Final output sent to browser
DEBUG - 2023-04-25 06:37:50 --> Total execution time: 0.0223
ERROR - 2023-04-25 06:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:37:50 --> Config Class Initialized
INFO - 2023-04-25 06:37:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:37:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:37:50 --> Utf8 Class Initialized
INFO - 2023-04-25 06:37:50 --> URI Class Initialized
DEBUG - 2023-04-25 06:37:50 --> No URI present. Default controller set.
INFO - 2023-04-25 06:37:50 --> Router Class Initialized
INFO - 2023-04-25 06:37:50 --> Output Class Initialized
INFO - 2023-04-25 06:37:50 --> Security Class Initialized
DEBUG - 2023-04-25 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:37:50 --> Input Class Initialized
INFO - 2023-04-25 06:37:50 --> Language Class Initialized
INFO - 2023-04-25 06:37:50 --> Loader Class Initialized
INFO - 2023-04-25 06:37:50 --> Helper loaded: url_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: file_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: html_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: text_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: form_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: security_helper
INFO - 2023-04-25 06:37:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:37:50 --> Database Driver Class Initialized
INFO - 2023-04-25 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:37:50 --> Parser Class Initialized
INFO - 2023-04-25 06:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:37:50 --> Pagination Class Initialized
INFO - 2023-04-25 06:37:50 --> Form Validation Class Initialized
INFO - 2023-04-25 06:37:50 --> Controller Class Initialized
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
DEBUG - 2023-04-25 06:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
DEBUG - 2023-04-25 06:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
DEBUG - 2023-04-25 06:37:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 06:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
INFO - 2023-04-25 06:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 06:37:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 06:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 06:37:50 --> Model Class Initialized
INFO - 2023-04-25 06:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 06:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 06:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 06:37:50 --> Final output sent to browser
DEBUG - 2023-04-25 06:37:50 --> Total execution time: 0.1624
ERROR - 2023-04-25 06:37:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:37:51 --> Config Class Initialized
INFO - 2023-04-25 06:37:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:37:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:37:51 --> Utf8 Class Initialized
INFO - 2023-04-25 06:37:51 --> URI Class Initialized
INFO - 2023-04-25 06:37:51 --> Router Class Initialized
INFO - 2023-04-25 06:37:51 --> Output Class Initialized
INFO - 2023-04-25 06:37:51 --> Security Class Initialized
DEBUG - 2023-04-25 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:37:51 --> Input Class Initialized
INFO - 2023-04-25 06:37:51 --> Language Class Initialized
INFO - 2023-04-25 06:37:51 --> Loader Class Initialized
INFO - 2023-04-25 06:37:51 --> Helper loaded: url_helper
INFO - 2023-04-25 06:37:51 --> Helper loaded: file_helper
INFO - 2023-04-25 06:37:51 --> Helper loaded: html_helper
INFO - 2023-04-25 06:37:51 --> Helper loaded: text_helper
INFO - 2023-04-25 06:37:51 --> Helper loaded: form_helper
INFO - 2023-04-25 06:37:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:37:51 --> Helper loaded: security_helper
INFO - 2023-04-25 06:37:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:37:51 --> Database Driver Class Initialized
INFO - 2023-04-25 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:37:51 --> Parser Class Initialized
INFO - 2023-04-25 06:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:37:51 --> Pagination Class Initialized
INFO - 2023-04-25 06:37:51 --> Form Validation Class Initialized
INFO - 2023-04-25 06:37:51 --> Controller Class Initialized
DEBUG - 2023-04-25 06:37:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 06:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:37:51 --> Model Class Initialized
INFO - 2023-04-25 06:37:51 --> Final output sent to browser
DEBUG - 2023-04-25 06:37:51 --> Total execution time: 0.0146
ERROR - 2023-04-25 06:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:38:15 --> Config Class Initialized
INFO - 2023-04-25 06:38:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:38:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:38:15 --> Utf8 Class Initialized
INFO - 2023-04-25 06:38:15 --> URI Class Initialized
INFO - 2023-04-25 06:38:15 --> Router Class Initialized
INFO - 2023-04-25 06:38:15 --> Output Class Initialized
INFO - 2023-04-25 06:38:15 --> Security Class Initialized
DEBUG - 2023-04-25 06:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:38:15 --> Input Class Initialized
INFO - 2023-04-25 06:38:15 --> Language Class Initialized
INFO - 2023-04-25 06:38:15 --> Loader Class Initialized
INFO - 2023-04-25 06:38:15 --> Helper loaded: url_helper
INFO - 2023-04-25 06:38:15 --> Helper loaded: file_helper
INFO - 2023-04-25 06:38:15 --> Helper loaded: html_helper
INFO - 2023-04-25 06:38:15 --> Helper loaded: text_helper
INFO - 2023-04-25 06:38:15 --> Helper loaded: form_helper
INFO - 2023-04-25 06:38:15 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:38:15 --> Helper loaded: security_helper
INFO - 2023-04-25 06:38:15 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:38:15 --> Database Driver Class Initialized
INFO - 2023-04-25 06:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:38:15 --> Parser Class Initialized
INFO - 2023-04-25 06:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:38:15 --> Pagination Class Initialized
INFO - 2023-04-25 06:38:15 --> Form Validation Class Initialized
INFO - 2023-04-25 06:38:15 --> Controller Class Initialized
INFO - 2023-04-25 06:38:15 --> Model Class Initialized
INFO - 2023-04-25 06:38:15 --> Model Class Initialized
ERROR - 2023-04-25 06:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-25 06:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-25 06:38:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 06:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 06:38:15 --> Model Class Initialized
INFO - 2023-04-25 06:38:15 --> Model Class Initialized
INFO - 2023-04-25 06:38:15 --> Model Class Initialized
INFO - 2023-04-25 06:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 06:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 06:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 06:38:15 --> Final output sent to browser
DEBUG - 2023-04-25 06:38:15 --> Total execution time: 0.1892
ERROR - 2023-04-25 06:40:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:40:30 --> Config Class Initialized
INFO - 2023-04-25 06:40:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:40:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:40:30 --> Utf8 Class Initialized
INFO - 2023-04-25 06:40:30 --> URI Class Initialized
INFO - 2023-04-25 06:40:30 --> Router Class Initialized
INFO - 2023-04-25 06:40:30 --> Output Class Initialized
INFO - 2023-04-25 06:40:30 --> Security Class Initialized
DEBUG - 2023-04-25 06:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:40:30 --> Input Class Initialized
INFO - 2023-04-25 06:40:30 --> Language Class Initialized
INFO - 2023-04-25 06:40:30 --> Loader Class Initialized
INFO - 2023-04-25 06:40:30 --> Helper loaded: url_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: file_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: html_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: text_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: form_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: security_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:40:30 --> Database Driver Class Initialized
INFO - 2023-04-25 06:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:40:30 --> Parser Class Initialized
INFO - 2023-04-25 06:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:40:30 --> Pagination Class Initialized
INFO - 2023-04-25 06:40:30 --> Form Validation Class Initialized
INFO - 2023-04-25 06:40:30 --> Controller Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
ERROR - 2023-04-25 06:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-25 06:40:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
ERROR - 2023-04-25 06:40:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:40:30 --> Config Class Initialized
INFO - 2023-04-25 06:40:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:40:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:40:30 --> Utf8 Class Initialized
INFO - 2023-04-25 06:40:30 --> URI Class Initialized
INFO - 2023-04-25 06:40:30 --> Router Class Initialized
INFO - 2023-04-25 06:40:30 --> Output Class Initialized
INFO - 2023-04-25 06:40:30 --> Security Class Initialized
DEBUG - 2023-04-25 06:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:40:30 --> Input Class Initialized
INFO - 2023-04-25 06:40:30 --> Language Class Initialized
INFO - 2023-04-25 06:40:30 --> Loader Class Initialized
INFO - 2023-04-25 06:40:30 --> Helper loaded: url_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: file_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: html_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: text_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: form_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: security_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:40:30 --> Database Driver Class Initialized
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 06:40:30 --> Final output sent to browser
DEBUG - 2023-04-25 06:40:30 --> Total execution time: 0.1737
INFO - 2023-04-25 06:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:40:30 --> Parser Class Initialized
INFO - 2023-04-25 06:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:40:30 --> Pagination Class Initialized
INFO - 2023-04-25 06:40:30 --> Form Validation Class Initialized
INFO - 2023-04-25 06:40:30 --> Controller Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
ERROR - 2023-04-25 06:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-25 06:40:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 06:40:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
INFO - 2023-04-25 06:40:30 --> Model Class Initialized
ERROR - 2023-04-25 06:40:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:40:30 --> Config Class Initialized
INFO - 2023-04-25 06:40:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:40:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:40:30 --> Utf8 Class Initialized
INFO - 2023-04-25 06:40:30 --> URI Class Initialized
INFO - 2023-04-25 06:40:30 --> Router Class Initialized
INFO - 2023-04-25 06:40:30 --> Output Class Initialized
INFO - 2023-04-25 06:40:30 --> Security Class Initialized
DEBUG - 2023-04-25 06:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:40:30 --> Input Class Initialized
INFO - 2023-04-25 06:40:30 --> Language Class Initialized
INFO - 2023-04-25 06:40:30 --> Loader Class Initialized
INFO - 2023-04-25 06:40:30 --> Helper loaded: url_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: file_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: html_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: text_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: form_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: security_helper
INFO - 2023-04-25 06:40:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:40:30 --> Database Driver Class Initialized
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 06:40:31 --> Final output sent to browser
DEBUG - 2023-04-25 06:40:31 --> Total execution time: 0.2446
INFO - 2023-04-25 06:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:40:31 --> Parser Class Initialized
INFO - 2023-04-25 06:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:40:31 --> Pagination Class Initialized
INFO - 2023-04-25 06:40:31 --> Form Validation Class Initialized
INFO - 2023-04-25 06:40:31 --> Controller Class Initialized
INFO - 2023-04-25 06:40:31 --> Model Class Initialized
INFO - 2023-04-25 06:40:31 --> Model Class Initialized
ERROR - 2023-04-25 06:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-25 06:40:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 06:40:31 --> Model Class Initialized
INFO - 2023-04-25 06:40:31 --> Model Class Initialized
INFO - 2023-04-25 06:40:31 --> Model Class Initialized
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 06:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 06:40:31 --> Final output sent to browser
DEBUG - 2023-04-25 06:40:31 --> Total execution time: 0.2321
ERROR - 2023-04-25 06:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 06:40:51 --> Config Class Initialized
INFO - 2023-04-25 06:40:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 06:40:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 06:40:51 --> Utf8 Class Initialized
INFO - 2023-04-25 06:40:51 --> URI Class Initialized
INFO - 2023-04-25 06:40:51 --> Router Class Initialized
INFO - 2023-04-25 06:40:51 --> Output Class Initialized
INFO - 2023-04-25 06:40:51 --> Security Class Initialized
DEBUG - 2023-04-25 06:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 06:40:51 --> Input Class Initialized
INFO - 2023-04-25 06:40:51 --> Language Class Initialized
INFO - 2023-04-25 06:40:51 --> Loader Class Initialized
INFO - 2023-04-25 06:40:51 --> Helper loaded: url_helper
INFO - 2023-04-25 06:40:51 --> Helper loaded: file_helper
INFO - 2023-04-25 06:40:51 --> Helper loaded: html_helper
INFO - 2023-04-25 06:40:51 --> Helper loaded: text_helper
INFO - 2023-04-25 06:40:51 --> Helper loaded: form_helper
INFO - 2023-04-25 06:40:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 06:40:51 --> Helper loaded: security_helper
INFO - 2023-04-25 06:40:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 06:40:51 --> Database Driver Class Initialized
INFO - 2023-04-25 06:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 06:40:51 --> Parser Class Initialized
INFO - 2023-04-25 06:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 06:40:51 --> Pagination Class Initialized
INFO - 2023-04-25 06:40:51 --> Form Validation Class Initialized
INFO - 2023-04-25 06:40:51 --> Controller Class Initialized
INFO - 2023-04-25 06:40:51 --> Model Class Initialized
INFO - 2023-04-25 06:40:51 --> Model Class Initialized
ERROR - 2023-04-25 06:40:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-25 06:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-25 06:40:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 06:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 06:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 06:40:51 --> Model Class Initialized
INFO - 2023-04-25 06:40:51 --> Model Class Initialized
INFO - 2023-04-25 06:40:51 --> Model Class Initialized
INFO - 2023-04-25 06:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 06:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 06:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 06:40:51 --> Final output sent to browser
DEBUG - 2023-04-25 06:40:51 --> Total execution time: 0.1761
ERROR - 2023-04-25 07:14:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 07:14:50 --> Config Class Initialized
INFO - 2023-04-25 07:14:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:14:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:14:50 --> Utf8 Class Initialized
INFO - 2023-04-25 07:14:50 --> URI Class Initialized
DEBUG - 2023-04-25 07:14:50 --> No URI present. Default controller set.
INFO - 2023-04-25 07:14:50 --> Router Class Initialized
INFO - 2023-04-25 07:14:50 --> Output Class Initialized
INFO - 2023-04-25 07:14:50 --> Security Class Initialized
DEBUG - 2023-04-25 07:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:14:50 --> Input Class Initialized
INFO - 2023-04-25 07:14:50 --> Language Class Initialized
INFO - 2023-04-25 07:14:50 --> Loader Class Initialized
INFO - 2023-04-25 07:14:50 --> Helper loaded: url_helper
INFO - 2023-04-25 07:14:50 --> Helper loaded: file_helper
INFO - 2023-04-25 07:14:50 --> Helper loaded: html_helper
INFO - 2023-04-25 07:14:50 --> Helper loaded: text_helper
INFO - 2023-04-25 07:14:50 --> Helper loaded: form_helper
INFO - 2023-04-25 07:14:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 07:14:50 --> Helper loaded: security_helper
INFO - 2023-04-25 07:14:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 07:14:50 --> Database Driver Class Initialized
INFO - 2023-04-25 07:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 07:14:50 --> Parser Class Initialized
INFO - 2023-04-25 07:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 07:14:50 --> Pagination Class Initialized
INFO - 2023-04-25 07:14:50 --> Form Validation Class Initialized
INFO - 2023-04-25 07:14:50 --> Controller Class Initialized
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
DEBUG - 2023-04-25 07:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
DEBUG - 2023-04-25 07:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
DEBUG - 2023-04-25 07:14:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 07:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
INFO - 2023-04-25 07:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 07:14:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 07:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 07:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 07:14:50 --> Model Class Initialized
INFO - 2023-04-25 07:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 07:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 07:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 07:14:50 --> Final output sent to browser
DEBUG - 2023-04-25 07:14:50 --> Total execution time: 0.1966
ERROR - 2023-04-25 07:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 07:14:55 --> Config Class Initialized
INFO - 2023-04-25 07:14:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:14:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:14:55 --> Utf8 Class Initialized
INFO - 2023-04-25 07:14:55 --> URI Class Initialized
INFO - 2023-04-25 07:14:55 --> Router Class Initialized
INFO - 2023-04-25 07:14:55 --> Output Class Initialized
INFO - 2023-04-25 07:14:55 --> Security Class Initialized
DEBUG - 2023-04-25 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:14:55 --> Input Class Initialized
INFO - 2023-04-25 07:14:55 --> Language Class Initialized
INFO - 2023-04-25 07:14:55 --> Loader Class Initialized
INFO - 2023-04-25 07:14:55 --> Helper loaded: url_helper
INFO - 2023-04-25 07:14:55 --> Helper loaded: file_helper
INFO - 2023-04-25 07:14:55 --> Helper loaded: html_helper
INFO - 2023-04-25 07:14:55 --> Helper loaded: text_helper
INFO - 2023-04-25 07:14:55 --> Helper loaded: form_helper
INFO - 2023-04-25 07:14:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 07:14:55 --> Helper loaded: security_helper
INFO - 2023-04-25 07:14:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 07:14:55 --> Database Driver Class Initialized
INFO - 2023-04-25 07:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 07:14:55 --> Parser Class Initialized
INFO - 2023-04-25 07:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 07:14:55 --> Pagination Class Initialized
INFO - 2023-04-25 07:14:55 --> Form Validation Class Initialized
INFO - 2023-04-25 07:14:55 --> Controller Class Initialized
INFO - 2023-04-25 07:14:55 --> Model Class Initialized
INFO - 2023-04-25 07:14:55 --> Model Class Initialized
ERROR - 2023-04-25 07:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2023-04-25 07:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2023-04-25 07:14:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 07:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 07:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 07:14:55 --> Model Class Initialized
INFO - 2023-04-25 07:14:55 --> Model Class Initialized
INFO - 2023-04-25 07:14:55 --> Model Class Initialized
INFO - 2023-04-25 07:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 07:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 07:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 07:14:55 --> Final output sent to browser
DEBUG - 2023-04-25 07:14:55 --> Total execution time: 0.1523
ERROR - 2023-04-25 07:15:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 07:15:01 --> Config Class Initialized
INFO - 2023-04-25 07:15:01 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:15:01 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:15:01 --> Utf8 Class Initialized
INFO - 2023-04-25 07:15:01 --> URI Class Initialized
INFO - 2023-04-25 07:15:01 --> Router Class Initialized
INFO - 2023-04-25 07:15:01 --> Output Class Initialized
INFO - 2023-04-25 07:15:01 --> Security Class Initialized
DEBUG - 2023-04-25 07:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:15:01 --> Input Class Initialized
INFO - 2023-04-25 07:15:01 --> Language Class Initialized
INFO - 2023-04-25 07:15:01 --> Loader Class Initialized
INFO - 2023-04-25 07:15:01 --> Helper loaded: url_helper
INFO - 2023-04-25 07:15:01 --> Helper loaded: file_helper
INFO - 2023-04-25 07:15:01 --> Helper loaded: html_helper
INFO - 2023-04-25 07:15:01 --> Helper loaded: text_helper
INFO - 2023-04-25 07:15:01 --> Helper loaded: form_helper
INFO - 2023-04-25 07:15:01 --> Helper loaded: lang_helper
INFO - 2023-04-25 07:15:01 --> Helper loaded: security_helper
INFO - 2023-04-25 07:15:01 --> Helper loaded: cookie_helper
INFO - 2023-04-25 07:15:01 --> Database Driver Class Initialized
INFO - 2023-04-25 07:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 07:15:01 --> Parser Class Initialized
INFO - 2023-04-25 07:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 07:15:01 --> Pagination Class Initialized
INFO - 2023-04-25 07:15:01 --> Form Validation Class Initialized
INFO - 2023-04-25 07:15:01 --> Controller Class Initialized
INFO - 2023-04-25 07:15:01 --> Model Class Initialized
INFO - 2023-04-25 07:15:01 --> Final output sent to browser
DEBUG - 2023-04-25 07:15:01 --> Total execution time: 0.0186
ERROR - 2023-04-25 07:15:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 07:15:03 --> Config Class Initialized
INFO - 2023-04-25 07:15:03 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:15:03 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:15:03 --> Utf8 Class Initialized
INFO - 2023-04-25 07:15:03 --> URI Class Initialized
INFO - 2023-04-25 07:15:03 --> Router Class Initialized
INFO - 2023-04-25 07:15:03 --> Output Class Initialized
INFO - 2023-04-25 07:15:03 --> Security Class Initialized
DEBUG - 2023-04-25 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:15:03 --> Input Class Initialized
INFO - 2023-04-25 07:15:03 --> Language Class Initialized
INFO - 2023-04-25 07:15:03 --> Loader Class Initialized
INFO - 2023-04-25 07:15:03 --> Helper loaded: url_helper
INFO - 2023-04-25 07:15:03 --> Helper loaded: file_helper
INFO - 2023-04-25 07:15:03 --> Helper loaded: html_helper
INFO - 2023-04-25 07:15:03 --> Helper loaded: text_helper
INFO - 2023-04-25 07:15:03 --> Helper loaded: form_helper
INFO - 2023-04-25 07:15:03 --> Helper loaded: lang_helper
INFO - 2023-04-25 07:15:03 --> Helper loaded: security_helper
INFO - 2023-04-25 07:15:03 --> Helper loaded: cookie_helper
INFO - 2023-04-25 07:15:03 --> Database Driver Class Initialized
INFO - 2023-04-25 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 07:15:03 --> Parser Class Initialized
INFO - 2023-04-25 07:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 07:15:03 --> Pagination Class Initialized
INFO - 2023-04-25 07:15:03 --> Form Validation Class Initialized
INFO - 2023-04-25 07:15:03 --> Controller Class Initialized
INFO - 2023-04-25 07:15:03 --> Model Class Initialized
DEBUG - 2023-04-25 07:15:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 07:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 07:15:03 --> Model Class Initialized
DEBUG - 2023-04-25 07:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 07:15:03 --> Model Class Initialized
INFO - 2023-04-25 07:15:03 --> Final output sent to browser
DEBUG - 2023-04-25 07:15:03 --> Total execution time: 0.0191
ERROR - 2023-04-25 08:35:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:35:33 --> Config Class Initialized
INFO - 2023-04-25 08:35:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:35:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:35:33 --> Utf8 Class Initialized
INFO - 2023-04-25 08:35:33 --> URI Class Initialized
DEBUG - 2023-04-25 08:35:33 --> No URI present. Default controller set.
INFO - 2023-04-25 08:35:33 --> Router Class Initialized
INFO - 2023-04-25 08:35:33 --> Output Class Initialized
INFO - 2023-04-25 08:35:33 --> Security Class Initialized
DEBUG - 2023-04-25 08:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:35:33 --> Input Class Initialized
INFO - 2023-04-25 08:35:33 --> Language Class Initialized
INFO - 2023-04-25 08:35:33 --> Loader Class Initialized
INFO - 2023-04-25 08:35:33 --> Helper loaded: url_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: file_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: html_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: text_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: form_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: security_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:35:33 --> Database Driver Class Initialized
INFO - 2023-04-25 08:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:35:33 --> Parser Class Initialized
INFO - 2023-04-25 08:35:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:35:33 --> Pagination Class Initialized
INFO - 2023-04-25 08:35:33 --> Form Validation Class Initialized
INFO - 2023-04-25 08:35:33 --> Controller Class Initialized
INFO - 2023-04-25 08:35:33 --> Model Class Initialized
DEBUG - 2023-04-25 08:35:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 08:35:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:35:33 --> Config Class Initialized
INFO - 2023-04-25 08:35:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:35:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:35:33 --> Utf8 Class Initialized
INFO - 2023-04-25 08:35:33 --> URI Class Initialized
INFO - 2023-04-25 08:35:33 --> Router Class Initialized
INFO - 2023-04-25 08:35:33 --> Output Class Initialized
INFO - 2023-04-25 08:35:33 --> Security Class Initialized
DEBUG - 2023-04-25 08:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:35:33 --> Input Class Initialized
INFO - 2023-04-25 08:35:33 --> Language Class Initialized
INFO - 2023-04-25 08:35:33 --> Loader Class Initialized
INFO - 2023-04-25 08:35:33 --> Helper loaded: url_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: file_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: html_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: text_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: form_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: security_helper
INFO - 2023-04-25 08:35:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:35:33 --> Database Driver Class Initialized
INFO - 2023-04-25 08:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:35:33 --> Parser Class Initialized
INFO - 2023-04-25 08:35:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:35:33 --> Pagination Class Initialized
INFO - 2023-04-25 08:35:33 --> Form Validation Class Initialized
INFO - 2023-04-25 08:35:33 --> Controller Class Initialized
INFO - 2023-04-25 08:35:33 --> Model Class Initialized
DEBUG - 2023-04-25 08:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 08:35:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 08:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 08:35:33 --> Model Class Initialized
INFO - 2023-04-25 08:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 08:35:33 --> Final output sent to browser
DEBUG - 2023-04-25 08:35:33 --> Total execution time: 0.0336
ERROR - 2023-04-25 08:35:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:35:47 --> Config Class Initialized
INFO - 2023-04-25 08:35:47 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:35:47 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:35:47 --> Utf8 Class Initialized
INFO - 2023-04-25 08:35:47 --> URI Class Initialized
INFO - 2023-04-25 08:35:47 --> Router Class Initialized
INFO - 2023-04-25 08:35:47 --> Output Class Initialized
INFO - 2023-04-25 08:35:47 --> Security Class Initialized
DEBUG - 2023-04-25 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:35:47 --> Input Class Initialized
INFO - 2023-04-25 08:35:47 --> Language Class Initialized
INFO - 2023-04-25 08:35:47 --> Loader Class Initialized
INFO - 2023-04-25 08:35:47 --> Helper loaded: url_helper
INFO - 2023-04-25 08:35:47 --> Helper loaded: file_helper
INFO - 2023-04-25 08:35:47 --> Helper loaded: html_helper
INFO - 2023-04-25 08:35:47 --> Helper loaded: text_helper
INFO - 2023-04-25 08:35:47 --> Helper loaded: form_helper
INFO - 2023-04-25 08:35:47 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:35:47 --> Helper loaded: security_helper
INFO - 2023-04-25 08:35:47 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:35:47 --> Database Driver Class Initialized
INFO - 2023-04-25 08:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:35:47 --> Parser Class Initialized
INFO - 2023-04-25 08:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:35:47 --> Pagination Class Initialized
INFO - 2023-04-25 08:35:47 --> Form Validation Class Initialized
INFO - 2023-04-25 08:35:47 --> Controller Class Initialized
INFO - 2023-04-25 08:35:47 --> Model Class Initialized
DEBUG - 2023-04-25 08:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 08:35:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 08:35:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 08:35:47 --> Model Class Initialized
INFO - 2023-04-25 08:35:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 08:35:47 --> Final output sent to browser
DEBUG - 2023-04-25 08:35:47 --> Total execution time: 0.0289
ERROR - 2023-04-25 08:35:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:35:53 --> Config Class Initialized
INFO - 2023-04-25 08:35:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:35:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:35:53 --> Utf8 Class Initialized
INFO - 2023-04-25 08:35:53 --> URI Class Initialized
INFO - 2023-04-25 08:35:53 --> Router Class Initialized
INFO - 2023-04-25 08:35:53 --> Output Class Initialized
INFO - 2023-04-25 08:35:53 --> Security Class Initialized
DEBUG - 2023-04-25 08:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:35:53 --> Input Class Initialized
INFO - 2023-04-25 08:35:53 --> Language Class Initialized
INFO - 2023-04-25 08:35:53 --> Loader Class Initialized
INFO - 2023-04-25 08:35:53 --> Helper loaded: url_helper
INFO - 2023-04-25 08:35:53 --> Helper loaded: file_helper
INFO - 2023-04-25 08:35:53 --> Helper loaded: html_helper
INFO - 2023-04-25 08:35:53 --> Helper loaded: text_helper
INFO - 2023-04-25 08:35:53 --> Helper loaded: form_helper
INFO - 2023-04-25 08:35:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:35:53 --> Helper loaded: security_helper
INFO - 2023-04-25 08:35:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:35:53 --> Database Driver Class Initialized
INFO - 2023-04-25 08:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:35:53 --> Parser Class Initialized
INFO - 2023-04-25 08:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:35:53 --> Pagination Class Initialized
INFO - 2023-04-25 08:35:53 --> Form Validation Class Initialized
INFO - 2023-04-25 08:35:53 --> Controller Class Initialized
INFO - 2023-04-25 08:35:53 --> Model Class Initialized
DEBUG - 2023-04-25 08:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:53 --> Model Class Initialized
INFO - 2023-04-25 08:35:53 --> Final output sent to browser
DEBUG - 2023-04-25 08:35:53 --> Total execution time: 0.0205
ERROR - 2023-04-25 08:35:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:35:54 --> Config Class Initialized
INFO - 2023-04-25 08:35:54 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:35:54 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:35:54 --> Utf8 Class Initialized
INFO - 2023-04-25 08:35:54 --> URI Class Initialized
DEBUG - 2023-04-25 08:35:54 --> No URI present. Default controller set.
INFO - 2023-04-25 08:35:54 --> Router Class Initialized
INFO - 2023-04-25 08:35:54 --> Output Class Initialized
INFO - 2023-04-25 08:35:54 --> Security Class Initialized
DEBUG - 2023-04-25 08:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:35:54 --> Input Class Initialized
INFO - 2023-04-25 08:35:54 --> Language Class Initialized
INFO - 2023-04-25 08:35:54 --> Loader Class Initialized
INFO - 2023-04-25 08:35:54 --> Helper loaded: url_helper
INFO - 2023-04-25 08:35:54 --> Helper loaded: file_helper
INFO - 2023-04-25 08:35:54 --> Helper loaded: html_helper
INFO - 2023-04-25 08:35:54 --> Helper loaded: text_helper
INFO - 2023-04-25 08:35:54 --> Helper loaded: form_helper
INFO - 2023-04-25 08:35:54 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:35:54 --> Helper loaded: security_helper
INFO - 2023-04-25 08:35:54 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:35:54 --> Database Driver Class Initialized
INFO - 2023-04-25 08:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:35:54 --> Parser Class Initialized
INFO - 2023-04-25 08:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:35:54 --> Pagination Class Initialized
INFO - 2023-04-25 08:35:54 --> Form Validation Class Initialized
INFO - 2023-04-25 08:35:54 --> Controller Class Initialized
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
DEBUG - 2023-04-25 08:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
DEBUG - 2023-04-25 08:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
DEBUG - 2023-04-25 08:35:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
INFO - 2023-04-25 08:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 08:35:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 08:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 08:35:54 --> Model Class Initialized
INFO - 2023-04-25 08:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 08:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 08:35:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 08:35:54 --> Final output sent to browser
DEBUG - 2023-04-25 08:35:54 --> Total execution time: 0.0652
ERROR - 2023-04-25 08:36:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:36:57 --> Config Class Initialized
INFO - 2023-04-25 08:36:57 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:36:57 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:36:57 --> Utf8 Class Initialized
INFO - 2023-04-25 08:36:57 --> URI Class Initialized
INFO - 2023-04-25 08:36:57 --> Router Class Initialized
INFO - 2023-04-25 08:36:57 --> Output Class Initialized
INFO - 2023-04-25 08:36:57 --> Security Class Initialized
DEBUG - 2023-04-25 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:36:57 --> Input Class Initialized
INFO - 2023-04-25 08:36:57 --> Language Class Initialized
INFO - 2023-04-25 08:36:57 --> Loader Class Initialized
INFO - 2023-04-25 08:36:57 --> Helper loaded: url_helper
INFO - 2023-04-25 08:36:57 --> Helper loaded: file_helper
INFO - 2023-04-25 08:36:57 --> Helper loaded: html_helper
INFO - 2023-04-25 08:36:57 --> Helper loaded: text_helper
INFO - 2023-04-25 08:36:57 --> Helper loaded: form_helper
INFO - 2023-04-25 08:36:57 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:36:57 --> Helper loaded: security_helper
INFO - 2023-04-25 08:36:57 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:36:57 --> Database Driver Class Initialized
INFO - 2023-04-25 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:36:57 --> Parser Class Initialized
INFO - 2023-04-25 08:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:36:57 --> Pagination Class Initialized
INFO - 2023-04-25 08:36:57 --> Form Validation Class Initialized
INFO - 2023-04-25 08:36:57 --> Controller Class Initialized
INFO - 2023-04-25 08:36:57 --> Model Class Initialized
DEBUG - 2023-04-25 08:36:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:36:57 --> Model Class Initialized
DEBUG - 2023-04-25 08:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-04-25 08:36:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 08:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 08:36:57 --> Model Class Initialized
INFO - 2023-04-25 08:36:57 --> Model Class Initialized
INFO - 2023-04-25 08:36:57 --> Model Class Initialized
INFO - 2023-04-25 08:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 08:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 08:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 08:36:57 --> Final output sent to browser
DEBUG - 2023-04-25 08:36:57 --> Total execution time: 0.0588
ERROR - 2023-04-25 08:37:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:37:17 --> Config Class Initialized
INFO - 2023-04-25 08:37:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:37:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:37:17 --> Utf8 Class Initialized
INFO - 2023-04-25 08:37:17 --> URI Class Initialized
INFO - 2023-04-25 08:37:17 --> Router Class Initialized
INFO - 2023-04-25 08:37:17 --> Output Class Initialized
INFO - 2023-04-25 08:37:17 --> Security Class Initialized
DEBUG - 2023-04-25 08:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:37:17 --> Input Class Initialized
INFO - 2023-04-25 08:37:17 --> Language Class Initialized
INFO - 2023-04-25 08:37:17 --> Loader Class Initialized
INFO - 2023-04-25 08:37:17 --> Helper loaded: url_helper
INFO - 2023-04-25 08:37:17 --> Helper loaded: file_helper
INFO - 2023-04-25 08:37:17 --> Helper loaded: html_helper
INFO - 2023-04-25 08:37:17 --> Helper loaded: text_helper
INFO - 2023-04-25 08:37:17 --> Helper loaded: form_helper
INFO - 2023-04-25 08:37:17 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:37:17 --> Helper loaded: security_helper
INFO - 2023-04-25 08:37:17 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:37:17 --> Database Driver Class Initialized
INFO - 2023-04-25 08:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:37:17 --> Parser Class Initialized
INFO - 2023-04-25 08:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:37:17 --> Pagination Class Initialized
INFO - 2023-04-25 08:37:17 --> Form Validation Class Initialized
INFO - 2023-04-25 08:37:17 --> Controller Class Initialized
INFO - 2023-04-25 08:37:17 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:17 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:17 --> Model Class Initialized
INFO - 2023-04-25 08:37:17 --> Final output sent to browser
DEBUG - 2023-04-25 08:37:17 --> Total execution time: 0.0196
ERROR - 2023-04-25 08:37:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:37:19 --> Config Class Initialized
INFO - 2023-04-25 08:37:19 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:37:19 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:37:19 --> Utf8 Class Initialized
INFO - 2023-04-25 08:37:19 --> URI Class Initialized
INFO - 2023-04-25 08:37:19 --> Router Class Initialized
INFO - 2023-04-25 08:37:19 --> Output Class Initialized
INFO - 2023-04-25 08:37:19 --> Security Class Initialized
DEBUG - 2023-04-25 08:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:37:19 --> Input Class Initialized
INFO - 2023-04-25 08:37:19 --> Language Class Initialized
INFO - 2023-04-25 08:37:19 --> Loader Class Initialized
INFO - 2023-04-25 08:37:19 --> Helper loaded: url_helper
INFO - 2023-04-25 08:37:19 --> Helper loaded: file_helper
INFO - 2023-04-25 08:37:19 --> Helper loaded: html_helper
INFO - 2023-04-25 08:37:19 --> Helper loaded: text_helper
INFO - 2023-04-25 08:37:19 --> Helper loaded: form_helper
INFO - 2023-04-25 08:37:19 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:37:19 --> Helper loaded: security_helper
INFO - 2023-04-25 08:37:19 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:37:19 --> Database Driver Class Initialized
INFO - 2023-04-25 08:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:37:19 --> Parser Class Initialized
INFO - 2023-04-25 08:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:37:19 --> Pagination Class Initialized
INFO - 2023-04-25 08:37:19 --> Form Validation Class Initialized
INFO - 2023-04-25 08:37:19 --> Controller Class Initialized
INFO - 2023-04-25 08:37:19 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:19 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:19 --> Model Class Initialized
INFO - 2023-04-25 08:37:19 --> Final output sent to browser
DEBUG - 2023-04-25 08:37:19 --> Total execution time: 0.0171
ERROR - 2023-04-25 08:37:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:37:20 --> Config Class Initialized
INFO - 2023-04-25 08:37:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:37:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:37:20 --> Utf8 Class Initialized
INFO - 2023-04-25 08:37:20 --> URI Class Initialized
INFO - 2023-04-25 08:37:20 --> Router Class Initialized
INFO - 2023-04-25 08:37:20 --> Output Class Initialized
INFO - 2023-04-25 08:37:20 --> Security Class Initialized
DEBUG - 2023-04-25 08:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:37:20 --> Input Class Initialized
INFO - 2023-04-25 08:37:20 --> Language Class Initialized
INFO - 2023-04-25 08:37:20 --> Loader Class Initialized
INFO - 2023-04-25 08:37:20 --> Helper loaded: url_helper
INFO - 2023-04-25 08:37:20 --> Helper loaded: file_helper
INFO - 2023-04-25 08:37:20 --> Helper loaded: html_helper
INFO - 2023-04-25 08:37:20 --> Helper loaded: text_helper
INFO - 2023-04-25 08:37:20 --> Helper loaded: form_helper
INFO - 2023-04-25 08:37:20 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:37:20 --> Helper loaded: security_helper
INFO - 2023-04-25 08:37:20 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:37:20 --> Database Driver Class Initialized
INFO - 2023-04-25 08:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:37:20 --> Parser Class Initialized
INFO - 2023-04-25 08:37:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:37:20 --> Pagination Class Initialized
INFO - 2023-04-25 08:37:20 --> Form Validation Class Initialized
INFO - 2023-04-25 08:37:20 --> Controller Class Initialized
INFO - 2023-04-25 08:37:20 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:20 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:20 --> Model Class Initialized
INFO - 2023-04-25 08:37:20 --> Final output sent to browser
DEBUG - 2023-04-25 08:37:20 --> Total execution time: 0.0205
ERROR - 2023-04-25 08:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:37:24 --> Config Class Initialized
INFO - 2023-04-25 08:37:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:37:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:37:24 --> Utf8 Class Initialized
INFO - 2023-04-25 08:37:24 --> URI Class Initialized
INFO - 2023-04-25 08:37:24 --> Router Class Initialized
INFO - 2023-04-25 08:37:24 --> Output Class Initialized
INFO - 2023-04-25 08:37:24 --> Security Class Initialized
DEBUG - 2023-04-25 08:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:37:24 --> Input Class Initialized
INFO - 2023-04-25 08:37:24 --> Language Class Initialized
INFO - 2023-04-25 08:37:24 --> Loader Class Initialized
INFO - 2023-04-25 08:37:24 --> Helper loaded: url_helper
INFO - 2023-04-25 08:37:24 --> Helper loaded: file_helper
INFO - 2023-04-25 08:37:24 --> Helper loaded: html_helper
INFO - 2023-04-25 08:37:24 --> Helper loaded: text_helper
INFO - 2023-04-25 08:37:24 --> Helper loaded: form_helper
INFO - 2023-04-25 08:37:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:37:24 --> Helper loaded: security_helper
INFO - 2023-04-25 08:37:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:37:24 --> Database Driver Class Initialized
INFO - 2023-04-25 08:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:37:24 --> Parser Class Initialized
INFO - 2023-04-25 08:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:37:24 --> Pagination Class Initialized
INFO - 2023-04-25 08:37:24 --> Form Validation Class Initialized
INFO - 2023-04-25 08:37:24 --> Controller Class Initialized
INFO - 2023-04-25 08:37:24 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:24 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:24 --> Model Class Initialized
INFO - 2023-04-25 08:37:24 --> Final output sent to browser
DEBUG - 2023-04-25 08:37:24 --> Total execution time: 0.0218
ERROR - 2023-04-25 08:37:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:37:25 --> Config Class Initialized
INFO - 2023-04-25 08:37:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:37:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:37:25 --> Utf8 Class Initialized
INFO - 2023-04-25 08:37:25 --> URI Class Initialized
INFO - 2023-04-25 08:37:25 --> Router Class Initialized
INFO - 2023-04-25 08:37:25 --> Output Class Initialized
INFO - 2023-04-25 08:37:25 --> Security Class Initialized
DEBUG - 2023-04-25 08:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:37:25 --> Input Class Initialized
INFO - 2023-04-25 08:37:25 --> Language Class Initialized
INFO - 2023-04-25 08:37:25 --> Loader Class Initialized
INFO - 2023-04-25 08:37:25 --> Helper loaded: url_helper
INFO - 2023-04-25 08:37:25 --> Helper loaded: file_helper
INFO - 2023-04-25 08:37:25 --> Helper loaded: html_helper
INFO - 2023-04-25 08:37:25 --> Helper loaded: text_helper
INFO - 2023-04-25 08:37:25 --> Helper loaded: form_helper
INFO - 2023-04-25 08:37:25 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:37:25 --> Helper loaded: security_helper
INFO - 2023-04-25 08:37:25 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:37:25 --> Database Driver Class Initialized
INFO - 2023-04-25 08:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:37:25 --> Parser Class Initialized
INFO - 2023-04-25 08:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:37:25 --> Pagination Class Initialized
INFO - 2023-04-25 08:37:25 --> Form Validation Class Initialized
INFO - 2023-04-25 08:37:25 --> Controller Class Initialized
INFO - 2023-04-25 08:37:25 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:25 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:25 --> Model Class Initialized
INFO - 2023-04-25 08:37:25 --> Final output sent to browser
DEBUG - 2023-04-25 08:37:25 --> Total execution time: 0.0172
ERROR - 2023-04-25 08:37:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 08:37:30 --> Config Class Initialized
INFO - 2023-04-25 08:37:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:37:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:37:30 --> Utf8 Class Initialized
INFO - 2023-04-25 08:37:30 --> URI Class Initialized
INFO - 2023-04-25 08:37:30 --> Router Class Initialized
INFO - 2023-04-25 08:37:30 --> Output Class Initialized
INFO - 2023-04-25 08:37:30 --> Security Class Initialized
DEBUG - 2023-04-25 08:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:37:30 --> Input Class Initialized
INFO - 2023-04-25 08:37:30 --> Language Class Initialized
INFO - 2023-04-25 08:37:30 --> Loader Class Initialized
INFO - 2023-04-25 08:37:30 --> Helper loaded: url_helper
INFO - 2023-04-25 08:37:30 --> Helper loaded: file_helper
INFO - 2023-04-25 08:37:30 --> Helper loaded: html_helper
INFO - 2023-04-25 08:37:30 --> Helper loaded: text_helper
INFO - 2023-04-25 08:37:30 --> Helper loaded: form_helper
INFO - 2023-04-25 08:37:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 08:37:30 --> Helper loaded: security_helper
INFO - 2023-04-25 08:37:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 08:37:30 --> Database Driver Class Initialized
INFO - 2023-04-25 08:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 08:37:30 --> Parser Class Initialized
INFO - 2023-04-25 08:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 08:37:30 --> Pagination Class Initialized
INFO - 2023-04-25 08:37:30 --> Form Validation Class Initialized
INFO - 2023-04-25 08:37:30 --> Controller Class Initialized
INFO - 2023-04-25 08:37:30 --> Model Class Initialized
DEBUG - 2023-04-25 08:37:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 08:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 08:37:30 --> Model Class Initialized
INFO - 2023-04-25 08:37:30 --> Model Class Initialized
INFO - 2023-04-25 08:37:30 --> Final output sent to browser
DEBUG - 2023-04-25 08:37:30 --> Total execution time: 0.0190
ERROR - 2023-04-25 13:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:12:26 --> Config Class Initialized
INFO - 2023-04-25 13:12:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:26 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:26 --> URI Class Initialized
DEBUG - 2023-04-25 13:12:26 --> No URI present. Default controller set.
INFO - 2023-04-25 13:12:26 --> Router Class Initialized
INFO - 2023-04-25 13:12:26 --> Output Class Initialized
INFO - 2023-04-25 13:12:26 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:26 --> Input Class Initialized
INFO - 2023-04-25 13:12:26 --> Language Class Initialized
INFO - 2023-04-25 13:12:26 --> Loader Class Initialized
INFO - 2023-04-25 13:12:26 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:26 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:26 --> Helper loaded: html_helper
INFO - 2023-04-25 13:12:26 --> Helper loaded: text_helper
INFO - 2023-04-25 13:12:26 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:26 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:12:26 --> Helper loaded: security_helper
INFO - 2023-04-25 13:12:26 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:12:26 --> Database Driver Class Initialized
INFO - 2023-04-25 13:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:26 --> Parser Class Initialized
INFO - 2023-04-25 13:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:12:26 --> Pagination Class Initialized
INFO - 2023-04-25 13:12:26 --> Form Validation Class Initialized
INFO - 2023-04-25 13:12:26 --> Controller Class Initialized
INFO - 2023-04-25 13:12:26 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 13:12:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:12:27 --> Config Class Initialized
INFO - 2023-04-25 13:12:27 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:27 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:27 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:27 --> URI Class Initialized
INFO - 2023-04-25 13:12:27 --> Router Class Initialized
INFO - 2023-04-25 13:12:27 --> Output Class Initialized
INFO - 2023-04-25 13:12:27 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:27 --> Input Class Initialized
INFO - 2023-04-25 13:12:27 --> Language Class Initialized
INFO - 2023-04-25 13:12:27 --> Loader Class Initialized
INFO - 2023-04-25 13:12:27 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:27 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:27 --> Helper loaded: html_helper
INFO - 2023-04-25 13:12:27 --> Helper loaded: text_helper
INFO - 2023-04-25 13:12:27 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:27 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:12:27 --> Helper loaded: security_helper
INFO - 2023-04-25 13:12:27 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:12:27 --> Database Driver Class Initialized
INFO - 2023-04-25 13:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:27 --> Parser Class Initialized
INFO - 2023-04-25 13:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:12:27 --> Pagination Class Initialized
INFO - 2023-04-25 13:12:27 --> Form Validation Class Initialized
INFO - 2023-04-25 13:12:27 --> Controller Class Initialized
INFO - 2023-04-25 13:12:27 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 13:12:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:12:27 --> Model Class Initialized
INFO - 2023-04-25 13:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:12:27 --> Final output sent to browser
DEBUG - 2023-04-25 13:12:27 --> Total execution time: 0.0319
ERROR - 2023-04-25 13:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:12:35 --> Config Class Initialized
INFO - 2023-04-25 13:12:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:35 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:35 --> URI Class Initialized
DEBUG - 2023-04-25 13:12:35 --> No URI present. Default controller set.
INFO - 2023-04-25 13:12:35 --> Router Class Initialized
INFO - 2023-04-25 13:12:35 --> Output Class Initialized
INFO - 2023-04-25 13:12:35 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:35 --> Input Class Initialized
INFO - 2023-04-25 13:12:35 --> Language Class Initialized
INFO - 2023-04-25 13:12:35 --> Loader Class Initialized
INFO - 2023-04-25 13:12:35 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:35 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:35 --> Helper loaded: html_helper
INFO - 2023-04-25 13:12:35 --> Helper loaded: text_helper
INFO - 2023-04-25 13:12:35 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:12:35 --> Helper loaded: security_helper
INFO - 2023-04-25 13:12:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:12:35 --> Database Driver Class Initialized
INFO - 2023-04-25 13:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:35 --> Parser Class Initialized
INFO - 2023-04-25 13:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:12:35 --> Pagination Class Initialized
INFO - 2023-04-25 13:12:35 --> Form Validation Class Initialized
INFO - 2023-04-25 13:12:35 --> Controller Class Initialized
INFO - 2023-04-25 13:12:35 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 13:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:12:36 --> Config Class Initialized
INFO - 2023-04-25 13:12:36 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:36 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:36 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:36 --> URI Class Initialized
INFO - 2023-04-25 13:12:36 --> Router Class Initialized
INFO - 2023-04-25 13:12:36 --> Output Class Initialized
INFO - 2023-04-25 13:12:36 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:36 --> Input Class Initialized
INFO - 2023-04-25 13:12:36 --> Language Class Initialized
INFO - 2023-04-25 13:12:36 --> Loader Class Initialized
INFO - 2023-04-25 13:12:36 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:36 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:36 --> Helper loaded: html_helper
INFO - 2023-04-25 13:12:36 --> Helper loaded: text_helper
INFO - 2023-04-25 13:12:36 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:36 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:12:36 --> Helper loaded: security_helper
INFO - 2023-04-25 13:12:36 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:12:36 --> Database Driver Class Initialized
INFO - 2023-04-25 13:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:36 --> Parser Class Initialized
INFO - 2023-04-25 13:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:12:36 --> Pagination Class Initialized
INFO - 2023-04-25 13:12:36 --> Form Validation Class Initialized
INFO - 2023-04-25 13:12:36 --> Controller Class Initialized
INFO - 2023-04-25 13:12:36 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 13:12:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:12:36 --> Model Class Initialized
INFO - 2023-04-25 13:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:12:36 --> Final output sent to browser
DEBUG - 2023-04-25 13:12:36 --> Total execution time: 0.0285
ERROR - 2023-04-25 13:12:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:12:53 --> Config Class Initialized
INFO - 2023-04-25 13:12:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:53 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:53 --> URI Class Initialized
INFO - 2023-04-25 13:12:53 --> Router Class Initialized
INFO - 2023-04-25 13:12:53 --> Output Class Initialized
INFO - 2023-04-25 13:12:53 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:53 --> Input Class Initialized
INFO - 2023-04-25 13:12:53 --> Language Class Initialized
INFO - 2023-04-25 13:12:53 --> Loader Class Initialized
INFO - 2023-04-25 13:12:53 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:53 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:53 --> Helper loaded: html_helper
INFO - 2023-04-25 13:12:53 --> Helper loaded: text_helper
INFO - 2023-04-25 13:12:53 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:12:53 --> Helper loaded: security_helper
INFO - 2023-04-25 13:12:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:12:53 --> Database Driver Class Initialized
INFO - 2023-04-25 13:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:53 --> Parser Class Initialized
INFO - 2023-04-25 13:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:12:53 --> Pagination Class Initialized
INFO - 2023-04-25 13:12:53 --> Form Validation Class Initialized
INFO - 2023-04-25 13:12:53 --> Controller Class Initialized
INFO - 2023-04-25 13:12:53 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:53 --> Model Class Initialized
INFO - 2023-04-25 13:12:53 --> Final output sent to browser
DEBUG - 2023-04-25 13:12:53 --> Total execution time: 0.0208
ERROR - 2023-04-25 13:12:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:12:54 --> Config Class Initialized
INFO - 2023-04-25 13:12:54 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:12:54 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:12:54 --> Utf8 Class Initialized
INFO - 2023-04-25 13:12:54 --> URI Class Initialized
DEBUG - 2023-04-25 13:12:54 --> No URI present. Default controller set.
INFO - 2023-04-25 13:12:54 --> Router Class Initialized
INFO - 2023-04-25 13:12:54 --> Output Class Initialized
INFO - 2023-04-25 13:12:54 --> Security Class Initialized
DEBUG - 2023-04-25 13:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:12:54 --> Input Class Initialized
INFO - 2023-04-25 13:12:54 --> Language Class Initialized
INFO - 2023-04-25 13:12:54 --> Loader Class Initialized
INFO - 2023-04-25 13:12:54 --> Helper loaded: url_helper
INFO - 2023-04-25 13:12:54 --> Helper loaded: file_helper
INFO - 2023-04-25 13:12:54 --> Helper loaded: html_helper
INFO - 2023-04-25 13:12:54 --> Helper loaded: text_helper
INFO - 2023-04-25 13:12:54 --> Helper loaded: form_helper
INFO - 2023-04-25 13:12:54 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:12:54 --> Helper loaded: security_helper
INFO - 2023-04-25 13:12:54 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:12:54 --> Database Driver Class Initialized
INFO - 2023-04-25 13:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:12:54 --> Parser Class Initialized
INFO - 2023-04-25 13:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:12:54 --> Pagination Class Initialized
INFO - 2023-04-25 13:12:54 --> Form Validation Class Initialized
INFO - 2023-04-25 13:12:54 --> Controller Class Initialized
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
DEBUG - 2023-04-25 13:12:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 13:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
INFO - 2023-04-25 13:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 13:12:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:12:54 --> Model Class Initialized
INFO - 2023-04-25 13:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 13:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 13:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:12:54 --> Final output sent to browser
DEBUG - 2023-04-25 13:12:54 --> Total execution time: 0.0713
ERROR - 2023-04-25 13:13:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:13:49 --> Config Class Initialized
INFO - 2023-04-25 13:13:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:13:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:13:49 --> Utf8 Class Initialized
INFO - 2023-04-25 13:13:49 --> URI Class Initialized
DEBUG - 2023-04-25 13:13:49 --> No URI present. Default controller set.
INFO - 2023-04-25 13:13:49 --> Router Class Initialized
INFO - 2023-04-25 13:13:49 --> Output Class Initialized
INFO - 2023-04-25 13:13:49 --> Security Class Initialized
DEBUG - 2023-04-25 13:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:13:49 --> Input Class Initialized
INFO - 2023-04-25 13:13:49 --> Language Class Initialized
INFO - 2023-04-25 13:13:49 --> Loader Class Initialized
INFO - 2023-04-25 13:13:49 --> Helper loaded: url_helper
INFO - 2023-04-25 13:13:49 --> Helper loaded: file_helper
INFO - 2023-04-25 13:13:49 --> Helper loaded: html_helper
INFO - 2023-04-25 13:13:49 --> Helper loaded: text_helper
INFO - 2023-04-25 13:13:49 --> Helper loaded: form_helper
INFO - 2023-04-25 13:13:49 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:13:49 --> Helper loaded: security_helper
INFO - 2023-04-25 13:13:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:13:49 --> Database Driver Class Initialized
INFO - 2023-04-25 13:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:13:49 --> Parser Class Initialized
INFO - 2023-04-25 13:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:13:49 --> Pagination Class Initialized
INFO - 2023-04-25 13:13:49 --> Form Validation Class Initialized
INFO - 2023-04-25 13:13:49 --> Controller Class Initialized
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
DEBUG - 2023-04-25 13:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
DEBUG - 2023-04-25 13:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
DEBUG - 2023-04-25 13:13:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 13:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
INFO - 2023-04-25 13:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 13:13:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:13:49 --> Model Class Initialized
INFO - 2023-04-25 13:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 13:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 13:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:13:49 --> Final output sent to browser
DEBUG - 2023-04-25 13:13:49 --> Total execution time: 0.0602
ERROR - 2023-04-25 13:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:34:35 --> Config Class Initialized
INFO - 2023-04-25 13:34:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:34:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:34:35 --> Utf8 Class Initialized
INFO - 2023-04-25 13:34:35 --> URI Class Initialized
DEBUG - 2023-04-25 13:34:35 --> No URI present. Default controller set.
INFO - 2023-04-25 13:34:35 --> Router Class Initialized
INFO - 2023-04-25 13:34:35 --> Output Class Initialized
INFO - 2023-04-25 13:34:35 --> Security Class Initialized
DEBUG - 2023-04-25 13:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:34:35 --> Input Class Initialized
INFO - 2023-04-25 13:34:35 --> Language Class Initialized
INFO - 2023-04-25 13:34:35 --> Loader Class Initialized
INFO - 2023-04-25 13:34:35 --> Helper loaded: url_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: file_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: html_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: text_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: form_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: security_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:34:35 --> Database Driver Class Initialized
INFO - 2023-04-25 13:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:34:35 --> Parser Class Initialized
INFO - 2023-04-25 13:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:34:35 --> Pagination Class Initialized
INFO - 2023-04-25 13:34:35 --> Form Validation Class Initialized
INFO - 2023-04-25 13:34:35 --> Controller Class Initialized
INFO - 2023-04-25 13:34:35 --> Model Class Initialized
DEBUG - 2023-04-25 13:34:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 13:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:34:35 --> Config Class Initialized
INFO - 2023-04-25 13:34:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:34:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:34:35 --> Utf8 Class Initialized
INFO - 2023-04-25 13:34:35 --> URI Class Initialized
INFO - 2023-04-25 13:34:35 --> Router Class Initialized
INFO - 2023-04-25 13:34:35 --> Output Class Initialized
INFO - 2023-04-25 13:34:35 --> Security Class Initialized
DEBUG - 2023-04-25 13:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:34:35 --> Input Class Initialized
INFO - 2023-04-25 13:34:35 --> Language Class Initialized
INFO - 2023-04-25 13:34:35 --> Loader Class Initialized
INFO - 2023-04-25 13:34:35 --> Helper loaded: url_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: file_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: html_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: text_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: form_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: security_helper
INFO - 2023-04-25 13:34:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:34:35 --> Database Driver Class Initialized
INFO - 2023-04-25 13:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:34:35 --> Parser Class Initialized
INFO - 2023-04-25 13:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:34:35 --> Pagination Class Initialized
INFO - 2023-04-25 13:34:35 --> Form Validation Class Initialized
INFO - 2023-04-25 13:34:35 --> Controller Class Initialized
INFO - 2023-04-25 13:34:35 --> Model Class Initialized
DEBUG - 2023-04-25 13:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 13:34:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:34:35 --> Model Class Initialized
INFO - 2023-04-25 13:34:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:34:35 --> Final output sent to browser
DEBUG - 2023-04-25 13:34:35 --> Total execution time: 0.0306
ERROR - 2023-04-25 13:36:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:36:55 --> Config Class Initialized
INFO - 2023-04-25 13:36:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:36:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:36:55 --> Utf8 Class Initialized
INFO - 2023-04-25 13:36:55 --> URI Class Initialized
DEBUG - 2023-04-25 13:36:55 --> No URI present. Default controller set.
INFO - 2023-04-25 13:36:55 --> Router Class Initialized
INFO - 2023-04-25 13:36:55 --> Output Class Initialized
INFO - 2023-04-25 13:36:55 --> Security Class Initialized
DEBUG - 2023-04-25 13:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:36:55 --> Input Class Initialized
INFO - 2023-04-25 13:36:55 --> Language Class Initialized
INFO - 2023-04-25 13:36:55 --> Loader Class Initialized
INFO - 2023-04-25 13:36:55 --> Helper loaded: url_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: file_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: html_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: text_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: form_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: security_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:36:55 --> Database Driver Class Initialized
INFO - 2023-04-25 13:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:36:55 --> Parser Class Initialized
INFO - 2023-04-25 13:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:36:55 --> Pagination Class Initialized
INFO - 2023-04-25 13:36:55 --> Form Validation Class Initialized
INFO - 2023-04-25 13:36:55 --> Controller Class Initialized
INFO - 2023-04-25 13:36:55 --> Model Class Initialized
DEBUG - 2023-04-25 13:36:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 13:36:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:36:55 --> Config Class Initialized
INFO - 2023-04-25 13:36:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:36:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:36:55 --> Utf8 Class Initialized
INFO - 2023-04-25 13:36:55 --> URI Class Initialized
INFO - 2023-04-25 13:36:55 --> Router Class Initialized
INFO - 2023-04-25 13:36:55 --> Output Class Initialized
INFO - 2023-04-25 13:36:55 --> Security Class Initialized
DEBUG - 2023-04-25 13:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:36:55 --> Input Class Initialized
INFO - 2023-04-25 13:36:55 --> Language Class Initialized
INFO - 2023-04-25 13:36:55 --> Loader Class Initialized
INFO - 2023-04-25 13:36:55 --> Helper loaded: url_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: file_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: html_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: text_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: form_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: security_helper
INFO - 2023-04-25 13:36:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:36:55 --> Database Driver Class Initialized
INFO - 2023-04-25 13:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:36:55 --> Parser Class Initialized
INFO - 2023-04-25 13:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:36:55 --> Pagination Class Initialized
INFO - 2023-04-25 13:36:55 --> Form Validation Class Initialized
INFO - 2023-04-25 13:36:55 --> Controller Class Initialized
INFO - 2023-04-25 13:36:55 --> Model Class Initialized
DEBUG - 2023-04-25 13:36:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:36:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 13:36:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:36:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:36:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:36:55 --> Model Class Initialized
INFO - 2023-04-25 13:36:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:36:55 --> Final output sent to browser
DEBUG - 2023-04-25 13:36:55 --> Total execution time: 0.0304
ERROR - 2023-04-25 13:37:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:37:30 --> Config Class Initialized
INFO - 2023-04-25 13:37:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:37:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:37:30 --> Utf8 Class Initialized
INFO - 2023-04-25 13:37:30 --> URI Class Initialized
DEBUG - 2023-04-25 13:37:30 --> No URI present. Default controller set.
INFO - 2023-04-25 13:37:30 --> Router Class Initialized
INFO - 2023-04-25 13:37:30 --> Output Class Initialized
INFO - 2023-04-25 13:37:30 --> Security Class Initialized
DEBUG - 2023-04-25 13:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:37:30 --> Input Class Initialized
INFO - 2023-04-25 13:37:30 --> Language Class Initialized
INFO - 2023-04-25 13:37:30 --> Loader Class Initialized
INFO - 2023-04-25 13:37:30 --> Helper loaded: url_helper
INFO - 2023-04-25 13:37:30 --> Helper loaded: file_helper
INFO - 2023-04-25 13:37:30 --> Helper loaded: html_helper
INFO - 2023-04-25 13:37:30 --> Helper loaded: text_helper
INFO - 2023-04-25 13:37:30 --> Helper loaded: form_helper
INFO - 2023-04-25 13:37:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:37:30 --> Helper loaded: security_helper
INFO - 2023-04-25 13:37:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:37:30 --> Database Driver Class Initialized
INFO - 2023-04-25 13:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:37:30 --> Parser Class Initialized
INFO - 2023-04-25 13:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:37:30 --> Pagination Class Initialized
INFO - 2023-04-25 13:37:30 --> Form Validation Class Initialized
INFO - 2023-04-25 13:37:30 --> Controller Class Initialized
INFO - 2023-04-25 13:37:30 --> Model Class Initialized
DEBUG - 2023-04-25 13:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 13:37:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:37:31 --> Config Class Initialized
INFO - 2023-04-25 13:37:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:37:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:37:31 --> Utf8 Class Initialized
INFO - 2023-04-25 13:37:31 --> URI Class Initialized
INFO - 2023-04-25 13:37:31 --> Router Class Initialized
INFO - 2023-04-25 13:37:31 --> Output Class Initialized
INFO - 2023-04-25 13:37:31 --> Security Class Initialized
DEBUG - 2023-04-25 13:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:37:31 --> Input Class Initialized
INFO - 2023-04-25 13:37:31 --> Language Class Initialized
INFO - 2023-04-25 13:37:31 --> Loader Class Initialized
INFO - 2023-04-25 13:37:31 --> Helper loaded: url_helper
INFO - 2023-04-25 13:37:31 --> Helper loaded: file_helper
INFO - 2023-04-25 13:37:31 --> Helper loaded: html_helper
INFO - 2023-04-25 13:37:31 --> Helper loaded: text_helper
INFO - 2023-04-25 13:37:31 --> Helper loaded: form_helper
INFO - 2023-04-25 13:37:31 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:37:31 --> Helper loaded: security_helper
INFO - 2023-04-25 13:37:31 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:37:31 --> Database Driver Class Initialized
INFO - 2023-04-25 13:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:37:31 --> Parser Class Initialized
INFO - 2023-04-25 13:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:37:31 --> Pagination Class Initialized
INFO - 2023-04-25 13:37:31 --> Form Validation Class Initialized
INFO - 2023-04-25 13:37:31 --> Controller Class Initialized
INFO - 2023-04-25 13:37:31 --> Model Class Initialized
DEBUG - 2023-04-25 13:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 13:37:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:37:31 --> Model Class Initialized
INFO - 2023-04-25 13:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:37:31 --> Final output sent to browser
DEBUG - 2023-04-25 13:37:31 --> Total execution time: 0.0267
ERROR - 2023-04-25 13:37:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:37:48 --> Config Class Initialized
INFO - 2023-04-25 13:37:48 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:37:48 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:37:48 --> Utf8 Class Initialized
INFO - 2023-04-25 13:37:48 --> URI Class Initialized
INFO - 2023-04-25 13:37:48 --> Router Class Initialized
INFO - 2023-04-25 13:37:48 --> Output Class Initialized
INFO - 2023-04-25 13:37:48 --> Security Class Initialized
DEBUG - 2023-04-25 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:37:48 --> Input Class Initialized
INFO - 2023-04-25 13:37:48 --> Language Class Initialized
INFO - 2023-04-25 13:37:48 --> Loader Class Initialized
INFO - 2023-04-25 13:37:48 --> Helper loaded: url_helper
INFO - 2023-04-25 13:37:48 --> Helper loaded: file_helper
INFO - 2023-04-25 13:37:48 --> Helper loaded: html_helper
INFO - 2023-04-25 13:37:48 --> Helper loaded: text_helper
INFO - 2023-04-25 13:37:48 --> Helper loaded: form_helper
INFO - 2023-04-25 13:37:48 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:37:48 --> Helper loaded: security_helper
INFO - 2023-04-25 13:37:48 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:37:48 --> Database Driver Class Initialized
INFO - 2023-04-25 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:37:48 --> Parser Class Initialized
INFO - 2023-04-25 13:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:37:48 --> Pagination Class Initialized
INFO - 2023-04-25 13:37:48 --> Form Validation Class Initialized
INFO - 2023-04-25 13:37:48 --> Controller Class Initialized
INFO - 2023-04-25 13:37:48 --> Model Class Initialized
DEBUG - 2023-04-25 13:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:37:48 --> Model Class Initialized
INFO - 2023-04-25 13:37:48 --> Final output sent to browser
DEBUG - 2023-04-25 13:37:48 --> Total execution time: 0.0210
ERROR - 2023-04-25 13:37:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:37:49 --> Config Class Initialized
INFO - 2023-04-25 13:37:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:37:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:37:49 --> Utf8 Class Initialized
INFO - 2023-04-25 13:37:49 --> URI Class Initialized
DEBUG - 2023-04-25 13:37:49 --> No URI present. Default controller set.
INFO - 2023-04-25 13:37:49 --> Router Class Initialized
INFO - 2023-04-25 13:37:49 --> Output Class Initialized
INFO - 2023-04-25 13:37:49 --> Security Class Initialized
DEBUG - 2023-04-25 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:37:49 --> Input Class Initialized
INFO - 2023-04-25 13:37:49 --> Language Class Initialized
INFO - 2023-04-25 13:37:49 --> Loader Class Initialized
INFO - 2023-04-25 13:37:49 --> Helper loaded: url_helper
INFO - 2023-04-25 13:37:49 --> Helper loaded: file_helper
INFO - 2023-04-25 13:37:49 --> Helper loaded: html_helper
INFO - 2023-04-25 13:37:49 --> Helper loaded: text_helper
INFO - 2023-04-25 13:37:49 --> Helper loaded: form_helper
INFO - 2023-04-25 13:37:49 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:37:49 --> Helper loaded: security_helper
INFO - 2023-04-25 13:37:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:37:49 --> Database Driver Class Initialized
INFO - 2023-04-25 13:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:37:49 --> Parser Class Initialized
INFO - 2023-04-25 13:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:37:49 --> Pagination Class Initialized
INFO - 2023-04-25 13:37:49 --> Form Validation Class Initialized
INFO - 2023-04-25 13:37:49 --> Controller Class Initialized
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
DEBUG - 2023-04-25 13:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
DEBUG - 2023-04-25 13:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
DEBUG - 2023-04-25 13:37:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 13:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
INFO - 2023-04-25 13:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 13:37:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:37:49 --> Model Class Initialized
INFO - 2023-04-25 13:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 13:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 13:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:37:49 --> Final output sent to browser
DEBUG - 2023-04-25 13:37:49 --> Total execution time: 0.0744
ERROR - 2023-04-25 13:38:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:38:21 --> Config Class Initialized
INFO - 2023-04-25 13:38:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:38:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:38:21 --> Utf8 Class Initialized
INFO - 2023-04-25 13:38:21 --> URI Class Initialized
INFO - 2023-04-25 13:38:21 --> Router Class Initialized
INFO - 2023-04-25 13:38:21 --> Output Class Initialized
INFO - 2023-04-25 13:38:21 --> Security Class Initialized
DEBUG - 2023-04-25 13:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:38:21 --> Input Class Initialized
INFO - 2023-04-25 13:38:21 --> Language Class Initialized
INFO - 2023-04-25 13:38:21 --> Loader Class Initialized
INFO - 2023-04-25 13:38:21 --> Helper loaded: url_helper
INFO - 2023-04-25 13:38:21 --> Helper loaded: file_helper
INFO - 2023-04-25 13:38:21 --> Helper loaded: html_helper
INFO - 2023-04-25 13:38:21 --> Helper loaded: text_helper
INFO - 2023-04-25 13:38:21 --> Helper loaded: form_helper
INFO - 2023-04-25 13:38:21 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:38:21 --> Helper loaded: security_helper
INFO - 2023-04-25 13:38:21 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:38:21 --> Database Driver Class Initialized
INFO - 2023-04-25 13:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:38:21 --> Parser Class Initialized
INFO - 2023-04-25 13:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:38:21 --> Pagination Class Initialized
INFO - 2023-04-25 13:38:21 --> Form Validation Class Initialized
INFO - 2023-04-25 13:38:21 --> Controller Class Initialized
INFO - 2023-04-25 13:38:21 --> Model Class Initialized
DEBUG - 2023-04-25 13:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 13:38:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:38:21 --> Model Class Initialized
INFO - 2023-04-25 13:38:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:38:21 --> Final output sent to browser
DEBUG - 2023-04-25 13:38:21 --> Total execution time: 0.0310
ERROR - 2023-04-25 13:38:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 13:38:22 --> Config Class Initialized
INFO - 2023-04-25 13:38:22 --> Hooks Class Initialized
DEBUG - 2023-04-25 13:38:22 --> UTF-8 Support Enabled
INFO - 2023-04-25 13:38:22 --> Utf8 Class Initialized
INFO - 2023-04-25 13:38:22 --> URI Class Initialized
INFO - 2023-04-25 13:38:22 --> Router Class Initialized
INFO - 2023-04-25 13:38:22 --> Output Class Initialized
INFO - 2023-04-25 13:38:22 --> Security Class Initialized
DEBUG - 2023-04-25 13:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 13:38:22 --> Input Class Initialized
INFO - 2023-04-25 13:38:22 --> Language Class Initialized
INFO - 2023-04-25 13:38:22 --> Loader Class Initialized
INFO - 2023-04-25 13:38:22 --> Helper loaded: url_helper
INFO - 2023-04-25 13:38:22 --> Helper loaded: file_helper
INFO - 2023-04-25 13:38:22 --> Helper loaded: html_helper
INFO - 2023-04-25 13:38:22 --> Helper loaded: text_helper
INFO - 2023-04-25 13:38:22 --> Helper loaded: form_helper
INFO - 2023-04-25 13:38:22 --> Helper loaded: lang_helper
INFO - 2023-04-25 13:38:22 --> Helper loaded: security_helper
INFO - 2023-04-25 13:38:22 --> Helper loaded: cookie_helper
INFO - 2023-04-25 13:38:22 --> Database Driver Class Initialized
INFO - 2023-04-25 13:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 13:38:22 --> Parser Class Initialized
INFO - 2023-04-25 13:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 13:38:22 --> Pagination Class Initialized
INFO - 2023-04-25 13:38:22 --> Form Validation Class Initialized
INFO - 2023-04-25 13:38:22 --> Controller Class Initialized
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
DEBUG - 2023-04-25 13:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
DEBUG - 2023-04-25 13:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
DEBUG - 2023-04-25 13:38:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 13:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
INFO - 2023-04-25 13:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 13:38:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 13:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 13:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 13:38:22 --> Model Class Initialized
INFO - 2023-04-25 13:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 13:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 13:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 13:38:22 --> Final output sent to browser
DEBUG - 2023-04-25 13:38:22 --> Total execution time: 0.0702
ERROR - 2023-04-25 14:02:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:02:24 --> Config Class Initialized
INFO - 2023-04-25 14:02:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:02:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:02:24 --> Utf8 Class Initialized
INFO - 2023-04-25 14:02:24 --> URI Class Initialized
DEBUG - 2023-04-25 14:02:24 --> No URI present. Default controller set.
INFO - 2023-04-25 14:02:24 --> Router Class Initialized
INFO - 2023-04-25 14:02:24 --> Output Class Initialized
INFO - 2023-04-25 14:02:24 --> Security Class Initialized
DEBUG - 2023-04-25 14:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:02:24 --> Input Class Initialized
INFO - 2023-04-25 14:02:24 --> Language Class Initialized
INFO - 2023-04-25 14:02:24 --> Loader Class Initialized
INFO - 2023-04-25 14:02:24 --> Helper loaded: url_helper
INFO - 2023-04-25 14:02:24 --> Helper loaded: file_helper
INFO - 2023-04-25 14:02:24 --> Helper loaded: html_helper
INFO - 2023-04-25 14:02:24 --> Helper loaded: text_helper
INFO - 2023-04-25 14:02:24 --> Helper loaded: form_helper
INFO - 2023-04-25 14:02:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:02:24 --> Helper loaded: security_helper
INFO - 2023-04-25 14:02:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:02:24 --> Database Driver Class Initialized
INFO - 2023-04-25 14:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:02:24 --> Parser Class Initialized
INFO - 2023-04-25 14:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:02:24 --> Pagination Class Initialized
INFO - 2023-04-25 14:02:24 --> Form Validation Class Initialized
INFO - 2023-04-25 14:02:24 --> Controller Class Initialized
INFO - 2023-04-25 14:02:24 --> Model Class Initialized
DEBUG - 2023-04-25 14:02:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 14:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:02:25 --> Config Class Initialized
INFO - 2023-04-25 14:02:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:02:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:02:25 --> Utf8 Class Initialized
INFO - 2023-04-25 14:02:25 --> URI Class Initialized
INFO - 2023-04-25 14:02:25 --> Router Class Initialized
INFO - 2023-04-25 14:02:25 --> Output Class Initialized
INFO - 2023-04-25 14:02:25 --> Security Class Initialized
DEBUG - 2023-04-25 14:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:02:25 --> Input Class Initialized
INFO - 2023-04-25 14:02:25 --> Language Class Initialized
INFO - 2023-04-25 14:02:25 --> Loader Class Initialized
INFO - 2023-04-25 14:02:25 --> Helper loaded: url_helper
INFO - 2023-04-25 14:02:25 --> Helper loaded: file_helper
INFO - 2023-04-25 14:02:25 --> Helper loaded: html_helper
INFO - 2023-04-25 14:02:25 --> Helper loaded: text_helper
INFO - 2023-04-25 14:02:25 --> Helper loaded: form_helper
INFO - 2023-04-25 14:02:25 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:02:25 --> Helper loaded: security_helper
INFO - 2023-04-25 14:02:25 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:02:25 --> Database Driver Class Initialized
INFO - 2023-04-25 14:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:02:25 --> Parser Class Initialized
INFO - 2023-04-25 14:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:02:25 --> Pagination Class Initialized
INFO - 2023-04-25 14:02:25 --> Form Validation Class Initialized
INFO - 2023-04-25 14:02:25 --> Controller Class Initialized
INFO - 2023-04-25 14:02:25 --> Model Class Initialized
DEBUG - 2023-04-25 14:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 14:02:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:02:25 --> Model Class Initialized
INFO - 2023-04-25 14:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:02:25 --> Final output sent to browser
DEBUG - 2023-04-25 14:02:25 --> Total execution time: 0.0408
ERROR - 2023-04-25 14:02:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:02:48 --> Config Class Initialized
INFO - 2023-04-25 14:02:48 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:02:48 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:02:48 --> Utf8 Class Initialized
INFO - 2023-04-25 14:02:48 --> URI Class Initialized
INFO - 2023-04-25 14:02:48 --> Router Class Initialized
INFO - 2023-04-25 14:02:48 --> Output Class Initialized
INFO - 2023-04-25 14:02:48 --> Security Class Initialized
DEBUG - 2023-04-25 14:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:02:48 --> Input Class Initialized
INFO - 2023-04-25 14:02:48 --> Language Class Initialized
INFO - 2023-04-25 14:02:48 --> Loader Class Initialized
INFO - 2023-04-25 14:02:48 --> Helper loaded: url_helper
INFO - 2023-04-25 14:02:48 --> Helper loaded: file_helper
INFO - 2023-04-25 14:02:48 --> Helper loaded: html_helper
INFO - 2023-04-25 14:02:48 --> Helper loaded: text_helper
INFO - 2023-04-25 14:02:48 --> Helper loaded: form_helper
INFO - 2023-04-25 14:02:48 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:02:48 --> Helper loaded: security_helper
INFO - 2023-04-25 14:02:48 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:02:48 --> Database Driver Class Initialized
INFO - 2023-04-25 14:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:02:48 --> Parser Class Initialized
INFO - 2023-04-25 14:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:02:48 --> Pagination Class Initialized
INFO - 2023-04-25 14:02:48 --> Form Validation Class Initialized
INFO - 2023-04-25 14:02:48 --> Controller Class Initialized
INFO - 2023-04-25 14:02:48 --> Model Class Initialized
DEBUG - 2023-04-25 14:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:02:48 --> Model Class Initialized
INFO - 2023-04-25 14:02:48 --> Final output sent to browser
DEBUG - 2023-04-25 14:02:48 --> Total execution time: 0.0219
ERROR - 2023-04-25 14:02:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:02:49 --> Config Class Initialized
INFO - 2023-04-25 14:02:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:02:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:02:49 --> Utf8 Class Initialized
INFO - 2023-04-25 14:02:49 --> URI Class Initialized
DEBUG - 2023-04-25 14:02:49 --> No URI present. Default controller set.
INFO - 2023-04-25 14:02:49 --> Router Class Initialized
INFO - 2023-04-25 14:02:49 --> Output Class Initialized
INFO - 2023-04-25 14:02:49 --> Security Class Initialized
DEBUG - 2023-04-25 14:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:02:49 --> Input Class Initialized
INFO - 2023-04-25 14:02:49 --> Language Class Initialized
INFO - 2023-04-25 14:02:49 --> Loader Class Initialized
INFO - 2023-04-25 14:02:49 --> Helper loaded: url_helper
INFO - 2023-04-25 14:02:49 --> Helper loaded: file_helper
INFO - 2023-04-25 14:02:49 --> Helper loaded: html_helper
INFO - 2023-04-25 14:02:49 --> Helper loaded: text_helper
INFO - 2023-04-25 14:02:49 --> Helper loaded: form_helper
INFO - 2023-04-25 14:02:49 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:02:49 --> Helper loaded: security_helper
INFO - 2023-04-25 14:02:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:02:49 --> Database Driver Class Initialized
INFO - 2023-04-25 14:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:02:49 --> Parser Class Initialized
INFO - 2023-04-25 14:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:02:49 --> Pagination Class Initialized
INFO - 2023-04-25 14:02:49 --> Form Validation Class Initialized
INFO - 2023-04-25 14:02:49 --> Controller Class Initialized
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
DEBUG - 2023-04-25 14:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
DEBUG - 2023-04-25 14:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
DEBUG - 2023-04-25 14:02:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
INFO - 2023-04-25 14:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 14:02:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:02:49 --> Model Class Initialized
INFO - 2023-04-25 14:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:02:49 --> Final output sent to browser
DEBUG - 2023-04-25 14:02:49 --> Total execution time: 0.0673
ERROR - 2023-04-25 14:03:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:08 --> Config Class Initialized
INFO - 2023-04-25 14:03:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:08 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:08 --> URI Class Initialized
INFO - 2023-04-25 14:03:08 --> Router Class Initialized
INFO - 2023-04-25 14:03:08 --> Output Class Initialized
INFO - 2023-04-25 14:03:08 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:08 --> Input Class Initialized
INFO - 2023-04-25 14:03:08 --> Language Class Initialized
INFO - 2023-04-25 14:03:08 --> Loader Class Initialized
INFO - 2023-04-25 14:03:08 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:08 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:08 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:08 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:08 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:08 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:08 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:08 --> Parser Class Initialized
INFO - 2023-04-25 14:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:08 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:08 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:08 --> Controller Class Initialized
INFO - 2023-04-25 14:03:08 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:08 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:08 --> Model Class Initialized
INFO - 2023-04-25 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 14:03:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:08 --> Model Class Initialized
INFO - 2023-04-25 14:03:08 --> Model Class Initialized
INFO - 2023-04-25 14:03:08 --> Model Class Initialized
INFO - 2023-04-25 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:08 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:08 --> Total execution time: 0.0626
ERROR - 2023-04-25 14:03:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:09 --> Config Class Initialized
INFO - 2023-04-25 14:03:09 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:09 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:09 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:09 --> URI Class Initialized
INFO - 2023-04-25 14:03:09 --> Router Class Initialized
INFO - 2023-04-25 14:03:09 --> Output Class Initialized
INFO - 2023-04-25 14:03:09 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:09 --> Input Class Initialized
INFO - 2023-04-25 14:03:09 --> Language Class Initialized
INFO - 2023-04-25 14:03:09 --> Loader Class Initialized
INFO - 2023-04-25 14:03:09 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:09 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:09 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:09 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:09 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:09 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:09 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:09 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:09 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:09 --> Parser Class Initialized
INFO - 2023-04-25 14:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:09 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:09 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:09 --> Controller Class Initialized
INFO - 2023-04-25 14:03:09 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:09 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:09 --> Model Class Initialized
INFO - 2023-04-25 14:03:09 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:09 --> Total execution time: 0.0195
ERROR - 2023-04-25 14:03:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:16 --> Config Class Initialized
INFO - 2023-04-25 14:03:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:16 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:16 --> URI Class Initialized
INFO - 2023-04-25 14:03:16 --> Router Class Initialized
INFO - 2023-04-25 14:03:16 --> Output Class Initialized
INFO - 2023-04-25 14:03:16 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:16 --> Input Class Initialized
INFO - 2023-04-25 14:03:16 --> Language Class Initialized
INFO - 2023-04-25 14:03:16 --> Loader Class Initialized
INFO - 2023-04-25 14:03:16 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:16 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:16 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:16 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:16 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:16 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:16 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:16 --> Parser Class Initialized
INFO - 2023-04-25 14:03:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:16 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:16 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:16 --> Controller Class Initialized
INFO - 2023-04-25 14:03:16 --> Model Class Initialized
INFO - 2023-04-25 14:03:16 --> Model Class Initialized
INFO - 2023-04-25 14:03:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-04-25 14:03:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:16 --> Model Class Initialized
INFO - 2023-04-25 14:03:16 --> Model Class Initialized
INFO - 2023-04-25 14:03:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:16 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:16 --> Total execution time: 0.0520
ERROR - 2023-04-25 14:03:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:17 --> Config Class Initialized
INFO - 2023-04-25 14:03:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:17 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:17 --> URI Class Initialized
INFO - 2023-04-25 14:03:17 --> Router Class Initialized
INFO - 2023-04-25 14:03:17 --> Output Class Initialized
INFO - 2023-04-25 14:03:17 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:17 --> Input Class Initialized
INFO - 2023-04-25 14:03:17 --> Language Class Initialized
INFO - 2023-04-25 14:03:17 --> Loader Class Initialized
INFO - 2023-04-25 14:03:17 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:17 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:17 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:17 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:17 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:17 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:17 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:17 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:17 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:17 --> Parser Class Initialized
INFO - 2023-04-25 14:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:17 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:17 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:17 --> Controller Class Initialized
INFO - 2023-04-25 14:03:17 --> Model Class Initialized
INFO - 2023-04-25 14:03:17 --> Model Class Initialized
INFO - 2023-04-25 14:03:17 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:17 --> Total execution time: 0.0163
ERROR - 2023-04-25 14:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:31 --> Config Class Initialized
INFO - 2023-04-25 14:03:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:31 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:31 --> URI Class Initialized
INFO - 2023-04-25 14:03:31 --> Router Class Initialized
INFO - 2023-04-25 14:03:31 --> Output Class Initialized
INFO - 2023-04-25 14:03:31 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:31 --> Input Class Initialized
INFO - 2023-04-25 14:03:31 --> Language Class Initialized
INFO - 2023-04-25 14:03:31 --> Loader Class Initialized
INFO - 2023-04-25 14:03:31 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:31 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:31 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:31 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:31 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:31 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:31 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:31 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:31 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:31 --> Parser Class Initialized
INFO - 2023-04-25 14:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:31 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:31 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:31 --> Controller Class Initialized
INFO - 2023-04-25 14:03:31 --> Model Class Initialized
INFO - 2023-04-25 14:03:31 --> Model Class Initialized
INFO - 2023-04-25 14:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-04-25 14:03:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:31 --> Model Class Initialized
INFO - 2023-04-25 14:03:31 --> Model Class Initialized
INFO - 2023-04-25 14:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:31 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:31 --> Total execution time: 0.0639
ERROR - 2023-04-25 14:03:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:32 --> Config Class Initialized
INFO - 2023-04-25 14:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:32 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:32 --> URI Class Initialized
INFO - 2023-04-25 14:03:32 --> Router Class Initialized
INFO - 2023-04-25 14:03:32 --> Output Class Initialized
INFO - 2023-04-25 14:03:32 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:32 --> Input Class Initialized
INFO - 2023-04-25 14:03:32 --> Language Class Initialized
INFO - 2023-04-25 14:03:32 --> Loader Class Initialized
INFO - 2023-04-25 14:03:32 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:32 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:32 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:32 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:32 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:32 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:32 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:32 --> Parser Class Initialized
INFO - 2023-04-25 14:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:32 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:32 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:32 --> Controller Class Initialized
INFO - 2023-04-25 14:03:32 --> Model Class Initialized
INFO - 2023-04-25 14:03:32 --> Model Class Initialized
INFO - 2023-04-25 14:03:32 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:32 --> Total execution time: 0.0177
ERROR - 2023-04-25 14:03:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:38 --> Config Class Initialized
INFO - 2023-04-25 14:03:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:38 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:38 --> URI Class Initialized
INFO - 2023-04-25 14:03:38 --> Router Class Initialized
INFO - 2023-04-25 14:03:38 --> Output Class Initialized
INFO - 2023-04-25 14:03:38 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:38 --> Input Class Initialized
INFO - 2023-04-25 14:03:38 --> Language Class Initialized
INFO - 2023-04-25 14:03:38 --> Loader Class Initialized
INFO - 2023-04-25 14:03:38 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:38 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:38 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:38 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:38 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:38 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:38 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:38 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:38 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:38 --> Parser Class Initialized
INFO - 2023-04-25 14:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:38 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:38 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:38 --> Controller Class Initialized
INFO - 2023-04-25 14:03:38 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:38 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:38 --> Model Class Initialized
INFO - 2023-04-25 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 14:03:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:38 --> Model Class Initialized
INFO - 2023-04-25 14:03:38 --> Model Class Initialized
INFO - 2023-04-25 14:03:38 --> Model Class Initialized
INFO - 2023-04-25 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:38 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:38 --> Total execution time: 0.0586
ERROR - 2023-04-25 14:03:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:39 --> Config Class Initialized
INFO - 2023-04-25 14:03:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:39 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:39 --> URI Class Initialized
INFO - 2023-04-25 14:03:39 --> Router Class Initialized
INFO - 2023-04-25 14:03:39 --> Output Class Initialized
INFO - 2023-04-25 14:03:39 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:39 --> Input Class Initialized
INFO - 2023-04-25 14:03:39 --> Language Class Initialized
INFO - 2023-04-25 14:03:39 --> Loader Class Initialized
INFO - 2023-04-25 14:03:39 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:39 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:39 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:39 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:39 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:39 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:39 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:39 --> Parser Class Initialized
INFO - 2023-04-25 14:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:39 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:39 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:39 --> Controller Class Initialized
INFO - 2023-04-25 14:03:39 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:39 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:39 --> Model Class Initialized
INFO - 2023-04-25 14:03:39 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:39 --> Total execution time: 0.0193
ERROR - 2023-04-25 14:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:49 --> Config Class Initialized
INFO - 2023-04-25 14:03:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:49 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:49 --> URI Class Initialized
DEBUG - 2023-04-25 14:03:49 --> No URI present. Default controller set.
INFO - 2023-04-25 14:03:49 --> Router Class Initialized
INFO - 2023-04-25 14:03:49 --> Output Class Initialized
INFO - 2023-04-25 14:03:49 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:49 --> Input Class Initialized
INFO - 2023-04-25 14:03:49 --> Language Class Initialized
INFO - 2023-04-25 14:03:49 --> Loader Class Initialized
INFO - 2023-04-25 14:03:49 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:49 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:49 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:49 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:49 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:49 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:49 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:49 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:49 --> Parser Class Initialized
INFO - 2023-04-25 14:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:49 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:49 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:49 --> Controller Class Initialized
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
INFO - 2023-04-25 14:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 14:03:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:49 --> Model Class Initialized
INFO - 2023-04-25 14:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:49 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:49 --> Total execution time: 0.0562
ERROR - 2023-04-25 14:03:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:52 --> Config Class Initialized
INFO - 2023-04-25 14:03:52 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:52 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:52 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:52 --> URI Class Initialized
INFO - 2023-04-25 14:03:52 --> Router Class Initialized
INFO - 2023-04-25 14:03:52 --> Output Class Initialized
INFO - 2023-04-25 14:03:52 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:52 --> Input Class Initialized
INFO - 2023-04-25 14:03:52 --> Language Class Initialized
INFO - 2023-04-25 14:03:52 --> Loader Class Initialized
INFO - 2023-04-25 14:03:52 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:52 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:52 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:52 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:52 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:52 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:52 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:52 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:52 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:52 --> Parser Class Initialized
INFO - 2023-04-25 14:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:52 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:52 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:52 --> Controller Class Initialized
INFO - 2023-04-25 14:03:52 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:52 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:52 --> Model Class Initialized
INFO - 2023-04-25 14:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-25 14:03:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:52 --> Model Class Initialized
INFO - 2023-04-25 14:03:52 --> Model Class Initialized
INFO - 2023-04-25 14:03:52 --> Model Class Initialized
INFO - 2023-04-25 14:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:52 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:52 --> Total execution time: 0.0656
ERROR - 2023-04-25 14:03:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:53 --> Config Class Initialized
INFO - 2023-04-25 14:03:53 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:53 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:53 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:53 --> URI Class Initialized
INFO - 2023-04-25 14:03:53 --> Router Class Initialized
INFO - 2023-04-25 14:03:53 --> Output Class Initialized
INFO - 2023-04-25 14:03:53 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:53 --> Input Class Initialized
INFO - 2023-04-25 14:03:53 --> Language Class Initialized
INFO - 2023-04-25 14:03:53 --> Loader Class Initialized
INFO - 2023-04-25 14:03:53 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:53 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:53 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:53 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:53 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:53 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:53 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:53 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:53 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:53 --> Parser Class Initialized
INFO - 2023-04-25 14:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:53 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:53 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:53 --> Controller Class Initialized
INFO - 2023-04-25 14:03:53 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:53 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:53 --> Model Class Initialized
INFO - 2023-04-25 14:03:53 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:53 --> Total execution time: 0.0200
ERROR - 2023-04-25 14:03:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:56 --> Config Class Initialized
INFO - 2023-04-25 14:03:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:56 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:56 --> URI Class Initialized
DEBUG - 2023-04-25 14:03:56 --> No URI present. Default controller set.
INFO - 2023-04-25 14:03:56 --> Router Class Initialized
INFO - 2023-04-25 14:03:56 --> Output Class Initialized
INFO - 2023-04-25 14:03:56 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:56 --> Input Class Initialized
INFO - 2023-04-25 14:03:56 --> Language Class Initialized
INFO - 2023-04-25 14:03:56 --> Loader Class Initialized
INFO - 2023-04-25 14:03:56 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:56 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:56 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:56 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:56 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:56 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:56 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:56 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:56 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:56 --> Parser Class Initialized
INFO - 2023-04-25 14:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:56 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:56 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:56 --> Controller Class Initialized
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
INFO - 2023-04-25 14:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 14:03:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:56 --> Model Class Initialized
INFO - 2023-04-25 14:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:56 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:56 --> Total execution time: 0.0582
ERROR - 2023-04-25 14:03:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:58 --> Config Class Initialized
INFO - 2023-04-25 14:03:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:58 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:58 --> URI Class Initialized
INFO - 2023-04-25 14:03:58 --> Router Class Initialized
INFO - 2023-04-25 14:03:58 --> Output Class Initialized
INFO - 2023-04-25 14:03:58 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:58 --> Input Class Initialized
INFO - 2023-04-25 14:03:58 --> Language Class Initialized
INFO - 2023-04-25 14:03:58 --> Loader Class Initialized
INFO - 2023-04-25 14:03:58 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:58 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:58 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:58 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:58 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:58 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:58 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:58 --> Parser Class Initialized
INFO - 2023-04-25 14:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:58 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:58 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:58 --> Controller Class Initialized
INFO - 2023-04-25 14:03:58 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:58 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:58 --> Model Class Initialized
INFO - 2023-04-25 14:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-04-25 14:03:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:03:58 --> Model Class Initialized
INFO - 2023-04-25 14:03:58 --> Model Class Initialized
INFO - 2023-04-25 14:03:58 --> Model Class Initialized
INFO - 2023-04-25 14:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:03:58 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:58 --> Total execution time: 0.0556
ERROR - 2023-04-25 14:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:03:59 --> Config Class Initialized
INFO - 2023-04-25 14:03:59 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:03:59 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:03:59 --> Utf8 Class Initialized
INFO - 2023-04-25 14:03:59 --> URI Class Initialized
INFO - 2023-04-25 14:03:59 --> Router Class Initialized
INFO - 2023-04-25 14:03:59 --> Output Class Initialized
INFO - 2023-04-25 14:03:59 --> Security Class Initialized
DEBUG - 2023-04-25 14:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:03:59 --> Input Class Initialized
INFO - 2023-04-25 14:03:59 --> Language Class Initialized
INFO - 2023-04-25 14:03:59 --> Loader Class Initialized
INFO - 2023-04-25 14:03:59 --> Helper loaded: url_helper
INFO - 2023-04-25 14:03:59 --> Helper loaded: file_helper
INFO - 2023-04-25 14:03:59 --> Helper loaded: html_helper
INFO - 2023-04-25 14:03:59 --> Helper loaded: text_helper
INFO - 2023-04-25 14:03:59 --> Helper loaded: form_helper
INFO - 2023-04-25 14:03:59 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:03:59 --> Helper loaded: security_helper
INFO - 2023-04-25 14:03:59 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:03:59 --> Database Driver Class Initialized
INFO - 2023-04-25 14:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:03:59 --> Parser Class Initialized
INFO - 2023-04-25 14:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:03:59 --> Pagination Class Initialized
INFO - 2023-04-25 14:03:59 --> Form Validation Class Initialized
INFO - 2023-04-25 14:03:59 --> Controller Class Initialized
INFO - 2023-04-25 14:03:59 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:59 --> Model Class Initialized
DEBUG - 2023-04-25 14:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:03:59 --> Model Class Initialized
INFO - 2023-04-25 14:03:59 --> Final output sent to browser
DEBUG - 2023-04-25 14:03:59 --> Total execution time: 0.0191
ERROR - 2023-04-25 14:04:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:04 --> Config Class Initialized
INFO - 2023-04-25 14:04:04 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:04 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:04 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:04 --> URI Class Initialized
DEBUG - 2023-04-25 14:04:04 --> No URI present. Default controller set.
INFO - 2023-04-25 14:04:04 --> Router Class Initialized
INFO - 2023-04-25 14:04:04 --> Output Class Initialized
INFO - 2023-04-25 14:04:04 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:04 --> Input Class Initialized
INFO - 2023-04-25 14:04:04 --> Language Class Initialized
INFO - 2023-04-25 14:04:04 --> Loader Class Initialized
INFO - 2023-04-25 14:04:04 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:04 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:04 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:04 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:04 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:04 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:04 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:04 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:04 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:04 --> Parser Class Initialized
INFO - 2023-04-25 14:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:04 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:04 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:04 --> Controller Class Initialized
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
INFO - 2023-04-25 14:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 14:04:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:04 --> Model Class Initialized
INFO - 2023-04-25 14:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:04 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:04 --> Total execution time: 0.0601
ERROR - 2023-04-25 14:04:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:08 --> Config Class Initialized
INFO - 2023-04-25 14:04:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:08 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:08 --> URI Class Initialized
INFO - 2023-04-25 14:04:08 --> Router Class Initialized
INFO - 2023-04-25 14:04:08 --> Output Class Initialized
INFO - 2023-04-25 14:04:08 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:08 --> Input Class Initialized
INFO - 2023-04-25 14:04:08 --> Language Class Initialized
INFO - 2023-04-25 14:04:08 --> Loader Class Initialized
INFO - 2023-04-25 14:04:08 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:08 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:08 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:08 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:08 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:08 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:08 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:08 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:08 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:08 --> Parser Class Initialized
INFO - 2023-04-25 14:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:08 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:08 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:08 --> Controller Class Initialized
INFO - 2023-04-25 14:04:08 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:08 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:08 --> Model Class Initialized
INFO - 2023-04-25 14:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 14:04:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:08 --> Model Class Initialized
INFO - 2023-04-25 14:04:08 --> Model Class Initialized
INFO - 2023-04-25 14:04:08 --> Model Class Initialized
INFO - 2023-04-25 14:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:08 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:08 --> Total execution time: 0.0594
ERROR - 2023-04-25 14:04:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:09 --> Config Class Initialized
INFO - 2023-04-25 14:04:09 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:09 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:09 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:09 --> URI Class Initialized
INFO - 2023-04-25 14:04:09 --> Router Class Initialized
INFO - 2023-04-25 14:04:09 --> Output Class Initialized
INFO - 2023-04-25 14:04:09 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:09 --> Input Class Initialized
INFO - 2023-04-25 14:04:09 --> Language Class Initialized
INFO - 2023-04-25 14:04:09 --> Loader Class Initialized
INFO - 2023-04-25 14:04:09 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:09 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:09 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:09 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:09 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:09 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:09 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:09 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:09 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:09 --> Parser Class Initialized
INFO - 2023-04-25 14:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:09 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:09 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:09 --> Controller Class Initialized
INFO - 2023-04-25 14:04:09 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:09 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:09 --> Model Class Initialized
INFO - 2023-04-25 14:04:09 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:09 --> Total execution time: 0.0198
ERROR - 2023-04-25 14:04:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:12 --> Config Class Initialized
INFO - 2023-04-25 14:04:12 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:12 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:12 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:12 --> URI Class Initialized
DEBUG - 2023-04-25 14:04:12 --> No URI present. Default controller set.
INFO - 2023-04-25 14:04:12 --> Router Class Initialized
INFO - 2023-04-25 14:04:12 --> Output Class Initialized
INFO - 2023-04-25 14:04:12 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:12 --> Input Class Initialized
INFO - 2023-04-25 14:04:12 --> Language Class Initialized
INFO - 2023-04-25 14:04:12 --> Loader Class Initialized
INFO - 2023-04-25 14:04:12 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:12 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:12 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:12 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:12 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:12 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:12 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:12 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:12 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:12 --> Parser Class Initialized
INFO - 2023-04-25 14:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:12 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:12 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:12 --> Controller Class Initialized
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
INFO - 2023-04-25 14:04:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 14:04:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:12 --> Model Class Initialized
INFO - 2023-04-25 14:04:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:12 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:12 --> Total execution time: 0.0563
ERROR - 2023-04-25 14:04:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:25 --> Config Class Initialized
INFO - 2023-04-25 14:04:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:25 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:25 --> URI Class Initialized
INFO - 2023-04-25 14:04:25 --> Router Class Initialized
INFO - 2023-04-25 14:04:25 --> Output Class Initialized
INFO - 2023-04-25 14:04:25 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:25 --> Input Class Initialized
INFO - 2023-04-25 14:04:25 --> Language Class Initialized
INFO - 2023-04-25 14:04:25 --> Loader Class Initialized
INFO - 2023-04-25 14:04:25 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:25 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:25 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:25 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:25 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:25 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:25 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:25 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:25 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:25 --> Parser Class Initialized
INFO - 2023-04-25 14:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:25 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:25 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:25 --> Controller Class Initialized
INFO - 2023-04-25 14:04:25 --> Model Class Initialized
INFO - 2023-04-25 14:04:25 --> Model Class Initialized
INFO - 2023-04-25 14:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-04-25 14:04:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:25 --> Model Class Initialized
INFO - 2023-04-25 14:04:25 --> Model Class Initialized
INFO - 2023-04-25 14:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:25 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:25 --> Total execution time: 0.0521
ERROR - 2023-04-25 14:04:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:26 --> Config Class Initialized
INFO - 2023-04-25 14:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:26 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:26 --> URI Class Initialized
INFO - 2023-04-25 14:04:26 --> Router Class Initialized
INFO - 2023-04-25 14:04:26 --> Output Class Initialized
INFO - 2023-04-25 14:04:26 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:26 --> Input Class Initialized
INFO - 2023-04-25 14:04:26 --> Language Class Initialized
INFO - 2023-04-25 14:04:26 --> Loader Class Initialized
INFO - 2023-04-25 14:04:26 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:26 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:26 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:26 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:26 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:26 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:26 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:26 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:26 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:26 --> Parser Class Initialized
INFO - 2023-04-25 14:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:26 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:26 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:26 --> Controller Class Initialized
INFO - 2023-04-25 14:04:26 --> Model Class Initialized
INFO - 2023-04-25 14:04:26 --> Model Class Initialized
INFO - 2023-04-25 14:04:26 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:26 --> Total execution time: 0.0174
ERROR - 2023-04-25 14:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:32 --> Config Class Initialized
INFO - 2023-04-25 14:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:32 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:32 --> URI Class Initialized
INFO - 2023-04-25 14:04:32 --> Router Class Initialized
INFO - 2023-04-25 14:04:32 --> Output Class Initialized
INFO - 2023-04-25 14:04:32 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:32 --> Input Class Initialized
INFO - 2023-04-25 14:04:32 --> Language Class Initialized
INFO - 2023-04-25 14:04:32 --> Loader Class Initialized
INFO - 2023-04-25 14:04:32 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:32 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:32 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:32 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:32 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:32 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:32 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:32 --> Parser Class Initialized
INFO - 2023-04-25 14:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:32 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:32 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:32 --> Controller Class Initialized
DEBUG - 2023-04-25 14:04:32 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:32 --> Model Class Initialized
INFO - 2023-04-25 14:04:32 --> Model Class Initialized
INFO - 2023-04-25 14:04:32 --> Model Class Initialized
INFO - 2023-04-25 14:04:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-04-25 14:04:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:32 --> Model Class Initialized
INFO - 2023-04-25 14:04:32 --> Model Class Initialized
INFO - 2023-04-25 14:04:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:32 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:32 --> Total execution time: 0.0580
ERROR - 2023-04-25 14:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:40 --> Config Class Initialized
INFO - 2023-04-25 14:04:40 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:40 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:40 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:40 --> URI Class Initialized
INFO - 2023-04-25 14:04:40 --> Router Class Initialized
INFO - 2023-04-25 14:04:40 --> Output Class Initialized
INFO - 2023-04-25 14:04:40 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:40 --> Input Class Initialized
INFO - 2023-04-25 14:04:40 --> Language Class Initialized
INFO - 2023-04-25 14:04:40 --> Loader Class Initialized
INFO - 2023-04-25 14:04:40 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:40 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:40 --> Parser Class Initialized
INFO - 2023-04-25 14:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:40 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:40 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:40 --> Controller Class Initialized
INFO - 2023-04-25 14:04:40 --> Model Class Initialized
INFO - 2023-04-25 14:04:40 --> Model Class Initialized
INFO - 2023-04-25 14:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-04-25 14:04:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:40 --> Model Class Initialized
INFO - 2023-04-25 14:04:40 --> Model Class Initialized
INFO - 2023-04-25 14:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:40 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:40 --> Total execution time: 0.0559
ERROR - 2023-04-25 14:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:40 --> Config Class Initialized
INFO - 2023-04-25 14:04:40 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:40 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:40 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:40 --> URI Class Initialized
DEBUG - 2023-04-25 14:04:40 --> No URI present. Default controller set.
INFO - 2023-04-25 14:04:40 --> Router Class Initialized
INFO - 2023-04-25 14:04:40 --> Output Class Initialized
INFO - 2023-04-25 14:04:40 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:40 --> Input Class Initialized
INFO - 2023-04-25 14:04:40 --> Language Class Initialized
INFO - 2023-04-25 14:04:40 --> Loader Class Initialized
INFO - 2023-04-25 14:04:40 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:40 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:40 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:41 --> Parser Class Initialized
INFO - 2023-04-25 14:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:41 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:41 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:41 --> Controller Class Initialized
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 14:04:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:41 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:41 --> Total execution time: 0.0650
ERROR - 2023-04-25 14:04:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:41 --> Config Class Initialized
INFO - 2023-04-25 14:04:41 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:41 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:41 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:41 --> URI Class Initialized
INFO - 2023-04-25 14:04:41 --> Router Class Initialized
INFO - 2023-04-25 14:04:41 --> Output Class Initialized
INFO - 2023-04-25 14:04:41 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:41 --> Input Class Initialized
INFO - 2023-04-25 14:04:41 --> Language Class Initialized
INFO - 2023-04-25 14:04:41 --> Loader Class Initialized
INFO - 2023-04-25 14:04:41 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:41 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:41 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:41 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:41 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:41 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:41 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:41 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:41 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:41 --> Parser Class Initialized
INFO - 2023-04-25 14:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:41 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:41 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:41 --> Controller Class Initialized
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> Model Class Initialized
INFO - 2023-04-25 14:04:41 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:41 --> Total execution time: 0.0166
ERROR - 2023-04-25 14:04:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:42 --> Config Class Initialized
INFO - 2023-04-25 14:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:42 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:42 --> URI Class Initialized
INFO - 2023-04-25 14:04:42 --> Router Class Initialized
INFO - 2023-04-25 14:04:42 --> Output Class Initialized
INFO - 2023-04-25 14:04:42 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:42 --> Input Class Initialized
INFO - 2023-04-25 14:04:42 --> Language Class Initialized
INFO - 2023-04-25 14:04:42 --> Loader Class Initialized
INFO - 2023-04-25 14:04:42 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:42 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:42 --> Parser Class Initialized
INFO - 2023-04-25 14:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:42 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:42 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:42 --> Controller Class Initialized
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 14:04:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:42 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:42 --> Total execution time: 0.0264
ERROR - 2023-04-25 14:04:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 14:04:42 --> Config Class Initialized
INFO - 2023-04-25 14:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 14:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 14:04:42 --> Utf8 Class Initialized
INFO - 2023-04-25 14:04:42 --> URI Class Initialized
INFO - 2023-04-25 14:04:42 --> Router Class Initialized
INFO - 2023-04-25 14:04:42 --> Output Class Initialized
INFO - 2023-04-25 14:04:42 --> Security Class Initialized
DEBUG - 2023-04-25 14:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 14:04:42 --> Input Class Initialized
INFO - 2023-04-25 14:04:42 --> Language Class Initialized
INFO - 2023-04-25 14:04:42 --> Loader Class Initialized
INFO - 2023-04-25 14:04:42 --> Helper loaded: url_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: file_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: html_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: text_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: form_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: lang_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: security_helper
INFO - 2023-04-25 14:04:42 --> Helper loaded: cookie_helper
INFO - 2023-04-25 14:04:42 --> Database Driver Class Initialized
INFO - 2023-04-25 14:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 14:04:42 --> Parser Class Initialized
INFO - 2023-04-25 14:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 14:04:42 --> Pagination Class Initialized
INFO - 2023-04-25 14:04:42 --> Form Validation Class Initialized
INFO - 2023-04-25 14:04:42 --> Controller Class Initialized
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
DEBUG - 2023-04-25 14:04:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 14:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 14:04:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 14:04:42 --> Model Class Initialized
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 14:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 14:04:42 --> Final output sent to browser
DEBUG - 2023-04-25 14:04:42 --> Total execution time: 0.0660
ERROR - 2023-04-25 18:41:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:41:18 --> Config Class Initialized
INFO - 2023-04-25 18:41:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:41:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:41:18 --> Utf8 Class Initialized
INFO - 2023-04-25 18:41:18 --> URI Class Initialized
DEBUG - 2023-04-25 18:41:18 --> No URI present. Default controller set.
INFO - 2023-04-25 18:41:18 --> Router Class Initialized
INFO - 2023-04-25 18:41:18 --> Output Class Initialized
INFO - 2023-04-25 18:41:18 --> Security Class Initialized
DEBUG - 2023-04-25 18:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:41:18 --> Input Class Initialized
INFO - 2023-04-25 18:41:18 --> Language Class Initialized
INFO - 2023-04-25 18:41:18 --> Loader Class Initialized
INFO - 2023-04-25 18:41:18 --> Helper loaded: url_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: file_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: html_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: text_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: form_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: security_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:41:18 --> Database Driver Class Initialized
INFO - 2023-04-25 18:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:41:18 --> Parser Class Initialized
INFO - 2023-04-25 18:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:41:18 --> Pagination Class Initialized
INFO - 2023-04-25 18:41:18 --> Form Validation Class Initialized
INFO - 2023-04-25 18:41:18 --> Controller Class Initialized
INFO - 2023-04-25 18:41:18 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 18:41:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:41:18 --> Config Class Initialized
INFO - 2023-04-25 18:41:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:41:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:41:18 --> Utf8 Class Initialized
INFO - 2023-04-25 18:41:18 --> URI Class Initialized
INFO - 2023-04-25 18:41:18 --> Router Class Initialized
INFO - 2023-04-25 18:41:18 --> Output Class Initialized
INFO - 2023-04-25 18:41:18 --> Security Class Initialized
DEBUG - 2023-04-25 18:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:41:18 --> Input Class Initialized
INFO - 2023-04-25 18:41:18 --> Language Class Initialized
INFO - 2023-04-25 18:41:18 --> Loader Class Initialized
INFO - 2023-04-25 18:41:18 --> Helper loaded: url_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: file_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: html_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: text_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: form_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: security_helper
INFO - 2023-04-25 18:41:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:41:18 --> Database Driver Class Initialized
INFO - 2023-04-25 18:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:41:18 --> Parser Class Initialized
INFO - 2023-04-25 18:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:41:18 --> Pagination Class Initialized
INFO - 2023-04-25 18:41:18 --> Form Validation Class Initialized
INFO - 2023-04-25 18:41:18 --> Controller Class Initialized
INFO - 2023-04-25 18:41:18 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 18:41:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:41:18 --> Model Class Initialized
INFO - 2023-04-25 18:41:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:41:18 --> Final output sent to browser
DEBUG - 2023-04-25 18:41:18 --> Total execution time: 0.0332
ERROR - 2023-04-25 18:41:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:41:39 --> Config Class Initialized
INFO - 2023-04-25 18:41:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:41:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:41:39 --> Utf8 Class Initialized
INFO - 2023-04-25 18:41:39 --> URI Class Initialized
INFO - 2023-04-25 18:41:39 --> Router Class Initialized
INFO - 2023-04-25 18:41:39 --> Output Class Initialized
INFO - 2023-04-25 18:41:39 --> Security Class Initialized
DEBUG - 2023-04-25 18:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:41:39 --> Input Class Initialized
INFO - 2023-04-25 18:41:39 --> Language Class Initialized
INFO - 2023-04-25 18:41:39 --> Loader Class Initialized
INFO - 2023-04-25 18:41:39 --> Helper loaded: url_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: file_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: html_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: text_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: form_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: security_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:41:39 --> Database Driver Class Initialized
INFO - 2023-04-25 18:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:41:39 --> Parser Class Initialized
INFO - 2023-04-25 18:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:41:39 --> Pagination Class Initialized
INFO - 2023-04-25 18:41:39 --> Form Validation Class Initialized
INFO - 2023-04-25 18:41:39 --> Controller Class Initialized
INFO - 2023-04-25 18:41:39 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:39 --> Model Class Initialized
INFO - 2023-04-25 18:41:39 --> Final output sent to browser
DEBUG - 2023-04-25 18:41:39 --> Total execution time: 0.0207
ERROR - 2023-04-25 18:41:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:41:39 --> Config Class Initialized
INFO - 2023-04-25 18:41:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:41:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:41:39 --> Utf8 Class Initialized
INFO - 2023-04-25 18:41:39 --> URI Class Initialized
INFO - 2023-04-25 18:41:39 --> Router Class Initialized
INFO - 2023-04-25 18:41:39 --> Output Class Initialized
INFO - 2023-04-25 18:41:39 --> Security Class Initialized
DEBUG - 2023-04-25 18:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:41:39 --> Input Class Initialized
INFO - 2023-04-25 18:41:39 --> Language Class Initialized
INFO - 2023-04-25 18:41:39 --> Loader Class Initialized
INFO - 2023-04-25 18:41:39 --> Helper loaded: url_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: file_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: html_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: text_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: form_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: security_helper
INFO - 2023-04-25 18:41:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:41:39 --> Database Driver Class Initialized
INFO - 2023-04-25 18:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:41:39 --> Parser Class Initialized
INFO - 2023-04-25 18:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:41:39 --> Pagination Class Initialized
INFO - 2023-04-25 18:41:39 --> Form Validation Class Initialized
INFO - 2023-04-25 18:41:39 --> Controller Class Initialized
INFO - 2023-04-25 18:41:39 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 18:41:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:41:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:41:39 --> Model Class Initialized
INFO - 2023-04-25 18:41:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:41:39 --> Final output sent to browser
DEBUG - 2023-04-25 18:41:39 --> Total execution time: 0.0269
ERROR - 2023-04-25 18:41:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:41:58 --> Config Class Initialized
INFO - 2023-04-25 18:41:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:41:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:41:58 --> Utf8 Class Initialized
INFO - 2023-04-25 18:41:58 --> URI Class Initialized
INFO - 2023-04-25 18:41:58 --> Router Class Initialized
INFO - 2023-04-25 18:41:58 --> Output Class Initialized
INFO - 2023-04-25 18:41:58 --> Security Class Initialized
DEBUG - 2023-04-25 18:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:41:58 --> Input Class Initialized
INFO - 2023-04-25 18:41:58 --> Language Class Initialized
INFO - 2023-04-25 18:41:58 --> Loader Class Initialized
INFO - 2023-04-25 18:41:58 --> Helper loaded: url_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: file_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: html_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: text_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: form_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: security_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:41:58 --> Database Driver Class Initialized
INFO - 2023-04-25 18:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:41:58 --> Parser Class Initialized
INFO - 2023-04-25 18:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:41:58 --> Pagination Class Initialized
INFO - 2023-04-25 18:41:58 --> Form Validation Class Initialized
INFO - 2023-04-25 18:41:58 --> Controller Class Initialized
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
INFO - 2023-04-25 18:41:58 --> Final output sent to browser
DEBUG - 2023-04-25 18:41:58 --> Total execution time: 0.0190
ERROR - 2023-04-25 18:41:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:41:58 --> Config Class Initialized
INFO - 2023-04-25 18:41:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:41:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:41:58 --> Utf8 Class Initialized
INFO - 2023-04-25 18:41:58 --> URI Class Initialized
DEBUG - 2023-04-25 18:41:58 --> No URI present. Default controller set.
INFO - 2023-04-25 18:41:58 --> Router Class Initialized
INFO - 2023-04-25 18:41:58 --> Output Class Initialized
INFO - 2023-04-25 18:41:58 --> Security Class Initialized
DEBUG - 2023-04-25 18:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:41:58 --> Input Class Initialized
INFO - 2023-04-25 18:41:58 --> Language Class Initialized
INFO - 2023-04-25 18:41:58 --> Loader Class Initialized
INFO - 2023-04-25 18:41:58 --> Helper loaded: url_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: file_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: html_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: text_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: form_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: security_helper
INFO - 2023-04-25 18:41:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:41:58 --> Database Driver Class Initialized
INFO - 2023-04-25 18:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:41:58 --> Parser Class Initialized
INFO - 2023-04-25 18:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:41:58 --> Pagination Class Initialized
INFO - 2023-04-25 18:41:58 --> Form Validation Class Initialized
INFO - 2023-04-25 18:41:58 --> Controller Class Initialized
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
DEBUG - 2023-04-25 18:41:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
INFO - 2023-04-25 18:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 18:41:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:41:58 --> Model Class Initialized
INFO - 2023-04-25 18:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:41:58 --> Final output sent to browser
DEBUG - 2023-04-25 18:41:58 --> Total execution time: 0.1634
ERROR - 2023-04-25 18:41:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:41:59 --> Config Class Initialized
INFO - 2023-04-25 18:41:59 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:41:59 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:41:59 --> Utf8 Class Initialized
INFO - 2023-04-25 18:41:59 --> URI Class Initialized
INFO - 2023-04-25 18:41:59 --> Router Class Initialized
INFO - 2023-04-25 18:41:59 --> Output Class Initialized
INFO - 2023-04-25 18:41:59 --> Security Class Initialized
DEBUG - 2023-04-25 18:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:41:59 --> Input Class Initialized
INFO - 2023-04-25 18:41:59 --> Language Class Initialized
INFO - 2023-04-25 18:41:59 --> Loader Class Initialized
INFO - 2023-04-25 18:41:59 --> Helper loaded: url_helper
INFO - 2023-04-25 18:41:59 --> Helper loaded: file_helper
INFO - 2023-04-25 18:41:59 --> Helper loaded: html_helper
INFO - 2023-04-25 18:41:59 --> Helper loaded: text_helper
INFO - 2023-04-25 18:41:59 --> Helper loaded: form_helper
INFO - 2023-04-25 18:41:59 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:41:59 --> Helper loaded: security_helper
INFO - 2023-04-25 18:41:59 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:41:59 --> Database Driver Class Initialized
INFO - 2023-04-25 18:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:41:59 --> Parser Class Initialized
INFO - 2023-04-25 18:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:41:59 --> Pagination Class Initialized
INFO - 2023-04-25 18:41:59 --> Form Validation Class Initialized
INFO - 2023-04-25 18:41:59 --> Controller Class Initialized
DEBUG - 2023-04-25 18:41:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:41:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:41:59 --> Model Class Initialized
INFO - 2023-04-25 18:41:59 --> Final output sent to browser
DEBUG - 2023-04-25 18:41:59 --> Total execution time: 0.0135
ERROR - 2023-04-25 18:42:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:42:39 --> Config Class Initialized
INFO - 2023-04-25 18:42:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:42:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:42:39 --> Utf8 Class Initialized
INFO - 2023-04-25 18:42:39 --> URI Class Initialized
INFO - 2023-04-25 18:42:39 --> Router Class Initialized
INFO - 2023-04-25 18:42:39 --> Output Class Initialized
INFO - 2023-04-25 18:42:39 --> Security Class Initialized
DEBUG - 2023-04-25 18:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:42:39 --> Input Class Initialized
INFO - 2023-04-25 18:42:39 --> Language Class Initialized
INFO - 2023-04-25 18:42:39 --> Loader Class Initialized
INFO - 2023-04-25 18:42:39 --> Helper loaded: url_helper
INFO - 2023-04-25 18:42:39 --> Helper loaded: file_helper
INFO - 2023-04-25 18:42:39 --> Helper loaded: html_helper
INFO - 2023-04-25 18:42:39 --> Helper loaded: text_helper
INFO - 2023-04-25 18:42:39 --> Helper loaded: form_helper
INFO - 2023-04-25 18:42:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:42:39 --> Helper loaded: security_helper
INFO - 2023-04-25 18:42:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:42:39 --> Database Driver Class Initialized
INFO - 2023-04-25 18:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:42:39 --> Parser Class Initialized
INFO - 2023-04-25 18:42:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:42:39 --> Pagination Class Initialized
INFO - 2023-04-25 18:42:39 --> Form Validation Class Initialized
INFO - 2023-04-25 18:42:39 --> Controller Class Initialized
DEBUG - 2023-04-25 18:42:39 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-04-25 18:42:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:42:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:42:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:39 --> Model Class Initialized
INFO - 2023-04-25 18:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:42:40 --> Final output sent to browser
DEBUG - 2023-04-25 18:42:40 --> Total execution time: 0.1930
ERROR - 2023-04-25 18:42:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:42:50 --> Config Class Initialized
INFO - 2023-04-25 18:42:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:42:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:42:50 --> Utf8 Class Initialized
INFO - 2023-04-25 18:42:50 --> URI Class Initialized
INFO - 2023-04-25 18:42:50 --> Router Class Initialized
INFO - 2023-04-25 18:42:50 --> Output Class Initialized
INFO - 2023-04-25 18:42:50 --> Security Class Initialized
DEBUG - 2023-04-25 18:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:42:50 --> Input Class Initialized
INFO - 2023-04-25 18:42:50 --> Language Class Initialized
INFO - 2023-04-25 18:42:50 --> Loader Class Initialized
INFO - 2023-04-25 18:42:50 --> Helper loaded: url_helper
INFO - 2023-04-25 18:42:50 --> Helper loaded: file_helper
INFO - 2023-04-25 18:42:50 --> Helper loaded: html_helper
INFO - 2023-04-25 18:42:50 --> Helper loaded: text_helper
INFO - 2023-04-25 18:42:50 --> Helper loaded: form_helper
INFO - 2023-04-25 18:42:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:42:50 --> Helper loaded: security_helper
INFO - 2023-04-25 18:42:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:42:50 --> Database Driver Class Initialized
INFO - 2023-04-25 18:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:42:50 --> Parser Class Initialized
INFO - 2023-04-25 18:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:42:50 --> Pagination Class Initialized
INFO - 2023-04-25 18:42:50 --> Form Validation Class Initialized
INFO - 2023-04-25 18:42:50 --> Controller Class Initialized
DEBUG - 2023-04-25 18:42:50 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:42:50 --> Model Class Initialized
INFO - 2023-04-25 18:42:50 --> Model Class Initialized
INFO - 2023-04-25 18:42:50 --> Model Class Initialized
INFO - 2023-04-25 18:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-04-25 18:42:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:42:50 --> Model Class Initialized
INFO - 2023-04-25 18:42:50 --> Model Class Initialized
INFO - 2023-04-25 18:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:42:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:42:50 --> Final output sent to browser
DEBUG - 2023-04-25 18:42:50 --> Total execution time: 0.1242
ERROR - 2023-04-25 18:42:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:42:51 --> Config Class Initialized
INFO - 2023-04-25 18:42:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:42:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:42:51 --> Utf8 Class Initialized
INFO - 2023-04-25 18:42:51 --> URI Class Initialized
INFO - 2023-04-25 18:42:51 --> Router Class Initialized
INFO - 2023-04-25 18:42:51 --> Output Class Initialized
INFO - 2023-04-25 18:42:51 --> Security Class Initialized
DEBUG - 2023-04-25 18:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:42:51 --> Input Class Initialized
INFO - 2023-04-25 18:42:51 --> Language Class Initialized
INFO - 2023-04-25 18:42:51 --> Loader Class Initialized
INFO - 2023-04-25 18:42:51 --> Helper loaded: url_helper
INFO - 2023-04-25 18:42:51 --> Helper loaded: file_helper
INFO - 2023-04-25 18:42:51 --> Helper loaded: html_helper
INFO - 2023-04-25 18:42:51 --> Helper loaded: text_helper
INFO - 2023-04-25 18:42:51 --> Helper loaded: form_helper
INFO - 2023-04-25 18:42:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:42:51 --> Helper loaded: security_helper
INFO - 2023-04-25 18:42:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:42:51 --> Database Driver Class Initialized
INFO - 2023-04-25 18:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:42:51 --> Parser Class Initialized
INFO - 2023-04-25 18:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:42:51 --> Pagination Class Initialized
INFO - 2023-04-25 18:42:51 --> Form Validation Class Initialized
INFO - 2023-04-25 18:42:51 --> Controller Class Initialized
DEBUG - 2023-04-25 18:42:51 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:42:51 --> Model Class Initialized
INFO - 2023-04-25 18:42:51 --> Model Class Initialized
INFO - 2023-04-25 18:42:51 --> Final output sent to browser
DEBUG - 2023-04-25 18:42:51 --> Total execution time: 0.0471
ERROR - 2023-04-25 18:43:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:15 --> Config Class Initialized
INFO - 2023-04-25 18:43:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:15 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:15 --> URI Class Initialized
INFO - 2023-04-25 18:43:15 --> Router Class Initialized
INFO - 2023-04-25 18:43:15 --> Output Class Initialized
INFO - 2023-04-25 18:43:15 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:15 --> Input Class Initialized
INFO - 2023-04-25 18:43:15 --> Language Class Initialized
INFO - 2023-04-25 18:43:15 --> Loader Class Initialized
INFO - 2023-04-25 18:43:15 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:15 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:15 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:15 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:15 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:15 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:15 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:15 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:15 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:15 --> Parser Class Initialized
INFO - 2023-04-25 18:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:15 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:15 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:15 --> Controller Class Initialized
INFO - 2023-04-25 18:43:15 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:15 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-04-25 18:43:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:43:15 --> Model Class Initialized
INFO - 2023-04-25 18:43:15 --> Model Class Initialized
INFO - 2023-04-25 18:43:15 --> Model Class Initialized
INFO - 2023-04-25 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:43:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:43:15 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:15 --> Total execution time: 0.1348
ERROR - 2023-04-25 18:43:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:20 --> Config Class Initialized
INFO - 2023-04-25 18:43:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:20 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:20 --> URI Class Initialized
INFO - 2023-04-25 18:43:20 --> Router Class Initialized
INFO - 2023-04-25 18:43:20 --> Output Class Initialized
INFO - 2023-04-25 18:43:20 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:20 --> Input Class Initialized
INFO - 2023-04-25 18:43:20 --> Language Class Initialized
INFO - 2023-04-25 18:43:20 --> Loader Class Initialized
INFO - 2023-04-25 18:43:20 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:20 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:20 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:20 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:20 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:20 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:20 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:20 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:20 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:20 --> Parser Class Initialized
INFO - 2023-04-25 18:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:20 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:20 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:20 --> Controller Class Initialized
INFO - 2023-04-25 18:43:20 --> Model Class Initialized
ERROR - 2023-04-25 18:43:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cstockrequest.php 204
INFO - 2023-04-25 18:43:20 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:20 --> Total execution time: 0.0142
ERROR - 2023-04-25 18:43:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:24 --> Config Class Initialized
INFO - 2023-04-25 18:43:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:24 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:24 --> URI Class Initialized
INFO - 2023-04-25 18:43:24 --> Router Class Initialized
INFO - 2023-04-25 18:43:24 --> Output Class Initialized
INFO - 2023-04-25 18:43:24 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:24 --> Input Class Initialized
INFO - 2023-04-25 18:43:24 --> Language Class Initialized
INFO - 2023-04-25 18:43:24 --> Loader Class Initialized
INFO - 2023-04-25 18:43:24 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:24 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:24 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:24 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:24 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:24 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:24 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:24 --> Parser Class Initialized
INFO - 2023-04-25 18:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:24 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:24 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:24 --> Controller Class Initialized
INFO - 2023-04-25 18:43:24 --> Model Class Initialized
INFO - 2023-04-25 18:43:24 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:24 --> Total execution time: 0.0161
ERROR - 2023-04-25 18:43:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:29 --> Config Class Initialized
INFO - 2023-04-25 18:43:29 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:29 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:29 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:29 --> URI Class Initialized
INFO - 2023-04-25 18:43:29 --> Router Class Initialized
INFO - 2023-04-25 18:43:29 --> Output Class Initialized
INFO - 2023-04-25 18:43:29 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:29 --> Input Class Initialized
INFO - 2023-04-25 18:43:29 --> Language Class Initialized
INFO - 2023-04-25 18:43:29 --> Loader Class Initialized
INFO - 2023-04-25 18:43:29 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:29 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:29 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:29 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:29 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:29 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:29 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:29 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:30 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:30 --> Parser Class Initialized
INFO - 2023-04-25 18:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:30 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:30 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:30 --> Controller Class Initialized
INFO - 2023-04-25 18:43:30 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:30 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:30 --> Model Class Initialized
INFO - 2023-04-25 18:43:30 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:30 --> Total execution time: 0.0198
ERROR - 2023-04-25 18:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:30 --> Config Class Initialized
INFO - 2023-04-25 18:43:30 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:30 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:30 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:30 --> URI Class Initialized
INFO - 2023-04-25 18:43:30 --> Router Class Initialized
INFO - 2023-04-25 18:43:30 --> Output Class Initialized
INFO - 2023-04-25 18:43:30 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:30 --> Input Class Initialized
INFO - 2023-04-25 18:43:30 --> Language Class Initialized
INFO - 2023-04-25 18:43:30 --> Loader Class Initialized
INFO - 2023-04-25 18:43:30 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:30 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:30 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:30 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:30 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:30 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:30 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:30 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:30 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:30 --> Parser Class Initialized
INFO - 2023-04-25 18:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:30 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:30 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:30 --> Controller Class Initialized
INFO - 2023-04-25 18:43:30 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:30 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:30 --> Model Class Initialized
INFO - 2023-04-25 18:43:30 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:30 --> Total execution time: 0.0179
ERROR - 2023-04-25 18:43:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:32 --> Config Class Initialized
INFO - 2023-04-25 18:43:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:32 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:32 --> URI Class Initialized
INFO - 2023-04-25 18:43:32 --> Router Class Initialized
INFO - 2023-04-25 18:43:32 --> Output Class Initialized
INFO - 2023-04-25 18:43:32 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:32 --> Input Class Initialized
INFO - 2023-04-25 18:43:32 --> Language Class Initialized
INFO - 2023-04-25 18:43:32 --> Loader Class Initialized
INFO - 2023-04-25 18:43:32 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:32 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:32 --> Parser Class Initialized
INFO - 2023-04-25 18:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:32 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:32 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:32 --> Controller Class Initialized
INFO - 2023-04-25 18:43:32 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:32 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:32 --> Model Class Initialized
INFO - 2023-04-25 18:43:32 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:32 --> Total execution time: 0.0172
ERROR - 2023-04-25 18:43:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:32 --> Config Class Initialized
INFO - 2023-04-25 18:43:32 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:32 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:32 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:32 --> URI Class Initialized
INFO - 2023-04-25 18:43:32 --> Router Class Initialized
INFO - 2023-04-25 18:43:32 --> Output Class Initialized
INFO - 2023-04-25 18:43:32 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:32 --> Input Class Initialized
INFO - 2023-04-25 18:43:32 --> Language Class Initialized
INFO - 2023-04-25 18:43:32 --> Loader Class Initialized
INFO - 2023-04-25 18:43:32 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:32 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:32 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:32 --> Parser Class Initialized
INFO - 2023-04-25 18:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:32 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:32 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:32 --> Controller Class Initialized
INFO - 2023-04-25 18:43:32 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:32 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:32 --> Model Class Initialized
INFO - 2023-04-25 18:43:32 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:32 --> Total execution time: 0.0175
ERROR - 2023-04-25 18:43:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:33 --> Config Class Initialized
INFO - 2023-04-25 18:43:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:33 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:33 --> URI Class Initialized
INFO - 2023-04-25 18:43:33 --> Router Class Initialized
INFO - 2023-04-25 18:43:33 --> Output Class Initialized
INFO - 2023-04-25 18:43:33 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:33 --> Input Class Initialized
INFO - 2023-04-25 18:43:33 --> Language Class Initialized
INFO - 2023-04-25 18:43:33 --> Loader Class Initialized
INFO - 2023-04-25 18:43:33 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:33 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:33 --> Parser Class Initialized
INFO - 2023-04-25 18:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:33 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:33 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:33 --> Controller Class Initialized
INFO - 2023-04-25 18:43:33 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:33 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:33 --> Model Class Initialized
INFO - 2023-04-25 18:43:33 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:33 --> Total execution time: 0.0177
ERROR - 2023-04-25 18:43:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:33 --> Config Class Initialized
INFO - 2023-04-25 18:43:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:33 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:33 --> URI Class Initialized
INFO - 2023-04-25 18:43:33 --> Router Class Initialized
INFO - 2023-04-25 18:43:33 --> Output Class Initialized
INFO - 2023-04-25 18:43:33 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:33 --> Input Class Initialized
INFO - 2023-04-25 18:43:33 --> Language Class Initialized
INFO - 2023-04-25 18:43:33 --> Loader Class Initialized
INFO - 2023-04-25 18:43:33 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:33 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:33 --> Parser Class Initialized
INFO - 2023-04-25 18:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:33 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:33 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:33 --> Controller Class Initialized
INFO - 2023-04-25 18:43:33 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:33 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:33 --> Model Class Initialized
INFO - 2023-04-25 18:43:33 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:33 --> Total execution time: 0.0206
ERROR - 2023-04-25 18:43:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:35 --> Config Class Initialized
INFO - 2023-04-25 18:43:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:35 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:35 --> URI Class Initialized
INFO - 2023-04-25 18:43:35 --> Router Class Initialized
INFO - 2023-04-25 18:43:35 --> Output Class Initialized
INFO - 2023-04-25 18:43:35 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:35 --> Input Class Initialized
INFO - 2023-04-25 18:43:35 --> Language Class Initialized
INFO - 2023-04-25 18:43:35 --> Loader Class Initialized
INFO - 2023-04-25 18:43:35 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:35 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:35 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:35 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:35 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:35 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:35 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:35 --> Parser Class Initialized
INFO - 2023-04-25 18:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:35 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:35 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:35 --> Controller Class Initialized
INFO - 2023-04-25 18:43:35 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:35 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:35 --> Model Class Initialized
INFO - 2023-04-25 18:43:35 --> Model Class Initialized
INFO - 2023-04-25 18:43:35 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:35 --> Total execution time: 0.0202
ERROR - 2023-04-25 18:43:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:37 --> Config Class Initialized
INFO - 2023-04-25 18:43:37 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:37 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:37 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:37 --> URI Class Initialized
INFO - 2023-04-25 18:43:37 --> Router Class Initialized
INFO - 2023-04-25 18:43:37 --> Output Class Initialized
INFO - 2023-04-25 18:43:37 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:37 --> Input Class Initialized
INFO - 2023-04-25 18:43:37 --> Language Class Initialized
INFO - 2023-04-25 18:43:37 --> Loader Class Initialized
INFO - 2023-04-25 18:43:37 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:37 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:37 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:37 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:37 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:37 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:37 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:37 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:37 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:37 --> Parser Class Initialized
INFO - 2023-04-25 18:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:37 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:37 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:37 --> Controller Class Initialized
INFO - 2023-04-25 18:43:37 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:37 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:37 --> Model Class Initialized
INFO - 2023-04-25 18:43:37 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:37 --> Total execution time: 0.0179
ERROR - 2023-04-25 18:43:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:54 --> Config Class Initialized
INFO - 2023-04-25 18:43:54 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:54 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:54 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:54 --> URI Class Initialized
INFO - 2023-04-25 18:43:54 --> Router Class Initialized
INFO - 2023-04-25 18:43:54 --> Output Class Initialized
INFO - 2023-04-25 18:43:54 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:54 --> Input Class Initialized
INFO - 2023-04-25 18:43:54 --> Language Class Initialized
INFO - 2023-04-25 18:43:54 --> Loader Class Initialized
INFO - 2023-04-25 18:43:54 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:54 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:54 --> Parser Class Initialized
INFO - 2023-04-25 18:43:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:54 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:54 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:54 --> Controller Class Initialized
INFO - 2023-04-25 18:43:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:54 --> Model Class Initialized
INFO - 2023-04-25 18:43:54 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:54 --> Total execution time: 0.0208
ERROR - 2023-04-25 18:43:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:54 --> Config Class Initialized
INFO - 2023-04-25 18:43:54 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:54 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:54 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:54 --> URI Class Initialized
INFO - 2023-04-25 18:43:54 --> Router Class Initialized
INFO - 2023-04-25 18:43:54 --> Output Class Initialized
INFO - 2023-04-25 18:43:54 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:54 --> Input Class Initialized
INFO - 2023-04-25 18:43:54 --> Language Class Initialized
INFO - 2023-04-25 18:43:54 --> Loader Class Initialized
INFO - 2023-04-25 18:43:54 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:54 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:54 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:54 --> Parser Class Initialized
INFO - 2023-04-25 18:43:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:54 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:54 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:54 --> Controller Class Initialized
INFO - 2023-04-25 18:43:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:54 --> Model Class Initialized
INFO - 2023-04-25 18:43:54 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:54 --> Total execution time: 0.0171
ERROR - 2023-04-25 18:43:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:55 --> Config Class Initialized
INFO - 2023-04-25 18:43:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:55 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:55 --> URI Class Initialized
INFO - 2023-04-25 18:43:55 --> Router Class Initialized
INFO - 2023-04-25 18:43:55 --> Output Class Initialized
INFO - 2023-04-25 18:43:55 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:55 --> Input Class Initialized
INFO - 2023-04-25 18:43:55 --> Language Class Initialized
INFO - 2023-04-25 18:43:55 --> Loader Class Initialized
INFO - 2023-04-25 18:43:55 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:55 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:55 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:55 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:55 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:55 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:55 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:55 --> Parser Class Initialized
INFO - 2023-04-25 18:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:55 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:55 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:55 --> Controller Class Initialized
INFO - 2023-04-25 18:43:55 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:55 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:55 --> Model Class Initialized
INFO - 2023-04-25 18:43:55 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:55 --> Total execution time: 0.0175
ERROR - 2023-04-25 18:43:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:57 --> Config Class Initialized
INFO - 2023-04-25 18:43:57 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:57 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:57 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:57 --> URI Class Initialized
INFO - 2023-04-25 18:43:57 --> Router Class Initialized
INFO - 2023-04-25 18:43:57 --> Output Class Initialized
INFO - 2023-04-25 18:43:57 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:57 --> Input Class Initialized
INFO - 2023-04-25 18:43:57 --> Language Class Initialized
INFO - 2023-04-25 18:43:57 --> Loader Class Initialized
INFO - 2023-04-25 18:43:57 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:57 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:57 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:57 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:57 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:57 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:57 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:57 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:57 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:57 --> Parser Class Initialized
INFO - 2023-04-25 18:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:57 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:57 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:57 --> Controller Class Initialized
INFO - 2023-04-25 18:43:57 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:57 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:57 --> Model Class Initialized
INFO - 2023-04-25 18:43:57 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:57 --> Total execution time: 0.0173
ERROR - 2023-04-25 18:43:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:43:59 --> Config Class Initialized
INFO - 2023-04-25 18:43:59 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:43:59 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:43:59 --> Utf8 Class Initialized
INFO - 2023-04-25 18:43:59 --> URI Class Initialized
INFO - 2023-04-25 18:43:59 --> Router Class Initialized
INFO - 2023-04-25 18:43:59 --> Output Class Initialized
INFO - 2023-04-25 18:43:59 --> Security Class Initialized
DEBUG - 2023-04-25 18:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:43:59 --> Input Class Initialized
INFO - 2023-04-25 18:43:59 --> Language Class Initialized
INFO - 2023-04-25 18:43:59 --> Loader Class Initialized
INFO - 2023-04-25 18:43:59 --> Helper loaded: url_helper
INFO - 2023-04-25 18:43:59 --> Helper loaded: file_helper
INFO - 2023-04-25 18:43:59 --> Helper loaded: html_helper
INFO - 2023-04-25 18:43:59 --> Helper loaded: text_helper
INFO - 2023-04-25 18:43:59 --> Helper loaded: form_helper
INFO - 2023-04-25 18:43:59 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:43:59 --> Helper loaded: security_helper
INFO - 2023-04-25 18:43:59 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:43:59 --> Database Driver Class Initialized
INFO - 2023-04-25 18:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:43:59 --> Parser Class Initialized
INFO - 2023-04-25 18:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:43:59 --> Pagination Class Initialized
INFO - 2023-04-25 18:43:59 --> Form Validation Class Initialized
INFO - 2023-04-25 18:43:59 --> Controller Class Initialized
INFO - 2023-04-25 18:43:59 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:59 --> Model Class Initialized
DEBUG - 2023-04-25 18:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:43:59 --> Model Class Initialized
INFO - 2023-04-25 18:43:59 --> Model Class Initialized
INFO - 2023-04-25 18:43:59 --> Final output sent to browser
DEBUG - 2023-04-25 18:43:59 --> Total execution time: 0.0227
ERROR - 2023-04-25 18:44:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:44:02 --> Config Class Initialized
INFO - 2023-04-25 18:44:02 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:44:02 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:44:02 --> Utf8 Class Initialized
INFO - 2023-04-25 18:44:02 --> URI Class Initialized
INFO - 2023-04-25 18:44:02 --> Router Class Initialized
INFO - 2023-04-25 18:44:02 --> Output Class Initialized
INFO - 2023-04-25 18:44:02 --> Security Class Initialized
DEBUG - 2023-04-25 18:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:44:02 --> Input Class Initialized
INFO - 2023-04-25 18:44:02 --> Language Class Initialized
INFO - 2023-04-25 18:44:02 --> Loader Class Initialized
INFO - 2023-04-25 18:44:02 --> Helper loaded: url_helper
INFO - 2023-04-25 18:44:02 --> Helper loaded: file_helper
INFO - 2023-04-25 18:44:02 --> Helper loaded: html_helper
INFO - 2023-04-25 18:44:02 --> Helper loaded: text_helper
INFO - 2023-04-25 18:44:02 --> Helper loaded: form_helper
INFO - 2023-04-25 18:44:02 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:44:02 --> Helper loaded: security_helper
INFO - 2023-04-25 18:44:02 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:44:02 --> Database Driver Class Initialized
INFO - 2023-04-25 18:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:44:02 --> Parser Class Initialized
INFO - 2023-04-25 18:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:44:02 --> Pagination Class Initialized
INFO - 2023-04-25 18:44:02 --> Form Validation Class Initialized
INFO - 2023-04-25 18:44:02 --> Controller Class Initialized
INFO - 2023-04-25 18:44:02 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:02 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:02 --> Model Class Initialized
INFO - 2023-04-25 18:44:02 --> Final output sent to browser
DEBUG - 2023-04-25 18:44:02 --> Total execution time: 0.0184
ERROR - 2023-04-25 18:44:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:44:11 --> Config Class Initialized
INFO - 2023-04-25 18:44:11 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:44:11 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:44:11 --> Utf8 Class Initialized
INFO - 2023-04-25 18:44:11 --> URI Class Initialized
INFO - 2023-04-25 18:44:11 --> Router Class Initialized
INFO - 2023-04-25 18:44:11 --> Output Class Initialized
INFO - 2023-04-25 18:44:11 --> Security Class Initialized
DEBUG - 2023-04-25 18:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:44:11 --> Input Class Initialized
INFO - 2023-04-25 18:44:11 --> Language Class Initialized
INFO - 2023-04-25 18:44:11 --> Loader Class Initialized
INFO - 2023-04-25 18:44:11 --> Helper loaded: url_helper
INFO - 2023-04-25 18:44:11 --> Helper loaded: file_helper
INFO - 2023-04-25 18:44:11 --> Helper loaded: html_helper
INFO - 2023-04-25 18:44:11 --> Helper loaded: text_helper
INFO - 2023-04-25 18:44:11 --> Helper loaded: form_helper
INFO - 2023-04-25 18:44:11 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:44:11 --> Helper loaded: security_helper
INFO - 2023-04-25 18:44:11 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:44:11 --> Database Driver Class Initialized
INFO - 2023-04-25 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:44:11 --> Parser Class Initialized
INFO - 2023-04-25 18:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:44:11 --> Pagination Class Initialized
INFO - 2023-04-25 18:44:11 --> Form Validation Class Initialized
INFO - 2023-04-25 18:44:11 --> Controller Class Initialized
INFO - 2023-04-25 18:44:11 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:11 --> Model Class Initialized
INFO - 2023-04-25 18:44:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-04-25 18:44:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:44:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:44:11 --> Model Class Initialized
INFO - 2023-04-25 18:44:11 --> Model Class Initialized
INFO - 2023-04-25 18:44:11 --> Model Class Initialized
INFO - 2023-04-25 18:44:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:44:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:44:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:44:11 --> Final output sent to browser
DEBUG - 2023-04-25 18:44:11 --> Total execution time: 0.1338
ERROR - 2023-04-25 18:44:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:44:12 --> Config Class Initialized
INFO - 2023-04-25 18:44:12 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:44:12 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:44:12 --> Utf8 Class Initialized
INFO - 2023-04-25 18:44:12 --> URI Class Initialized
INFO - 2023-04-25 18:44:12 --> Router Class Initialized
INFO - 2023-04-25 18:44:12 --> Output Class Initialized
INFO - 2023-04-25 18:44:12 --> Security Class Initialized
DEBUG - 2023-04-25 18:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:44:12 --> Input Class Initialized
INFO - 2023-04-25 18:44:12 --> Language Class Initialized
INFO - 2023-04-25 18:44:12 --> Loader Class Initialized
INFO - 2023-04-25 18:44:12 --> Helper loaded: url_helper
INFO - 2023-04-25 18:44:12 --> Helper loaded: file_helper
INFO - 2023-04-25 18:44:12 --> Helper loaded: html_helper
INFO - 2023-04-25 18:44:12 --> Helper loaded: text_helper
INFO - 2023-04-25 18:44:12 --> Helper loaded: form_helper
INFO - 2023-04-25 18:44:12 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:44:12 --> Helper loaded: security_helper
INFO - 2023-04-25 18:44:12 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:44:12 --> Database Driver Class Initialized
INFO - 2023-04-25 18:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:44:12 --> Parser Class Initialized
INFO - 2023-04-25 18:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:44:12 --> Pagination Class Initialized
INFO - 2023-04-25 18:44:12 --> Form Validation Class Initialized
INFO - 2023-04-25 18:44:12 --> Controller Class Initialized
INFO - 2023-04-25 18:44:12 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:12 --> Model Class Initialized
INFO - 2023-04-25 18:44:12 --> Final output sent to browser
DEBUG - 2023-04-25 18:44:12 --> Total execution time: 0.0208
ERROR - 2023-04-25 18:44:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:44:17 --> Config Class Initialized
INFO - 2023-04-25 18:44:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:44:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:44:17 --> Utf8 Class Initialized
INFO - 2023-04-25 18:44:17 --> URI Class Initialized
INFO - 2023-04-25 18:44:17 --> Router Class Initialized
INFO - 2023-04-25 18:44:17 --> Output Class Initialized
INFO - 2023-04-25 18:44:17 --> Security Class Initialized
DEBUG - 2023-04-25 18:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:44:17 --> Input Class Initialized
INFO - 2023-04-25 18:44:17 --> Language Class Initialized
INFO - 2023-04-25 18:44:17 --> Loader Class Initialized
INFO - 2023-04-25 18:44:17 --> Helper loaded: url_helper
INFO - 2023-04-25 18:44:17 --> Helper loaded: file_helper
INFO - 2023-04-25 18:44:17 --> Helper loaded: html_helper
INFO - 2023-04-25 18:44:17 --> Helper loaded: text_helper
INFO - 2023-04-25 18:44:17 --> Helper loaded: form_helper
INFO - 2023-04-25 18:44:17 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:44:17 --> Helper loaded: security_helper
INFO - 2023-04-25 18:44:17 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:44:17 --> Database Driver Class Initialized
INFO - 2023-04-25 18:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:44:17 --> Parser Class Initialized
INFO - 2023-04-25 18:44:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:44:17 --> Pagination Class Initialized
INFO - 2023-04-25 18:44:17 --> Form Validation Class Initialized
INFO - 2023-04-25 18:44:17 --> Controller Class Initialized
INFO - 2023-04-25 18:44:17 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:17 --> Model Class Initialized
INFO - 2023-04-25 18:44:17 --> Final output sent to browser
DEBUG - 2023-04-25 18:44:17 --> Total execution time: 0.0205
ERROR - 2023-04-25 18:44:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:44:36 --> Config Class Initialized
INFO - 2023-04-25 18:44:36 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:44:36 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:44:36 --> Utf8 Class Initialized
INFO - 2023-04-25 18:44:36 --> URI Class Initialized
DEBUG - 2023-04-25 18:44:36 --> No URI present. Default controller set.
INFO - 2023-04-25 18:44:36 --> Router Class Initialized
INFO - 2023-04-25 18:44:36 --> Output Class Initialized
INFO - 2023-04-25 18:44:36 --> Security Class Initialized
DEBUG - 2023-04-25 18:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:44:36 --> Input Class Initialized
INFO - 2023-04-25 18:44:36 --> Language Class Initialized
INFO - 2023-04-25 18:44:36 --> Loader Class Initialized
INFO - 2023-04-25 18:44:36 --> Helper loaded: url_helper
INFO - 2023-04-25 18:44:36 --> Helper loaded: file_helper
INFO - 2023-04-25 18:44:36 --> Helper loaded: html_helper
INFO - 2023-04-25 18:44:36 --> Helper loaded: text_helper
INFO - 2023-04-25 18:44:36 --> Helper loaded: form_helper
INFO - 2023-04-25 18:44:36 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:44:36 --> Helper loaded: security_helper
INFO - 2023-04-25 18:44:36 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:44:36 --> Database Driver Class Initialized
INFO - 2023-04-25 18:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:44:36 --> Parser Class Initialized
INFO - 2023-04-25 18:44:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:44:36 --> Pagination Class Initialized
INFO - 2023-04-25 18:44:36 --> Form Validation Class Initialized
INFO - 2023-04-25 18:44:36 --> Controller Class Initialized
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:44:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
INFO - 2023-04-25 18:44:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 18:44:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:44:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:44:36 --> Model Class Initialized
INFO - 2023-04-25 18:44:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:44:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:44:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:44:36 --> Final output sent to browser
DEBUG - 2023-04-25 18:44:36 --> Total execution time: 0.1546
ERROR - 2023-04-25 18:44:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:44:50 --> Config Class Initialized
INFO - 2023-04-25 18:44:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:44:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:44:50 --> Utf8 Class Initialized
INFO - 2023-04-25 18:44:50 --> URI Class Initialized
INFO - 2023-04-25 18:44:50 --> Router Class Initialized
INFO - 2023-04-25 18:44:50 --> Output Class Initialized
INFO - 2023-04-25 18:44:50 --> Security Class Initialized
DEBUG - 2023-04-25 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:44:50 --> Input Class Initialized
INFO - 2023-04-25 18:44:50 --> Language Class Initialized
INFO - 2023-04-25 18:44:50 --> Loader Class Initialized
INFO - 2023-04-25 18:44:50 --> Helper loaded: url_helper
INFO - 2023-04-25 18:44:50 --> Helper loaded: file_helper
INFO - 2023-04-25 18:44:50 --> Helper loaded: html_helper
INFO - 2023-04-25 18:44:50 --> Helper loaded: text_helper
INFO - 2023-04-25 18:44:50 --> Helper loaded: form_helper
INFO - 2023-04-25 18:44:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:44:50 --> Helper loaded: security_helper
INFO - 2023-04-25 18:44:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:44:50 --> Database Driver Class Initialized
INFO - 2023-04-25 18:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:44:50 --> Parser Class Initialized
INFO - 2023-04-25 18:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:44:50 --> Pagination Class Initialized
INFO - 2023-04-25 18:44:50 --> Form Validation Class Initialized
INFO - 2023-04-25 18:44:50 --> Controller Class Initialized
INFO - 2023-04-25 18:44:50 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:50 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:50 --> Model Class Initialized
INFO - 2023-04-25 18:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 18:44:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:44:50 --> Model Class Initialized
INFO - 2023-04-25 18:44:50 --> Model Class Initialized
INFO - 2023-04-25 18:44:50 --> Model Class Initialized
INFO - 2023-04-25 18:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:44:50 --> Final output sent to browser
DEBUG - 2023-04-25 18:44:50 --> Total execution time: 0.1347
ERROR - 2023-04-25 18:44:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:44:51 --> Config Class Initialized
INFO - 2023-04-25 18:44:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:44:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:44:51 --> Utf8 Class Initialized
INFO - 2023-04-25 18:44:51 --> URI Class Initialized
INFO - 2023-04-25 18:44:51 --> Router Class Initialized
INFO - 2023-04-25 18:44:51 --> Output Class Initialized
INFO - 2023-04-25 18:44:51 --> Security Class Initialized
DEBUG - 2023-04-25 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:44:51 --> Input Class Initialized
INFO - 2023-04-25 18:44:51 --> Language Class Initialized
INFO - 2023-04-25 18:44:51 --> Loader Class Initialized
INFO - 2023-04-25 18:44:51 --> Helper loaded: url_helper
INFO - 2023-04-25 18:44:51 --> Helper loaded: file_helper
INFO - 2023-04-25 18:44:51 --> Helper loaded: html_helper
INFO - 2023-04-25 18:44:51 --> Helper loaded: text_helper
INFO - 2023-04-25 18:44:51 --> Helper loaded: form_helper
INFO - 2023-04-25 18:44:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:44:51 --> Helper loaded: security_helper
INFO - 2023-04-25 18:44:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:44:51 --> Database Driver Class Initialized
INFO - 2023-04-25 18:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:44:51 --> Parser Class Initialized
INFO - 2023-04-25 18:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:44:51 --> Pagination Class Initialized
INFO - 2023-04-25 18:44:51 --> Form Validation Class Initialized
INFO - 2023-04-25 18:44:51 --> Controller Class Initialized
INFO - 2023-04-25 18:44:51 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:51 --> Model Class Initialized
DEBUG - 2023-04-25 18:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:44:51 --> Model Class Initialized
INFO - 2023-04-25 18:44:51 --> Final output sent to browser
DEBUG - 2023-04-25 18:44:51 --> Total execution time: 0.0502
ERROR - 2023-04-25 18:45:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:45:00 --> Config Class Initialized
INFO - 2023-04-25 18:45:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:45:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:45:00 --> Utf8 Class Initialized
INFO - 2023-04-25 18:45:00 --> URI Class Initialized
INFO - 2023-04-25 18:45:00 --> Router Class Initialized
INFO - 2023-04-25 18:45:00 --> Output Class Initialized
INFO - 2023-04-25 18:45:00 --> Security Class Initialized
DEBUG - 2023-04-25 18:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:45:00 --> Input Class Initialized
INFO - 2023-04-25 18:45:00 --> Language Class Initialized
INFO - 2023-04-25 18:45:00 --> Loader Class Initialized
INFO - 2023-04-25 18:45:00 --> Helper loaded: url_helper
INFO - 2023-04-25 18:45:00 --> Helper loaded: file_helper
INFO - 2023-04-25 18:45:00 --> Helper loaded: html_helper
INFO - 2023-04-25 18:45:00 --> Helper loaded: text_helper
INFO - 2023-04-25 18:45:00 --> Helper loaded: form_helper
INFO - 2023-04-25 18:45:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:45:00 --> Helper loaded: security_helper
INFO - 2023-04-25 18:45:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:45:00 --> Database Driver Class Initialized
INFO - 2023-04-25 18:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:45:00 --> Parser Class Initialized
INFO - 2023-04-25 18:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:45:00 --> Pagination Class Initialized
INFO - 2023-04-25 18:45:00 --> Form Validation Class Initialized
INFO - 2023-04-25 18:45:00 --> Controller Class Initialized
INFO - 2023-04-25 18:45:00 --> Model Class Initialized
DEBUG - 2023-04-25 18:45:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:45:00 --> Model Class Initialized
INFO - 2023-04-25 18:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-25 18:45:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:45:00 --> Model Class Initialized
INFO - 2023-04-25 18:45:00 --> Model Class Initialized
INFO - 2023-04-25 18:45:00 --> Model Class Initialized
INFO - 2023-04-25 18:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:45:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:45:00 --> Final output sent to browser
DEBUG - 2023-04-25 18:45:00 --> Total execution time: 0.1379
ERROR - 2023-04-25 18:45:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:45:01 --> Config Class Initialized
INFO - 2023-04-25 18:45:01 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:45:01 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:45:01 --> Utf8 Class Initialized
INFO - 2023-04-25 18:45:01 --> URI Class Initialized
INFO - 2023-04-25 18:45:01 --> Router Class Initialized
INFO - 2023-04-25 18:45:01 --> Output Class Initialized
INFO - 2023-04-25 18:45:01 --> Security Class Initialized
DEBUG - 2023-04-25 18:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:45:01 --> Input Class Initialized
INFO - 2023-04-25 18:45:01 --> Language Class Initialized
INFO - 2023-04-25 18:45:01 --> Loader Class Initialized
INFO - 2023-04-25 18:45:01 --> Helper loaded: url_helper
INFO - 2023-04-25 18:45:01 --> Helper loaded: file_helper
INFO - 2023-04-25 18:45:01 --> Helper loaded: html_helper
INFO - 2023-04-25 18:45:01 --> Helper loaded: text_helper
INFO - 2023-04-25 18:45:01 --> Helper loaded: form_helper
INFO - 2023-04-25 18:45:01 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:45:01 --> Helper loaded: security_helper
INFO - 2023-04-25 18:45:01 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:45:01 --> Database Driver Class Initialized
INFO - 2023-04-25 18:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:45:01 --> Parser Class Initialized
INFO - 2023-04-25 18:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:45:01 --> Pagination Class Initialized
INFO - 2023-04-25 18:45:01 --> Form Validation Class Initialized
INFO - 2023-04-25 18:45:01 --> Controller Class Initialized
INFO - 2023-04-25 18:45:01 --> Model Class Initialized
DEBUG - 2023-04-25 18:45:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:45:01 --> Model Class Initialized
INFO - 2023-04-25 18:45:01 --> Final output sent to browser
DEBUG - 2023-04-25 18:45:01 --> Total execution time: 0.0285
ERROR - 2023-04-25 18:45:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:45:04 --> Config Class Initialized
INFO - 2023-04-25 18:45:04 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:45:04 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:45:04 --> Utf8 Class Initialized
INFO - 2023-04-25 18:45:04 --> URI Class Initialized
INFO - 2023-04-25 18:45:04 --> Router Class Initialized
INFO - 2023-04-25 18:45:04 --> Output Class Initialized
INFO - 2023-04-25 18:45:04 --> Security Class Initialized
DEBUG - 2023-04-25 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:45:04 --> Input Class Initialized
INFO - 2023-04-25 18:45:04 --> Language Class Initialized
INFO - 2023-04-25 18:45:04 --> Loader Class Initialized
INFO - 2023-04-25 18:45:04 --> Helper loaded: url_helper
INFO - 2023-04-25 18:45:04 --> Helper loaded: file_helper
INFO - 2023-04-25 18:45:04 --> Helper loaded: html_helper
INFO - 2023-04-25 18:45:04 --> Helper loaded: text_helper
INFO - 2023-04-25 18:45:04 --> Helper loaded: form_helper
INFO - 2023-04-25 18:45:04 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:45:04 --> Helper loaded: security_helper
INFO - 2023-04-25 18:45:04 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:45:04 --> Database Driver Class Initialized
INFO - 2023-04-25 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:45:04 --> Parser Class Initialized
INFO - 2023-04-25 18:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:45:04 --> Pagination Class Initialized
INFO - 2023-04-25 18:45:04 --> Form Validation Class Initialized
INFO - 2023-04-25 18:45:04 --> Controller Class Initialized
INFO - 2023-04-25 18:45:04 --> Model Class Initialized
DEBUG - 2023-04-25 18:45:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:45:04 --> Model Class Initialized
DEBUG - 2023-04-25 18:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-04-25 18:45:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:45:04 --> Model Class Initialized
INFO - 2023-04-25 18:45:04 --> Model Class Initialized
INFO - 2023-04-25 18:45:04 --> Model Class Initialized
INFO - 2023-04-25 18:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:45:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:45:04 --> Final output sent to browser
DEBUG - 2023-04-25 18:45:04 --> Total execution time: 0.1193
ERROR - 2023-04-25 18:52:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:52:36 --> Config Class Initialized
INFO - 2023-04-25 18:52:36 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:52:36 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:52:36 --> Utf8 Class Initialized
INFO - 2023-04-25 18:52:36 --> URI Class Initialized
INFO - 2023-04-25 18:52:36 --> Router Class Initialized
INFO - 2023-04-25 18:52:36 --> Output Class Initialized
INFO - 2023-04-25 18:52:36 --> Security Class Initialized
DEBUG - 2023-04-25 18:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:52:36 --> Input Class Initialized
INFO - 2023-04-25 18:52:36 --> Language Class Initialized
INFO - 2023-04-25 18:52:36 --> Loader Class Initialized
INFO - 2023-04-25 18:52:36 --> Helper loaded: url_helper
INFO - 2023-04-25 18:52:36 --> Helper loaded: file_helper
INFO - 2023-04-25 18:52:36 --> Helper loaded: html_helper
INFO - 2023-04-25 18:52:36 --> Helper loaded: text_helper
INFO - 2023-04-25 18:52:36 --> Helper loaded: form_helper
INFO - 2023-04-25 18:52:36 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:52:36 --> Helper loaded: security_helper
INFO - 2023-04-25 18:52:36 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:52:36 --> Database Driver Class Initialized
INFO - 2023-04-25 18:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:52:36 --> Parser Class Initialized
INFO - 2023-04-25 18:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:52:36 --> Pagination Class Initialized
INFO - 2023-04-25 18:52:36 --> Form Validation Class Initialized
INFO - 2023-04-25 18:52:36 --> Controller Class Initialized
INFO - 2023-04-25 18:52:36 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:36 --> Model Class Initialized
INFO - 2023-04-25 18:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-25 18:52:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:52:36 --> Model Class Initialized
INFO - 2023-04-25 18:52:36 --> Model Class Initialized
INFO - 2023-04-25 18:52:36 --> Model Class Initialized
INFO - 2023-04-25 18:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:52:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:52:36 --> Final output sent to browser
DEBUG - 2023-04-25 18:52:36 --> Total execution time: 0.1290
ERROR - 2023-04-25 18:52:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:52:37 --> Config Class Initialized
INFO - 2023-04-25 18:52:37 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:52:37 --> Utf8 Class Initialized
INFO - 2023-04-25 18:52:37 --> URI Class Initialized
INFO - 2023-04-25 18:52:37 --> Router Class Initialized
INFO - 2023-04-25 18:52:37 --> Output Class Initialized
INFO - 2023-04-25 18:52:37 --> Security Class Initialized
DEBUG - 2023-04-25 18:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:52:37 --> Input Class Initialized
INFO - 2023-04-25 18:52:37 --> Language Class Initialized
INFO - 2023-04-25 18:52:37 --> Loader Class Initialized
INFO - 2023-04-25 18:52:37 --> Helper loaded: url_helper
INFO - 2023-04-25 18:52:37 --> Helper loaded: file_helper
INFO - 2023-04-25 18:52:37 --> Helper loaded: html_helper
INFO - 2023-04-25 18:52:37 --> Helper loaded: text_helper
INFO - 2023-04-25 18:52:37 --> Helper loaded: form_helper
INFO - 2023-04-25 18:52:37 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:52:37 --> Helper loaded: security_helper
INFO - 2023-04-25 18:52:37 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:52:37 --> Database Driver Class Initialized
INFO - 2023-04-25 18:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:52:37 --> Parser Class Initialized
INFO - 2023-04-25 18:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:52:37 --> Pagination Class Initialized
INFO - 2023-04-25 18:52:37 --> Form Validation Class Initialized
INFO - 2023-04-25 18:52:37 --> Controller Class Initialized
INFO - 2023-04-25 18:52:37 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:37 --> Model Class Initialized
INFO - 2023-04-25 18:52:37 --> Final output sent to browser
DEBUG - 2023-04-25 18:52:37 --> Total execution time: 0.0327
ERROR - 2023-04-25 18:52:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:52:44 --> Config Class Initialized
INFO - 2023-04-25 18:52:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:52:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:52:44 --> Utf8 Class Initialized
INFO - 2023-04-25 18:52:44 --> URI Class Initialized
INFO - 2023-04-25 18:52:44 --> Router Class Initialized
INFO - 2023-04-25 18:52:44 --> Output Class Initialized
INFO - 2023-04-25 18:52:44 --> Security Class Initialized
DEBUG - 2023-04-25 18:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:52:44 --> Input Class Initialized
INFO - 2023-04-25 18:52:44 --> Language Class Initialized
INFO - 2023-04-25 18:52:44 --> Loader Class Initialized
INFO - 2023-04-25 18:52:44 --> Helper loaded: url_helper
INFO - 2023-04-25 18:52:44 --> Helper loaded: file_helper
INFO - 2023-04-25 18:52:44 --> Helper loaded: html_helper
INFO - 2023-04-25 18:52:44 --> Helper loaded: text_helper
INFO - 2023-04-25 18:52:44 --> Helper loaded: form_helper
INFO - 2023-04-25 18:52:44 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:52:44 --> Helper loaded: security_helper
INFO - 2023-04-25 18:52:44 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:52:44 --> Database Driver Class Initialized
INFO - 2023-04-25 18:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:52:44 --> Parser Class Initialized
INFO - 2023-04-25 18:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:52:44 --> Pagination Class Initialized
INFO - 2023-04-25 18:52:44 --> Form Validation Class Initialized
INFO - 2023-04-25 18:52:44 --> Controller Class Initialized
INFO - 2023-04-25 18:52:44 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:44 --> Model Class Initialized
ERROR - 2023-04-25 18:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:52:45 --> Config Class Initialized
INFO - 2023-04-25 18:52:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:52:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:52:45 --> Utf8 Class Initialized
INFO - 2023-04-25 18:52:45 --> URI Class Initialized
INFO - 2023-04-25 18:52:45 --> Router Class Initialized
INFO - 2023-04-25 18:52:45 --> Output Class Initialized
INFO - 2023-04-25 18:52:45 --> Security Class Initialized
DEBUG - 2023-04-25 18:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:52:45 --> Input Class Initialized
INFO - 2023-04-25 18:52:45 --> Language Class Initialized
INFO - 2023-04-25 18:52:45 --> Loader Class Initialized
INFO - 2023-04-25 18:52:45 --> Helper loaded: url_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: file_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: html_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: text_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: form_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: security_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:52:45 --> Database Driver Class Initialized
INFO - 2023-04-25 18:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:52:45 --> Parser Class Initialized
INFO - 2023-04-25 18:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:52:45 --> Pagination Class Initialized
INFO - 2023-04-25 18:52:45 --> Form Validation Class Initialized
INFO - 2023-04-25 18:52:45 --> Controller Class Initialized
INFO - 2023-04-25 18:52:45 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:45 --> Model Class Initialized
INFO - 2023-04-25 18:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-04-25 18:52:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:52:45 --> Model Class Initialized
INFO - 2023-04-25 18:52:45 --> Model Class Initialized
INFO - 2023-04-25 18:52:45 --> Model Class Initialized
INFO - 2023-04-25 18:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:52:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:52:45 --> Final output sent to browser
DEBUG - 2023-04-25 18:52:45 --> Total execution time: 0.1277
ERROR - 2023-04-25 18:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:52:45 --> Config Class Initialized
INFO - 2023-04-25 18:52:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:52:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:52:45 --> Utf8 Class Initialized
INFO - 2023-04-25 18:52:45 --> URI Class Initialized
INFO - 2023-04-25 18:52:45 --> Router Class Initialized
INFO - 2023-04-25 18:52:45 --> Output Class Initialized
INFO - 2023-04-25 18:52:45 --> Security Class Initialized
DEBUG - 2023-04-25 18:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:52:45 --> Input Class Initialized
INFO - 2023-04-25 18:52:45 --> Language Class Initialized
INFO - 2023-04-25 18:52:45 --> Loader Class Initialized
INFO - 2023-04-25 18:52:45 --> Helper loaded: url_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: file_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: html_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: text_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: form_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: security_helper
INFO - 2023-04-25 18:52:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:52:45 --> Database Driver Class Initialized
INFO - 2023-04-25 18:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:52:45 --> Parser Class Initialized
INFO - 2023-04-25 18:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:52:45 --> Pagination Class Initialized
INFO - 2023-04-25 18:52:45 --> Form Validation Class Initialized
INFO - 2023-04-25 18:52:45 --> Controller Class Initialized
INFO - 2023-04-25 18:52:45 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:45 --> Model Class Initialized
INFO - 2023-04-25 18:52:45 --> Final output sent to browser
DEBUG - 2023-04-25 18:52:45 --> Total execution time: 0.0278
ERROR - 2023-04-25 18:52:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:52:55 --> Config Class Initialized
INFO - 2023-04-25 18:52:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:52:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:52:55 --> Utf8 Class Initialized
INFO - 2023-04-25 18:52:55 --> URI Class Initialized
INFO - 2023-04-25 18:52:55 --> Router Class Initialized
INFO - 2023-04-25 18:52:55 --> Output Class Initialized
INFO - 2023-04-25 18:52:55 --> Security Class Initialized
DEBUG - 2023-04-25 18:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:52:55 --> Input Class Initialized
INFO - 2023-04-25 18:52:55 --> Language Class Initialized
INFO - 2023-04-25 18:52:55 --> Loader Class Initialized
INFO - 2023-04-25 18:52:55 --> Helper loaded: url_helper
INFO - 2023-04-25 18:52:55 --> Helper loaded: file_helper
INFO - 2023-04-25 18:52:55 --> Helper loaded: html_helper
INFO - 2023-04-25 18:52:55 --> Helper loaded: text_helper
INFO - 2023-04-25 18:52:55 --> Helper loaded: form_helper
INFO - 2023-04-25 18:52:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:52:55 --> Helper loaded: security_helper
INFO - 2023-04-25 18:52:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:52:55 --> Database Driver Class Initialized
INFO - 2023-04-25 18:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:52:55 --> Parser Class Initialized
INFO - 2023-04-25 18:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:52:55 --> Pagination Class Initialized
INFO - 2023-04-25 18:52:55 --> Form Validation Class Initialized
INFO - 2023-04-25 18:52:55 --> Controller Class Initialized
DEBUG - 2023-04-25 18:52:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:55 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:55 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:55 --> Model Class Initialized
INFO - 2023-04-25 18:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-04-25 18:52:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:52:55 --> Model Class Initialized
INFO - 2023-04-25 18:52:55 --> Model Class Initialized
INFO - 2023-04-25 18:52:55 --> Model Class Initialized
INFO - 2023-04-25 18:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:52:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:52:55 --> Final output sent to browser
DEBUG - 2023-04-25 18:52:55 --> Total execution time: 0.1405
ERROR - 2023-04-25 18:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:52:56 --> Config Class Initialized
INFO - 2023-04-25 18:52:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:52:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:52:56 --> Utf8 Class Initialized
INFO - 2023-04-25 18:52:56 --> URI Class Initialized
INFO - 2023-04-25 18:52:56 --> Router Class Initialized
INFO - 2023-04-25 18:52:56 --> Output Class Initialized
INFO - 2023-04-25 18:52:56 --> Security Class Initialized
DEBUG - 2023-04-25 18:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:52:56 --> Input Class Initialized
INFO - 2023-04-25 18:52:56 --> Language Class Initialized
INFO - 2023-04-25 18:52:56 --> Loader Class Initialized
INFO - 2023-04-25 18:52:56 --> Helper loaded: url_helper
INFO - 2023-04-25 18:52:56 --> Helper loaded: file_helper
INFO - 2023-04-25 18:52:56 --> Helper loaded: html_helper
INFO - 2023-04-25 18:52:56 --> Helper loaded: text_helper
INFO - 2023-04-25 18:52:56 --> Helper loaded: form_helper
INFO - 2023-04-25 18:52:56 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:52:56 --> Helper loaded: security_helper
INFO - 2023-04-25 18:52:56 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:52:56 --> Database Driver Class Initialized
INFO - 2023-04-25 18:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:52:56 --> Parser Class Initialized
INFO - 2023-04-25 18:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:52:56 --> Pagination Class Initialized
INFO - 2023-04-25 18:52:56 --> Form Validation Class Initialized
INFO - 2023-04-25 18:52:56 --> Controller Class Initialized
DEBUG - 2023-04-25 18:52:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:56 --> Model Class Initialized
DEBUG - 2023-04-25 18:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:52:56 --> Model Class Initialized
INFO - 2023-04-25 18:52:56 --> Final output sent to browser
DEBUG - 2023-04-25 18:52:56 --> Total execution time: 0.0292
ERROR - 2023-04-25 18:53:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:53:03 --> Config Class Initialized
INFO - 2023-04-25 18:53:03 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:53:03 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:53:03 --> Utf8 Class Initialized
INFO - 2023-04-25 18:53:03 --> URI Class Initialized
INFO - 2023-04-25 18:53:03 --> Router Class Initialized
INFO - 2023-04-25 18:53:03 --> Output Class Initialized
INFO - 2023-04-25 18:53:03 --> Security Class Initialized
DEBUG - 2023-04-25 18:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:53:03 --> Input Class Initialized
INFO - 2023-04-25 18:53:03 --> Language Class Initialized
INFO - 2023-04-25 18:53:03 --> Loader Class Initialized
INFO - 2023-04-25 18:53:03 --> Helper loaded: url_helper
INFO - 2023-04-25 18:53:03 --> Helper loaded: file_helper
INFO - 2023-04-25 18:53:03 --> Helper loaded: html_helper
INFO - 2023-04-25 18:53:03 --> Helper loaded: text_helper
INFO - 2023-04-25 18:53:03 --> Helper loaded: form_helper
INFO - 2023-04-25 18:53:03 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:53:03 --> Helper loaded: security_helper
INFO - 2023-04-25 18:53:03 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:53:03 --> Database Driver Class Initialized
INFO - 2023-04-25 18:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:53:03 --> Parser Class Initialized
INFO - 2023-04-25 18:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:53:03 --> Pagination Class Initialized
INFO - 2023-04-25 18:53:03 --> Form Validation Class Initialized
INFO - 2023-04-25 18:53:03 --> Controller Class Initialized
DEBUG - 2023-04-25 18:53:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:53:03 --> Model Class Initialized
DEBUG - 2023-04-25 18:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:53:03 --> Model Class Initialized
INFO - 2023-04-25 18:53:03 --> Final output sent to browser
DEBUG - 2023-04-25 18:53:03 --> Total execution time: 0.0763
ERROR - 2023-04-25 18:53:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:53:16 --> Config Class Initialized
INFO - 2023-04-25 18:53:16 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:53:16 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:53:16 --> Utf8 Class Initialized
INFO - 2023-04-25 18:53:16 --> URI Class Initialized
INFO - 2023-04-25 18:53:16 --> Router Class Initialized
INFO - 2023-04-25 18:53:16 --> Output Class Initialized
INFO - 2023-04-25 18:53:16 --> Security Class Initialized
DEBUG - 2023-04-25 18:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:53:16 --> Input Class Initialized
INFO - 2023-04-25 18:53:16 --> Language Class Initialized
INFO - 2023-04-25 18:53:16 --> Loader Class Initialized
INFO - 2023-04-25 18:53:16 --> Helper loaded: url_helper
INFO - 2023-04-25 18:53:16 --> Helper loaded: file_helper
INFO - 2023-04-25 18:53:16 --> Helper loaded: html_helper
INFO - 2023-04-25 18:53:16 --> Helper loaded: text_helper
INFO - 2023-04-25 18:53:16 --> Helper loaded: form_helper
INFO - 2023-04-25 18:53:16 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:53:16 --> Helper loaded: security_helper
INFO - 2023-04-25 18:53:16 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:53:16 --> Database Driver Class Initialized
INFO - 2023-04-25 18:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:53:16 --> Parser Class Initialized
INFO - 2023-04-25 18:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:53:16 --> Pagination Class Initialized
INFO - 2023-04-25 18:53:16 --> Form Validation Class Initialized
INFO - 2023-04-25 18:53:16 --> Controller Class Initialized
DEBUG - 2023-04-25 18:53:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:53:16 --> Model Class Initialized
DEBUG - 2023-04-25 18:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:53:16 --> Model Class Initialized
INFO - 2023-04-25 18:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-04-25 18:53:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:53:16 --> Model Class Initialized
INFO - 2023-04-25 18:53:16 --> Model Class Initialized
INFO - 2023-04-25 18:53:16 --> Model Class Initialized
INFO - 2023-04-25 18:53:16 --> Model Class Initialized
INFO - 2023-04-25 18:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:53:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:53:16 --> Final output sent to browser
DEBUG - 2023-04-25 18:53:16 --> Total execution time: 0.1292
ERROR - 2023-04-25 18:54:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:00 --> Config Class Initialized
INFO - 2023-04-25 18:54:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:00 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:00 --> URI Class Initialized
DEBUG - 2023-04-25 18:54:00 --> No URI present. Default controller set.
INFO - 2023-04-25 18:54:00 --> Router Class Initialized
INFO - 2023-04-25 18:54:00 --> Output Class Initialized
INFO - 2023-04-25 18:54:00 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:00 --> Input Class Initialized
INFO - 2023-04-25 18:54:00 --> Language Class Initialized
INFO - 2023-04-25 18:54:00 --> Loader Class Initialized
INFO - 2023-04-25 18:54:00 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:00 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:00 --> Parser Class Initialized
INFO - 2023-04-25 18:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:00 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:00 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:00 --> Controller Class Initialized
INFO - 2023-04-25 18:54:00 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-04-25 18:54:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:00 --> Config Class Initialized
INFO - 2023-04-25 18:54:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:00 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:00 --> URI Class Initialized
INFO - 2023-04-25 18:54:00 --> Router Class Initialized
INFO - 2023-04-25 18:54:00 --> Output Class Initialized
INFO - 2023-04-25 18:54:00 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:00 --> Input Class Initialized
INFO - 2023-04-25 18:54:00 --> Language Class Initialized
INFO - 2023-04-25 18:54:00 --> Loader Class Initialized
INFO - 2023-04-25 18:54:00 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:00 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:00 --> Parser Class Initialized
INFO - 2023-04-25 18:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:00 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:00 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:00 --> Controller Class Initialized
INFO - 2023-04-25 18:54:00 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-04-25 18:54:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:54:00 --> Model Class Initialized
INFO - 2023-04-25 18:54:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:54:00 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:00 --> Total execution time: 0.0301
ERROR - 2023-04-25 18:54:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:18 --> Config Class Initialized
INFO - 2023-04-25 18:54:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:18 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:18 --> URI Class Initialized
INFO - 2023-04-25 18:54:18 --> Router Class Initialized
INFO - 2023-04-25 18:54:18 --> Output Class Initialized
INFO - 2023-04-25 18:54:18 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:18 --> Input Class Initialized
INFO - 2023-04-25 18:54:18 --> Language Class Initialized
INFO - 2023-04-25 18:54:18 --> Loader Class Initialized
INFO - 2023-04-25 18:54:18 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:18 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:18 --> Parser Class Initialized
INFO - 2023-04-25 18:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:18 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:18 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:18 --> Controller Class Initialized
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
INFO - 2023-04-25 18:54:18 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:18 --> Total execution time: 0.0181
ERROR - 2023-04-25 18:54:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:18 --> Config Class Initialized
INFO - 2023-04-25 18:54:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:18 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:18 --> URI Class Initialized
DEBUG - 2023-04-25 18:54:18 --> No URI present. Default controller set.
INFO - 2023-04-25 18:54:18 --> Router Class Initialized
INFO - 2023-04-25 18:54:18 --> Output Class Initialized
INFO - 2023-04-25 18:54:18 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:18 --> Input Class Initialized
INFO - 2023-04-25 18:54:18 --> Language Class Initialized
INFO - 2023-04-25 18:54:18 --> Loader Class Initialized
INFO - 2023-04-25 18:54:18 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:18 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:18 --> Parser Class Initialized
INFO - 2023-04-25 18:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:18 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:18 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:18 --> Controller Class Initialized
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
INFO - 2023-04-25 18:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 18:54:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:54:18 --> Model Class Initialized
INFO - 2023-04-25 18:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:54:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:54:18 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:18 --> Total execution time: 0.0584
ERROR - 2023-04-25 18:54:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:27 --> Config Class Initialized
INFO - 2023-04-25 18:54:27 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:27 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:27 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:27 --> URI Class Initialized
INFO - 2023-04-25 18:54:27 --> Router Class Initialized
INFO - 2023-04-25 18:54:27 --> Output Class Initialized
INFO - 2023-04-25 18:54:27 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:27 --> Input Class Initialized
INFO - 2023-04-25 18:54:27 --> Language Class Initialized
INFO - 2023-04-25 18:54:27 --> Loader Class Initialized
INFO - 2023-04-25 18:54:27 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:27 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:27 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:27 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:27 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:27 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:27 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:27 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:27 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:27 --> Parser Class Initialized
INFO - 2023-04-25 18:54:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:27 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:27 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:27 --> Controller Class Initialized
INFO - 2023-04-25 18:54:27 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:27 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-04-25 18:54:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:54:27 --> Model Class Initialized
INFO - 2023-04-25 18:54:27 --> Model Class Initialized
INFO - 2023-04-25 18:54:27 --> Model Class Initialized
INFO - 2023-04-25 18:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:54:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:54:27 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:27 --> Total execution time: 0.0563
ERROR - 2023-04-25 18:54:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:48 --> Config Class Initialized
INFO - 2023-04-25 18:54:48 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:48 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:48 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:48 --> URI Class Initialized
INFO - 2023-04-25 18:54:48 --> Router Class Initialized
INFO - 2023-04-25 18:54:48 --> Output Class Initialized
INFO - 2023-04-25 18:54:48 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:48 --> Input Class Initialized
INFO - 2023-04-25 18:54:48 --> Language Class Initialized
INFO - 2023-04-25 18:54:48 --> Loader Class Initialized
INFO - 2023-04-25 18:54:48 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:48 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:48 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:48 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:48 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:48 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:48 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:48 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:48 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:48 --> Parser Class Initialized
INFO - 2023-04-25 18:54:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:48 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:48 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:48 --> Controller Class Initialized
INFO - 2023-04-25 18:54:48 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:48 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:48 --> Model Class Initialized
INFO - 2023-04-25 18:54:48 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:48 --> Total execution time: 0.0211
ERROR - 2023-04-25 18:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:49 --> Config Class Initialized
INFO - 2023-04-25 18:54:49 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:49 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:49 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:49 --> URI Class Initialized
INFO - 2023-04-25 18:54:49 --> Router Class Initialized
INFO - 2023-04-25 18:54:49 --> Output Class Initialized
INFO - 2023-04-25 18:54:49 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:49 --> Input Class Initialized
INFO - 2023-04-25 18:54:49 --> Language Class Initialized
INFO - 2023-04-25 18:54:49 --> Loader Class Initialized
INFO - 2023-04-25 18:54:49 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:49 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:49 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:49 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:49 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:49 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:49 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:49 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:49 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:49 --> Parser Class Initialized
INFO - 2023-04-25 18:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:49 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:49 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:49 --> Controller Class Initialized
INFO - 2023-04-25 18:54:49 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:49 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:49 --> Model Class Initialized
INFO - 2023-04-25 18:54:49 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:49 --> Total execution time: 0.0177
ERROR - 2023-04-25 18:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:50 --> Config Class Initialized
INFO - 2023-04-25 18:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:50 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:50 --> URI Class Initialized
INFO - 2023-04-25 18:54:50 --> Router Class Initialized
INFO - 2023-04-25 18:54:50 --> Output Class Initialized
INFO - 2023-04-25 18:54:50 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:50 --> Input Class Initialized
INFO - 2023-04-25 18:54:50 --> Language Class Initialized
INFO - 2023-04-25 18:54:50 --> Loader Class Initialized
INFO - 2023-04-25 18:54:50 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:50 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:50 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:50 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:50 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:50 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:50 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:50 --> Parser Class Initialized
INFO - 2023-04-25 18:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:50 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:50 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:50 --> Controller Class Initialized
INFO - 2023-04-25 18:54:50 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:50 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:50 --> Model Class Initialized
INFO - 2023-04-25 18:54:50 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:50 --> Total execution time: 0.0180
ERROR - 2023-04-25 18:54:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:54:51 --> Config Class Initialized
INFO - 2023-04-25 18:54:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:54:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:54:51 --> Utf8 Class Initialized
INFO - 2023-04-25 18:54:51 --> URI Class Initialized
INFO - 2023-04-25 18:54:51 --> Router Class Initialized
INFO - 2023-04-25 18:54:51 --> Output Class Initialized
INFO - 2023-04-25 18:54:51 --> Security Class Initialized
DEBUG - 2023-04-25 18:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:54:51 --> Input Class Initialized
INFO - 2023-04-25 18:54:51 --> Language Class Initialized
INFO - 2023-04-25 18:54:51 --> Loader Class Initialized
INFO - 2023-04-25 18:54:51 --> Helper loaded: url_helper
INFO - 2023-04-25 18:54:51 --> Helper loaded: file_helper
INFO - 2023-04-25 18:54:51 --> Helper loaded: html_helper
INFO - 2023-04-25 18:54:51 --> Helper loaded: text_helper
INFO - 2023-04-25 18:54:51 --> Helper loaded: form_helper
INFO - 2023-04-25 18:54:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:54:51 --> Helper loaded: security_helper
INFO - 2023-04-25 18:54:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:54:51 --> Database Driver Class Initialized
INFO - 2023-04-25 18:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:54:51 --> Parser Class Initialized
INFO - 2023-04-25 18:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:54:51 --> Pagination Class Initialized
INFO - 2023-04-25 18:54:51 --> Form Validation Class Initialized
INFO - 2023-04-25 18:54:51 --> Controller Class Initialized
INFO - 2023-04-25 18:54:51 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:51 --> Model Class Initialized
DEBUG - 2023-04-25 18:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:54:51 --> Model Class Initialized
INFO - 2023-04-25 18:54:51 --> Final output sent to browser
DEBUG - 2023-04-25 18:54:51 --> Total execution time: 0.0175
ERROR - 2023-04-25 18:55:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:04 --> Config Class Initialized
INFO - 2023-04-25 18:55:04 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:04 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:04 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:04 --> URI Class Initialized
INFO - 2023-04-25 18:55:04 --> Router Class Initialized
INFO - 2023-04-25 18:55:04 --> Output Class Initialized
INFO - 2023-04-25 18:55:04 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:04 --> Input Class Initialized
INFO - 2023-04-25 18:55:04 --> Language Class Initialized
INFO - 2023-04-25 18:55:04 --> Loader Class Initialized
INFO - 2023-04-25 18:55:04 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:04 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:04 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:04 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:04 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:04 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:04 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:04 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:04 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:04 --> Parser Class Initialized
INFO - 2023-04-25 18:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:04 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:04 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:04 --> Controller Class Initialized
INFO - 2023-04-25 18:55:04 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:04 --> Model Class Initialized
INFO - 2023-04-25 18:55:04 --> Model Class Initialized
INFO - 2023-04-25 18:55:04 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:04 --> Total execution time: 0.0196
ERROR - 2023-04-25 18:55:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:12 --> Config Class Initialized
INFO - 2023-04-25 18:55:12 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:12 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:12 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:12 --> URI Class Initialized
INFO - 2023-04-25 18:55:12 --> Router Class Initialized
INFO - 2023-04-25 18:55:12 --> Output Class Initialized
INFO - 2023-04-25 18:55:12 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:12 --> Input Class Initialized
INFO - 2023-04-25 18:55:12 --> Language Class Initialized
INFO - 2023-04-25 18:55:12 --> Loader Class Initialized
INFO - 2023-04-25 18:55:12 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:12 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:12 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:12 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:12 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:12 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:12 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:12 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:12 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:12 --> Parser Class Initialized
INFO - 2023-04-25 18:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:12 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:12 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:12 --> Controller Class Initialized
INFO - 2023-04-25 18:55:12 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:12 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:12 --> Model Class Initialized
INFO - 2023-04-25 18:55:12 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:12 --> Total execution time: 0.0185
ERROR - 2023-04-25 18:55:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:13 --> Config Class Initialized
INFO - 2023-04-25 18:55:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:13 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:13 --> URI Class Initialized
INFO - 2023-04-25 18:55:13 --> Router Class Initialized
INFO - 2023-04-25 18:55:13 --> Output Class Initialized
INFO - 2023-04-25 18:55:13 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:13 --> Input Class Initialized
INFO - 2023-04-25 18:55:13 --> Language Class Initialized
INFO - 2023-04-25 18:55:13 --> Loader Class Initialized
INFO - 2023-04-25 18:55:13 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:13 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:13 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:13 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:13 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:13 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:13 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:13 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:13 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:13 --> Parser Class Initialized
INFO - 2023-04-25 18:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:13 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:13 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:13 --> Controller Class Initialized
INFO - 2023-04-25 18:55:13 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:13 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:13 --> Model Class Initialized
INFO - 2023-04-25 18:55:13 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:13 --> Total execution time: 0.0211
ERROR - 2023-04-25 18:55:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:14 --> Config Class Initialized
INFO - 2023-04-25 18:55:14 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:14 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:14 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:14 --> URI Class Initialized
INFO - 2023-04-25 18:55:14 --> Router Class Initialized
INFO - 2023-04-25 18:55:14 --> Output Class Initialized
INFO - 2023-04-25 18:55:14 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:14 --> Input Class Initialized
INFO - 2023-04-25 18:55:14 --> Language Class Initialized
INFO - 2023-04-25 18:55:14 --> Loader Class Initialized
INFO - 2023-04-25 18:55:14 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:14 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:14 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:14 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:14 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:14 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:14 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:14 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:14 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:14 --> Parser Class Initialized
INFO - 2023-04-25 18:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:14 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:14 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:14 --> Controller Class Initialized
INFO - 2023-04-25 18:55:14 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:14 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:14 --> Model Class Initialized
INFO - 2023-04-25 18:55:14 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:14 --> Total execution time: 0.0186
ERROR - 2023-04-25 18:55:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:18 --> Config Class Initialized
INFO - 2023-04-25 18:55:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:18 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:18 --> URI Class Initialized
INFO - 2023-04-25 18:55:18 --> Router Class Initialized
INFO - 2023-04-25 18:55:18 --> Output Class Initialized
INFO - 2023-04-25 18:55:18 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:18 --> Input Class Initialized
INFO - 2023-04-25 18:55:18 --> Language Class Initialized
INFO - 2023-04-25 18:55:18 --> Loader Class Initialized
INFO - 2023-04-25 18:55:18 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:18 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:18 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:18 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:18 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:18 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:18 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:18 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:18 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:18 --> Parser Class Initialized
INFO - 2023-04-25 18:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:18 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:18 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:18 --> Controller Class Initialized
INFO - 2023-04-25 18:55:18 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:18 --> Model Class Initialized
INFO - 2023-04-25 18:55:18 --> Model Class Initialized
INFO - 2023-04-25 18:55:18 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:18 --> Total execution time: 0.0166
ERROR - 2023-04-25 18:55:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:28 --> Config Class Initialized
INFO - 2023-04-25 18:55:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:28 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:28 --> URI Class Initialized
INFO - 2023-04-25 18:55:28 --> Router Class Initialized
INFO - 2023-04-25 18:55:28 --> Output Class Initialized
INFO - 2023-04-25 18:55:28 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:28 --> Input Class Initialized
INFO - 2023-04-25 18:55:28 --> Language Class Initialized
INFO - 2023-04-25 18:55:28 --> Loader Class Initialized
INFO - 2023-04-25 18:55:28 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:28 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:28 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:28 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:28 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:28 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:28 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:28 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:28 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:28 --> Parser Class Initialized
INFO - 2023-04-25 18:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:28 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:28 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:28 --> Controller Class Initialized
INFO - 2023-04-25 18:55:28 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:28 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:28 --> Model Class Initialized
INFO - 2023-04-25 18:55:28 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:28 --> Total execution time: 0.0176
ERROR - 2023-04-25 18:55:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:29 --> Config Class Initialized
INFO - 2023-04-25 18:55:29 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:29 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:29 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:29 --> URI Class Initialized
INFO - 2023-04-25 18:55:29 --> Router Class Initialized
INFO - 2023-04-25 18:55:29 --> Output Class Initialized
INFO - 2023-04-25 18:55:29 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:29 --> Input Class Initialized
INFO - 2023-04-25 18:55:29 --> Language Class Initialized
INFO - 2023-04-25 18:55:29 --> Loader Class Initialized
INFO - 2023-04-25 18:55:29 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:29 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:29 --> Parser Class Initialized
INFO - 2023-04-25 18:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:29 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:29 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:29 --> Controller Class Initialized
INFO - 2023-04-25 18:55:29 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:29 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:29 --> Model Class Initialized
INFO - 2023-04-25 18:55:29 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:29 --> Total execution time: 0.0166
ERROR - 2023-04-25 18:55:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:29 --> Config Class Initialized
INFO - 2023-04-25 18:55:29 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:29 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:29 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:29 --> URI Class Initialized
INFO - 2023-04-25 18:55:29 --> Router Class Initialized
INFO - 2023-04-25 18:55:29 --> Output Class Initialized
INFO - 2023-04-25 18:55:29 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:29 --> Input Class Initialized
INFO - 2023-04-25 18:55:29 --> Language Class Initialized
INFO - 2023-04-25 18:55:29 --> Loader Class Initialized
INFO - 2023-04-25 18:55:29 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:29 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:29 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:29 --> Parser Class Initialized
INFO - 2023-04-25 18:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:29 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:29 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:29 --> Controller Class Initialized
INFO - 2023-04-25 18:55:29 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:29 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:29 --> Model Class Initialized
INFO - 2023-04-25 18:55:29 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:29 --> Total execution time: 0.0176
ERROR - 2023-04-25 18:55:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:31 --> Config Class Initialized
INFO - 2023-04-25 18:55:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:31 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:31 --> URI Class Initialized
INFO - 2023-04-25 18:55:31 --> Router Class Initialized
INFO - 2023-04-25 18:55:31 --> Output Class Initialized
INFO - 2023-04-25 18:55:31 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:31 --> Input Class Initialized
INFO - 2023-04-25 18:55:31 --> Language Class Initialized
INFO - 2023-04-25 18:55:31 --> Loader Class Initialized
INFO - 2023-04-25 18:55:31 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:31 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:31 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:31 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:31 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:31 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:31 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:31 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:31 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:31 --> Parser Class Initialized
INFO - 2023-04-25 18:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:31 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:31 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:31 --> Controller Class Initialized
INFO - 2023-04-25 18:55:31 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:31 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:31 --> Model Class Initialized
INFO - 2023-04-25 18:55:31 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:31 --> Total execution time: 0.0182
ERROR - 2023-04-25 18:55:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:33 --> Config Class Initialized
INFO - 2023-04-25 18:55:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:33 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:33 --> URI Class Initialized
INFO - 2023-04-25 18:55:33 --> Router Class Initialized
INFO - 2023-04-25 18:55:33 --> Output Class Initialized
INFO - 2023-04-25 18:55:33 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:33 --> Input Class Initialized
INFO - 2023-04-25 18:55:33 --> Language Class Initialized
INFO - 2023-04-25 18:55:33 --> Loader Class Initialized
INFO - 2023-04-25 18:55:33 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:33 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:33 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:33 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:33 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:33 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:33 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:33 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:33 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:33 --> Parser Class Initialized
INFO - 2023-04-25 18:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:33 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:33 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:33 --> Controller Class Initialized
INFO - 2023-04-25 18:55:33 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:33 --> Model Class Initialized
INFO - 2023-04-25 18:55:33 --> Model Class Initialized
INFO - 2023-04-25 18:55:33 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:33 --> Total execution time: 0.0174
ERROR - 2023-04-25 18:55:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:40 --> Config Class Initialized
INFO - 2023-04-25 18:55:40 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:40 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:40 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:40 --> URI Class Initialized
INFO - 2023-04-25 18:55:40 --> Router Class Initialized
INFO - 2023-04-25 18:55:40 --> Output Class Initialized
INFO - 2023-04-25 18:55:40 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:40 --> Input Class Initialized
INFO - 2023-04-25 18:55:40 --> Language Class Initialized
INFO - 2023-04-25 18:55:40 --> Loader Class Initialized
INFO - 2023-04-25 18:55:40 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:40 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:40 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:40 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:40 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:40 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:40 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:40 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:40 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:40 --> Parser Class Initialized
INFO - 2023-04-25 18:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:40 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:40 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:40 --> Controller Class Initialized
INFO - 2023-04-25 18:55:40 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:40 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:40 --> Model Class Initialized
INFO - 2023-04-25 18:55:40 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:40 --> Total execution time: 0.0174
ERROR - 2023-04-25 18:55:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:41 --> Config Class Initialized
INFO - 2023-04-25 18:55:41 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:41 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:41 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:41 --> URI Class Initialized
INFO - 2023-04-25 18:55:41 --> Router Class Initialized
INFO - 2023-04-25 18:55:41 --> Output Class Initialized
INFO - 2023-04-25 18:55:41 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:41 --> Input Class Initialized
INFO - 2023-04-25 18:55:41 --> Language Class Initialized
INFO - 2023-04-25 18:55:41 --> Loader Class Initialized
INFO - 2023-04-25 18:55:41 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:41 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:41 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:41 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:41 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:41 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:41 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:41 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:41 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:41 --> Parser Class Initialized
INFO - 2023-04-25 18:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:41 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:41 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:41 --> Controller Class Initialized
INFO - 2023-04-25 18:55:41 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:41 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:41 --> Model Class Initialized
INFO - 2023-04-25 18:55:41 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:41 --> Total execution time: 0.0171
ERROR - 2023-04-25 18:55:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:42 --> Config Class Initialized
INFO - 2023-04-25 18:55:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:42 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:42 --> URI Class Initialized
INFO - 2023-04-25 18:55:42 --> Router Class Initialized
INFO - 2023-04-25 18:55:42 --> Output Class Initialized
INFO - 2023-04-25 18:55:42 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:42 --> Input Class Initialized
INFO - 2023-04-25 18:55:42 --> Language Class Initialized
INFO - 2023-04-25 18:55:42 --> Loader Class Initialized
INFO - 2023-04-25 18:55:42 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:42 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:42 --> Parser Class Initialized
INFO - 2023-04-25 18:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:42 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:42 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:42 --> Controller Class Initialized
INFO - 2023-04-25 18:55:42 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:42 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:42 --> Model Class Initialized
INFO - 2023-04-25 18:55:42 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:42 --> Total execution time: 0.0173
ERROR - 2023-04-25 18:55:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:42 --> Config Class Initialized
INFO - 2023-04-25 18:55:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:42 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:42 --> URI Class Initialized
INFO - 2023-04-25 18:55:42 --> Router Class Initialized
INFO - 2023-04-25 18:55:42 --> Output Class Initialized
INFO - 2023-04-25 18:55:42 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:42 --> Input Class Initialized
INFO - 2023-04-25 18:55:42 --> Language Class Initialized
INFO - 2023-04-25 18:55:42 --> Loader Class Initialized
INFO - 2023-04-25 18:55:42 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:42 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:42 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:42 --> Parser Class Initialized
INFO - 2023-04-25 18:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:42 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:42 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:42 --> Controller Class Initialized
INFO - 2023-04-25 18:55:42 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:42 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:42 --> Model Class Initialized
INFO - 2023-04-25 18:55:42 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:42 --> Total execution time: 0.0176
ERROR - 2023-04-25 18:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:44 --> Config Class Initialized
INFO - 2023-04-25 18:55:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:44 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:44 --> URI Class Initialized
INFO - 2023-04-25 18:55:44 --> Router Class Initialized
INFO - 2023-04-25 18:55:44 --> Output Class Initialized
INFO - 2023-04-25 18:55:44 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:44 --> Input Class Initialized
INFO - 2023-04-25 18:55:44 --> Language Class Initialized
INFO - 2023-04-25 18:55:44 --> Loader Class Initialized
INFO - 2023-04-25 18:55:44 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:44 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:44 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:44 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:44 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:44 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:44 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:44 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:44 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:44 --> Parser Class Initialized
INFO - 2023-04-25 18:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:44 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:44 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:44 --> Controller Class Initialized
INFO - 2023-04-25 18:55:44 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:44 --> Model Class Initialized
INFO - 2023-04-25 18:55:44 --> Model Class Initialized
INFO - 2023-04-25 18:55:44 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:44 --> Total execution time: 0.0181
ERROR - 2023-04-25 18:55:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:54 --> Config Class Initialized
INFO - 2023-04-25 18:55:54 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:54 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:54 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:54 --> URI Class Initialized
INFO - 2023-04-25 18:55:54 --> Router Class Initialized
INFO - 2023-04-25 18:55:54 --> Output Class Initialized
INFO - 2023-04-25 18:55:54 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:54 --> Input Class Initialized
INFO - 2023-04-25 18:55:54 --> Language Class Initialized
INFO - 2023-04-25 18:55:54 --> Loader Class Initialized
INFO - 2023-04-25 18:55:54 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:54 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:54 --> Parser Class Initialized
INFO - 2023-04-25 18:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:54 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:54 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:54 --> Controller Class Initialized
INFO - 2023-04-25 18:55:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:54 --> Model Class Initialized
INFO - 2023-04-25 18:55:54 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:54 --> Total execution time: 0.0179
ERROR - 2023-04-25 18:55:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:54 --> Config Class Initialized
INFO - 2023-04-25 18:55:54 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:54 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:54 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:54 --> URI Class Initialized
INFO - 2023-04-25 18:55:54 --> Router Class Initialized
INFO - 2023-04-25 18:55:54 --> Output Class Initialized
INFO - 2023-04-25 18:55:54 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:54 --> Input Class Initialized
INFO - 2023-04-25 18:55:54 --> Language Class Initialized
INFO - 2023-04-25 18:55:54 --> Loader Class Initialized
INFO - 2023-04-25 18:55:54 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:54 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:54 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:54 --> Parser Class Initialized
INFO - 2023-04-25 18:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:54 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:54 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:54 --> Controller Class Initialized
INFO - 2023-04-25 18:55:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:54 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:54 --> Model Class Initialized
INFO - 2023-04-25 18:55:54 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:54 --> Total execution time: 0.0170
ERROR - 2023-04-25 18:55:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:55 --> Config Class Initialized
INFO - 2023-04-25 18:55:55 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:55 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:55 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:55 --> URI Class Initialized
INFO - 2023-04-25 18:55:55 --> Router Class Initialized
INFO - 2023-04-25 18:55:55 --> Output Class Initialized
INFO - 2023-04-25 18:55:55 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:55 --> Input Class Initialized
INFO - 2023-04-25 18:55:55 --> Language Class Initialized
INFO - 2023-04-25 18:55:55 --> Loader Class Initialized
INFO - 2023-04-25 18:55:55 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:55 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:55 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:55 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:55 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:55 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:55 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:55 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:55 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:55 --> Parser Class Initialized
INFO - 2023-04-25 18:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:55 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:55 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:55 --> Controller Class Initialized
INFO - 2023-04-25 18:55:55 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:55 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:55 --> Model Class Initialized
INFO - 2023-04-25 18:55:55 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:55 --> Total execution time: 0.0172
ERROR - 2023-04-25 18:55:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:55:58 --> Config Class Initialized
INFO - 2023-04-25 18:55:58 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:55:58 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:55:58 --> Utf8 Class Initialized
INFO - 2023-04-25 18:55:58 --> URI Class Initialized
INFO - 2023-04-25 18:55:58 --> Router Class Initialized
INFO - 2023-04-25 18:55:58 --> Output Class Initialized
INFO - 2023-04-25 18:55:58 --> Security Class Initialized
DEBUG - 2023-04-25 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:55:58 --> Input Class Initialized
INFO - 2023-04-25 18:55:58 --> Language Class Initialized
INFO - 2023-04-25 18:55:58 --> Loader Class Initialized
INFO - 2023-04-25 18:55:58 --> Helper loaded: url_helper
INFO - 2023-04-25 18:55:58 --> Helper loaded: file_helper
INFO - 2023-04-25 18:55:58 --> Helper loaded: html_helper
INFO - 2023-04-25 18:55:58 --> Helper loaded: text_helper
INFO - 2023-04-25 18:55:58 --> Helper loaded: form_helper
INFO - 2023-04-25 18:55:58 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:55:58 --> Helper loaded: security_helper
INFO - 2023-04-25 18:55:58 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:55:58 --> Database Driver Class Initialized
INFO - 2023-04-25 18:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:55:58 --> Parser Class Initialized
INFO - 2023-04-25 18:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:55:58 --> Pagination Class Initialized
INFO - 2023-04-25 18:55:58 --> Form Validation Class Initialized
INFO - 2023-04-25 18:55:58 --> Controller Class Initialized
INFO - 2023-04-25 18:55:58 --> Model Class Initialized
DEBUG - 2023-04-25 18:55:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:55:58 --> Model Class Initialized
INFO - 2023-04-25 18:55:58 --> Model Class Initialized
INFO - 2023-04-25 18:55:58 --> Final output sent to browser
DEBUG - 2023-04-25 18:55:58 --> Total execution time: 0.0184
ERROR - 2023-04-25 18:56:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:00 --> Config Class Initialized
INFO - 2023-04-25 18:56:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:00 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:00 --> URI Class Initialized
INFO - 2023-04-25 18:56:00 --> Router Class Initialized
INFO - 2023-04-25 18:56:00 --> Output Class Initialized
INFO - 2023-04-25 18:56:00 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:00 --> Input Class Initialized
INFO - 2023-04-25 18:56:00 --> Language Class Initialized
INFO - 2023-04-25 18:56:00 --> Loader Class Initialized
INFO - 2023-04-25 18:56:00 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:00 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:00 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:00 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:00 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:00 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:00 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:00 --> Parser Class Initialized
INFO - 2023-04-25 18:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:00 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:00 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:00 --> Controller Class Initialized
INFO - 2023-04-25 18:56:00 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:00 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:00 --> Model Class Initialized
INFO - 2023-04-25 18:56:00 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:00 --> Total execution time: 0.0178
ERROR - 2023-04-25 18:56:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:10 --> Config Class Initialized
INFO - 2023-04-25 18:56:10 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:10 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:10 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:10 --> URI Class Initialized
INFO - 2023-04-25 18:56:10 --> Router Class Initialized
INFO - 2023-04-25 18:56:10 --> Output Class Initialized
INFO - 2023-04-25 18:56:10 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:10 --> Input Class Initialized
INFO - 2023-04-25 18:56:10 --> Language Class Initialized
INFO - 2023-04-25 18:56:10 --> Loader Class Initialized
INFO - 2023-04-25 18:56:10 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:10 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:10 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:10 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:10 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:10 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:10 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:10 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:10 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:10 --> Parser Class Initialized
INFO - 2023-04-25 18:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:10 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:10 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:10 --> Controller Class Initialized
INFO - 2023-04-25 18:56:10 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:10 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:10 --> Model Class Initialized
INFO - 2023-04-25 18:56:10 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:10 --> Total execution time: 0.0166
ERROR - 2023-04-25 18:56:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:11 --> Config Class Initialized
INFO - 2023-04-25 18:56:11 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:11 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:11 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:11 --> URI Class Initialized
INFO - 2023-04-25 18:56:11 --> Router Class Initialized
INFO - 2023-04-25 18:56:11 --> Output Class Initialized
INFO - 2023-04-25 18:56:11 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:11 --> Input Class Initialized
INFO - 2023-04-25 18:56:11 --> Language Class Initialized
INFO - 2023-04-25 18:56:11 --> Loader Class Initialized
INFO - 2023-04-25 18:56:11 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:11 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:11 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:11 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:11 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:11 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:11 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:11 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:11 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:11 --> Parser Class Initialized
INFO - 2023-04-25 18:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:11 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:11 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:11 --> Controller Class Initialized
INFO - 2023-04-25 18:56:11 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:11 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:11 --> Model Class Initialized
INFO - 2023-04-25 18:56:11 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:11 --> Total execution time: 0.0170
ERROR - 2023-04-25 18:56:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:13 --> Config Class Initialized
INFO - 2023-04-25 18:56:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:13 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:13 --> URI Class Initialized
INFO - 2023-04-25 18:56:13 --> Router Class Initialized
INFO - 2023-04-25 18:56:13 --> Output Class Initialized
INFO - 2023-04-25 18:56:13 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:13 --> Input Class Initialized
INFO - 2023-04-25 18:56:13 --> Language Class Initialized
INFO - 2023-04-25 18:56:13 --> Loader Class Initialized
INFO - 2023-04-25 18:56:13 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:13 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:13 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:13 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:13 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:13 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:13 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:13 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:13 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:13 --> Parser Class Initialized
INFO - 2023-04-25 18:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:13 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:13 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:13 --> Controller Class Initialized
INFO - 2023-04-25 18:56:13 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:13 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:13 --> Model Class Initialized
INFO - 2023-04-25 18:56:13 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:13 --> Total execution time: 0.0183
ERROR - 2023-04-25 18:56:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:15 --> Config Class Initialized
INFO - 2023-04-25 18:56:15 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:15 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:15 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:15 --> URI Class Initialized
INFO - 2023-04-25 18:56:15 --> Router Class Initialized
INFO - 2023-04-25 18:56:15 --> Output Class Initialized
INFO - 2023-04-25 18:56:15 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:15 --> Input Class Initialized
INFO - 2023-04-25 18:56:15 --> Language Class Initialized
INFO - 2023-04-25 18:56:15 --> Loader Class Initialized
INFO - 2023-04-25 18:56:15 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:15 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:15 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:15 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:15 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:15 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:15 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:15 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:15 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:15 --> Parser Class Initialized
INFO - 2023-04-25 18:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:15 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:15 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:15 --> Controller Class Initialized
INFO - 2023-04-25 18:56:15 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:15 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:15 --> Model Class Initialized
INFO - 2023-04-25 18:56:15 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:15 --> Total execution time: 0.0210
ERROR - 2023-04-25 18:56:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:17 --> Config Class Initialized
INFO - 2023-04-25 18:56:17 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:17 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:17 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:17 --> URI Class Initialized
INFO - 2023-04-25 18:56:17 --> Router Class Initialized
INFO - 2023-04-25 18:56:17 --> Output Class Initialized
INFO - 2023-04-25 18:56:17 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:17 --> Input Class Initialized
INFO - 2023-04-25 18:56:17 --> Language Class Initialized
INFO - 2023-04-25 18:56:17 --> Loader Class Initialized
INFO - 2023-04-25 18:56:17 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:17 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:17 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:17 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:17 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:17 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:17 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:17 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:17 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:17 --> Parser Class Initialized
INFO - 2023-04-25 18:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:17 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:17 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:17 --> Controller Class Initialized
INFO - 2023-04-25 18:56:17 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:17 --> Model Class Initialized
INFO - 2023-04-25 18:56:17 --> Model Class Initialized
INFO - 2023-04-25 18:56:17 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:17 --> Total execution time: 0.0180
ERROR - 2023-04-25 18:56:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:41 --> Config Class Initialized
INFO - 2023-04-25 18:56:41 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:41 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:41 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:41 --> URI Class Initialized
INFO - 2023-04-25 18:56:41 --> Router Class Initialized
INFO - 2023-04-25 18:56:41 --> Output Class Initialized
INFO - 2023-04-25 18:56:41 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:41 --> Input Class Initialized
INFO - 2023-04-25 18:56:41 --> Language Class Initialized
INFO - 2023-04-25 18:56:41 --> Loader Class Initialized
INFO - 2023-04-25 18:56:41 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:41 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:41 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:41 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:41 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:41 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:41 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:41 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:41 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:41 --> Parser Class Initialized
INFO - 2023-04-25 18:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:41 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:41 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:41 --> Controller Class Initialized
INFO - 2023-04-25 18:56:41 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:41 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:41 --> Model Class Initialized
INFO - 2023-04-25 18:56:41 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:41 --> Total execution time: 0.0207
ERROR - 2023-04-25 18:56:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:42 --> Config Class Initialized
INFO - 2023-04-25 18:56:42 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:42 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:42 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:42 --> URI Class Initialized
INFO - 2023-04-25 18:56:42 --> Router Class Initialized
INFO - 2023-04-25 18:56:42 --> Output Class Initialized
INFO - 2023-04-25 18:56:42 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:42 --> Input Class Initialized
INFO - 2023-04-25 18:56:42 --> Language Class Initialized
INFO - 2023-04-25 18:56:42 --> Loader Class Initialized
INFO - 2023-04-25 18:56:42 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:42 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:42 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:42 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:42 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:42 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:42 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:42 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:42 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:42 --> Parser Class Initialized
INFO - 2023-04-25 18:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:42 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:42 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:42 --> Controller Class Initialized
INFO - 2023-04-25 18:56:42 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:42 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:42 --> Model Class Initialized
INFO - 2023-04-25 18:56:42 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:42 --> Total execution time: 0.0180
ERROR - 2023-04-25 18:56:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:43 --> Config Class Initialized
INFO - 2023-04-25 18:56:43 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:43 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:43 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:43 --> URI Class Initialized
INFO - 2023-04-25 18:56:43 --> Router Class Initialized
INFO - 2023-04-25 18:56:43 --> Output Class Initialized
INFO - 2023-04-25 18:56:43 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:43 --> Input Class Initialized
INFO - 2023-04-25 18:56:43 --> Language Class Initialized
INFO - 2023-04-25 18:56:43 --> Loader Class Initialized
INFO - 2023-04-25 18:56:43 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:43 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:43 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:43 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:43 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:43 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:43 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:43 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:43 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:43 --> Parser Class Initialized
INFO - 2023-04-25 18:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:43 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:43 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:43 --> Controller Class Initialized
INFO - 2023-04-25 18:56:43 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:43 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:43 --> Model Class Initialized
INFO - 2023-04-25 18:56:43 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:43 --> Total execution time: 0.0173
ERROR - 2023-04-25 18:56:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:56:45 --> Config Class Initialized
INFO - 2023-04-25 18:56:45 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:56:45 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:56:45 --> Utf8 Class Initialized
INFO - 2023-04-25 18:56:45 --> URI Class Initialized
INFO - 2023-04-25 18:56:45 --> Router Class Initialized
INFO - 2023-04-25 18:56:45 --> Output Class Initialized
INFO - 2023-04-25 18:56:45 --> Security Class Initialized
DEBUG - 2023-04-25 18:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:56:45 --> Input Class Initialized
INFO - 2023-04-25 18:56:45 --> Language Class Initialized
INFO - 2023-04-25 18:56:45 --> Loader Class Initialized
INFO - 2023-04-25 18:56:45 --> Helper loaded: url_helper
INFO - 2023-04-25 18:56:45 --> Helper loaded: file_helper
INFO - 2023-04-25 18:56:45 --> Helper loaded: html_helper
INFO - 2023-04-25 18:56:45 --> Helper loaded: text_helper
INFO - 2023-04-25 18:56:45 --> Helper loaded: form_helper
INFO - 2023-04-25 18:56:45 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:56:45 --> Helper loaded: security_helper
INFO - 2023-04-25 18:56:45 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:56:45 --> Database Driver Class Initialized
INFO - 2023-04-25 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:56:45 --> Parser Class Initialized
INFO - 2023-04-25 18:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:56:45 --> Pagination Class Initialized
INFO - 2023-04-25 18:56:45 --> Form Validation Class Initialized
INFO - 2023-04-25 18:56:45 --> Controller Class Initialized
INFO - 2023-04-25 18:56:45 --> Model Class Initialized
DEBUG - 2023-04-25 18:56:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:56:45 --> Model Class Initialized
INFO - 2023-04-25 18:56:45 --> Model Class Initialized
INFO - 2023-04-25 18:56:45 --> Final output sent to browser
DEBUG - 2023-04-25 18:56:45 --> Total execution time: 0.0182
ERROR - 2023-04-25 18:57:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:20 --> Config Class Initialized
INFO - 2023-04-25 18:57:20 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:20 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:20 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:20 --> URI Class Initialized
INFO - 2023-04-25 18:57:20 --> Router Class Initialized
INFO - 2023-04-25 18:57:20 --> Output Class Initialized
INFO - 2023-04-25 18:57:20 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:20 --> Input Class Initialized
INFO - 2023-04-25 18:57:20 --> Language Class Initialized
INFO - 2023-04-25 18:57:20 --> Loader Class Initialized
INFO - 2023-04-25 18:57:20 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:20 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:20 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:20 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:20 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:20 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:20 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:20 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:20 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:20 --> Parser Class Initialized
INFO - 2023-04-25 18:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:20 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:20 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:20 --> Controller Class Initialized
INFO - 2023-04-25 18:57:20 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:20 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:20 --> Model Class Initialized
INFO - 2023-04-25 18:57:20 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:20 --> Total execution time: 0.0201
ERROR - 2023-04-25 18:57:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:21 --> Config Class Initialized
INFO - 2023-04-25 18:57:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:21 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:21 --> URI Class Initialized
INFO - 2023-04-25 18:57:21 --> Router Class Initialized
INFO - 2023-04-25 18:57:21 --> Output Class Initialized
INFO - 2023-04-25 18:57:21 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:21 --> Input Class Initialized
INFO - 2023-04-25 18:57:21 --> Language Class Initialized
INFO - 2023-04-25 18:57:21 --> Loader Class Initialized
INFO - 2023-04-25 18:57:21 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:21 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:21 --> Parser Class Initialized
INFO - 2023-04-25 18:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:21 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:21 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:21 --> Controller Class Initialized
INFO - 2023-04-25 18:57:21 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:21 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:21 --> Model Class Initialized
INFO - 2023-04-25 18:57:21 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:21 --> Total execution time: 0.0172
ERROR - 2023-04-25 18:57:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:21 --> Config Class Initialized
INFO - 2023-04-25 18:57:21 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:21 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:21 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:21 --> URI Class Initialized
INFO - 2023-04-25 18:57:21 --> Router Class Initialized
INFO - 2023-04-25 18:57:21 --> Output Class Initialized
INFO - 2023-04-25 18:57:21 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:21 --> Input Class Initialized
INFO - 2023-04-25 18:57:21 --> Language Class Initialized
INFO - 2023-04-25 18:57:21 --> Loader Class Initialized
INFO - 2023-04-25 18:57:21 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:21 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:21 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:21 --> Parser Class Initialized
INFO - 2023-04-25 18:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:21 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:21 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:21 --> Controller Class Initialized
INFO - 2023-04-25 18:57:21 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:21 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:21 --> Model Class Initialized
INFO - 2023-04-25 18:57:21 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:21 --> Total execution time: 0.0186
ERROR - 2023-04-25 18:57:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:23 --> Config Class Initialized
INFO - 2023-04-25 18:57:23 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:23 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:23 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:23 --> URI Class Initialized
INFO - 2023-04-25 18:57:23 --> Router Class Initialized
INFO - 2023-04-25 18:57:23 --> Output Class Initialized
INFO - 2023-04-25 18:57:23 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:23 --> Input Class Initialized
INFO - 2023-04-25 18:57:23 --> Language Class Initialized
INFO - 2023-04-25 18:57:23 --> Loader Class Initialized
INFO - 2023-04-25 18:57:23 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:23 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:23 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:23 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:23 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:23 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:23 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:23 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:23 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:23 --> Parser Class Initialized
INFO - 2023-04-25 18:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:23 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:23 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:23 --> Controller Class Initialized
INFO - 2023-04-25 18:57:23 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:23 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:23 --> Model Class Initialized
INFO - 2023-04-25 18:57:23 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:23 --> Total execution time: 0.0175
ERROR - 2023-04-25 18:57:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:24 --> Config Class Initialized
INFO - 2023-04-25 18:57:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:24 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:24 --> URI Class Initialized
INFO - 2023-04-25 18:57:24 --> Router Class Initialized
INFO - 2023-04-25 18:57:24 --> Output Class Initialized
INFO - 2023-04-25 18:57:24 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:24 --> Input Class Initialized
INFO - 2023-04-25 18:57:24 --> Language Class Initialized
INFO - 2023-04-25 18:57:24 --> Loader Class Initialized
INFO - 2023-04-25 18:57:24 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:24 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:24 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:24 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:24 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:24 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:24 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:24 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:24 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:24 --> Parser Class Initialized
INFO - 2023-04-25 18:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:24 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:24 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:24 --> Controller Class Initialized
INFO - 2023-04-25 18:57:24 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:24 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:24 --> Model Class Initialized
INFO - 2023-04-25 18:57:24 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:24 --> Total execution time: 0.0173
ERROR - 2023-04-25 18:57:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:25 --> Config Class Initialized
INFO - 2023-04-25 18:57:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:25 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:25 --> URI Class Initialized
INFO - 2023-04-25 18:57:25 --> Router Class Initialized
INFO - 2023-04-25 18:57:25 --> Output Class Initialized
INFO - 2023-04-25 18:57:25 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:25 --> Input Class Initialized
INFO - 2023-04-25 18:57:25 --> Language Class Initialized
INFO - 2023-04-25 18:57:25 --> Loader Class Initialized
INFO - 2023-04-25 18:57:25 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:25 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:25 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:25 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:25 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:25 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:25 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:25 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:25 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:25 --> Parser Class Initialized
INFO - 2023-04-25 18:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:25 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:25 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:25 --> Controller Class Initialized
INFO - 2023-04-25 18:57:25 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:25 --> Model Class Initialized
INFO - 2023-04-25 18:57:25 --> Model Class Initialized
INFO - 2023-04-25 18:57:25 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:25 --> Total execution time: 0.0219
ERROR - 2023-04-25 18:57:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:35 --> Config Class Initialized
INFO - 2023-04-25 18:57:35 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:35 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:35 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:35 --> URI Class Initialized
INFO - 2023-04-25 18:57:35 --> Router Class Initialized
INFO - 2023-04-25 18:57:35 --> Output Class Initialized
INFO - 2023-04-25 18:57:35 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:35 --> Input Class Initialized
INFO - 2023-04-25 18:57:35 --> Language Class Initialized
INFO - 2023-04-25 18:57:35 --> Loader Class Initialized
INFO - 2023-04-25 18:57:35 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:35 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:35 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:35 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:35 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:35 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:35 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:35 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:35 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:35 --> Parser Class Initialized
INFO - 2023-04-25 18:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:35 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:35 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:35 --> Controller Class Initialized
INFO - 2023-04-25 18:57:35 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:35 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:35 --> Model Class Initialized
INFO - 2023-04-25 18:57:35 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:35 --> Total execution time: 0.0172
ERROR - 2023-04-25 18:57:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:37 --> Config Class Initialized
INFO - 2023-04-25 18:57:37 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:37 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:37 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:37 --> URI Class Initialized
INFO - 2023-04-25 18:57:37 --> Router Class Initialized
INFO - 2023-04-25 18:57:37 --> Output Class Initialized
INFO - 2023-04-25 18:57:37 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:37 --> Input Class Initialized
INFO - 2023-04-25 18:57:37 --> Language Class Initialized
INFO - 2023-04-25 18:57:37 --> Loader Class Initialized
INFO - 2023-04-25 18:57:37 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:37 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:37 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:37 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:37 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:37 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:37 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:37 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:37 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:37 --> Parser Class Initialized
INFO - 2023-04-25 18:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:37 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:37 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:37 --> Controller Class Initialized
INFO - 2023-04-25 18:57:37 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:37 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:37 --> Model Class Initialized
INFO - 2023-04-25 18:57:37 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:37 --> Total execution time: 0.0173
ERROR - 2023-04-25 18:57:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:57:39 --> Config Class Initialized
INFO - 2023-04-25 18:57:39 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:57:39 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:57:39 --> Utf8 Class Initialized
INFO - 2023-04-25 18:57:39 --> URI Class Initialized
INFO - 2023-04-25 18:57:39 --> Router Class Initialized
INFO - 2023-04-25 18:57:39 --> Output Class Initialized
INFO - 2023-04-25 18:57:39 --> Security Class Initialized
DEBUG - 2023-04-25 18:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:57:39 --> Input Class Initialized
INFO - 2023-04-25 18:57:39 --> Language Class Initialized
INFO - 2023-04-25 18:57:39 --> Loader Class Initialized
INFO - 2023-04-25 18:57:39 --> Helper loaded: url_helper
INFO - 2023-04-25 18:57:39 --> Helper loaded: file_helper
INFO - 2023-04-25 18:57:39 --> Helper loaded: html_helper
INFO - 2023-04-25 18:57:39 --> Helper loaded: text_helper
INFO - 2023-04-25 18:57:39 --> Helper loaded: form_helper
INFO - 2023-04-25 18:57:39 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:57:39 --> Helper loaded: security_helper
INFO - 2023-04-25 18:57:39 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:57:39 --> Database Driver Class Initialized
INFO - 2023-04-25 18:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:57:39 --> Parser Class Initialized
INFO - 2023-04-25 18:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:57:39 --> Pagination Class Initialized
INFO - 2023-04-25 18:57:39 --> Form Validation Class Initialized
INFO - 2023-04-25 18:57:39 --> Controller Class Initialized
INFO - 2023-04-25 18:57:39 --> Model Class Initialized
DEBUG - 2023-04-25 18:57:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:57:39 --> Model Class Initialized
INFO - 2023-04-25 18:57:39 --> Model Class Initialized
INFO - 2023-04-25 18:57:39 --> Final output sent to browser
DEBUG - 2023-04-25 18:57:39 --> Total execution time: 0.0177
ERROR - 2023-04-25 18:58:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:58:37 --> Config Class Initialized
INFO - 2023-04-25 18:58:37 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:58:37 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:58:37 --> Utf8 Class Initialized
INFO - 2023-04-25 18:58:37 --> URI Class Initialized
INFO - 2023-04-25 18:58:37 --> Router Class Initialized
INFO - 2023-04-25 18:58:37 --> Output Class Initialized
INFO - 2023-04-25 18:58:37 --> Security Class Initialized
DEBUG - 2023-04-25 18:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:58:37 --> Input Class Initialized
INFO - 2023-04-25 18:58:37 --> Language Class Initialized
INFO - 2023-04-25 18:58:37 --> Loader Class Initialized
INFO - 2023-04-25 18:58:37 --> Helper loaded: url_helper
INFO - 2023-04-25 18:58:37 --> Helper loaded: file_helper
INFO - 2023-04-25 18:58:37 --> Helper loaded: html_helper
INFO - 2023-04-25 18:58:37 --> Helper loaded: text_helper
INFO - 2023-04-25 18:58:37 --> Helper loaded: form_helper
INFO - 2023-04-25 18:58:37 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:58:37 --> Helper loaded: security_helper
INFO - 2023-04-25 18:58:37 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:58:37 --> Database Driver Class Initialized
INFO - 2023-04-25 18:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:58:37 --> Parser Class Initialized
INFO - 2023-04-25 18:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:58:37 --> Pagination Class Initialized
INFO - 2023-04-25 18:58:37 --> Form Validation Class Initialized
INFO - 2023-04-25 18:58:37 --> Controller Class Initialized
INFO - 2023-04-25 18:58:37 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:58:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:37 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:37 --> Model Class Initialized
INFO - 2023-04-25 18:58:37 --> Final output sent to browser
DEBUG - 2023-04-25 18:58:37 --> Total execution time: 0.0208
ERROR - 2023-04-25 18:58:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:58:38 --> Config Class Initialized
INFO - 2023-04-25 18:58:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:58:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:58:38 --> Utf8 Class Initialized
INFO - 2023-04-25 18:58:38 --> URI Class Initialized
INFO - 2023-04-25 18:58:38 --> Router Class Initialized
INFO - 2023-04-25 18:58:38 --> Output Class Initialized
INFO - 2023-04-25 18:58:38 --> Security Class Initialized
DEBUG - 2023-04-25 18:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:58:38 --> Input Class Initialized
INFO - 2023-04-25 18:58:38 --> Language Class Initialized
INFO - 2023-04-25 18:58:38 --> Loader Class Initialized
INFO - 2023-04-25 18:58:38 --> Helper loaded: url_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: file_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: html_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: text_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: form_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: security_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:58:38 --> Database Driver Class Initialized
INFO - 2023-04-25 18:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:58:38 --> Parser Class Initialized
INFO - 2023-04-25 18:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:58:38 --> Pagination Class Initialized
INFO - 2023-04-25 18:58:38 --> Form Validation Class Initialized
INFO - 2023-04-25 18:58:38 --> Controller Class Initialized
INFO - 2023-04-25 18:58:38 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:38 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:38 --> Model Class Initialized
INFO - 2023-04-25 18:58:38 --> Final output sent to browser
DEBUG - 2023-04-25 18:58:38 --> Total execution time: 0.0174
ERROR - 2023-04-25 18:58:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:58:38 --> Config Class Initialized
INFO - 2023-04-25 18:58:38 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:58:38 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:58:38 --> Utf8 Class Initialized
INFO - 2023-04-25 18:58:38 --> URI Class Initialized
INFO - 2023-04-25 18:58:38 --> Router Class Initialized
INFO - 2023-04-25 18:58:38 --> Output Class Initialized
INFO - 2023-04-25 18:58:38 --> Security Class Initialized
DEBUG - 2023-04-25 18:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:58:38 --> Input Class Initialized
INFO - 2023-04-25 18:58:38 --> Language Class Initialized
INFO - 2023-04-25 18:58:38 --> Loader Class Initialized
INFO - 2023-04-25 18:58:38 --> Helper loaded: url_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: file_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: html_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: text_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: form_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: security_helper
INFO - 2023-04-25 18:58:38 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:58:38 --> Database Driver Class Initialized
INFO - 2023-04-25 18:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:58:38 --> Parser Class Initialized
INFO - 2023-04-25 18:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:58:38 --> Pagination Class Initialized
INFO - 2023-04-25 18:58:38 --> Form Validation Class Initialized
INFO - 2023-04-25 18:58:38 --> Controller Class Initialized
INFO - 2023-04-25 18:58:38 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:38 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:38 --> Model Class Initialized
INFO - 2023-04-25 18:58:38 --> Final output sent to browser
DEBUG - 2023-04-25 18:58:38 --> Total execution time: 0.0176
ERROR - 2023-04-25 18:58:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:58:41 --> Config Class Initialized
INFO - 2023-04-25 18:58:41 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:58:41 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:58:41 --> Utf8 Class Initialized
INFO - 2023-04-25 18:58:41 --> URI Class Initialized
INFO - 2023-04-25 18:58:41 --> Router Class Initialized
INFO - 2023-04-25 18:58:41 --> Output Class Initialized
INFO - 2023-04-25 18:58:41 --> Security Class Initialized
DEBUG - 2023-04-25 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:58:41 --> Input Class Initialized
INFO - 2023-04-25 18:58:41 --> Language Class Initialized
INFO - 2023-04-25 18:58:41 --> Loader Class Initialized
INFO - 2023-04-25 18:58:41 --> Helper loaded: url_helper
INFO - 2023-04-25 18:58:41 --> Helper loaded: file_helper
INFO - 2023-04-25 18:58:41 --> Helper loaded: html_helper
INFO - 2023-04-25 18:58:41 --> Helper loaded: text_helper
INFO - 2023-04-25 18:58:41 --> Helper loaded: form_helper
INFO - 2023-04-25 18:58:41 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:58:41 --> Helper loaded: security_helper
INFO - 2023-04-25 18:58:41 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:58:41 --> Database Driver Class Initialized
INFO - 2023-04-25 18:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:58:41 --> Parser Class Initialized
INFO - 2023-04-25 18:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:58:41 --> Pagination Class Initialized
INFO - 2023-04-25 18:58:41 --> Form Validation Class Initialized
INFO - 2023-04-25 18:58:41 --> Controller Class Initialized
INFO - 2023-04-25 18:58:41 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:41 --> Model Class Initialized
INFO - 2023-04-25 18:58:41 --> Model Class Initialized
INFO - 2023-04-25 18:58:41 --> Final output sent to browser
DEBUG - 2023-04-25 18:58:41 --> Total execution time: 0.0186
ERROR - 2023-04-25 18:58:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:58:50 --> Config Class Initialized
INFO - 2023-04-25 18:58:50 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:58:50 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:58:50 --> Utf8 Class Initialized
INFO - 2023-04-25 18:58:50 --> URI Class Initialized
INFO - 2023-04-25 18:58:50 --> Router Class Initialized
INFO - 2023-04-25 18:58:50 --> Output Class Initialized
INFO - 2023-04-25 18:58:50 --> Security Class Initialized
DEBUG - 2023-04-25 18:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:58:50 --> Input Class Initialized
INFO - 2023-04-25 18:58:50 --> Language Class Initialized
INFO - 2023-04-25 18:58:50 --> Loader Class Initialized
INFO - 2023-04-25 18:58:50 --> Helper loaded: url_helper
INFO - 2023-04-25 18:58:50 --> Helper loaded: file_helper
INFO - 2023-04-25 18:58:50 --> Helper loaded: html_helper
INFO - 2023-04-25 18:58:50 --> Helper loaded: text_helper
INFO - 2023-04-25 18:58:50 --> Helper loaded: form_helper
INFO - 2023-04-25 18:58:50 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:58:50 --> Helper loaded: security_helper
INFO - 2023-04-25 18:58:50 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:58:50 --> Database Driver Class Initialized
INFO - 2023-04-25 18:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:58:50 --> Parser Class Initialized
INFO - 2023-04-25 18:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:58:50 --> Pagination Class Initialized
INFO - 2023-04-25 18:58:50 --> Form Validation Class Initialized
INFO - 2023-04-25 18:58:50 --> Controller Class Initialized
INFO - 2023-04-25 18:58:50 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:50 --> Model Class Initialized
INFO - 2023-04-25 18:58:50 --> Email Class Initialized
INFO - 2023-04-25 18:58:50 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-04-25 18:58:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:58:51 --> Config Class Initialized
INFO - 2023-04-25 18:58:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:58:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:58:51 --> Utf8 Class Initialized
INFO - 2023-04-25 18:58:51 --> URI Class Initialized
INFO - 2023-04-25 18:58:51 --> Router Class Initialized
INFO - 2023-04-25 18:58:51 --> Output Class Initialized
INFO - 2023-04-25 18:58:51 --> Security Class Initialized
DEBUG - 2023-04-25 18:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:58:51 --> Input Class Initialized
INFO - 2023-04-25 18:58:51 --> Language Class Initialized
INFO - 2023-04-25 18:58:51 --> Loader Class Initialized
INFO - 2023-04-25 18:58:51 --> Helper loaded: url_helper
INFO - 2023-04-25 18:58:51 --> Helper loaded: file_helper
INFO - 2023-04-25 18:58:51 --> Helper loaded: html_helper
INFO - 2023-04-25 18:58:51 --> Helper loaded: text_helper
INFO - 2023-04-25 18:58:51 --> Helper loaded: form_helper
INFO - 2023-04-25 18:58:51 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:58:51 --> Helper loaded: security_helper
INFO - 2023-04-25 18:58:51 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:58:51 --> Database Driver Class Initialized
INFO - 2023-04-25 18:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:58:51 --> Parser Class Initialized
INFO - 2023-04-25 18:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:58:51 --> Pagination Class Initialized
INFO - 2023-04-25 18:58:51 --> Form Validation Class Initialized
INFO - 2023-04-25 18:58:51 --> Controller Class Initialized
INFO - 2023-04-25 18:58:51 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:51 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-04-25 18:58:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:58:51 --> Model Class Initialized
INFO - 2023-04-25 18:58:51 --> Model Class Initialized
INFO - 2023-04-25 18:58:51 --> Model Class Initialized
INFO - 2023-04-25 18:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:58:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:58:51 --> Final output sent to browser
DEBUG - 2023-04-25 18:58:51 --> Total execution time: 0.0553
ERROR - 2023-04-25 18:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:58:59 --> Config Class Initialized
INFO - 2023-04-25 18:58:59 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:58:59 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:58:59 --> Utf8 Class Initialized
INFO - 2023-04-25 18:58:59 --> URI Class Initialized
INFO - 2023-04-25 18:58:59 --> Router Class Initialized
INFO - 2023-04-25 18:58:59 --> Output Class Initialized
INFO - 2023-04-25 18:58:59 --> Security Class Initialized
DEBUG - 2023-04-25 18:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:58:59 --> Input Class Initialized
INFO - 2023-04-25 18:58:59 --> Language Class Initialized
INFO - 2023-04-25 18:58:59 --> Loader Class Initialized
INFO - 2023-04-25 18:58:59 --> Helper loaded: url_helper
INFO - 2023-04-25 18:58:59 --> Helper loaded: file_helper
INFO - 2023-04-25 18:58:59 --> Helper loaded: html_helper
INFO - 2023-04-25 18:58:59 --> Helper loaded: text_helper
INFO - 2023-04-25 18:58:59 --> Helper loaded: form_helper
INFO - 2023-04-25 18:58:59 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:58:59 --> Helper loaded: security_helper
INFO - 2023-04-25 18:58:59 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:58:59 --> Database Driver Class Initialized
INFO - 2023-04-25 18:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:58:59 --> Parser Class Initialized
INFO - 2023-04-25 18:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:58:59 --> Pagination Class Initialized
INFO - 2023-04-25 18:58:59 --> Form Validation Class Initialized
INFO - 2023-04-25 18:58:59 --> Controller Class Initialized
INFO - 2023-04-25 18:58:59 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:59 --> Model Class Initialized
DEBUG - 2023-04-25 18:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:59 --> Model Class Initialized
INFO - 2023-04-25 18:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-04-25 18:58:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:58:59 --> Model Class Initialized
INFO - 2023-04-25 18:58:59 --> Model Class Initialized
INFO - 2023-04-25 18:58:59 --> Model Class Initialized
INFO - 2023-04-25 18:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:58:59 --> Final output sent to browser
DEBUG - 2023-04-25 18:58:59 --> Total execution time: 0.0609
ERROR - 2023-04-25 18:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:59:00 --> Config Class Initialized
INFO - 2023-04-25 18:59:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:59:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:59:00 --> Utf8 Class Initialized
INFO - 2023-04-25 18:59:00 --> URI Class Initialized
INFO - 2023-04-25 18:59:00 --> Router Class Initialized
INFO - 2023-04-25 18:59:00 --> Output Class Initialized
INFO - 2023-04-25 18:59:00 --> Security Class Initialized
DEBUG - 2023-04-25 18:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:59:00 --> Input Class Initialized
INFO - 2023-04-25 18:59:00 --> Language Class Initialized
INFO - 2023-04-25 18:59:00 --> Loader Class Initialized
INFO - 2023-04-25 18:59:00 --> Helper loaded: url_helper
INFO - 2023-04-25 18:59:00 --> Helper loaded: file_helper
INFO - 2023-04-25 18:59:00 --> Helper loaded: html_helper
INFO - 2023-04-25 18:59:00 --> Helper loaded: text_helper
INFO - 2023-04-25 18:59:00 --> Helper loaded: form_helper
INFO - 2023-04-25 18:59:00 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:59:00 --> Helper loaded: security_helper
INFO - 2023-04-25 18:59:00 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:59:00 --> Database Driver Class Initialized
INFO - 2023-04-25 18:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:59:00 --> Parser Class Initialized
INFO - 2023-04-25 18:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:59:00 --> Pagination Class Initialized
INFO - 2023-04-25 18:59:00 --> Form Validation Class Initialized
INFO - 2023-04-25 18:59:00 --> Controller Class Initialized
INFO - 2023-04-25 18:59:00 --> Model Class Initialized
DEBUG - 2023-04-25 18:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:00 --> Model Class Initialized
DEBUG - 2023-04-25 18:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:00 --> Model Class Initialized
INFO - 2023-04-25 18:59:00 --> Final output sent to browser
DEBUG - 2023-04-25 18:59:00 --> Total execution time: 0.0201
ERROR - 2023-04-25 18:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:59:05 --> Config Class Initialized
INFO - 2023-04-25 18:59:05 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:59:05 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:59:05 --> Utf8 Class Initialized
INFO - 2023-04-25 18:59:05 --> URI Class Initialized
INFO - 2023-04-25 18:59:05 --> Router Class Initialized
INFO - 2023-04-25 18:59:05 --> Output Class Initialized
INFO - 2023-04-25 18:59:05 --> Security Class Initialized
DEBUG - 2023-04-25 18:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:59:05 --> Input Class Initialized
INFO - 2023-04-25 18:59:05 --> Language Class Initialized
INFO - 2023-04-25 18:59:05 --> Loader Class Initialized
INFO - 2023-04-25 18:59:05 --> Helper loaded: url_helper
INFO - 2023-04-25 18:59:05 --> Helper loaded: file_helper
INFO - 2023-04-25 18:59:05 --> Helper loaded: html_helper
INFO - 2023-04-25 18:59:05 --> Helper loaded: text_helper
INFO - 2023-04-25 18:59:05 --> Helper loaded: form_helper
INFO - 2023-04-25 18:59:05 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:59:05 --> Helper loaded: security_helper
INFO - 2023-04-25 18:59:05 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:59:05 --> Database Driver Class Initialized
INFO - 2023-04-25 18:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:59:05 --> Parser Class Initialized
INFO - 2023-04-25 18:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:59:05 --> Pagination Class Initialized
INFO - 2023-04-25 18:59:05 --> Form Validation Class Initialized
INFO - 2023-04-25 18:59:05 --> Controller Class Initialized
INFO - 2023-04-25 18:59:05 --> Model Class Initialized
DEBUG - 2023-04-25 18:59:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:05 --> Model Class Initialized
DEBUG - 2023-04-25 18:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-04-25 18:59:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:59:05 --> Model Class Initialized
INFO - 2023-04-25 18:59:05 --> Model Class Initialized
INFO - 2023-04-25 18:59:05 --> Model Class Initialized
INFO - 2023-04-25 18:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:59:05 --> Final output sent to browser
DEBUG - 2023-04-25 18:59:05 --> Total execution time: 0.0559
ERROR - 2023-04-25 18:59:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-04-25 18:59:12 --> Config Class Initialized
INFO - 2023-04-25 18:59:12 --> Hooks Class Initialized
DEBUG - 2023-04-25 18:59:12 --> UTF-8 Support Enabled
INFO - 2023-04-25 18:59:12 --> Utf8 Class Initialized
INFO - 2023-04-25 18:59:12 --> URI Class Initialized
DEBUG - 2023-04-25 18:59:12 --> No URI present. Default controller set.
INFO - 2023-04-25 18:59:12 --> Router Class Initialized
INFO - 2023-04-25 18:59:12 --> Output Class Initialized
INFO - 2023-04-25 18:59:12 --> Security Class Initialized
DEBUG - 2023-04-25 18:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 18:59:12 --> Input Class Initialized
INFO - 2023-04-25 18:59:12 --> Language Class Initialized
INFO - 2023-04-25 18:59:12 --> Loader Class Initialized
INFO - 2023-04-25 18:59:12 --> Helper loaded: url_helper
INFO - 2023-04-25 18:59:12 --> Helper loaded: file_helper
INFO - 2023-04-25 18:59:12 --> Helper loaded: html_helper
INFO - 2023-04-25 18:59:12 --> Helper loaded: text_helper
INFO - 2023-04-25 18:59:12 --> Helper loaded: form_helper
INFO - 2023-04-25 18:59:12 --> Helper loaded: lang_helper
INFO - 2023-04-25 18:59:12 --> Helper loaded: security_helper
INFO - 2023-04-25 18:59:12 --> Helper loaded: cookie_helper
INFO - 2023-04-25 18:59:12 --> Database Driver Class Initialized
INFO - 2023-04-25 18:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-25 18:59:12 --> Parser Class Initialized
INFO - 2023-04-25 18:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-04-25 18:59:12 --> Pagination Class Initialized
INFO - 2023-04-25 18:59:12 --> Form Validation Class Initialized
INFO - 2023-04-25 18:59:12 --> Controller Class Initialized
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
DEBUG - 2023-04-25 18:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
DEBUG - 2023-04-25 18:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
DEBUG - 2023-04-25 18:59:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-04-25 18:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
INFO - 2023-04-25 18:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-04-25 18:59:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-04-25 18:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-04-25 18:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-04-25 18:59:12 --> Model Class Initialized
INFO - 2023-04-25 18:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-04-25 18:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-04-25 18:59:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-04-25 18:59:12 --> Final output sent to browser
DEBUG - 2023-04-25 18:59:12 --> Total execution time: 0.0674
