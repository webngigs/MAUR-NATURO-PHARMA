<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-19 00:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 00:11:48 --> Config Class Initialized
INFO - 2024-01-19 00:11:48 --> Hooks Class Initialized
DEBUG - 2024-01-19 00:11:48 --> UTF-8 Support Enabled
INFO - 2024-01-19 00:11:48 --> Utf8 Class Initialized
INFO - 2024-01-19 00:11:48 --> URI Class Initialized
INFO - 2024-01-19 00:11:48 --> Router Class Initialized
INFO - 2024-01-19 00:11:48 --> Output Class Initialized
INFO - 2024-01-19 00:11:48 --> Security Class Initialized
DEBUG - 2024-01-19 00:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 00:11:48 --> Input Class Initialized
INFO - 2024-01-19 00:11:48 --> Language Class Initialized
ERROR - 2024-01-19 00:11:48 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-19 07:21:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:21:25 --> Config Class Initialized
INFO - 2024-01-19 07:21:25 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:21:25 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:21:25 --> Utf8 Class Initialized
INFO - 2024-01-19 07:21:25 --> URI Class Initialized
DEBUG - 2024-01-19 07:21:25 --> No URI present. Default controller set.
INFO - 2024-01-19 07:21:25 --> Router Class Initialized
INFO - 2024-01-19 07:21:25 --> Output Class Initialized
INFO - 2024-01-19 07:21:25 --> Security Class Initialized
DEBUG - 2024-01-19 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:21:25 --> Input Class Initialized
INFO - 2024-01-19 07:21:25 --> Language Class Initialized
INFO - 2024-01-19 07:21:25 --> Loader Class Initialized
INFO - 2024-01-19 07:21:25 --> Helper loaded: url_helper
INFO - 2024-01-19 07:21:25 --> Helper loaded: file_helper
INFO - 2024-01-19 07:21:25 --> Helper loaded: html_helper
INFO - 2024-01-19 07:21:25 --> Helper loaded: text_helper
INFO - 2024-01-19 07:21:25 --> Helper loaded: form_helper
INFO - 2024-01-19 07:21:25 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:21:25 --> Helper loaded: security_helper
INFO - 2024-01-19 07:21:25 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:21:25 --> Database Driver Class Initialized
INFO - 2024-01-19 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:21:25 --> Parser Class Initialized
INFO - 2024-01-19 07:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:21:25 --> Pagination Class Initialized
INFO - 2024-01-19 07:21:25 --> Form Validation Class Initialized
INFO - 2024-01-19 07:21:25 --> Controller Class Initialized
INFO - 2024-01-19 07:21:25 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 07:21:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:21:26 --> Config Class Initialized
INFO - 2024-01-19 07:21:26 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:21:26 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:21:26 --> Utf8 Class Initialized
INFO - 2024-01-19 07:21:26 --> URI Class Initialized
INFO - 2024-01-19 07:21:26 --> Router Class Initialized
INFO - 2024-01-19 07:21:26 --> Output Class Initialized
INFO - 2024-01-19 07:21:26 --> Security Class Initialized
DEBUG - 2024-01-19 07:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:21:26 --> Input Class Initialized
INFO - 2024-01-19 07:21:26 --> Language Class Initialized
INFO - 2024-01-19 07:21:26 --> Loader Class Initialized
INFO - 2024-01-19 07:21:26 --> Helper loaded: url_helper
INFO - 2024-01-19 07:21:26 --> Helper loaded: file_helper
INFO - 2024-01-19 07:21:26 --> Helper loaded: html_helper
INFO - 2024-01-19 07:21:26 --> Helper loaded: text_helper
INFO - 2024-01-19 07:21:26 --> Helper loaded: form_helper
INFO - 2024-01-19 07:21:26 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:21:26 --> Helper loaded: security_helper
INFO - 2024-01-19 07:21:26 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:21:26 --> Database Driver Class Initialized
INFO - 2024-01-19 07:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:21:26 --> Parser Class Initialized
INFO - 2024-01-19 07:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:21:26 --> Pagination Class Initialized
INFO - 2024-01-19 07:21:26 --> Form Validation Class Initialized
INFO - 2024-01-19 07:21:26 --> Controller Class Initialized
INFO - 2024-01-19 07:21:26 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-19 07:21:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:21:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:21:26 --> Model Class Initialized
INFO - 2024-01-19 07:21:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:21:26 --> Final output sent to browser
DEBUG - 2024-01-19 07:21:26 --> Total execution time: 0.0352
ERROR - 2024-01-19 07:21:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:21:40 --> Config Class Initialized
INFO - 2024-01-19 07:21:40 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:21:40 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:21:40 --> Utf8 Class Initialized
INFO - 2024-01-19 07:21:40 --> URI Class Initialized
INFO - 2024-01-19 07:21:40 --> Router Class Initialized
INFO - 2024-01-19 07:21:40 --> Output Class Initialized
INFO - 2024-01-19 07:21:40 --> Security Class Initialized
DEBUG - 2024-01-19 07:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:21:40 --> Input Class Initialized
INFO - 2024-01-19 07:21:40 --> Language Class Initialized
INFO - 2024-01-19 07:21:40 --> Loader Class Initialized
INFO - 2024-01-19 07:21:40 --> Helper loaded: url_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: file_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: html_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: text_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: form_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: security_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:21:40 --> Database Driver Class Initialized
INFO - 2024-01-19 07:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:21:40 --> Parser Class Initialized
INFO - 2024-01-19 07:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:21:40 --> Pagination Class Initialized
INFO - 2024-01-19 07:21:40 --> Form Validation Class Initialized
INFO - 2024-01-19 07:21:40 --> Controller Class Initialized
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
INFO - 2024-01-19 07:21:40 --> Final output sent to browser
DEBUG - 2024-01-19 07:21:40 --> Total execution time: 0.0227
ERROR - 2024-01-19 07:21:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:21:40 --> Config Class Initialized
INFO - 2024-01-19 07:21:40 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:21:40 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:21:40 --> Utf8 Class Initialized
INFO - 2024-01-19 07:21:40 --> URI Class Initialized
DEBUG - 2024-01-19 07:21:40 --> No URI present. Default controller set.
INFO - 2024-01-19 07:21:40 --> Router Class Initialized
INFO - 2024-01-19 07:21:40 --> Output Class Initialized
INFO - 2024-01-19 07:21:40 --> Security Class Initialized
DEBUG - 2024-01-19 07:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:21:40 --> Input Class Initialized
INFO - 2024-01-19 07:21:40 --> Language Class Initialized
INFO - 2024-01-19 07:21:40 --> Loader Class Initialized
INFO - 2024-01-19 07:21:40 --> Helper loaded: url_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: file_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: html_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: text_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: form_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: security_helper
INFO - 2024-01-19 07:21:40 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:21:40 --> Database Driver Class Initialized
INFO - 2024-01-19 07:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:21:40 --> Parser Class Initialized
INFO - 2024-01-19 07:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:21:40 --> Pagination Class Initialized
INFO - 2024-01-19 07:21:40 --> Form Validation Class Initialized
INFO - 2024-01-19 07:21:40 --> Controller Class Initialized
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
INFO - 2024-01-19 07:21:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 07:21:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:21:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:21:40 --> Model Class Initialized
INFO - 2024-01-19 07:21:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:21:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:21:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:21:40 --> Final output sent to browser
DEBUG - 2024-01-19 07:21:40 --> Total execution time: 0.2394
ERROR - 2024-01-19 07:21:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:21:51 --> Config Class Initialized
INFO - 2024-01-19 07:21:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:21:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:21:51 --> Utf8 Class Initialized
INFO - 2024-01-19 07:21:51 --> URI Class Initialized
INFO - 2024-01-19 07:21:51 --> Router Class Initialized
INFO - 2024-01-19 07:21:51 --> Output Class Initialized
INFO - 2024-01-19 07:21:51 --> Security Class Initialized
DEBUG - 2024-01-19 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:21:51 --> Input Class Initialized
INFO - 2024-01-19 07:21:51 --> Language Class Initialized
INFO - 2024-01-19 07:21:51 --> Loader Class Initialized
INFO - 2024-01-19 07:21:51 --> Helper loaded: url_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: file_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: html_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: text_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: form_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: security_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:21:51 --> Database Driver Class Initialized
INFO - 2024-01-19 07:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:21:51 --> Parser Class Initialized
INFO - 2024-01-19 07:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:21:51 --> Pagination Class Initialized
INFO - 2024-01-19 07:21:51 --> Form Validation Class Initialized
INFO - 2024-01-19 07:21:51 --> Controller Class Initialized
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-19 07:21:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:21:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
INFO - 2024-01-19 07:21:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:21:51 --> Final output sent to browser
DEBUG - 2024-01-19 07:21:51 --> Total execution time: 0.0279
ERROR - 2024-01-19 07:21:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:21:51 --> Config Class Initialized
INFO - 2024-01-19 07:21:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:21:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:21:51 --> Utf8 Class Initialized
INFO - 2024-01-19 07:21:51 --> URI Class Initialized
INFO - 2024-01-19 07:21:51 --> Router Class Initialized
INFO - 2024-01-19 07:21:51 --> Output Class Initialized
INFO - 2024-01-19 07:21:51 --> Security Class Initialized
DEBUG - 2024-01-19 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:21:51 --> Input Class Initialized
INFO - 2024-01-19 07:21:51 --> Language Class Initialized
INFO - 2024-01-19 07:21:51 --> Loader Class Initialized
INFO - 2024-01-19 07:21:51 --> Helper loaded: url_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: file_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: html_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: text_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: form_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: security_helper
INFO - 2024-01-19 07:21:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:21:51 --> Database Driver Class Initialized
INFO - 2024-01-19 07:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:21:51 --> Parser Class Initialized
INFO - 2024-01-19 07:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:21:51 --> Pagination Class Initialized
INFO - 2024-01-19 07:21:51 --> Form Validation Class Initialized
INFO - 2024-01-19 07:21:51 --> Controller Class Initialized
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
DEBUG - 2024-01-19 07:21:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
INFO - 2024-01-19 07:21:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 07:21:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:21:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:21:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:21:51 --> Model Class Initialized
INFO - 2024-01-19 07:21:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:21:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:21:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:21:52 --> Final output sent to browser
DEBUG - 2024-01-19 07:21:52 --> Total execution time: 0.2286
ERROR - 2024-01-19 07:22:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:22:01 --> Config Class Initialized
INFO - 2024-01-19 07:22:01 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:22:01 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:22:01 --> Utf8 Class Initialized
INFO - 2024-01-19 07:22:01 --> URI Class Initialized
INFO - 2024-01-19 07:22:01 --> Router Class Initialized
INFO - 2024-01-19 07:22:01 --> Output Class Initialized
INFO - 2024-01-19 07:22:01 --> Security Class Initialized
DEBUG - 2024-01-19 07:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:22:01 --> Input Class Initialized
INFO - 2024-01-19 07:22:01 --> Language Class Initialized
INFO - 2024-01-19 07:22:01 --> Loader Class Initialized
INFO - 2024-01-19 07:22:01 --> Helper loaded: url_helper
INFO - 2024-01-19 07:22:01 --> Helper loaded: file_helper
INFO - 2024-01-19 07:22:01 --> Helper loaded: html_helper
INFO - 2024-01-19 07:22:01 --> Helper loaded: text_helper
INFO - 2024-01-19 07:22:01 --> Helper loaded: form_helper
INFO - 2024-01-19 07:22:01 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:22:01 --> Helper loaded: security_helper
INFO - 2024-01-19 07:22:01 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:22:01 --> Database Driver Class Initialized
INFO - 2024-01-19 07:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:22:01 --> Parser Class Initialized
INFO - 2024-01-19 07:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:22:01 --> Pagination Class Initialized
INFO - 2024-01-19 07:22:01 --> Form Validation Class Initialized
INFO - 2024-01-19 07:22:01 --> Controller Class Initialized
INFO - 2024-01-19 07:22:01 --> Model Class Initialized
DEBUG - 2024-01-19 07:22:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:01 --> Model Class Initialized
DEBUG - 2024-01-19 07:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:01 --> Model Class Initialized
INFO - 2024-01-19 07:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-19 07:22:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:22:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:22:01 --> Model Class Initialized
INFO - 2024-01-19 07:22:01 --> Model Class Initialized
INFO - 2024-01-19 07:22:01 --> Model Class Initialized
INFO - 2024-01-19 07:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:22:02 --> Final output sent to browser
DEBUG - 2024-01-19 07:22:02 --> Total execution time: 0.1881
ERROR - 2024-01-19 07:22:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:22:11 --> Config Class Initialized
INFO - 2024-01-19 07:22:11 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:22:11 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:22:11 --> Utf8 Class Initialized
INFO - 2024-01-19 07:22:11 --> URI Class Initialized
INFO - 2024-01-19 07:22:11 --> Router Class Initialized
INFO - 2024-01-19 07:22:11 --> Output Class Initialized
INFO - 2024-01-19 07:22:11 --> Security Class Initialized
DEBUG - 2024-01-19 07:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:22:11 --> Input Class Initialized
INFO - 2024-01-19 07:22:11 --> Language Class Initialized
INFO - 2024-01-19 07:22:11 --> Loader Class Initialized
INFO - 2024-01-19 07:22:11 --> Helper loaded: url_helper
INFO - 2024-01-19 07:22:11 --> Helper loaded: file_helper
INFO - 2024-01-19 07:22:11 --> Helper loaded: html_helper
INFO - 2024-01-19 07:22:11 --> Helper loaded: text_helper
INFO - 2024-01-19 07:22:11 --> Helper loaded: form_helper
INFO - 2024-01-19 07:22:11 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:22:11 --> Helper loaded: security_helper
INFO - 2024-01-19 07:22:11 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:22:11 --> Database Driver Class Initialized
INFO - 2024-01-19 07:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:22:11 --> Parser Class Initialized
INFO - 2024-01-19 07:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:22:11 --> Pagination Class Initialized
INFO - 2024-01-19 07:22:11 --> Form Validation Class Initialized
INFO - 2024-01-19 07:22:11 --> Controller Class Initialized
INFO - 2024-01-19 07:22:11 --> Model Class Initialized
DEBUG - 2024-01-19 07:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:11 --> Final output sent to browser
DEBUG - 2024-01-19 07:22:11 --> Total execution time: 0.0162
ERROR - 2024-01-19 07:22:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:22:12 --> Config Class Initialized
INFO - 2024-01-19 07:22:12 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:22:12 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:22:12 --> Utf8 Class Initialized
INFO - 2024-01-19 07:22:12 --> URI Class Initialized
INFO - 2024-01-19 07:22:12 --> Router Class Initialized
INFO - 2024-01-19 07:22:12 --> Output Class Initialized
INFO - 2024-01-19 07:22:12 --> Security Class Initialized
DEBUG - 2024-01-19 07:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:22:12 --> Input Class Initialized
INFO - 2024-01-19 07:22:12 --> Language Class Initialized
INFO - 2024-01-19 07:22:12 --> Loader Class Initialized
INFO - 2024-01-19 07:22:12 --> Helper loaded: url_helper
INFO - 2024-01-19 07:22:12 --> Helper loaded: file_helper
INFO - 2024-01-19 07:22:12 --> Helper loaded: html_helper
INFO - 2024-01-19 07:22:12 --> Helper loaded: text_helper
INFO - 2024-01-19 07:22:12 --> Helper loaded: form_helper
INFO - 2024-01-19 07:22:12 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:22:12 --> Helper loaded: security_helper
INFO - 2024-01-19 07:22:12 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:22:12 --> Database Driver Class Initialized
INFO - 2024-01-19 07:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:22:12 --> Parser Class Initialized
INFO - 2024-01-19 07:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:22:12 --> Pagination Class Initialized
INFO - 2024-01-19 07:22:12 --> Form Validation Class Initialized
INFO - 2024-01-19 07:22:12 --> Controller Class Initialized
INFO - 2024-01-19 07:22:12 --> Model Class Initialized
DEBUG - 2024-01-19 07:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:12 --> Final output sent to browser
DEBUG - 2024-01-19 07:22:12 --> Total execution time: 0.0154
ERROR - 2024-01-19 07:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:22:23 --> Config Class Initialized
INFO - 2024-01-19 07:22:23 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:22:23 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:22:23 --> Utf8 Class Initialized
INFO - 2024-01-19 07:22:23 --> URI Class Initialized
INFO - 2024-01-19 07:22:23 --> Router Class Initialized
INFO - 2024-01-19 07:22:23 --> Output Class Initialized
INFO - 2024-01-19 07:22:23 --> Security Class Initialized
DEBUG - 2024-01-19 07:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:22:23 --> Input Class Initialized
INFO - 2024-01-19 07:22:23 --> Language Class Initialized
INFO - 2024-01-19 07:22:23 --> Loader Class Initialized
INFO - 2024-01-19 07:22:23 --> Helper loaded: url_helper
INFO - 2024-01-19 07:22:23 --> Helper loaded: file_helper
INFO - 2024-01-19 07:22:23 --> Helper loaded: html_helper
INFO - 2024-01-19 07:22:23 --> Helper loaded: text_helper
INFO - 2024-01-19 07:22:23 --> Helper loaded: form_helper
INFO - 2024-01-19 07:22:23 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:22:23 --> Helper loaded: security_helper
INFO - 2024-01-19 07:22:23 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:22:23 --> Database Driver Class Initialized
INFO - 2024-01-19 07:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:22:23 --> Parser Class Initialized
INFO - 2024-01-19 07:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:22:23 --> Pagination Class Initialized
INFO - 2024-01-19 07:22:23 --> Form Validation Class Initialized
INFO - 2024-01-19 07:22:23 --> Controller Class Initialized
INFO - 2024-01-19 07:22:23 --> Final output sent to browser
DEBUG - 2024-01-19 07:22:23 --> Total execution time: 0.0174
ERROR - 2024-01-19 07:22:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:22:41 --> Config Class Initialized
INFO - 2024-01-19 07:22:41 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:22:41 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:22:41 --> Utf8 Class Initialized
INFO - 2024-01-19 07:22:41 --> URI Class Initialized
INFO - 2024-01-19 07:22:41 --> Router Class Initialized
INFO - 2024-01-19 07:22:41 --> Output Class Initialized
INFO - 2024-01-19 07:22:41 --> Security Class Initialized
DEBUG - 2024-01-19 07:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:22:41 --> Input Class Initialized
INFO - 2024-01-19 07:22:41 --> Language Class Initialized
INFO - 2024-01-19 07:22:41 --> Loader Class Initialized
INFO - 2024-01-19 07:22:41 --> Helper loaded: url_helper
INFO - 2024-01-19 07:22:41 --> Helper loaded: file_helper
INFO - 2024-01-19 07:22:41 --> Helper loaded: html_helper
INFO - 2024-01-19 07:22:41 --> Helper loaded: text_helper
INFO - 2024-01-19 07:22:41 --> Helper loaded: form_helper
INFO - 2024-01-19 07:22:41 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:22:41 --> Helper loaded: security_helper
INFO - 2024-01-19 07:22:41 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:22:41 --> Database Driver Class Initialized
INFO - 2024-01-19 07:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:22:41 --> Parser Class Initialized
INFO - 2024-01-19 07:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:22:41 --> Pagination Class Initialized
INFO - 2024-01-19 07:22:41 --> Form Validation Class Initialized
INFO - 2024-01-19 07:22:41 --> Controller Class Initialized
INFO - 2024-01-19 07:22:41 --> Model Class Initialized
DEBUG - 2024-01-19 07:22:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:41 --> Model Class Initialized
DEBUG - 2024-01-19 07:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:41 --> Model Class Initialized
INFO - 2024-01-19 07:22:41 --> Final output sent to browser
DEBUG - 2024-01-19 07:22:41 --> Total execution time: 0.0913
ERROR - 2024-01-19 07:22:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:22:48 --> Config Class Initialized
INFO - 2024-01-19 07:22:48 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:22:48 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:22:48 --> Utf8 Class Initialized
INFO - 2024-01-19 07:22:48 --> URI Class Initialized
INFO - 2024-01-19 07:22:48 --> Router Class Initialized
INFO - 2024-01-19 07:22:48 --> Output Class Initialized
INFO - 2024-01-19 07:22:48 --> Security Class Initialized
DEBUG - 2024-01-19 07:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:22:48 --> Input Class Initialized
INFO - 2024-01-19 07:22:48 --> Language Class Initialized
INFO - 2024-01-19 07:22:48 --> Loader Class Initialized
INFO - 2024-01-19 07:22:48 --> Helper loaded: url_helper
INFO - 2024-01-19 07:22:48 --> Helper loaded: file_helper
INFO - 2024-01-19 07:22:48 --> Helper loaded: html_helper
INFO - 2024-01-19 07:22:48 --> Helper loaded: text_helper
INFO - 2024-01-19 07:22:48 --> Helper loaded: form_helper
INFO - 2024-01-19 07:22:48 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:22:48 --> Helper loaded: security_helper
INFO - 2024-01-19 07:22:48 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:22:48 --> Database Driver Class Initialized
INFO - 2024-01-19 07:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:22:48 --> Parser Class Initialized
INFO - 2024-01-19 07:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:22:48 --> Pagination Class Initialized
INFO - 2024-01-19 07:22:48 --> Form Validation Class Initialized
INFO - 2024-01-19 07:22:48 --> Controller Class Initialized
INFO - 2024-01-19 07:22:48 --> Model Class Initialized
DEBUG - 2024-01-19 07:22:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:22:48 --> Model Class Initialized
INFO - 2024-01-19 07:22:48 --> Model Class Initialized
INFO - 2024-01-19 07:22:48 --> Final output sent to browser
DEBUG - 2024-01-19 07:22:48 --> Total execution time: 0.0194
ERROR - 2024-01-19 07:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:23:00 --> Config Class Initialized
INFO - 2024-01-19 07:23:00 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:23:00 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:23:00 --> Utf8 Class Initialized
INFO - 2024-01-19 07:23:00 --> URI Class Initialized
INFO - 2024-01-19 07:23:00 --> Router Class Initialized
INFO - 2024-01-19 07:23:00 --> Output Class Initialized
INFO - 2024-01-19 07:23:00 --> Security Class Initialized
DEBUG - 2024-01-19 07:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:23:00 --> Input Class Initialized
INFO - 2024-01-19 07:23:00 --> Language Class Initialized
INFO - 2024-01-19 07:23:00 --> Loader Class Initialized
INFO - 2024-01-19 07:23:00 --> Helper loaded: url_helper
INFO - 2024-01-19 07:23:00 --> Helper loaded: file_helper
INFO - 2024-01-19 07:23:00 --> Helper loaded: html_helper
INFO - 2024-01-19 07:23:00 --> Helper loaded: text_helper
INFO - 2024-01-19 07:23:00 --> Helper loaded: form_helper
INFO - 2024-01-19 07:23:00 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:23:00 --> Helper loaded: security_helper
INFO - 2024-01-19 07:23:00 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:23:00 --> Database Driver Class Initialized
INFO - 2024-01-19 07:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:23:00 --> Parser Class Initialized
INFO - 2024-01-19 07:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:23:00 --> Pagination Class Initialized
INFO - 2024-01-19 07:23:00 --> Form Validation Class Initialized
INFO - 2024-01-19 07:23:00 --> Controller Class Initialized
INFO - 2024-01-19 07:23:00 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:00 --> Model Class Initialized
INFO - 2024-01-19 07:23:00 --> Final output sent to browser
DEBUG - 2024-01-19 07:23:00 --> Total execution time: 0.0185
ERROR - 2024-01-19 07:23:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:23:01 --> Config Class Initialized
INFO - 2024-01-19 07:23:01 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:23:01 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:23:01 --> Utf8 Class Initialized
INFO - 2024-01-19 07:23:01 --> URI Class Initialized
INFO - 2024-01-19 07:23:01 --> Router Class Initialized
INFO - 2024-01-19 07:23:01 --> Output Class Initialized
INFO - 2024-01-19 07:23:01 --> Security Class Initialized
DEBUG - 2024-01-19 07:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:23:01 --> Input Class Initialized
INFO - 2024-01-19 07:23:01 --> Language Class Initialized
INFO - 2024-01-19 07:23:01 --> Loader Class Initialized
INFO - 2024-01-19 07:23:01 --> Helper loaded: url_helper
INFO - 2024-01-19 07:23:01 --> Helper loaded: file_helper
INFO - 2024-01-19 07:23:01 --> Helper loaded: html_helper
INFO - 2024-01-19 07:23:01 --> Helper loaded: text_helper
INFO - 2024-01-19 07:23:01 --> Helper loaded: form_helper
INFO - 2024-01-19 07:23:01 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:23:01 --> Helper loaded: security_helper
INFO - 2024-01-19 07:23:01 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:23:01 --> Database Driver Class Initialized
INFO - 2024-01-19 07:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:23:01 --> Parser Class Initialized
INFO - 2024-01-19 07:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:23:01 --> Pagination Class Initialized
INFO - 2024-01-19 07:23:01 --> Form Validation Class Initialized
INFO - 2024-01-19 07:23:01 --> Controller Class Initialized
INFO - 2024-01-19 07:23:01 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:01 --> Model Class Initialized
INFO - 2024-01-19 07:23:01 --> Final output sent to browser
DEBUG - 2024-01-19 07:23:01 --> Total execution time: 0.0167
ERROR - 2024-01-19 07:23:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:23:27 --> Config Class Initialized
INFO - 2024-01-19 07:23:27 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:23:27 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:23:27 --> Utf8 Class Initialized
INFO - 2024-01-19 07:23:27 --> URI Class Initialized
INFO - 2024-01-19 07:23:27 --> Router Class Initialized
INFO - 2024-01-19 07:23:27 --> Output Class Initialized
INFO - 2024-01-19 07:23:27 --> Security Class Initialized
DEBUG - 2024-01-19 07:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:23:27 --> Input Class Initialized
INFO - 2024-01-19 07:23:27 --> Language Class Initialized
INFO - 2024-01-19 07:23:27 --> Loader Class Initialized
INFO - 2024-01-19 07:23:27 --> Helper loaded: url_helper
INFO - 2024-01-19 07:23:27 --> Helper loaded: file_helper
INFO - 2024-01-19 07:23:27 --> Helper loaded: html_helper
INFO - 2024-01-19 07:23:27 --> Helper loaded: text_helper
INFO - 2024-01-19 07:23:27 --> Helper loaded: form_helper
INFO - 2024-01-19 07:23:27 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:23:27 --> Helper loaded: security_helper
INFO - 2024-01-19 07:23:27 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:23:27 --> Database Driver Class Initialized
INFO - 2024-01-19 07:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:23:27 --> Parser Class Initialized
INFO - 2024-01-19 07:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:23:27 --> Pagination Class Initialized
INFO - 2024-01-19 07:23:27 --> Form Validation Class Initialized
INFO - 2024-01-19 07:23:27 --> Controller Class Initialized
INFO - 2024-01-19 07:23:27 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:27 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:27 --> Model Class Initialized
INFO - 2024-01-19 07:23:27 --> Final output sent to browser
DEBUG - 2024-01-19 07:23:27 --> Total execution time: 0.0919
ERROR - 2024-01-19 07:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:23:31 --> Config Class Initialized
INFO - 2024-01-19 07:23:31 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:23:31 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:23:31 --> Utf8 Class Initialized
INFO - 2024-01-19 07:23:31 --> URI Class Initialized
INFO - 2024-01-19 07:23:31 --> Router Class Initialized
INFO - 2024-01-19 07:23:31 --> Output Class Initialized
INFO - 2024-01-19 07:23:31 --> Security Class Initialized
DEBUG - 2024-01-19 07:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:23:31 --> Input Class Initialized
INFO - 2024-01-19 07:23:31 --> Language Class Initialized
INFO - 2024-01-19 07:23:31 --> Loader Class Initialized
INFO - 2024-01-19 07:23:31 --> Helper loaded: url_helper
INFO - 2024-01-19 07:23:31 --> Helper loaded: file_helper
INFO - 2024-01-19 07:23:31 --> Helper loaded: html_helper
INFO - 2024-01-19 07:23:31 --> Helper loaded: text_helper
INFO - 2024-01-19 07:23:31 --> Helper loaded: form_helper
INFO - 2024-01-19 07:23:31 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:23:31 --> Helper loaded: security_helper
INFO - 2024-01-19 07:23:31 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:23:31 --> Database Driver Class Initialized
INFO - 2024-01-19 07:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:23:31 --> Parser Class Initialized
INFO - 2024-01-19 07:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:23:31 --> Pagination Class Initialized
INFO - 2024-01-19 07:23:31 --> Form Validation Class Initialized
INFO - 2024-01-19 07:23:31 --> Controller Class Initialized
INFO - 2024-01-19 07:23:31 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:31 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:31 --> Model Class Initialized
INFO - 2024-01-19 07:23:31 --> Final output sent to browser
DEBUG - 2024-01-19 07:23:31 --> Total execution time: 0.0873
ERROR - 2024-01-19 07:23:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:23:32 --> Config Class Initialized
INFO - 2024-01-19 07:23:32 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:23:32 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:23:32 --> Utf8 Class Initialized
INFO - 2024-01-19 07:23:32 --> URI Class Initialized
INFO - 2024-01-19 07:23:32 --> Router Class Initialized
INFO - 2024-01-19 07:23:32 --> Output Class Initialized
INFO - 2024-01-19 07:23:32 --> Security Class Initialized
DEBUG - 2024-01-19 07:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:23:32 --> Input Class Initialized
INFO - 2024-01-19 07:23:32 --> Language Class Initialized
INFO - 2024-01-19 07:23:32 --> Loader Class Initialized
INFO - 2024-01-19 07:23:32 --> Helper loaded: url_helper
INFO - 2024-01-19 07:23:32 --> Helper loaded: file_helper
INFO - 2024-01-19 07:23:32 --> Helper loaded: html_helper
INFO - 2024-01-19 07:23:32 --> Helper loaded: text_helper
INFO - 2024-01-19 07:23:32 --> Helper loaded: form_helper
INFO - 2024-01-19 07:23:32 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:23:32 --> Helper loaded: security_helper
INFO - 2024-01-19 07:23:32 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:23:32 --> Database Driver Class Initialized
INFO - 2024-01-19 07:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:23:32 --> Parser Class Initialized
INFO - 2024-01-19 07:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:23:32 --> Pagination Class Initialized
INFO - 2024-01-19 07:23:32 --> Form Validation Class Initialized
INFO - 2024-01-19 07:23:32 --> Controller Class Initialized
INFO - 2024-01-19 07:23:32 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:32 --> Model Class Initialized
DEBUG - 2024-01-19 07:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:23:32 --> Model Class Initialized
INFO - 2024-01-19 07:23:32 --> Final output sent to browser
DEBUG - 2024-01-19 07:23:32 --> Total execution time: 0.0992
ERROR - 2024-01-19 07:24:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:24 --> Config Class Initialized
INFO - 2024-01-19 07:24:24 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:24 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:24 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:24 --> URI Class Initialized
INFO - 2024-01-19 07:24:24 --> Router Class Initialized
INFO - 2024-01-19 07:24:24 --> Output Class Initialized
INFO - 2024-01-19 07:24:24 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:24 --> Input Class Initialized
INFO - 2024-01-19 07:24:24 --> Language Class Initialized
INFO - 2024-01-19 07:24:24 --> Loader Class Initialized
INFO - 2024-01-19 07:24:24 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:24 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:24 --> Parser Class Initialized
INFO - 2024-01-19 07:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:24 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:24 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:24 --> Controller Class Initialized
INFO - 2024-01-19 07:24:24 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:24 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:24 --> Model Class Initialized
INFO - 2024-01-19 07:24:24 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:24 --> Total execution time: 0.0903
ERROR - 2024-01-19 07:24:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:24 --> Config Class Initialized
INFO - 2024-01-19 07:24:24 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:24 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:24 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:24 --> URI Class Initialized
INFO - 2024-01-19 07:24:24 --> Router Class Initialized
INFO - 2024-01-19 07:24:24 --> Output Class Initialized
INFO - 2024-01-19 07:24:24 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:24 --> Input Class Initialized
INFO - 2024-01-19 07:24:24 --> Language Class Initialized
INFO - 2024-01-19 07:24:24 --> Loader Class Initialized
INFO - 2024-01-19 07:24:24 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:24 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:24 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:24 --> Parser Class Initialized
INFO - 2024-01-19 07:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:24 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:24 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:24 --> Controller Class Initialized
INFO - 2024-01-19 07:24:24 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:24 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:24 --> Model Class Initialized
INFO - 2024-01-19 07:24:24 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:24 --> Total execution time: 0.0854
ERROR - 2024-01-19 07:24:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:31 --> Config Class Initialized
INFO - 2024-01-19 07:24:31 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:31 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:31 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:31 --> URI Class Initialized
INFO - 2024-01-19 07:24:31 --> Router Class Initialized
INFO - 2024-01-19 07:24:31 --> Output Class Initialized
INFO - 2024-01-19 07:24:31 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:31 --> Input Class Initialized
INFO - 2024-01-19 07:24:31 --> Language Class Initialized
INFO - 2024-01-19 07:24:31 --> Loader Class Initialized
INFO - 2024-01-19 07:24:31 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:31 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:31 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:31 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:31 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:31 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:31 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:31 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:31 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:31 --> Parser Class Initialized
INFO - 2024-01-19 07:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:31 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:31 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:31 --> Controller Class Initialized
INFO - 2024-01-19 07:24:31 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:31 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:31 --> Model Class Initialized
INFO - 2024-01-19 07:24:31 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:31 --> Total execution time: 0.0855
ERROR - 2024-01-19 07:24:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:35 --> Config Class Initialized
INFO - 2024-01-19 07:24:35 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:35 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:35 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:35 --> URI Class Initialized
INFO - 2024-01-19 07:24:35 --> Router Class Initialized
INFO - 2024-01-19 07:24:35 --> Output Class Initialized
INFO - 2024-01-19 07:24:35 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:35 --> Input Class Initialized
INFO - 2024-01-19 07:24:35 --> Language Class Initialized
INFO - 2024-01-19 07:24:35 --> Loader Class Initialized
INFO - 2024-01-19 07:24:35 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:35 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:35 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:35 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:35 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:35 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:35 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:35 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:35 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:35 --> Parser Class Initialized
INFO - 2024-01-19 07:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:35 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:35 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:35 --> Controller Class Initialized
INFO - 2024-01-19 07:24:35 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:35 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:35 --> Model Class Initialized
INFO - 2024-01-19 07:24:35 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:35 --> Total execution time: 0.1049
ERROR - 2024-01-19 07:24:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:43 --> Config Class Initialized
INFO - 2024-01-19 07:24:43 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:43 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:43 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:43 --> URI Class Initialized
INFO - 2024-01-19 07:24:43 --> Router Class Initialized
INFO - 2024-01-19 07:24:43 --> Output Class Initialized
INFO - 2024-01-19 07:24:43 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:43 --> Input Class Initialized
INFO - 2024-01-19 07:24:43 --> Language Class Initialized
INFO - 2024-01-19 07:24:43 --> Loader Class Initialized
INFO - 2024-01-19 07:24:43 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:43 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:43 --> Parser Class Initialized
INFO - 2024-01-19 07:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:43 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:43 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:43 --> Controller Class Initialized
INFO - 2024-01-19 07:24:43 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:43 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:43 --> Model Class Initialized
INFO - 2024-01-19 07:24:43 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:43 --> Total execution time: 0.0211
ERROR - 2024-01-19 07:24:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:43 --> Config Class Initialized
INFO - 2024-01-19 07:24:43 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:43 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:43 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:43 --> URI Class Initialized
INFO - 2024-01-19 07:24:43 --> Router Class Initialized
INFO - 2024-01-19 07:24:43 --> Output Class Initialized
INFO - 2024-01-19 07:24:43 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:43 --> Input Class Initialized
INFO - 2024-01-19 07:24:43 --> Language Class Initialized
INFO - 2024-01-19 07:24:43 --> Loader Class Initialized
INFO - 2024-01-19 07:24:43 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:43 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:43 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:43 --> Parser Class Initialized
INFO - 2024-01-19 07:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:43 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:43 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:43 --> Controller Class Initialized
INFO - 2024-01-19 07:24:43 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:43 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:43 --> Model Class Initialized
INFO - 2024-01-19 07:24:43 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:43 --> Total execution time: 0.0193
ERROR - 2024-01-19 07:24:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:45 --> Config Class Initialized
INFO - 2024-01-19 07:24:45 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:45 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:45 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:45 --> URI Class Initialized
INFO - 2024-01-19 07:24:45 --> Router Class Initialized
INFO - 2024-01-19 07:24:45 --> Output Class Initialized
INFO - 2024-01-19 07:24:45 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:45 --> Input Class Initialized
INFO - 2024-01-19 07:24:45 --> Language Class Initialized
INFO - 2024-01-19 07:24:45 --> Loader Class Initialized
INFO - 2024-01-19 07:24:45 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:45 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:45 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:45 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:45 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:45 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:45 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:45 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:45 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:45 --> Parser Class Initialized
INFO - 2024-01-19 07:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:45 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:45 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:45 --> Controller Class Initialized
INFO - 2024-01-19 07:24:45 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:45 --> Model Class Initialized
INFO - 2024-01-19 07:24:45 --> Model Class Initialized
INFO - 2024-01-19 07:24:45 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:45 --> Total execution time: 0.0241
ERROR - 2024-01-19 07:24:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:24:57 --> Config Class Initialized
INFO - 2024-01-19 07:24:57 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:24:57 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:24:57 --> Utf8 Class Initialized
INFO - 2024-01-19 07:24:57 --> URI Class Initialized
INFO - 2024-01-19 07:24:57 --> Router Class Initialized
INFO - 2024-01-19 07:24:57 --> Output Class Initialized
INFO - 2024-01-19 07:24:57 --> Security Class Initialized
DEBUG - 2024-01-19 07:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:24:57 --> Input Class Initialized
INFO - 2024-01-19 07:24:57 --> Language Class Initialized
INFO - 2024-01-19 07:24:57 --> Loader Class Initialized
INFO - 2024-01-19 07:24:57 --> Helper loaded: url_helper
INFO - 2024-01-19 07:24:57 --> Helper loaded: file_helper
INFO - 2024-01-19 07:24:57 --> Helper loaded: html_helper
INFO - 2024-01-19 07:24:57 --> Helper loaded: text_helper
INFO - 2024-01-19 07:24:57 --> Helper loaded: form_helper
INFO - 2024-01-19 07:24:57 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:24:57 --> Helper loaded: security_helper
INFO - 2024-01-19 07:24:57 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:24:57 --> Database Driver Class Initialized
INFO - 2024-01-19 07:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:24:57 --> Parser Class Initialized
INFO - 2024-01-19 07:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:24:57 --> Pagination Class Initialized
INFO - 2024-01-19 07:24:57 --> Form Validation Class Initialized
INFO - 2024-01-19 07:24:57 --> Controller Class Initialized
INFO - 2024-01-19 07:24:57 --> Model Class Initialized
DEBUG - 2024-01-19 07:24:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:24:57 --> Model Class Initialized
INFO - 2024-01-19 07:24:57 --> Final output sent to browser
DEBUG - 2024-01-19 07:24:57 --> Total execution time: 0.0201
ERROR - 2024-01-19 07:25:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:25:00 --> Config Class Initialized
INFO - 2024-01-19 07:25:00 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:25:00 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:25:00 --> Utf8 Class Initialized
INFO - 2024-01-19 07:25:00 --> URI Class Initialized
INFO - 2024-01-19 07:25:00 --> Router Class Initialized
INFO - 2024-01-19 07:25:00 --> Output Class Initialized
INFO - 2024-01-19 07:25:00 --> Security Class Initialized
DEBUG - 2024-01-19 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:25:00 --> Input Class Initialized
INFO - 2024-01-19 07:25:00 --> Language Class Initialized
INFO - 2024-01-19 07:25:00 --> Loader Class Initialized
INFO - 2024-01-19 07:25:00 --> Helper loaded: url_helper
INFO - 2024-01-19 07:25:00 --> Helper loaded: file_helper
INFO - 2024-01-19 07:25:00 --> Helper loaded: html_helper
INFO - 2024-01-19 07:25:00 --> Helper loaded: text_helper
INFO - 2024-01-19 07:25:00 --> Helper loaded: form_helper
INFO - 2024-01-19 07:25:00 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:25:00 --> Helper loaded: security_helper
INFO - 2024-01-19 07:25:00 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:25:00 --> Database Driver Class Initialized
INFO - 2024-01-19 07:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:25:00 --> Parser Class Initialized
INFO - 2024-01-19 07:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:25:00 --> Pagination Class Initialized
INFO - 2024-01-19 07:25:00 --> Form Validation Class Initialized
INFO - 2024-01-19 07:25:00 --> Controller Class Initialized
INFO - 2024-01-19 07:25:00 --> Model Class Initialized
DEBUG - 2024-01-19 07:25:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:25:00 --> Model Class Initialized
INFO - 2024-01-19 07:25:00 --> Final output sent to browser
DEBUG - 2024-01-19 07:25:00 --> Total execution time: 0.0152
ERROR - 2024-01-19 07:25:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:25:48 --> Config Class Initialized
INFO - 2024-01-19 07:25:48 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:25:48 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:25:48 --> Utf8 Class Initialized
INFO - 2024-01-19 07:25:48 --> URI Class Initialized
INFO - 2024-01-19 07:25:48 --> Router Class Initialized
INFO - 2024-01-19 07:25:48 --> Output Class Initialized
INFO - 2024-01-19 07:25:48 --> Security Class Initialized
DEBUG - 2024-01-19 07:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:25:48 --> Input Class Initialized
INFO - 2024-01-19 07:25:48 --> Language Class Initialized
INFO - 2024-01-19 07:25:48 --> Loader Class Initialized
INFO - 2024-01-19 07:25:48 --> Helper loaded: url_helper
INFO - 2024-01-19 07:25:48 --> Helper loaded: file_helper
INFO - 2024-01-19 07:25:48 --> Helper loaded: html_helper
INFO - 2024-01-19 07:25:48 --> Helper loaded: text_helper
INFO - 2024-01-19 07:25:48 --> Helper loaded: form_helper
INFO - 2024-01-19 07:25:48 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:25:48 --> Helper loaded: security_helper
INFO - 2024-01-19 07:25:48 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:25:48 --> Database Driver Class Initialized
INFO - 2024-01-19 07:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:25:48 --> Parser Class Initialized
INFO - 2024-01-19 07:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:25:48 --> Pagination Class Initialized
INFO - 2024-01-19 07:25:48 --> Form Validation Class Initialized
INFO - 2024-01-19 07:25:48 --> Controller Class Initialized
INFO - 2024-01-19 07:25:48 --> Model Class Initialized
DEBUG - 2024-01-19 07:25:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:25:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:25:48 --> Model Class Initialized
INFO - 2024-01-19 07:25:49 --> Final output sent to browser
DEBUG - 2024-01-19 07:25:49 --> Total execution time: 0.0210
ERROR - 2024-01-19 07:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:25:51 --> Config Class Initialized
INFO - 2024-01-19 07:25:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:25:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:25:51 --> Utf8 Class Initialized
INFO - 2024-01-19 07:25:51 --> URI Class Initialized
INFO - 2024-01-19 07:25:51 --> Router Class Initialized
INFO - 2024-01-19 07:25:51 --> Output Class Initialized
INFO - 2024-01-19 07:25:51 --> Security Class Initialized
DEBUG - 2024-01-19 07:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:25:51 --> Input Class Initialized
INFO - 2024-01-19 07:25:51 --> Language Class Initialized
INFO - 2024-01-19 07:25:51 --> Loader Class Initialized
INFO - 2024-01-19 07:25:51 --> Helper loaded: url_helper
INFO - 2024-01-19 07:25:51 --> Helper loaded: file_helper
INFO - 2024-01-19 07:25:51 --> Helper loaded: html_helper
INFO - 2024-01-19 07:25:51 --> Helper loaded: text_helper
INFO - 2024-01-19 07:25:51 --> Helper loaded: form_helper
INFO - 2024-01-19 07:25:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:25:51 --> Helper loaded: security_helper
INFO - 2024-01-19 07:25:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:25:51 --> Database Driver Class Initialized
INFO - 2024-01-19 07:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:25:51 --> Parser Class Initialized
INFO - 2024-01-19 07:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:25:51 --> Pagination Class Initialized
INFO - 2024-01-19 07:25:51 --> Form Validation Class Initialized
INFO - 2024-01-19 07:25:51 --> Controller Class Initialized
INFO - 2024-01-19 07:25:51 --> Model Class Initialized
DEBUG - 2024-01-19 07:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:25:51 --> Model Class Initialized
INFO - 2024-01-19 07:25:51 --> Final output sent to browser
DEBUG - 2024-01-19 07:25:51 --> Total execution time: 0.0162
ERROR - 2024-01-19 07:26:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:26:15 --> Config Class Initialized
INFO - 2024-01-19 07:26:15 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:26:15 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:26:15 --> Utf8 Class Initialized
INFO - 2024-01-19 07:26:15 --> URI Class Initialized
INFO - 2024-01-19 07:26:15 --> Router Class Initialized
INFO - 2024-01-19 07:26:15 --> Output Class Initialized
INFO - 2024-01-19 07:26:15 --> Security Class Initialized
DEBUG - 2024-01-19 07:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:26:15 --> Input Class Initialized
INFO - 2024-01-19 07:26:15 --> Language Class Initialized
INFO - 2024-01-19 07:26:15 --> Loader Class Initialized
INFO - 2024-01-19 07:26:15 --> Helper loaded: url_helper
INFO - 2024-01-19 07:26:15 --> Helper loaded: file_helper
INFO - 2024-01-19 07:26:15 --> Helper loaded: html_helper
INFO - 2024-01-19 07:26:15 --> Helper loaded: text_helper
INFO - 2024-01-19 07:26:15 --> Helper loaded: form_helper
INFO - 2024-01-19 07:26:15 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:26:15 --> Helper loaded: security_helper
INFO - 2024-01-19 07:26:15 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:26:15 --> Database Driver Class Initialized
INFO - 2024-01-19 07:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:26:15 --> Parser Class Initialized
INFO - 2024-01-19 07:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:26:15 --> Pagination Class Initialized
INFO - 2024-01-19 07:26:15 --> Form Validation Class Initialized
INFO - 2024-01-19 07:26:15 --> Controller Class Initialized
INFO - 2024-01-19 07:26:15 --> Model Class Initialized
DEBUG - 2024-01-19 07:26:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:26:15 --> Model Class Initialized
DEBUG - 2024-01-19 07:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:26:15 --> Model Class Initialized
INFO - 2024-01-19 07:26:15 --> Final output sent to browser
DEBUG - 2024-01-19 07:26:15 --> Total execution time: 0.0904
ERROR - 2024-01-19 07:26:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:26:26 --> Config Class Initialized
INFO - 2024-01-19 07:26:26 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:26:26 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:26:26 --> Utf8 Class Initialized
INFO - 2024-01-19 07:26:26 --> URI Class Initialized
INFO - 2024-01-19 07:26:26 --> Router Class Initialized
INFO - 2024-01-19 07:26:26 --> Output Class Initialized
INFO - 2024-01-19 07:26:26 --> Security Class Initialized
DEBUG - 2024-01-19 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:26:26 --> Input Class Initialized
INFO - 2024-01-19 07:26:26 --> Language Class Initialized
INFO - 2024-01-19 07:26:26 --> Loader Class Initialized
INFO - 2024-01-19 07:26:26 --> Helper loaded: url_helper
INFO - 2024-01-19 07:26:26 --> Helper loaded: file_helper
INFO - 2024-01-19 07:26:26 --> Helper loaded: html_helper
INFO - 2024-01-19 07:26:26 --> Helper loaded: text_helper
INFO - 2024-01-19 07:26:26 --> Helper loaded: form_helper
INFO - 2024-01-19 07:26:26 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:26:26 --> Helper loaded: security_helper
INFO - 2024-01-19 07:26:26 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:26:26 --> Database Driver Class Initialized
INFO - 2024-01-19 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:26:26 --> Parser Class Initialized
INFO - 2024-01-19 07:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:26:26 --> Pagination Class Initialized
INFO - 2024-01-19 07:26:26 --> Form Validation Class Initialized
INFO - 2024-01-19 07:26:26 --> Controller Class Initialized
INFO - 2024-01-19 07:26:26 --> Model Class Initialized
DEBUG - 2024-01-19 07:26:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:26:26 --> Model Class Initialized
DEBUG - 2024-01-19 07:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:26:26 --> Model Class Initialized
INFO - 2024-01-19 07:26:26 --> Final output sent to browser
DEBUG - 2024-01-19 07:26:26 --> Total execution time: 0.0948
ERROR - 2024-01-19 07:26:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:26:27 --> Config Class Initialized
INFO - 2024-01-19 07:26:27 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:26:27 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:26:27 --> Utf8 Class Initialized
INFO - 2024-01-19 07:26:27 --> URI Class Initialized
INFO - 2024-01-19 07:26:27 --> Router Class Initialized
INFO - 2024-01-19 07:26:27 --> Output Class Initialized
INFO - 2024-01-19 07:26:27 --> Security Class Initialized
DEBUG - 2024-01-19 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:26:27 --> Input Class Initialized
INFO - 2024-01-19 07:26:27 --> Language Class Initialized
INFO - 2024-01-19 07:26:27 --> Loader Class Initialized
INFO - 2024-01-19 07:26:27 --> Helper loaded: url_helper
INFO - 2024-01-19 07:26:27 --> Helper loaded: file_helper
INFO - 2024-01-19 07:26:27 --> Helper loaded: html_helper
INFO - 2024-01-19 07:26:27 --> Helper loaded: text_helper
INFO - 2024-01-19 07:26:27 --> Helper loaded: form_helper
INFO - 2024-01-19 07:26:27 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:26:27 --> Helper loaded: security_helper
INFO - 2024-01-19 07:26:27 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:26:27 --> Database Driver Class Initialized
INFO - 2024-01-19 07:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:26:27 --> Parser Class Initialized
INFO - 2024-01-19 07:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:26:27 --> Pagination Class Initialized
INFO - 2024-01-19 07:26:27 --> Form Validation Class Initialized
INFO - 2024-01-19 07:26:27 --> Controller Class Initialized
INFO - 2024-01-19 07:26:27 --> Model Class Initialized
DEBUG - 2024-01-19 07:26:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:26:27 --> Model Class Initialized
DEBUG - 2024-01-19 07:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:26:27 --> Model Class Initialized
INFO - 2024-01-19 07:26:27 --> Final output sent to browser
DEBUG - 2024-01-19 07:26:27 --> Total execution time: 0.0871
ERROR - 2024-01-19 07:30:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:34 --> Config Class Initialized
INFO - 2024-01-19 07:30:34 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:34 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:34 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:34 --> URI Class Initialized
INFO - 2024-01-19 07:30:34 --> Router Class Initialized
INFO - 2024-01-19 07:30:34 --> Output Class Initialized
INFO - 2024-01-19 07:30:34 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:34 --> Input Class Initialized
INFO - 2024-01-19 07:30:34 --> Language Class Initialized
INFO - 2024-01-19 07:30:34 --> Loader Class Initialized
INFO - 2024-01-19 07:30:34 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:34 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:34 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:34 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:34 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:34 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:34 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:34 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:34 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:34 --> Parser Class Initialized
INFO - 2024-01-19 07:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:34 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:34 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:34 --> Controller Class Initialized
INFO - 2024-01-19 07:30:34 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:34 --> Model Class Initialized
INFO - 2024-01-19 07:30:34 --> Model Class Initialized
INFO - 2024-01-19 07:30:34 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:34 --> Total execution time: 0.0253
ERROR - 2024-01-19 07:30:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:38 --> Config Class Initialized
INFO - 2024-01-19 07:30:38 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:38 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:38 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:38 --> URI Class Initialized
INFO - 2024-01-19 07:30:38 --> Router Class Initialized
INFO - 2024-01-19 07:30:38 --> Output Class Initialized
INFO - 2024-01-19 07:30:38 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:38 --> Input Class Initialized
INFO - 2024-01-19 07:30:38 --> Language Class Initialized
INFO - 2024-01-19 07:30:38 --> Loader Class Initialized
INFO - 2024-01-19 07:30:38 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:38 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:38 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:38 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:38 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:38 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:38 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:38 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:38 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:38 --> Parser Class Initialized
INFO - 2024-01-19 07:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:38 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:38 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:38 --> Controller Class Initialized
INFO - 2024-01-19 07:30:38 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:38 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:38 --> Model Class Initialized
INFO - 2024-01-19 07:30:38 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:38 --> Total execution time: 0.0184
ERROR - 2024-01-19 07:30:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:47 --> Config Class Initialized
INFO - 2024-01-19 07:30:47 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:47 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:47 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:47 --> URI Class Initialized
INFO - 2024-01-19 07:30:47 --> Router Class Initialized
INFO - 2024-01-19 07:30:47 --> Output Class Initialized
INFO - 2024-01-19 07:30:47 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:47 --> Input Class Initialized
INFO - 2024-01-19 07:30:47 --> Language Class Initialized
INFO - 2024-01-19 07:30:47 --> Loader Class Initialized
INFO - 2024-01-19 07:30:47 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:47 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:47 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:47 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:47 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:47 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:47 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:47 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:47 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:47 --> Parser Class Initialized
INFO - 2024-01-19 07:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:47 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:47 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:47 --> Controller Class Initialized
INFO - 2024-01-19 07:30:47 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:47 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:47 --> Model Class Initialized
INFO - 2024-01-19 07:30:47 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:47 --> Total execution time: 0.0935
ERROR - 2024-01-19 07:30:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:50 --> Config Class Initialized
INFO - 2024-01-19 07:30:50 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:50 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:50 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:50 --> URI Class Initialized
INFO - 2024-01-19 07:30:50 --> Router Class Initialized
INFO - 2024-01-19 07:30:50 --> Output Class Initialized
INFO - 2024-01-19 07:30:50 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:50 --> Input Class Initialized
INFO - 2024-01-19 07:30:50 --> Language Class Initialized
INFO - 2024-01-19 07:30:50 --> Loader Class Initialized
INFO - 2024-01-19 07:30:50 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:50 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:50 --> Parser Class Initialized
INFO - 2024-01-19 07:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:50 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:50 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:50 --> Controller Class Initialized
INFO - 2024-01-19 07:30:50 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:50 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:50 --> Model Class Initialized
INFO - 2024-01-19 07:30:50 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:50 --> Total execution time: 0.0883
ERROR - 2024-01-19 07:30:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:50 --> Config Class Initialized
INFO - 2024-01-19 07:30:50 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:50 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:50 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:50 --> URI Class Initialized
INFO - 2024-01-19 07:30:50 --> Router Class Initialized
INFO - 2024-01-19 07:30:50 --> Output Class Initialized
INFO - 2024-01-19 07:30:50 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:50 --> Input Class Initialized
INFO - 2024-01-19 07:30:50 --> Language Class Initialized
INFO - 2024-01-19 07:30:50 --> Loader Class Initialized
INFO - 2024-01-19 07:30:50 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:50 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:50 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:50 --> Parser Class Initialized
INFO - 2024-01-19 07:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:50 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:50 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:50 --> Controller Class Initialized
INFO - 2024-01-19 07:30:50 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:50 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:50 --> Model Class Initialized
INFO - 2024-01-19 07:30:50 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:50 --> Total execution time: 0.0926
ERROR - 2024-01-19 07:30:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:51 --> Config Class Initialized
INFO - 2024-01-19 07:30:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:51 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:51 --> URI Class Initialized
INFO - 2024-01-19 07:30:51 --> Router Class Initialized
INFO - 2024-01-19 07:30:51 --> Output Class Initialized
INFO - 2024-01-19 07:30:51 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:51 --> Input Class Initialized
INFO - 2024-01-19 07:30:51 --> Language Class Initialized
INFO - 2024-01-19 07:30:51 --> Loader Class Initialized
INFO - 2024-01-19 07:30:51 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:51 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:51 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:51 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:51 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:51 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:51 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:51 --> Parser Class Initialized
INFO - 2024-01-19 07:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:51 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:51 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:51 --> Controller Class Initialized
INFO - 2024-01-19 07:30:51 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:51 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:51 --> Model Class Initialized
INFO - 2024-01-19 07:30:51 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:51 --> Total execution time: 0.0959
ERROR - 2024-01-19 07:30:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:52 --> Config Class Initialized
INFO - 2024-01-19 07:30:52 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:52 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:52 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:52 --> URI Class Initialized
INFO - 2024-01-19 07:30:52 --> Router Class Initialized
INFO - 2024-01-19 07:30:52 --> Output Class Initialized
INFO - 2024-01-19 07:30:52 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:52 --> Input Class Initialized
INFO - 2024-01-19 07:30:52 --> Language Class Initialized
INFO - 2024-01-19 07:30:52 --> Loader Class Initialized
INFO - 2024-01-19 07:30:52 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:52 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:52 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:52 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:52 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:52 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:52 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:52 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:52 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:52 --> Parser Class Initialized
INFO - 2024-01-19 07:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:52 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:52 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:52 --> Controller Class Initialized
INFO - 2024-01-19 07:30:52 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:52 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:52 --> Model Class Initialized
INFO - 2024-01-19 07:30:52 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:52 --> Total execution time: 0.0844
ERROR - 2024-01-19 07:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:30:58 --> Config Class Initialized
INFO - 2024-01-19 07:30:58 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:30:58 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:30:58 --> Utf8 Class Initialized
INFO - 2024-01-19 07:30:58 --> URI Class Initialized
INFO - 2024-01-19 07:30:58 --> Router Class Initialized
INFO - 2024-01-19 07:30:58 --> Output Class Initialized
INFO - 2024-01-19 07:30:58 --> Security Class Initialized
DEBUG - 2024-01-19 07:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:30:58 --> Input Class Initialized
INFO - 2024-01-19 07:30:58 --> Language Class Initialized
INFO - 2024-01-19 07:30:58 --> Loader Class Initialized
INFO - 2024-01-19 07:30:58 --> Helper loaded: url_helper
INFO - 2024-01-19 07:30:58 --> Helper loaded: file_helper
INFO - 2024-01-19 07:30:58 --> Helper loaded: html_helper
INFO - 2024-01-19 07:30:58 --> Helper loaded: text_helper
INFO - 2024-01-19 07:30:58 --> Helper loaded: form_helper
INFO - 2024-01-19 07:30:58 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:30:58 --> Helper loaded: security_helper
INFO - 2024-01-19 07:30:58 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:30:58 --> Database Driver Class Initialized
INFO - 2024-01-19 07:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:30:58 --> Parser Class Initialized
INFO - 2024-01-19 07:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:30:58 --> Pagination Class Initialized
INFO - 2024-01-19 07:30:58 --> Form Validation Class Initialized
INFO - 2024-01-19 07:30:58 --> Controller Class Initialized
INFO - 2024-01-19 07:30:58 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:58 --> Model Class Initialized
DEBUG - 2024-01-19 07:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:30:58 --> Model Class Initialized
INFO - 2024-01-19 07:30:58 --> Final output sent to browser
DEBUG - 2024-01-19 07:30:58 --> Total execution time: 0.0192
ERROR - 2024-01-19 07:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:01 --> Config Class Initialized
INFO - 2024-01-19 07:31:01 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:01 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:01 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:01 --> URI Class Initialized
INFO - 2024-01-19 07:31:01 --> Router Class Initialized
INFO - 2024-01-19 07:31:01 --> Output Class Initialized
INFO - 2024-01-19 07:31:01 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:01 --> Input Class Initialized
INFO - 2024-01-19 07:31:01 --> Language Class Initialized
INFO - 2024-01-19 07:31:01 --> Loader Class Initialized
INFO - 2024-01-19 07:31:01 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:01 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:01 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:01 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:01 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:01 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:01 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:01 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:01 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:01 --> Parser Class Initialized
INFO - 2024-01-19 07:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:01 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:01 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:01 --> Controller Class Initialized
INFO - 2024-01-19 07:31:01 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:01 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:01 --> Model Class Initialized
INFO - 2024-01-19 07:31:01 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:01 --> Total execution time: 0.0186
ERROR - 2024-01-19 07:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:05 --> Config Class Initialized
INFO - 2024-01-19 07:31:05 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:05 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:05 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:05 --> URI Class Initialized
INFO - 2024-01-19 07:31:05 --> Router Class Initialized
INFO - 2024-01-19 07:31:05 --> Output Class Initialized
INFO - 2024-01-19 07:31:05 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:05 --> Input Class Initialized
INFO - 2024-01-19 07:31:05 --> Language Class Initialized
INFO - 2024-01-19 07:31:05 --> Loader Class Initialized
INFO - 2024-01-19 07:31:05 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:05 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:05 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:05 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:05 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:05 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:05 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:05 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:05 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:05 --> Parser Class Initialized
INFO - 2024-01-19 07:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:05 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:05 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:05 --> Controller Class Initialized
INFO - 2024-01-19 07:31:05 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:05 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:05 --> Model Class Initialized
INFO - 2024-01-19 07:31:05 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:05 --> Total execution time: 0.0926
ERROR - 2024-01-19 07:31:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:06 --> Config Class Initialized
INFO - 2024-01-19 07:31:06 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:06 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:06 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:06 --> URI Class Initialized
INFO - 2024-01-19 07:31:06 --> Router Class Initialized
INFO - 2024-01-19 07:31:06 --> Output Class Initialized
INFO - 2024-01-19 07:31:06 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:06 --> Input Class Initialized
INFO - 2024-01-19 07:31:06 --> Language Class Initialized
INFO - 2024-01-19 07:31:06 --> Loader Class Initialized
INFO - 2024-01-19 07:31:06 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:06 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:06 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:06 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:06 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:06 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:06 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:06 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:06 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:06 --> Parser Class Initialized
INFO - 2024-01-19 07:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:06 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:06 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:06 --> Controller Class Initialized
INFO - 2024-01-19 07:31:06 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:06 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:06 --> Model Class Initialized
INFO - 2024-01-19 07:31:06 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:06 --> Total execution time: 0.0187
ERROR - 2024-01-19 07:31:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:09 --> Config Class Initialized
INFO - 2024-01-19 07:31:09 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:09 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:09 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:09 --> URI Class Initialized
INFO - 2024-01-19 07:31:09 --> Router Class Initialized
INFO - 2024-01-19 07:31:09 --> Output Class Initialized
INFO - 2024-01-19 07:31:09 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:09 --> Input Class Initialized
INFO - 2024-01-19 07:31:09 --> Language Class Initialized
INFO - 2024-01-19 07:31:09 --> Loader Class Initialized
INFO - 2024-01-19 07:31:09 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:09 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:09 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:09 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:09 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:09 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:09 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:09 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:09 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:09 --> Parser Class Initialized
INFO - 2024-01-19 07:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:09 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:09 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:09 --> Controller Class Initialized
INFO - 2024-01-19 07:31:09 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:09 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:09 --> Model Class Initialized
INFO - 2024-01-19 07:31:09 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:09 --> Total execution time: 0.0207
ERROR - 2024-01-19 07:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:10 --> Config Class Initialized
INFO - 2024-01-19 07:31:10 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:10 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:10 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:10 --> URI Class Initialized
INFO - 2024-01-19 07:31:10 --> Router Class Initialized
INFO - 2024-01-19 07:31:10 --> Output Class Initialized
INFO - 2024-01-19 07:31:10 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:10 --> Input Class Initialized
INFO - 2024-01-19 07:31:10 --> Language Class Initialized
INFO - 2024-01-19 07:31:10 --> Loader Class Initialized
INFO - 2024-01-19 07:31:10 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:10 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:10 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:10 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:10 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:10 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:10 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:10 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:10 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:10 --> Parser Class Initialized
INFO - 2024-01-19 07:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:10 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:10 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:10 --> Controller Class Initialized
INFO - 2024-01-19 07:31:10 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:10 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:10 --> Model Class Initialized
INFO - 2024-01-19 07:31:10 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:10 --> Total execution time: 0.0182
ERROR - 2024-01-19 07:31:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:11 --> Config Class Initialized
INFO - 2024-01-19 07:31:11 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:11 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:11 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:11 --> URI Class Initialized
INFO - 2024-01-19 07:31:11 --> Router Class Initialized
INFO - 2024-01-19 07:31:11 --> Output Class Initialized
INFO - 2024-01-19 07:31:11 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:11 --> Input Class Initialized
INFO - 2024-01-19 07:31:11 --> Language Class Initialized
INFO - 2024-01-19 07:31:11 --> Loader Class Initialized
INFO - 2024-01-19 07:31:11 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:11 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:11 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:11 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:11 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:11 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:11 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:11 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:11 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:11 --> Parser Class Initialized
INFO - 2024-01-19 07:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:11 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:11 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:11 --> Controller Class Initialized
INFO - 2024-01-19 07:31:11 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:11 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:11 --> Model Class Initialized
INFO - 2024-01-19 07:31:11 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:11 --> Total execution time: 0.1028
ERROR - 2024-01-19 07:31:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:16 --> Config Class Initialized
INFO - 2024-01-19 07:31:16 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:16 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:16 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:16 --> URI Class Initialized
INFO - 2024-01-19 07:31:16 --> Router Class Initialized
INFO - 2024-01-19 07:31:16 --> Output Class Initialized
INFO - 2024-01-19 07:31:16 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:16 --> Input Class Initialized
INFO - 2024-01-19 07:31:16 --> Language Class Initialized
INFO - 2024-01-19 07:31:16 --> Loader Class Initialized
INFO - 2024-01-19 07:31:16 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:16 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:16 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:16 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:16 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:16 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:16 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:16 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:16 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:16 --> Parser Class Initialized
INFO - 2024-01-19 07:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:16 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:16 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:16 --> Controller Class Initialized
INFO - 2024-01-19 07:31:16 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:16 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:16 --> Model Class Initialized
INFO - 2024-01-19 07:31:16 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:16 --> Total execution time: 0.0250
ERROR - 2024-01-19 07:31:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:19 --> Config Class Initialized
INFO - 2024-01-19 07:31:19 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:19 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:19 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:19 --> URI Class Initialized
INFO - 2024-01-19 07:31:19 --> Router Class Initialized
INFO - 2024-01-19 07:31:19 --> Output Class Initialized
INFO - 2024-01-19 07:31:19 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:19 --> Input Class Initialized
INFO - 2024-01-19 07:31:19 --> Language Class Initialized
INFO - 2024-01-19 07:31:19 --> Loader Class Initialized
INFO - 2024-01-19 07:31:19 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:19 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:19 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:19 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:19 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:19 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:19 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:19 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:19 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:19 --> Parser Class Initialized
INFO - 2024-01-19 07:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:19 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:19 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:19 --> Controller Class Initialized
INFO - 2024-01-19 07:31:19 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:19 --> Model Class Initialized
INFO - 2024-01-19 07:31:19 --> Model Class Initialized
INFO - 2024-01-19 07:31:19 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:19 --> Total execution time: 0.0198
ERROR - 2024-01-19 07:31:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:31:27 --> Config Class Initialized
INFO - 2024-01-19 07:31:27 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:31:27 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:31:27 --> Utf8 Class Initialized
INFO - 2024-01-19 07:31:27 --> URI Class Initialized
INFO - 2024-01-19 07:31:27 --> Router Class Initialized
INFO - 2024-01-19 07:31:27 --> Output Class Initialized
INFO - 2024-01-19 07:31:27 --> Security Class Initialized
DEBUG - 2024-01-19 07:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:31:27 --> Input Class Initialized
INFO - 2024-01-19 07:31:27 --> Language Class Initialized
INFO - 2024-01-19 07:31:27 --> Loader Class Initialized
INFO - 2024-01-19 07:31:27 --> Helper loaded: url_helper
INFO - 2024-01-19 07:31:27 --> Helper loaded: file_helper
INFO - 2024-01-19 07:31:27 --> Helper loaded: html_helper
INFO - 2024-01-19 07:31:27 --> Helper loaded: text_helper
INFO - 2024-01-19 07:31:27 --> Helper loaded: form_helper
INFO - 2024-01-19 07:31:27 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:31:27 --> Helper loaded: security_helper
INFO - 2024-01-19 07:31:27 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:31:27 --> Database Driver Class Initialized
INFO - 2024-01-19 07:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:31:27 --> Parser Class Initialized
INFO - 2024-01-19 07:31:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:31:27 --> Pagination Class Initialized
INFO - 2024-01-19 07:31:27 --> Form Validation Class Initialized
INFO - 2024-01-19 07:31:27 --> Controller Class Initialized
INFO - 2024-01-19 07:31:27 --> Model Class Initialized
DEBUG - 2024-01-19 07:31:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:31:27 --> Model Class Initialized
INFO - 2024-01-19 07:31:27 --> Final output sent to browser
DEBUG - 2024-01-19 07:31:27 --> Total execution time: 0.0156
ERROR - 2024-01-19 07:32:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:32:15 --> Config Class Initialized
INFO - 2024-01-19 07:32:15 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:32:15 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:32:15 --> Utf8 Class Initialized
INFO - 2024-01-19 07:32:15 --> URI Class Initialized
INFO - 2024-01-19 07:32:15 --> Router Class Initialized
INFO - 2024-01-19 07:32:15 --> Output Class Initialized
INFO - 2024-01-19 07:32:15 --> Security Class Initialized
DEBUG - 2024-01-19 07:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:32:15 --> Input Class Initialized
INFO - 2024-01-19 07:32:15 --> Language Class Initialized
INFO - 2024-01-19 07:32:15 --> Loader Class Initialized
INFO - 2024-01-19 07:32:15 --> Helper loaded: url_helper
INFO - 2024-01-19 07:32:15 --> Helper loaded: file_helper
INFO - 2024-01-19 07:32:15 --> Helper loaded: html_helper
INFO - 2024-01-19 07:32:15 --> Helper loaded: text_helper
INFO - 2024-01-19 07:32:15 --> Helper loaded: form_helper
INFO - 2024-01-19 07:32:15 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:32:15 --> Helper loaded: security_helper
INFO - 2024-01-19 07:32:15 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:32:15 --> Database Driver Class Initialized
INFO - 2024-01-19 07:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:32:15 --> Parser Class Initialized
INFO - 2024-01-19 07:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:32:15 --> Pagination Class Initialized
INFO - 2024-01-19 07:32:15 --> Form Validation Class Initialized
INFO - 2024-01-19 07:32:15 --> Controller Class Initialized
INFO - 2024-01-19 07:32:15 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:15 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:15 --> Model Class Initialized
INFO - 2024-01-19 07:32:15 --> Email Class Initialized
DEBUG - 2024-01-19 07:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-19 07:32:15 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-01-19 07:32:15 --> Language file loaded: language/english/email_lang.php
INFO - 2024-01-19 07:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-01-19 07:32:15 --> Final output sent to browser
DEBUG - 2024-01-19 07:32:15 --> Total execution time: 0.2477
ERROR - 2024-01-19 07:32:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:32:23 --> Config Class Initialized
INFO - 2024-01-19 07:32:23 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:32:23 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:32:23 --> Utf8 Class Initialized
INFO - 2024-01-19 07:32:23 --> URI Class Initialized
INFO - 2024-01-19 07:32:23 --> Router Class Initialized
INFO - 2024-01-19 07:32:23 --> Output Class Initialized
INFO - 2024-01-19 07:32:23 --> Security Class Initialized
DEBUG - 2024-01-19 07:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:32:23 --> Input Class Initialized
INFO - 2024-01-19 07:32:23 --> Language Class Initialized
INFO - 2024-01-19 07:32:23 --> Loader Class Initialized
INFO - 2024-01-19 07:32:23 --> Helper loaded: url_helper
INFO - 2024-01-19 07:32:23 --> Helper loaded: file_helper
INFO - 2024-01-19 07:32:23 --> Helper loaded: html_helper
INFO - 2024-01-19 07:32:23 --> Helper loaded: text_helper
INFO - 2024-01-19 07:32:23 --> Helper loaded: form_helper
INFO - 2024-01-19 07:32:23 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:32:23 --> Helper loaded: security_helper
INFO - 2024-01-19 07:32:23 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:32:23 --> Database Driver Class Initialized
INFO - 2024-01-19 07:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:32:23 --> Parser Class Initialized
INFO - 2024-01-19 07:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:32:23 --> Pagination Class Initialized
INFO - 2024-01-19 07:32:23 --> Form Validation Class Initialized
INFO - 2024-01-19 07:32:23 --> Controller Class Initialized
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
INFO - 2024-01-19 07:32:23 --> Model Class Initialized
INFO - 2024-01-19 07:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 07:32:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:32:24 --> Model Class Initialized
INFO - 2024-01-19 07:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:32:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:32:24 --> Final output sent to browser
DEBUG - 2024-01-19 07:32:24 --> Total execution time: 0.2322
ERROR - 2024-01-19 07:32:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:32:54 --> Config Class Initialized
INFO - 2024-01-19 07:32:54 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:32:54 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:32:54 --> Utf8 Class Initialized
INFO - 2024-01-19 07:32:54 --> URI Class Initialized
INFO - 2024-01-19 07:32:54 --> Router Class Initialized
INFO - 2024-01-19 07:32:54 --> Output Class Initialized
INFO - 2024-01-19 07:32:54 --> Security Class Initialized
DEBUG - 2024-01-19 07:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:32:54 --> Input Class Initialized
INFO - 2024-01-19 07:32:54 --> Language Class Initialized
INFO - 2024-01-19 07:32:54 --> Loader Class Initialized
INFO - 2024-01-19 07:32:54 --> Helper loaded: url_helper
INFO - 2024-01-19 07:32:54 --> Helper loaded: file_helper
INFO - 2024-01-19 07:32:54 --> Helper loaded: html_helper
INFO - 2024-01-19 07:32:54 --> Helper loaded: text_helper
INFO - 2024-01-19 07:32:54 --> Helper loaded: form_helper
INFO - 2024-01-19 07:32:54 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:32:54 --> Helper loaded: security_helper
INFO - 2024-01-19 07:32:54 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:32:54 --> Database Driver Class Initialized
INFO - 2024-01-19 07:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:32:54 --> Parser Class Initialized
INFO - 2024-01-19 07:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:32:54 --> Pagination Class Initialized
INFO - 2024-01-19 07:32:54 --> Form Validation Class Initialized
INFO - 2024-01-19 07:32:54 --> Controller Class Initialized
INFO - 2024-01-19 07:32:54 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:54 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:54 --> Model Class Initialized
INFO - 2024-01-19 07:32:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-19 07:32:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:32:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:32:54 --> Model Class Initialized
INFO - 2024-01-19 07:32:54 --> Model Class Initialized
INFO - 2024-01-19 07:32:54 --> Model Class Initialized
INFO - 2024-01-19 07:32:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:32:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:32:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:32:54 --> Final output sent to browser
DEBUG - 2024-01-19 07:32:54 --> Total execution time: 0.1517
ERROR - 2024-01-19 07:32:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:32:55 --> Config Class Initialized
INFO - 2024-01-19 07:32:55 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:32:55 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:32:55 --> Utf8 Class Initialized
INFO - 2024-01-19 07:32:55 --> URI Class Initialized
INFO - 2024-01-19 07:32:55 --> Router Class Initialized
INFO - 2024-01-19 07:32:55 --> Output Class Initialized
INFO - 2024-01-19 07:32:55 --> Security Class Initialized
DEBUG - 2024-01-19 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:32:55 --> Input Class Initialized
INFO - 2024-01-19 07:32:55 --> Language Class Initialized
INFO - 2024-01-19 07:32:55 --> Loader Class Initialized
INFO - 2024-01-19 07:32:55 --> Helper loaded: url_helper
INFO - 2024-01-19 07:32:55 --> Helper loaded: file_helper
INFO - 2024-01-19 07:32:55 --> Helper loaded: html_helper
INFO - 2024-01-19 07:32:55 --> Helper loaded: text_helper
INFO - 2024-01-19 07:32:55 --> Helper loaded: form_helper
INFO - 2024-01-19 07:32:55 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:32:55 --> Helper loaded: security_helper
INFO - 2024-01-19 07:32:55 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:32:55 --> Database Driver Class Initialized
INFO - 2024-01-19 07:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:32:55 --> Parser Class Initialized
INFO - 2024-01-19 07:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:32:55 --> Pagination Class Initialized
INFO - 2024-01-19 07:32:55 --> Form Validation Class Initialized
INFO - 2024-01-19 07:32:55 --> Controller Class Initialized
INFO - 2024-01-19 07:32:55 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:55 --> Model Class Initialized
DEBUG - 2024-01-19 07:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:32:55 --> Model Class Initialized
INFO - 2024-01-19 07:32:55 --> Final output sent to browser
DEBUG - 2024-01-19 07:32:55 --> Total execution time: 0.0475
ERROR - 2024-01-19 07:33:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:33:04 --> Config Class Initialized
INFO - 2024-01-19 07:33:04 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:33:04 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:33:04 --> Utf8 Class Initialized
INFO - 2024-01-19 07:33:04 --> URI Class Initialized
INFO - 2024-01-19 07:33:04 --> Router Class Initialized
INFO - 2024-01-19 07:33:04 --> Output Class Initialized
INFO - 2024-01-19 07:33:04 --> Security Class Initialized
DEBUG - 2024-01-19 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:33:04 --> Input Class Initialized
INFO - 2024-01-19 07:33:04 --> Language Class Initialized
INFO - 2024-01-19 07:33:04 --> Loader Class Initialized
INFO - 2024-01-19 07:33:04 --> Helper loaded: url_helper
INFO - 2024-01-19 07:33:04 --> Helper loaded: file_helper
INFO - 2024-01-19 07:33:04 --> Helper loaded: html_helper
INFO - 2024-01-19 07:33:04 --> Helper loaded: text_helper
INFO - 2024-01-19 07:33:04 --> Helper loaded: form_helper
INFO - 2024-01-19 07:33:04 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:33:04 --> Helper loaded: security_helper
INFO - 2024-01-19 07:33:04 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:33:04 --> Database Driver Class Initialized
INFO - 2024-01-19 07:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:33:04 --> Parser Class Initialized
INFO - 2024-01-19 07:33:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:33:04 --> Pagination Class Initialized
INFO - 2024-01-19 07:33:04 --> Form Validation Class Initialized
INFO - 2024-01-19 07:33:04 --> Controller Class Initialized
INFO - 2024-01-19 07:33:04 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:04 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:04 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-19 07:33:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:33:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:33:04 --> Model Class Initialized
INFO - 2024-01-19 07:33:04 --> Model Class Initialized
INFO - 2024-01-19 07:33:04 --> Model Class Initialized
INFO - 2024-01-19 07:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:33:05 --> Final output sent to browser
DEBUG - 2024-01-19 07:33:05 --> Total execution time: 0.2397
ERROR - 2024-01-19 07:33:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:33:12 --> Config Class Initialized
INFO - 2024-01-19 07:33:12 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:33:12 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:33:12 --> Utf8 Class Initialized
INFO - 2024-01-19 07:33:12 --> URI Class Initialized
INFO - 2024-01-19 07:33:12 --> Router Class Initialized
INFO - 2024-01-19 07:33:12 --> Output Class Initialized
INFO - 2024-01-19 07:33:12 --> Security Class Initialized
DEBUG - 2024-01-19 07:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:33:12 --> Input Class Initialized
INFO - 2024-01-19 07:33:12 --> Language Class Initialized
INFO - 2024-01-19 07:33:12 --> Loader Class Initialized
INFO - 2024-01-19 07:33:12 --> Helper loaded: url_helper
INFO - 2024-01-19 07:33:12 --> Helper loaded: file_helper
INFO - 2024-01-19 07:33:12 --> Helper loaded: html_helper
INFO - 2024-01-19 07:33:12 --> Helper loaded: text_helper
INFO - 2024-01-19 07:33:12 --> Helper loaded: form_helper
INFO - 2024-01-19 07:33:12 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:33:12 --> Helper loaded: security_helper
INFO - 2024-01-19 07:33:12 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:33:12 --> Database Driver Class Initialized
INFO - 2024-01-19 07:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:33:12 --> Parser Class Initialized
INFO - 2024-01-19 07:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:33:12 --> Pagination Class Initialized
INFO - 2024-01-19 07:33:12 --> Form Validation Class Initialized
INFO - 2024-01-19 07:33:12 --> Controller Class Initialized
INFO - 2024-01-19 07:33:12 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:12 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:12 --> Model Class Initialized
INFO - 2024-01-19 07:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-19 07:33:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:33:12 --> Model Class Initialized
INFO - 2024-01-19 07:33:12 --> Model Class Initialized
INFO - 2024-01-19 07:33:12 --> Model Class Initialized
INFO - 2024-01-19 07:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:33:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:33:12 --> Final output sent to browser
DEBUG - 2024-01-19 07:33:12 --> Total execution time: 0.1578
ERROR - 2024-01-19 07:33:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:33:13 --> Config Class Initialized
INFO - 2024-01-19 07:33:13 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:33:13 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:33:13 --> Utf8 Class Initialized
INFO - 2024-01-19 07:33:13 --> URI Class Initialized
INFO - 2024-01-19 07:33:13 --> Router Class Initialized
INFO - 2024-01-19 07:33:13 --> Output Class Initialized
INFO - 2024-01-19 07:33:13 --> Security Class Initialized
DEBUG - 2024-01-19 07:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:33:13 --> Input Class Initialized
INFO - 2024-01-19 07:33:13 --> Language Class Initialized
INFO - 2024-01-19 07:33:13 --> Loader Class Initialized
INFO - 2024-01-19 07:33:13 --> Helper loaded: url_helper
INFO - 2024-01-19 07:33:13 --> Helper loaded: file_helper
INFO - 2024-01-19 07:33:13 --> Helper loaded: html_helper
INFO - 2024-01-19 07:33:13 --> Helper loaded: text_helper
INFO - 2024-01-19 07:33:13 --> Helper loaded: form_helper
INFO - 2024-01-19 07:33:13 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:33:13 --> Helper loaded: security_helper
INFO - 2024-01-19 07:33:13 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:33:13 --> Database Driver Class Initialized
INFO - 2024-01-19 07:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:33:13 --> Parser Class Initialized
INFO - 2024-01-19 07:33:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:33:13 --> Pagination Class Initialized
INFO - 2024-01-19 07:33:13 --> Form Validation Class Initialized
INFO - 2024-01-19 07:33:13 --> Controller Class Initialized
INFO - 2024-01-19 07:33:13 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:13 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:13 --> Model Class Initialized
INFO - 2024-01-19 07:33:13 --> Final output sent to browser
DEBUG - 2024-01-19 07:33:13 --> Total execution time: 0.0430
ERROR - 2024-01-19 07:33:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:33:29 --> Config Class Initialized
INFO - 2024-01-19 07:33:29 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:33:29 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:33:29 --> Utf8 Class Initialized
INFO - 2024-01-19 07:33:29 --> URI Class Initialized
INFO - 2024-01-19 07:33:29 --> Router Class Initialized
INFO - 2024-01-19 07:33:29 --> Output Class Initialized
INFO - 2024-01-19 07:33:29 --> Security Class Initialized
DEBUG - 2024-01-19 07:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:33:29 --> Input Class Initialized
INFO - 2024-01-19 07:33:29 --> Language Class Initialized
INFO - 2024-01-19 07:33:29 --> Loader Class Initialized
INFO - 2024-01-19 07:33:29 --> Helper loaded: url_helper
INFO - 2024-01-19 07:33:29 --> Helper loaded: file_helper
INFO - 2024-01-19 07:33:29 --> Helper loaded: html_helper
INFO - 2024-01-19 07:33:29 --> Helper loaded: text_helper
INFO - 2024-01-19 07:33:29 --> Helper loaded: form_helper
INFO - 2024-01-19 07:33:29 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:33:29 --> Helper loaded: security_helper
INFO - 2024-01-19 07:33:29 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:33:29 --> Database Driver Class Initialized
INFO - 2024-01-19 07:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:33:29 --> Parser Class Initialized
INFO - 2024-01-19 07:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:33:29 --> Pagination Class Initialized
INFO - 2024-01-19 07:33:29 --> Form Validation Class Initialized
INFO - 2024-01-19 07:33:29 --> Controller Class Initialized
INFO - 2024-01-19 07:33:29 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:29 --> Model Class Initialized
DEBUG - 2024-01-19 07:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:33:29 --> Model Class Initialized
INFO - 2024-01-19 07:33:29 --> Final output sent to browser
DEBUG - 2024-01-19 07:33:29 --> Total execution time: 0.1220
ERROR - 2024-01-19 07:34:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:34:08 --> Config Class Initialized
INFO - 2024-01-19 07:34:08 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:34:08 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:34:08 --> Utf8 Class Initialized
INFO - 2024-01-19 07:34:08 --> URI Class Initialized
INFO - 2024-01-19 07:34:08 --> Router Class Initialized
INFO - 2024-01-19 07:34:08 --> Output Class Initialized
INFO - 2024-01-19 07:34:08 --> Security Class Initialized
DEBUG - 2024-01-19 07:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:34:08 --> Input Class Initialized
INFO - 2024-01-19 07:34:08 --> Language Class Initialized
INFO - 2024-01-19 07:34:08 --> Loader Class Initialized
INFO - 2024-01-19 07:34:08 --> Helper loaded: url_helper
INFO - 2024-01-19 07:34:08 --> Helper loaded: file_helper
INFO - 2024-01-19 07:34:08 --> Helper loaded: html_helper
INFO - 2024-01-19 07:34:08 --> Helper loaded: text_helper
INFO - 2024-01-19 07:34:08 --> Helper loaded: form_helper
INFO - 2024-01-19 07:34:08 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:34:08 --> Helper loaded: security_helper
INFO - 2024-01-19 07:34:08 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:34:08 --> Database Driver Class Initialized
INFO - 2024-01-19 07:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:34:08 --> Parser Class Initialized
INFO - 2024-01-19 07:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:34:08 --> Pagination Class Initialized
INFO - 2024-01-19 07:34:08 --> Form Validation Class Initialized
INFO - 2024-01-19 07:34:08 --> Controller Class Initialized
INFO - 2024-01-19 07:34:08 --> Model Class Initialized
DEBUG - 2024-01-19 07:34:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:08 --> Model Class Initialized
DEBUG - 2024-01-19 07:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:08 --> Model Class Initialized
DEBUG - 2024-01-19 07:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-19 07:34:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:34:08 --> Model Class Initialized
INFO - 2024-01-19 07:34:08 --> Model Class Initialized
INFO - 2024-01-19 07:34:08 --> Model Class Initialized
INFO - 2024-01-19 07:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:34:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:34:08 --> Final output sent to browser
DEBUG - 2024-01-19 07:34:08 --> Total execution time: 0.1578
ERROR - 2024-01-19 07:34:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 07:34:46 --> Config Class Initialized
INFO - 2024-01-19 07:34:46 --> Hooks Class Initialized
DEBUG - 2024-01-19 07:34:46 --> UTF-8 Support Enabled
INFO - 2024-01-19 07:34:46 --> Utf8 Class Initialized
INFO - 2024-01-19 07:34:46 --> URI Class Initialized
INFO - 2024-01-19 07:34:46 --> Router Class Initialized
INFO - 2024-01-19 07:34:46 --> Output Class Initialized
INFO - 2024-01-19 07:34:46 --> Security Class Initialized
DEBUG - 2024-01-19 07:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 07:34:46 --> Input Class Initialized
INFO - 2024-01-19 07:34:46 --> Language Class Initialized
INFO - 2024-01-19 07:34:46 --> Loader Class Initialized
INFO - 2024-01-19 07:34:46 --> Helper loaded: url_helper
INFO - 2024-01-19 07:34:46 --> Helper loaded: file_helper
INFO - 2024-01-19 07:34:46 --> Helper loaded: html_helper
INFO - 2024-01-19 07:34:46 --> Helper loaded: text_helper
INFO - 2024-01-19 07:34:46 --> Helper loaded: form_helper
INFO - 2024-01-19 07:34:46 --> Helper loaded: lang_helper
INFO - 2024-01-19 07:34:46 --> Helper loaded: security_helper
INFO - 2024-01-19 07:34:46 --> Helper loaded: cookie_helper
INFO - 2024-01-19 07:34:46 --> Database Driver Class Initialized
INFO - 2024-01-19 07:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 07:34:46 --> Parser Class Initialized
INFO - 2024-01-19 07:34:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 07:34:46 --> Pagination Class Initialized
INFO - 2024-01-19 07:34:46 --> Form Validation Class Initialized
INFO - 2024-01-19 07:34:46 --> Controller Class Initialized
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
DEBUG - 2024-01-19 07:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
DEBUG - 2024-01-19 07:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
DEBUG - 2024-01-19 07:34:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 07:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
INFO - 2024-01-19 07:34:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 07:34:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 07:34:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 07:34:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 07:34:46 --> Model Class Initialized
INFO - 2024-01-19 07:34:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 07:34:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 07:34:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 07:34:46 --> Final output sent to browser
DEBUG - 2024-01-19 07:34:46 --> Total execution time: 0.2311
ERROR - 2024-01-19 08:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 08:10:51 --> Config Class Initialized
INFO - 2024-01-19 08:10:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 08:10:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 08:10:51 --> Utf8 Class Initialized
INFO - 2024-01-19 08:10:51 --> URI Class Initialized
DEBUG - 2024-01-19 08:10:51 --> No URI present. Default controller set.
INFO - 2024-01-19 08:10:51 --> Router Class Initialized
INFO - 2024-01-19 08:10:51 --> Output Class Initialized
INFO - 2024-01-19 08:10:51 --> Security Class Initialized
DEBUG - 2024-01-19 08:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 08:10:51 --> Input Class Initialized
INFO - 2024-01-19 08:10:51 --> Language Class Initialized
INFO - 2024-01-19 08:10:51 --> Loader Class Initialized
INFO - 2024-01-19 08:10:51 --> Helper loaded: url_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: file_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: html_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: text_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: form_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: security_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 08:10:51 --> Database Driver Class Initialized
INFO - 2024-01-19 08:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 08:10:51 --> Parser Class Initialized
INFO - 2024-01-19 08:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 08:10:51 --> Pagination Class Initialized
INFO - 2024-01-19 08:10:51 --> Form Validation Class Initialized
INFO - 2024-01-19 08:10:51 --> Controller Class Initialized
INFO - 2024-01-19 08:10:51 --> Model Class Initialized
DEBUG - 2024-01-19 08:10:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 08:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 08:10:51 --> Config Class Initialized
INFO - 2024-01-19 08:10:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 08:10:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 08:10:51 --> Utf8 Class Initialized
INFO - 2024-01-19 08:10:51 --> URI Class Initialized
INFO - 2024-01-19 08:10:51 --> Router Class Initialized
INFO - 2024-01-19 08:10:51 --> Output Class Initialized
INFO - 2024-01-19 08:10:51 --> Security Class Initialized
DEBUG - 2024-01-19 08:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 08:10:51 --> Input Class Initialized
INFO - 2024-01-19 08:10:51 --> Language Class Initialized
INFO - 2024-01-19 08:10:51 --> Loader Class Initialized
INFO - 2024-01-19 08:10:51 --> Helper loaded: url_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: file_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: html_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: text_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: form_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: security_helper
INFO - 2024-01-19 08:10:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 08:10:51 --> Database Driver Class Initialized
INFO - 2024-01-19 08:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 08:10:51 --> Parser Class Initialized
INFO - 2024-01-19 08:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 08:10:51 --> Pagination Class Initialized
INFO - 2024-01-19 08:10:51 --> Form Validation Class Initialized
INFO - 2024-01-19 08:10:51 --> Controller Class Initialized
INFO - 2024-01-19 08:10:51 --> Model Class Initialized
DEBUG - 2024-01-19 08:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 08:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-19 08:10:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 08:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 08:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 08:10:51 --> Model Class Initialized
INFO - 2024-01-19 08:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 08:10:51 --> Final output sent to browser
DEBUG - 2024-01-19 08:10:51 --> Total execution time: 0.0310
ERROR - 2024-01-19 09:11:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:11:53 --> Config Class Initialized
INFO - 2024-01-19 09:11:53 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:11:53 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:11:53 --> Utf8 Class Initialized
INFO - 2024-01-19 09:11:53 --> URI Class Initialized
DEBUG - 2024-01-19 09:11:53 --> No URI present. Default controller set.
INFO - 2024-01-19 09:11:53 --> Router Class Initialized
INFO - 2024-01-19 09:11:53 --> Output Class Initialized
INFO - 2024-01-19 09:11:53 --> Security Class Initialized
DEBUG - 2024-01-19 09:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:11:53 --> Input Class Initialized
INFO - 2024-01-19 09:11:53 --> Language Class Initialized
INFO - 2024-01-19 09:11:53 --> Loader Class Initialized
INFO - 2024-01-19 09:11:53 --> Helper loaded: url_helper
INFO - 2024-01-19 09:11:53 --> Helper loaded: file_helper
INFO - 2024-01-19 09:11:53 --> Helper loaded: html_helper
INFO - 2024-01-19 09:11:53 --> Helper loaded: text_helper
INFO - 2024-01-19 09:11:53 --> Helper loaded: form_helper
INFO - 2024-01-19 09:11:53 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:11:53 --> Helper loaded: security_helper
INFO - 2024-01-19 09:11:53 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:11:53 --> Database Driver Class Initialized
INFO - 2024-01-19 09:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:11:53 --> Parser Class Initialized
INFO - 2024-01-19 09:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:11:53 --> Pagination Class Initialized
INFO - 2024-01-19 09:11:53 --> Form Validation Class Initialized
INFO - 2024-01-19 09:11:53 --> Controller Class Initialized
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
DEBUG - 2024-01-19 09:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
DEBUG - 2024-01-19 09:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
DEBUG - 2024-01-19 09:11:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 09:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
INFO - 2024-01-19 09:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 09:11:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 09:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 09:11:53 --> Model Class Initialized
INFO - 2024-01-19 09:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 09:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 09:11:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 09:11:53 --> Final output sent to browser
DEBUG - 2024-01-19 09:11:53 --> Total execution time: 0.2312
ERROR - 2024-01-19 09:12:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:12:00 --> Config Class Initialized
INFO - 2024-01-19 09:12:00 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:12:00 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:12:00 --> Utf8 Class Initialized
INFO - 2024-01-19 09:12:00 --> URI Class Initialized
INFO - 2024-01-19 09:12:00 --> Router Class Initialized
INFO - 2024-01-19 09:12:00 --> Output Class Initialized
INFO - 2024-01-19 09:12:00 --> Security Class Initialized
DEBUG - 2024-01-19 09:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:12:00 --> Input Class Initialized
INFO - 2024-01-19 09:12:00 --> Language Class Initialized
INFO - 2024-01-19 09:12:00 --> Loader Class Initialized
INFO - 2024-01-19 09:12:00 --> Helper loaded: url_helper
INFO - 2024-01-19 09:12:00 --> Helper loaded: file_helper
INFO - 2024-01-19 09:12:00 --> Helper loaded: html_helper
INFO - 2024-01-19 09:12:00 --> Helper loaded: text_helper
INFO - 2024-01-19 09:12:00 --> Helper loaded: form_helper
INFO - 2024-01-19 09:12:00 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:12:00 --> Helper loaded: security_helper
INFO - 2024-01-19 09:12:00 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:12:00 --> Database Driver Class Initialized
INFO - 2024-01-19 09:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:12:00 --> Parser Class Initialized
INFO - 2024-01-19 09:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:12:00 --> Pagination Class Initialized
INFO - 2024-01-19 09:12:00 --> Form Validation Class Initialized
INFO - 2024-01-19 09:12:00 --> Controller Class Initialized
INFO - 2024-01-19 09:12:00 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 09:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:00 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:00 --> Model Class Initialized
INFO - 2024-01-19 09:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-19 09:12:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 09:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 09:12:00 --> Model Class Initialized
INFO - 2024-01-19 09:12:00 --> Model Class Initialized
INFO - 2024-01-19 09:12:00 --> Model Class Initialized
INFO - 2024-01-19 09:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 09:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 09:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 09:12:00 --> Final output sent to browser
DEBUG - 2024-01-19 09:12:00 --> Total execution time: 0.1394
ERROR - 2024-01-19 09:12:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:12:01 --> Config Class Initialized
INFO - 2024-01-19 09:12:01 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:12:01 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:12:01 --> Utf8 Class Initialized
INFO - 2024-01-19 09:12:01 --> URI Class Initialized
INFO - 2024-01-19 09:12:01 --> Router Class Initialized
INFO - 2024-01-19 09:12:01 --> Output Class Initialized
INFO - 2024-01-19 09:12:01 --> Security Class Initialized
DEBUG - 2024-01-19 09:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:12:01 --> Input Class Initialized
INFO - 2024-01-19 09:12:01 --> Language Class Initialized
INFO - 2024-01-19 09:12:01 --> Loader Class Initialized
INFO - 2024-01-19 09:12:01 --> Helper loaded: url_helper
INFO - 2024-01-19 09:12:01 --> Helper loaded: file_helper
INFO - 2024-01-19 09:12:01 --> Helper loaded: html_helper
INFO - 2024-01-19 09:12:01 --> Helper loaded: text_helper
INFO - 2024-01-19 09:12:01 --> Helper loaded: form_helper
INFO - 2024-01-19 09:12:01 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:12:01 --> Helper loaded: security_helper
INFO - 2024-01-19 09:12:01 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:12:01 --> Database Driver Class Initialized
INFO - 2024-01-19 09:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:12:01 --> Parser Class Initialized
INFO - 2024-01-19 09:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:12:01 --> Pagination Class Initialized
INFO - 2024-01-19 09:12:01 --> Form Validation Class Initialized
INFO - 2024-01-19 09:12:01 --> Controller Class Initialized
INFO - 2024-01-19 09:12:01 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 09:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:01 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:01 --> Model Class Initialized
INFO - 2024-01-19 09:12:01 --> Final output sent to browser
DEBUG - 2024-01-19 09:12:01 --> Total execution time: 0.0414
ERROR - 2024-01-19 09:12:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:12:04 --> Config Class Initialized
INFO - 2024-01-19 09:12:04 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:12:04 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:12:04 --> Utf8 Class Initialized
INFO - 2024-01-19 09:12:04 --> URI Class Initialized
INFO - 2024-01-19 09:12:04 --> Router Class Initialized
INFO - 2024-01-19 09:12:04 --> Output Class Initialized
INFO - 2024-01-19 09:12:04 --> Security Class Initialized
DEBUG - 2024-01-19 09:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:12:04 --> Input Class Initialized
INFO - 2024-01-19 09:12:04 --> Language Class Initialized
INFO - 2024-01-19 09:12:04 --> Loader Class Initialized
INFO - 2024-01-19 09:12:04 --> Helper loaded: url_helper
INFO - 2024-01-19 09:12:04 --> Helper loaded: file_helper
INFO - 2024-01-19 09:12:04 --> Helper loaded: html_helper
INFO - 2024-01-19 09:12:04 --> Helper loaded: text_helper
INFO - 2024-01-19 09:12:04 --> Helper loaded: form_helper
INFO - 2024-01-19 09:12:04 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:12:04 --> Helper loaded: security_helper
INFO - 2024-01-19 09:12:04 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:12:04 --> Database Driver Class Initialized
INFO - 2024-01-19 09:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:12:04 --> Parser Class Initialized
INFO - 2024-01-19 09:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:12:04 --> Pagination Class Initialized
INFO - 2024-01-19 09:12:04 --> Form Validation Class Initialized
INFO - 2024-01-19 09:12:04 --> Controller Class Initialized
INFO - 2024-01-19 09:12:04 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 09:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:04 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:04 --> Model Class Initialized
INFO - 2024-01-19 09:12:04 --> Final output sent to browser
DEBUG - 2024-01-19 09:12:04 --> Total execution time: 0.0999
ERROR - 2024-01-19 09:12:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:12:25 --> Config Class Initialized
INFO - 2024-01-19 09:12:25 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:12:25 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:12:25 --> Utf8 Class Initialized
INFO - 2024-01-19 09:12:25 --> URI Class Initialized
INFO - 2024-01-19 09:12:25 --> Router Class Initialized
INFO - 2024-01-19 09:12:25 --> Output Class Initialized
INFO - 2024-01-19 09:12:25 --> Security Class Initialized
DEBUG - 2024-01-19 09:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:12:25 --> Input Class Initialized
INFO - 2024-01-19 09:12:25 --> Language Class Initialized
INFO - 2024-01-19 09:12:25 --> Loader Class Initialized
INFO - 2024-01-19 09:12:25 --> Helper loaded: url_helper
INFO - 2024-01-19 09:12:25 --> Helper loaded: file_helper
INFO - 2024-01-19 09:12:25 --> Helper loaded: html_helper
INFO - 2024-01-19 09:12:25 --> Helper loaded: text_helper
INFO - 2024-01-19 09:12:25 --> Helper loaded: form_helper
INFO - 2024-01-19 09:12:25 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:12:25 --> Helper loaded: security_helper
INFO - 2024-01-19 09:12:25 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:12:25 --> Database Driver Class Initialized
INFO - 2024-01-19 09:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:12:25 --> Parser Class Initialized
INFO - 2024-01-19 09:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:12:25 --> Pagination Class Initialized
INFO - 2024-01-19 09:12:25 --> Form Validation Class Initialized
INFO - 2024-01-19 09:12:25 --> Controller Class Initialized
INFO - 2024-01-19 09:12:25 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 09:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:25 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:25 --> Model Class Initialized
DEBUG - 2024-01-19 09:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-19 09:12:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 09:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 09:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 09:12:25 --> Model Class Initialized
INFO - 2024-01-19 09:12:25 --> Model Class Initialized
INFO - 2024-01-19 09:12:25 --> Model Class Initialized
INFO - 2024-01-19 09:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 09:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 09:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 09:12:25 --> Final output sent to browser
DEBUG - 2024-01-19 09:12:25 --> Total execution time: 0.1606
ERROR - 2024-01-19 09:13:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:13:46 --> Config Class Initialized
INFO - 2024-01-19 09:13:46 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:13:46 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:13:46 --> Utf8 Class Initialized
INFO - 2024-01-19 09:13:46 --> URI Class Initialized
DEBUG - 2024-01-19 09:13:46 --> No URI present. Default controller set.
INFO - 2024-01-19 09:13:46 --> Router Class Initialized
INFO - 2024-01-19 09:13:46 --> Output Class Initialized
INFO - 2024-01-19 09:13:46 --> Security Class Initialized
DEBUG - 2024-01-19 09:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:13:46 --> Input Class Initialized
INFO - 2024-01-19 09:13:46 --> Language Class Initialized
INFO - 2024-01-19 09:13:46 --> Loader Class Initialized
INFO - 2024-01-19 09:13:46 --> Helper loaded: url_helper
INFO - 2024-01-19 09:13:46 --> Helper loaded: file_helper
INFO - 2024-01-19 09:13:46 --> Helper loaded: html_helper
INFO - 2024-01-19 09:13:46 --> Helper loaded: text_helper
INFO - 2024-01-19 09:13:46 --> Helper loaded: form_helper
INFO - 2024-01-19 09:13:46 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:13:46 --> Helper loaded: security_helper
INFO - 2024-01-19 09:13:46 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:13:46 --> Database Driver Class Initialized
INFO - 2024-01-19 09:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:13:46 --> Parser Class Initialized
INFO - 2024-01-19 09:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:13:46 --> Pagination Class Initialized
INFO - 2024-01-19 09:13:46 --> Form Validation Class Initialized
INFO - 2024-01-19 09:13:46 --> Controller Class Initialized
INFO - 2024-01-19 09:13:46 --> Model Class Initialized
DEBUG - 2024-01-19 09:13:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 09:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:13:47 --> Config Class Initialized
INFO - 2024-01-19 09:13:47 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:13:47 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:13:47 --> Utf8 Class Initialized
INFO - 2024-01-19 09:13:47 --> URI Class Initialized
DEBUG - 2024-01-19 09:13:47 --> No URI present. Default controller set.
INFO - 2024-01-19 09:13:47 --> Router Class Initialized
INFO - 2024-01-19 09:13:47 --> Output Class Initialized
INFO - 2024-01-19 09:13:47 --> Security Class Initialized
DEBUG - 2024-01-19 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:13:47 --> Input Class Initialized
INFO - 2024-01-19 09:13:47 --> Language Class Initialized
INFO - 2024-01-19 09:13:47 --> Loader Class Initialized
INFO - 2024-01-19 09:13:47 --> Helper loaded: url_helper
INFO - 2024-01-19 09:13:47 --> Helper loaded: file_helper
INFO - 2024-01-19 09:13:47 --> Helper loaded: html_helper
INFO - 2024-01-19 09:13:47 --> Helper loaded: text_helper
INFO - 2024-01-19 09:13:47 --> Helper loaded: form_helper
INFO - 2024-01-19 09:13:47 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:13:47 --> Helper loaded: security_helper
INFO - 2024-01-19 09:13:47 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:13:47 --> Database Driver Class Initialized
INFO - 2024-01-19 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:13:47 --> Parser Class Initialized
INFO - 2024-01-19 09:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:13:47 --> Pagination Class Initialized
INFO - 2024-01-19 09:13:47 --> Form Validation Class Initialized
INFO - 2024-01-19 09:13:47 --> Controller Class Initialized
INFO - 2024-01-19 09:13:47 --> Model Class Initialized
DEBUG - 2024-01-19 09:13:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 09:13:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:13:49 --> Config Class Initialized
INFO - 2024-01-19 09:13:49 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:13:49 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:13:49 --> Utf8 Class Initialized
INFO - 2024-01-19 09:13:49 --> URI Class Initialized
DEBUG - 2024-01-19 09:13:49 --> No URI present. Default controller set.
INFO - 2024-01-19 09:13:49 --> Router Class Initialized
INFO - 2024-01-19 09:13:49 --> Output Class Initialized
INFO - 2024-01-19 09:13:49 --> Security Class Initialized
DEBUG - 2024-01-19 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:13:49 --> Input Class Initialized
INFO - 2024-01-19 09:13:49 --> Language Class Initialized
INFO - 2024-01-19 09:13:49 --> Loader Class Initialized
INFO - 2024-01-19 09:13:49 --> Helper loaded: url_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: file_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: html_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: text_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: form_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: security_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:13:49 --> Database Driver Class Initialized
INFO - 2024-01-19 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:13:49 --> Parser Class Initialized
INFO - 2024-01-19 09:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:13:49 --> Pagination Class Initialized
INFO - 2024-01-19 09:13:49 --> Form Validation Class Initialized
INFO - 2024-01-19 09:13:49 --> Controller Class Initialized
INFO - 2024-01-19 09:13:49 --> Model Class Initialized
DEBUG - 2024-01-19 09:13:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 09:13:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 09:13:49 --> Config Class Initialized
INFO - 2024-01-19 09:13:49 --> Hooks Class Initialized
DEBUG - 2024-01-19 09:13:49 --> UTF-8 Support Enabled
INFO - 2024-01-19 09:13:49 --> Utf8 Class Initialized
INFO - 2024-01-19 09:13:49 --> URI Class Initialized
DEBUG - 2024-01-19 09:13:49 --> No URI present. Default controller set.
INFO - 2024-01-19 09:13:49 --> Router Class Initialized
INFO - 2024-01-19 09:13:49 --> Output Class Initialized
INFO - 2024-01-19 09:13:49 --> Security Class Initialized
DEBUG - 2024-01-19 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 09:13:49 --> Input Class Initialized
INFO - 2024-01-19 09:13:49 --> Language Class Initialized
INFO - 2024-01-19 09:13:49 --> Loader Class Initialized
INFO - 2024-01-19 09:13:49 --> Helper loaded: url_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: file_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: html_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: text_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: form_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: lang_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: security_helper
INFO - 2024-01-19 09:13:49 --> Helper loaded: cookie_helper
INFO - 2024-01-19 09:13:49 --> Database Driver Class Initialized
INFO - 2024-01-19 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 09:13:49 --> Parser Class Initialized
INFO - 2024-01-19 09:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 09:13:49 --> Pagination Class Initialized
INFO - 2024-01-19 09:13:49 --> Form Validation Class Initialized
INFO - 2024-01-19 09:13:49 --> Controller Class Initialized
INFO - 2024-01-19 09:13:49 --> Model Class Initialized
DEBUG - 2024-01-19 09:13:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 12:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:04:18 --> Config Class Initialized
INFO - 2024-01-19 12:04:18 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:04:18 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:04:18 --> Utf8 Class Initialized
INFO - 2024-01-19 12:04:18 --> URI Class Initialized
DEBUG - 2024-01-19 12:04:18 --> No URI present. Default controller set.
INFO - 2024-01-19 12:04:18 --> Router Class Initialized
INFO - 2024-01-19 12:04:18 --> Output Class Initialized
INFO - 2024-01-19 12:04:18 --> Security Class Initialized
DEBUG - 2024-01-19 12:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:04:18 --> Input Class Initialized
INFO - 2024-01-19 12:04:18 --> Language Class Initialized
INFO - 2024-01-19 12:04:18 --> Loader Class Initialized
INFO - 2024-01-19 12:04:18 --> Helper loaded: url_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: file_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: html_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: text_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: form_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: security_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:04:18 --> Database Driver Class Initialized
INFO - 2024-01-19 12:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:04:18 --> Parser Class Initialized
INFO - 2024-01-19 12:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:04:18 --> Pagination Class Initialized
INFO - 2024-01-19 12:04:18 --> Form Validation Class Initialized
INFO - 2024-01-19 12:04:18 --> Controller Class Initialized
INFO - 2024-01-19 12:04:18 --> Model Class Initialized
DEBUG - 2024-01-19 12:04:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 12:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:04:18 --> Config Class Initialized
INFO - 2024-01-19 12:04:18 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:04:18 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:04:18 --> Utf8 Class Initialized
INFO - 2024-01-19 12:04:18 --> URI Class Initialized
INFO - 2024-01-19 12:04:18 --> Router Class Initialized
INFO - 2024-01-19 12:04:18 --> Output Class Initialized
INFO - 2024-01-19 12:04:18 --> Security Class Initialized
DEBUG - 2024-01-19 12:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:04:18 --> Input Class Initialized
INFO - 2024-01-19 12:04:18 --> Language Class Initialized
INFO - 2024-01-19 12:04:18 --> Loader Class Initialized
INFO - 2024-01-19 12:04:18 --> Helper loaded: url_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: file_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: html_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: text_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: form_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: security_helper
INFO - 2024-01-19 12:04:18 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:04:18 --> Database Driver Class Initialized
INFO - 2024-01-19 12:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:04:18 --> Parser Class Initialized
INFO - 2024-01-19 12:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:04:18 --> Pagination Class Initialized
INFO - 2024-01-19 12:04:18 --> Form Validation Class Initialized
INFO - 2024-01-19 12:04:18 --> Controller Class Initialized
INFO - 2024-01-19 12:04:18 --> Model Class Initialized
DEBUG - 2024-01-19 12:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-19 12:04:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 12:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 12:04:18 --> Model Class Initialized
INFO - 2024-01-19 12:04:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 12:04:18 --> Final output sent to browser
DEBUG - 2024-01-19 12:04:18 --> Total execution time: 0.0383
ERROR - 2024-01-19 12:05:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:07 --> Config Class Initialized
INFO - 2024-01-19 12:05:07 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:07 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:07 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:07 --> URI Class Initialized
DEBUG - 2024-01-19 12:05:07 --> No URI present. Default controller set.
INFO - 2024-01-19 12:05:07 --> Router Class Initialized
INFO - 2024-01-19 12:05:07 --> Output Class Initialized
INFO - 2024-01-19 12:05:07 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:07 --> Input Class Initialized
INFO - 2024-01-19 12:05:07 --> Language Class Initialized
INFO - 2024-01-19 12:05:07 --> Loader Class Initialized
INFO - 2024-01-19 12:05:07 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:07 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:07 --> Parser Class Initialized
INFO - 2024-01-19 12:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:07 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:07 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:07 --> Controller Class Initialized
INFO - 2024-01-19 12:05:07 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 12:05:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:07 --> Config Class Initialized
INFO - 2024-01-19 12:05:07 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:07 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:07 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:07 --> URI Class Initialized
INFO - 2024-01-19 12:05:07 --> Router Class Initialized
INFO - 2024-01-19 12:05:07 --> Output Class Initialized
INFO - 2024-01-19 12:05:07 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:07 --> Input Class Initialized
INFO - 2024-01-19 12:05:07 --> Language Class Initialized
INFO - 2024-01-19 12:05:07 --> Loader Class Initialized
INFO - 2024-01-19 12:05:07 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:07 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:07 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:07 --> Parser Class Initialized
INFO - 2024-01-19 12:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:07 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:07 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:07 --> Controller Class Initialized
INFO - 2024-01-19 12:05:07 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-19 12:05:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 12:05:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 12:05:07 --> Model Class Initialized
INFO - 2024-01-19 12:05:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 12:05:07 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:07 --> Total execution time: 0.0288
ERROR - 2024-01-19 12:05:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:14 --> Config Class Initialized
INFO - 2024-01-19 12:05:14 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:14 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:14 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:14 --> URI Class Initialized
INFO - 2024-01-19 12:05:14 --> Router Class Initialized
INFO - 2024-01-19 12:05:14 --> Output Class Initialized
INFO - 2024-01-19 12:05:14 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:14 --> Input Class Initialized
INFO - 2024-01-19 12:05:14 --> Language Class Initialized
INFO - 2024-01-19 12:05:14 --> Loader Class Initialized
INFO - 2024-01-19 12:05:14 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:14 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:14 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:14 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:14 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:14 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:14 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:14 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:14 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:14 --> Parser Class Initialized
INFO - 2024-01-19 12:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:14 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:14 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:14 --> Controller Class Initialized
INFO - 2024-01-19 12:05:14 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:14 --> Model Class Initialized
INFO - 2024-01-19 12:05:14 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:14 --> Total execution time: 0.0213
ERROR - 2024-01-19 12:05:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:15 --> Config Class Initialized
INFO - 2024-01-19 12:05:15 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:15 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:15 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:15 --> URI Class Initialized
DEBUG - 2024-01-19 12:05:15 --> No URI present. Default controller set.
INFO - 2024-01-19 12:05:15 --> Router Class Initialized
INFO - 2024-01-19 12:05:15 --> Output Class Initialized
INFO - 2024-01-19 12:05:15 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:15 --> Input Class Initialized
INFO - 2024-01-19 12:05:15 --> Language Class Initialized
INFO - 2024-01-19 12:05:15 --> Loader Class Initialized
INFO - 2024-01-19 12:05:15 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:15 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:15 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:15 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:15 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:15 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:15 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:15 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:15 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:15 --> Parser Class Initialized
INFO - 2024-01-19 12:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:15 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:15 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:15 --> Controller Class Initialized
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
INFO - 2024-01-19 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 12:05:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 12:05:15 --> Model Class Initialized
INFO - 2024-01-19 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 12:05:15 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:15 --> Total execution time: 0.2354
ERROR - 2024-01-19 12:05:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:21 --> Config Class Initialized
INFO - 2024-01-19 12:05:21 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:21 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:21 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:21 --> URI Class Initialized
INFO - 2024-01-19 12:05:21 --> Router Class Initialized
INFO - 2024-01-19 12:05:21 --> Output Class Initialized
INFO - 2024-01-19 12:05:21 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:21 --> Input Class Initialized
INFO - 2024-01-19 12:05:21 --> Language Class Initialized
INFO - 2024-01-19 12:05:21 --> Loader Class Initialized
INFO - 2024-01-19 12:05:21 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:21 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:21 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:21 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:21 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:21 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:21 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:21 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:21 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:21 --> Parser Class Initialized
INFO - 2024-01-19 12:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:21 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:21 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:21 --> Controller Class Initialized
INFO - 2024-01-19 12:05:21 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 12:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:21 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:21 --> Model Class Initialized
INFO - 2024-01-19 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-19 12:05:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 12:05:21 --> Model Class Initialized
INFO - 2024-01-19 12:05:21 --> Model Class Initialized
INFO - 2024-01-19 12:05:21 --> Model Class Initialized
INFO - 2024-01-19 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 12:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 12:05:21 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:21 --> Total execution time: 0.1635
ERROR - 2024-01-19 12:05:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:27 --> Config Class Initialized
INFO - 2024-01-19 12:05:27 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:27 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:27 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:27 --> URI Class Initialized
INFO - 2024-01-19 12:05:27 --> Router Class Initialized
INFO - 2024-01-19 12:05:27 --> Output Class Initialized
INFO - 2024-01-19 12:05:27 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:27 --> Input Class Initialized
INFO - 2024-01-19 12:05:27 --> Language Class Initialized
INFO - 2024-01-19 12:05:27 --> Loader Class Initialized
INFO - 2024-01-19 12:05:27 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:27 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:27 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:27 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:27 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:27 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:27 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:27 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:27 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:27 --> Parser Class Initialized
INFO - 2024-01-19 12:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:27 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:27 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:27 --> Controller Class Initialized
INFO - 2024-01-19 12:05:27 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:27 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:27 --> Total execution time: 0.0158
ERROR - 2024-01-19 12:05:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:45 --> Config Class Initialized
INFO - 2024-01-19 12:05:45 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:45 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:45 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:45 --> URI Class Initialized
INFO - 2024-01-19 12:05:45 --> Router Class Initialized
INFO - 2024-01-19 12:05:45 --> Output Class Initialized
INFO - 2024-01-19 12:05:45 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:45 --> Input Class Initialized
INFO - 2024-01-19 12:05:45 --> Language Class Initialized
INFO - 2024-01-19 12:05:45 --> Loader Class Initialized
INFO - 2024-01-19 12:05:45 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:45 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:45 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:45 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:45 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:45 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:45 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:45 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:45 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:45 --> Parser Class Initialized
INFO - 2024-01-19 12:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:45 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:45 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:45 --> Controller Class Initialized
INFO - 2024-01-19 12:05:45 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:45 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:45 --> Total execution time: 0.0182
ERROR - 2024-01-19 12:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:49 --> Config Class Initialized
INFO - 2024-01-19 12:05:49 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:49 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:49 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:49 --> URI Class Initialized
DEBUG - 2024-01-19 12:05:49 --> No URI present. Default controller set.
INFO - 2024-01-19 12:05:49 --> Router Class Initialized
INFO - 2024-01-19 12:05:49 --> Output Class Initialized
INFO - 2024-01-19 12:05:49 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:49 --> Input Class Initialized
INFO - 2024-01-19 12:05:49 --> Language Class Initialized
INFO - 2024-01-19 12:05:49 --> Loader Class Initialized
INFO - 2024-01-19 12:05:49 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:49 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:49 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:49 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:49 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:49 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:49 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:49 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:49 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:49 --> Parser Class Initialized
INFO - 2024-01-19 12:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:49 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:49 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:49 --> Controller Class Initialized
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
INFO - 2024-01-19 12:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 12:05:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 12:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 12:05:49 --> Model Class Initialized
INFO - 2024-01-19 12:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 12:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 12:05:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 12:05:49 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:49 --> Total execution time: 0.2367
ERROR - 2024-01-19 12:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:51 --> Config Class Initialized
INFO - 2024-01-19 12:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:51 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:51 --> URI Class Initialized
INFO - 2024-01-19 12:05:51 --> Router Class Initialized
INFO - 2024-01-19 12:05:51 --> Output Class Initialized
INFO - 2024-01-19 12:05:51 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:51 --> Input Class Initialized
INFO - 2024-01-19 12:05:51 --> Language Class Initialized
INFO - 2024-01-19 12:05:51 --> Loader Class Initialized
INFO - 2024-01-19 12:05:51 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:51 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:51 --> Parser Class Initialized
INFO - 2024-01-19 12:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:51 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:51 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:51 --> Controller Class Initialized
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-19 12:05:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 12:05:51 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:51 --> Total execution time: 0.0272
ERROR - 2024-01-19 12:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 12:05:51 --> Config Class Initialized
INFO - 2024-01-19 12:05:51 --> Hooks Class Initialized
DEBUG - 2024-01-19 12:05:51 --> UTF-8 Support Enabled
INFO - 2024-01-19 12:05:51 --> Utf8 Class Initialized
INFO - 2024-01-19 12:05:51 --> URI Class Initialized
INFO - 2024-01-19 12:05:51 --> Router Class Initialized
INFO - 2024-01-19 12:05:51 --> Output Class Initialized
INFO - 2024-01-19 12:05:51 --> Security Class Initialized
DEBUG - 2024-01-19 12:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 12:05:51 --> Input Class Initialized
INFO - 2024-01-19 12:05:51 --> Language Class Initialized
INFO - 2024-01-19 12:05:51 --> Loader Class Initialized
INFO - 2024-01-19 12:05:51 --> Helper loaded: url_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: file_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: html_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: text_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: form_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: lang_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: security_helper
INFO - 2024-01-19 12:05:51 --> Helper loaded: cookie_helper
INFO - 2024-01-19 12:05:51 --> Database Driver Class Initialized
INFO - 2024-01-19 12:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 12:05:51 --> Parser Class Initialized
INFO - 2024-01-19 12:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 12:05:51 --> Pagination Class Initialized
INFO - 2024-01-19 12:05:51 --> Form Validation Class Initialized
INFO - 2024-01-19 12:05:51 --> Controller Class Initialized
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
DEBUG - 2024-01-19 12:05:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-19 12:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-19 12:05:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 12:05:51 --> Model Class Initialized
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-19 12:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 12:05:51 --> Final output sent to browser
DEBUG - 2024-01-19 12:05:51 --> Total execution time: 0.2194
ERROR - 2024-01-19 21:28:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 21:28:11 --> Config Class Initialized
INFO - 2024-01-19 21:28:11 --> Hooks Class Initialized
DEBUG - 2024-01-19 21:28:11 --> UTF-8 Support Enabled
INFO - 2024-01-19 21:28:11 --> Utf8 Class Initialized
INFO - 2024-01-19 21:28:11 --> URI Class Initialized
INFO - 2024-01-19 21:28:11 --> Router Class Initialized
INFO - 2024-01-19 21:28:11 --> Output Class Initialized
INFO - 2024-01-19 21:28:11 --> Security Class Initialized
DEBUG - 2024-01-19 21:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 21:28:11 --> Input Class Initialized
INFO - 2024-01-19 21:28:11 --> Language Class Initialized
ERROR - 2024-01-19 21:28:11 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-19 22:24:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 22:24:07 --> Config Class Initialized
INFO - 2024-01-19 22:24:07 --> Hooks Class Initialized
DEBUG - 2024-01-19 22:24:07 --> UTF-8 Support Enabled
INFO - 2024-01-19 22:24:07 --> Utf8 Class Initialized
INFO - 2024-01-19 22:24:07 --> URI Class Initialized
INFO - 2024-01-19 22:24:07 --> Router Class Initialized
INFO - 2024-01-19 22:24:07 --> Output Class Initialized
INFO - 2024-01-19 22:24:07 --> Security Class Initialized
DEBUG - 2024-01-19 22:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 22:24:07 --> Input Class Initialized
INFO - 2024-01-19 22:24:07 --> Language Class Initialized
ERROR - 2024-01-19 22:24:07 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-01-19 22:24:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 22:24:08 --> Config Class Initialized
INFO - 2024-01-19 22:24:08 --> Hooks Class Initialized
DEBUG - 2024-01-19 22:24:08 --> UTF-8 Support Enabled
INFO - 2024-01-19 22:24:08 --> Utf8 Class Initialized
INFO - 2024-01-19 22:24:08 --> URI Class Initialized
DEBUG - 2024-01-19 22:24:08 --> No URI present. Default controller set.
INFO - 2024-01-19 22:24:08 --> Router Class Initialized
INFO - 2024-01-19 22:24:08 --> Output Class Initialized
INFO - 2024-01-19 22:24:08 --> Security Class Initialized
DEBUG - 2024-01-19 22:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 22:24:08 --> Input Class Initialized
INFO - 2024-01-19 22:24:08 --> Language Class Initialized
INFO - 2024-01-19 22:24:08 --> Loader Class Initialized
INFO - 2024-01-19 22:24:08 --> Helper loaded: url_helper
INFO - 2024-01-19 22:24:08 --> Helper loaded: file_helper
INFO - 2024-01-19 22:24:08 --> Helper loaded: html_helper
INFO - 2024-01-19 22:24:08 --> Helper loaded: text_helper
INFO - 2024-01-19 22:24:08 --> Helper loaded: form_helper
INFO - 2024-01-19 22:24:08 --> Helper loaded: lang_helper
INFO - 2024-01-19 22:24:08 --> Helper loaded: security_helper
INFO - 2024-01-19 22:24:08 --> Helper loaded: cookie_helper
INFO - 2024-01-19 22:24:08 --> Database Driver Class Initialized
INFO - 2024-01-19 22:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 22:24:08 --> Parser Class Initialized
INFO - 2024-01-19 22:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 22:24:08 --> Pagination Class Initialized
INFO - 2024-01-19 22:24:08 --> Form Validation Class Initialized
INFO - 2024-01-19 22:24:08 --> Controller Class Initialized
INFO - 2024-01-19 22:24:08 --> Model Class Initialized
DEBUG - 2024-01-19 22:24:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 22:24:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 22:24:10 --> Config Class Initialized
INFO - 2024-01-19 22:24:10 --> Hooks Class Initialized
DEBUG - 2024-01-19 22:24:10 --> UTF-8 Support Enabled
INFO - 2024-01-19 22:24:10 --> Utf8 Class Initialized
INFO - 2024-01-19 22:24:10 --> URI Class Initialized
INFO - 2024-01-19 22:24:10 --> Router Class Initialized
INFO - 2024-01-19 22:24:10 --> Output Class Initialized
INFO - 2024-01-19 22:24:10 --> Security Class Initialized
DEBUG - 2024-01-19 22:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 22:24:10 --> Input Class Initialized
INFO - 2024-01-19 22:24:10 --> Language Class Initialized
ERROR - 2024-01-19 22:24:10 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-01-19 23:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:16 --> Config Class Initialized
INFO - 2024-01-19 23:10:16 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:16 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:16 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:16 --> URI Class Initialized
DEBUG - 2024-01-19 23:10:16 --> No URI present. Default controller set.
INFO - 2024-01-19 23:10:16 --> Router Class Initialized
INFO - 2024-01-19 23:10:16 --> Output Class Initialized
INFO - 2024-01-19 23:10:16 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:16 --> Input Class Initialized
INFO - 2024-01-19 23:10:16 --> Language Class Initialized
INFO - 2024-01-19 23:10:16 --> Loader Class Initialized
INFO - 2024-01-19 23:10:16 --> Helper loaded: url_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: file_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: html_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: text_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: form_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: lang_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: security_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: cookie_helper
INFO - 2024-01-19 23:10:16 --> Database Driver Class Initialized
INFO - 2024-01-19 23:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 23:10:16 --> Parser Class Initialized
INFO - 2024-01-19 23:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 23:10:16 --> Pagination Class Initialized
INFO - 2024-01-19 23:10:16 --> Form Validation Class Initialized
INFO - 2024-01-19 23:10:16 --> Controller Class Initialized
INFO - 2024-01-19 23:10:16 --> Model Class Initialized
DEBUG - 2024-01-19 23:10:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 23:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:16 --> Config Class Initialized
INFO - 2024-01-19 23:10:16 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:16 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:16 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:16 --> URI Class Initialized
INFO - 2024-01-19 23:10:16 --> Router Class Initialized
INFO - 2024-01-19 23:10:16 --> Output Class Initialized
INFO - 2024-01-19 23:10:16 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:16 --> Input Class Initialized
INFO - 2024-01-19 23:10:16 --> Language Class Initialized
ERROR - 2024-01-19 23:10:16 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-01-19 23:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:16 --> Config Class Initialized
INFO - 2024-01-19 23:10:16 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:16 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:16 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:16 --> URI Class Initialized
INFO - 2024-01-19 23:10:16 --> Router Class Initialized
INFO - 2024-01-19 23:10:16 --> Output Class Initialized
INFO - 2024-01-19 23:10:16 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:16 --> Input Class Initialized
INFO - 2024-01-19 23:10:16 --> Language Class Initialized
ERROR - 2024-01-19 23:10:16 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-01-19 23:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:16 --> Config Class Initialized
INFO - 2024-01-19 23:10:16 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:16 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:16 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:16 --> URI Class Initialized
DEBUG - 2024-01-19 23:10:16 --> No URI present. Default controller set.
INFO - 2024-01-19 23:10:16 --> Router Class Initialized
INFO - 2024-01-19 23:10:16 --> Output Class Initialized
INFO - 2024-01-19 23:10:16 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:16 --> Input Class Initialized
INFO - 2024-01-19 23:10:16 --> Language Class Initialized
INFO - 2024-01-19 23:10:16 --> Loader Class Initialized
INFO - 2024-01-19 23:10:16 --> Helper loaded: url_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: file_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: html_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: text_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: form_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: lang_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: security_helper
INFO - 2024-01-19 23:10:16 --> Helper loaded: cookie_helper
INFO - 2024-01-19 23:10:16 --> Database Driver Class Initialized
INFO - 2024-01-19 23:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 23:10:16 --> Parser Class Initialized
INFO - 2024-01-19 23:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 23:10:16 --> Pagination Class Initialized
INFO - 2024-01-19 23:10:16 --> Form Validation Class Initialized
INFO - 2024-01-19 23:10:16 --> Controller Class Initialized
INFO - 2024-01-19 23:10:16 --> Model Class Initialized
DEBUG - 2024-01-19 23:10:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Website/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-01-19 23:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:10:17 --> Config Class Initialized
INFO - 2024-01-19 23:10:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:10:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:10:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:10:17 --> URI Class Initialized
INFO - 2024-01-19 23:10:17 --> Router Class Initialized
INFO - 2024-01-19 23:10:17 --> Output Class Initialized
INFO - 2024-01-19 23:10:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:10:17 --> Input Class Initialized
INFO - 2024-01-19 23:10:17 --> Language Class Initialized
ERROR - 2024-01-19 23:10:17 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-01-19 23:18:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:18:20 --> Config Class Initialized
INFO - 2024-01-19 23:18:20 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:18:20 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:18:20 --> Utf8 Class Initialized
INFO - 2024-01-19 23:18:20 --> URI Class Initialized
DEBUG - 2024-01-19 23:18:20 --> No URI present. Default controller set.
INFO - 2024-01-19 23:18:20 --> Router Class Initialized
INFO - 2024-01-19 23:18:20 --> Output Class Initialized
INFO - 2024-01-19 23:18:20 --> Security Class Initialized
DEBUG - 2024-01-19 23:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:18:20 --> Input Class Initialized
INFO - 2024-01-19 23:18:20 --> Language Class Initialized
INFO - 2024-01-19 23:18:20 --> Loader Class Initialized
INFO - 2024-01-19 23:18:20 --> Helper loaded: url_helper
INFO - 2024-01-19 23:18:20 --> Helper loaded: file_helper
INFO - 2024-01-19 23:18:20 --> Helper loaded: html_helper
INFO - 2024-01-19 23:18:20 --> Helper loaded: text_helper
INFO - 2024-01-19 23:18:20 --> Helper loaded: form_helper
INFO - 2024-01-19 23:18:20 --> Helper loaded: lang_helper
INFO - 2024-01-19 23:18:20 --> Helper loaded: security_helper
INFO - 2024-01-19 23:18:20 --> Helper loaded: cookie_helper
INFO - 2024-01-19 23:18:20 --> Database Driver Class Initialized
INFO - 2024-01-19 23:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 23:18:20 --> Parser Class Initialized
INFO - 2024-01-19 23:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 23:18:20 --> Pagination Class Initialized
INFO - 2024-01-19 23:18:20 --> Form Validation Class Initialized
INFO - 2024-01-19 23:18:20 --> Controller Class Initialized
INFO - 2024-01-19 23:18:20 --> Model Class Initialized
DEBUG - 2024-01-19 23:18:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 23:52:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:52:06 --> Config Class Initialized
INFO - 2024-01-19 23:52:06 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:52:06 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:52:06 --> Utf8 Class Initialized
INFO - 2024-01-19 23:52:06 --> URI Class Initialized
DEBUG - 2024-01-19 23:52:06 --> No URI present. Default controller set.
INFO - 2024-01-19 23:52:06 --> Router Class Initialized
INFO - 2024-01-19 23:52:06 --> Output Class Initialized
INFO - 2024-01-19 23:52:06 --> Security Class Initialized
DEBUG - 2024-01-19 23:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:52:06 --> Input Class Initialized
INFO - 2024-01-19 23:52:06 --> Language Class Initialized
INFO - 2024-01-19 23:52:06 --> Loader Class Initialized
INFO - 2024-01-19 23:52:06 --> Helper loaded: url_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: file_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: html_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: text_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: form_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: lang_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: security_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: cookie_helper
INFO - 2024-01-19 23:52:06 --> Database Driver Class Initialized
INFO - 2024-01-19 23:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 23:52:06 --> Parser Class Initialized
INFO - 2024-01-19 23:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 23:52:06 --> Pagination Class Initialized
INFO - 2024-01-19 23:52:06 --> Form Validation Class Initialized
INFO - 2024-01-19 23:52:06 --> Controller Class Initialized
INFO - 2024-01-19 23:52:06 --> Model Class Initialized
DEBUG - 2024-01-19 23:52:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-19 23:52:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:52:06 --> Config Class Initialized
INFO - 2024-01-19 23:52:06 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:52:06 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:52:06 --> Utf8 Class Initialized
INFO - 2024-01-19 23:52:06 --> URI Class Initialized
INFO - 2024-01-19 23:52:06 --> Router Class Initialized
INFO - 2024-01-19 23:52:06 --> Output Class Initialized
INFO - 2024-01-19 23:52:06 --> Security Class Initialized
DEBUG - 2024-01-19 23:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:52:06 --> Input Class Initialized
INFO - 2024-01-19 23:52:06 --> Language Class Initialized
INFO - 2024-01-19 23:52:06 --> Loader Class Initialized
INFO - 2024-01-19 23:52:06 --> Helper loaded: url_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: file_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: html_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: text_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: form_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: lang_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: security_helper
INFO - 2024-01-19 23:52:06 --> Helper loaded: cookie_helper
INFO - 2024-01-19 23:52:06 --> Database Driver Class Initialized
INFO - 2024-01-19 23:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-19 23:52:06 --> Parser Class Initialized
INFO - 2024-01-19 23:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-19 23:52:06 --> Pagination Class Initialized
INFO - 2024-01-19 23:52:06 --> Form Validation Class Initialized
INFO - 2024-01-19 23:52:06 --> Controller Class Initialized
INFO - 2024-01-19 23:52:06 --> Model Class Initialized
DEBUG - 2024-01-19 23:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-19 23:52:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-19 23:52:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-19 23:52:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-19 23:52:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-19 23:52:06 --> Model Class Initialized
INFO - 2024-01-19 23:52:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-19 23:52:06 --> Final output sent to browser
DEBUG - 2024-01-19 23:52:06 --> Total execution time: 0.0317
ERROR - 2024-01-19 23:58:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-19 23:58:17 --> Config Class Initialized
INFO - 2024-01-19 23:58:17 --> Hooks Class Initialized
DEBUG - 2024-01-19 23:58:17 --> UTF-8 Support Enabled
INFO - 2024-01-19 23:58:17 --> Utf8 Class Initialized
INFO - 2024-01-19 23:58:17 --> URI Class Initialized
INFO - 2024-01-19 23:58:17 --> Router Class Initialized
INFO - 2024-01-19 23:58:17 --> Output Class Initialized
INFO - 2024-01-19 23:58:17 --> Security Class Initialized
DEBUG - 2024-01-19 23:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-19 23:58:17 --> Input Class Initialized
INFO - 2024-01-19 23:58:17 --> Language Class Initialized
ERROR - 2024-01-19 23:58:17 --> 404 Page Not Found: Well-known/assetlinks.json
