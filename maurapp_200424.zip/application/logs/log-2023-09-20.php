<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-20 05:53:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 05:53:49 --> Config Class Initialized
INFO - 2023-09-20 05:53:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 05:53:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 05:53:49 --> Utf8 Class Initialized
INFO - 2023-09-20 05:53:49 --> URI Class Initialized
DEBUG - 2023-09-20 05:53:49 --> No URI present. Default controller set.
INFO - 2023-09-20 05:53:49 --> Router Class Initialized
INFO - 2023-09-20 05:53:49 --> Output Class Initialized
INFO - 2023-09-20 05:53:49 --> Security Class Initialized
DEBUG - 2023-09-20 05:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 05:53:49 --> Input Class Initialized
INFO - 2023-09-20 05:53:49 --> Language Class Initialized
INFO - 2023-09-20 05:53:49 --> Loader Class Initialized
INFO - 2023-09-20 05:53:49 --> Helper loaded: url_helper
INFO - 2023-09-20 05:53:49 --> Helper loaded: file_helper
INFO - 2023-09-20 05:53:49 --> Helper loaded: html_helper
INFO - 2023-09-20 05:53:49 --> Helper loaded: text_helper
INFO - 2023-09-20 05:53:49 --> Helper loaded: form_helper
INFO - 2023-09-20 05:53:49 --> Helper loaded: lang_helper
INFO - 2023-09-20 05:53:49 --> Helper loaded: security_helper
INFO - 2023-09-20 05:53:49 --> Helper loaded: cookie_helper
INFO - 2023-09-20 05:53:49 --> Database Driver Class Initialized
INFO - 2023-09-20 05:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 05:53:49 --> Parser Class Initialized
INFO - 2023-09-20 05:53:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 05:53:49 --> Pagination Class Initialized
INFO - 2023-09-20 05:53:49 --> Form Validation Class Initialized
INFO - 2023-09-20 05:53:49 --> Controller Class Initialized
INFO - 2023-09-20 05:53:49 --> Model Class Initialized
DEBUG - 2023-09-20 05:53:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 05:53:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 05:53:50 --> Config Class Initialized
INFO - 2023-09-20 05:53:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 05:53:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 05:53:50 --> Utf8 Class Initialized
INFO - 2023-09-20 05:53:50 --> URI Class Initialized
INFO - 2023-09-20 05:53:50 --> Router Class Initialized
INFO - 2023-09-20 05:53:50 --> Output Class Initialized
INFO - 2023-09-20 05:53:50 --> Security Class Initialized
DEBUG - 2023-09-20 05:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 05:53:50 --> Input Class Initialized
INFO - 2023-09-20 05:53:50 --> Language Class Initialized
INFO - 2023-09-20 05:53:50 --> Loader Class Initialized
INFO - 2023-09-20 05:53:50 --> Helper loaded: url_helper
INFO - 2023-09-20 05:53:50 --> Helper loaded: file_helper
INFO - 2023-09-20 05:53:50 --> Helper loaded: html_helper
INFO - 2023-09-20 05:53:50 --> Helper loaded: text_helper
INFO - 2023-09-20 05:53:50 --> Helper loaded: form_helper
INFO - 2023-09-20 05:53:50 --> Helper loaded: lang_helper
INFO - 2023-09-20 05:53:50 --> Helper loaded: security_helper
INFO - 2023-09-20 05:53:50 --> Helper loaded: cookie_helper
INFO - 2023-09-20 05:53:50 --> Database Driver Class Initialized
INFO - 2023-09-20 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 05:53:50 --> Parser Class Initialized
INFO - 2023-09-20 05:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 05:53:50 --> Pagination Class Initialized
INFO - 2023-09-20 05:53:50 --> Form Validation Class Initialized
INFO - 2023-09-20 05:53:50 --> Controller Class Initialized
INFO - 2023-09-20 05:53:50 --> Model Class Initialized
DEBUG - 2023-09-20 05:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 05:53:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 05:53:50 --> Model Class Initialized
INFO - 2023-09-20 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 05:53:50 --> Final output sent to browser
DEBUG - 2023-09-20 05:53:50 --> Total execution time: 0.0338
ERROR - 2023-09-20 06:00:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:26 --> Config Class Initialized
INFO - 2023-09-20 06:00:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:26 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:26 --> URI Class Initialized
DEBUG - 2023-09-20 06:00:26 --> No URI present. Default controller set.
INFO - 2023-09-20 06:00:26 --> Router Class Initialized
INFO - 2023-09-20 06:00:26 --> Output Class Initialized
INFO - 2023-09-20 06:00:26 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:26 --> Input Class Initialized
INFO - 2023-09-20 06:00:26 --> Language Class Initialized
INFO - 2023-09-20 06:00:26 --> Loader Class Initialized
INFO - 2023-09-20 06:00:26 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:26 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:26 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:26 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:26 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:26 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:26 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:26 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:26 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:26 --> Parser Class Initialized
INFO - 2023-09-20 06:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:26 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:26 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:26 --> Controller Class Initialized
INFO - 2023-09-20 06:00:26 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 06:00:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:27 --> Config Class Initialized
INFO - 2023-09-20 06:00:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:27 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:27 --> URI Class Initialized
INFO - 2023-09-20 06:00:27 --> Router Class Initialized
INFO - 2023-09-20 06:00:27 --> Output Class Initialized
INFO - 2023-09-20 06:00:27 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:27 --> Input Class Initialized
INFO - 2023-09-20 06:00:27 --> Language Class Initialized
INFO - 2023-09-20 06:00:27 --> Loader Class Initialized
INFO - 2023-09-20 06:00:27 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:27 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:27 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:27 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:27 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:27 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:27 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:27 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:27 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:27 --> Parser Class Initialized
INFO - 2023-09-20 06:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:27 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:27 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:27 --> Controller Class Initialized
INFO - 2023-09-20 06:00:27 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 06:00:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 06:00:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 06:00:27 --> Model Class Initialized
INFO - 2023-09-20 06:00:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 06:00:27 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:27 --> Total execution time: 0.0298
ERROR - 2023-09-20 06:00:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:41 --> Config Class Initialized
INFO - 2023-09-20 06:00:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:41 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:41 --> URI Class Initialized
INFO - 2023-09-20 06:00:41 --> Router Class Initialized
INFO - 2023-09-20 06:00:41 --> Output Class Initialized
INFO - 2023-09-20 06:00:41 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:41 --> Input Class Initialized
INFO - 2023-09-20 06:00:41 --> Language Class Initialized
INFO - 2023-09-20 06:00:41 --> Loader Class Initialized
INFO - 2023-09-20 06:00:41 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:41 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:41 --> Parser Class Initialized
INFO - 2023-09-20 06:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:41 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:41 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:41 --> Controller Class Initialized
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
INFO - 2023-09-20 06:00:41 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:41 --> Total execution time: 0.0216
ERROR - 2023-09-20 06:00:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:41 --> Config Class Initialized
INFO - 2023-09-20 06:00:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:41 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:41 --> URI Class Initialized
DEBUG - 2023-09-20 06:00:41 --> No URI present. Default controller set.
INFO - 2023-09-20 06:00:41 --> Router Class Initialized
INFO - 2023-09-20 06:00:41 --> Output Class Initialized
INFO - 2023-09-20 06:00:41 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:41 --> Input Class Initialized
INFO - 2023-09-20 06:00:41 --> Language Class Initialized
INFO - 2023-09-20 06:00:41 --> Loader Class Initialized
INFO - 2023-09-20 06:00:41 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:41 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:41 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:41 --> Parser Class Initialized
INFO - 2023-09-20 06:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:41 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:41 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:41 --> Controller Class Initialized
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
INFO - 2023-09-20 06:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 06:00:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 06:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 06:00:41 --> Model Class Initialized
INFO - 2023-09-20 06:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 06:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 06:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 06:00:41 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:41 --> Total execution time: 0.1024
ERROR - 2023-09-20 06:00:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:45 --> Config Class Initialized
INFO - 2023-09-20 06:00:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:45 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:45 --> URI Class Initialized
INFO - 2023-09-20 06:00:45 --> Router Class Initialized
INFO - 2023-09-20 06:00:45 --> Output Class Initialized
INFO - 2023-09-20 06:00:45 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:45 --> Input Class Initialized
INFO - 2023-09-20 06:00:45 --> Language Class Initialized
INFO - 2023-09-20 06:00:45 --> Loader Class Initialized
INFO - 2023-09-20 06:00:45 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:45 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:45 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:45 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:45 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:45 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:45 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:45 --> Parser Class Initialized
INFO - 2023-09-20 06:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:45 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:45 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:45 --> Controller Class Initialized
INFO - 2023-09-20 06:00:45 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:45 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:45 --> Model Class Initialized
INFO - 2023-09-20 06:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 06:00:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 06:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 06:00:45 --> Model Class Initialized
INFO - 2023-09-20 06:00:45 --> Model Class Initialized
INFO - 2023-09-20 06:00:45 --> Model Class Initialized
INFO - 2023-09-20 06:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 06:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 06:00:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 06:00:45 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:45 --> Total execution time: 0.0898
ERROR - 2023-09-20 06:00:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:47 --> Config Class Initialized
INFO - 2023-09-20 06:00:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:47 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:47 --> URI Class Initialized
INFO - 2023-09-20 06:00:47 --> Router Class Initialized
INFO - 2023-09-20 06:00:47 --> Output Class Initialized
INFO - 2023-09-20 06:00:47 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:47 --> Input Class Initialized
INFO - 2023-09-20 06:00:47 --> Language Class Initialized
INFO - 2023-09-20 06:00:47 --> Loader Class Initialized
INFO - 2023-09-20 06:00:47 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:47 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:47 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:47 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:47 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:47 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:47 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:47 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:47 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:47 --> Parser Class Initialized
INFO - 2023-09-20 06:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:47 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:47 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:47 --> Controller Class Initialized
INFO - 2023-09-20 06:00:47 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:47 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:47 --> Model Class Initialized
INFO - 2023-09-20 06:00:47 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:47 --> Total execution time: 0.0357
ERROR - 2023-09-20 06:00:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:51 --> Config Class Initialized
INFO - 2023-09-20 06:00:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:51 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:51 --> URI Class Initialized
INFO - 2023-09-20 06:00:51 --> Router Class Initialized
INFO - 2023-09-20 06:00:51 --> Output Class Initialized
INFO - 2023-09-20 06:00:51 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:51 --> Input Class Initialized
INFO - 2023-09-20 06:00:51 --> Language Class Initialized
INFO - 2023-09-20 06:00:51 --> Loader Class Initialized
INFO - 2023-09-20 06:00:51 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:51 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:51 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:51 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:51 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:51 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:51 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:51 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:51 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:51 --> Parser Class Initialized
INFO - 2023-09-20 06:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:51 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:51 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:51 --> Controller Class Initialized
INFO - 2023-09-20 06:00:51 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:51 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:51 --> Model Class Initialized
INFO - 2023-09-20 06:00:51 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:51 --> Total execution time: 0.0370
ERROR - 2023-09-20 06:00:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:52 --> Config Class Initialized
INFO - 2023-09-20 06:00:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:52 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:52 --> URI Class Initialized
INFO - 2023-09-20 06:00:52 --> Router Class Initialized
INFO - 2023-09-20 06:00:52 --> Output Class Initialized
INFO - 2023-09-20 06:00:52 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:52 --> Input Class Initialized
INFO - 2023-09-20 06:00:52 --> Language Class Initialized
INFO - 2023-09-20 06:00:52 --> Loader Class Initialized
INFO - 2023-09-20 06:00:52 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:52 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:52 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:52 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:52 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:52 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:52 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:52 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:52 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:52 --> Parser Class Initialized
INFO - 2023-09-20 06:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:52 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:52 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:52 --> Controller Class Initialized
INFO - 2023-09-20 06:00:52 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:52 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:52 --> Model Class Initialized
INFO - 2023-09-20 06:00:52 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:52 --> Total execution time: 0.0367
ERROR - 2023-09-20 06:00:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:00:56 --> Config Class Initialized
INFO - 2023-09-20 06:00:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:00:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:00:56 --> Utf8 Class Initialized
INFO - 2023-09-20 06:00:56 --> URI Class Initialized
INFO - 2023-09-20 06:00:56 --> Router Class Initialized
INFO - 2023-09-20 06:00:56 --> Output Class Initialized
INFO - 2023-09-20 06:00:56 --> Security Class Initialized
DEBUG - 2023-09-20 06:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:00:56 --> Input Class Initialized
INFO - 2023-09-20 06:00:56 --> Language Class Initialized
INFO - 2023-09-20 06:00:56 --> Loader Class Initialized
INFO - 2023-09-20 06:00:56 --> Helper loaded: url_helper
INFO - 2023-09-20 06:00:56 --> Helper loaded: file_helper
INFO - 2023-09-20 06:00:56 --> Helper loaded: html_helper
INFO - 2023-09-20 06:00:56 --> Helper loaded: text_helper
INFO - 2023-09-20 06:00:56 --> Helper loaded: form_helper
INFO - 2023-09-20 06:00:56 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:00:56 --> Helper loaded: security_helper
INFO - 2023-09-20 06:00:56 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:00:56 --> Database Driver Class Initialized
INFO - 2023-09-20 06:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:00:56 --> Parser Class Initialized
INFO - 2023-09-20 06:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:00:56 --> Pagination Class Initialized
INFO - 2023-09-20 06:00:56 --> Form Validation Class Initialized
INFO - 2023-09-20 06:00:56 --> Controller Class Initialized
INFO - 2023-09-20 06:00:56 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:56 --> Model Class Initialized
DEBUG - 2023-09-20 06:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:00:56 --> Model Class Initialized
INFO - 2023-09-20 06:00:56 --> Final output sent to browser
DEBUG - 2023-09-20 06:00:56 --> Total execution time: 0.0266
ERROR - 2023-09-20 06:01:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:01:03 --> Config Class Initialized
INFO - 2023-09-20 06:01:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:01:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:01:03 --> Utf8 Class Initialized
INFO - 2023-09-20 06:01:03 --> URI Class Initialized
INFO - 2023-09-20 06:01:03 --> Router Class Initialized
INFO - 2023-09-20 06:01:03 --> Output Class Initialized
INFO - 2023-09-20 06:01:03 --> Security Class Initialized
DEBUG - 2023-09-20 06:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:01:03 --> Input Class Initialized
INFO - 2023-09-20 06:01:03 --> Language Class Initialized
INFO - 2023-09-20 06:01:03 --> Loader Class Initialized
INFO - 2023-09-20 06:01:03 --> Helper loaded: url_helper
INFO - 2023-09-20 06:01:03 --> Helper loaded: file_helper
INFO - 2023-09-20 06:01:03 --> Helper loaded: html_helper
INFO - 2023-09-20 06:01:03 --> Helper loaded: text_helper
INFO - 2023-09-20 06:01:03 --> Helper loaded: form_helper
INFO - 2023-09-20 06:01:03 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:01:03 --> Helper loaded: security_helper
INFO - 2023-09-20 06:01:03 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:01:03 --> Database Driver Class Initialized
INFO - 2023-09-20 06:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:01:03 --> Parser Class Initialized
INFO - 2023-09-20 06:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:01:03 --> Pagination Class Initialized
INFO - 2023-09-20 06:01:03 --> Form Validation Class Initialized
INFO - 2023-09-20 06:01:03 --> Controller Class Initialized
INFO - 2023-09-20 06:01:03 --> Model Class Initialized
DEBUG - 2023-09-20 06:01:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:01:03 --> Model Class Initialized
DEBUG - 2023-09-20 06:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:01:03 --> Model Class Initialized
DEBUG - 2023-09-20 06:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-20 06:01:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 06:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 06:01:03 --> Model Class Initialized
INFO - 2023-09-20 06:01:03 --> Model Class Initialized
INFO - 2023-09-20 06:01:03 --> Model Class Initialized
INFO - 2023-09-20 06:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 06:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 06:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 06:01:03 --> Final output sent to browser
DEBUG - 2023-09-20 06:01:03 --> Total execution time: 0.1032
ERROR - 2023-09-20 06:06:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:06:19 --> Config Class Initialized
INFO - 2023-09-20 06:06:19 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:06:19 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:06:19 --> Utf8 Class Initialized
INFO - 2023-09-20 06:06:19 --> URI Class Initialized
INFO - 2023-09-20 06:06:19 --> Router Class Initialized
INFO - 2023-09-20 06:06:19 --> Output Class Initialized
INFO - 2023-09-20 06:06:19 --> Security Class Initialized
DEBUG - 2023-09-20 06:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:06:19 --> Input Class Initialized
INFO - 2023-09-20 06:06:19 --> Language Class Initialized
INFO - 2023-09-20 06:06:19 --> Loader Class Initialized
INFO - 2023-09-20 06:06:19 --> Helper loaded: url_helper
INFO - 2023-09-20 06:06:19 --> Helper loaded: file_helper
INFO - 2023-09-20 06:06:19 --> Helper loaded: html_helper
INFO - 2023-09-20 06:06:19 --> Helper loaded: text_helper
INFO - 2023-09-20 06:06:19 --> Helper loaded: form_helper
INFO - 2023-09-20 06:06:19 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:06:19 --> Helper loaded: security_helper
INFO - 2023-09-20 06:06:19 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:06:19 --> Database Driver Class Initialized
INFO - 2023-09-20 06:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:06:19 --> Parser Class Initialized
INFO - 2023-09-20 06:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:06:19 --> Pagination Class Initialized
INFO - 2023-09-20 06:06:19 --> Form Validation Class Initialized
INFO - 2023-09-20 06:06:19 --> Controller Class Initialized
INFO - 2023-09-20 06:06:19 --> Model Class Initialized
DEBUG - 2023-09-20 06:06:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:06:19 --> Model Class Initialized
DEBUG - 2023-09-20 06:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:06:19 --> Model Class Initialized
INFO - 2023-09-20 06:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 06:06:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 06:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 06:06:19 --> Model Class Initialized
INFO - 2023-09-20 06:06:19 --> Model Class Initialized
INFO - 2023-09-20 06:06:19 --> Model Class Initialized
INFO - 2023-09-20 06:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 06:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 06:06:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 06:06:19 --> Final output sent to browser
DEBUG - 2023-09-20 06:06:19 --> Total execution time: 0.0905
ERROR - 2023-09-20 06:06:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:06:20 --> Config Class Initialized
INFO - 2023-09-20 06:06:20 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:06:20 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:06:20 --> Utf8 Class Initialized
INFO - 2023-09-20 06:06:20 --> URI Class Initialized
INFO - 2023-09-20 06:06:20 --> Router Class Initialized
INFO - 2023-09-20 06:06:20 --> Output Class Initialized
INFO - 2023-09-20 06:06:20 --> Security Class Initialized
DEBUG - 2023-09-20 06:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:06:20 --> Input Class Initialized
INFO - 2023-09-20 06:06:20 --> Language Class Initialized
INFO - 2023-09-20 06:06:20 --> Loader Class Initialized
INFO - 2023-09-20 06:06:20 --> Helper loaded: url_helper
INFO - 2023-09-20 06:06:20 --> Helper loaded: file_helper
INFO - 2023-09-20 06:06:20 --> Helper loaded: html_helper
INFO - 2023-09-20 06:06:20 --> Helper loaded: text_helper
INFO - 2023-09-20 06:06:20 --> Helper loaded: form_helper
INFO - 2023-09-20 06:06:20 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:06:20 --> Helper loaded: security_helper
INFO - 2023-09-20 06:06:20 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:06:20 --> Database Driver Class Initialized
INFO - 2023-09-20 06:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:06:20 --> Parser Class Initialized
INFO - 2023-09-20 06:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:06:20 --> Pagination Class Initialized
INFO - 2023-09-20 06:06:20 --> Form Validation Class Initialized
INFO - 2023-09-20 06:06:20 --> Controller Class Initialized
INFO - 2023-09-20 06:06:20 --> Model Class Initialized
DEBUG - 2023-09-20 06:06:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:06:20 --> Model Class Initialized
DEBUG - 2023-09-20 06:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:06:20 --> Model Class Initialized
INFO - 2023-09-20 06:06:20 --> Final output sent to browser
DEBUG - 2023-09-20 06:06:20 --> Total execution time: 0.0402
ERROR - 2023-09-20 06:07:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:07:08 --> Config Class Initialized
INFO - 2023-09-20 06:07:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:07:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:07:08 --> Utf8 Class Initialized
INFO - 2023-09-20 06:07:08 --> URI Class Initialized
INFO - 2023-09-20 06:07:08 --> Router Class Initialized
INFO - 2023-09-20 06:07:08 --> Output Class Initialized
INFO - 2023-09-20 06:07:08 --> Security Class Initialized
DEBUG - 2023-09-20 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:07:08 --> Input Class Initialized
INFO - 2023-09-20 06:07:08 --> Language Class Initialized
INFO - 2023-09-20 06:07:08 --> Loader Class Initialized
INFO - 2023-09-20 06:07:08 --> Helper loaded: url_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: file_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: html_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: text_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: form_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: security_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:07:08 --> Database Driver Class Initialized
INFO - 2023-09-20 06:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:07:08 --> Parser Class Initialized
INFO - 2023-09-20 06:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:07:08 --> Pagination Class Initialized
INFO - 2023-09-20 06:07:08 --> Form Validation Class Initialized
INFO - 2023-09-20 06:07:08 --> Controller Class Initialized
INFO - 2023-09-20 06:07:08 --> Model Class Initialized
DEBUG - 2023-09-20 06:07:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:07:08 --> Model Class Initialized
DEBUG - 2023-09-20 06:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:07:08 --> Model Class Initialized
INFO - 2023-09-20 06:07:08 --> Final output sent to browser
DEBUG - 2023-09-20 06:07:08 --> Total execution time: 0.0416
ERROR - 2023-09-20 06:07:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:07:08 --> Config Class Initialized
INFO - 2023-09-20 06:07:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:07:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:07:08 --> Utf8 Class Initialized
INFO - 2023-09-20 06:07:08 --> URI Class Initialized
INFO - 2023-09-20 06:07:08 --> Router Class Initialized
INFO - 2023-09-20 06:07:08 --> Output Class Initialized
INFO - 2023-09-20 06:07:08 --> Security Class Initialized
DEBUG - 2023-09-20 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:07:08 --> Input Class Initialized
INFO - 2023-09-20 06:07:08 --> Language Class Initialized
INFO - 2023-09-20 06:07:08 --> Loader Class Initialized
INFO - 2023-09-20 06:07:08 --> Helper loaded: url_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: file_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: html_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: text_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: form_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: security_helper
INFO - 2023-09-20 06:07:08 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:07:08 --> Database Driver Class Initialized
INFO - 2023-09-20 06:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:07:08 --> Parser Class Initialized
INFO - 2023-09-20 06:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:07:08 --> Pagination Class Initialized
INFO - 2023-09-20 06:07:08 --> Form Validation Class Initialized
INFO - 2023-09-20 06:07:08 --> Controller Class Initialized
INFO - 2023-09-20 06:07:08 --> Model Class Initialized
DEBUG - 2023-09-20 06:07:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:07:08 --> Model Class Initialized
DEBUG - 2023-09-20 06:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:07:08 --> Model Class Initialized
INFO - 2023-09-20 06:07:08 --> Final output sent to browser
DEBUG - 2023-09-20 06:07:08 --> Total execution time: 0.0394
ERROR - 2023-09-20 06:07:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 06:07:15 --> Config Class Initialized
INFO - 2023-09-20 06:07:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 06:07:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 06:07:15 --> Utf8 Class Initialized
INFO - 2023-09-20 06:07:15 --> URI Class Initialized
INFO - 2023-09-20 06:07:15 --> Router Class Initialized
INFO - 2023-09-20 06:07:15 --> Output Class Initialized
INFO - 2023-09-20 06:07:15 --> Security Class Initialized
DEBUG - 2023-09-20 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 06:07:15 --> Input Class Initialized
INFO - 2023-09-20 06:07:15 --> Language Class Initialized
INFO - 2023-09-20 06:07:15 --> Loader Class Initialized
INFO - 2023-09-20 06:07:15 --> Helper loaded: url_helper
INFO - 2023-09-20 06:07:15 --> Helper loaded: file_helper
INFO - 2023-09-20 06:07:15 --> Helper loaded: html_helper
INFO - 2023-09-20 06:07:15 --> Helper loaded: text_helper
INFO - 2023-09-20 06:07:15 --> Helper loaded: form_helper
INFO - 2023-09-20 06:07:15 --> Helper loaded: lang_helper
INFO - 2023-09-20 06:07:15 --> Helper loaded: security_helper
INFO - 2023-09-20 06:07:15 --> Helper loaded: cookie_helper
INFO - 2023-09-20 06:07:15 --> Database Driver Class Initialized
INFO - 2023-09-20 06:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 06:07:15 --> Parser Class Initialized
INFO - 2023-09-20 06:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 06:07:15 --> Pagination Class Initialized
INFO - 2023-09-20 06:07:15 --> Form Validation Class Initialized
INFO - 2023-09-20 06:07:15 --> Controller Class Initialized
INFO - 2023-09-20 06:07:15 --> Model Class Initialized
DEBUG - 2023-09-20 06:07:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 06:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:07:15 --> Model Class Initialized
DEBUG - 2023-09-20 06:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 06:07:15 --> Model Class Initialized
INFO - 2023-09-20 06:07:15 --> Final output sent to browser
DEBUG - 2023-09-20 06:07:15 --> Total execution time: 0.0290
ERROR - 2023-09-20 07:37:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 07:37:37 --> Config Class Initialized
INFO - 2023-09-20 07:37:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:37:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:37:37 --> Utf8 Class Initialized
INFO - 2023-09-20 07:37:37 --> URI Class Initialized
DEBUG - 2023-09-20 07:37:37 --> No URI present. Default controller set.
INFO - 2023-09-20 07:37:37 --> Router Class Initialized
INFO - 2023-09-20 07:37:37 --> Output Class Initialized
INFO - 2023-09-20 07:37:37 --> Security Class Initialized
DEBUG - 2023-09-20 07:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:37:37 --> Input Class Initialized
INFO - 2023-09-20 07:37:37 --> Language Class Initialized
INFO - 2023-09-20 07:37:37 --> Loader Class Initialized
INFO - 2023-09-20 07:37:37 --> Helper loaded: url_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: file_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: html_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: text_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: form_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: lang_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: security_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: cookie_helper
INFO - 2023-09-20 07:37:37 --> Database Driver Class Initialized
INFO - 2023-09-20 07:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:37:37 --> Parser Class Initialized
INFO - 2023-09-20 07:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 07:37:37 --> Pagination Class Initialized
INFO - 2023-09-20 07:37:37 --> Form Validation Class Initialized
INFO - 2023-09-20 07:37:37 --> Controller Class Initialized
INFO - 2023-09-20 07:37:37 --> Model Class Initialized
DEBUG - 2023-09-20 07:37:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 07:37:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 07:37:37 --> Config Class Initialized
INFO - 2023-09-20 07:37:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 07:37:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 07:37:37 --> Utf8 Class Initialized
INFO - 2023-09-20 07:37:37 --> URI Class Initialized
INFO - 2023-09-20 07:37:37 --> Router Class Initialized
INFO - 2023-09-20 07:37:37 --> Output Class Initialized
INFO - 2023-09-20 07:37:37 --> Security Class Initialized
DEBUG - 2023-09-20 07:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 07:37:37 --> Input Class Initialized
INFO - 2023-09-20 07:37:37 --> Language Class Initialized
INFO - 2023-09-20 07:37:37 --> Loader Class Initialized
INFO - 2023-09-20 07:37:37 --> Helper loaded: url_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: file_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: html_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: text_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: form_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: lang_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: security_helper
INFO - 2023-09-20 07:37:37 --> Helper loaded: cookie_helper
INFO - 2023-09-20 07:37:37 --> Database Driver Class Initialized
INFO - 2023-09-20 07:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 07:37:37 --> Parser Class Initialized
INFO - 2023-09-20 07:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 07:37:37 --> Pagination Class Initialized
INFO - 2023-09-20 07:37:37 --> Form Validation Class Initialized
INFO - 2023-09-20 07:37:37 --> Controller Class Initialized
INFO - 2023-09-20 07:37:37 --> Model Class Initialized
DEBUG - 2023-09-20 07:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 07:37:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 07:37:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 07:37:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 07:37:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 07:37:37 --> Model Class Initialized
INFO - 2023-09-20 07:37:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 07:37:37 --> Final output sent to browser
DEBUG - 2023-09-20 07:37:37 --> Total execution time: 0.0329
ERROR - 2023-09-20 09:21:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:21:05 --> Config Class Initialized
INFO - 2023-09-20 09:21:05 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:21:05 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:21:05 --> Utf8 Class Initialized
INFO - 2023-09-20 09:21:05 --> URI Class Initialized
DEBUG - 2023-09-20 09:21:05 --> No URI present. Default controller set.
INFO - 2023-09-20 09:21:05 --> Router Class Initialized
INFO - 2023-09-20 09:21:05 --> Output Class Initialized
INFO - 2023-09-20 09:21:05 --> Security Class Initialized
DEBUG - 2023-09-20 09:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:21:05 --> Input Class Initialized
INFO - 2023-09-20 09:21:05 --> Language Class Initialized
INFO - 2023-09-20 09:21:05 --> Loader Class Initialized
INFO - 2023-09-20 09:21:05 --> Helper loaded: url_helper
INFO - 2023-09-20 09:21:05 --> Helper loaded: file_helper
INFO - 2023-09-20 09:21:05 --> Helper loaded: html_helper
INFO - 2023-09-20 09:21:05 --> Helper loaded: text_helper
INFO - 2023-09-20 09:21:05 --> Helper loaded: form_helper
INFO - 2023-09-20 09:21:05 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:21:05 --> Helper loaded: security_helper
INFO - 2023-09-20 09:21:05 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:21:05 --> Database Driver Class Initialized
INFO - 2023-09-20 09:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:21:05 --> Parser Class Initialized
INFO - 2023-09-20 09:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:21:05 --> Pagination Class Initialized
INFO - 2023-09-20 09:21:05 --> Form Validation Class Initialized
INFO - 2023-09-20 09:21:05 --> Controller Class Initialized
INFO - 2023-09-20 09:21:05 --> Model Class Initialized
DEBUG - 2023-09-20 09:21:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 09:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:21:06 --> Config Class Initialized
INFO - 2023-09-20 09:21:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:21:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:21:06 --> Utf8 Class Initialized
INFO - 2023-09-20 09:21:06 --> URI Class Initialized
INFO - 2023-09-20 09:21:06 --> Router Class Initialized
INFO - 2023-09-20 09:21:06 --> Output Class Initialized
INFO - 2023-09-20 09:21:06 --> Security Class Initialized
DEBUG - 2023-09-20 09:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:21:06 --> Input Class Initialized
INFO - 2023-09-20 09:21:06 --> Language Class Initialized
INFO - 2023-09-20 09:21:06 --> Loader Class Initialized
INFO - 2023-09-20 09:21:06 --> Helper loaded: url_helper
INFO - 2023-09-20 09:21:06 --> Helper loaded: file_helper
INFO - 2023-09-20 09:21:06 --> Helper loaded: html_helper
INFO - 2023-09-20 09:21:06 --> Helper loaded: text_helper
INFO - 2023-09-20 09:21:06 --> Helper loaded: form_helper
INFO - 2023-09-20 09:21:06 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:21:06 --> Helper loaded: security_helper
INFO - 2023-09-20 09:21:06 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:21:06 --> Database Driver Class Initialized
INFO - 2023-09-20 09:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:21:06 --> Parser Class Initialized
INFO - 2023-09-20 09:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:21:06 --> Pagination Class Initialized
INFO - 2023-09-20 09:21:06 --> Form Validation Class Initialized
INFO - 2023-09-20 09:21:06 --> Controller Class Initialized
INFO - 2023-09-20 09:21:06 --> Model Class Initialized
DEBUG - 2023-09-20 09:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 09:21:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:21:06 --> Model Class Initialized
INFO - 2023-09-20 09:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:21:06 --> Final output sent to browser
DEBUG - 2023-09-20 09:21:06 --> Total execution time: 0.0358
ERROR - 2023-09-20 09:21:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:21:09 --> Config Class Initialized
INFO - 2023-09-20 09:21:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:21:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:21:09 --> Utf8 Class Initialized
INFO - 2023-09-20 09:21:09 --> URI Class Initialized
INFO - 2023-09-20 09:21:09 --> Router Class Initialized
INFO - 2023-09-20 09:21:09 --> Output Class Initialized
INFO - 2023-09-20 09:21:09 --> Security Class Initialized
DEBUG - 2023-09-20 09:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:21:09 --> Input Class Initialized
INFO - 2023-09-20 09:21:09 --> Language Class Initialized
INFO - 2023-09-20 09:21:09 --> Loader Class Initialized
INFO - 2023-09-20 09:21:09 --> Helper loaded: url_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: file_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: html_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: text_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: form_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: security_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:21:09 --> Database Driver Class Initialized
INFO - 2023-09-20 09:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:21:09 --> Parser Class Initialized
INFO - 2023-09-20 09:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:21:09 --> Pagination Class Initialized
INFO - 2023-09-20 09:21:09 --> Form Validation Class Initialized
INFO - 2023-09-20 09:21:09 --> Controller Class Initialized
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
DEBUG - 2023-09-20 09:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
INFO - 2023-09-20 09:21:09 --> Final output sent to browser
DEBUG - 2023-09-20 09:21:09 --> Total execution time: 0.0175
ERROR - 2023-09-20 09:21:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:21:09 --> Config Class Initialized
INFO - 2023-09-20 09:21:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:21:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:21:09 --> Utf8 Class Initialized
INFO - 2023-09-20 09:21:09 --> URI Class Initialized
DEBUG - 2023-09-20 09:21:09 --> No URI present. Default controller set.
INFO - 2023-09-20 09:21:09 --> Router Class Initialized
INFO - 2023-09-20 09:21:09 --> Output Class Initialized
INFO - 2023-09-20 09:21:09 --> Security Class Initialized
DEBUG - 2023-09-20 09:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:21:09 --> Input Class Initialized
INFO - 2023-09-20 09:21:09 --> Language Class Initialized
INFO - 2023-09-20 09:21:09 --> Loader Class Initialized
INFO - 2023-09-20 09:21:09 --> Helper loaded: url_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: file_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: html_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: text_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: form_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: security_helper
INFO - 2023-09-20 09:21:09 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:21:09 --> Database Driver Class Initialized
INFO - 2023-09-20 09:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:21:09 --> Parser Class Initialized
INFO - 2023-09-20 09:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:21:09 --> Pagination Class Initialized
INFO - 2023-09-20 09:21:09 --> Form Validation Class Initialized
INFO - 2023-09-20 09:21:09 --> Controller Class Initialized
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
DEBUG - 2023-09-20 09:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
DEBUG - 2023-09-20 09:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
DEBUG - 2023-09-20 09:21:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
INFO - 2023-09-20 09:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 09:21:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:21:09 --> Model Class Initialized
INFO - 2023-09-20 09:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:21:09 --> Final output sent to browser
DEBUG - 2023-09-20 09:21:09 --> Total execution time: 0.1972
ERROR - 2023-09-20 09:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:21:10 --> Config Class Initialized
INFO - 2023-09-20 09:21:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:21:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:21:10 --> Utf8 Class Initialized
INFO - 2023-09-20 09:21:10 --> URI Class Initialized
INFO - 2023-09-20 09:21:10 --> Router Class Initialized
INFO - 2023-09-20 09:21:10 --> Output Class Initialized
INFO - 2023-09-20 09:21:10 --> Security Class Initialized
DEBUG - 2023-09-20 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:21:10 --> Input Class Initialized
INFO - 2023-09-20 09:21:10 --> Language Class Initialized
INFO - 2023-09-20 09:21:10 --> Loader Class Initialized
INFO - 2023-09-20 09:21:10 --> Helper loaded: url_helper
INFO - 2023-09-20 09:21:10 --> Helper loaded: file_helper
INFO - 2023-09-20 09:21:10 --> Helper loaded: html_helper
INFO - 2023-09-20 09:21:10 --> Helper loaded: text_helper
INFO - 2023-09-20 09:21:10 --> Helper loaded: form_helper
INFO - 2023-09-20 09:21:10 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:21:10 --> Helper loaded: security_helper
INFO - 2023-09-20 09:21:10 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:21:10 --> Database Driver Class Initialized
INFO - 2023-09-20 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:21:10 --> Parser Class Initialized
INFO - 2023-09-20 09:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:21:10 --> Pagination Class Initialized
INFO - 2023-09-20 09:21:10 --> Form Validation Class Initialized
INFO - 2023-09-20 09:21:10 --> Controller Class Initialized
DEBUG - 2023-09-20 09:21:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:21:10 --> Model Class Initialized
INFO - 2023-09-20 09:21:10 --> Final output sent to browser
DEBUG - 2023-09-20 09:21:10 --> Total execution time: 0.0132
ERROR - 2023-09-20 09:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:23:07 --> Config Class Initialized
INFO - 2023-09-20 09:23:07 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:23:07 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:23:07 --> Utf8 Class Initialized
INFO - 2023-09-20 09:23:07 --> URI Class Initialized
DEBUG - 2023-09-20 09:23:07 --> No URI present. Default controller set.
INFO - 2023-09-20 09:23:07 --> Router Class Initialized
INFO - 2023-09-20 09:23:07 --> Output Class Initialized
INFO - 2023-09-20 09:23:07 --> Security Class Initialized
DEBUG - 2023-09-20 09:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:23:07 --> Input Class Initialized
INFO - 2023-09-20 09:23:07 --> Language Class Initialized
INFO - 2023-09-20 09:23:07 --> Loader Class Initialized
INFO - 2023-09-20 09:23:07 --> Helper loaded: url_helper
INFO - 2023-09-20 09:23:07 --> Helper loaded: file_helper
INFO - 2023-09-20 09:23:07 --> Helper loaded: html_helper
INFO - 2023-09-20 09:23:07 --> Helper loaded: text_helper
INFO - 2023-09-20 09:23:07 --> Helper loaded: form_helper
INFO - 2023-09-20 09:23:07 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:23:07 --> Helper loaded: security_helper
INFO - 2023-09-20 09:23:07 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:23:07 --> Database Driver Class Initialized
INFO - 2023-09-20 09:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:23:07 --> Parser Class Initialized
INFO - 2023-09-20 09:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:23:07 --> Pagination Class Initialized
INFO - 2023-09-20 09:23:07 --> Form Validation Class Initialized
INFO - 2023-09-20 09:23:07 --> Controller Class Initialized
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
DEBUG - 2023-09-20 09:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
DEBUG - 2023-09-20 09:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
DEBUG - 2023-09-20 09:23:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
INFO - 2023-09-20 09:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 09:23:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:23:07 --> Model Class Initialized
INFO - 2023-09-20 09:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:23:07 --> Final output sent to browser
DEBUG - 2023-09-20 09:23:07 --> Total execution time: 0.2214
ERROR - 2023-09-20 09:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:28:26 --> Config Class Initialized
INFO - 2023-09-20 09:28:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:28:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:28:26 --> Utf8 Class Initialized
INFO - 2023-09-20 09:28:26 --> URI Class Initialized
DEBUG - 2023-09-20 09:28:26 --> No URI present. Default controller set.
INFO - 2023-09-20 09:28:26 --> Router Class Initialized
INFO - 2023-09-20 09:28:26 --> Output Class Initialized
INFO - 2023-09-20 09:28:26 --> Security Class Initialized
DEBUG - 2023-09-20 09:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:28:26 --> Input Class Initialized
INFO - 2023-09-20 09:28:26 --> Language Class Initialized
INFO - 2023-09-20 09:28:26 --> Loader Class Initialized
INFO - 2023-09-20 09:28:26 --> Helper loaded: url_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: file_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: html_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: text_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: form_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: security_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:28:26 --> Database Driver Class Initialized
INFO - 2023-09-20 09:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:28:26 --> Parser Class Initialized
INFO - 2023-09-20 09:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:28:26 --> Pagination Class Initialized
INFO - 2023-09-20 09:28:26 --> Form Validation Class Initialized
INFO - 2023-09-20 09:28:26 --> Controller Class Initialized
INFO - 2023-09-20 09:28:26 --> Model Class Initialized
DEBUG - 2023-09-20 09:28:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 09:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:28:26 --> Config Class Initialized
INFO - 2023-09-20 09:28:26 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:28:26 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:28:26 --> Utf8 Class Initialized
INFO - 2023-09-20 09:28:26 --> URI Class Initialized
INFO - 2023-09-20 09:28:26 --> Router Class Initialized
INFO - 2023-09-20 09:28:26 --> Output Class Initialized
INFO - 2023-09-20 09:28:26 --> Security Class Initialized
DEBUG - 2023-09-20 09:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:28:26 --> Input Class Initialized
INFO - 2023-09-20 09:28:26 --> Language Class Initialized
INFO - 2023-09-20 09:28:26 --> Loader Class Initialized
INFO - 2023-09-20 09:28:26 --> Helper loaded: url_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: file_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: html_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: text_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: form_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: security_helper
INFO - 2023-09-20 09:28:26 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:28:26 --> Database Driver Class Initialized
INFO - 2023-09-20 09:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:28:26 --> Parser Class Initialized
INFO - 2023-09-20 09:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:28:26 --> Pagination Class Initialized
INFO - 2023-09-20 09:28:26 --> Form Validation Class Initialized
INFO - 2023-09-20 09:28:26 --> Controller Class Initialized
INFO - 2023-09-20 09:28:26 --> Model Class Initialized
DEBUG - 2023-09-20 09:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 09:28:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:28:26 --> Model Class Initialized
INFO - 2023-09-20 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:28:26 --> Final output sent to browser
DEBUG - 2023-09-20 09:28:26 --> Total execution time: 0.0290
ERROR - 2023-09-20 09:29:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:29:16 --> Config Class Initialized
INFO - 2023-09-20 09:29:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:29:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:29:16 --> Utf8 Class Initialized
INFO - 2023-09-20 09:29:16 --> URI Class Initialized
INFO - 2023-09-20 09:29:16 --> Router Class Initialized
INFO - 2023-09-20 09:29:16 --> Output Class Initialized
INFO - 2023-09-20 09:29:16 --> Security Class Initialized
DEBUG - 2023-09-20 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:29:16 --> Input Class Initialized
INFO - 2023-09-20 09:29:16 --> Language Class Initialized
INFO - 2023-09-20 09:29:16 --> Loader Class Initialized
INFO - 2023-09-20 09:29:16 --> Helper loaded: url_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: file_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: html_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: text_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: form_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: security_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:29:16 --> Database Driver Class Initialized
INFO - 2023-09-20 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:29:16 --> Parser Class Initialized
INFO - 2023-09-20 09:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:29:16 --> Pagination Class Initialized
INFO - 2023-09-20 09:29:16 --> Form Validation Class Initialized
INFO - 2023-09-20 09:29:16 --> Controller Class Initialized
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
INFO - 2023-09-20 09:29:16 --> Final output sent to browser
DEBUG - 2023-09-20 09:29:16 --> Total execution time: 0.0202
ERROR - 2023-09-20 09:29:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:29:16 --> Config Class Initialized
INFO - 2023-09-20 09:29:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:29:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:29:16 --> Utf8 Class Initialized
INFO - 2023-09-20 09:29:16 --> URI Class Initialized
DEBUG - 2023-09-20 09:29:16 --> No URI present. Default controller set.
INFO - 2023-09-20 09:29:16 --> Router Class Initialized
INFO - 2023-09-20 09:29:16 --> Output Class Initialized
INFO - 2023-09-20 09:29:16 --> Security Class Initialized
DEBUG - 2023-09-20 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:29:16 --> Input Class Initialized
INFO - 2023-09-20 09:29:16 --> Language Class Initialized
INFO - 2023-09-20 09:29:16 --> Loader Class Initialized
INFO - 2023-09-20 09:29:16 --> Helper loaded: url_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: file_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: html_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: text_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: form_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: security_helper
INFO - 2023-09-20 09:29:16 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:29:16 --> Database Driver Class Initialized
INFO - 2023-09-20 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:29:16 --> Parser Class Initialized
INFO - 2023-09-20 09:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:29:16 --> Pagination Class Initialized
INFO - 2023-09-20 09:29:16 --> Form Validation Class Initialized
INFO - 2023-09-20 09:29:16 --> Controller Class Initialized
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
INFO - 2023-09-20 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 09:29:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:29:16 --> Model Class Initialized
INFO - 2023-09-20 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:29:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:29:16 --> Final output sent to browser
DEBUG - 2023-09-20 09:29:16 --> Total execution time: 0.0935
ERROR - 2023-09-20 09:29:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:29:48 --> Config Class Initialized
INFO - 2023-09-20 09:29:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:29:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:29:48 --> Utf8 Class Initialized
INFO - 2023-09-20 09:29:48 --> URI Class Initialized
INFO - 2023-09-20 09:29:48 --> Router Class Initialized
INFO - 2023-09-20 09:29:48 --> Output Class Initialized
INFO - 2023-09-20 09:29:48 --> Security Class Initialized
DEBUG - 2023-09-20 09:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:29:48 --> Input Class Initialized
INFO - 2023-09-20 09:29:48 --> Language Class Initialized
INFO - 2023-09-20 09:29:48 --> Loader Class Initialized
INFO - 2023-09-20 09:29:48 --> Helper loaded: url_helper
INFO - 2023-09-20 09:29:48 --> Helper loaded: file_helper
INFO - 2023-09-20 09:29:48 --> Helper loaded: html_helper
INFO - 2023-09-20 09:29:48 --> Helper loaded: text_helper
INFO - 2023-09-20 09:29:48 --> Helper loaded: form_helper
INFO - 2023-09-20 09:29:48 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:29:48 --> Helper loaded: security_helper
INFO - 2023-09-20 09:29:48 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:29:48 --> Database Driver Class Initialized
INFO - 2023-09-20 09:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:29:48 --> Parser Class Initialized
INFO - 2023-09-20 09:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:29:48 --> Pagination Class Initialized
INFO - 2023-09-20 09:29:48 --> Form Validation Class Initialized
INFO - 2023-09-20 09:29:48 --> Controller Class Initialized
INFO - 2023-09-20 09:29:48 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:48 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:48 --> Model Class Initialized
INFO - 2023-09-20 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 09:29:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:29:48 --> Model Class Initialized
INFO - 2023-09-20 09:29:48 --> Model Class Initialized
INFO - 2023-09-20 09:29:48 --> Model Class Initialized
INFO - 2023-09-20 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:29:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:29:48 --> Final output sent to browser
DEBUG - 2023-09-20 09:29:48 --> Total execution time: 0.0754
ERROR - 2023-09-20 09:29:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:29:49 --> Config Class Initialized
INFO - 2023-09-20 09:29:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:29:49 --> Utf8 Class Initialized
INFO - 2023-09-20 09:29:49 --> URI Class Initialized
INFO - 2023-09-20 09:29:49 --> Router Class Initialized
INFO - 2023-09-20 09:29:49 --> Output Class Initialized
INFO - 2023-09-20 09:29:49 --> Security Class Initialized
DEBUG - 2023-09-20 09:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:29:49 --> Input Class Initialized
INFO - 2023-09-20 09:29:49 --> Language Class Initialized
INFO - 2023-09-20 09:29:49 --> Loader Class Initialized
INFO - 2023-09-20 09:29:49 --> Helper loaded: url_helper
INFO - 2023-09-20 09:29:49 --> Helper loaded: file_helper
INFO - 2023-09-20 09:29:49 --> Helper loaded: html_helper
INFO - 2023-09-20 09:29:49 --> Helper loaded: text_helper
INFO - 2023-09-20 09:29:49 --> Helper loaded: form_helper
INFO - 2023-09-20 09:29:49 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:29:49 --> Helper loaded: security_helper
INFO - 2023-09-20 09:29:49 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:29:49 --> Database Driver Class Initialized
INFO - 2023-09-20 09:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:29:49 --> Parser Class Initialized
INFO - 2023-09-20 09:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:29:49 --> Pagination Class Initialized
INFO - 2023-09-20 09:29:49 --> Form Validation Class Initialized
INFO - 2023-09-20 09:29:49 --> Controller Class Initialized
INFO - 2023-09-20 09:29:49 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:49 --> Model Class Initialized
DEBUG - 2023-09-20 09:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:29:49 --> Model Class Initialized
INFO - 2023-09-20 09:29:49 --> Final output sent to browser
DEBUG - 2023-09-20 09:29:49 --> Total execution time: 0.0304
ERROR - 2023-09-20 09:30:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:30:34 --> Config Class Initialized
INFO - 2023-09-20 09:30:34 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:30:34 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:30:34 --> Utf8 Class Initialized
INFO - 2023-09-20 09:30:34 --> URI Class Initialized
INFO - 2023-09-20 09:30:34 --> Router Class Initialized
INFO - 2023-09-20 09:30:34 --> Output Class Initialized
INFO - 2023-09-20 09:30:34 --> Security Class Initialized
DEBUG - 2023-09-20 09:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:30:34 --> Input Class Initialized
INFO - 2023-09-20 09:30:34 --> Language Class Initialized
INFO - 2023-09-20 09:30:34 --> Loader Class Initialized
INFO - 2023-09-20 09:30:34 --> Helper loaded: url_helper
INFO - 2023-09-20 09:30:34 --> Helper loaded: file_helper
INFO - 2023-09-20 09:30:34 --> Helper loaded: html_helper
INFO - 2023-09-20 09:30:34 --> Helper loaded: text_helper
INFO - 2023-09-20 09:30:34 --> Helper loaded: form_helper
INFO - 2023-09-20 09:30:34 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:30:34 --> Helper loaded: security_helper
INFO - 2023-09-20 09:30:34 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:30:34 --> Database Driver Class Initialized
INFO - 2023-09-20 09:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:30:34 --> Parser Class Initialized
INFO - 2023-09-20 09:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:30:34 --> Pagination Class Initialized
INFO - 2023-09-20 09:30:34 --> Form Validation Class Initialized
INFO - 2023-09-20 09:30:34 --> Controller Class Initialized
INFO - 2023-09-20 09:30:34 --> Model Class Initialized
DEBUG - 2023-09-20 09:30:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:30:34 --> Model Class Initialized
DEBUG - 2023-09-20 09:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:30:34 --> Model Class Initialized
DEBUG - 2023-09-20 09:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-20 09:30:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:30:34 --> Model Class Initialized
INFO - 2023-09-20 09:30:34 --> Model Class Initialized
INFO - 2023-09-20 09:30:34 --> Model Class Initialized
INFO - 2023-09-20 09:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:30:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:30:34 --> Final output sent to browser
DEBUG - 2023-09-20 09:30:34 --> Total execution time: 0.0860
ERROR - 2023-09-20 09:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:30:58 --> Config Class Initialized
INFO - 2023-09-20 09:30:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:30:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:30:58 --> Utf8 Class Initialized
INFO - 2023-09-20 09:30:58 --> URI Class Initialized
DEBUG - 2023-09-20 09:30:58 --> No URI present. Default controller set.
INFO - 2023-09-20 09:30:58 --> Router Class Initialized
INFO - 2023-09-20 09:30:58 --> Output Class Initialized
INFO - 2023-09-20 09:30:58 --> Security Class Initialized
DEBUG - 2023-09-20 09:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:30:58 --> Input Class Initialized
INFO - 2023-09-20 09:30:58 --> Language Class Initialized
INFO - 2023-09-20 09:30:58 --> Loader Class Initialized
INFO - 2023-09-20 09:30:58 --> Helper loaded: url_helper
INFO - 2023-09-20 09:30:58 --> Helper loaded: file_helper
INFO - 2023-09-20 09:30:58 --> Helper loaded: html_helper
INFO - 2023-09-20 09:30:58 --> Helper loaded: text_helper
INFO - 2023-09-20 09:30:58 --> Helper loaded: form_helper
INFO - 2023-09-20 09:30:58 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:30:58 --> Helper loaded: security_helper
INFO - 2023-09-20 09:30:58 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:30:58 --> Database Driver Class Initialized
INFO - 2023-09-20 09:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:30:58 --> Parser Class Initialized
INFO - 2023-09-20 09:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:30:58 --> Pagination Class Initialized
INFO - 2023-09-20 09:30:58 --> Form Validation Class Initialized
INFO - 2023-09-20 09:30:58 --> Controller Class Initialized
INFO - 2023-09-20 09:30:58 --> Model Class Initialized
DEBUG - 2023-09-20 09:30:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 09:30:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:30:59 --> Config Class Initialized
INFO - 2023-09-20 09:30:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:30:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:30:59 --> Utf8 Class Initialized
INFO - 2023-09-20 09:30:59 --> URI Class Initialized
INFO - 2023-09-20 09:30:59 --> Router Class Initialized
INFO - 2023-09-20 09:30:59 --> Output Class Initialized
INFO - 2023-09-20 09:30:59 --> Security Class Initialized
DEBUG - 2023-09-20 09:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:30:59 --> Input Class Initialized
INFO - 2023-09-20 09:30:59 --> Language Class Initialized
INFO - 2023-09-20 09:30:59 --> Loader Class Initialized
INFO - 2023-09-20 09:30:59 --> Helper loaded: url_helper
INFO - 2023-09-20 09:30:59 --> Helper loaded: file_helper
INFO - 2023-09-20 09:30:59 --> Helper loaded: html_helper
INFO - 2023-09-20 09:30:59 --> Helper loaded: text_helper
INFO - 2023-09-20 09:30:59 --> Helper loaded: form_helper
INFO - 2023-09-20 09:30:59 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:30:59 --> Helper loaded: security_helper
INFO - 2023-09-20 09:30:59 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:30:59 --> Database Driver Class Initialized
INFO - 2023-09-20 09:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:30:59 --> Parser Class Initialized
INFO - 2023-09-20 09:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:30:59 --> Pagination Class Initialized
INFO - 2023-09-20 09:30:59 --> Form Validation Class Initialized
INFO - 2023-09-20 09:30:59 --> Controller Class Initialized
INFO - 2023-09-20 09:30:59 --> Model Class Initialized
DEBUG - 2023-09-20 09:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 09:30:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:30:59 --> Model Class Initialized
INFO - 2023-09-20 09:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:30:59 --> Final output sent to browser
DEBUG - 2023-09-20 09:30:59 --> Total execution time: 0.0297
ERROR - 2023-09-20 09:31:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:31:19 --> Config Class Initialized
INFO - 2023-09-20 09:31:19 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:31:19 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:31:19 --> Utf8 Class Initialized
INFO - 2023-09-20 09:31:19 --> URI Class Initialized
INFO - 2023-09-20 09:31:19 --> Router Class Initialized
INFO - 2023-09-20 09:31:19 --> Output Class Initialized
INFO - 2023-09-20 09:31:19 --> Security Class Initialized
DEBUG - 2023-09-20 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:31:19 --> Input Class Initialized
INFO - 2023-09-20 09:31:19 --> Language Class Initialized
INFO - 2023-09-20 09:31:19 --> Loader Class Initialized
INFO - 2023-09-20 09:31:19 --> Helper loaded: url_helper
INFO - 2023-09-20 09:31:19 --> Helper loaded: file_helper
INFO - 2023-09-20 09:31:19 --> Helper loaded: html_helper
INFO - 2023-09-20 09:31:19 --> Helper loaded: text_helper
INFO - 2023-09-20 09:31:19 --> Helper loaded: form_helper
INFO - 2023-09-20 09:31:19 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:31:19 --> Helper loaded: security_helper
INFO - 2023-09-20 09:31:19 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:31:19 --> Database Driver Class Initialized
INFO - 2023-09-20 09:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:31:19 --> Parser Class Initialized
INFO - 2023-09-20 09:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:31:19 --> Pagination Class Initialized
INFO - 2023-09-20 09:31:19 --> Form Validation Class Initialized
INFO - 2023-09-20 09:31:19 --> Controller Class Initialized
INFO - 2023-09-20 09:31:19 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:19 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:19 --> Model Class Initialized
INFO - 2023-09-20 09:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 09:31:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:31:19 --> Model Class Initialized
INFO - 2023-09-20 09:31:19 --> Model Class Initialized
INFO - 2023-09-20 09:31:19 --> Model Class Initialized
INFO - 2023-09-20 09:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:31:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:31:19 --> Final output sent to browser
DEBUG - 2023-09-20 09:31:19 --> Total execution time: 0.0733
ERROR - 2023-09-20 09:31:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:31:23 --> Config Class Initialized
INFO - 2023-09-20 09:31:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:31:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:31:23 --> Utf8 Class Initialized
INFO - 2023-09-20 09:31:23 --> URI Class Initialized
INFO - 2023-09-20 09:31:23 --> Router Class Initialized
INFO - 2023-09-20 09:31:23 --> Output Class Initialized
INFO - 2023-09-20 09:31:23 --> Security Class Initialized
DEBUG - 2023-09-20 09:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:31:23 --> Input Class Initialized
INFO - 2023-09-20 09:31:23 --> Language Class Initialized
INFO - 2023-09-20 09:31:23 --> Loader Class Initialized
INFO - 2023-09-20 09:31:23 --> Helper loaded: url_helper
INFO - 2023-09-20 09:31:23 --> Helper loaded: file_helper
INFO - 2023-09-20 09:31:23 --> Helper loaded: html_helper
INFO - 2023-09-20 09:31:23 --> Helper loaded: text_helper
INFO - 2023-09-20 09:31:23 --> Helper loaded: form_helper
INFO - 2023-09-20 09:31:23 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:31:23 --> Helper loaded: security_helper
INFO - 2023-09-20 09:31:23 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:31:23 --> Database Driver Class Initialized
INFO - 2023-09-20 09:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:31:23 --> Parser Class Initialized
INFO - 2023-09-20 09:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:31:23 --> Pagination Class Initialized
INFO - 2023-09-20 09:31:23 --> Form Validation Class Initialized
INFO - 2023-09-20 09:31:23 --> Controller Class Initialized
INFO - 2023-09-20 09:31:23 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:31:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:23 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:23 --> Model Class Initialized
INFO - 2023-09-20 09:31:23 --> Final output sent to browser
DEBUG - 2023-09-20 09:31:23 --> Total execution time: 0.0305
ERROR - 2023-09-20 09:31:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:31:30 --> Config Class Initialized
INFO - 2023-09-20 09:31:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:31:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:31:30 --> Utf8 Class Initialized
INFO - 2023-09-20 09:31:30 --> URI Class Initialized
INFO - 2023-09-20 09:31:30 --> Router Class Initialized
INFO - 2023-09-20 09:31:30 --> Output Class Initialized
INFO - 2023-09-20 09:31:30 --> Security Class Initialized
DEBUG - 2023-09-20 09:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:31:30 --> Input Class Initialized
INFO - 2023-09-20 09:31:30 --> Language Class Initialized
INFO - 2023-09-20 09:31:30 --> Loader Class Initialized
INFO - 2023-09-20 09:31:30 --> Helper loaded: url_helper
INFO - 2023-09-20 09:31:30 --> Helper loaded: file_helper
INFO - 2023-09-20 09:31:30 --> Helper loaded: html_helper
INFO - 2023-09-20 09:31:30 --> Helper loaded: text_helper
INFO - 2023-09-20 09:31:30 --> Helper loaded: form_helper
INFO - 2023-09-20 09:31:30 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:31:30 --> Helper loaded: security_helper
INFO - 2023-09-20 09:31:30 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:31:30 --> Database Driver Class Initialized
INFO - 2023-09-20 09:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:31:30 --> Parser Class Initialized
INFO - 2023-09-20 09:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:31:30 --> Pagination Class Initialized
INFO - 2023-09-20 09:31:30 --> Form Validation Class Initialized
INFO - 2023-09-20 09:31:30 --> Controller Class Initialized
INFO - 2023-09-20 09:31:30 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:30 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:30 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-20 09:31:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:31:30 --> Model Class Initialized
INFO - 2023-09-20 09:31:30 --> Model Class Initialized
INFO - 2023-09-20 09:31:30 --> Model Class Initialized
INFO - 2023-09-20 09:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:31:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:31:30 --> Final output sent to browser
DEBUG - 2023-09-20 09:31:30 --> Total execution time: 0.0789
ERROR - 2023-09-20 09:31:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:31:50 --> Config Class Initialized
INFO - 2023-09-20 09:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:31:50 --> Utf8 Class Initialized
INFO - 2023-09-20 09:31:50 --> URI Class Initialized
INFO - 2023-09-20 09:31:50 --> Router Class Initialized
INFO - 2023-09-20 09:31:50 --> Output Class Initialized
INFO - 2023-09-20 09:31:50 --> Security Class Initialized
DEBUG - 2023-09-20 09:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:31:50 --> Input Class Initialized
INFO - 2023-09-20 09:31:50 --> Language Class Initialized
INFO - 2023-09-20 09:31:50 --> Loader Class Initialized
INFO - 2023-09-20 09:31:50 --> Helper loaded: url_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: file_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: html_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: text_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: form_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: security_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:31:50 --> Database Driver Class Initialized
INFO - 2023-09-20 09:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:31:50 --> Parser Class Initialized
INFO - 2023-09-20 09:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:31:50 --> Pagination Class Initialized
INFO - 2023-09-20 09:31:50 --> Form Validation Class Initialized
INFO - 2023-09-20 09:31:50 --> Controller Class Initialized
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
INFO - 2023-09-20 09:31:50 --> Final output sent to browser
DEBUG - 2023-09-20 09:31:50 --> Total execution time: 0.0189
ERROR - 2023-09-20 09:31:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:31:50 --> Config Class Initialized
INFO - 2023-09-20 09:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:31:50 --> Utf8 Class Initialized
INFO - 2023-09-20 09:31:50 --> URI Class Initialized
DEBUG - 2023-09-20 09:31:50 --> No URI present. Default controller set.
INFO - 2023-09-20 09:31:50 --> Router Class Initialized
INFO - 2023-09-20 09:31:50 --> Output Class Initialized
INFO - 2023-09-20 09:31:50 --> Security Class Initialized
DEBUG - 2023-09-20 09:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:31:50 --> Input Class Initialized
INFO - 2023-09-20 09:31:50 --> Language Class Initialized
INFO - 2023-09-20 09:31:50 --> Loader Class Initialized
INFO - 2023-09-20 09:31:50 --> Helper loaded: url_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: file_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: html_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: text_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: form_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: security_helper
INFO - 2023-09-20 09:31:50 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:31:50 --> Database Driver Class Initialized
INFO - 2023-09-20 09:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:31:50 --> Parser Class Initialized
INFO - 2023-09-20 09:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:31:50 --> Pagination Class Initialized
INFO - 2023-09-20 09:31:50 --> Form Validation Class Initialized
INFO - 2023-09-20 09:31:50 --> Controller Class Initialized
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
DEBUG - 2023-09-20 09:31:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
INFO - 2023-09-20 09:31:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 09:31:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:31:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:31:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:31:50 --> Model Class Initialized
INFO - 2023-09-20 09:31:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:31:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:31:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:31:51 --> Final output sent to browser
DEBUG - 2023-09-20 09:31:51 --> Total execution time: 0.1010
ERROR - 2023-09-20 09:32:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:32:21 --> Config Class Initialized
INFO - 2023-09-20 09:32:21 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:32:21 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:32:21 --> Utf8 Class Initialized
INFO - 2023-09-20 09:32:21 --> URI Class Initialized
INFO - 2023-09-20 09:32:21 --> Router Class Initialized
INFO - 2023-09-20 09:32:21 --> Output Class Initialized
INFO - 2023-09-20 09:32:21 --> Security Class Initialized
DEBUG - 2023-09-20 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:32:21 --> Input Class Initialized
INFO - 2023-09-20 09:32:21 --> Language Class Initialized
INFO - 2023-09-20 09:32:21 --> Loader Class Initialized
INFO - 2023-09-20 09:32:21 --> Helper loaded: url_helper
INFO - 2023-09-20 09:32:21 --> Helper loaded: file_helper
INFO - 2023-09-20 09:32:21 --> Helper loaded: html_helper
INFO - 2023-09-20 09:32:21 --> Helper loaded: text_helper
INFO - 2023-09-20 09:32:21 --> Helper loaded: form_helper
INFO - 2023-09-20 09:32:21 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:32:21 --> Helper loaded: security_helper
INFO - 2023-09-20 09:32:21 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:32:21 --> Database Driver Class Initialized
INFO - 2023-09-20 09:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:32:21 --> Parser Class Initialized
INFO - 2023-09-20 09:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:32:21 --> Pagination Class Initialized
INFO - 2023-09-20 09:32:21 --> Form Validation Class Initialized
INFO - 2023-09-20 09:32:21 --> Controller Class Initialized
INFO - 2023-09-20 09:32:21 --> Model Class Initialized
DEBUG - 2023-09-20 09:32:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:32:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:32:21 --> Model Class Initialized
DEBUG - 2023-09-20 09:32:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:32:21 --> Model Class Initialized
INFO - 2023-09-20 09:32:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 09:32:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:32:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 09:32:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 09:32:21 --> Model Class Initialized
INFO - 2023-09-20 09:32:21 --> Model Class Initialized
INFO - 2023-09-20 09:32:21 --> Model Class Initialized
INFO - 2023-09-20 09:32:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 09:32:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 09:32:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 09:32:21 --> Final output sent to browser
DEBUG - 2023-09-20 09:32:21 --> Total execution time: 0.0802
ERROR - 2023-09-20 09:32:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 09:32:24 --> Config Class Initialized
INFO - 2023-09-20 09:32:24 --> Hooks Class Initialized
DEBUG - 2023-09-20 09:32:24 --> UTF-8 Support Enabled
INFO - 2023-09-20 09:32:24 --> Utf8 Class Initialized
INFO - 2023-09-20 09:32:24 --> URI Class Initialized
INFO - 2023-09-20 09:32:24 --> Router Class Initialized
INFO - 2023-09-20 09:32:24 --> Output Class Initialized
INFO - 2023-09-20 09:32:24 --> Security Class Initialized
DEBUG - 2023-09-20 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 09:32:24 --> Input Class Initialized
INFO - 2023-09-20 09:32:24 --> Language Class Initialized
INFO - 2023-09-20 09:32:24 --> Loader Class Initialized
INFO - 2023-09-20 09:32:24 --> Helper loaded: url_helper
INFO - 2023-09-20 09:32:24 --> Helper loaded: file_helper
INFO - 2023-09-20 09:32:24 --> Helper loaded: html_helper
INFO - 2023-09-20 09:32:24 --> Helper loaded: text_helper
INFO - 2023-09-20 09:32:24 --> Helper loaded: form_helper
INFO - 2023-09-20 09:32:24 --> Helper loaded: lang_helper
INFO - 2023-09-20 09:32:24 --> Helper loaded: security_helper
INFO - 2023-09-20 09:32:24 --> Helper loaded: cookie_helper
INFO - 2023-09-20 09:32:24 --> Database Driver Class Initialized
INFO - 2023-09-20 09:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 09:32:24 --> Parser Class Initialized
INFO - 2023-09-20 09:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 09:32:24 --> Pagination Class Initialized
INFO - 2023-09-20 09:32:24 --> Form Validation Class Initialized
INFO - 2023-09-20 09:32:24 --> Controller Class Initialized
INFO - 2023-09-20 09:32:24 --> Model Class Initialized
DEBUG - 2023-09-20 09:32:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 09:32:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:32:24 --> Model Class Initialized
DEBUG - 2023-09-20 09:32:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 09:32:24 --> Model Class Initialized
INFO - 2023-09-20 09:32:24 --> Final output sent to browser
DEBUG - 2023-09-20 09:32:24 --> Total execution time: 0.0283
ERROR - 2023-09-20 14:20:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:20:55 --> Config Class Initialized
INFO - 2023-09-20 14:20:55 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:20:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:20:55 --> Utf8 Class Initialized
INFO - 2023-09-20 14:20:55 --> URI Class Initialized
DEBUG - 2023-09-20 14:20:55 --> No URI present. Default controller set.
INFO - 2023-09-20 14:20:55 --> Router Class Initialized
INFO - 2023-09-20 14:20:55 --> Output Class Initialized
INFO - 2023-09-20 14:20:55 --> Security Class Initialized
DEBUG - 2023-09-20 14:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:20:55 --> Input Class Initialized
INFO - 2023-09-20 14:20:55 --> Language Class Initialized
INFO - 2023-09-20 14:20:55 --> Loader Class Initialized
INFO - 2023-09-20 14:20:55 --> Helper loaded: url_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: file_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: html_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: text_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: form_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: security_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:20:55 --> Database Driver Class Initialized
INFO - 2023-09-20 14:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:20:55 --> Parser Class Initialized
INFO - 2023-09-20 14:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:20:55 --> Pagination Class Initialized
INFO - 2023-09-20 14:20:55 --> Form Validation Class Initialized
INFO - 2023-09-20 14:20:55 --> Controller Class Initialized
INFO - 2023-09-20 14:20:55 --> Model Class Initialized
DEBUG - 2023-09-20 14:20:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 14:20:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:20:55 --> Config Class Initialized
INFO - 2023-09-20 14:20:55 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:20:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:20:55 --> Utf8 Class Initialized
INFO - 2023-09-20 14:20:55 --> URI Class Initialized
INFO - 2023-09-20 14:20:55 --> Router Class Initialized
INFO - 2023-09-20 14:20:55 --> Output Class Initialized
INFO - 2023-09-20 14:20:55 --> Security Class Initialized
DEBUG - 2023-09-20 14:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:20:55 --> Input Class Initialized
INFO - 2023-09-20 14:20:55 --> Language Class Initialized
INFO - 2023-09-20 14:20:55 --> Loader Class Initialized
INFO - 2023-09-20 14:20:55 --> Helper loaded: url_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: file_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: html_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: text_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: form_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: security_helper
INFO - 2023-09-20 14:20:55 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:20:55 --> Database Driver Class Initialized
INFO - 2023-09-20 14:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:20:55 --> Parser Class Initialized
INFO - 2023-09-20 14:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:20:55 --> Pagination Class Initialized
INFO - 2023-09-20 14:20:55 --> Form Validation Class Initialized
INFO - 2023-09-20 14:20:55 --> Controller Class Initialized
INFO - 2023-09-20 14:20:55 --> Model Class Initialized
DEBUG - 2023-09-20 14:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 14:20:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:20:55 --> Model Class Initialized
INFO - 2023-09-20 14:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:20:55 --> Final output sent to browser
DEBUG - 2023-09-20 14:20:55 --> Total execution time: 0.0305
ERROR - 2023-09-20 14:21:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:21:17 --> Config Class Initialized
INFO - 2023-09-20 14:21:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:21:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:21:17 --> Utf8 Class Initialized
INFO - 2023-09-20 14:21:17 --> URI Class Initialized
INFO - 2023-09-20 14:21:17 --> Router Class Initialized
INFO - 2023-09-20 14:21:17 --> Output Class Initialized
INFO - 2023-09-20 14:21:17 --> Security Class Initialized
DEBUG - 2023-09-20 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:21:17 --> Input Class Initialized
INFO - 2023-09-20 14:21:17 --> Language Class Initialized
INFO - 2023-09-20 14:21:17 --> Loader Class Initialized
INFO - 2023-09-20 14:21:17 --> Helper loaded: url_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: file_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: html_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: text_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: form_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: security_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:21:17 --> Database Driver Class Initialized
INFO - 2023-09-20 14:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:21:17 --> Parser Class Initialized
INFO - 2023-09-20 14:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:21:17 --> Pagination Class Initialized
INFO - 2023-09-20 14:21:17 --> Form Validation Class Initialized
INFO - 2023-09-20 14:21:17 --> Controller Class Initialized
INFO - 2023-09-20 14:21:17 --> Model Class Initialized
DEBUG - 2023-09-20 14:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:17 --> Model Class Initialized
INFO - 2023-09-20 14:21:17 --> Final output sent to browser
DEBUG - 2023-09-20 14:21:17 --> Total execution time: 0.0215
ERROR - 2023-09-20 14:21:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:21:17 --> Config Class Initialized
INFO - 2023-09-20 14:21:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:21:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:21:17 --> Utf8 Class Initialized
INFO - 2023-09-20 14:21:17 --> URI Class Initialized
INFO - 2023-09-20 14:21:17 --> Router Class Initialized
INFO - 2023-09-20 14:21:17 --> Output Class Initialized
INFO - 2023-09-20 14:21:17 --> Security Class Initialized
DEBUG - 2023-09-20 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:21:17 --> Input Class Initialized
INFO - 2023-09-20 14:21:17 --> Language Class Initialized
INFO - 2023-09-20 14:21:17 --> Loader Class Initialized
INFO - 2023-09-20 14:21:17 --> Helper loaded: url_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: file_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: html_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: text_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: form_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: security_helper
INFO - 2023-09-20 14:21:17 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:21:17 --> Database Driver Class Initialized
INFO - 2023-09-20 14:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:21:17 --> Parser Class Initialized
INFO - 2023-09-20 14:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:21:17 --> Pagination Class Initialized
INFO - 2023-09-20 14:21:17 --> Form Validation Class Initialized
INFO - 2023-09-20 14:21:17 --> Controller Class Initialized
INFO - 2023-09-20 14:21:17 --> Model Class Initialized
DEBUG - 2023-09-20 14:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 14:21:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:21:17 --> Model Class Initialized
INFO - 2023-09-20 14:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:21:17 --> Final output sent to browser
DEBUG - 2023-09-20 14:21:17 --> Total execution time: 0.0295
ERROR - 2023-09-20 14:21:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:21:49 --> Config Class Initialized
INFO - 2023-09-20 14:21:49 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:21:49 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:21:49 --> Utf8 Class Initialized
INFO - 2023-09-20 14:21:49 --> URI Class Initialized
INFO - 2023-09-20 14:21:49 --> Router Class Initialized
INFO - 2023-09-20 14:21:49 --> Output Class Initialized
INFO - 2023-09-20 14:21:49 --> Security Class Initialized
DEBUG - 2023-09-20 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:21:49 --> Input Class Initialized
INFO - 2023-09-20 14:21:49 --> Language Class Initialized
INFO - 2023-09-20 14:21:49 --> Loader Class Initialized
INFO - 2023-09-20 14:21:49 --> Helper loaded: url_helper
INFO - 2023-09-20 14:21:49 --> Helper loaded: file_helper
INFO - 2023-09-20 14:21:49 --> Helper loaded: html_helper
INFO - 2023-09-20 14:21:49 --> Helper loaded: text_helper
INFO - 2023-09-20 14:21:49 --> Helper loaded: form_helper
INFO - 2023-09-20 14:21:49 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:21:49 --> Helper loaded: security_helper
INFO - 2023-09-20 14:21:49 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:21:49 --> Database Driver Class Initialized
INFO - 2023-09-20 14:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:21:49 --> Parser Class Initialized
INFO - 2023-09-20 14:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:21:49 --> Pagination Class Initialized
INFO - 2023-09-20 14:21:49 --> Form Validation Class Initialized
INFO - 2023-09-20 14:21:49 --> Controller Class Initialized
INFO - 2023-09-20 14:21:49 --> Model Class Initialized
DEBUG - 2023-09-20 14:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:49 --> Model Class Initialized
INFO - 2023-09-20 14:21:49 --> Final output sent to browser
DEBUG - 2023-09-20 14:21:49 --> Total execution time: 0.0192
ERROR - 2023-09-20 14:21:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:21:50 --> Config Class Initialized
INFO - 2023-09-20 14:21:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:21:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:21:50 --> Utf8 Class Initialized
INFO - 2023-09-20 14:21:50 --> URI Class Initialized
DEBUG - 2023-09-20 14:21:50 --> No URI present. Default controller set.
INFO - 2023-09-20 14:21:50 --> Router Class Initialized
INFO - 2023-09-20 14:21:50 --> Output Class Initialized
INFO - 2023-09-20 14:21:50 --> Security Class Initialized
DEBUG - 2023-09-20 14:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:21:50 --> Input Class Initialized
INFO - 2023-09-20 14:21:50 --> Language Class Initialized
INFO - 2023-09-20 14:21:50 --> Loader Class Initialized
INFO - 2023-09-20 14:21:50 --> Helper loaded: url_helper
INFO - 2023-09-20 14:21:50 --> Helper loaded: file_helper
INFO - 2023-09-20 14:21:50 --> Helper loaded: html_helper
INFO - 2023-09-20 14:21:50 --> Helper loaded: text_helper
INFO - 2023-09-20 14:21:50 --> Helper loaded: form_helper
INFO - 2023-09-20 14:21:50 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:21:50 --> Helper loaded: security_helper
INFO - 2023-09-20 14:21:50 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:21:50 --> Database Driver Class Initialized
INFO - 2023-09-20 14:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:21:50 --> Parser Class Initialized
INFO - 2023-09-20 14:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:21:50 --> Pagination Class Initialized
INFO - 2023-09-20 14:21:50 --> Form Validation Class Initialized
INFO - 2023-09-20 14:21:50 --> Controller Class Initialized
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
DEBUG - 2023-09-20 14:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
DEBUG - 2023-09-20 14:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
DEBUG - 2023-09-20 14:21:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
INFO - 2023-09-20 14:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 14:21:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:21:50 --> Model Class Initialized
INFO - 2023-09-20 14:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:21:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:21:50 --> Final output sent to browser
DEBUG - 2023-09-20 14:21:50 --> Total execution time: 0.0961
ERROR - 2023-09-20 14:22:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:22:11 --> Config Class Initialized
INFO - 2023-09-20 14:22:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:22:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:22:11 --> Utf8 Class Initialized
INFO - 2023-09-20 14:22:11 --> URI Class Initialized
INFO - 2023-09-20 14:22:11 --> Router Class Initialized
INFO - 2023-09-20 14:22:11 --> Output Class Initialized
INFO - 2023-09-20 14:22:11 --> Security Class Initialized
DEBUG - 2023-09-20 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:22:11 --> Input Class Initialized
INFO - 2023-09-20 14:22:11 --> Language Class Initialized
INFO - 2023-09-20 14:22:11 --> Loader Class Initialized
INFO - 2023-09-20 14:22:11 --> Helper loaded: url_helper
INFO - 2023-09-20 14:22:11 --> Helper loaded: file_helper
INFO - 2023-09-20 14:22:11 --> Helper loaded: html_helper
INFO - 2023-09-20 14:22:11 --> Helper loaded: text_helper
INFO - 2023-09-20 14:22:11 --> Helper loaded: form_helper
INFO - 2023-09-20 14:22:11 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:22:11 --> Helper loaded: security_helper
INFO - 2023-09-20 14:22:11 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:22:11 --> Database Driver Class Initialized
INFO - 2023-09-20 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:22:11 --> Parser Class Initialized
INFO - 2023-09-20 14:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:22:11 --> Pagination Class Initialized
INFO - 2023-09-20 14:22:11 --> Form Validation Class Initialized
INFO - 2023-09-20 14:22:11 --> Controller Class Initialized
DEBUG - 2023-09-20 14:22:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:22:11 --> Model Class Initialized
DEBUG - 2023-09-20 14:22:11 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:22:11 --> Model Class Initialized
DEBUG - 2023-09-20 14:22:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:22:11 --> Model Class Initialized
DEBUG - 2023-09-20 14:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:22:11 --> Model Class Initialized
INFO - 2023-09-20 14:22:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-20 14:22:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:22:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:22:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:22:11 --> Model Class Initialized
INFO - 2023-09-20 14:22:11 --> Model Class Initialized
INFO - 2023-09-20 14:22:11 --> Model Class Initialized
INFO - 2023-09-20 14:22:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:22:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:22:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:22:11 --> Final output sent to browser
DEBUG - 2023-09-20 14:22:11 --> Total execution time: 0.0732
ERROR - 2023-09-20 14:22:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:22:12 --> Config Class Initialized
INFO - 2023-09-20 14:22:12 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:22:12 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:22:12 --> Utf8 Class Initialized
INFO - 2023-09-20 14:22:12 --> URI Class Initialized
INFO - 2023-09-20 14:22:12 --> Router Class Initialized
INFO - 2023-09-20 14:22:12 --> Output Class Initialized
INFO - 2023-09-20 14:22:12 --> Security Class Initialized
DEBUG - 2023-09-20 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:22:12 --> Input Class Initialized
INFO - 2023-09-20 14:22:12 --> Language Class Initialized
INFO - 2023-09-20 14:22:12 --> Loader Class Initialized
INFO - 2023-09-20 14:22:12 --> Helper loaded: url_helper
INFO - 2023-09-20 14:22:12 --> Helper loaded: file_helper
INFO - 2023-09-20 14:22:12 --> Helper loaded: html_helper
INFO - 2023-09-20 14:22:12 --> Helper loaded: text_helper
INFO - 2023-09-20 14:22:12 --> Helper loaded: form_helper
INFO - 2023-09-20 14:22:12 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:22:12 --> Helper loaded: security_helper
INFO - 2023-09-20 14:22:12 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:22:12 --> Database Driver Class Initialized
INFO - 2023-09-20 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:22:12 --> Parser Class Initialized
INFO - 2023-09-20 14:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:22:12 --> Pagination Class Initialized
INFO - 2023-09-20 14:22:12 --> Form Validation Class Initialized
INFO - 2023-09-20 14:22:12 --> Controller Class Initialized
DEBUG - 2023-09-20 14:22:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:22:12 --> Model Class Initialized
INFO - 2023-09-20 14:22:12 --> Final output sent to browser
DEBUG - 2023-09-20 14:22:12 --> Total execution time: 0.0195
ERROR - 2023-09-20 14:22:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:22:45 --> Config Class Initialized
INFO - 2023-09-20 14:22:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:22:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:22:45 --> Utf8 Class Initialized
INFO - 2023-09-20 14:22:45 --> URI Class Initialized
INFO - 2023-09-20 14:22:45 --> Router Class Initialized
INFO - 2023-09-20 14:22:45 --> Output Class Initialized
INFO - 2023-09-20 14:22:45 --> Security Class Initialized
DEBUG - 2023-09-20 14:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:22:45 --> Input Class Initialized
INFO - 2023-09-20 14:22:45 --> Language Class Initialized
INFO - 2023-09-20 14:22:45 --> Loader Class Initialized
INFO - 2023-09-20 14:22:45 --> Helper loaded: url_helper
INFO - 2023-09-20 14:22:45 --> Helper loaded: file_helper
INFO - 2023-09-20 14:22:45 --> Helper loaded: html_helper
INFO - 2023-09-20 14:22:45 --> Helper loaded: text_helper
INFO - 2023-09-20 14:22:45 --> Helper loaded: form_helper
INFO - 2023-09-20 14:22:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:22:45 --> Helper loaded: security_helper
INFO - 2023-09-20 14:22:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:22:45 --> Database Driver Class Initialized
INFO - 2023-09-20 14:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:22:45 --> Parser Class Initialized
INFO - 2023-09-20 14:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:22:45 --> Pagination Class Initialized
INFO - 2023-09-20 14:22:45 --> Form Validation Class Initialized
INFO - 2023-09-20 14:22:45 --> Controller Class Initialized
DEBUG - 2023-09-20 14:22:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:22:45 --> Model Class Initialized
INFO - 2023-09-20 14:22:45 --> Final output sent to browser
DEBUG - 2023-09-20 14:22:45 --> Total execution time: 0.0196
ERROR - 2023-09-20 14:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:23:15 --> Config Class Initialized
INFO - 2023-09-20 14:23:15 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:23:15 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:23:15 --> Utf8 Class Initialized
INFO - 2023-09-20 14:23:15 --> URI Class Initialized
DEBUG - 2023-09-20 14:23:15 --> No URI present. Default controller set.
INFO - 2023-09-20 14:23:15 --> Router Class Initialized
INFO - 2023-09-20 14:23:15 --> Output Class Initialized
INFO - 2023-09-20 14:23:15 --> Security Class Initialized
DEBUG - 2023-09-20 14:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:23:15 --> Input Class Initialized
INFO - 2023-09-20 14:23:15 --> Language Class Initialized
INFO - 2023-09-20 14:23:15 --> Loader Class Initialized
INFO - 2023-09-20 14:23:15 --> Helper loaded: url_helper
INFO - 2023-09-20 14:23:15 --> Helper loaded: file_helper
INFO - 2023-09-20 14:23:15 --> Helper loaded: html_helper
INFO - 2023-09-20 14:23:15 --> Helper loaded: text_helper
INFO - 2023-09-20 14:23:15 --> Helper loaded: form_helper
INFO - 2023-09-20 14:23:15 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:23:15 --> Helper loaded: security_helper
INFO - 2023-09-20 14:23:15 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:23:15 --> Database Driver Class Initialized
INFO - 2023-09-20 14:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:23:15 --> Parser Class Initialized
INFO - 2023-09-20 14:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:23:15 --> Pagination Class Initialized
INFO - 2023-09-20 14:23:15 --> Form Validation Class Initialized
INFO - 2023-09-20 14:23:15 --> Controller Class Initialized
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
INFO - 2023-09-20 14:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 14:23:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:23:15 --> Model Class Initialized
INFO - 2023-09-20 14:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:23:15 --> Final output sent to browser
DEBUG - 2023-09-20 14:23:15 --> Total execution time: 0.0950
ERROR - 2023-09-20 14:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:23:30 --> Config Class Initialized
INFO - 2023-09-20 14:23:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:23:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:23:30 --> Utf8 Class Initialized
INFO - 2023-09-20 14:23:30 --> URI Class Initialized
INFO - 2023-09-20 14:23:30 --> Router Class Initialized
INFO - 2023-09-20 14:23:30 --> Output Class Initialized
INFO - 2023-09-20 14:23:30 --> Security Class Initialized
DEBUG - 2023-09-20 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:23:30 --> Input Class Initialized
INFO - 2023-09-20 14:23:30 --> Language Class Initialized
INFO - 2023-09-20 14:23:30 --> Loader Class Initialized
INFO - 2023-09-20 14:23:30 --> Helper loaded: url_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: file_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: html_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: text_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: form_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: security_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:23:30 --> Database Driver Class Initialized
INFO - 2023-09-20 14:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:23:30 --> Parser Class Initialized
INFO - 2023-09-20 14:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:23:30 --> Pagination Class Initialized
INFO - 2023-09-20 14:23:30 --> Form Validation Class Initialized
INFO - 2023-09-20 14:23:30 --> Controller Class Initialized
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
INFO - 2023-09-20 14:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-20 14:23:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
INFO - 2023-09-20 14:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:23:30 --> Final output sent to browser
DEBUG - 2023-09-20 14:23:30 --> Total execution time: 0.0755
ERROR - 2023-09-20 14:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:23:30 --> Config Class Initialized
INFO - 2023-09-20 14:23:30 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:23:30 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:23:30 --> Utf8 Class Initialized
INFO - 2023-09-20 14:23:30 --> URI Class Initialized
INFO - 2023-09-20 14:23:30 --> Router Class Initialized
INFO - 2023-09-20 14:23:30 --> Output Class Initialized
INFO - 2023-09-20 14:23:30 --> Security Class Initialized
DEBUG - 2023-09-20 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:23:30 --> Input Class Initialized
INFO - 2023-09-20 14:23:30 --> Language Class Initialized
INFO - 2023-09-20 14:23:30 --> Loader Class Initialized
INFO - 2023-09-20 14:23:30 --> Helper loaded: url_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: file_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: html_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: text_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: form_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: security_helper
INFO - 2023-09-20 14:23:30 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:23:30 --> Database Driver Class Initialized
INFO - 2023-09-20 14:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:23:30 --> Parser Class Initialized
INFO - 2023-09-20 14:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:23:30 --> Pagination Class Initialized
INFO - 2023-09-20 14:23:30 --> Form Validation Class Initialized
INFO - 2023-09-20 14:23:30 --> Controller Class Initialized
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:30 --> Model Class Initialized
INFO - 2023-09-20 14:23:30 --> Final output sent to browser
DEBUG - 2023-09-20 14:23:30 --> Total execution time: 0.0262
ERROR - 2023-09-20 14:23:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:23:52 --> Config Class Initialized
INFO - 2023-09-20 14:23:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:23:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:23:52 --> Utf8 Class Initialized
INFO - 2023-09-20 14:23:52 --> URI Class Initialized
INFO - 2023-09-20 14:23:52 --> Router Class Initialized
INFO - 2023-09-20 14:23:52 --> Output Class Initialized
INFO - 2023-09-20 14:23:52 --> Security Class Initialized
DEBUG - 2023-09-20 14:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:23:52 --> Input Class Initialized
INFO - 2023-09-20 14:23:52 --> Language Class Initialized
INFO - 2023-09-20 14:23:52 --> Loader Class Initialized
INFO - 2023-09-20 14:23:52 --> Helper loaded: url_helper
INFO - 2023-09-20 14:23:52 --> Helper loaded: file_helper
INFO - 2023-09-20 14:23:52 --> Helper loaded: html_helper
INFO - 2023-09-20 14:23:52 --> Helper loaded: text_helper
INFO - 2023-09-20 14:23:52 --> Helper loaded: form_helper
INFO - 2023-09-20 14:23:52 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:23:52 --> Helper loaded: security_helper
INFO - 2023-09-20 14:23:52 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:23:52 --> Database Driver Class Initialized
INFO - 2023-09-20 14:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:23:52 --> Parser Class Initialized
INFO - 2023-09-20 14:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:23:52 --> Pagination Class Initialized
INFO - 2023-09-20 14:23:52 --> Form Validation Class Initialized
INFO - 2023-09-20 14:23:52 --> Controller Class Initialized
INFO - 2023-09-20 14:23:52 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:52 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:52 --> Model Class Initialized
INFO - 2023-09-20 14:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 14:23:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:23:52 --> Model Class Initialized
INFO - 2023-09-20 14:23:52 --> Model Class Initialized
INFO - 2023-09-20 14:23:52 --> Model Class Initialized
INFO - 2023-09-20 14:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:23:52 --> Final output sent to browser
DEBUG - 2023-09-20 14:23:52 --> Total execution time: 0.0719
ERROR - 2023-09-20 14:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:23:53 --> Config Class Initialized
INFO - 2023-09-20 14:23:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:23:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:23:53 --> Utf8 Class Initialized
INFO - 2023-09-20 14:23:53 --> URI Class Initialized
INFO - 2023-09-20 14:23:53 --> Router Class Initialized
INFO - 2023-09-20 14:23:53 --> Output Class Initialized
INFO - 2023-09-20 14:23:53 --> Security Class Initialized
DEBUG - 2023-09-20 14:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:23:53 --> Input Class Initialized
INFO - 2023-09-20 14:23:53 --> Language Class Initialized
INFO - 2023-09-20 14:23:53 --> Loader Class Initialized
INFO - 2023-09-20 14:23:53 --> Helper loaded: url_helper
INFO - 2023-09-20 14:23:53 --> Helper loaded: file_helper
INFO - 2023-09-20 14:23:53 --> Helper loaded: html_helper
INFO - 2023-09-20 14:23:53 --> Helper loaded: text_helper
INFO - 2023-09-20 14:23:53 --> Helper loaded: form_helper
INFO - 2023-09-20 14:23:53 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:23:53 --> Helper loaded: security_helper
INFO - 2023-09-20 14:23:53 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:23:53 --> Database Driver Class Initialized
INFO - 2023-09-20 14:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:23:53 --> Parser Class Initialized
INFO - 2023-09-20 14:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:23:53 --> Pagination Class Initialized
INFO - 2023-09-20 14:23:53 --> Form Validation Class Initialized
INFO - 2023-09-20 14:23:53 --> Controller Class Initialized
INFO - 2023-09-20 14:23:53 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:53 --> Model Class Initialized
DEBUG - 2023-09-20 14:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:23:53 --> Model Class Initialized
INFO - 2023-09-20 14:23:53 --> Final output sent to browser
DEBUG - 2023-09-20 14:23:53 --> Total execution time: 0.0255
ERROR - 2023-09-20 14:24:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:24:27 --> Config Class Initialized
INFO - 2023-09-20 14:24:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:24:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:24:27 --> Utf8 Class Initialized
INFO - 2023-09-20 14:24:27 --> URI Class Initialized
INFO - 2023-09-20 14:24:27 --> Router Class Initialized
INFO - 2023-09-20 14:24:27 --> Output Class Initialized
INFO - 2023-09-20 14:24:27 --> Security Class Initialized
DEBUG - 2023-09-20 14:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:24:27 --> Input Class Initialized
INFO - 2023-09-20 14:24:27 --> Language Class Initialized
INFO - 2023-09-20 14:24:27 --> Loader Class Initialized
INFO - 2023-09-20 14:24:27 --> Helper loaded: url_helper
INFO - 2023-09-20 14:24:27 --> Helper loaded: file_helper
INFO - 2023-09-20 14:24:27 --> Helper loaded: html_helper
INFO - 2023-09-20 14:24:27 --> Helper loaded: text_helper
INFO - 2023-09-20 14:24:27 --> Helper loaded: form_helper
INFO - 2023-09-20 14:24:27 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:24:27 --> Helper loaded: security_helper
INFO - 2023-09-20 14:24:27 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:24:27 --> Database Driver Class Initialized
INFO - 2023-09-20 14:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:24:27 --> Parser Class Initialized
INFO - 2023-09-20 14:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:24:27 --> Pagination Class Initialized
INFO - 2023-09-20 14:24:27 --> Form Validation Class Initialized
INFO - 2023-09-20 14:24:27 --> Controller Class Initialized
DEBUG - 2023-09-20 14:24:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:27 --> Model Class Initialized
DEBUG - 2023-09-20 14:24:27 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:27 --> Model Class Initialized
DEBUG - 2023-09-20 14:24:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:27 --> Model Class Initialized
DEBUG - 2023-09-20 14:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:27 --> Model Class Initialized
INFO - 2023-09-20 14:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-20 14:24:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:24:27 --> Model Class Initialized
INFO - 2023-09-20 14:24:27 --> Model Class Initialized
INFO - 2023-09-20 14:24:27 --> Model Class Initialized
INFO - 2023-09-20 14:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:24:27 --> Final output sent to browser
DEBUG - 2023-09-20 14:24:27 --> Total execution time: 0.0723
ERROR - 2023-09-20 14:24:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:24:28 --> Config Class Initialized
INFO - 2023-09-20 14:24:28 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:24:28 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:24:28 --> Utf8 Class Initialized
INFO - 2023-09-20 14:24:28 --> URI Class Initialized
INFO - 2023-09-20 14:24:28 --> Router Class Initialized
INFO - 2023-09-20 14:24:28 --> Output Class Initialized
INFO - 2023-09-20 14:24:28 --> Security Class Initialized
DEBUG - 2023-09-20 14:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:24:28 --> Input Class Initialized
INFO - 2023-09-20 14:24:28 --> Language Class Initialized
INFO - 2023-09-20 14:24:28 --> Loader Class Initialized
INFO - 2023-09-20 14:24:28 --> Helper loaded: url_helper
INFO - 2023-09-20 14:24:28 --> Helper loaded: file_helper
INFO - 2023-09-20 14:24:28 --> Helper loaded: html_helper
INFO - 2023-09-20 14:24:28 --> Helper loaded: text_helper
INFO - 2023-09-20 14:24:28 --> Helper loaded: form_helper
INFO - 2023-09-20 14:24:28 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:24:28 --> Helper loaded: security_helper
INFO - 2023-09-20 14:24:28 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:24:28 --> Database Driver Class Initialized
INFO - 2023-09-20 14:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:24:28 --> Parser Class Initialized
INFO - 2023-09-20 14:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:24:28 --> Pagination Class Initialized
INFO - 2023-09-20 14:24:28 --> Form Validation Class Initialized
INFO - 2023-09-20 14:24:28 --> Controller Class Initialized
DEBUG - 2023-09-20 14:24:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:28 --> Model Class Initialized
INFO - 2023-09-20 14:24:28 --> Final output sent to browser
DEBUG - 2023-09-20 14:24:28 --> Total execution time: 0.0162
ERROR - 2023-09-20 14:24:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:24:59 --> Config Class Initialized
INFO - 2023-09-20 14:24:59 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:24:59 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:24:59 --> Utf8 Class Initialized
INFO - 2023-09-20 14:24:59 --> URI Class Initialized
INFO - 2023-09-20 14:24:59 --> Router Class Initialized
INFO - 2023-09-20 14:24:59 --> Output Class Initialized
INFO - 2023-09-20 14:24:59 --> Security Class Initialized
DEBUG - 2023-09-20 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:24:59 --> Input Class Initialized
INFO - 2023-09-20 14:24:59 --> Language Class Initialized
INFO - 2023-09-20 14:24:59 --> Loader Class Initialized
INFO - 2023-09-20 14:24:59 --> Helper loaded: url_helper
INFO - 2023-09-20 14:24:59 --> Helper loaded: file_helper
INFO - 2023-09-20 14:24:59 --> Helper loaded: html_helper
INFO - 2023-09-20 14:24:59 --> Helper loaded: text_helper
INFO - 2023-09-20 14:24:59 --> Helper loaded: form_helper
INFO - 2023-09-20 14:24:59 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:24:59 --> Helper loaded: security_helper
INFO - 2023-09-20 14:24:59 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:24:59 --> Database Driver Class Initialized
INFO - 2023-09-20 14:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:24:59 --> Parser Class Initialized
INFO - 2023-09-20 14:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:24:59 --> Pagination Class Initialized
INFO - 2023-09-20 14:24:59 --> Form Validation Class Initialized
INFO - 2023-09-20 14:24:59 --> Controller Class Initialized
DEBUG - 2023-09-20 14:24:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:59 --> Model Class Initialized
DEBUG - 2023-09-20 14:24:59 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:59 --> Model Class Initialized
DEBUG - 2023-09-20 14:24:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:59 --> Model Class Initialized
DEBUG - 2023-09-20 14:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:59 --> Model Class Initialized
INFO - 2023-09-20 14:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-20 14:24:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:24:59 --> Model Class Initialized
INFO - 2023-09-20 14:24:59 --> Model Class Initialized
INFO - 2023-09-20 14:24:59 --> Model Class Initialized
INFO - 2023-09-20 14:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:24:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:24:59 --> Final output sent to browser
DEBUG - 2023-09-20 14:24:59 --> Total execution time: 0.0696
ERROR - 2023-09-20 14:25:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:25:00 --> Config Class Initialized
INFO - 2023-09-20 14:25:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:25:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:25:00 --> Utf8 Class Initialized
INFO - 2023-09-20 14:25:00 --> URI Class Initialized
INFO - 2023-09-20 14:25:00 --> Router Class Initialized
INFO - 2023-09-20 14:25:00 --> Output Class Initialized
INFO - 2023-09-20 14:25:00 --> Security Class Initialized
DEBUG - 2023-09-20 14:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:25:00 --> Input Class Initialized
INFO - 2023-09-20 14:25:00 --> Language Class Initialized
INFO - 2023-09-20 14:25:00 --> Loader Class Initialized
INFO - 2023-09-20 14:25:00 --> Helper loaded: url_helper
INFO - 2023-09-20 14:25:00 --> Helper loaded: file_helper
INFO - 2023-09-20 14:25:00 --> Helper loaded: html_helper
INFO - 2023-09-20 14:25:00 --> Helper loaded: text_helper
INFO - 2023-09-20 14:25:00 --> Helper loaded: form_helper
INFO - 2023-09-20 14:25:00 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:25:00 --> Helper loaded: security_helper
INFO - 2023-09-20 14:25:00 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:25:00 --> Database Driver Class Initialized
INFO - 2023-09-20 14:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:25:00 --> Parser Class Initialized
INFO - 2023-09-20 14:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:25:00 --> Pagination Class Initialized
INFO - 2023-09-20 14:25:00 --> Form Validation Class Initialized
INFO - 2023-09-20 14:25:00 --> Controller Class Initialized
DEBUG - 2023-09-20 14:25:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:25:00 --> Model Class Initialized
INFO - 2023-09-20 14:25:00 --> Final output sent to browser
DEBUG - 2023-09-20 14:25:00 --> Total execution time: 0.0169
ERROR - 2023-09-20 14:25:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:25:08 --> Config Class Initialized
INFO - 2023-09-20 14:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:25:08 --> Utf8 Class Initialized
INFO - 2023-09-20 14:25:08 --> URI Class Initialized
INFO - 2023-09-20 14:25:08 --> Router Class Initialized
INFO - 2023-09-20 14:25:08 --> Output Class Initialized
INFO - 2023-09-20 14:25:08 --> Security Class Initialized
DEBUG - 2023-09-20 14:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:25:08 --> Input Class Initialized
INFO - 2023-09-20 14:25:08 --> Language Class Initialized
INFO - 2023-09-20 14:25:08 --> Loader Class Initialized
INFO - 2023-09-20 14:25:08 --> Helper loaded: url_helper
INFO - 2023-09-20 14:25:08 --> Helper loaded: file_helper
INFO - 2023-09-20 14:25:08 --> Helper loaded: html_helper
INFO - 2023-09-20 14:25:08 --> Helper loaded: text_helper
INFO - 2023-09-20 14:25:08 --> Helper loaded: form_helper
INFO - 2023-09-20 14:25:08 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:25:08 --> Helper loaded: security_helper
INFO - 2023-09-20 14:25:08 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:25:08 --> Database Driver Class Initialized
INFO - 2023-09-20 14:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:25:08 --> Parser Class Initialized
INFO - 2023-09-20 14:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:25:08 --> Pagination Class Initialized
INFO - 2023-09-20 14:25:08 --> Form Validation Class Initialized
INFO - 2023-09-20 14:25:08 --> Controller Class Initialized
INFO - 2023-09-20 14:25:08 --> Model Class Initialized
DEBUG - 2023-09-20 14:25:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:25:08 --> Model Class Initialized
DEBUG - 2023-09-20 14:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:25:08 --> Model Class Initialized
INFO - 2023-09-20 14:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 14:25:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 14:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 14:25:08 --> Model Class Initialized
INFO - 2023-09-20 14:25:08 --> Model Class Initialized
INFO - 2023-09-20 14:25:08 --> Model Class Initialized
INFO - 2023-09-20 14:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 14:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 14:25:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 14:25:08 --> Final output sent to browser
DEBUG - 2023-09-20 14:25:08 --> Total execution time: 0.0860
ERROR - 2023-09-20 14:25:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 14:25:09 --> Config Class Initialized
INFO - 2023-09-20 14:25:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 14:25:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 14:25:09 --> Utf8 Class Initialized
INFO - 2023-09-20 14:25:09 --> URI Class Initialized
INFO - 2023-09-20 14:25:09 --> Router Class Initialized
INFO - 2023-09-20 14:25:09 --> Output Class Initialized
INFO - 2023-09-20 14:25:09 --> Security Class Initialized
DEBUG - 2023-09-20 14:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 14:25:09 --> Input Class Initialized
INFO - 2023-09-20 14:25:09 --> Language Class Initialized
INFO - 2023-09-20 14:25:09 --> Loader Class Initialized
INFO - 2023-09-20 14:25:09 --> Helper loaded: url_helper
INFO - 2023-09-20 14:25:09 --> Helper loaded: file_helper
INFO - 2023-09-20 14:25:09 --> Helper loaded: html_helper
INFO - 2023-09-20 14:25:09 --> Helper loaded: text_helper
INFO - 2023-09-20 14:25:09 --> Helper loaded: form_helper
INFO - 2023-09-20 14:25:09 --> Helper loaded: lang_helper
INFO - 2023-09-20 14:25:09 --> Helper loaded: security_helper
INFO - 2023-09-20 14:25:09 --> Helper loaded: cookie_helper
INFO - 2023-09-20 14:25:09 --> Database Driver Class Initialized
INFO - 2023-09-20 14:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 14:25:09 --> Parser Class Initialized
INFO - 2023-09-20 14:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 14:25:09 --> Pagination Class Initialized
INFO - 2023-09-20 14:25:09 --> Form Validation Class Initialized
INFO - 2023-09-20 14:25:09 --> Controller Class Initialized
INFO - 2023-09-20 14:25:09 --> Model Class Initialized
DEBUG - 2023-09-20 14:25:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 14:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:25:09 --> Model Class Initialized
DEBUG - 2023-09-20 14:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 14:25:09 --> Model Class Initialized
INFO - 2023-09-20 14:25:09 --> Final output sent to browser
DEBUG - 2023-09-20 14:25:09 --> Total execution time: 0.0368
ERROR - 2023-09-20 15:23:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:36 --> Config Class Initialized
INFO - 2023-09-20 15:23:36 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:36 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:36 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:36 --> URI Class Initialized
DEBUG - 2023-09-20 15:23:36 --> No URI present. Default controller set.
INFO - 2023-09-20 15:23:36 --> Router Class Initialized
INFO - 2023-09-20 15:23:36 --> Output Class Initialized
INFO - 2023-09-20 15:23:36 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:36 --> Input Class Initialized
INFO - 2023-09-20 15:23:36 --> Language Class Initialized
INFO - 2023-09-20 15:23:36 --> Loader Class Initialized
INFO - 2023-09-20 15:23:36 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:36 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:36 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:36 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:36 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:36 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:36 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:36 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:36 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:36 --> Parser Class Initialized
INFO - 2023-09-20 15:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:36 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:36 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:36 --> Controller Class Initialized
INFO - 2023-09-20 15:23:36 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 15:23:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:37 --> Config Class Initialized
INFO - 2023-09-20 15:23:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:37 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:37 --> URI Class Initialized
INFO - 2023-09-20 15:23:37 --> Router Class Initialized
INFO - 2023-09-20 15:23:37 --> Output Class Initialized
INFO - 2023-09-20 15:23:37 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:37 --> Input Class Initialized
INFO - 2023-09-20 15:23:37 --> Language Class Initialized
INFO - 2023-09-20 15:23:37 --> Loader Class Initialized
INFO - 2023-09-20 15:23:37 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:37 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:37 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:37 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:37 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:37 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:37 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:37 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:37 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:37 --> Parser Class Initialized
INFO - 2023-09-20 15:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:37 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:37 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:37 --> Controller Class Initialized
INFO - 2023-09-20 15:23:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 15:23:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:23:37 --> Model Class Initialized
INFO - 2023-09-20 15:23:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:23:37 --> Final output sent to browser
DEBUG - 2023-09-20 15:23:37 --> Total execution time: 0.0295
ERROR - 2023-09-20 15:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:39 --> Config Class Initialized
INFO - 2023-09-20 15:23:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:39 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:39 --> URI Class Initialized
INFO - 2023-09-20 15:23:39 --> Router Class Initialized
INFO - 2023-09-20 15:23:39 --> Output Class Initialized
INFO - 2023-09-20 15:23:39 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:39 --> Input Class Initialized
INFO - 2023-09-20 15:23:39 --> Language Class Initialized
INFO - 2023-09-20 15:23:39 --> Loader Class Initialized
INFO - 2023-09-20 15:23:39 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:39 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:39 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:39 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:39 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:39 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:39 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:39 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:39 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:39 --> Parser Class Initialized
INFO - 2023-09-20 15:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:39 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:39 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:39 --> Controller Class Initialized
INFO - 2023-09-20 15:23:39 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:39 --> Model Class Initialized
INFO - 2023-09-20 15:23:39 --> Final output sent to browser
DEBUG - 2023-09-20 15:23:39 --> Total execution time: 0.0166
ERROR - 2023-09-20 15:23:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:40 --> Config Class Initialized
INFO - 2023-09-20 15:23:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:40 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:40 --> URI Class Initialized
DEBUG - 2023-09-20 15:23:40 --> No URI present. Default controller set.
INFO - 2023-09-20 15:23:40 --> Router Class Initialized
INFO - 2023-09-20 15:23:40 --> Output Class Initialized
INFO - 2023-09-20 15:23:40 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:40 --> Input Class Initialized
INFO - 2023-09-20 15:23:40 --> Language Class Initialized
INFO - 2023-09-20 15:23:40 --> Loader Class Initialized
INFO - 2023-09-20 15:23:40 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:40 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:40 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:40 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:40 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:40 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:40 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:40 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:40 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:40 --> Parser Class Initialized
INFO - 2023-09-20 15:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:40 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:40 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:40 --> Controller Class Initialized
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
INFO - 2023-09-20 15:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:23:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:23:40 --> Model Class Initialized
INFO - 2023-09-20 15:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:23:40 --> Final output sent to browser
DEBUG - 2023-09-20 15:23:40 --> Total execution time: 0.2031
ERROR - 2023-09-20 15:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:41 --> Config Class Initialized
INFO - 2023-09-20 15:23:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:41 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:41 --> URI Class Initialized
INFO - 2023-09-20 15:23:41 --> Router Class Initialized
INFO - 2023-09-20 15:23:41 --> Output Class Initialized
INFO - 2023-09-20 15:23:41 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:41 --> Input Class Initialized
INFO - 2023-09-20 15:23:41 --> Language Class Initialized
INFO - 2023-09-20 15:23:41 --> Loader Class Initialized
INFO - 2023-09-20 15:23:41 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:41 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:41 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:41 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:41 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:41 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:41 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:41 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:41 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:41 --> Parser Class Initialized
INFO - 2023-09-20 15:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:41 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:41 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:41 --> Controller Class Initialized
DEBUG - 2023-09-20 15:23:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:41 --> Model Class Initialized
INFO - 2023-09-20 15:23:41 --> Final output sent to browser
DEBUG - 2023-09-20 15:23:41 --> Total execution time: 0.0135
ERROR - 2023-09-20 15:23:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:50 --> Config Class Initialized
INFO - 2023-09-20 15:23:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:50 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:50 --> URI Class Initialized
INFO - 2023-09-20 15:23:50 --> Router Class Initialized
INFO - 2023-09-20 15:23:50 --> Output Class Initialized
INFO - 2023-09-20 15:23:50 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:50 --> Input Class Initialized
INFO - 2023-09-20 15:23:50 --> Language Class Initialized
INFO - 2023-09-20 15:23:50 --> Loader Class Initialized
INFO - 2023-09-20 15:23:50 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:50 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:50 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:50 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:50 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:50 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:50 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:50 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:50 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:50 --> Parser Class Initialized
INFO - 2023-09-20 15:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:50 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:50 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:50 --> Controller Class Initialized
INFO - 2023-09-20 15:23:50 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:50 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:50 --> Model Class Initialized
INFO - 2023-09-20 15:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:23:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:23:50 --> Model Class Initialized
INFO - 2023-09-20 15:23:50 --> Model Class Initialized
INFO - 2023-09-20 15:23:50 --> Model Class Initialized
INFO - 2023-09-20 15:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:23:50 --> Final output sent to browser
DEBUG - 2023-09-20 15:23:50 --> Total execution time: 0.1403
ERROR - 2023-09-20 15:23:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:51 --> Config Class Initialized
INFO - 2023-09-20 15:23:51 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:51 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:51 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:51 --> URI Class Initialized
INFO - 2023-09-20 15:23:51 --> Router Class Initialized
INFO - 2023-09-20 15:23:51 --> Output Class Initialized
INFO - 2023-09-20 15:23:51 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:51 --> Input Class Initialized
INFO - 2023-09-20 15:23:51 --> Language Class Initialized
INFO - 2023-09-20 15:23:51 --> Loader Class Initialized
INFO - 2023-09-20 15:23:51 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:51 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:51 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:51 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:51 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:51 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:51 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:51 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:51 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:51 --> Parser Class Initialized
INFO - 2023-09-20 15:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:51 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:51 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:51 --> Controller Class Initialized
INFO - 2023-09-20 15:23:51 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:51 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:51 --> Model Class Initialized
INFO - 2023-09-20 15:23:51 --> Final output sent to browser
DEBUG - 2023-09-20 15:23:51 --> Total execution time: 0.0550
ERROR - 2023-09-20 15:23:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:23:56 --> Config Class Initialized
INFO - 2023-09-20 15:23:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:23:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:23:56 --> Utf8 Class Initialized
INFO - 2023-09-20 15:23:56 --> URI Class Initialized
INFO - 2023-09-20 15:23:56 --> Router Class Initialized
INFO - 2023-09-20 15:23:56 --> Output Class Initialized
INFO - 2023-09-20 15:23:56 --> Security Class Initialized
DEBUG - 2023-09-20 15:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:23:56 --> Input Class Initialized
INFO - 2023-09-20 15:23:56 --> Language Class Initialized
INFO - 2023-09-20 15:23:56 --> Loader Class Initialized
INFO - 2023-09-20 15:23:56 --> Helper loaded: url_helper
INFO - 2023-09-20 15:23:56 --> Helper loaded: file_helper
INFO - 2023-09-20 15:23:56 --> Helper loaded: html_helper
INFO - 2023-09-20 15:23:56 --> Helper loaded: text_helper
INFO - 2023-09-20 15:23:56 --> Helper loaded: form_helper
INFO - 2023-09-20 15:23:56 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:23:56 --> Helper loaded: security_helper
INFO - 2023-09-20 15:23:56 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:23:56 --> Database Driver Class Initialized
INFO - 2023-09-20 15:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:23:56 --> Parser Class Initialized
INFO - 2023-09-20 15:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:23:56 --> Pagination Class Initialized
INFO - 2023-09-20 15:23:56 --> Form Validation Class Initialized
INFO - 2023-09-20 15:23:56 --> Controller Class Initialized
INFO - 2023-09-20 15:23:56 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:56 --> Model Class Initialized
DEBUG - 2023-09-20 15:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:23:56 --> Model Class Initialized
INFO - 2023-09-20 15:23:57 --> Final output sent to browser
DEBUG - 2023-09-20 15:23:57 --> Total execution time: 0.8694
ERROR - 2023-09-20 15:24:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:24:34 --> Config Class Initialized
INFO - 2023-09-20 15:24:34 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:24:34 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:24:34 --> Utf8 Class Initialized
INFO - 2023-09-20 15:24:34 --> URI Class Initialized
DEBUG - 2023-09-20 15:24:34 --> No URI present. Default controller set.
INFO - 2023-09-20 15:24:34 --> Router Class Initialized
INFO - 2023-09-20 15:24:34 --> Output Class Initialized
INFO - 2023-09-20 15:24:34 --> Security Class Initialized
DEBUG - 2023-09-20 15:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:24:34 --> Input Class Initialized
INFO - 2023-09-20 15:24:34 --> Language Class Initialized
INFO - 2023-09-20 15:24:34 --> Loader Class Initialized
INFO - 2023-09-20 15:24:34 --> Helper loaded: url_helper
INFO - 2023-09-20 15:24:34 --> Helper loaded: file_helper
INFO - 2023-09-20 15:24:34 --> Helper loaded: html_helper
INFO - 2023-09-20 15:24:34 --> Helper loaded: text_helper
INFO - 2023-09-20 15:24:34 --> Helper loaded: form_helper
INFO - 2023-09-20 15:24:34 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:24:34 --> Helper loaded: security_helper
INFO - 2023-09-20 15:24:34 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:24:34 --> Database Driver Class Initialized
INFO - 2023-09-20 15:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:24:34 --> Parser Class Initialized
INFO - 2023-09-20 15:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:24:34 --> Pagination Class Initialized
INFO - 2023-09-20 15:24:34 --> Form Validation Class Initialized
INFO - 2023-09-20 15:24:34 --> Controller Class Initialized
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
INFO - 2023-09-20 15:24:34 --> Model Class Initialized
INFO - 2023-09-20 15:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:24:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:24:35 --> Model Class Initialized
INFO - 2023-09-20 15:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:24:35 --> Final output sent to browser
DEBUG - 2023-09-20 15:24:35 --> Total execution time: 0.2473
ERROR - 2023-09-20 15:24:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:24:43 --> Config Class Initialized
INFO - 2023-09-20 15:24:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:24:43 --> Utf8 Class Initialized
INFO - 2023-09-20 15:24:43 --> URI Class Initialized
INFO - 2023-09-20 15:24:43 --> Router Class Initialized
INFO - 2023-09-20 15:24:43 --> Output Class Initialized
INFO - 2023-09-20 15:24:43 --> Security Class Initialized
DEBUG - 2023-09-20 15:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:24:43 --> Input Class Initialized
INFO - 2023-09-20 15:24:43 --> Language Class Initialized
INFO - 2023-09-20 15:24:43 --> Loader Class Initialized
INFO - 2023-09-20 15:24:43 --> Helper loaded: url_helper
INFO - 2023-09-20 15:24:43 --> Helper loaded: file_helper
INFO - 2023-09-20 15:24:43 --> Helper loaded: html_helper
INFO - 2023-09-20 15:24:43 --> Helper loaded: text_helper
INFO - 2023-09-20 15:24:43 --> Helper loaded: form_helper
INFO - 2023-09-20 15:24:43 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:24:43 --> Helper loaded: security_helper
INFO - 2023-09-20 15:24:43 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:24:43 --> Database Driver Class Initialized
INFO - 2023-09-20 15:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:24:43 --> Parser Class Initialized
INFO - 2023-09-20 15:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:24:43 --> Pagination Class Initialized
INFO - 2023-09-20 15:24:43 --> Form Validation Class Initialized
INFO - 2023-09-20 15:24:43 --> Controller Class Initialized
INFO - 2023-09-20 15:24:43 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:43 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:43 --> Model Class Initialized
INFO - 2023-09-20 15:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:24:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:24:43 --> Model Class Initialized
INFO - 2023-09-20 15:24:43 --> Model Class Initialized
INFO - 2023-09-20 15:24:43 --> Model Class Initialized
INFO - 2023-09-20 15:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:24:43 --> Final output sent to browser
DEBUG - 2023-09-20 15:24:43 --> Total execution time: 0.1431
ERROR - 2023-09-20 15:24:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:24:44 --> Config Class Initialized
INFO - 2023-09-20 15:24:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:24:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:24:44 --> Utf8 Class Initialized
INFO - 2023-09-20 15:24:44 --> URI Class Initialized
INFO - 2023-09-20 15:24:44 --> Router Class Initialized
INFO - 2023-09-20 15:24:44 --> Output Class Initialized
INFO - 2023-09-20 15:24:44 --> Security Class Initialized
DEBUG - 2023-09-20 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:24:44 --> Input Class Initialized
INFO - 2023-09-20 15:24:44 --> Language Class Initialized
INFO - 2023-09-20 15:24:44 --> Loader Class Initialized
INFO - 2023-09-20 15:24:44 --> Helper loaded: url_helper
INFO - 2023-09-20 15:24:44 --> Helper loaded: file_helper
INFO - 2023-09-20 15:24:44 --> Helper loaded: html_helper
INFO - 2023-09-20 15:24:44 --> Helper loaded: text_helper
INFO - 2023-09-20 15:24:44 --> Helper loaded: form_helper
INFO - 2023-09-20 15:24:44 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:24:44 --> Helper loaded: security_helper
INFO - 2023-09-20 15:24:44 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:24:44 --> Database Driver Class Initialized
INFO - 2023-09-20 15:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:24:44 --> Parser Class Initialized
INFO - 2023-09-20 15:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:24:44 --> Pagination Class Initialized
INFO - 2023-09-20 15:24:44 --> Form Validation Class Initialized
INFO - 2023-09-20 15:24:44 --> Controller Class Initialized
INFO - 2023-09-20 15:24:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:44 --> Model Class Initialized
INFO - 2023-09-20 15:24:44 --> Final output sent to browser
DEBUG - 2023-09-20 15:24:44 --> Total execution time: 0.0585
ERROR - 2023-09-20 15:24:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:24:47 --> Config Class Initialized
INFO - 2023-09-20 15:24:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:24:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:24:47 --> Utf8 Class Initialized
INFO - 2023-09-20 15:24:47 --> URI Class Initialized
INFO - 2023-09-20 15:24:47 --> Router Class Initialized
INFO - 2023-09-20 15:24:47 --> Output Class Initialized
INFO - 2023-09-20 15:24:47 --> Security Class Initialized
DEBUG - 2023-09-20 15:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:24:47 --> Input Class Initialized
INFO - 2023-09-20 15:24:47 --> Language Class Initialized
INFO - 2023-09-20 15:24:47 --> Loader Class Initialized
INFO - 2023-09-20 15:24:47 --> Helper loaded: url_helper
INFO - 2023-09-20 15:24:47 --> Helper loaded: file_helper
INFO - 2023-09-20 15:24:47 --> Helper loaded: html_helper
INFO - 2023-09-20 15:24:47 --> Helper loaded: text_helper
INFO - 2023-09-20 15:24:47 --> Helper loaded: form_helper
INFO - 2023-09-20 15:24:47 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:24:47 --> Helper loaded: security_helper
INFO - 2023-09-20 15:24:47 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:24:47 --> Database Driver Class Initialized
INFO - 2023-09-20 15:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:24:47 --> Parser Class Initialized
INFO - 2023-09-20 15:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:24:47 --> Pagination Class Initialized
INFO - 2023-09-20 15:24:47 --> Form Validation Class Initialized
INFO - 2023-09-20 15:24:47 --> Controller Class Initialized
INFO - 2023-09-20 15:24:47 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:47 --> Model Class Initialized
DEBUG - 2023-09-20 15:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:24:47 --> Model Class Initialized
INFO - 2023-09-20 15:24:48 --> Final output sent to browser
DEBUG - 2023-09-20 15:24:48 --> Total execution time: 0.9552
ERROR - 2023-09-20 15:25:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:25:03 --> Config Class Initialized
INFO - 2023-09-20 15:25:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:25:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:25:03 --> Utf8 Class Initialized
INFO - 2023-09-20 15:25:03 --> URI Class Initialized
DEBUG - 2023-09-20 15:25:03 --> No URI present. Default controller set.
INFO - 2023-09-20 15:25:03 --> Router Class Initialized
INFO - 2023-09-20 15:25:03 --> Output Class Initialized
INFO - 2023-09-20 15:25:03 --> Security Class Initialized
DEBUG - 2023-09-20 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:25:03 --> Input Class Initialized
INFO - 2023-09-20 15:25:03 --> Language Class Initialized
INFO - 2023-09-20 15:25:03 --> Loader Class Initialized
INFO - 2023-09-20 15:25:03 --> Helper loaded: url_helper
INFO - 2023-09-20 15:25:03 --> Helper loaded: file_helper
INFO - 2023-09-20 15:25:03 --> Helper loaded: html_helper
INFO - 2023-09-20 15:25:03 --> Helper loaded: text_helper
INFO - 2023-09-20 15:25:03 --> Helper loaded: form_helper
INFO - 2023-09-20 15:25:03 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:25:03 --> Helper loaded: security_helper
INFO - 2023-09-20 15:25:03 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:25:03 --> Database Driver Class Initialized
INFO - 2023-09-20 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:25:03 --> Parser Class Initialized
INFO - 2023-09-20 15:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:25:03 --> Pagination Class Initialized
INFO - 2023-09-20 15:25:03 --> Form Validation Class Initialized
INFO - 2023-09-20 15:25:03 --> Controller Class Initialized
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
DEBUG - 2023-09-20 15:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
DEBUG - 2023-09-20 15:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
DEBUG - 2023-09-20 15:25:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
INFO - 2023-09-20 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:25:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:25:03 --> Model Class Initialized
INFO - 2023-09-20 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:25:03 --> Final output sent to browser
DEBUG - 2023-09-20 15:25:03 --> Total execution time: 0.2193
ERROR - 2023-09-20 15:27:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:27:39 --> Config Class Initialized
INFO - 2023-09-20 15:27:39 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:27:39 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:27:39 --> Utf8 Class Initialized
INFO - 2023-09-20 15:27:39 --> URI Class Initialized
DEBUG - 2023-09-20 15:27:39 --> No URI present. Default controller set.
INFO - 2023-09-20 15:27:39 --> Router Class Initialized
INFO - 2023-09-20 15:27:39 --> Output Class Initialized
INFO - 2023-09-20 15:27:39 --> Security Class Initialized
DEBUG - 2023-09-20 15:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:27:39 --> Input Class Initialized
INFO - 2023-09-20 15:27:39 --> Language Class Initialized
INFO - 2023-09-20 15:27:39 --> Loader Class Initialized
INFO - 2023-09-20 15:27:39 --> Helper loaded: url_helper
INFO - 2023-09-20 15:27:39 --> Helper loaded: file_helper
INFO - 2023-09-20 15:27:39 --> Helper loaded: html_helper
INFO - 2023-09-20 15:27:39 --> Helper loaded: text_helper
INFO - 2023-09-20 15:27:39 --> Helper loaded: form_helper
INFO - 2023-09-20 15:27:39 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:27:39 --> Helper loaded: security_helper
INFO - 2023-09-20 15:27:39 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:27:39 --> Database Driver Class Initialized
INFO - 2023-09-20 15:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:27:39 --> Parser Class Initialized
INFO - 2023-09-20 15:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:27:39 --> Pagination Class Initialized
INFO - 2023-09-20 15:27:39 --> Form Validation Class Initialized
INFO - 2023-09-20 15:27:39 --> Controller Class Initialized
INFO - 2023-09-20 15:27:39 --> Model Class Initialized
DEBUG - 2023-09-20 15:27:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-20 15:27:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:27:40 --> Config Class Initialized
INFO - 2023-09-20 15:27:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:27:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:27:40 --> Utf8 Class Initialized
INFO - 2023-09-20 15:27:40 --> URI Class Initialized
INFO - 2023-09-20 15:27:40 --> Router Class Initialized
INFO - 2023-09-20 15:27:40 --> Output Class Initialized
INFO - 2023-09-20 15:27:40 --> Security Class Initialized
DEBUG - 2023-09-20 15:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:27:40 --> Input Class Initialized
INFO - 2023-09-20 15:27:40 --> Language Class Initialized
INFO - 2023-09-20 15:27:40 --> Loader Class Initialized
INFO - 2023-09-20 15:27:40 --> Helper loaded: url_helper
INFO - 2023-09-20 15:27:40 --> Helper loaded: file_helper
INFO - 2023-09-20 15:27:40 --> Helper loaded: html_helper
INFO - 2023-09-20 15:27:40 --> Helper loaded: text_helper
INFO - 2023-09-20 15:27:40 --> Helper loaded: form_helper
INFO - 2023-09-20 15:27:40 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:27:40 --> Helper loaded: security_helper
INFO - 2023-09-20 15:27:40 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:27:40 --> Database Driver Class Initialized
INFO - 2023-09-20 15:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:27:40 --> Parser Class Initialized
INFO - 2023-09-20 15:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:27:40 --> Pagination Class Initialized
INFO - 2023-09-20 15:27:40 --> Form Validation Class Initialized
INFO - 2023-09-20 15:27:40 --> Controller Class Initialized
INFO - 2023-09-20 15:27:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-20 15:27:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:27:40 --> Model Class Initialized
INFO - 2023-09-20 15:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:27:40 --> Final output sent to browser
DEBUG - 2023-09-20 15:27:40 --> Total execution time: 0.0321
ERROR - 2023-09-20 15:27:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:27:43 --> Config Class Initialized
INFO - 2023-09-20 15:27:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:27:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:27:43 --> Utf8 Class Initialized
INFO - 2023-09-20 15:27:43 --> URI Class Initialized
INFO - 2023-09-20 15:27:43 --> Router Class Initialized
INFO - 2023-09-20 15:27:43 --> Output Class Initialized
INFO - 2023-09-20 15:27:43 --> Security Class Initialized
DEBUG - 2023-09-20 15:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:27:43 --> Input Class Initialized
INFO - 2023-09-20 15:27:43 --> Language Class Initialized
INFO - 2023-09-20 15:27:43 --> Loader Class Initialized
INFO - 2023-09-20 15:27:43 --> Helper loaded: url_helper
INFO - 2023-09-20 15:27:43 --> Helper loaded: file_helper
INFO - 2023-09-20 15:27:43 --> Helper loaded: html_helper
INFO - 2023-09-20 15:27:43 --> Helper loaded: text_helper
INFO - 2023-09-20 15:27:43 --> Helper loaded: form_helper
INFO - 2023-09-20 15:27:43 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:27:43 --> Helper loaded: security_helper
INFO - 2023-09-20 15:27:43 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:27:43 --> Database Driver Class Initialized
INFO - 2023-09-20 15:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:27:43 --> Parser Class Initialized
INFO - 2023-09-20 15:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:27:43 --> Pagination Class Initialized
INFO - 2023-09-20 15:27:43 --> Form Validation Class Initialized
INFO - 2023-09-20 15:27:43 --> Controller Class Initialized
INFO - 2023-09-20 15:27:43 --> Model Class Initialized
DEBUG - 2023-09-20 15:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:27:43 --> Model Class Initialized
INFO - 2023-09-20 15:27:43 --> Final output sent to browser
DEBUG - 2023-09-20 15:27:43 --> Total execution time: 0.0194
ERROR - 2023-09-20 15:27:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:27:44 --> Config Class Initialized
INFO - 2023-09-20 15:27:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:27:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:27:44 --> Utf8 Class Initialized
INFO - 2023-09-20 15:27:44 --> URI Class Initialized
DEBUG - 2023-09-20 15:27:44 --> No URI present. Default controller set.
INFO - 2023-09-20 15:27:44 --> Router Class Initialized
INFO - 2023-09-20 15:27:44 --> Output Class Initialized
INFO - 2023-09-20 15:27:44 --> Security Class Initialized
DEBUG - 2023-09-20 15:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:27:44 --> Input Class Initialized
INFO - 2023-09-20 15:27:44 --> Language Class Initialized
INFO - 2023-09-20 15:27:44 --> Loader Class Initialized
INFO - 2023-09-20 15:27:44 --> Helper loaded: url_helper
INFO - 2023-09-20 15:27:44 --> Helper loaded: file_helper
INFO - 2023-09-20 15:27:44 --> Helper loaded: html_helper
INFO - 2023-09-20 15:27:44 --> Helper loaded: text_helper
INFO - 2023-09-20 15:27:44 --> Helper loaded: form_helper
INFO - 2023-09-20 15:27:44 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:27:44 --> Helper loaded: security_helper
INFO - 2023-09-20 15:27:44 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:27:44 --> Database Driver Class Initialized
INFO - 2023-09-20 15:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:27:44 --> Parser Class Initialized
INFO - 2023-09-20 15:27:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:27:44 --> Pagination Class Initialized
INFO - 2023-09-20 15:27:44 --> Form Validation Class Initialized
INFO - 2023-09-20 15:27:44 --> Controller Class Initialized
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:27:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
INFO - 2023-09-20 15:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:27:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:27:44 --> Model Class Initialized
INFO - 2023-09-20 15:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:27:44 --> Final output sent to browser
DEBUG - 2023-09-20 15:27:44 --> Total execution time: 0.1038
ERROR - 2023-09-20 15:28:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:28:11 --> Config Class Initialized
INFO - 2023-09-20 15:28:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:28:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:28:11 --> Utf8 Class Initialized
INFO - 2023-09-20 15:28:11 --> URI Class Initialized
INFO - 2023-09-20 15:28:11 --> Router Class Initialized
INFO - 2023-09-20 15:28:11 --> Output Class Initialized
INFO - 2023-09-20 15:28:11 --> Security Class Initialized
DEBUG - 2023-09-20 15:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:28:11 --> Input Class Initialized
INFO - 2023-09-20 15:28:11 --> Language Class Initialized
INFO - 2023-09-20 15:28:11 --> Loader Class Initialized
INFO - 2023-09-20 15:28:11 --> Helper loaded: url_helper
INFO - 2023-09-20 15:28:11 --> Helper loaded: file_helper
INFO - 2023-09-20 15:28:11 --> Helper loaded: html_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: text_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: form_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: security_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:28:12 --> Database Driver Class Initialized
INFO - 2023-09-20 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:28:12 --> Parser Class Initialized
INFO - 2023-09-20 15:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:28:12 --> Pagination Class Initialized
INFO - 2023-09-20 15:28:12 --> Form Validation Class Initialized
INFO - 2023-09-20 15:28:12 --> Controller Class Initialized
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
INFO - 2023-09-20 15:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:28:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
INFO - 2023-09-20 15:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:28:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:28:12 --> Final output sent to browser
DEBUG - 2023-09-20 15:28:12 --> Total execution time: 0.0905
ERROR - 2023-09-20 15:28:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:28:12 --> Config Class Initialized
INFO - 2023-09-20 15:28:12 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:28:12 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:28:12 --> Utf8 Class Initialized
INFO - 2023-09-20 15:28:12 --> URI Class Initialized
INFO - 2023-09-20 15:28:12 --> Router Class Initialized
INFO - 2023-09-20 15:28:12 --> Output Class Initialized
INFO - 2023-09-20 15:28:12 --> Security Class Initialized
DEBUG - 2023-09-20 15:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:28:12 --> Input Class Initialized
INFO - 2023-09-20 15:28:12 --> Language Class Initialized
INFO - 2023-09-20 15:28:12 --> Loader Class Initialized
INFO - 2023-09-20 15:28:12 --> Helper loaded: url_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: file_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: html_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: text_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: form_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: security_helper
INFO - 2023-09-20 15:28:12 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:28:12 --> Database Driver Class Initialized
INFO - 2023-09-20 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:28:12 --> Parser Class Initialized
INFO - 2023-09-20 15:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:28:12 --> Pagination Class Initialized
INFO - 2023-09-20 15:28:12 --> Form Validation Class Initialized
INFO - 2023-09-20 15:28:12 --> Controller Class Initialized
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:12 --> Model Class Initialized
INFO - 2023-09-20 15:28:12 --> Final output sent to browser
DEBUG - 2023-09-20 15:28:12 --> Total execution time: 0.0383
ERROR - 2023-09-20 15:28:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:28:16 --> Config Class Initialized
INFO - 2023-09-20 15:28:16 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:28:16 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:28:16 --> Utf8 Class Initialized
INFO - 2023-09-20 15:28:16 --> URI Class Initialized
INFO - 2023-09-20 15:28:16 --> Router Class Initialized
INFO - 2023-09-20 15:28:16 --> Output Class Initialized
INFO - 2023-09-20 15:28:16 --> Security Class Initialized
DEBUG - 2023-09-20 15:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:28:16 --> Input Class Initialized
INFO - 2023-09-20 15:28:16 --> Language Class Initialized
INFO - 2023-09-20 15:28:16 --> Loader Class Initialized
INFO - 2023-09-20 15:28:16 --> Helper loaded: url_helper
INFO - 2023-09-20 15:28:16 --> Helper loaded: file_helper
INFO - 2023-09-20 15:28:16 --> Helper loaded: html_helper
INFO - 2023-09-20 15:28:16 --> Helper loaded: text_helper
INFO - 2023-09-20 15:28:16 --> Helper loaded: form_helper
INFO - 2023-09-20 15:28:16 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:28:16 --> Helper loaded: security_helper
INFO - 2023-09-20 15:28:16 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:28:16 --> Database Driver Class Initialized
INFO - 2023-09-20 15:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:28:16 --> Parser Class Initialized
INFO - 2023-09-20 15:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:28:16 --> Pagination Class Initialized
INFO - 2023-09-20 15:28:16 --> Form Validation Class Initialized
INFO - 2023-09-20 15:28:16 --> Controller Class Initialized
INFO - 2023-09-20 15:28:16 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:16 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:16 --> Model Class Initialized
INFO - 2023-09-20 15:28:16 --> Final output sent to browser
DEBUG - 2023-09-20 15:28:16 --> Total execution time: 0.3489
ERROR - 2023-09-20 15:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:28:38 --> Config Class Initialized
INFO - 2023-09-20 15:28:38 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:28:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:28:38 --> Utf8 Class Initialized
INFO - 2023-09-20 15:28:38 --> URI Class Initialized
INFO - 2023-09-20 15:28:38 --> Router Class Initialized
INFO - 2023-09-20 15:28:38 --> Output Class Initialized
INFO - 2023-09-20 15:28:38 --> Security Class Initialized
DEBUG - 2023-09-20 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:28:38 --> Input Class Initialized
INFO - 2023-09-20 15:28:38 --> Language Class Initialized
INFO - 2023-09-20 15:28:38 --> Loader Class Initialized
INFO - 2023-09-20 15:28:38 --> Helper loaded: url_helper
INFO - 2023-09-20 15:28:38 --> Helper loaded: file_helper
INFO - 2023-09-20 15:28:38 --> Helper loaded: html_helper
INFO - 2023-09-20 15:28:38 --> Helper loaded: text_helper
INFO - 2023-09-20 15:28:38 --> Helper loaded: form_helper
INFO - 2023-09-20 15:28:38 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:28:38 --> Helper loaded: security_helper
INFO - 2023-09-20 15:28:38 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:28:38 --> Database Driver Class Initialized
INFO - 2023-09-20 15:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:28:38 --> Parser Class Initialized
INFO - 2023-09-20 15:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:28:38 --> Pagination Class Initialized
INFO - 2023-09-20 15:28:38 --> Form Validation Class Initialized
INFO - 2023-09-20 15:28:38 --> Controller Class Initialized
INFO - 2023-09-20 15:28:38 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:38 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:38 --> Model Class Initialized
INFO - 2023-09-20 15:28:38 --> Final output sent to browser
DEBUG - 2023-09-20 15:28:38 --> Total execution time: 0.0230
ERROR - 2023-09-20 15:28:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:28:45 --> Config Class Initialized
INFO - 2023-09-20 15:28:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:28:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:28:45 --> Utf8 Class Initialized
INFO - 2023-09-20 15:28:45 --> URI Class Initialized
INFO - 2023-09-20 15:28:45 --> Router Class Initialized
INFO - 2023-09-20 15:28:45 --> Output Class Initialized
INFO - 2023-09-20 15:28:45 --> Security Class Initialized
DEBUG - 2023-09-20 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:28:45 --> Input Class Initialized
INFO - 2023-09-20 15:28:45 --> Language Class Initialized
INFO - 2023-09-20 15:28:45 --> Loader Class Initialized
INFO - 2023-09-20 15:28:45 --> Helper loaded: url_helper
INFO - 2023-09-20 15:28:45 --> Helper loaded: file_helper
INFO - 2023-09-20 15:28:45 --> Helper loaded: html_helper
INFO - 2023-09-20 15:28:45 --> Helper loaded: text_helper
INFO - 2023-09-20 15:28:45 --> Helper loaded: form_helper
INFO - 2023-09-20 15:28:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:28:45 --> Helper loaded: security_helper
INFO - 2023-09-20 15:28:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:28:45 --> Database Driver Class Initialized
INFO - 2023-09-20 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:28:45 --> Parser Class Initialized
INFO - 2023-09-20 15:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:28:45 --> Pagination Class Initialized
INFO - 2023-09-20 15:28:45 --> Form Validation Class Initialized
INFO - 2023-09-20 15:28:45 --> Controller Class Initialized
INFO - 2023-09-20 15:28:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:28:45 --> Model Class Initialized
INFO - 2023-09-20 15:28:45 --> Final output sent to browser
DEBUG - 2023-09-20 15:28:45 --> Total execution time: 0.1192
ERROR - 2023-09-20 15:34:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:34:27 --> Config Class Initialized
INFO - 2023-09-20 15:34:27 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:34:27 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:34:27 --> Utf8 Class Initialized
INFO - 2023-09-20 15:34:27 --> URI Class Initialized
DEBUG - 2023-09-20 15:34:27 --> No URI present. Default controller set.
INFO - 2023-09-20 15:34:27 --> Router Class Initialized
INFO - 2023-09-20 15:34:27 --> Output Class Initialized
INFO - 2023-09-20 15:34:27 --> Security Class Initialized
DEBUG - 2023-09-20 15:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:34:27 --> Input Class Initialized
INFO - 2023-09-20 15:34:27 --> Language Class Initialized
INFO - 2023-09-20 15:34:27 --> Loader Class Initialized
INFO - 2023-09-20 15:34:27 --> Helper loaded: url_helper
INFO - 2023-09-20 15:34:27 --> Helper loaded: file_helper
INFO - 2023-09-20 15:34:27 --> Helper loaded: html_helper
INFO - 2023-09-20 15:34:27 --> Helper loaded: text_helper
INFO - 2023-09-20 15:34:27 --> Helper loaded: form_helper
INFO - 2023-09-20 15:34:27 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:34:27 --> Helper loaded: security_helper
INFO - 2023-09-20 15:34:27 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:34:27 --> Database Driver Class Initialized
INFO - 2023-09-20 15:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:34:27 --> Parser Class Initialized
INFO - 2023-09-20 15:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:34:27 --> Pagination Class Initialized
INFO - 2023-09-20 15:34:27 --> Form Validation Class Initialized
INFO - 2023-09-20 15:34:27 --> Controller Class Initialized
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
INFO - 2023-09-20 15:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:34:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:34:27 --> Model Class Initialized
INFO - 2023-09-20 15:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:34:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:34:27 --> Final output sent to browser
DEBUG - 2023-09-20 15:34:27 --> Total execution time: 0.1117
ERROR - 2023-09-20 15:34:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:34:37 --> Config Class Initialized
INFO - 2023-09-20 15:34:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:34:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:34:37 --> Utf8 Class Initialized
INFO - 2023-09-20 15:34:37 --> URI Class Initialized
INFO - 2023-09-20 15:34:37 --> Router Class Initialized
INFO - 2023-09-20 15:34:37 --> Output Class Initialized
INFO - 2023-09-20 15:34:37 --> Security Class Initialized
DEBUG - 2023-09-20 15:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:34:37 --> Input Class Initialized
INFO - 2023-09-20 15:34:37 --> Language Class Initialized
INFO - 2023-09-20 15:34:37 --> Loader Class Initialized
INFO - 2023-09-20 15:34:37 --> Helper loaded: url_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: file_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: html_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: text_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: form_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: security_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:34:37 --> Database Driver Class Initialized
INFO - 2023-09-20 15:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:34:37 --> Parser Class Initialized
INFO - 2023-09-20 15:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:34:37 --> Pagination Class Initialized
INFO - 2023-09-20 15:34:37 --> Form Validation Class Initialized
INFO - 2023-09-20 15:34:37 --> Controller Class Initialized
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
INFO - 2023-09-20 15:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:34:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
INFO - 2023-09-20 15:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:34:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:34:37 --> Final output sent to browser
DEBUG - 2023-09-20 15:34:37 --> Total execution time: 0.0882
ERROR - 2023-09-20 15:34:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:34:37 --> Config Class Initialized
INFO - 2023-09-20 15:34:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:34:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:34:37 --> Utf8 Class Initialized
INFO - 2023-09-20 15:34:37 --> URI Class Initialized
INFO - 2023-09-20 15:34:37 --> Router Class Initialized
INFO - 2023-09-20 15:34:37 --> Output Class Initialized
INFO - 2023-09-20 15:34:37 --> Security Class Initialized
DEBUG - 2023-09-20 15:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:34:37 --> Input Class Initialized
INFO - 2023-09-20 15:34:37 --> Language Class Initialized
INFO - 2023-09-20 15:34:37 --> Loader Class Initialized
INFO - 2023-09-20 15:34:37 --> Helper loaded: url_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: file_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: html_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: text_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: form_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: security_helper
INFO - 2023-09-20 15:34:37 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:34:37 --> Database Driver Class Initialized
INFO - 2023-09-20 15:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:34:37 --> Parser Class Initialized
INFO - 2023-09-20 15:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:34:37 --> Pagination Class Initialized
INFO - 2023-09-20 15:34:37 --> Form Validation Class Initialized
INFO - 2023-09-20 15:34:37 --> Controller Class Initialized
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:37 --> Model Class Initialized
INFO - 2023-09-20 15:34:37 --> Final output sent to browser
DEBUG - 2023-09-20 15:34:37 --> Total execution time: 0.0386
ERROR - 2023-09-20 15:34:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:34:40 --> Config Class Initialized
INFO - 2023-09-20 15:34:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:34:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:34:40 --> Utf8 Class Initialized
INFO - 2023-09-20 15:34:40 --> URI Class Initialized
INFO - 2023-09-20 15:34:40 --> Router Class Initialized
INFO - 2023-09-20 15:34:40 --> Output Class Initialized
INFO - 2023-09-20 15:34:40 --> Security Class Initialized
DEBUG - 2023-09-20 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:34:40 --> Input Class Initialized
INFO - 2023-09-20 15:34:40 --> Language Class Initialized
INFO - 2023-09-20 15:34:40 --> Loader Class Initialized
INFO - 2023-09-20 15:34:40 --> Helper loaded: url_helper
INFO - 2023-09-20 15:34:40 --> Helper loaded: file_helper
INFO - 2023-09-20 15:34:40 --> Helper loaded: html_helper
INFO - 2023-09-20 15:34:40 --> Helper loaded: text_helper
INFO - 2023-09-20 15:34:40 --> Helper loaded: form_helper
INFO - 2023-09-20 15:34:40 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:34:40 --> Helper loaded: security_helper
INFO - 2023-09-20 15:34:40 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:34:40 --> Database Driver Class Initialized
INFO - 2023-09-20 15:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:34:40 --> Parser Class Initialized
INFO - 2023-09-20 15:34:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:34:40 --> Pagination Class Initialized
INFO - 2023-09-20 15:34:40 --> Form Validation Class Initialized
INFO - 2023-09-20 15:34:40 --> Controller Class Initialized
INFO - 2023-09-20 15:34:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:34:40 --> Model Class Initialized
INFO - 2023-09-20 15:34:40 --> Final output sent to browser
DEBUG - 2023-09-20 15:34:40 --> Total execution time: 0.3154
ERROR - 2023-09-20 15:37:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:37:00 --> Config Class Initialized
INFO - 2023-09-20 15:37:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:37:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:37:00 --> Utf8 Class Initialized
INFO - 2023-09-20 15:37:00 --> URI Class Initialized
DEBUG - 2023-09-20 15:37:00 --> No URI present. Default controller set.
INFO - 2023-09-20 15:37:00 --> Router Class Initialized
INFO - 2023-09-20 15:37:00 --> Output Class Initialized
INFO - 2023-09-20 15:37:00 --> Security Class Initialized
DEBUG - 2023-09-20 15:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:37:00 --> Input Class Initialized
INFO - 2023-09-20 15:37:00 --> Language Class Initialized
INFO - 2023-09-20 15:37:00 --> Loader Class Initialized
INFO - 2023-09-20 15:37:00 --> Helper loaded: url_helper
INFO - 2023-09-20 15:37:00 --> Helper loaded: file_helper
INFO - 2023-09-20 15:37:00 --> Helper loaded: html_helper
INFO - 2023-09-20 15:37:00 --> Helper loaded: text_helper
INFO - 2023-09-20 15:37:00 --> Helper loaded: form_helper
INFO - 2023-09-20 15:37:00 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:37:00 --> Helper loaded: security_helper
INFO - 2023-09-20 15:37:00 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:37:00 --> Database Driver Class Initialized
INFO - 2023-09-20 15:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:37:00 --> Parser Class Initialized
INFO - 2023-09-20 15:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:37:00 --> Pagination Class Initialized
INFO - 2023-09-20 15:37:00 --> Form Validation Class Initialized
INFO - 2023-09-20 15:37:00 --> Controller Class Initialized
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
INFO - 2023-09-20 15:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:37:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:37:00 --> Model Class Initialized
INFO - 2023-09-20 15:37:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:37:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:37:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:37:01 --> Final output sent to browser
DEBUG - 2023-09-20 15:37:01 --> Total execution time: 0.1032
ERROR - 2023-09-20 15:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:37:50 --> Config Class Initialized
INFO - 2023-09-20 15:37:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:37:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:37:50 --> Utf8 Class Initialized
INFO - 2023-09-20 15:37:50 --> URI Class Initialized
INFO - 2023-09-20 15:37:50 --> Router Class Initialized
INFO - 2023-09-20 15:37:50 --> Output Class Initialized
INFO - 2023-09-20 15:37:50 --> Security Class Initialized
DEBUG - 2023-09-20 15:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:37:50 --> Input Class Initialized
INFO - 2023-09-20 15:37:50 --> Language Class Initialized
INFO - 2023-09-20 15:37:50 --> Loader Class Initialized
INFO - 2023-09-20 15:37:50 --> Helper loaded: url_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: file_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: html_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: text_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: form_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: security_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:37:50 --> Database Driver Class Initialized
INFO - 2023-09-20 15:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:37:50 --> Parser Class Initialized
INFO - 2023-09-20 15:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:37:50 --> Pagination Class Initialized
INFO - 2023-09-20 15:37:50 --> Form Validation Class Initialized
INFO - 2023-09-20 15:37:50 --> Controller Class Initialized
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
INFO - 2023-09-20 15:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:37:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
INFO - 2023-09-20 15:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:37:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:37:50 --> Final output sent to browser
DEBUG - 2023-09-20 15:37:50 --> Total execution time: 0.1036
ERROR - 2023-09-20 15:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:37:50 --> Config Class Initialized
INFO - 2023-09-20 15:37:50 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:37:50 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:37:50 --> Utf8 Class Initialized
INFO - 2023-09-20 15:37:50 --> URI Class Initialized
INFO - 2023-09-20 15:37:50 --> Router Class Initialized
INFO - 2023-09-20 15:37:50 --> Output Class Initialized
INFO - 2023-09-20 15:37:50 --> Security Class Initialized
DEBUG - 2023-09-20 15:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:37:50 --> Input Class Initialized
INFO - 2023-09-20 15:37:50 --> Language Class Initialized
INFO - 2023-09-20 15:37:50 --> Loader Class Initialized
INFO - 2023-09-20 15:37:50 --> Helper loaded: url_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: file_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: html_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: text_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: form_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: security_helper
INFO - 2023-09-20 15:37:50 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:37:50 --> Database Driver Class Initialized
INFO - 2023-09-20 15:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:37:50 --> Parser Class Initialized
INFO - 2023-09-20 15:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:37:50 --> Pagination Class Initialized
INFO - 2023-09-20 15:37:50 --> Form Validation Class Initialized
INFO - 2023-09-20 15:37:50 --> Controller Class Initialized
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:50 --> Model Class Initialized
INFO - 2023-09-20 15:37:50 --> Final output sent to browser
DEBUG - 2023-09-20 15:37:50 --> Total execution time: 0.0383
ERROR - 2023-09-20 15:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:37:53 --> Config Class Initialized
INFO - 2023-09-20 15:37:53 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:37:53 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:37:53 --> Utf8 Class Initialized
INFO - 2023-09-20 15:37:53 --> URI Class Initialized
INFO - 2023-09-20 15:37:53 --> Router Class Initialized
INFO - 2023-09-20 15:37:53 --> Output Class Initialized
INFO - 2023-09-20 15:37:53 --> Security Class Initialized
DEBUG - 2023-09-20 15:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:37:53 --> Input Class Initialized
INFO - 2023-09-20 15:37:53 --> Language Class Initialized
INFO - 2023-09-20 15:37:53 --> Loader Class Initialized
INFO - 2023-09-20 15:37:53 --> Helper loaded: url_helper
INFO - 2023-09-20 15:37:53 --> Helper loaded: file_helper
INFO - 2023-09-20 15:37:53 --> Helper loaded: html_helper
INFO - 2023-09-20 15:37:53 --> Helper loaded: text_helper
INFO - 2023-09-20 15:37:53 --> Helper loaded: form_helper
INFO - 2023-09-20 15:37:53 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:37:53 --> Helper loaded: security_helper
INFO - 2023-09-20 15:37:53 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:37:53 --> Database Driver Class Initialized
INFO - 2023-09-20 15:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:37:53 --> Parser Class Initialized
INFO - 2023-09-20 15:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:37:53 --> Pagination Class Initialized
INFO - 2023-09-20 15:37:53 --> Form Validation Class Initialized
INFO - 2023-09-20 15:37:53 --> Controller Class Initialized
INFO - 2023-09-20 15:37:53 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:53 --> Model Class Initialized
DEBUG - 2023-09-20 15:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:37:53 --> Model Class Initialized
INFO - 2023-09-20 15:37:53 --> Final output sent to browser
DEBUG - 2023-09-20 15:37:53 --> Total execution time: 0.3047
ERROR - 2023-09-20 15:38:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:38:00 --> Config Class Initialized
INFO - 2023-09-20 15:38:00 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:38:00 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:38:00 --> Utf8 Class Initialized
INFO - 2023-09-20 15:38:00 --> URI Class Initialized
DEBUG - 2023-09-20 15:38:00 --> No URI present. Default controller set.
INFO - 2023-09-20 15:38:00 --> Router Class Initialized
INFO - 2023-09-20 15:38:00 --> Output Class Initialized
INFO - 2023-09-20 15:38:01 --> Security Class Initialized
DEBUG - 2023-09-20 15:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:38:01 --> Input Class Initialized
INFO - 2023-09-20 15:38:01 --> Language Class Initialized
INFO - 2023-09-20 15:38:01 --> Loader Class Initialized
INFO - 2023-09-20 15:38:01 --> Helper loaded: url_helper
INFO - 2023-09-20 15:38:01 --> Helper loaded: file_helper
INFO - 2023-09-20 15:38:01 --> Helper loaded: html_helper
INFO - 2023-09-20 15:38:01 --> Helper loaded: text_helper
INFO - 2023-09-20 15:38:01 --> Helper loaded: form_helper
INFO - 2023-09-20 15:38:01 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:38:01 --> Helper loaded: security_helper
INFO - 2023-09-20 15:38:01 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:38:01 --> Database Driver Class Initialized
INFO - 2023-09-20 15:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:38:01 --> Parser Class Initialized
INFO - 2023-09-20 15:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:38:01 --> Pagination Class Initialized
INFO - 2023-09-20 15:38:01 --> Form Validation Class Initialized
INFO - 2023-09-20 15:38:01 --> Controller Class Initialized
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
INFO - 2023-09-20 15:38:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:38:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:38:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:38:01 --> Model Class Initialized
INFO - 2023-09-20 15:38:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:38:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:38:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:38:01 --> Final output sent to browser
DEBUG - 2023-09-20 15:38:01 --> Total execution time: 0.0961
ERROR - 2023-09-20 15:38:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:38:03 --> Config Class Initialized
INFO - 2023-09-20 15:38:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:38:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:38:03 --> Utf8 Class Initialized
INFO - 2023-09-20 15:38:03 --> URI Class Initialized
DEBUG - 2023-09-20 15:38:03 --> No URI present. Default controller set.
INFO - 2023-09-20 15:38:03 --> Router Class Initialized
INFO - 2023-09-20 15:38:03 --> Output Class Initialized
INFO - 2023-09-20 15:38:03 --> Security Class Initialized
DEBUG - 2023-09-20 15:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:38:03 --> Input Class Initialized
INFO - 2023-09-20 15:38:03 --> Language Class Initialized
INFO - 2023-09-20 15:38:03 --> Loader Class Initialized
INFO - 2023-09-20 15:38:03 --> Helper loaded: url_helper
INFO - 2023-09-20 15:38:03 --> Helper loaded: file_helper
INFO - 2023-09-20 15:38:03 --> Helper loaded: html_helper
INFO - 2023-09-20 15:38:03 --> Helper loaded: text_helper
INFO - 2023-09-20 15:38:03 --> Helper loaded: form_helper
INFO - 2023-09-20 15:38:03 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:38:03 --> Helper loaded: security_helper
INFO - 2023-09-20 15:38:03 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:38:03 --> Database Driver Class Initialized
INFO - 2023-09-20 15:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:38:03 --> Parser Class Initialized
INFO - 2023-09-20 15:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:38:03 --> Pagination Class Initialized
INFO - 2023-09-20 15:38:03 --> Form Validation Class Initialized
INFO - 2023-09-20 15:38:03 --> Controller Class Initialized
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
INFO - 2023-09-20 15:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:38:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:38:03 --> Model Class Initialized
INFO - 2023-09-20 15:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:38:03 --> Final output sent to browser
DEBUG - 2023-09-20 15:38:03 --> Total execution time: 0.1007
ERROR - 2023-09-20 15:38:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:38:10 --> Config Class Initialized
INFO - 2023-09-20 15:38:10 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:38:10 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:38:10 --> Utf8 Class Initialized
INFO - 2023-09-20 15:38:10 --> URI Class Initialized
INFO - 2023-09-20 15:38:10 --> Router Class Initialized
INFO - 2023-09-20 15:38:10 --> Output Class Initialized
INFO - 2023-09-20 15:38:10 --> Security Class Initialized
DEBUG - 2023-09-20 15:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:38:10 --> Input Class Initialized
INFO - 2023-09-20 15:38:10 --> Language Class Initialized
INFO - 2023-09-20 15:38:10 --> Loader Class Initialized
INFO - 2023-09-20 15:38:10 --> Helper loaded: url_helper
INFO - 2023-09-20 15:38:10 --> Helper loaded: file_helper
INFO - 2023-09-20 15:38:10 --> Helper loaded: html_helper
INFO - 2023-09-20 15:38:10 --> Helper loaded: text_helper
INFO - 2023-09-20 15:38:10 --> Helper loaded: form_helper
INFO - 2023-09-20 15:38:10 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:38:10 --> Helper loaded: security_helper
INFO - 2023-09-20 15:38:10 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:38:10 --> Database Driver Class Initialized
INFO - 2023-09-20 15:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:38:10 --> Parser Class Initialized
INFO - 2023-09-20 15:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:38:10 --> Pagination Class Initialized
INFO - 2023-09-20 15:38:10 --> Form Validation Class Initialized
INFO - 2023-09-20 15:38:10 --> Controller Class Initialized
DEBUG - 2023-09-20 15:38:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:10 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:10 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:10 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:10 --> Model Class Initialized
INFO - 2023-09-20 15:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-20 15:38:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:38:10 --> Model Class Initialized
INFO - 2023-09-20 15:38:10 --> Model Class Initialized
INFO - 2023-09-20 15:38:10 --> Model Class Initialized
INFO - 2023-09-20 15:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:38:10 --> Final output sent to browser
DEBUG - 2023-09-20 15:38:10 --> Total execution time: 0.0866
ERROR - 2023-09-20 15:38:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:38:11 --> Config Class Initialized
INFO - 2023-09-20 15:38:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:38:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:38:11 --> Utf8 Class Initialized
INFO - 2023-09-20 15:38:11 --> URI Class Initialized
INFO - 2023-09-20 15:38:11 --> Router Class Initialized
INFO - 2023-09-20 15:38:11 --> Output Class Initialized
INFO - 2023-09-20 15:38:11 --> Security Class Initialized
DEBUG - 2023-09-20 15:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:38:11 --> Input Class Initialized
INFO - 2023-09-20 15:38:11 --> Language Class Initialized
INFO - 2023-09-20 15:38:11 --> Loader Class Initialized
INFO - 2023-09-20 15:38:11 --> Helper loaded: url_helper
INFO - 2023-09-20 15:38:11 --> Helper loaded: file_helper
INFO - 2023-09-20 15:38:11 --> Helper loaded: html_helper
INFO - 2023-09-20 15:38:11 --> Helper loaded: text_helper
INFO - 2023-09-20 15:38:11 --> Helper loaded: form_helper
INFO - 2023-09-20 15:38:11 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:38:11 --> Helper loaded: security_helper
INFO - 2023-09-20 15:38:11 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:38:11 --> Database Driver Class Initialized
INFO - 2023-09-20 15:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:38:11 --> Parser Class Initialized
INFO - 2023-09-20 15:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:38:11 --> Pagination Class Initialized
INFO - 2023-09-20 15:38:11 --> Form Validation Class Initialized
INFO - 2023-09-20 15:38:11 --> Controller Class Initialized
DEBUG - 2023-09-20 15:38:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:11 --> Model Class Initialized
DEBUG - 2023-09-20 15:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:38:11 --> Model Class Initialized
INFO - 2023-09-20 15:38:11 --> Final output sent to browser
DEBUG - 2023-09-20 15:38:11 --> Total execution time: 0.0238
ERROR - 2023-09-20 15:40:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:40:42 --> Config Class Initialized
INFO - 2023-09-20 15:40:42 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:40:42 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:40:42 --> Utf8 Class Initialized
INFO - 2023-09-20 15:40:42 --> URI Class Initialized
INFO - 2023-09-20 15:40:42 --> Router Class Initialized
INFO - 2023-09-20 15:40:42 --> Output Class Initialized
INFO - 2023-09-20 15:40:42 --> Security Class Initialized
DEBUG - 2023-09-20 15:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:40:42 --> Input Class Initialized
INFO - 2023-09-20 15:40:42 --> Language Class Initialized
INFO - 2023-09-20 15:40:42 --> Loader Class Initialized
INFO - 2023-09-20 15:40:42 --> Helper loaded: url_helper
INFO - 2023-09-20 15:40:42 --> Helper loaded: file_helper
INFO - 2023-09-20 15:40:42 --> Helper loaded: html_helper
INFO - 2023-09-20 15:40:42 --> Helper loaded: text_helper
INFO - 2023-09-20 15:40:42 --> Helper loaded: form_helper
INFO - 2023-09-20 15:40:42 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:40:42 --> Helper loaded: security_helper
INFO - 2023-09-20 15:40:42 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:40:42 --> Database Driver Class Initialized
INFO - 2023-09-20 15:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:40:42 --> Parser Class Initialized
INFO - 2023-09-20 15:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:40:42 --> Pagination Class Initialized
INFO - 2023-09-20 15:40:42 --> Form Validation Class Initialized
INFO - 2023-09-20 15:40:42 --> Controller Class Initialized
DEBUG - 2023-09-20 15:40:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:40:42 --> Model Class Initialized
DEBUG - 2023-09-20 15:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:40:42 --> Model Class Initialized
INFO - 2023-09-20 15:40:42 --> Final output sent to browser
DEBUG - 2023-09-20 15:40:42 --> Total execution time: 0.0398
ERROR - 2023-09-20 15:41:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:41:06 --> Config Class Initialized
INFO - 2023-09-20 15:41:06 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:41:06 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:41:06 --> Utf8 Class Initialized
INFO - 2023-09-20 15:41:06 --> URI Class Initialized
DEBUG - 2023-09-20 15:41:06 --> No URI present. Default controller set.
INFO - 2023-09-20 15:41:06 --> Router Class Initialized
INFO - 2023-09-20 15:41:06 --> Output Class Initialized
INFO - 2023-09-20 15:41:06 --> Security Class Initialized
DEBUG - 2023-09-20 15:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:41:06 --> Input Class Initialized
INFO - 2023-09-20 15:41:06 --> Language Class Initialized
INFO - 2023-09-20 15:41:06 --> Loader Class Initialized
INFO - 2023-09-20 15:41:06 --> Helper loaded: url_helper
INFO - 2023-09-20 15:41:06 --> Helper loaded: file_helper
INFO - 2023-09-20 15:41:06 --> Helper loaded: html_helper
INFO - 2023-09-20 15:41:06 --> Helper loaded: text_helper
INFO - 2023-09-20 15:41:06 --> Helper loaded: form_helper
INFO - 2023-09-20 15:41:06 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:41:06 --> Helper loaded: security_helper
INFO - 2023-09-20 15:41:06 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:41:06 --> Database Driver Class Initialized
INFO - 2023-09-20 15:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:41:06 --> Parser Class Initialized
INFO - 2023-09-20 15:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:41:06 --> Pagination Class Initialized
INFO - 2023-09-20 15:41:06 --> Form Validation Class Initialized
INFO - 2023-09-20 15:41:06 --> Controller Class Initialized
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
INFO - 2023-09-20 15:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:41:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:41:06 --> Model Class Initialized
INFO - 2023-09-20 15:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:41:07 --> Final output sent to browser
DEBUG - 2023-09-20 15:41:07 --> Total execution time: 0.1052
ERROR - 2023-09-20 15:41:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:41:43 --> Config Class Initialized
INFO - 2023-09-20 15:41:43 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:41:43 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:41:43 --> Utf8 Class Initialized
INFO - 2023-09-20 15:41:43 --> URI Class Initialized
INFO - 2023-09-20 15:41:43 --> Router Class Initialized
INFO - 2023-09-20 15:41:43 --> Output Class Initialized
INFO - 2023-09-20 15:41:43 --> Security Class Initialized
DEBUG - 2023-09-20 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:41:43 --> Input Class Initialized
INFO - 2023-09-20 15:41:43 --> Language Class Initialized
INFO - 2023-09-20 15:41:43 --> Loader Class Initialized
INFO - 2023-09-20 15:41:43 --> Helper loaded: url_helper
INFO - 2023-09-20 15:41:43 --> Helper loaded: file_helper
INFO - 2023-09-20 15:41:43 --> Helper loaded: html_helper
INFO - 2023-09-20 15:41:43 --> Helper loaded: text_helper
INFO - 2023-09-20 15:41:43 --> Helper loaded: form_helper
INFO - 2023-09-20 15:41:43 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:41:43 --> Helper loaded: security_helper
INFO - 2023-09-20 15:41:43 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:41:43 --> Database Driver Class Initialized
INFO - 2023-09-20 15:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:41:43 --> Parser Class Initialized
INFO - 2023-09-20 15:41:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:41:43 --> Pagination Class Initialized
INFO - 2023-09-20 15:41:43 --> Form Validation Class Initialized
INFO - 2023-09-20 15:41:43 --> Controller Class Initialized
INFO - 2023-09-20 15:41:43 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:43 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:43 --> Model Class Initialized
INFO - 2023-09-20 15:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:41:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:41:43 --> Model Class Initialized
INFO - 2023-09-20 15:41:43 --> Model Class Initialized
INFO - 2023-09-20 15:41:43 --> Model Class Initialized
INFO - 2023-09-20 15:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:41:43 --> Final output sent to browser
DEBUG - 2023-09-20 15:41:43 --> Total execution time: 0.0889
ERROR - 2023-09-20 15:41:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:41:44 --> Config Class Initialized
INFO - 2023-09-20 15:41:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:41:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:41:44 --> Utf8 Class Initialized
INFO - 2023-09-20 15:41:44 --> URI Class Initialized
INFO - 2023-09-20 15:41:44 --> Router Class Initialized
INFO - 2023-09-20 15:41:44 --> Output Class Initialized
INFO - 2023-09-20 15:41:44 --> Security Class Initialized
DEBUG - 2023-09-20 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:41:44 --> Input Class Initialized
INFO - 2023-09-20 15:41:44 --> Language Class Initialized
INFO - 2023-09-20 15:41:44 --> Loader Class Initialized
INFO - 2023-09-20 15:41:44 --> Helper loaded: url_helper
INFO - 2023-09-20 15:41:44 --> Helper loaded: file_helper
INFO - 2023-09-20 15:41:44 --> Helper loaded: html_helper
INFO - 2023-09-20 15:41:44 --> Helper loaded: text_helper
INFO - 2023-09-20 15:41:44 --> Helper loaded: form_helper
INFO - 2023-09-20 15:41:44 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:41:44 --> Helper loaded: security_helper
INFO - 2023-09-20 15:41:44 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:41:44 --> Database Driver Class Initialized
INFO - 2023-09-20 15:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:41:44 --> Parser Class Initialized
INFO - 2023-09-20 15:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:41:44 --> Pagination Class Initialized
INFO - 2023-09-20 15:41:44 --> Form Validation Class Initialized
INFO - 2023-09-20 15:41:44 --> Controller Class Initialized
INFO - 2023-09-20 15:41:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:44 --> Model Class Initialized
INFO - 2023-09-20 15:41:44 --> Final output sent to browser
DEBUG - 2023-09-20 15:41:44 --> Total execution time: 0.0438
ERROR - 2023-09-20 15:41:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:41:47 --> Config Class Initialized
INFO - 2023-09-20 15:41:47 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:41:47 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:41:47 --> Utf8 Class Initialized
INFO - 2023-09-20 15:41:47 --> URI Class Initialized
INFO - 2023-09-20 15:41:47 --> Router Class Initialized
INFO - 2023-09-20 15:41:47 --> Output Class Initialized
INFO - 2023-09-20 15:41:47 --> Security Class Initialized
DEBUG - 2023-09-20 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:41:47 --> Input Class Initialized
INFO - 2023-09-20 15:41:47 --> Language Class Initialized
INFO - 2023-09-20 15:41:47 --> Loader Class Initialized
INFO - 2023-09-20 15:41:47 --> Helper loaded: url_helper
INFO - 2023-09-20 15:41:47 --> Helper loaded: file_helper
INFO - 2023-09-20 15:41:47 --> Helper loaded: html_helper
INFO - 2023-09-20 15:41:47 --> Helper loaded: text_helper
INFO - 2023-09-20 15:41:47 --> Helper loaded: form_helper
INFO - 2023-09-20 15:41:47 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:41:47 --> Helper loaded: security_helper
INFO - 2023-09-20 15:41:47 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:41:47 --> Database Driver Class Initialized
INFO - 2023-09-20 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:41:47 --> Parser Class Initialized
INFO - 2023-09-20 15:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:41:47 --> Pagination Class Initialized
INFO - 2023-09-20 15:41:47 --> Form Validation Class Initialized
INFO - 2023-09-20 15:41:47 --> Controller Class Initialized
INFO - 2023-09-20 15:41:47 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:47 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:47 --> Model Class Initialized
INFO - 2023-09-20 15:41:47 --> Final output sent to browser
DEBUG - 2023-09-20 15:41:47 --> Total execution time: 0.3347
ERROR - 2023-09-20 15:41:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:41:56 --> Config Class Initialized
INFO - 2023-09-20 15:41:56 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:41:56 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:41:56 --> Utf8 Class Initialized
INFO - 2023-09-20 15:41:56 --> URI Class Initialized
DEBUG - 2023-09-20 15:41:56 --> No URI present. Default controller set.
INFO - 2023-09-20 15:41:56 --> Router Class Initialized
INFO - 2023-09-20 15:41:56 --> Output Class Initialized
INFO - 2023-09-20 15:41:56 --> Security Class Initialized
DEBUG - 2023-09-20 15:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:41:56 --> Input Class Initialized
INFO - 2023-09-20 15:41:56 --> Language Class Initialized
INFO - 2023-09-20 15:41:56 --> Loader Class Initialized
INFO - 2023-09-20 15:41:56 --> Helper loaded: url_helper
INFO - 2023-09-20 15:41:56 --> Helper loaded: file_helper
INFO - 2023-09-20 15:41:56 --> Helper loaded: html_helper
INFO - 2023-09-20 15:41:56 --> Helper loaded: text_helper
INFO - 2023-09-20 15:41:56 --> Helper loaded: form_helper
INFO - 2023-09-20 15:41:56 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:41:56 --> Helper loaded: security_helper
INFO - 2023-09-20 15:41:56 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:41:56 --> Database Driver Class Initialized
INFO - 2023-09-20 15:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:41:56 --> Parser Class Initialized
INFO - 2023-09-20 15:41:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:41:56 --> Pagination Class Initialized
INFO - 2023-09-20 15:41:56 --> Form Validation Class Initialized
INFO - 2023-09-20 15:41:56 --> Controller Class Initialized
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
DEBUG - 2023-09-20 15:41:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
INFO - 2023-09-20 15:41:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:41:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:41:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:41:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:41:56 --> Model Class Initialized
INFO - 2023-09-20 15:41:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:41:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:41:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:41:56 --> Final output sent to browser
DEBUG - 2023-09-20 15:41:56 --> Total execution time: 0.1005
ERROR - 2023-09-20 15:42:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:42:45 --> Config Class Initialized
INFO - 2023-09-20 15:42:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:42:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:42:45 --> Utf8 Class Initialized
INFO - 2023-09-20 15:42:45 --> URI Class Initialized
DEBUG - 2023-09-20 15:42:45 --> No URI present. Default controller set.
INFO - 2023-09-20 15:42:45 --> Router Class Initialized
INFO - 2023-09-20 15:42:45 --> Output Class Initialized
INFO - 2023-09-20 15:42:45 --> Security Class Initialized
DEBUG - 2023-09-20 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:42:45 --> Input Class Initialized
INFO - 2023-09-20 15:42:45 --> Language Class Initialized
INFO - 2023-09-20 15:42:45 --> Loader Class Initialized
INFO - 2023-09-20 15:42:45 --> Helper loaded: url_helper
INFO - 2023-09-20 15:42:45 --> Helper loaded: file_helper
INFO - 2023-09-20 15:42:45 --> Helper loaded: html_helper
INFO - 2023-09-20 15:42:45 --> Helper loaded: text_helper
INFO - 2023-09-20 15:42:45 --> Helper loaded: form_helper
INFO - 2023-09-20 15:42:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:42:45 --> Helper loaded: security_helper
INFO - 2023-09-20 15:42:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:42:45 --> Database Driver Class Initialized
INFO - 2023-09-20 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:42:45 --> Parser Class Initialized
INFO - 2023-09-20 15:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:42:45 --> Pagination Class Initialized
INFO - 2023-09-20 15:42:45 --> Form Validation Class Initialized
INFO - 2023-09-20 15:42:45 --> Controller Class Initialized
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:42:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
INFO - 2023-09-20 15:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:42:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:42:45 --> Model Class Initialized
INFO - 2023-09-20 15:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:42:45 --> Final output sent to browser
DEBUG - 2023-09-20 15:42:45 --> Total execution time: 0.1043
ERROR - 2023-09-20 15:42:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:42:57 --> Config Class Initialized
INFO - 2023-09-20 15:42:57 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:42:57 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:42:57 --> Utf8 Class Initialized
INFO - 2023-09-20 15:42:57 --> URI Class Initialized
DEBUG - 2023-09-20 15:42:57 --> No URI present. Default controller set.
INFO - 2023-09-20 15:42:57 --> Router Class Initialized
INFO - 2023-09-20 15:42:57 --> Output Class Initialized
INFO - 2023-09-20 15:42:57 --> Security Class Initialized
DEBUG - 2023-09-20 15:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:42:57 --> Input Class Initialized
INFO - 2023-09-20 15:42:57 --> Language Class Initialized
INFO - 2023-09-20 15:42:57 --> Loader Class Initialized
INFO - 2023-09-20 15:42:57 --> Helper loaded: url_helper
INFO - 2023-09-20 15:42:57 --> Helper loaded: file_helper
INFO - 2023-09-20 15:42:57 --> Helper loaded: html_helper
INFO - 2023-09-20 15:42:57 --> Helper loaded: text_helper
INFO - 2023-09-20 15:42:57 --> Helper loaded: form_helper
INFO - 2023-09-20 15:42:57 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:42:57 --> Helper loaded: security_helper
INFO - 2023-09-20 15:42:57 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:42:57 --> Database Driver Class Initialized
INFO - 2023-09-20 15:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:42:57 --> Parser Class Initialized
INFO - 2023-09-20 15:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:42:57 --> Pagination Class Initialized
INFO - 2023-09-20 15:42:57 --> Form Validation Class Initialized
INFO - 2023-09-20 15:42:57 --> Controller Class Initialized
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
DEBUG - 2023-09-20 15:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
DEBUG - 2023-09-20 15:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
DEBUG - 2023-09-20 15:42:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
INFO - 2023-09-20 15:42:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:42:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:42:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:42:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:42:57 --> Model Class Initialized
INFO - 2023-09-20 15:42:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:42:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:42:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:42:57 --> Final output sent to browser
DEBUG - 2023-09-20 15:42:57 --> Total execution time: 0.1014
ERROR - 2023-09-20 15:43:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:02 --> Config Class Initialized
INFO - 2023-09-20 15:43:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:02 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:02 --> URI Class Initialized
DEBUG - 2023-09-20 15:43:02 --> No URI present. Default controller set.
INFO - 2023-09-20 15:43:02 --> Router Class Initialized
INFO - 2023-09-20 15:43:02 --> Output Class Initialized
INFO - 2023-09-20 15:43:02 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:02 --> Input Class Initialized
INFO - 2023-09-20 15:43:02 --> Language Class Initialized
INFO - 2023-09-20 15:43:02 --> Loader Class Initialized
INFO - 2023-09-20 15:43:02 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:02 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:02 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:02 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:02 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:02 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:02 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:02 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:02 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:02 --> Parser Class Initialized
INFO - 2023-09-20 15:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:02 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:02 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:02 --> Controller Class Initialized
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
INFO - 2023-09-20 15:43:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:43:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:43:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:43:02 --> Model Class Initialized
INFO - 2023-09-20 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:43:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:43:03 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:03 --> Total execution time: 0.2066
ERROR - 2023-09-20 15:43:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:13 --> Config Class Initialized
INFO - 2023-09-20 15:43:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:13 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:13 --> URI Class Initialized
INFO - 2023-09-20 15:43:13 --> Router Class Initialized
INFO - 2023-09-20 15:43:13 --> Output Class Initialized
INFO - 2023-09-20 15:43:13 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:13 --> Input Class Initialized
INFO - 2023-09-20 15:43:13 --> Language Class Initialized
INFO - 2023-09-20 15:43:13 --> Loader Class Initialized
INFO - 2023-09-20 15:43:13 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:13 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:13 --> Parser Class Initialized
INFO - 2023-09-20 15:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:13 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:13 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:13 --> Controller Class Initialized
DEBUG - 2023-09-20 15:43:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:13 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
INFO - 2023-09-20 15:43:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-20 15:43:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:43:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
INFO - 2023-09-20 15:43:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:43:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:43:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:43:13 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:13 --> Total execution time: 0.1414
ERROR - 2023-09-20 15:43:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:13 --> Config Class Initialized
INFO - 2023-09-20 15:43:13 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:13 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:13 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:13 --> URI Class Initialized
INFO - 2023-09-20 15:43:13 --> Router Class Initialized
INFO - 2023-09-20 15:43:13 --> Output Class Initialized
INFO - 2023-09-20 15:43:13 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:13 --> Input Class Initialized
INFO - 2023-09-20 15:43:13 --> Language Class Initialized
INFO - 2023-09-20 15:43:13 --> Loader Class Initialized
INFO - 2023-09-20 15:43:13 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:13 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:13 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:13 --> Parser Class Initialized
INFO - 2023-09-20 15:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:13 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:13 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:13 --> Controller Class Initialized
DEBUG - 2023-09-20 15:43:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:13 --> Model Class Initialized
INFO - 2023-09-20 15:43:13 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:13 --> Total execution time: 0.0314
ERROR - 2023-09-20 15:43:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:17 --> Config Class Initialized
INFO - 2023-09-20 15:43:17 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:17 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:17 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:17 --> URI Class Initialized
INFO - 2023-09-20 15:43:17 --> Router Class Initialized
INFO - 2023-09-20 15:43:17 --> Output Class Initialized
INFO - 2023-09-20 15:43:17 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:17 --> Input Class Initialized
INFO - 2023-09-20 15:43:17 --> Language Class Initialized
INFO - 2023-09-20 15:43:17 --> Loader Class Initialized
INFO - 2023-09-20 15:43:17 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:17 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:17 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:17 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:17 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:17 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:17 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:17 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:17 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:17 --> Parser Class Initialized
INFO - 2023-09-20 15:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:17 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:17 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:17 --> Controller Class Initialized
DEBUG - 2023-09-20 15:43:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:17 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:17 --> Model Class Initialized
INFO - 2023-09-20 15:43:17 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:17 --> Total execution time: 0.1508
ERROR - 2023-09-20 15:43:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:23 --> Config Class Initialized
INFO - 2023-09-20 15:43:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:23 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:23 --> URI Class Initialized
INFO - 2023-09-20 15:43:23 --> Router Class Initialized
INFO - 2023-09-20 15:43:23 --> Output Class Initialized
INFO - 2023-09-20 15:43:23 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:23 --> Input Class Initialized
INFO - 2023-09-20 15:43:23 --> Language Class Initialized
INFO - 2023-09-20 15:43:23 --> Loader Class Initialized
INFO - 2023-09-20 15:43:23 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:23 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:23 --> Parser Class Initialized
INFO - 2023-09-20 15:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:23 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:23 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:23 --> Controller Class Initialized
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
INFO - 2023-09-20 15:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:43:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
INFO - 2023-09-20 15:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:43:23 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:23 --> Total execution time: 0.1498
ERROR - 2023-09-20 15:43:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:23 --> Config Class Initialized
INFO - 2023-09-20 15:43:23 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:23 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:23 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:23 --> URI Class Initialized
INFO - 2023-09-20 15:43:23 --> Router Class Initialized
INFO - 2023-09-20 15:43:23 --> Output Class Initialized
INFO - 2023-09-20 15:43:23 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:23 --> Input Class Initialized
INFO - 2023-09-20 15:43:23 --> Language Class Initialized
INFO - 2023-09-20 15:43:23 --> Loader Class Initialized
INFO - 2023-09-20 15:43:23 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:23 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:23 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:23 --> Parser Class Initialized
INFO - 2023-09-20 15:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:23 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:23 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:23 --> Controller Class Initialized
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:23 --> Model Class Initialized
INFO - 2023-09-20 15:43:23 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:23 --> Total execution time: 0.0535
ERROR - 2023-09-20 15:43:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:38 --> Config Class Initialized
INFO - 2023-09-20 15:43:38 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:38 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:38 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:38 --> URI Class Initialized
INFO - 2023-09-20 15:43:38 --> Router Class Initialized
INFO - 2023-09-20 15:43:38 --> Output Class Initialized
INFO - 2023-09-20 15:43:38 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:38 --> Input Class Initialized
INFO - 2023-09-20 15:43:38 --> Language Class Initialized
INFO - 2023-09-20 15:43:38 --> Loader Class Initialized
INFO - 2023-09-20 15:43:38 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:38 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:38 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:38 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:38 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:38 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:38 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:38 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:38 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:38 --> Parser Class Initialized
INFO - 2023-09-20 15:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:38 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:38 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:38 --> Controller Class Initialized
INFO - 2023-09-20 15:43:38 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:38 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:38 --> Model Class Initialized
INFO - 2023-09-20 15:43:38 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:38 --> Total execution time: 0.0589
ERROR - 2023-09-20 15:43:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:41 --> Config Class Initialized
INFO - 2023-09-20 15:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:41 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:41 --> URI Class Initialized
INFO - 2023-09-20 15:43:41 --> Router Class Initialized
INFO - 2023-09-20 15:43:41 --> Output Class Initialized
INFO - 2023-09-20 15:43:41 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:41 --> Input Class Initialized
INFO - 2023-09-20 15:43:41 --> Language Class Initialized
INFO - 2023-09-20 15:43:41 --> Loader Class Initialized
INFO - 2023-09-20 15:43:41 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:41 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:41 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:41 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:41 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:41 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:41 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:41 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:41 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:41 --> Parser Class Initialized
INFO - 2023-09-20 15:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:41 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:41 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:41 --> Controller Class Initialized
INFO - 2023-09-20 15:43:41 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:41 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:41 --> Model Class Initialized
INFO - 2023-09-20 15:43:41 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:41 --> Total execution time: 0.0557
ERROR - 2023-09-20 15:43:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:43:52 --> Config Class Initialized
INFO - 2023-09-20 15:43:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:43:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:43:52 --> Utf8 Class Initialized
INFO - 2023-09-20 15:43:52 --> URI Class Initialized
DEBUG - 2023-09-20 15:43:52 --> No URI present. Default controller set.
INFO - 2023-09-20 15:43:52 --> Router Class Initialized
INFO - 2023-09-20 15:43:52 --> Output Class Initialized
INFO - 2023-09-20 15:43:52 --> Security Class Initialized
DEBUG - 2023-09-20 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:43:52 --> Input Class Initialized
INFO - 2023-09-20 15:43:52 --> Language Class Initialized
INFO - 2023-09-20 15:43:52 --> Loader Class Initialized
INFO - 2023-09-20 15:43:52 --> Helper loaded: url_helper
INFO - 2023-09-20 15:43:52 --> Helper loaded: file_helper
INFO - 2023-09-20 15:43:52 --> Helper loaded: html_helper
INFO - 2023-09-20 15:43:52 --> Helper loaded: text_helper
INFO - 2023-09-20 15:43:52 --> Helper loaded: form_helper
INFO - 2023-09-20 15:43:52 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:43:52 --> Helper loaded: security_helper
INFO - 2023-09-20 15:43:52 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:43:52 --> Database Driver Class Initialized
INFO - 2023-09-20 15:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:43:52 --> Parser Class Initialized
INFO - 2023-09-20 15:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:43:52 --> Pagination Class Initialized
INFO - 2023-09-20 15:43:52 --> Form Validation Class Initialized
INFO - 2023-09-20 15:43:52 --> Controller Class Initialized
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
DEBUG - 2023-09-20 15:43:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
INFO - 2023-09-20 15:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:43:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:43:52 --> Model Class Initialized
INFO - 2023-09-20 15:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:43:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:43:52 --> Final output sent to browser
DEBUG - 2023-09-20 15:43:52 --> Total execution time: 0.2304
ERROR - 2023-09-20 15:44:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:02 --> Config Class Initialized
INFO - 2023-09-20 15:44:02 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:02 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:02 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:02 --> URI Class Initialized
INFO - 2023-09-20 15:44:02 --> Router Class Initialized
INFO - 2023-09-20 15:44:02 --> Output Class Initialized
INFO - 2023-09-20 15:44:02 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:02 --> Input Class Initialized
INFO - 2023-09-20 15:44:02 --> Language Class Initialized
INFO - 2023-09-20 15:44:02 --> Loader Class Initialized
INFO - 2023-09-20 15:44:02 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:02 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:02 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:02 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:02 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:02 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:02 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:02 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:02 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:02 --> Parser Class Initialized
INFO - 2023-09-20 15:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:02 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:02 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:02 --> Controller Class Initialized
DEBUG - 2023-09-20 15:44:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:02 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:02 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:02 --> Model Class Initialized
INFO - 2023-09-20 15:44:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-20 15:44:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:44:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:44:02 --> Model Class Initialized
INFO - 2023-09-20 15:44:02 --> Model Class Initialized
INFO - 2023-09-20 15:44:02 --> Model Class Initialized
INFO - 2023-09-20 15:44:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:44:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:44:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:44:02 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:02 --> Total execution time: 0.1454
ERROR - 2023-09-20 15:44:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:03 --> Config Class Initialized
INFO - 2023-09-20 15:44:03 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:03 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:03 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:03 --> URI Class Initialized
INFO - 2023-09-20 15:44:03 --> Router Class Initialized
INFO - 2023-09-20 15:44:03 --> Output Class Initialized
INFO - 2023-09-20 15:44:03 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:03 --> Input Class Initialized
INFO - 2023-09-20 15:44:03 --> Language Class Initialized
INFO - 2023-09-20 15:44:03 --> Loader Class Initialized
INFO - 2023-09-20 15:44:03 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:03 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:03 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:03 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:03 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:03 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:03 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:03 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:03 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:03 --> Parser Class Initialized
INFO - 2023-09-20 15:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:03 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:03 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:03 --> Controller Class Initialized
DEBUG - 2023-09-20 15:44:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:03 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:03 --> Model Class Initialized
INFO - 2023-09-20 15:44:03 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:03 --> Total execution time: 0.0354
ERROR - 2023-09-20 15:44:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:08 --> Config Class Initialized
INFO - 2023-09-20 15:44:08 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:08 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:08 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:08 --> URI Class Initialized
INFO - 2023-09-20 15:44:08 --> Router Class Initialized
INFO - 2023-09-20 15:44:08 --> Output Class Initialized
INFO - 2023-09-20 15:44:08 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:08 --> Input Class Initialized
INFO - 2023-09-20 15:44:08 --> Language Class Initialized
INFO - 2023-09-20 15:44:08 --> Loader Class Initialized
INFO - 2023-09-20 15:44:08 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:08 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:08 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:08 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:08 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:08 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:08 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:08 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:08 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:08 --> Parser Class Initialized
INFO - 2023-09-20 15:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:08 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:08 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:08 --> Controller Class Initialized
DEBUG - 2023-09-20 15:44:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:08 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:08 --> Model Class Initialized
INFO - 2023-09-20 15:44:08 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:08 --> Total execution time: 0.0307
ERROR - 2023-09-20 15:44:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:11 --> Config Class Initialized
INFO - 2023-09-20 15:44:11 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:11 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:11 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:11 --> URI Class Initialized
INFO - 2023-09-20 15:44:11 --> Router Class Initialized
INFO - 2023-09-20 15:44:11 --> Output Class Initialized
INFO - 2023-09-20 15:44:11 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:11 --> Input Class Initialized
INFO - 2023-09-20 15:44:11 --> Language Class Initialized
INFO - 2023-09-20 15:44:11 --> Loader Class Initialized
INFO - 2023-09-20 15:44:11 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:11 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:11 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:11 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:11 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:11 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:11 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:11 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:11 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:11 --> Parser Class Initialized
INFO - 2023-09-20 15:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:11 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:11 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:11 --> Controller Class Initialized
DEBUG - 2023-09-20 15:44:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:11 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:11 --> Model Class Initialized
INFO - 2023-09-20 15:44:11 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:11 --> Total execution time: 0.1542
ERROR - 2023-09-20 15:44:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:19 --> Config Class Initialized
INFO - 2023-09-20 15:44:19 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:19 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:19 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:19 --> URI Class Initialized
INFO - 2023-09-20 15:44:19 --> Router Class Initialized
INFO - 2023-09-20 15:44:19 --> Output Class Initialized
INFO - 2023-09-20 15:44:19 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:19 --> Input Class Initialized
INFO - 2023-09-20 15:44:19 --> Language Class Initialized
INFO - 2023-09-20 15:44:19 --> Loader Class Initialized
INFO - 2023-09-20 15:44:19 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:19 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:19 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:19 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:19 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:19 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:19 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:19 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:19 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:19 --> Parser Class Initialized
INFO - 2023-09-20 15:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:19 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:19 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:19 --> Controller Class Initialized
DEBUG - 2023-09-20 15:44:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:19 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:19 --> Model Class Initialized
INFO - 2023-09-20 15:44:19 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:19 --> Total execution time: 0.1534
ERROR - 2023-09-20 15:44:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:40 --> Config Class Initialized
INFO - 2023-09-20 15:44:40 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:40 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:40 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:40 --> URI Class Initialized
DEBUG - 2023-09-20 15:44:40 --> No URI present. Default controller set.
INFO - 2023-09-20 15:44:40 --> Router Class Initialized
INFO - 2023-09-20 15:44:40 --> Output Class Initialized
INFO - 2023-09-20 15:44:40 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:40 --> Input Class Initialized
INFO - 2023-09-20 15:44:40 --> Language Class Initialized
INFO - 2023-09-20 15:44:40 --> Loader Class Initialized
INFO - 2023-09-20 15:44:40 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:40 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:40 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:40 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:40 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:40 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:40 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:40 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:40 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:40 --> Parser Class Initialized
INFO - 2023-09-20 15:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:40 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:40 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:40 --> Controller Class Initialized
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
INFO - 2023-09-20 15:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:44:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:44:40 --> Model Class Initialized
INFO - 2023-09-20 15:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:44:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:44:40 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:40 --> Total execution time: 0.2152
ERROR - 2023-09-20 15:44:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:46 --> Config Class Initialized
INFO - 2023-09-20 15:44:46 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:46 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:46 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:46 --> URI Class Initialized
DEBUG - 2023-09-20 15:44:46 --> No URI present. Default controller set.
INFO - 2023-09-20 15:44:46 --> Router Class Initialized
INFO - 2023-09-20 15:44:46 --> Output Class Initialized
INFO - 2023-09-20 15:44:46 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:46 --> Input Class Initialized
INFO - 2023-09-20 15:44:46 --> Language Class Initialized
INFO - 2023-09-20 15:44:46 --> Loader Class Initialized
INFO - 2023-09-20 15:44:46 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:46 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:46 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:46 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:46 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:46 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:46 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:46 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:46 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:46 --> Parser Class Initialized
INFO - 2023-09-20 15:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:46 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:46 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:46 --> Controller Class Initialized
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
INFO - 2023-09-20 15:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:44:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:44:46 --> Model Class Initialized
INFO - 2023-09-20 15:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:44:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:44:46 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:46 --> Total execution time: 0.1008
ERROR - 2023-09-20 15:44:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:54 --> Config Class Initialized
INFO - 2023-09-20 15:44:54 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:54 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:54 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:54 --> URI Class Initialized
INFO - 2023-09-20 15:44:54 --> Router Class Initialized
INFO - 2023-09-20 15:44:54 --> Output Class Initialized
INFO - 2023-09-20 15:44:54 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:54 --> Input Class Initialized
INFO - 2023-09-20 15:44:54 --> Language Class Initialized
INFO - 2023-09-20 15:44:54 --> Loader Class Initialized
INFO - 2023-09-20 15:44:54 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:54 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:54 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:54 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:54 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:54 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:54 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:54 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:54 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:54 --> Parser Class Initialized
INFO - 2023-09-20 15:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:54 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:54 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:54 --> Controller Class Initialized
INFO - 2023-09-20 15:44:54 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:54 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:54 --> Model Class Initialized
INFO - 2023-09-20 15:44:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:44:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:44:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:44:54 --> Model Class Initialized
INFO - 2023-09-20 15:44:54 --> Model Class Initialized
INFO - 2023-09-20 15:44:54 --> Model Class Initialized
INFO - 2023-09-20 15:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:44:55 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:55 --> Total execution time: 0.0871
ERROR - 2023-09-20 15:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:55 --> Config Class Initialized
INFO - 2023-09-20 15:44:55 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:55 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:55 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:55 --> URI Class Initialized
INFO - 2023-09-20 15:44:55 --> Router Class Initialized
INFO - 2023-09-20 15:44:55 --> Output Class Initialized
INFO - 2023-09-20 15:44:55 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:55 --> Input Class Initialized
INFO - 2023-09-20 15:44:55 --> Language Class Initialized
INFO - 2023-09-20 15:44:55 --> Loader Class Initialized
INFO - 2023-09-20 15:44:55 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:55 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:55 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:55 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:55 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:55 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:55 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:55 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:55 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:55 --> Parser Class Initialized
INFO - 2023-09-20 15:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:55 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:55 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:55 --> Controller Class Initialized
INFO - 2023-09-20 15:44:55 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:55 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:55 --> Model Class Initialized
INFO - 2023-09-20 15:44:55 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:55 --> Total execution time: 0.0388
ERROR - 2023-09-20 15:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:44:58 --> Config Class Initialized
INFO - 2023-09-20 15:44:58 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:44:58 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:44:58 --> Utf8 Class Initialized
INFO - 2023-09-20 15:44:58 --> URI Class Initialized
INFO - 2023-09-20 15:44:58 --> Router Class Initialized
INFO - 2023-09-20 15:44:58 --> Output Class Initialized
INFO - 2023-09-20 15:44:58 --> Security Class Initialized
DEBUG - 2023-09-20 15:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:44:58 --> Input Class Initialized
INFO - 2023-09-20 15:44:58 --> Language Class Initialized
INFO - 2023-09-20 15:44:58 --> Loader Class Initialized
INFO - 2023-09-20 15:44:58 --> Helper loaded: url_helper
INFO - 2023-09-20 15:44:58 --> Helper loaded: file_helper
INFO - 2023-09-20 15:44:58 --> Helper loaded: html_helper
INFO - 2023-09-20 15:44:58 --> Helper loaded: text_helper
INFO - 2023-09-20 15:44:58 --> Helper loaded: form_helper
INFO - 2023-09-20 15:44:58 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:44:58 --> Helper loaded: security_helper
INFO - 2023-09-20 15:44:58 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:44:58 --> Database Driver Class Initialized
INFO - 2023-09-20 15:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:44:58 --> Parser Class Initialized
INFO - 2023-09-20 15:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:44:58 --> Pagination Class Initialized
INFO - 2023-09-20 15:44:58 --> Form Validation Class Initialized
INFO - 2023-09-20 15:44:58 --> Controller Class Initialized
INFO - 2023-09-20 15:44:58 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:58 --> Model Class Initialized
DEBUG - 2023-09-20 15:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:44:58 --> Model Class Initialized
INFO - 2023-09-20 15:44:59 --> Final output sent to browser
DEBUG - 2023-09-20 15:44:59 --> Total execution time: 0.3130
ERROR - 2023-09-20 15:45:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:45:09 --> Config Class Initialized
INFO - 2023-09-20 15:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:45:09 --> Utf8 Class Initialized
INFO - 2023-09-20 15:45:09 --> URI Class Initialized
DEBUG - 2023-09-20 15:45:09 --> No URI present. Default controller set.
INFO - 2023-09-20 15:45:09 --> Router Class Initialized
INFO - 2023-09-20 15:45:09 --> Output Class Initialized
INFO - 2023-09-20 15:45:09 --> Security Class Initialized
DEBUG - 2023-09-20 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:45:09 --> Input Class Initialized
INFO - 2023-09-20 15:45:09 --> Language Class Initialized
INFO - 2023-09-20 15:45:09 --> Loader Class Initialized
INFO - 2023-09-20 15:45:09 --> Helper loaded: url_helper
INFO - 2023-09-20 15:45:09 --> Helper loaded: file_helper
INFO - 2023-09-20 15:45:09 --> Helper loaded: html_helper
INFO - 2023-09-20 15:45:09 --> Helper loaded: text_helper
INFO - 2023-09-20 15:45:09 --> Helper loaded: form_helper
INFO - 2023-09-20 15:45:09 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:45:09 --> Helper loaded: security_helper
INFO - 2023-09-20 15:45:09 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:45:09 --> Database Driver Class Initialized
INFO - 2023-09-20 15:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:45:09 --> Parser Class Initialized
INFO - 2023-09-20 15:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:45:09 --> Pagination Class Initialized
INFO - 2023-09-20 15:45:09 --> Form Validation Class Initialized
INFO - 2023-09-20 15:45:09 --> Controller Class Initialized
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:45:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
INFO - 2023-09-20 15:45:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:45:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:45:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:45:09 --> Model Class Initialized
INFO - 2023-09-20 15:45:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:45:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:45:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:45:09 --> Final output sent to browser
DEBUG - 2023-09-20 15:45:09 --> Total execution time: 0.1091
ERROR - 2023-09-20 15:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:45:18 --> Config Class Initialized
INFO - 2023-09-20 15:45:18 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:45:18 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:45:18 --> Utf8 Class Initialized
INFO - 2023-09-20 15:45:18 --> URI Class Initialized
DEBUG - 2023-09-20 15:45:18 --> No URI present. Default controller set.
INFO - 2023-09-20 15:45:18 --> Router Class Initialized
INFO - 2023-09-20 15:45:18 --> Output Class Initialized
INFO - 2023-09-20 15:45:18 --> Security Class Initialized
DEBUG - 2023-09-20 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:45:18 --> Input Class Initialized
INFO - 2023-09-20 15:45:18 --> Language Class Initialized
INFO - 2023-09-20 15:45:18 --> Loader Class Initialized
INFO - 2023-09-20 15:45:18 --> Helper loaded: url_helper
INFO - 2023-09-20 15:45:18 --> Helper loaded: file_helper
INFO - 2023-09-20 15:45:18 --> Helper loaded: html_helper
INFO - 2023-09-20 15:45:18 --> Helper loaded: text_helper
INFO - 2023-09-20 15:45:18 --> Helper loaded: form_helper
INFO - 2023-09-20 15:45:18 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:45:18 --> Helper loaded: security_helper
INFO - 2023-09-20 15:45:18 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:45:18 --> Database Driver Class Initialized
INFO - 2023-09-20 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:45:18 --> Parser Class Initialized
INFO - 2023-09-20 15:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:45:18 --> Pagination Class Initialized
INFO - 2023-09-20 15:45:18 --> Form Validation Class Initialized
INFO - 2023-09-20 15:45:18 --> Controller Class Initialized
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
INFO - 2023-09-20 15:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:45:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:45:18 --> Model Class Initialized
INFO - 2023-09-20 15:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:45:18 --> Final output sent to browser
DEBUG - 2023-09-20 15:45:18 --> Total execution time: 0.2151
ERROR - 2023-09-20 15:45:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:45:24 --> Config Class Initialized
INFO - 2023-09-20 15:45:24 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:45:24 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:45:24 --> Utf8 Class Initialized
INFO - 2023-09-20 15:45:24 --> URI Class Initialized
DEBUG - 2023-09-20 15:45:24 --> No URI present. Default controller set.
INFO - 2023-09-20 15:45:24 --> Router Class Initialized
INFO - 2023-09-20 15:45:24 --> Output Class Initialized
INFO - 2023-09-20 15:45:24 --> Security Class Initialized
DEBUG - 2023-09-20 15:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:45:24 --> Input Class Initialized
INFO - 2023-09-20 15:45:24 --> Language Class Initialized
INFO - 2023-09-20 15:45:24 --> Loader Class Initialized
INFO - 2023-09-20 15:45:24 --> Helper loaded: url_helper
INFO - 2023-09-20 15:45:24 --> Helper loaded: file_helper
INFO - 2023-09-20 15:45:24 --> Helper loaded: html_helper
INFO - 2023-09-20 15:45:24 --> Helper loaded: text_helper
INFO - 2023-09-20 15:45:24 --> Helper loaded: form_helper
INFO - 2023-09-20 15:45:24 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:45:24 --> Helper loaded: security_helper
INFO - 2023-09-20 15:45:24 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:45:24 --> Database Driver Class Initialized
INFO - 2023-09-20 15:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:45:24 --> Parser Class Initialized
INFO - 2023-09-20 15:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:45:24 --> Pagination Class Initialized
INFO - 2023-09-20 15:45:24 --> Form Validation Class Initialized
INFO - 2023-09-20 15:45:24 --> Controller Class Initialized
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
INFO - 2023-09-20 15:45:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:45:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:45:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:45:24 --> Model Class Initialized
INFO - 2023-09-20 15:45:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:45:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:45:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:45:24 --> Final output sent to browser
DEBUG - 2023-09-20 15:45:24 --> Total execution time: 0.2095
ERROR - 2023-09-20 15:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:45:44 --> Config Class Initialized
INFO - 2023-09-20 15:45:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:45:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:45:44 --> Utf8 Class Initialized
INFO - 2023-09-20 15:45:44 --> URI Class Initialized
INFO - 2023-09-20 15:45:44 --> Router Class Initialized
INFO - 2023-09-20 15:45:44 --> Output Class Initialized
INFO - 2023-09-20 15:45:44 --> Security Class Initialized
DEBUG - 2023-09-20 15:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:45:44 --> Input Class Initialized
INFO - 2023-09-20 15:45:44 --> Language Class Initialized
INFO - 2023-09-20 15:45:44 --> Loader Class Initialized
INFO - 2023-09-20 15:45:44 --> Helper loaded: url_helper
INFO - 2023-09-20 15:45:44 --> Helper loaded: file_helper
INFO - 2023-09-20 15:45:44 --> Helper loaded: html_helper
INFO - 2023-09-20 15:45:44 --> Helper loaded: text_helper
INFO - 2023-09-20 15:45:44 --> Helper loaded: form_helper
INFO - 2023-09-20 15:45:44 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:45:44 --> Helper loaded: security_helper
INFO - 2023-09-20 15:45:44 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:45:44 --> Database Driver Class Initialized
INFO - 2023-09-20 15:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:45:44 --> Parser Class Initialized
INFO - 2023-09-20 15:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:45:44 --> Pagination Class Initialized
INFO - 2023-09-20 15:45:44 --> Form Validation Class Initialized
INFO - 2023-09-20 15:45:44 --> Controller Class Initialized
INFO - 2023-09-20 15:45:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:44 --> Model Class Initialized
INFO - 2023-09-20 15:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-20 15:45:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:45:44 --> Model Class Initialized
INFO - 2023-09-20 15:45:44 --> Model Class Initialized
INFO - 2023-09-20 15:45:44 --> Model Class Initialized
INFO - 2023-09-20 15:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:45:44 --> Final output sent to browser
DEBUG - 2023-09-20 15:45:44 --> Total execution time: 0.1672
ERROR - 2023-09-20 15:45:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:45:45 --> Config Class Initialized
INFO - 2023-09-20 15:45:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:45:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:45:45 --> Utf8 Class Initialized
INFO - 2023-09-20 15:45:45 --> URI Class Initialized
INFO - 2023-09-20 15:45:45 --> Router Class Initialized
INFO - 2023-09-20 15:45:45 --> Output Class Initialized
INFO - 2023-09-20 15:45:45 --> Security Class Initialized
DEBUG - 2023-09-20 15:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:45:45 --> Input Class Initialized
INFO - 2023-09-20 15:45:45 --> Language Class Initialized
INFO - 2023-09-20 15:45:45 --> Loader Class Initialized
INFO - 2023-09-20 15:45:45 --> Helper loaded: url_helper
INFO - 2023-09-20 15:45:45 --> Helper loaded: file_helper
INFO - 2023-09-20 15:45:45 --> Helper loaded: html_helper
INFO - 2023-09-20 15:45:45 --> Helper loaded: text_helper
INFO - 2023-09-20 15:45:45 --> Helper loaded: form_helper
INFO - 2023-09-20 15:45:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:45:45 --> Helper loaded: security_helper
INFO - 2023-09-20 15:45:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:45:45 --> Database Driver Class Initialized
INFO - 2023-09-20 15:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:45:45 --> Parser Class Initialized
INFO - 2023-09-20 15:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:45:45 --> Pagination Class Initialized
INFO - 2023-09-20 15:45:45 --> Form Validation Class Initialized
INFO - 2023-09-20 15:45:45 --> Controller Class Initialized
INFO - 2023-09-20 15:45:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:45 --> Model Class Initialized
INFO - 2023-09-20 15:45:45 --> Final output sent to browser
DEBUG - 2023-09-20 15:45:45 --> Total execution time: 0.0632
ERROR - 2023-09-20 15:45:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:45:48 --> Config Class Initialized
INFO - 2023-09-20 15:45:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:45:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:45:48 --> Utf8 Class Initialized
INFO - 2023-09-20 15:45:48 --> URI Class Initialized
INFO - 2023-09-20 15:45:48 --> Router Class Initialized
INFO - 2023-09-20 15:45:48 --> Output Class Initialized
INFO - 2023-09-20 15:45:48 --> Security Class Initialized
DEBUG - 2023-09-20 15:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:45:48 --> Input Class Initialized
INFO - 2023-09-20 15:45:48 --> Language Class Initialized
INFO - 2023-09-20 15:45:48 --> Loader Class Initialized
INFO - 2023-09-20 15:45:48 --> Helper loaded: url_helper
INFO - 2023-09-20 15:45:48 --> Helper loaded: file_helper
INFO - 2023-09-20 15:45:48 --> Helper loaded: html_helper
INFO - 2023-09-20 15:45:48 --> Helper loaded: text_helper
INFO - 2023-09-20 15:45:48 --> Helper loaded: form_helper
INFO - 2023-09-20 15:45:48 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:45:48 --> Helper loaded: security_helper
INFO - 2023-09-20 15:45:48 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:45:48 --> Database Driver Class Initialized
INFO - 2023-09-20 15:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:45:48 --> Parser Class Initialized
INFO - 2023-09-20 15:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:45:48 --> Pagination Class Initialized
INFO - 2023-09-20 15:45:48 --> Form Validation Class Initialized
INFO - 2023-09-20 15:45:48 --> Controller Class Initialized
INFO - 2023-09-20 15:45:48 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:48 --> Model Class Initialized
DEBUG - 2023-09-20 15:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:45:48 --> Model Class Initialized
INFO - 2023-09-20 15:45:49 --> Final output sent to browser
DEBUG - 2023-09-20 15:45:49 --> Total execution time: 0.8892
ERROR - 2023-09-20 15:46:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:46:44 --> Config Class Initialized
INFO - 2023-09-20 15:46:44 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:46:44 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:46:44 --> Utf8 Class Initialized
INFO - 2023-09-20 15:46:44 --> URI Class Initialized
INFO - 2023-09-20 15:46:44 --> Router Class Initialized
INFO - 2023-09-20 15:46:44 --> Output Class Initialized
INFO - 2023-09-20 15:46:44 --> Security Class Initialized
DEBUG - 2023-09-20 15:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:46:44 --> Input Class Initialized
INFO - 2023-09-20 15:46:44 --> Language Class Initialized
INFO - 2023-09-20 15:46:44 --> Loader Class Initialized
INFO - 2023-09-20 15:46:44 --> Helper loaded: url_helper
INFO - 2023-09-20 15:46:44 --> Helper loaded: file_helper
INFO - 2023-09-20 15:46:44 --> Helper loaded: html_helper
INFO - 2023-09-20 15:46:44 --> Helper loaded: text_helper
INFO - 2023-09-20 15:46:44 --> Helper loaded: form_helper
INFO - 2023-09-20 15:46:44 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:46:44 --> Helper loaded: security_helper
INFO - 2023-09-20 15:46:44 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:46:44 --> Database Driver Class Initialized
INFO - 2023-09-20 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:46:44 --> Parser Class Initialized
INFO - 2023-09-20 15:46:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:46:44 --> Pagination Class Initialized
INFO - 2023-09-20 15:46:44 --> Form Validation Class Initialized
INFO - 2023-09-20 15:46:44 --> Controller Class Initialized
INFO - 2023-09-20 15:46:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:44 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:44 --> Model Class Initialized
ERROR - 2023-09-20 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php 113
INFO - 2023-09-20 15:46:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/edit_invoice_form.php
DEBUG - 2023-09-20 15:46:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:46:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:46:44 --> Model Class Initialized
INFO - 2023-09-20 15:46:44 --> Model Class Initialized
INFO - 2023-09-20 15:46:44 --> Model Class Initialized
INFO - 2023-09-20 15:46:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:46:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:46:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:46:44 --> Final output sent to browser
DEBUG - 2023-09-20 15:46:44 --> Total execution time: 0.2043
ERROR - 2023-09-20 15:46:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:46:45 --> Config Class Initialized
INFO - 2023-09-20 15:46:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:46:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:46:45 --> Utf8 Class Initialized
INFO - 2023-09-20 15:46:45 --> URI Class Initialized
INFO - 2023-09-20 15:46:45 --> Router Class Initialized
INFO - 2023-09-20 15:46:45 --> Output Class Initialized
INFO - 2023-09-20 15:46:45 --> Security Class Initialized
DEBUG - 2023-09-20 15:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:46:45 --> Input Class Initialized
INFO - 2023-09-20 15:46:45 --> Language Class Initialized
INFO - 2023-09-20 15:46:45 --> Loader Class Initialized
INFO - 2023-09-20 15:46:45 --> Helper loaded: url_helper
INFO - 2023-09-20 15:46:45 --> Helper loaded: file_helper
INFO - 2023-09-20 15:46:45 --> Helper loaded: html_helper
INFO - 2023-09-20 15:46:45 --> Helper loaded: text_helper
INFO - 2023-09-20 15:46:45 --> Helper loaded: form_helper
INFO - 2023-09-20 15:46:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:46:45 --> Helper loaded: security_helper
INFO - 2023-09-20 15:46:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:46:45 --> Database Driver Class Initialized
INFO - 2023-09-20 15:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:46:45 --> Parser Class Initialized
INFO - 2023-09-20 15:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:46:45 --> Pagination Class Initialized
INFO - 2023-09-20 15:46:45 --> Form Validation Class Initialized
INFO - 2023-09-20 15:46:45 --> Controller Class Initialized
INFO - 2023-09-20 15:46:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:45 --> Model Class Initialized
INFO - 2023-09-20 15:46:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:45 --> Final output sent to browser
DEBUG - 2023-09-20 15:46:45 --> Total execution time: 0.0212
ERROR - 2023-09-20 15:46:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:46:52 --> Config Class Initialized
INFO - 2023-09-20 15:46:52 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:46:52 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:46:52 --> Utf8 Class Initialized
INFO - 2023-09-20 15:46:52 --> URI Class Initialized
DEBUG - 2023-09-20 15:46:52 --> No URI present. Default controller set.
INFO - 2023-09-20 15:46:52 --> Router Class Initialized
INFO - 2023-09-20 15:46:52 --> Output Class Initialized
INFO - 2023-09-20 15:46:52 --> Security Class Initialized
DEBUG - 2023-09-20 15:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:46:52 --> Input Class Initialized
INFO - 2023-09-20 15:46:52 --> Language Class Initialized
INFO - 2023-09-20 15:46:52 --> Loader Class Initialized
INFO - 2023-09-20 15:46:52 --> Helper loaded: url_helper
INFO - 2023-09-20 15:46:52 --> Helper loaded: file_helper
INFO - 2023-09-20 15:46:52 --> Helper loaded: html_helper
INFO - 2023-09-20 15:46:52 --> Helper loaded: text_helper
INFO - 2023-09-20 15:46:52 --> Helper loaded: form_helper
INFO - 2023-09-20 15:46:52 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:46:52 --> Helper loaded: security_helper
INFO - 2023-09-20 15:46:52 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:46:52 --> Database Driver Class Initialized
INFO - 2023-09-20 15:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:46:52 --> Parser Class Initialized
INFO - 2023-09-20 15:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:46:52 --> Pagination Class Initialized
INFO - 2023-09-20 15:46:52 --> Form Validation Class Initialized
INFO - 2023-09-20 15:46:52 --> Controller Class Initialized
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
DEBUG - 2023-09-20 15:46:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
INFO - 2023-09-20 15:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:46:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:46:52 --> Model Class Initialized
INFO - 2023-09-20 15:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:46:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:46:52 --> Final output sent to browser
DEBUG - 2023-09-20 15:46:52 --> Total execution time: 0.2307
ERROR - 2023-09-20 15:48:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:48:34 --> Config Class Initialized
INFO - 2023-09-20 15:48:34 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:48:34 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:48:34 --> Utf8 Class Initialized
INFO - 2023-09-20 15:48:34 --> URI Class Initialized
DEBUG - 2023-09-20 15:48:34 --> No URI present. Default controller set.
INFO - 2023-09-20 15:48:34 --> Router Class Initialized
INFO - 2023-09-20 15:48:34 --> Output Class Initialized
INFO - 2023-09-20 15:48:34 --> Security Class Initialized
DEBUG - 2023-09-20 15:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:48:34 --> Input Class Initialized
INFO - 2023-09-20 15:48:34 --> Language Class Initialized
INFO - 2023-09-20 15:48:34 --> Loader Class Initialized
INFO - 2023-09-20 15:48:34 --> Helper loaded: url_helper
INFO - 2023-09-20 15:48:34 --> Helper loaded: file_helper
INFO - 2023-09-20 15:48:34 --> Helper loaded: html_helper
INFO - 2023-09-20 15:48:34 --> Helper loaded: text_helper
INFO - 2023-09-20 15:48:34 --> Helper loaded: form_helper
INFO - 2023-09-20 15:48:34 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:48:34 --> Helper loaded: security_helper
INFO - 2023-09-20 15:48:34 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:48:34 --> Database Driver Class Initialized
INFO - 2023-09-20 15:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:48:34 --> Parser Class Initialized
INFO - 2023-09-20 15:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:48:34 --> Pagination Class Initialized
INFO - 2023-09-20 15:48:34 --> Form Validation Class Initialized
INFO - 2023-09-20 15:48:34 --> Controller Class Initialized
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
INFO - 2023-09-20 15:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:48:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:48:34 --> Model Class Initialized
INFO - 2023-09-20 15:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:48:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:48:34 --> Final output sent to browser
DEBUG - 2023-09-20 15:48:34 --> Total execution time: 0.1034
ERROR - 2023-09-20 15:48:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:48:37 --> Config Class Initialized
INFO - 2023-09-20 15:48:37 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:48:37 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:48:37 --> Utf8 Class Initialized
INFO - 2023-09-20 15:48:37 --> URI Class Initialized
DEBUG - 2023-09-20 15:48:37 --> No URI present. Default controller set.
INFO - 2023-09-20 15:48:37 --> Router Class Initialized
INFO - 2023-09-20 15:48:37 --> Output Class Initialized
INFO - 2023-09-20 15:48:37 --> Security Class Initialized
DEBUG - 2023-09-20 15:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:48:37 --> Input Class Initialized
INFO - 2023-09-20 15:48:37 --> Language Class Initialized
INFO - 2023-09-20 15:48:37 --> Loader Class Initialized
INFO - 2023-09-20 15:48:37 --> Helper loaded: url_helper
INFO - 2023-09-20 15:48:37 --> Helper loaded: file_helper
INFO - 2023-09-20 15:48:37 --> Helper loaded: html_helper
INFO - 2023-09-20 15:48:37 --> Helper loaded: text_helper
INFO - 2023-09-20 15:48:37 --> Helper loaded: form_helper
INFO - 2023-09-20 15:48:37 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:48:37 --> Helper loaded: security_helper
INFO - 2023-09-20 15:48:37 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:48:37 --> Database Driver Class Initialized
INFO - 2023-09-20 15:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:48:37 --> Parser Class Initialized
INFO - 2023-09-20 15:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:48:37 --> Pagination Class Initialized
INFO - 2023-09-20 15:48:37 --> Form Validation Class Initialized
INFO - 2023-09-20 15:48:37 --> Controller Class Initialized
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
INFO - 2023-09-20 15:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-20 15:48:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:48:37 --> Model Class Initialized
INFO - 2023-09-20 15:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:48:37 --> Final output sent to browser
DEBUG - 2023-09-20 15:48:37 --> Total execution time: 0.1048
ERROR - 2023-09-20 15:48:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:48:45 --> Config Class Initialized
INFO - 2023-09-20 15:48:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:48:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:48:45 --> Utf8 Class Initialized
INFO - 2023-09-20 15:48:45 --> URI Class Initialized
INFO - 2023-09-20 15:48:45 --> Router Class Initialized
INFO - 2023-09-20 15:48:45 --> Output Class Initialized
INFO - 2023-09-20 15:48:45 --> Security Class Initialized
DEBUG - 2023-09-20 15:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:48:45 --> Input Class Initialized
INFO - 2023-09-20 15:48:45 --> Language Class Initialized
INFO - 2023-09-20 15:48:45 --> Loader Class Initialized
INFO - 2023-09-20 15:48:45 --> Helper loaded: url_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: file_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: html_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: text_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: form_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: security_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:48:45 --> Database Driver Class Initialized
INFO - 2023-09-20 15:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:48:45 --> Parser Class Initialized
INFO - 2023-09-20 15:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:48:45 --> Pagination Class Initialized
INFO - 2023-09-20 15:48:45 --> Form Validation Class Initialized
INFO - 2023-09-20 15:48:45 --> Controller Class Initialized
DEBUG - 2023-09-20 15:48:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
INFO - 2023-09-20 15:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-20 15:48:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-20 15:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
INFO - 2023-09-20 15:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-20 15:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-20 15:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-20 15:48:45 --> Final output sent to browser
DEBUG - 2023-09-20 15:48:45 --> Total execution time: 0.0812
ERROR - 2023-09-20 15:48:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:48:45 --> Config Class Initialized
INFO - 2023-09-20 15:48:45 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:48:45 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:48:45 --> Utf8 Class Initialized
INFO - 2023-09-20 15:48:45 --> URI Class Initialized
INFO - 2023-09-20 15:48:45 --> Router Class Initialized
INFO - 2023-09-20 15:48:45 --> Output Class Initialized
INFO - 2023-09-20 15:48:45 --> Security Class Initialized
DEBUG - 2023-09-20 15:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:48:45 --> Input Class Initialized
INFO - 2023-09-20 15:48:45 --> Language Class Initialized
INFO - 2023-09-20 15:48:45 --> Loader Class Initialized
INFO - 2023-09-20 15:48:45 --> Helper loaded: url_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: file_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: html_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: text_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: form_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: security_helper
INFO - 2023-09-20 15:48:45 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:48:45 --> Database Driver Class Initialized
INFO - 2023-09-20 15:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:48:45 --> Parser Class Initialized
INFO - 2023-09-20 15:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:48:45 --> Pagination Class Initialized
INFO - 2023-09-20 15:48:45 --> Form Validation Class Initialized
INFO - 2023-09-20 15:48:45 --> Controller Class Initialized
DEBUG - 2023-09-20 15:48:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:45 --> Model Class Initialized
INFO - 2023-09-20 15:48:45 --> Final output sent to browser
DEBUG - 2023-09-20 15:48:45 --> Total execution time: 0.0212
ERROR - 2023-09-20 15:48:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-20 15:48:48 --> Config Class Initialized
INFO - 2023-09-20 15:48:48 --> Hooks Class Initialized
DEBUG - 2023-09-20 15:48:48 --> UTF-8 Support Enabled
INFO - 2023-09-20 15:48:48 --> Utf8 Class Initialized
INFO - 2023-09-20 15:48:48 --> URI Class Initialized
INFO - 2023-09-20 15:48:48 --> Router Class Initialized
INFO - 2023-09-20 15:48:48 --> Output Class Initialized
INFO - 2023-09-20 15:48:48 --> Security Class Initialized
DEBUG - 2023-09-20 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-20 15:48:48 --> Input Class Initialized
INFO - 2023-09-20 15:48:48 --> Language Class Initialized
INFO - 2023-09-20 15:48:48 --> Loader Class Initialized
INFO - 2023-09-20 15:48:48 --> Helper loaded: url_helper
INFO - 2023-09-20 15:48:48 --> Helper loaded: file_helper
INFO - 2023-09-20 15:48:48 --> Helper loaded: html_helper
INFO - 2023-09-20 15:48:48 --> Helper loaded: text_helper
INFO - 2023-09-20 15:48:48 --> Helper loaded: form_helper
INFO - 2023-09-20 15:48:48 --> Helper loaded: lang_helper
INFO - 2023-09-20 15:48:48 --> Helper loaded: security_helper
INFO - 2023-09-20 15:48:48 --> Helper loaded: cookie_helper
INFO - 2023-09-20 15:48:48 --> Database Driver Class Initialized
INFO - 2023-09-20 15:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-20 15:48:48 --> Parser Class Initialized
INFO - 2023-09-20 15:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-20 15:48:48 --> Pagination Class Initialized
INFO - 2023-09-20 15:48:48 --> Form Validation Class Initialized
INFO - 2023-09-20 15:48:48 --> Controller Class Initialized
DEBUG - 2023-09-20 15:48:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-20 15:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:48 --> Model Class Initialized
DEBUG - 2023-09-20 15:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-20 15:48:48 --> Model Class Initialized
INFO - 2023-09-20 15:48:48 --> Final output sent to browser
DEBUG - 2023-09-20 15:48:48 --> Total execution time: 0.0406
